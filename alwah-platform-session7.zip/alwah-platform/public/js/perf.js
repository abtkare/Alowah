// ألواح — شاشات تحليل الأداء: المعاملة، المصرف، الفرع، الموظف
// كل الأرقام تُحسب في قاعدة البيانات من السجل الزمني للمراحل (لا يُدخلها أحد ولا تُعدَّل)
import { esc, num, kpi, rpc, cleanErr, wdTxt, ROLE_LABELS, el } from './core.js';

const PERIODS = [[30, 'آخر 30 يوماً'], [90, 'آخر 90 يوماً'], [120, 'آخر 120 يوماً'], [365, 'آخر سنة']];
const pctTxt = v => v == null ? '—' : `<span class="num">${Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 })}%</span>`;
const tone = v => v == null ? 'muted' : v >= 85 ? 'ok' : v >= 65 ? 'warn' : 'bad';

// mode: 'bank' (نطاق المستخدم) | 'oversight' (المركزي والنزاهة: كل المصارف أو مصرف محدد)
export async function perfView(ctx, host, { mode = 'bank' } = {}) {
  const st = ctx.perf ||= { days: 120, bank: '', sub: new URLSearchParams(location.search).get('sub') || 'overview' };
  const banks = ctx.orgs.filter(o => o.type === 'bank');
  host.innerHTML = `
    <div class="row mb perf-filters" style="flex-wrap:wrap;gap:8px">
      <select class="input sm" data-days>${PERIODS.map(([d, t]) => `<option value="${d}" ${d === st.days ? 'selected' : ''}>${t}</option>`).join('')}</select>
      ${mode === 'oversight' ? `<select class="input sm" data-bank><option value="">كل المصارف</option>${banks.map(b => `<option value="${b.id}" ${b.id === st.bank ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select>` : ''}
      <span class="sp"></span>
      <div class="seg">${[['overview', 'المؤشرات والاختناقات'], ['staff', 'أداء الموظفين'], ['branches', 'الفروع']].map(([k, t]) => `<button class="${st.sub === k ? 'on' : ''}" data-sub="${k}">${t}</button>`).join('')}</div>
    </div>
    <div data-out><div class="spin"></div></div>`;
  host.querySelector('[data-days]').onchange = e => { st.days = +e.target.value; perfView(ctx, host, { mode }); };
  const bs = host.querySelector('[data-bank]'); if (bs) bs.onchange = e => { st.bank = e.target.value; perfView(ctx, host, { mode }); };
  host.querySelectorAll('[data-sub]').forEach(b => b.onclick = () => { st.sub = b.dataset.sub; perfView(ctx, host, { mode }); });
  const out = host.querySelector('[data-out]');
  try {
    const args = { p_bank: st.bank || null, p_days: st.days };
    if (st.sub === 'staff') return renderStaff(out, await rpc(ctx.sb, 'perf_employees', args), mode);
    const ov = await rpc(ctx.sb, 'perf_overview', args);
    if (st.sub === 'branches') return renderBranches(out, ov);
    renderOverview(out, ov);
  } catch (e) { out.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}

function renderOverview(out, ov) {
  const t = ov.totals || {};
  const stages = ov.stages || [];
  const max = Math.max(1, ...stages.map(s => Math.max(Number(s.avg || 0), Number(s.sla || 0))));
  const worst = stages.filter(s => s.done > 0 && s.sla > 0 && Number(s.breach_pct) >= 25).sort((a, b) => b.breach_pct - a.breach_pct || b.avg / b.sla - a.avg / a.sla).slice(0, 3);
  let phase = '';
  out.innerHTML = `
    <div class="grid g4 mb">
      ${kpi('متوسط دورة المعاملة', t.avg_cycle != null ? wdTxt(t.avg_cycle) : '—', 'من استلام المصرف حتى إغلاق الملف', true)}
      ${kpi('المراحل المنجزة ضمن المدة', pctTxt(t.on_time_pct), 'مقابل المدة المسموحة لكل مرحلة')}
      ${kpi('معاملات متأخرة الآن', `<span class="num">${num(t.open_overdue)}</span>`, 'تجاوزت مدة مرحلتها الحالية')}
      ${kpi('المعاملات', `<span class="num">${num(t.apps)}</span>`, `${num(t.completed)} مكتملة · ${num(t.active)} قيد المعالجة · ${num(t.returns)} إعادة`)}
    </div>
    ${ov.banks ? banksTable(ov.banks) : ''}
    ${worst.length ? `<div class="notice warn mb"><div><b>أكبر الاختناقات:</b><ul style="margin:6px 0 0;padding-inline-start:18px">${worst.map(w => `<li>المرحلة <b class="num">${w.stage}</b> «${esc(w.name)}» لدى ${esc(w.unit)}: تجاوزت المدة في ${pctTxt(w.breach_pct)} من المعاملات</li>`).join('')}</ul></div></div>` : ''}
    <div class="card"><h3>مدة كل مرحلة مقابل المدة المسموحة <span class="sp"></span><span class="legend" style="margin:0"><span><i style="background:var(--indigo)"></i>المتوسط</span><span><i style="background:var(--bad)"></i>فوق المسموح</span><span><i class="mk"></i>المسموح</span></span></h3>
      <div class="tl">${stages.map(s => {
        const head = s.phase !== phase ? `<div class="tl-ph">${esc(phase = s.phase)}</div>` : '';
        const over = s.sla > 0 && Number(s.avg) > Number(s.sla);
        return `${head}<div class="tl-r ${over ? 'over' : ''}"><div class="tl-n"><b class="num">${s.stage}</b> ${esc(s.name)}<small>${esc(s.unit)} · أُنجزت <span class="num">${num(s.done)}</span>${s.open ? ` · جارية <span class="num">${s.open}</span>` : ''}${s.open_overdue ? ` · <b style="color:var(--bad)">متأخرة <span class="num">${s.open_overdue}</span></b>` : ''}</small></div>
          <div class="tl-b"><i style="width:${(Number(s.avg || 0) / max * 100).toFixed(1)}%"></i>${s.sla > 0 ? `<u style="inset-inline-start:${(s.sla / max * 100).toFixed(1)}%"></u>` : ''}</div>
          <div class="tl-v">${s.done ? wdTxt(s.avg) : '—'}<small>${s.breach_pct != null ? `تجاوز المدة في ${pctTxt(s.breach_pct)}` : ''} · المسموح ${wdTxt(s.sla)}</small></div></div>`;
      }).join('')}</div>
      <p class="small muted mt">المدة بأيام الدوام الفعلي (تُستثنى الجمعة والسبت). المدد المسموحة مقترحة وقابلة للتعديل من إدارة المنصة بقرار المصرف أو البنك المركزي.</p></div>`;
}

function banksTable(rows) {
  return `<div class="card flush mb"><h3>مقارنة المصارف</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>المعاملات</th><th>مكتملة</th><th>متوسط الدورة</th><th>ضمن المدة</th><th>متأخرة الآن</th><th>انتظار قرار المركزي</th></tr></thead><tbody>
    ${rows.map(b => `<tr><td><b>${esc(b.name)}</b></td><td class="num">${num(b.apps)}</td><td class="num">${num(b.completed)}</td><td>${b.avg_cycle != null ? wdTxt(b.avg_cycle) : '—'}</td>
      <td><span class="badge ${tone(b.on_time_pct)}">${pctTxt(b.on_time_pct)}</span></td><td>${b.open_overdue ? `<span class="badge bad num">${b.open_overdue}</span>` : '<span class="muted">0</span>'}</td><td>${b.cbi_wait != null ? wdTxt(b.cbi_wait) : '—'}</td></tr>`).join('')}
    </tbody></table></div></div>`;
}

function renderBranches(out, ov) {
  const rows = ov.branches || [];
  out.innerHTML = rows.length ? `<div class="card flush"><h3>أداء الفروع</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الفرع</th><th>المصرف</th><th>المعاملات</th><th>متوسط الدورة</th><th>مراحل الفرع ضمن المدة</th><th>متأخرة الآن</th></tr></thead><tbody>
    ${rows.map(b => `<tr><td><b>${esc(b.name)}</b></td><td>${esc(b.bank)}</td><td class="num">${num(b.apps)}</td><td>${b.avg_cycle != null ? wdTxt(b.avg_cycle) : '—'}</td>
      <td><span class="badge ${tone(b.on_time_pct)}">${pctTxt(b.on_time_pct)}</span></td><td>${b.open_overdue ? `<span class="badge bad num">${b.open_overdue}</span>` : '<span class="muted">0</span>'}</td></tr>`).join('')}
    </tbody></table></div></div>` : '<div class="card empty">لا فروع ضمن النطاق.</div>';
}

function renderStaff(out, rows, mode) {
  const flagged = rows.filter(r => r.flags?.length);
  const st = { only: false };
  const draw = () => {
    const list = st.only ? flagged : rows;
    out.innerHTML = `
      <div class="grid g3 mb">
        ${kpi('الموظفون ضمن النطاق', `<span class="num">${rows.length}</span>`, '', true)}
        ${kpi('عليهم مؤشرات تستدعي المراجعة', `<span class="num">${flagged.length}</span>`, 'تأخير، خمول، خارج الدوام، موافقات سريعة')}
        ${kpi('إجراءات منجزة', `<span class="num">${num(rows.reduce((t, r) => t + (r.actions || 0), 0))}</span>`, 'ضمن الفترة')}
      </div>
      <div class="notice mb">المؤشرات إنذار مبكر لا اتهام: تُراجع مع الموظف ومديره قبل أي إجراء. ${mode === 'oversight' ? 'هذه اللوحة للاطلاع فقط.' : 'تُرفع تلقائياً لهيئة النزاهة والبنك المركزي عند التأخير الكبير.'}</div>
      <div class="row mb"><label class="row small" style="gap:6px"><input type="checkbox" data-only ${st.only ? 'checked' : ''}> عرض من عليهم مؤشرات فقط</label></div>
      <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الموظف</th><th>الوحدة</th><th>الفرع</th><th>إجراءات</th><th>متوسط المدة</th><th>تجاوز المدة</th><th>خارج الدوام</th><th>آخر إجراء</th><th>بانتظار وحدته</th><th>المؤشرات</th></tr></thead><tbody>
      ${list.map(r => `<tr class="${r.flags?.length ? 'flag' : ''}"><td><b>${esc(String(r.full_name).split(' — ')[0])}</b>${mode === 'oversight' ? `<div class="small muted">${esc(r.bank)}</div>` : ''}</td>
        <td class="small">${esc(ROLE_LABELS[r.role] || r.role)}</td><td class="small">${esc(r.branch || 'الإدارة العامة')}</td>
        <td class="num">${num(r.actions)}</td><td>${r.actions ? wdTxt(r.avg_wd) : '—'}</td>
        <td>${r.actions ? `<span class="badge ${r.breach_pct >= 40 ? 'bad' : r.breach_pct >= 20 ? 'warn' : 'ok'}">${pctTxt(r.breach_pct)}</span>` : '—'}</td>
        <td class="num">${r.after_hours ? `<b style="color:var(--bad)">${r.after_hours}</b>` : '0'}</td>
        <td class="small">${r.idle_days == null ? '—' : Number(r.idle_days) < 1 ? 'اليوم' : `قبل ${wdTxt(r.idle_days)}`}</td>
        <td class="small">${r.open_items ? `<span class="num">${r.open_items}</span>${r.unit_overdue ? ` · <b style="color:var(--bad)">متأخرة ${r.unit_overdue}</b>` : ''}` : '—'}</td>
        <td>${(r.flags || []).map(f => `<span class="badge bad flagb">${esc(f)}</span>`).join(' ') || '<span class="badge ok">سليم</span>'}</td></tr>`).join('')}
      </tbody></table></div></div>
      <p class="small muted mt"><b>طريقة الحساب:</b> تأخير متكرر = تجاوز المدة في 40% فأكثر من الإجراءات · خمول = لا إجراء منذ 3 أيام دوام مع معاملات متأخرة بانتظار وحدته · خارج الدوام = إجراءات قبل 8 صباحاً أو بعد 4 عصراً أو أيام العطل · موافقات سريعة = اعتماد معاملات من 10 ملايين فأكثر خلال أقل من ربع ساعة.</p>`;
    out.querySelector('[data-only]').onchange = e => { st.only = e.target.checked; draw(); };
  };
  draw();
}

// «أدائي» — لكل موظف عن نفسه
export async function myPerf(ctx, host) {
  host.innerHTML = '<div class="spin"></div>';
  try {
    const r = await rpc(ctx.sb, 'perf_me', { p_days: 120 });
    host.innerHTML = `
      <div class="grid g4 mb">
        ${kpi('إجراءاتي المنجزة', `<span class="num">${num(r.actions || 0)}</span>`, 'آخر 120 يوماً', true)}
        ${kpi('متوسط مدة إنجازي', r.actions ? wdTxt(r.avg_wd) : '—', 'من وصول المعاملة لوحدتي')}
        ${kpi('ضمن المدة المسموحة', r.actions ? `<span class="num">${100 - (r.breach_pct || 0)}%</span>` : '—')}
        ${kpi('بانتظار وحدتي الآن', `<span class="num">${num(r.open_items || 0)}</span>`, r.unit_overdue ? `منها ${r.unit_overdue} متأخرة` : 'لا متأخر')}
      </div>
      ${(r.flags || []).length ? `<div class="notice warn">مؤشرات تظهر لإدارتك: ${r.flags.map(esc).join('، ')}</div>` : '<div class="notice">لا مؤشرات سلبية على أدائك ضمن الفترة.</div>'}
      <p class="small muted">يُحسب أداؤك آلياً من السجل الزمني للمعاملات ويطّلع عليه مديرك وإدارة المصرف والجهات الرقابية.</p>`;
  } catch (e) { host.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}

export const canSeePerf = role => ['bank_md', 'bank_risk', 'bank_initiatives_mgr', 'bank_committee', 'bank_branch_mgr'].includes(role);
