// ألواح — أدوات مشتركة لكل البوابات
export const PORTALS = {
  citizen:   { title: 'بوابة المواطن', short: 'المواطن', sub: 'تمويلك كله من هاتفك: قدّم وقارن ووقّع وتابع — دون مراجعات ولا أوراق', points: ['هويتك تُقرأ من بطاقتك الوطنية مباشرة', 'قارن المصارف وعمولاتها قبل أن تختار', 'وقّع إلكترونياً برمز يصل هاتفك', 'تابع طلبك لحظة بلحظة وكل جهة تمسكه'] },
  bank:      { title: 'بوابة المصرف', short: 'المصرف', sub: 'دورة الطلب كاملة داخل المصرف: الفرع ← قسم المبادرات ← الإدارة العليا (قرار الإقراض) ← تعزيز السلفة من ائتمان المصرف لدى البنك المركزي ← التنفيذ والصرف', points: ['صندوق مستقل لكل وحدة وفرع', 'السلفة التجميعية بكتاب موقّع للبنك المركزي', 'سجل زمني لكل مرحلة ومن أنجزها', 'تحليل أداء الفروع والموظفين'] },
  registry:  { title: 'بوابة التسجيل العقاري', short: 'التسجيل العقاري', sub: 'إحالات الرهن الواردة من المصارف', points: ['استعلام الخلو من الإشارات', 'مطابقة السند وهوية المالك', 'تأشير الرهن برقم موثق', 'فك الرهن بعد براءة الذمة'] },
  cbi:       { title: 'لوحة البنك المركزي العراقي', short: 'البنك المركزي', sub: 'جهة قطاعية رقابية: تراقب وتدقق أداء المصارف واستخدام ائتماناتها — لا توافق ولا ترفض الإقراض، وتتدخل عند الحاجة فقط', points: ['قرار السلف التجميعية', 'حصص المصارف ومهل التنفيذ', 'مقارنة أداء المصارف والفروع', 'خريطة المنظومات المركّبة'] },
  supplier:  { title: 'بوابة المورد', short: 'المورد', sub: 'الكتالوج والطلبات والتركيب وتوثيق التشغيل', points: ['عروضك لكل فئة قدرة', 'الطلبات التي اختارك فيها المواطن', 'محضر التركيب بالأرقام التسلسلية', 'توثيق التشغيل بالكاميرا'] },
  integrity: { title: 'لوحة هيئة النزاهة', short: 'هيئة النزاهة', sub: 'قراءة كاملة وتنبيهات آلية — دون أي تعديل أو إيقاف', points: ['تنبيهات الأسعار والعمولات', 'كشف التكرار والتواطؤ', 'سجل تدقيق متسلسل لا يُمحى', 'تصدير ملف أي طلب'] },
  syndicate: { title: 'بوابة نقابة الأطباء البيطريين', short: 'النقابة', sub: 'تأييد عضوية الطبيب البيطري وسريان إجازة ممارسته لهذه السنة — النقابة لا تقرر الإقراض', points: ['طلبات تأييد العضوية', 'مطابقة هوية النقابة وإجازة الممارسة', 'كتاب تأييد إلكتروني برقم', 'سجل الأعضاء المستفيدين من المبادرة'] },
  vetdept:   { title: 'بوابة دائرة البيطرة', short: 'دائرة البيطرة', sub: 'الموافقة المبدئية على المشروع البيطري وموقعه قبل التقديم للمصرف، ثم إجازة النشاط بعد التشغيل', points: ['دراسات المشاريع الواردة', 'الموافقة أو الإعادة أو الرفض مسبباً', 'إجازة النشاط بعد الكشف الفني', 'متابعة التوريد والتركيب والتشغيل'] },
};

export const ROLE_LABELS = {
  citizen: 'مواطن', bank_cs: 'خدمة العملاء', bank_compliance: 'الامتثال ومكافحة غسل الأموال', bank_credit: 'ائتمان المبادرات',
  bank_committee: 'اللجنة الائتمانية العليا', bank_legal: 'الشؤون القانونية', bank_ops: 'العمليات المصرفية', bank_collection: 'التحصيل والمتابعة',
  bank_risk: 'المخاطر والتدقيق الداخلي', bank_branch_mgr: 'مدير الفرع', bank_initiatives: 'إداري قسم المبادرات الائتمانية',
  bank_initiatives_mgr: 'مدير قسم المبادرات ومعاونه', bank_md: 'الإدارة العليا للمصرف', bank_inspection: 'لجنة الكشف الموقعي',
  bank_admin: 'قسم الإدارة', bank_teller: 'أمين الصندوق', registry_officer: 'موظف التسجيل العقاري', cbi_admin: 'البنك المركزي',
  supplier_admin: 'مدير حساب المورد', integrity_viewer: 'مدقق النزاهة', syndicate_officer: 'لجنة التسجيل — النقابة', vetdept_officer: 'قسم الإجازات — دائرة البيطرة'
};

// ───────── الجلسة 6: مبادرة تمويل مشاريع الأطباء البيطريين ─────────
export const VET_TYPES = { lab: 'مختبر بيطري', clinic: 'عيادة بيطرية', hospital: 'مستشفى بيطري', pharma: 'معمل أدوية ولقاحات بيطرية', supplies: 'معمل مستلزمات بيطرية' };
export const VET_STEPS = ['التحقق من الهوية', 'العضوية وتأييد النقابة', 'المشروع والمصرف', 'الضمان', 'الدفع والإرسال'];
export const MEMBER_STATUS = { draft: ['لم تُرسل بعد', 'muted'], pending: ['بانتظار تأييد النقابة', 'warn'], endorsed: ['مؤيدة من النقابة', 'ok'], returned: ['أعادتها النقابة للاستكمال', 'warn'], rejected: ['لم تؤيدها النقابة', 'bad'] };
export const VETDEPT_STATUS = { draft: ['لم تُرسل بعد', 'muted'], pending: ['بانتظار موافقة دائرة البيطرة', 'warn'], approved: ['موافقة مبدئية من دائرة البيطرة', 'ok'], returned: ['أعادتها دائرة البيطرة للاستكمال', 'warn'], rejected: ['رفضتها دائرة البيطرة', 'bad'] };
export const TRANCHE_STATUS = { pending: ['غير مستحقة بعد', 'muted'], ready: ['مستحقة — بانتظار الصرف', 'warn'], paid: ['مصروفة', 'ok'] };
export const MILESTONES = [['delivered', 'توريد الأجهزة وخط الإنتاج'], ['installed', 'التركيب'], ['operating', 'التشغيل التجريبي']];
export const isVet = a => a?.program === 'vet';

export const PAY_METHODS = [['zaincash', 'زين كاش', '#D6246E'], ['qicard', 'كي كارد', '#E39B00'], ['asiapay', 'آسيا باي', '#C8102E'], ['fastpay', 'فاست باي', '#25307A'],
  ['fib', 'FIB', '#00877F'], ['visa', 'Visa', '#1A1F71'], ['mastercard', 'Mastercard', '#C4161C'], ['other', 'محفظة أو بطاقة أخرى', '#5B6B82']];
export const PAY_LABEL = Object.fromEntries(PAY_METHODS.map(([k, t]) => [k, t]));
export const GUARANTEE = { single_salary: 'راتب موظف واحد', multi_salary: 'رواتب عدة موظفين', mortgage: 'رهن عقار' };
export const STATUS = {
  active: ['قيد المعالجة', 'info'], returned: ['مُعاد للاستكمال', 'warn'], rejected: ['مرفوض', 'bad'],
  completed: ['مكتمل', 'ok'], court_hold: ['موقوف بأمر قضائي', 'bad'], cancelled: ['ملغى', 'muted']
};
export const REF_STATUS = {
  pending: ['بانتظار استعلام الخلو', 'warn'], clear: ['خالٍ — بانتظار المطابقة', 'info'], encumbered: ['عليه إشارة', 'bad'],
  matched: ['مطابق — بانتظار التأشير', 'info'], annotated: ['رهن مؤشَّر', 'ok'], released: ['مفكوك', 'muted'], rejected: ['مرفوض', 'bad']
};
export const PROP_STATUS = { free: ['خالٍ', 'ok'], mortgaged: ['مرهون', 'warn'], seized: ['محجوز', 'bad'], frozen: ['موقوف', 'bad'] };

// نص زر الإنجاز لمراحل المصرف يأتي من جدول المراحل (action_label)؛ ولمراحل المواطن الخمس:
export const ADVANCE_LABEL = { 1: 'إكمال التحقق من الهوية', 2: 'تأكيد رقم «أور»', 3: 'تثبيت العرض المختار', 4: 'تأكيد الضمان', 5: 'تأكيد اختيار المصرف' };
export const BATCH_STATUS = { draft: ['مسودة — بانتظار توقيع الإدارة العليا', 'warn'], signed: ['موقّع — بانتظار الإرسال', 'info'], sent: ['مرسل — بانتظار كفاية ائتمان المصرف', 'warn'], approved: ['معزَّزة من ائتمان المصرف', 'ok'], rejected: ['مرفوضة (قبل تصحيح دور المركزي)', 'muted'] };
export const wdTxt = d => d == null ? '—' : Number(d) < 1 ? `<span class="num">${Math.max(1, Math.round(Number(d) * 8))}</span> ساعة دوام` : `<span class="num">${Number(d).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> يوم`;

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const num = n => n == null ? '—' : Number(n).toLocaleString('en-US');
export const iqd = n => n == null ? '—' : `<span class="num">${num(Math.round(n))}</span> د.ع`;
export const mln = n => `<span class="num">${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`;
export const pct = n => `<span class="num">${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 1 })}%</span>`;
export const dt = s => s ? new Date(s).toLocaleString('ar-IQ-u-nu-latn', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
export const ago = s => {
  const m = Math.round((Date.now() - new Date(s)) / 60000);
  if (m < 1) return 'الآن'; if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.round(m / 60); if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.round(h / 24)} يوم`;
};
export const badge = ([t, k]) => `<span class="badge ${k}"><i class="dot"></i>${esc(t)}</span>`;
export const statusBadge = s => badge(STATUS[s] || [s, 'muted']);

export function el(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }

let toastTimer;
export function toast(msg, kind = '') {
  let t = document.querySelector('.toast');
  if (!t) { t = el('<div class="toast"></div>'); document.body.appendChild(t); }
  t.className = 'toast ' + kind; t.textContent = msg;
  requestAnimationFrame(() => t.classList.add('on'));
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 3800);
}

// شريط المراحل
export function stageBar(app, total = 37) {
  let out = '';
  for (let i = 1; i <= total; i++) {
    let c = '';
    if (app.status === 'completed' || i < app.stage) c = 'done';
    else if (i === app.stage) c = app.status === 'rejected' ? 'bad' : 'cur';
    out += `<span class="s ${c}" title="${i}"></span>`;
  }
  return `<div class="stages" style="grid-template-columns:repeat(${total},1fr)">${out}</div>`;
}

export function stageList(app, stages) {
  let phase = '';
  // المشروع البيطري: خطوات المقترض الخمس بأسمائها في هذا البرنامج
  if (app?.program === 'vet') stages = stages.map(x => x.n <= 5 ? { ...x, name: VET_STEPS[x.n - 1], proc_ref: null } : x);
  return `<ol class="stage-list">${stages.map(s => {
    const done = app.status === 'completed' || s.n < app.stage;
    const cur = s.n === app.stage && app.status !== 'completed';
    const head = s.phase && s.phase !== phase ? `<li class="ph">${esc(phase = s.phase)}</li>` : '';
    return `${head}<li class="${done ? 'done' : cur ? (app.status === 'returned' ? 'cur ret' : 'cur') : ''}"><span class="n">${done ? '✓' : s.n}</span><span>${esc(s.name)}${s.proc_ref ? `<small class="ref">${esc(s.proc_ref)}</small>` : ''}</span><span class="who">${esc(s.owner_label)}</span></li>`;
  }).join('')}</ol>`;
}

// السجل الزمني للمعاملة: كم استغرقت كل مرحلة مقابل المدة المسموحة ومن أنجزها
export function timelineCard(rows, app, settings = {}) {
  if (!rows?.length) return '';
  const bank = rows.filter(r => r.stage >= 6);
  const sum = bank.reduce((t, r) => t + Number(r.wd || 0), 0);
  const late = bank.filter(r => r.sla > 0 && Number(r.wd) > Number(r.sla));
  const max = Math.max(1, ...bank.map(r => Math.max(Number(r.wd || 0), Number(r.sla || 0))));
  const day = 864e5, now = Date.now();
  const dl = [];
  if (app.initial_approved_at && app.stage <= 22 && !['rejected', 'cancelled', 'completed'].includes(app.status)) {
    const left = (settings.initial_validity_days || 90) - (now - new Date(app.initial_approved_at)) / day;
    dl.push(`<span class="badge ${left < 15 ? 'bad' : left < 30 ? 'warn' : 'info'}">مهلة إكمال الضمانات وإعلام المركزي: ${left > 0 ? `<b class="num">${Math.ceil(left)}</b> يوماً متبقية` : 'انتهت — الموافقة لاغية'}</span>`);
  }
  if (app.cbi_approved_at && app.stage < 35 && app.status === 'active') {
    const used = (now - new Date(app.cbi_approved_at)) / day, win = settings.execution_window_days || 30;
    dl.push(`<span class="badge ${used > 90 ? 'bad' : used > win ? 'warn' : 'info'}">${used > 90 ? `تجاوز 3 أشهر من التعزيز — غرامة ${settings.late_penalty_pct || 5}%` : used > win ? `تجاوز مهلة التنفيذ (${win} يوماً)` : `مهلة التنفيذ: <b class="num">${Math.ceil(win - used)}</b> يوماً متبقية`}</span>`);
  }
  return `<div class="card mb"><h3>السجل الزمني للمعاملة <span class="sp"></span><span class="badge muted">أيام دوام</span></h3>
    <div class="row mb" style="flex-wrap:wrap;gap:8px"><span class="badge info">لدى المصرف حتى الآن: ${wdTxt(sum)}</span>
      <span class="badge ${late.length ? 'bad' : 'ok'}">${late.length ? `<b class="num">${late.length}</b> مرحلة تجاوزت المدة` : 'كل المراحل ضمن المدة'}</span>${dl.join('')}</div>
    <div class="tl">${bank.map(r => {
      const over = r.sla > 0 && Number(r.wd) > Number(r.sla);
      return `<div class="tl-r ${r.open ? 'open' : ''} ${over ? 'over' : ''}"><div class="tl-n"><b class="num">${r.stage}</b> ${esc(r.name)}<small>${esc(r.by || r.unit)}${r.returns ? ` · أعيد ${r.returns}` : ''}${r.outcome === 'rejected' ? ' · رفض' : ''}</small></div>
        <div class="tl-b"><i style="width:${(Number(r.wd) / max * 100).toFixed(1)}%"></i>${r.sla > 0 ? `<u style="inset-inline-start:${(r.sla / max * 100).toFixed(1)}%" title="المدة المسموحة"></u>` : ''}</div>
        <div class="tl-v">${wdTxt(r.wd)}${r.open ? ' <span class="badge warn">جارية</span>' : ''}<small>المسموح ${r.sla > 0 ? wdTxt(r.sla) : '—'}</small></div></div>`;
    }).join('')}</div></div>`;
}

// سجل الأحداث: منصب منفّذ كل إجراء ظاهر لكل من يرى المعاملة، ورمزه الوظيفي وختمه للمخوّلين فقط (sigs)
export function eventsList(events, sigs = []) {
  if (!events.length) return '<p class="muted small">لا أحداث بعد.</p>';
  const S = Object.fromEntries((sigs || []).map(x => [x.event_id, x]));
  return `<ul class="events">${events.slice().reverse().map(e => { const g = S[e.id]; return `
    <li><div><b>${esc(e.action)}</b> — <span class="muted">${esc(e.actor_name || '')}</span></div>
    ${e.actor_title ? `<div class="small muted">${esc(e.actor_title)}</div>` : ''}
    ${e.note ? `<div>${esc(e.note)}</div>` : ''}
    ${g ? `<div class="sig">${g.actor_code ? `الرمز الوظيفي <code>${esc(g.actor_code)}</code>` : ''} الختم الإلكتروني <code>${esc(g.seal)}</code></div>` : ''}
    <div class="t">${dt(e.created_at)} · المرحلة ${e.stage} · <span class="h" title="${esc(e.hash)}">#${esc((e.hash || '').slice(0, 12))}</span></div></li>`; }).join('')}</ul>`;
}

// عرض مستند بحجمه الكامل
export async function viewDoc(sb, id) {
  const { data } = await sb.from('app_documents').select('*').eq('id', id).maybeSingle();
  if (!data) return toast('تعذر فتح المستند', 'bad');
  modal(`<div class="docview"><h3>${esc({ deed: 'سند العقار', poa: 'وكالة مالك العقار بالرهن', owner_id_front: 'البطاقة الوطنية لمالك العقار', owner_id_back: 'ظهر بطاقة المالك', evidence: 'دليل قرار التسجيل العقاري', quote: 'عرض سعر المورد', site: 'صورة موقع المشروع', other: 'مستند' }[data.kind] || 'مستند')}</h3>
    ${String(data.mime).includes('pdf') ? `<a class="btn" href="${data.data}" download="document.pdf">فتح ملف PDF</a>` : `<img src="${data.data}" alt="">`}
    <p class="small muted mt">${data.source === 'camera' ? 'التُقط بالكاميرا مباشرة' : data.source === 'demo' ? 'نموذج عرض' : 'ملف مرفوع'} · ${esc(data.uploaded_by_title || '')} · ${dt(data.created_at)}${data.sha256 ? `<br>البصمة <code dir="ltr">${esc(data.sha256.slice(0, 24))}…</code>` : ''}</p></div>`, { wide: true });
}

// درج تفاصيل الطلب — مشترك لكل البوابات
export async function openApp(ctx, app, { actions = [], extra = '' } = {}) {
  const { sb, stages } = ctx;
  closeDrawer();
  const bg = el('<div class="drawer-bg"></div>');
  const dr = el(`<aside class="drawer" role="dialog" aria-label="تفاصيل الطلب">
    <div class="dh"><div><div class="small" style="color:#8FA3C0">طلب تمويل</div><h2 class="num">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
    <div class="db"><div class="spin"></div></div>
    <div class="df" ${actions.length ? '' : 'hidden'}></div></aside>`);
  document.body.append(bg, dr);
  requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
  bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;

  const [events, tl, sigs, docs, pays] = await Promise.all([
    sb.from('application_events').select('*').eq('application_id', app.id).order('id').then(r => r.data || []),
    sb.rpc('app_timeline', { p_app: app.id }).then(r => r.data || []),
    sb.from('event_signatures').select('event_id,actor_code,seal').eq('application_id', app.id).then(r => r.data || []),
    sb.from('app_documents').select('id,kind,source,mime,uploaded_by_title,created_at').eq('application_id', app.id).order('created_at').then(r => r.data || []),
    sb.from('payments').select('*').eq('application_id', app.id).then(r => r.data || []),
  ]);
  const DOCK = { deed: 'سند العقار', poa: 'وكالة المالك بالرهن', owner_id_front: 'بطاقة مالك العقار', owner_id_back: 'ظهر بطاقة المالك', evidence: 'دليل التسجيل العقاري', quote: 'عرض سعر المورد', site: 'صورة الموقع', other: 'مستند' };
  const vet = isVet(app) ? await vetData(sb, app) : null;
  const own = app.ownership;
  if (!ctx.settings) ctx.settings = Object.fromEntries(((await sb.from('settings').select('key,value')).data || []).map(x => [x.key, Number(x.value)]));
  if (!ctx.branches) ctx.branches = (await sb.from('branches').select('*')).data || [];
  const branch = ctx.branches.find(b => b.id === app.branch_id);
  const cur = stages.find(s => s.n === app.stage);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  dr.querySelector('.db').innerHTML = `
    <div class="card mb">
      <div class="row"><b>${esc(app.citizen_name)}</b><span class="sp"></span><span class="muted small">${esc(app.governorate)}</span></div>
      ${stageBar(app, stages.length)}
      <div class="small muted">المرحلة الحالية: <b style="color:var(--text)">${app.stage}. ${esc(cur?.name)}</b> — لدى ${esc(cur?.owner_label)}</div>
    </div>
    ${extra}
    ${vet ? vetCards(ctx, app, vet) : ''}
    ${timelineCard(tl, app, ctx.settings)}
    <div class="card mb"><h3>بيانات الطلب</h3>
      <dl class="kv">
        ${vet ? `<dt>البرنامج</dt><dd>مبادرة تمويل مشاريع الأطباء البيطريين</dd><dt>المشروع</dt><dd>${esc(VET_TYPES[vet.p?.project_type] || '—')}</dd>` : `<dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd>`}
        <dt>المورد</dt><dd>${esc(org(app.supplier_id))}</dd>
        ${ctx.hide?.includes('amount') ? '' : `<dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)} × <span class="num">${app.term_months - (vet ? app.grace_months || 0 : 0)}</span> شهراً${vet && app.grace_months ? ` بعد سماح <span class="num">${app.grace_months}</span> شهراً` : ''}</dd>`}
        ${ctx.hide?.includes('guarantee') ? '' : `<dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type] || '—')}</dd>`}
        <dt>المصرف</dt><dd>${esc(org(app.bank_id))}${branch ? ` — ${esc(branch.name)}` : ''}</dd>
        ${app.cbi_fee && !ctx.hide?.includes('amount') ? `<dt>عمولة البنك المركزي</dt><dd>${iqd(app.cbi_fee)} <span class="muted small">لمرة واحدة ولا تُسترجع</span></dd>` : ''}
        ${app.fees_paid_at ? `<dt>إيداع العمولات وأجور الكشف</dt><dd>${dt(app.fees_paid_at)}</dd>` : ''}
        ${vet ? '' : `<dt>رقم «أور»</dt><dd><span class="num">${esc(app.ur_number || '—')}</span> ${app.ur_verified ? badge(['متحقق منه', 'ok']) : badge(['بانتظار التحقق', 'warn'])}</dd>`}
        ${app.inspection_result ? `<dt>التدقيق الهندسي</dt><dd>${badge([app.inspection_result, 'ok'])}</dd>` : ''}
        <dt>تاريخ التقديم</dt><dd>${dt(app.created_at)}</dd>
      </dl>
    </div>
    ${own || docs.length ? `<div class="card mb"><h3>${own ? 'المستندات وملكية العقار' : 'المستندات'}</h3>
      ${own ? `<p style="margin-top:0">${own.is_owner ? 'المقترض هو مالك العقار' : `المالك شخص آخر: <b>${esc(own.owner_name)}</b> (${esc(own.relation || '')}) — وافق على الرهن برمز التحقق`}
        · سند <b>${esc(own.deed_no)}</b> · ${own.match === 'matched' ? badge(['مطابق للسجل العقاري', 'ok']) : badge(['بانتظار مطابقة التسجيل العقاري', 'warn'])}</p>` : ''}
      <div class="row" style="gap:8px;flex-wrap:wrap">${docs.map(d => `<button type="button" class="btn ghost sm" data-doc="${d.id}">${esc(DOCK[d.kind] || d.kind)} ${d.source === 'camera' ? '📷' : d.mime?.includes('pdf') ? 'PDF' : ''}</button>`).join('')}</div>
      <p class="small muted" style="margin:8px 0 0">صلاحية الطباعة تُحدد لكل قسم (قيد الاعتماد) — العرض متاح لمن يرى المعاملة.</p></div>` : ''}
    ${pays.length && !ctx.hide?.includes('amount') ? `<div class="card mb"><h3>المدفوعات قبل الإرسال</h3>${pays.map(p => `<div class="row small"><span>${(p.items || []).map(i => `${esc(i.label)}: ${iqd(i.amount)}`).join(' · ')}</span><span class="sp"></span><b>${iqd(p.amount)}</b> <span class="muted">${esc((PAY_LABEL[p.method] || p.method))} · <span class="num">${esc(p.ref)}</span></span></div>`).join('')}</div>` : ''}
    <div class="grid g2">
      <div class="card"><h3>المراحل</h3>${stageList(app, stages)}</div>
      <div class="card"><h3>سجل التدقيق <span class="sp"></span><span class="badge muted">متسلسل بالبصمة وموقّع</span></h3>${eventsList(events, sigs)}</div>
    </div>`;
  dr.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.doc));
  if (vet) wireVet(ctx, app, vet, dr);

  if (actions.length) {
    const f = dr.querySelector('.df');
    f.innerHTML = `<div class="field" style="margin-bottom:10px"><textarea class="input" rows="2" placeholder="ملاحظة أو سبب (يُحفظ في سجل التدقيق)"></textarea></div><div class="row"></div>`;
    const row = f.querySelector('.row');
    actions.forEach(a => {
      const b = el(`<button class="btn ${a.kind || ''}">${esc(a.label)}</button>`);
      b.onclick = async () => {
        const note = f.querySelector('textarea').value.trim() || null;
        if (a.needNote && !note) return toast('اكتب السبب أولاً', 'bad');
        row.querySelectorAll('button').forEach(x => x.disabled = true);
        try { await a.run(note); toast(a.done || 'تم تنفيذ الإجراء', 'ok'); closeDrawer(); ctx.refresh(); }
        catch (e) { toast(cleanErr(e), 'bad'); row.querySelectorAll('button').forEach(x => x.disabled = false); }
      };
      row.appendChild(b);
    });
  }
}

export function closeDrawer() {
  document.querySelectorAll('.drawer,.drawer-bg').forEach(n => { n.classList.remove('on'); setTimeout(() => n.remove(), 250); });
}

export const cleanErr = e => (e?.message || String(e)).replace(/^.*?ERROR:\s*/, '');

// إجراءات المسار العامة
export async function rpc(sb, fn, args) {
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw error;
  return data;
}

export function stageActions(ctx, app) {
  const { sb } = ctx;
  const st = ctx.stages.find(x => x.n === app.stage);
  const acts = [];
  if (!st?.batch_only) acts.push({ label: st?.action_label || 'إنجاز المرحلة', kind: 'ok', done: 'تم إنجاز المرحلة ونُقل الطلب للمرحلة التالية', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'advance', p_note: note }) });
  acts.push({ label: 'إعادة للاستكمال', kind: 'warn', needNote: true, done: 'أُعيد الطلب للاستكمال', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'return', p_note: note }) });
  acts.push({ label: 'رفض مسبب', kind: 'bad', needNote: true, done: 'رُفض الطلب', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'reject', p_note: note }) });
  return acts;
}

export function appsTable(apps, ctx, { onOpen, cols = ['code', 'name', 'kw', 'amount', 'stage', 'status', 'updated'] } = {}) {
  if (!apps.length) return `<div class="empty">لا توجد طلبات هنا الآن.</div>`;
  const st = n => ctx.stages.find(s => s.n === n);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  const C = {
    code: ['رقم الطلب', a => `<b class="num">${esc(a.code)}</b>`],
    name: ['المتقدم', a => esc(a.citizen_name)],
    gov: ['المحافظة', a => esc(a.governorate)],
    kw: ['القدرة / المشروع', a => isVet(a) ? `<span class="badge info">بيطري</span> ${esc(VET_TYPES[a.vet_type] || 'مشروع بيطري')}` : `<span class="num">${num(a.kw)}</span> kW`],
    amount: ['التمويل', a => iqd(a.amount)],
    guarantee: ['الضمان', a => esc(GUARANTEE[a.guarantee_type] || '—')],
    bank: ['المصرف', a => esc(org(a.bank_id))],
    branch: ['الفرع', a => esc(ctx.branches?.find(b => b.id === a.branch_id)?.name || '—')],
    supplier: ['المورد', a => esc(org(a.supplier_id))],
    stage: ['المرحلة', a => `<span class="num">${a.stage}</span>. ${esc(st(a.stage)?.name)}`],
    status: ['الحالة', a => statusBadge(a.status)],
    updated: ['آخر تحديث', a => `<span class="muted small">${ago(a.updated_at)}</span>`],
  };
  const id = 't' + Math.random().toString(36).slice(2);
  setTimeout(() => {
    document.querySelectorAll(`#${id} tbody tr`).forEach((tr, i) => tr.onclick = () => onOpen && onOpen(apps[i]));
  });
  return `<div class="tbl-wrap"><table class="tbl" id="${id}"><thead><tr>${cols.map(c => `<th>${C[c][0]}</th>`).join('')}</tr></thead>
    <tbody>${apps.map(a => `<tr class="${onOpen ? 'click' : ''}">${cols.map(c => `<td>${C[c][1](a)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

export function kpi(label, value, sub = '', accent = false) {
  return `<div class="card kpi ${accent ? 'accent' : ''}"><span class="l">${label}</span><span class="v">${value}</span>${sub ? `<span class="s">${sub}</span>` : ''}</div>`;
}

export function tabs(root, defs, onChange) {
  const bar = el('<div class="tabs" role="tablist"></div>');
  defs.forEach((d, i) => {
    const b = el(`<button class="tab ${i === 0 ? 'on' : ''}" role="tab">${esc(d.label)}${d.count ? `<span class="count">${d.count}</span>` : ''}</button>`);
    b.onclick = () => { bar.querySelectorAll('.tab').forEach(x => x.classList.remove('on')); b.classList.add('on'); onChange(d.key); };
    bar.appendChild(b);
  });
  root.appendChild(bar);
}

// ───────── الجلسة 2: أدوات مشتركة إضافية ─────────

// المحافظات الثماني عشرة وإحداثيات تقريبية لمركز كل منها (لخريطة البنك المركزي)
export const GOVS = [
  ['بغداد', 33.31, 44.36], ['البصرة', 30.51, 47.78], ['نينوى', 36.34, 43.13], ['أربيل', 36.19, 44.01], ['النجف', 32.0, 44.33],
  ['كربلاء', 32.6, 44.02], ['بابل', 32.47, 44.42], ['ذي قار', 31.05, 46.26], ['الأنبار', 33.42, 43.3], ['ديالى', 33.75, 44.6],
  ['واسط', 32.5, 45.82], ['ميسان', 31.84, 47.14], ['الديوانية', 31.99, 44.92], ['صلاح الدين', 34.6, 43.68], ['كركوك', 35.47, 44.39],
  ['المثنى', 31.31, 45.28], ['السليمانية', 35.56, 45.43], ['دهوك', 36.87, 42.99]
];
export const govOptions = (sel = '') => `<option value="">اختر المحافظة</option>` + GOVS.map(([g]) => `<option ${g === sel ? 'selected' : ''}>${g}</option>`).join('');

// القسط الشهري بطريقة التقسيط المتناقص
export function installment(amount, ratePct, months) {
  const r = ratePct / 1200;
  if (!r) return Math.round(amount / months);
  return Math.round(amount * r / (1 - Math.pow(1 + r, -months)));
}

export const maskPhone = p => p ? String(p).replace(/^(\d{4})\d{4}(\d{3})$/, '$1••••$2') : '—';
export const maskId = s => s ? '••••••••' + String(s).slice(-4) : '—';

// نجوم التقييم (تقبل كسوراً)
export const stars = (v, size = 15) => `<span class="stars" style="--v:${Number(v || 0).toFixed(2)};font-size:${size}px" aria-label="${Number(v || 0).toFixed(1)} من 5"><span>★★★★★</span></span>`;

// نافذة منبثقة عامة
export function modal(html, { wide = false, onClose } = {}) {
  const bg = el(`<div class="mdl-bg"><div class="mdl ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><button class="mdl-x" aria-label="إغلاق">×</button><div class="mdl-b"></div></div></div>`);
  bg.querySelector('.mdl-b').innerHTML = html;
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  const close = () => { bg.classList.remove('on'); setTimeout(() => bg.remove(), 200); onClose && onClose(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc_);
  bg.querySelector('.mdl-x').onclick = close;
  bg.addEventListener('click', e => { if (e.target === bg) close(); });
  return { el: bg.querySelector('.mdl-b'), close };
}

// نافذة رمز التحقق OTP — في وضع المطور الرمز 1234
// verify(code) تُستدعى للتحقق (من الخادم غالباً) وترمي خطأ إن فشل. تعيد Promise بالرمز أو null عند الإلغاء.
export function askOtp({ title = 'رمز التحقق', phone = '', purpose = '', verify } = {}) {
  return new Promise(resolve => {
    const dev = window.ALWAH_DEV || {};
    let done = false;
    const m = modal(`<div class="otp">
      <div class="otp-ic">✉</div>
      <h3>${esc(title)}</h3>
      <p class="muted">أرسلنا رمزاً من 4 أرقام برسالة نصية إلى <b class="num">${esc(maskPhone(phone))}</b>${purpose ? `<br><span class="small">${esc(purpose)}</span>` : ''}</p>
      ${dev.dev_mode ? `<button type="button" class="devchip" data-fill>وضع المطور — الرمز <b class="num">${esc(dev.dev_otp || '1234')}</b> · اضغط للتعبئة</button>` : ''}
      <div class="otp-in" dir="ltr">${[0, 1, 2, 3].map(i => `<input inputmode="numeric" maxlength="1" aria-label="الرقم ${i + 1}" autocomplete="${i === 0 ? 'one-time-code' : 'off'}">`).join('')}</div>
      <div class="err-line" hidden></div>
      <button class="btn cyan block" data-ok>تأكيد</button>
      <p class="small muted" style="margin-top:12px">لم يصلك الرمز؟ <button type="button" class="linkbtn" data-re disabled>إعادة الإرسال <span data-t>30</span></button></p>
    </div>`, { onClose: () => { if (!done) resolve(null); } });
    const ins = [...m.el.querySelectorAll('.otp-in input')], err = m.el.querySelector('.err-line'), ok = m.el.querySelector('[data-ok]');
    const code = () => ins.map(i => i.value).join('');
    ins.forEach((inp, i) => {
      inp.addEventListener('input', () => {
        inp.value = inp.value.replace(/\D/g, '').slice(-1);
        if (inp.value && i < 3) ins[i + 1].focus();
        if (code().length === 4) submit();
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Backspace' && !inp.value && i > 0) ins[i - 1].focus(); if (e.key === 'Enter') submit(); });
      inp.addEventListener('paste', e => {
        const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 4);
        if (d.length) { e.preventDefault(); d.split('').forEach((c, k) => ins[k] && (ins[k].value = c)); if (d.length === 4) submit(); }
      });
    });
    setTimeout(() => ins[0].focus(), 60);
    const fill = m.el.querySelector('[data-fill]');
    if (fill) fill.onclick = () => { (dev.dev_otp || '1234').split('').forEach((c, k) => ins[k].value = c); submit(); };
    let t = 30; const tEl = m.el.querySelector('[data-t]'), re = m.el.querySelector('[data-re]');
    const iv = setInterval(() => { t--; tEl.textContent = t; if (t <= 0) { clearInterval(iv); re.disabled = false; tEl.textContent = ''; } }, 1000);
    re.onclick = () => { toast('أُعيد إرسال الرمز', 'ok'); re.disabled = true; t = 30; tEl.textContent = t; };
    let busy = false;
    async function submit() {
      if (busy) return;
      const c = code();
      if (c.length !== 4) { err.hidden = false; err.textContent = 'اكتب الأرقام الأربعة'; return; }
      busy = true; ok.disabled = true; ok.textContent = 'جارِ التحقق…'; err.hidden = true;
      try {
        if (verify) await verify(c);
        done = true; clearInterval(iv); m.close(); resolve(c);
      } catch (e) {
        err.hidden = false; err.textContent = cleanErr(e);
        ins.forEach(i => i.value = ''); ins[0].focus();
        ok.disabled = false; ok.textContent = 'تأكيد'; busy = false;
      }
    }
    ok.onclick = submit;
  });
}

// تحقق موحّد من الرمز عبر الخادم (يرفض أي رمز غير صحيح)
export const serverOtp = (sb, phone, purpose) => async code => { await rpc(sb, 'verify_otp', { p_phone: phone, p_code: code, p_purpose: purpose }); };

export function normPhone(p) {
  let d = String(p || '').replace(/[^\d٠-٩]/g, '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  if (d.startsWith('00964')) d = '0' + d.slice(5); else if (d.startsWith('964')) d = '0' + d.slice(3); else if (/^7\d{9}$/.test(d)) d = '0' + d;
  return d;
}
export const validPhone = p => /^07[3-9]\d{8}$/.test(normPhone(p));
export const digits = s => String(s || '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/\D/g, '');

// ───────── الجلسة 6: المشروع البيطري داخل درج الطلب (لكل الجهات) ─────────
// إضافة نوع المشروع لصفوف الطلبات البيطرية (لعمود «القدرة / المشروع»)
export async function enrichVet(sb, apps) {
  const ids = apps.filter(isVet).map(a => a.id);
  if (!ids.length) return apps;
  const { data } = await sb.from('vet_projects').select('application_id,project_type,title,vetdept_status,milestones,license_no').in('application_id', ids);
  const P = Object.fromEntries((data || []).map(p => [p.application_id, p]));
  apps.forEach(a => { if (P[a.id]) { a.vet_type = P[a.id].project_type; a.vet = P[a.id]; } });
  return apps;
}

async function vetData(sb, app) {
  const [p, tr, m] = await Promise.all([
    sb.from('vet_projects').select('*').eq('application_id', app.id).maybeSingle().then(r => r.data),
    sb.from('vet_tranches').select('*').eq('application_id', app.id).order('n').then(r => r.data || []),
    sb.from('vet_memberships').select('id,membership_no,syndicate_branch,license_no,license_year,status,letter_no,valid_until,note,decided_at').eq('profile_id', app.citizen_id).maybeSingle().then(r => r.data),
  ]);
  return { p, tr, m };
}

function vetCards(ctx, app, { p, tr, m }) {
  if (!p) return '';
  const role = ctx.profile?.role, org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  const hideMoney = ctx.hide?.includes('amount');
  const ms = p.milestones || {};
  const own = { owned: 'ملك', rented: 'إيجار' }[p.site_ownership] || '—';
  const items = (p.items || []).map(i => `<tr><td>${esc(i.name)}</td><td class="num">${num(i.qty)}</td>${hideMoney ? '' : `<td>${iqd(i.price)}</td><td>${iqd(i.qty * i.price)}</td>`}</tr>`).join('');
  const nextMs = MILESTONES.find(([k]) => !ms[k]);
  const canMs = role === 'supplier_admin' && app.supplier_id === ctx.profile.org_id && app.stage === 31 && app.status === 'active' && nextMs;
  const canPay = role === 'bank_teller' && app.bank_id === ctx.profile.org_id && app.stage >= 31 && app.stage <= 35 && app.status === 'active';
  return `<div class="card mb vet-card"><h3>المشروع البيطري <span class="sp"></span><span class="badge info">${esc(VET_TYPES[p.project_type] || '')}</span></h3>
      <dl class="kv"><dt>اسم المشروع</dt><dd>${esc(p.title || '—')}</dd>
        <dt>الموقع</dt><dd>${esc([p.site_governorate, p.site_city, p.site_address].filter(Boolean).join(' — '))} · ${own}${p.site_area ? ` · <span class="num">${num(p.site_area)}</span> م²` : ''}</dd>
        ${p.products ? `<dt>المنتجات</dt><dd>${esc(p.products)}</dd>` : ''}${p.capacity ? `<dt>الطاقة الإنتاجية</dt><dd>${esc(p.capacity)}</dd>` : ''}
        ${p.staff_count ? `<dt>عدد العاملين</dt><dd class="num">${num(p.staff_count)}</dd>` : ''}
        <dt>المورد وعرض السعر</dt><dd>${esc(org(app.supplier_id))}${p.quote_no ? ` · عرض <span class="num">${esc(p.quote_no)}</span>` : ''}</dd>
        ${hideMoney ? '' : `<dt>كلفة الأجهزة</dt><dd>${iqd(p.equipment_cost)}</dd><dt>أعمال وتكاليف أخرى</dt><dd>${iqd(p.other_cost)}</dd><dt>الكلفة الكلية</dt><dd><b>${iqd(p.total_cost)}</b></dd>
        <dt>مساهمة الطبيب</dt><dd>${iqd(p.contribution)} <span class="muted small">(${p.total_cost ? Math.round(p.contribution / p.total_cost * 100) : 0}%)</span></dd><dt>القرض</dt><dd><b>${iqd(app.amount)}</b></dd>
        ${p.revenue_monthly ? `<dt>الإيراد الشهري المتوقع</dt><dd>${iqd(p.revenue_monthly)}</dd>` : ''}`}</dl>
      ${items ? `<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الجهاز / البند</th><th>العدد</th>${hideMoney ? '' : '<th>السعر</th><th>المجموع</th>'}</tr></thead><tbody>${items}</tbody></table></div>` : ''}
    </div>
    <div class="card mb"><h3>الموافقات الرسمية</h3>
      <dl class="kv"><dt>نقابة الأطباء البيطريين</dt><dd>${m ? `${badge(MEMBER_STATUS[m.status] || [m.status, 'muted'])} عضوية <span class="num">${esc(m.membership_no || '—')}</span> · إجازة <span class="num">${esc(m.license_no || '—')}</span> لسنة <span class="num">${esc(m.license_year || '—')}</span>${m.letter_no ? ` · كتاب <span class="num">${esc(m.letter_no)}</span>` : ''}${m.note ? `<div class="small muted">${esc(m.note)}</div>` : ''}` : badge(['لا عضوية مسجلة', 'bad'])}</dd>
        <dt>دائرة البيطرة — الموافقة المبدئية</dt><dd>${badge(VETDEPT_STATUS[p.vetdept_status] || [p.vetdept_status, 'muted'])}${p.vetdept_ref ? ` <span class="num">${esc(p.vetdept_ref)}</span>` : ''}${p.vetdept_note ? `<div class="small muted">${esc(p.vetdept_note)}</div>` : ''}</dd>
        <dt>إجازة ممارسة النشاط</dt><dd>${p.license_no ? `${badge(['ممنوحة', 'ok'])} <span class="num">${esc(p.license_no)}</span> · ${dt(p.license_at)}` : '<span class="muted">تُمنح بعد التشغيل والكشف الفني</span>'}</dd></dl>
    </div>
    ${tr.length ? `<div class="card mb"><h3>التوريد والصرف للمورد على دفعات</h3>
      <ol class="vet-ms">${MILESTONES.map(([k, l]) => `<li class="${ms[k] ? 'done' : ''}"><i>${ms[k] ? '✓' : ''}</i><span>${l}</span><small>${ms[k] ? dt(ms[k].at) : 'بانتظار توثيق المورد'}</small></li>`).join('')}
        <li class="${p.license_no ? 'done' : ''}"><i>${p.license_no ? '✓' : ''}</i><span>إجازة دائرة البيطرة</span><small>${p.license_no ? dt(p.license_at) : 'بعد التشغيل'}</small></li></ol>
      ${hideMoney ? '' : `<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الدفعة</th><th>النسبة</th><th>المبلغ</th><th>الحالة</th><th></th></tr></thead><tbody>
        ${tr.map(t => `<tr><td><span class="num">${t.n}</span>. ${esc(t.label)}</td><td class="num">${num(t.pct)}%</td><td>${iqd(t.amount)}</td><td>${badge(TRANCHE_STATUS[t.status])}${t.ref ? ` <span class="num small muted">${esc(t.ref)}</span>` : ''}</td>
          <td>${canPay && t.status === 'ready' ? `<button type="button" class="btn ok sm" data-pay="${t.n}">صرف الدفعة</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`}
      ${canMs ? `<div class="row mt"><span class="small muted">الخطوة التالية: <b>${esc(nextMs[1])}</b></span><span class="sp"></span><button type="button" class="btn cyan sm" data-ms="${nextMs[0]}">توثيق: ${esc(nextMs[1])}</button></div>` : ''}
    </div>` : ''}`;
}

function wireVet(ctx, app, v, dr) {
  const { sb } = ctx;
  const ask = (title, body, run, okText = 'تأكيد') => {
    const m = modal(`<h3>${esc(title)}</h3><p class="muted">${body}</p><div class="field"><label>ملاحظة (اختياري — تُحفظ في سجل التدقيق)</label><textarea class="input" rows="2" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn cyan" data-y>${esc(okText)}</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-y]').onclick = async e => {
      e.target.disabled = true;
      try { await run(m.el.querySelector('[data-n]').value.trim() || null); m.close(); closeDrawer(); ctx.refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  dr.querySelectorAll('[data-ms]').forEach(b => b.onclick = () => {
    const k = b.dataset.ms, l = MILESTONES.find(x => x[0] === k)[1];
    ask(`توثيق: ${l}`, k === 'operating' ? 'بعد التشغيل التجريبي تكشف دائرة البيطرة وتمنح الإجازة، ثم تُصرف الدفعة الأخيرة.' : 'يفتح هذا التوثيق استحقاق الدفعة المرتبطة به لدى أمين الصندوق.',
      async n => { await rpc(sb, 'vet_milestone', { p_app: app.id, p_key: k, p_note: n }); toast(`وُثّق: ${l}`, 'ok'); }, 'توثيق');
  });
  dr.querySelectorAll('[data-pay]').forEach(b => b.onclick = () => {
    const t = v.tr.find(x => x.n === Number(b.dataset.pay));
    ask(`صرف الدفعة ${t.n} للمورد`, `${esc(t.label)} — ${iqd(t.amount)} إلى ${esc(ctx.orgs.find(o => o.id === app.supplier_id)?.name || 'المورد')}.`,
      async n => { await rpc(sb, 'vet_tranche_pay', { p_app: app.id, p_n: t.n, p_note: n }); toast('صُرفت الدفعة وسُجّل القيد', 'ok'); }, 'صرف');
  });
}
