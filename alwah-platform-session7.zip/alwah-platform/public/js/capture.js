// التقاط المستندات: كاميرا حية فقط للمواطن (لا معرض ولا ملفات)، وكاميرا أو ملف لموظفي الجهات عند إرفاق الأدلة
import { esc, toast } from './core.js';

const MAX = 1600;

function toJpegDataUrl(source, sw, sh, sx = 0, sy = 0) {
  const s = Math.min(1, MAX / Math.max(sw, sh));
  const c = document.createElement('canvas');
  c.width = Math.round(sw * s); c.height = Math.round(sh * s);
  c.getContext('2d').drawImage(source, sx, sy, sw, sh, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.82);
}

// كاميرا بإطار المستند (السند بالطول A4 تقريباً، والبطاقة بالعرض)
// تعيد { data, meta } أو null عند الإلغاء
export function cameraCapture({ title = 'صوّر المستند', hint = '', ratio = 0.72, allowFile = false } = {}) {
  return new Promise(resolve => {
    const bg = document.createElement('div');
    bg.className = 'cam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <div class="cam-frame"><i></i><i></i><i></i><i></i></div>
      <p class="cam-hint">${esc(title)}<small>${esc(hint || 'ضع المستند كاملاً داخل الإطار في إضاءة جيدة ودون انعكاس')}</small></p>
      <div class="cam-bar">
        <button type="button" class="cam-x" aria-label="إغلاق">✕</button>
        <button type="button" class="cam-shoot" aria-label="التقاط"></button>
        ${allowFile ? '<label class="cam-gal">ملف<input type="file" accept="image/*,application/pdf" hidden></label>' : '<span class="cam-gal" style="visibility:hidden">—</span>'}
      </div>`;
    document.body.appendChild(bg);
    const video = bg.querySelector('video'), frame = bg.querySelector('.cam-frame');
    let stream = null;
    const done = v => { stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); resolve(v); };
    bg.querySelector('.cam-x').onclick = () => done(null);
    const fileIn = bg.querySelector('.cam-gal input');
    if (fileIn) fileIn.onchange = e => {
      const f = e.target.files[0]; if (!f) return;
      if (f.size > 3e6) return toast('حجم الملف أكبر من 3 ميغابايت', 'bad');
      const r = new FileReader();
      r.onload = () => {
        if (f.type === 'application/pdf') return done({ data: r.result, meta: { live: false, name: f.name, type: f.type } });
        const img = new Image(); img.onload = () => done({ data: toJpegDataUrl(img, img.naturalWidth, img.naturalHeight), meta: { live: false, name: f.name } }); img.src = r.result;
      };
      r.readAsDataURL(f);
    };
    bg.querySelector('.cam-shoot').onclick = () => {
      const VW = video.videoWidth, VH = video.videoHeight; if (!VW) return;
      const vr = video.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      const k = Math.max(vr.width / VW, vr.height / VH);
      const x0 = vr.left + (vr.width - VW * k) / 2, y0 = vr.top + (vr.height - VH * k) / 2;
      let sx = (fr.left - x0) / k, sy = (fr.top - y0) / k, sw = fr.width / k, sh = fr.height / k;
      sx = Math.max(0, sx); sy = Math.max(0, sy); sw = Math.min(VW - sx, sw); sh = Math.min(VH - sy, sh);
      const track = stream && stream.getVideoTracks()[0];
      done({ data: toJpegDataUrl(video, sw, sh, sx, sy), meta: { live: true, captured_at: new Date().toISOString(), w: VW, h: VH,
        device: (track && track.label) || '', facing: (track && track.getSettings && track.getSettings().facingMode) || '', ua: navigator.userAgent.slice(0, 160) } });
    };
    const fit = () => {
      const h = Math.min(innerHeight * 0.62, (innerWidth * 0.9) / ratio);
      frame.style.height = h + 'px'; frame.style.width = h * ratio + 'px';
    };
    fit(); addEventListener('resize', fit, { once: true });
    (navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      ? navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false })
      : Promise.reject())
      .then(st => { stream = st; video.srcObject = st; })
      .catch(() => {
        bg.querySelector('.cam-hint').innerHTML = allowFile ? 'تعذر فتح الكاميرا — اختر «ملف»' : 'تعذر فتح الكاميرا. التصوير المباشر شرط لقبول المستند: افتح المنصة من هاتفك واسمح للموقع باستخدام الكاميرا.';
        bg.querySelector('.cam-shoot').disabled = true;
      });
  });
}

// معاينة مصغرة لمستند ملتقط
export const docThumb = (d, label) => `<figure class="doc-th"><div class="doc-img">${d?.data
  ? (String(d.data).startsWith('data:application/pdf') ? '<span class="pdf">PDF</span>' : `<img src="${d.data}" alt="">`)
  : '<span class="muted small">لم يُصوَّر بعد</span>'}</div><figcaption>${esc(label)}${d?.meta?.live || d?.source === 'camera' ? ' <span class="badge ok">كاميرا مباشرة</span>' : ''}</figcaption></figure>`;
