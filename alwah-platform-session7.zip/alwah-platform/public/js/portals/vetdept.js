// بوابة دائرة البيطرة (وزارة الزراعة) — الموافقة المبدئية على المشروع البيطري وموقعه قبل التقديم للمصرف،
// ثم إجازة ممارسة النشاط بعد التوريد والتركيب والتشغيل التجريبي
import { esc, num, ago, badge, kpi, tabs, rpc, appsTable, openApp, VET_TYPES, VETDEPT_STATUS, enrichVet } from '../core.js';

export async function render(ctx) {
  const { sb, root, org } = ctx;
  const apps = (await sb.from('applications').select('*').eq('program', 'vet').order('updated_at', { ascending: false })).data || [];
  await enrichVet(sb, apps);
  const live = a => ['active', 'returned'].includes(a.status);
  const pending = apps.filter(a => live(a) && a.stage <= 5 && a.vet?.vetdept_status === 'pending');
  const toLicense = apps.filter(a => a.status === 'active' && a.stage >= 31 && a.vet?.milestones?.operating && !a.vet?.license_no);
  const approved = apps.filter(a => a.vet?.vetdept_status === 'approved');
  const licensed = apps.filter(a => a.vet?.license_no);
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'دائرة البيطرة')}</h1><p>مبادرة تمويل مشاريع الأطباء البيطريين: توافق الدائرة مبدئياً على المشروع وموقعه قبل أن يُرسل للمصرف، وتمنح إجازة ممارسة النشاط بعد الكشف الفني على التشغيل. قرار القرض للمصرف وحده.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('دراسات بانتظار الموافقة', `<span class="num">${pending.length}</span>`, 'في صندوقك', true)}
      ${kpi('بانتظار الإجازة', `<span class="num">${toLicense.length}</span>`, 'شُغّلت وتنتظر الكشف الفني')}
      ${kpi('موافقات مبدئية', `<span class="num">${approved.length}</span>`)}
      ${kpi('إجازات ممنوحة', `<span class="num">${licensed.length}</span>`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'inbox', label: 'الموافقة المبدئية', count: pending.length }, { key: 'license', label: 'إجازة النشاط', count: toLicense.length }, { key: 'all', label: 'كل المشاريع البيطرية' }];
  ctx.vdTab = ctx.vdTab || 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.vdTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.vdTab));
  ctx.hide = ['guarantee', 'amount'];

  const open = a => {
    const acts = [];
    if (pending.includes(a)) acts.push(
      { label: 'الموافقة المبدئية على المشروع وموقعه', kind: 'ok', done: 'سُجّلت الموافقة وأُبلغ الطبيب', run: n => rpc(sb, 'vetdept_action', { p_app: a.id, p_action: 'approve', p_note: n }) },
      { label: 'إعادة للاستكمال', kind: 'warn', needNote: true, done: 'أُعيدت الدراسة للطبيب', run: n => rpc(sb, 'vetdept_action', { p_app: a.id, p_action: 'return', p_note: n }) },
      { label: 'رفض مسبب', kind: 'bad', needNote: true, done: 'رُفض المشروع', run: n => rpc(sb, 'vetdept_action', { p_app: a.id, p_action: 'reject', p_note: n }) });
    if (toLicense.includes(a)) acts.push({ label: 'منح إجازة ممارسة النشاط بعد الكشف الفني', kind: 'ok', done: 'مُنحت الإجازة — استحقت الدفعة الأخيرة للمورد', run: n => rpc(sb, 'vetdept_action', { p_app: a.id, p_action: 'license', p_note: n }) });
    openApp(ctx, a, { actions: acts });
  };
  const rows = list => list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>الطبيب</th><th>المشروع</th><th>الموقع</th><th>موافقة الدائرة</th><th>الإجازة</th><th>آخر تحديث</th></tr></thead><tbody>
    ${list.map(a => `<tr class="click" data-a="${a.id}"><td><b class="num">${esc(a.code)}</b></td><td>${esc(a.citizen_name)}</td><td>${esc(a.vet?.title || '')}<div class="small muted">${esc(VET_TYPES[a.vet_type] || '')}</div></td><td>${esc(a.governorate)}</td>
      <td>${badge(VETDEPT_STATUS[a.vet?.vetdept_status || 'draft'])}</td><td>${a.vet?.license_no ? `<span class="num">${esc(a.vet.license_no)}</span>` : '—'}</td><td class="small muted">${ago(a.updated_at)}</td></tr>`).join('')}</tbody></table></div>`
    : '<div class="empty">لا مشاريع هنا الآن.</div>';
  function show(k) {
    const list = k === 'inbox' ? pending : k === 'license' ? toLicense : apps.filter(a => a.vet?.vetdept_status !== 'draft');
    body.innerHTML = `${k === 'inbox' ? '<div class="notice">راجع نوع المشروع وموقعه وملكيته وقائمة الأجهزة وعرض سعر المورد المصوَّر. الموافقة مبدئية على المشروع والموقع، وتُمنح الإجازة بعد التشغيل.</div>' : ''}
      ${k === 'license' ? '<div class="notice">وثّق المورد التوريد والتركيب والتشغيل التجريبي. بعد الكشف الفني امنح الإجازة — تُصرف بعدها الدفعة الأخيرة للمورد.</div>' : ''}
      <div class="card flush">${rows(list)}</div>`;
    body.querySelectorAll('[data-a]').forEach(tr => tr.onclick = () => open(apps.find(a => a.id === tr.dataset.a)));
  }
  show(ctx.vdTab);
}

export const shouldRefresh = () => !document.querySelector('.mdl-bg');
