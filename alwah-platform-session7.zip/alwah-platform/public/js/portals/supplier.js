// بوابة المورد — العروض والطلبات والتركيب وتوثيق التشغيل
import { esc, iqd, mln, num, kpi, appsTable, openApp, stageActions, tabs, enrichVet, isVet } from '../core.js';

export async function render(ctx) {
  const { sb, root, org } = ctx;
  const [apps, offers, tiers] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('supplier_offers').select('*').eq('supplier_id', org.id).then(r => r.data || []),
    sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
  ]);
  await enrichVet(sb, apps);
  const meta = org.meta || {};
  const vetSup = meta.kind === 'vet';
  const inbox = apps.filter(a => a.stage === 31 && a.status === 'active');
  const done = apps.filter(a => a.status === 'completed');

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}</h1><p>${meta.legacy ? '<span class="badge ok">معتمد — تعامل سابق</span> ' : '<span class="badge info">معتمد</span> '}مؤشراتك تحسبها المنصة ولا تُدخلها الشركة.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظار التركيب أو التوثيق', `<span class="num">${inbox.length}</span>`, 'طلبات في صندوقك', true)}
      ${kpi('تركيبات منجزة', `<span class="num">${num((meta.installs || 0) + done.length)}</span>`, 'منها على المنصة ' + done.length)}
      ${kpi('نسبة المطابقة في التدقيق', `<span class="num">${meta.match_rate || 0}%</span>`)}
      ${kpi('متوسط مدة التنفيذ', `<span class="num">${meta.avg_days || 0}</span> أيام`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'inbox', label: 'أوامر الشراء: التركيب والتوثيق', count: inbox.length }, { key: 'all', label: 'كل طلباتي' }, ...(vetSup ? [] : [{ key: 'offers', label: 'عروضي في الكتالوج' }])];
  ctx.supTab = defs.find(d => d.key === ctx.supTab) ? ctx.supTab : 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.supTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.supTab));
  ctx.hide = ['guarantee'];
  const open = a => openApp(ctx, a, { actions: a.stage === 31 && a.status === 'active' ? stageActions(ctx, a).slice(0, 2) : [] });

  function show(k) {
    if (k === 'inbox') body.innerHTML = vetSup ? `<div class="notice">⚕ مورد معتمد في مبادرة الطب البيطري: يصلك الطلب بعد أمر الشراء من المصرف. افتح الطلب ووثّق بالترتيب: <b>التوريد</b> ← <b>التركيب</b> ← <b>التشغيل التجريبي</b>. كل توثيق يفتح دفعتك لدى أمين الصندوق، والدفعة الأخيرة بعد إجازة دائرة البيطرة. ثم اعتمد المحضر.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'stage', 'updated'] })}</div>` : `<div class="notice">أدلة التركيب والتشغيل تُلتقط بكاميرا تطبيق الفني فقط، مع بصمة ووقت وموقع. تصلك المعاملة بعد صدور أمر الشراء من المصرف. بعد توثيقك تكشف لجنة المصرف على التركيب وتستلمه، ثم يُصرف مبلغك من أمين الصندوق.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'stage', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'bank', 'stage', 'status'] })}</div>`;
    if (k === 'offers' && vetSup) return;
    if (k === 'offers') body.innerHTML = `<div class="grid g3">${offers.map(o => {
      const t = tiers.find(x => x.id === o.tier_id);
      return `<div class="card offer"><div class="row"><b style="font-size:18px"><span class="num">${num(t?.kw)}</span> kW</b><span class="sp"></span><span class="badge ok">منشور · نسخة ${o.version}</span></div>
        <div class="price">${iqd(o.price)}</div><div class="small muted">سقف البرنامج لهذه القدرة: ${iqd(t?.price_cap)}</div>
        <ul class="small" style="margin:6px 0;padding-inline-start:18px">${(o.components || []).map(c => `<li>${esc(c.item)}: ${esc(c.brand)} ${esc(c.model)} × <span class="num">${c.qty}</span></li>`).join('')}</ul>
        <div class="small muted">${esc(o.warranty)}</div></div>`;
    }).join('')}</div>`;
  }
  show(ctx.supTab);
}
