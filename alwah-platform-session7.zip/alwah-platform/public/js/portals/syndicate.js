// بوابة نقابة الأطباء البيطريين — تأييد العضوية وسريان إجازة الممارسة لهذه السنة فقط (لا تقرر الإقراض)
import { esc, num, dt, ago, badge, kpi, tabs, rpc, toast, cleanErr, modal, MEMBER_STATUS } from '../core.js';

export async function render(ctx) {
  const { sb, root, org } = ctx;
  const members = (await sb.from('vet_memberships').select('*').order('submitted_at', { ascending: false, nullsFirst: false })).data || [];
  const y = new Date().getFullYear();
  const pending = members.filter(m => m.status === 'pending');
  const endorsed = members.filter(m => m.status === 'endorsed' && Number(m.license_year) === y);
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'نقابة الأطباء البيطريين')}</h1><p>مبادرة تمويل مشاريع أعضاء النقابة: تؤيد النقابة عضوية الطبيب وسريان إجازة ممارسته لسنة <span class="num">${y}</span> فقط. قرار القرض للمصرف وحده، والموافقة على المشروع لدائرة البيطرة.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظار التأييد', `<span class="num">${pending.length}</span>`, 'طلبات في صندوقك', true)}
      ${kpi('أعضاء مؤيَّدون لسنة ' + y, `<span class="num">${endorsed.length}</span>`, 'بكتاب تأييد إلكتروني')}
      ${kpi('أُعيدت للاستكمال', `<span class="num">${members.filter(m => m.status === 'returned').length}</span>`)}
      ${kpi('لم تؤيَّد', `<span class="num">${members.filter(m => m.status === 'rejected').length}</span>`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'inbox', label: 'طلبات التأييد', count: pending.length }, { key: 'all', label: 'كل الأعضاء' }];
  ctx.synTab = ctx.synTab || 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.synTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.synTab));

  const table = list => list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الطبيب</th><th>رقم العضوية</th><th>الفرع</th><th>إجازة الممارسة</th><th>التخرج</th><th>الحالة</th><th>الإرسال</th></tr></thead><tbody>
    ${list.map(m => `<tr class="click" data-m="${m.id}"><td><b>${esc(m.full_name)}</b><div class="small muted">${esc(m.college || '')}</div></td><td class="num">${esc(m.membership_no || '—')}</td><td>${esc(m.syndicate_branch || '—')}</td>
      <td><span class="num">${esc(m.license_no || '—')}</span> · <span class="num">${esc(m.license_year || '')}</span> ${Number(m.license_year) === y ? '' : badge(['غير مجددة', 'bad'])}</td><td class="num">${esc(m.graduation_year || '—')}</td>
      <td>${badge(MEMBER_STATUS[m.status] || [m.status, 'muted'])}${m.letter_no ? `<div class="small num muted">${esc(m.letter_no)}</div>` : ''}</td><td class="small muted">${m.submitted_at ? ago(m.submitted_at) : '—'}</td></tr>`).join('')}</tbody></table></div>`
    : '<div class="empty">لا طلبات هنا الآن.</div>';
  function show(k) {
    const list = k === 'inbox' ? pending : members.filter(m => m.status !== 'draft');
    body.innerHTML = `${k === 'inbox' ? '<div class="notice">طابق رقم العضوية والاسم مع سجل النقابة، وتأكد أن إجازة الممارسة مجددة لهذه السنة (تُجدَّد في كانون الثاني). المستندات صُوّرت بكاميرا هاتف الطبيب مباشرة.</div>' : ''}<div class="card flush">${table(list)}</div>`;
    body.querySelectorAll('[data-m]').forEach(tr => tr.onclick = () => openMember(members.find(m => m.id === tr.dataset.m)));
  }

  async function openMember(m) {
    const docs = (await sb.from('vet_member_docs').select('kind,data,meta,created_at').eq('membership_id', m.id)).data || [];
    const D = { union_id: 'هوية النقابة', license: 'إجازة ممارسة المهنة', degree: 'شهادة التخرج' };
    const can = m.status === 'pending';
    const md = modal(`<h3>${esc(m.full_name)} ${badge(MEMBER_STATUS[m.status])}</h3>
      <dl class="kv"><dt>رقم العضوية</dt><dd class="num">${esc(m.membership_no || '—')}</dd><dt>فرع النقابة</dt><dd>${esc(m.syndicate_branch || '—')}</dd>
        <dt>إجازة الممارسة</dt><dd><span class="num">${esc(m.license_no || '—')}</span> لسنة <span class="num">${esc(m.license_year || '')}</span> ${Number(m.license_year) === y ? badge(['مجددة', 'ok']) : badge(['غير مجددة لهذه السنة', 'bad'])}</dd>
        <dt>الكلية</dt><dd>${esc(m.college || '—')}</dd><dt>سنة التخرج</dt><dd class="num">${esc(m.graduation_year || '—')}</dd><dt>الاختصاص</dt><dd>${esc(m.specialty || '—')}</dd>
        <dt>الرقم الوطني</dt><dd class="num">${esc(m.national_id ? '••••••••' + String(m.national_id).slice(-4) : '—')}</dd>
        ${m.letter_no ? `<dt>كتاب التأييد</dt><dd><span class="num">${esc(m.letter_no)}</span> · ساري حتى <span class="num">${esc(m.valid_until)}</span></dd>` : ''}
        ${m.note ? `<dt>ملاحظة</dt><dd>${esc(m.note)}</dd>` : ''}${m.decided_at ? `<dt>القرار</dt><dd>${esc(m.decided_by_title || '')} · ${dt(m.decided_at)}</dd>` : ''}</dl>
      <div class="mdocs">${['union_id', 'license', 'degree'].map(k => { const d = docs.find(x => x.kind === k); return `<figure><div>${d ? `<img src="${d.data}" alt="${esc(D[k])}">` : '<span class="muted small">لم يُصوَّر</span>'}</div><figcaption>${esc(D[k])}${d?.meta?.demo ? ' <span class="badge muted">نموذج</span>' : d ? ' <span class="badge ok">كاميرا مباشرة</span>' : ''}</figcaption></figure>`; }).join('')}</div>
      ${can ? `<div class="field mt"><label>ملاحظة أو سبب (إلزامي للإعادة وعدم التأييد)</label><textarea class="input" rows="2" data-n></textarea></div>
      <div class="row"><button class="btn bad" data-a="reject">عدم التأييد</button><button class="btn warn" data-a="return">إعادة للاستكمال</button><span class="sp"></span><button class="btn ok" data-a="endorse">تأييد العضوية وإصدار الكتاب</button></div>` : ''}`, { wide: true });
    md.el.querySelectorAll('.mdocs img').forEach(i => i.onclick = () => modal(`<div class="docview"><img src="${i.src}" alt=""></div>`, { wide: true }));
    md.el.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
      const note = md.el.querySelector('[data-n]').value.trim() || null;
      if (b.dataset.a !== 'endorse' && !note) return toast('اكتب السبب أولاً', 'bad');
      md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = true);
      try { const r = await rpc(sb, 'syndicate_action', { p_member: m.id, p_action: b.dataset.a, p_note: note }); md.close();
        toast(b.dataset.a === 'endorse' ? `أُيدت العضوية — كتاب ${r.letter_no}` : 'سُجّل القرار وأُبلغ الطبيب', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = false); }
    });
  }
  show(ctx.synTab);
}

export const shouldRefresh = () => !document.querySelector('.mdl-bg');
