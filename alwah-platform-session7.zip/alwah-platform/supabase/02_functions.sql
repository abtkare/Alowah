-- ألواح — دوال محرك المراحل والتسجيل العقاري (security definer: الكتابة لا تتم إلا عبرها)

create or replace function public.advance_application(p_app uuid, p_action text, p_note text default null)
returns public.applications language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; st stages; ref mortgage_referrals; new_stage int; act text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  select * into a from applications where id = p_app for update;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  select * into st from stages where n = a.stage;

  if st.owner_role = 'citizen' then
    if a.citizen_id is distinct from me.id then raise exception 'هذه المرحلة لصاحب الطلب'; end if;
  else
    if me.role <> st.owner_role then raise exception 'هذه المرحلة من صلاحية: %', st.owner_label; end if;
    if me.portal = 'bank' and a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
    if me.portal = 'supplier' and a.supplier_id is distinct from me.org_id then raise exception 'الطلب لا يخص شركتك'; end if;
  end if;

  if p_action = 'reject' then
    update applications set status='rejected', updated_at=now() where id=a.id returning * into a; act := 'رفض مسبب';
  elsif p_action = 'return' then
    update applications set status='returned', updated_at=now() where id=a.id returning * into a; act := 'إعادة للاستكمال';
  elsif p_action = 'advance' then
    if a.stage = 8 and a.guarantee_type = 'mortgage' then
      select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
      if ref is null or ref.status not in ('clear','matched','annotated') then raise exception 'لا يُنتقل قبل تأكيد خلو العقار من التسجيل العقاري'; end if;
    end if;
    if a.stage = 9 then
      if exists (select 1 from bank_allocations b where b.bank_id=a.bank_id and (b.allocated - b.reserved - b.disbursed) < a.amount) then
        raise exception 'حصة المصرف لا تكفي — يلزم طلب تعزيز من البنك المركزي';
      end if;
      update bank_allocations set reserved = reserved + a.amount where bank_id = a.bank_id;
    end if;
    if a.stage = 10 and a.guarantee_type = 'mortgage' then
      select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
      if ref is null or ref.status <> 'annotated' then raise exception 'لا يوقَّع العقد قبل تأشير الرهن في التسجيل العقاري'; end if;
    end if;
    if a.stage = 12 then update applications set inspection_result='مطابق' where id=a.id; end if;
    if a.stage = 14 then
      update bank_allocations set reserved = reserved - a.amount, disbursed = disbursed + a.amount where bank_id = a.bank_id;
      update applications set status='completed', updated_at=now() where id=a.id returning * into a;
      act := 'صرف للمورد واكتمال الطلب';
    else
      new_stage := a.stage + 1;
      update applications set stage=new_stage, status='active', updated_at=now(), bank_unit=(select owner_label from stages where n=new_stage)
      where id=a.id returning * into a;
      act := 'إنجاز: ' || st.name;
    end if;
  else raise exception 'إجراء غير معروف';
  end if;

  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, st.n, act, p_note, me.id, me.full_name, me.role);
  return a;
end $$;

create or replace function public.refer_mortgage(p_app uuid, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; r mortgage_referrals;
begin
  select * into me from profiles where id=auth.uid();
  select * into a from applications where id=p_app;
  if me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_credit','bank_legal') then raise exception 'الإحالة من الائتمان أو القانونية'; end if;
  if a.property_id is null then raise exception 'لا يوجد عقار مرتبط بالطلب'; end if;
  insert into mortgage_referrals(application_id, property_id, bank_id, debt_amount, note) values (a.id, a.property_id, a.bank_id, a.amount, p_note) returning * into r;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, 'إحالة رهن إلى التسجيل العقاري', p_note, me.id, me.full_name, me.role);
  return r;
end $$;

create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare me profiles; r mortgage_referrals; p properties; act text; newst text;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك';
  elsif p_action='annotate' then
    if r.status <> 'matched' then raise exception 'التأشير بعد المطابقة'; end if;
    newst:='annotated'; act:='تأشير الرهن على السند';
    update properties set status='mortgaged' where id=p.id;
    update mortgage_referrals set annotation_no = 'ره-' || to_char(now(),'YYYY') || '-' || lpad((floor(random()*99999))::text,5,'0') where id=r.id;
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then newst:='rejected'; act:='رفض الإحالة';
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now() where id=r.id returning * into r;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (r.application_id, (select stage from applications where id=r.application_id), act, p_note, me.id, me.full_name, me.role);
  return r;
end $$;

grant execute on function public.advance_application, public.refer_mortgage, public.registry_action to authenticated;

-- البيانات التجريبية (المؤسسات، القدرات، العروض، المصارف، العقارات، 31 طلباً، التنبيهات، 25 مستخدماً)
-- مطبّقة عبر ترحيلات Supabase: seed_reference_data, seed_demo_users, seed_applications
-- الدالتان المساعدتان public._mk_user و public._mk_app موجودتان في القاعدة ومقفلتان على المستخدمين (للمطور فقط عبر SQL).
