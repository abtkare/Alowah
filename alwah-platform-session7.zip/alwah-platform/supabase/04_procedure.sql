-- ألواح — الجلسة 4: مطابقة دورة الطلب مع إجراء تمويل المبادرة وسياسة التمويل في المصرف
-- (مسميات وظيفية عامة فقط — لا أسماء أشخاص ولا مصارف حقيقية ولا رموز وثائق داخلية)
-- مطبَّق على المشروع alwah-platform بالترحيل session4_procedure

-- 1) الفروع
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(), bank_id uuid not null references public.orgs(id),
  code text unique not null, name text not null, governorates text[] not null default '{}',
  is_main boolean default false, complaint_phone text, created_at timestamptz default now()
);
alter table public.branches enable row level security;
drop policy if exists read_branches on public.branches;
create policy read_branches on public.branches for select to authenticated using (true);

alter table public.profiles add column if not exists branch_id uuid references public.branches(id);

-- 2) أعمدة الطلب الجديدة
alter table public.applications drop constraint if exists applications_stage_check;
alter table public.applications add constraint applications_stage_check check (stage between 1 and 37);
alter table public.applications
  add column if not exists branch_id uuid references public.branches(id),
  add column if not exists batch_id uuid,
  add column if not exists initial_approved_at timestamptz,   -- الموافقة المبدئية لمدير الفرع (تبدأ مهلة 90 يوماً)
  add column if not exists cbi_approved_at timestamptz,       -- موافقة المركزي على السلفة (تبدأ مهلة التنفيذ)
  add column if not exists fees_paid_at timestamptz,          -- إيداع العمولات وأجور الكشف
  add column if not exists cbi_fee bigint,                    -- عمولة المركزي لمرة واحدة
  add column if not exists grace_months int default 0;

-- 3) المراحل: صاحب كل مرحلة، مدتها المسموحة بأيام الدوام، ومرجعها في الإجراء
alter table public.stages
  add column if not exists sla_days numeric default 0, add column if not exists proc_ref text,
  add column if not exists action_label text, add column if not exists branch_level boolean default false,
  add column if not exists batch_only boolean default false, add column if not exists phase text;

delete from public.stages;
insert into public.stages (n, name, owner_role, owner_label, sla_days, proc_ref, action_label, branch_level, batch_only, phase) values
(1,'التحقق من الهوية وتصوير المستمسكات','citizen','المواطن',0,'السياسة: المستمسكات الثبوتية','إكمال التحقق من الهوية',false,false,'المواطن'),
(2,'رقم «أور»','citizen','المواطن',0,null,'تأكيد رقم «أور»',false,false,'المواطن'),
(3,'اختيار القدرة والعرض','citizen','المواطن',0,null,'تثبيت العرض المختار',false,false,'المواطن'),
(4,'الضمان والكفلاء','citizen','المواطن',0,'السياسة: الضمانات المقبولة','تأكيد الضمان',false,false,'المواطن'),
(5,'اختيار المصرف والتوقيع الإلكتروني','citizen','المواطن',0,'السياسة: التقديم بالاستمارة الإلكترونية','تأكيد اختيار المصرف',false,false,'المواطن'),
(6,'الاستقبال وتدقيق المستمسكات والاستعلام الائتماني','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوتان 1–2','تأكيد اكتمال المستمسكات والاستعلام الائتماني',true,false,'الفرع'),
(7,'فتح الحساب والامتثال','bank_compliance','الامتثال وفتح الحسابات',2,'الإجراء: الخطوة 2 · السياسة: الخدمة لأصحاب الحسابات','تأكيد وجود الحساب واجتياز الامتثال',false,false,'الفرع'),
(8,'الموافقة المبدئية','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 3','الموافقة المبدئية والتوجيه بإجراء الضمان',true,false,'الفرع'),
(9,'إجراءات الضمان الأولية','bank_cs','خدمة الزبائن — العمليات الائتمانية',5,'الإجراء: الخطوة 4','تأكيد إنجاز إجراءات الضمان الأولية',true,false,'الفرع'),
(10,'الإضبارة الإلكترونية والوعد بالشراء وإيداع العمولات','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوة 5','فتح الإضبارة وتثبيت الوعد بالشراء وإيداع العمولات',true,false,'الفرع'),
(11,'قرار اللجنة الائتمانية في الفرع','bank_branch_mgr','مدير الفرع',2,'الإجراء: الخطوة 6','توقيع قرار اللجنة الائتمانية وختمه',true,false,'الفرع'),
(12,'استلام الإضبارة وقائمة التدقيق','bank_initiatives','إداري قسم المبادرات الائتمانية',2,'الإجراء: الخطوتان 7–8','إعداد قائمة تدقيق محتويات الإضبارة',false,false,'قسم المبادرات'),
(13,'التحقق من خلو الإضبارة من النواقص','bank_credit','مسؤول شعبة ائتمان المبادرات',1,'الإجراء: الخطوة 9','تأكيد خلو الإضبارة من النواقص',false,false,'قسم المبادرات'),
(14,'الكشف الموقعي وتقرير الجدارة الائتمانية','bank_inspection','لجنة الكشف الموقعي',7,'الإجراء: الخطوات 10–12 · السياسة: ثالثاً','رفع تقرير الكشف الموقعي والجدارة',false,false,'قسم المبادرات'),
(15,'الدراسة الائتمانية والتوصية','bank_credit','مسؤول شعبة ائتمان المبادرات',3,'الإجراء: الخطوة 13','رفع الدراسة الائتمانية والتوصية',false,false,'قسم المبادرات'),
(16,'قرار قسم المبادرات الائتمانية','bank_initiatives_mgr','مدير قسم المبادرات ومعاونه',2,'الإجراء: الخطوة 14','كتابة القرار وتوقيع الدراسة',false,false,'قسم المبادرات'),
(17,'رأي القسم القانوني','bank_legal','القسم القانوني',2,'الإجراء: الخطوة 15','كتابة القرار القانوني والتوقيع',false,false,'الإدارة العامة'),
(18,'موافقة الإدارة العليا ضمن الصلاحيات','bank_md','الإدارة العليا للمصرف',2,'الإجراء: الخطوة 16','الموافقة والتوقيع والختم',false,false,'الإدارة العامة'),
(19,'استكمال الضمان النهائي','bank_initiatives','إداري قسم المبادرات الائتمانية',5,'الإجراء: الخطوة 17 · السياسة: مهلة 3 أشهر','تأكيد استحصال الضمان النهائي',false,false,'قسم المبادرات'),
(20,'التجميع في سلفة تجميعية','bank_initiatives','إداري قسم المبادرات الائتمانية',5,'الإجراء: الخطوتان 18–19','إضافة إلى سلفة تجميعية',false,true,'البنك المركزي'),
(21,'توقيع كتاب طلب السلفة','bank_md','الإدارة العليا للمصرف',2,'الإجراء: الخطوة 20','توقيع الكتاب',false,true,'البنك المركزي'),
(22,'إرسال الكتاب إلى البنك المركزي','bank_admin','قسم الإدارة',1,'الإجراء: الخطوتان 21–22','إرسال الكتاب',false,true,'البنك المركزي'),
(23,'قرار البنك المركزي على السلفة','cbi_admin','البنك المركزي',15,'الإجراء: الخطوة 23','الموافقة على السلفة',false,true,'البنك المركزي'),
(24,'إبلاغ الفرع وفتح التسهيل','bank_credit','مسؤول شعبة ائتمان المبادرات',1,'الإجراء: الخطوة 24 · السياسة: التنفيذ خلال شهر','إبلاغ الفرع بتوقيع العقد وفتح التسهيل',false,false,'التنفيذ'),
(25,'توقيع عقد التمويل والكمبيالة','bank_cs','خدمة الزبائن — العمليات الائتمانية',3,'الإجراء: الخطوة 25','تأكيد توقيع العقد والكمبيالة واستمارة القبول',true,false,'التنفيذ'),
(26,'تدقيق العقد والكمبيالة','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 26','تدقيق العقد والكمبيالة والتوقيع',true,false,'التنفيذ'),
(27,'طلب تنفيذ التمويل','bank_credit','مسؤول شعبة ائتمان المبادرات',2,'الإجراء: الخطوة 27','تعبئة استمارة طلب التنفيذ',false,false,'التنفيذ'),
(28,'التحقق من مطابقة الطلب للسياسة','bank_initiatives_mgr','مدير قسم المبادرات ومعاونه',1,'الإجراء: الخطوة 28','تأكيد المطابقة للسياسة وتعليمات المركزي',false,false,'التنفيذ'),
(29,'اعتماد طلب التنفيذ','bank_md','الإدارة العليا للمصرف',1,'الإجراء: الخطوة 29','اعتماد طلب التنفيذ',false,false,'التنفيذ'),
(30,'تسجيل الطلب وأمر الشراء من المورد','bank_ops','قسم العمليات المصرفية',2,'الإجراء: الخطوات 30–33','إصدار أمر الشراء للمورد',false,false,'التنفيذ'),
(31,'التركيب وتوثيق التشغيل','supplier_admin','المورد',14,'ألواح: توثيق بالصورة والفيديو والموقع','اعتماد محضر التركيب وتوثيق التشغيل',false,false,'التنفيذ'),
(32,'الكشف على التركيب واستلام البضاعة','bank_inspection','لجنة الكشف الموقعي',3,'الإجراء: الخطوة 34','تأكيد المطابقة واستلام البضاعة',false,false,'التنفيذ'),
(33,'تنفيذ التمويل وجدول الأقساط','bank_ops','قسم العمليات المصرفية',2,'الإجراء: الخطوتان 34–35','تنفيذ التمويل وإصدار جدول الأقساط',false,false,'التنفيذ'),
(34,'تسليم جدول الأقساط وتوثيق الاستلام','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوة 36','تأكيد تسليم الجدول وتوقيع المقترض',true,false,'التنفيذ'),
(35,'صرف المبلغ للمورد','bank_teller','أمين الصندوق',1,'الإجراء: الخطوة 37','صرف المبلغ وتوقيع القيد',true,false,'التنفيذ'),
(36,'تدقيق القيد من مدير الفرع','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 38','تدقيق القيد والموافقة',true,false,'التنفيذ'),
(37,'حفظ العقود في الخزنة وإغلاق الملف','bank_cs','خدمة الزبائن — العمليات الائتمانية',1,'الإجراء: الخطوة الأخيرة','حفظ العقود وإغلاق الملف',true,false,'التنفيذ');

-- 4) القواعد المالية حسب السياسة (قابلة للتعديل من لوحة المركزي)
update public.settings set value = 0, label = 'عائد سنوي إضافي للبنك المركزي % (لا يوجد — العمولة لمرة واحدة)', circular_no = 'سياسة التمويل' where key = 'cbi_rate';
update public.settings set value = 3.5, label = 'الحد الأعلى لعوائد المصرف السنوية % (متناقصة)', circular_no = 'سياسة التمويل' where key = 'margin_max';
update public.settings set value = 60, label = 'أقصى مدة سداد شاملة مدة السماح (شهر)', circular_no = 'سياسة التمويل' where key = 'term_max_months';
insert into public.settings(key, value, label, circular_no) values
 ('grace_max_months', 12, 'أقصى مدة سماح (شهر)', 'سياسة التمويل'),
 ('cbi_fee_small', 1.5, 'عمولة البنك المركزي لمرة واحدة % حتى 20 مليون — لا تُسترجع', 'سياسة التمويل'),
 ('cbi_fee_large', 2, 'عمولة البنك المركزي لمرة واحدة % فوق 20 مليون — لا تُسترجع', 'سياسة التمويل'),
 ('guarantor_permille', 0.006, 'أرباح الشركة الضامنة سنوياً (بالألف، متناقصة)', 'سياسة التمويل'),
 ('sme_cap', 20000000, 'سقف المشاريع الصغيرة والمتوسطة (دينار)', 'سياسة التمويل'),
 ('batch_cap', 200000000, 'سقف السلفة التجميعية الواحدة (دينار)', 'سياسة التمويل'),
 ('initial_validity_days', 90, 'مهلة إكمال الضمانات وإعلام المركزي من الموافقة المبدئية (يوم)', 'سياسة التمويل'),
 ('execution_window_days', 30, 'مهلة تنفيذ التمويل بعد تعزيز حساب المصرف (يوم)', 'سياسة التمويل'),
 ('late_penalty_pct', 5, 'غرامة عدم التنفيذ خلال 3 أشهر %', 'سياسة التمويل')
on conflict (key) do update set value = excluded.value, label = excluded.label, circular_no = excluded.circular_no;
update public.bank_terms set max_term_months = least(max_term_months, 60), margin = least(margin, 3.5);

-- 5) السلفة التجميعية
create table if not exists public.cbi_batches (
  id uuid primary key default gen_random_uuid(), code text unique not null, bank_id uuid not null references public.orgs(id),
  total bigint not null default 0, apps_count int not null default 0,
  status text not null default 'draft' check (status in ('draft','signed','sent','approved','rejected')),
  letter_ref text, created_by uuid, created_by_name text, signed_by_name text, signed_at timestamptz,
  sent_by_name text, sent_at timestamptz, decided_by_name text, decided_at timestamptz, decision_note text,
  created_at timestamptz default now()
);
alter table public.applications drop constraint if exists applications_batch_fk;
alter table public.applications add constraint applications_batch_fk foreign key (batch_id) references public.cbi_batches(id) on delete set null;
alter table public.cbi_batches enable row level security;
drop policy if exists read_batches on public.cbi_batches;
create policy read_batches on public.cbi_batches for select to authenticated using (bank_id = my_org() or my_portal() in ('cbi','integrity'));

-- 6) السجل الزمني لكل مرحلة (أساس تحليل الأداء)
create table if not exists public.stage_log (
  id bigint generated always as identity primary key,
  application_id uuid not null references public.applications(id) on delete cascade,
  stage int not null, bank_id uuid, branch_id uuid,
  entered_at timestamptz not null default now(), finished_at timestamptz,
  finished_by uuid, finished_by_name text, finished_by_role text,
  outcome text check (outcome in ('done','rejected','cancelled','sent_back')),
  returns int not null default 0, sla_days numeric
);
create index if not exists stage_log_app on public.stage_log(application_id);
create index if not exists stage_log_open on public.stage_log(stage) where finished_at is null;
alter table public.stage_log enable row level security;
drop policy if exists read_stage_log on public.stage_log;
create policy read_stage_log on public.stage_log for select to authenticated using (exists (select 1 from applications a where a.id = application_id));

-- أيام الدوام الفعلي بين وقتين (تُستثنى الجمعة والسبت، بتوقيت بغداد)
create or replace function public._wd(a timestamptz, b timestamptz) returns numeric
language sql stable set search_path = public as $$
  select case when b is null or a is null or b <= a then 0 else coalesce(round((sum(extract(epoch from (
      least(b, (g.d at time zone 'Asia/Baghdad') + interval '1 day') - greatest(a, g.d at time zone 'Asia/Baghdad')))) / 86400.0)::numeric, 2), 0) end
  from generate_series(date_trunc('day', a at time zone 'Asia/Baghdad'), date_trunc('day', b at time zone 'Asia/Baghdad'), interval '1 day') g(d)
  where extract(isodow from g.d) not in (5, 6)
$$;

-- يُسجَّل كل انتقال تلقائياً مهما كان مصدره (المواطن، المحرك، السلفة)
create or replace function public._track_stage() returns trigger
language plpgsql security definer set search_path = public as $$
declare me profiles; oc text; dur numeric; lim numeric;
begin
  if tg_op = 'INSERT' then
    insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days)
    values (new.id, new.stage, new.bank_id, new.branch_id, coalesce(new.created_at, now()), (select sla_days from stages where n = new.stage));
    return new;
  end if;
  select * into me from profiles where id = auth.uid();
  if new.status = 'returned' and old.status is distinct from 'returned' then
    update stage_log set returns = returns + 1 where application_id = new.id and stage = old.stage and finished_at is null;
  end if;
  if new.stage <> old.stage or (new.status <> old.status and new.status in ('completed','rejected','cancelled')) then
    oc := case when new.status = 'completed' then 'done' when new.status = 'rejected' then 'rejected' when new.status = 'cancelled' then 'cancelled'
               when new.stage > old.stage then 'done' else 'sent_back' end;
    update stage_log set finished_at = now(), finished_by = me.id, finished_by_name = me.full_name, finished_by_role = me.role, outcome = oc,
      bank_id = new.bank_id, branch_id = new.branch_id
    where application_id = new.id and stage = old.stage and finished_at is null
    returning _wd(entered_at, finished_at), sla_days into dur, lim;
    -- تأخير يتجاوز ضعف المدة المسموحة ← تنبيه آلي لهيئة النزاهة والمركزي
    if lim > 0 and dur > lim * 2 then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('sla', case when dur > lim * 3 then 'high' else 'medium' end,
        'تأخير في مرحلة «' || (select name from stages where n = old.stage) || '»',
        'استغرقت ' || dur || ' يوم دوام والمسموح ' || lim || '. المنفذ: ' || coalesce(me.full_name, '—'),
        new.id, (select name from orgs where id = new.bank_id));
    end if;
    if new.stage <> old.stage and new.status in ('active','returned') then
      insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days)
      values (new.id, new.stage, new.bank_id, new.branch_id, now(), (select sla_days from stages where n = new.stage));
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_track_stage on public.applications;
create trigger trg_track_stage after insert or update of stage, status on public.applications for each row execute function public._track_stage();

-- 7) صلاحية القراءة: موظفو الفرع يرون طلبات فرعهم فقط (سرية معلومات الزبائن)
drop policy if exists read_apps on public.applications;
create policy read_apps on public.applications for select to authenticated using (
  citizen_id = auth.uid()
  or (my_portal() = 'bank' and bank_id = my_org() and ((select branch_id from profiles where id = auth.uid()) is null or branch_id = (select branch_id from profiles where id = auth.uid())))
  or (my_portal() = 'supplier' and supplier_id = my_org() and stage >= 30)
  or (my_portal() = 'registry' and exists (select 1 from mortgage_referrals m where m.application_id = applications.id))
  or my_portal() in ('cbi','integrity'));

do $$ begin alter publication supabase_realtime add table public.cbi_batches, public.stage_log; exception when duplicate_object then null; end $$;

-- 8) سجل الحدث
create or replace function public._ev(p_app uuid, p_stage int, p_act text, p_note text) returns void
language sql security definer set search_path = public as $$
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  select p_app, p_stage, p_act, p_note, id, full_name, role from profiles where id = auth.uid()
$$;

-- 9) محرك المراحل — بشروط الإجراء والسياسة
create or replace function public.advance_application(p_app uuid, p_action text, p_note text default null)
returns public.applications language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; st stages; ref mortgage_referrals; act text; lim int;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  select * into a from applications where id = p_app for update;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  select * into st from stages where n = a.stage;

  if st.owner_role = 'citizen' then
    if a.citizen_id is distinct from me.id then raise exception 'هذه المرحلة لصاحب الطلب'; end if;
  else
    if me.role <> st.owner_role then raise exception 'هذه المرحلة من صلاحية: %', st.owner_label; end if;
    if me.portal = 'bank' and a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
    if me.portal = 'supplier' and a.supplier_id is distinct from me.org_id then raise exception 'الطلب لا يخص شركتك'; end if;
    if st.branch_level and me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  end if;
  if p_action in ('reject','return') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;

  if p_action = 'reject' then
    if a.cbi_approved_at is not null and a.stage < 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0) where bank_id = a.bank_id;
    end if;
    update applications set status='rejected', updated_at=now() where id=a.id returning * into a; act := 'رفض مسبب';
  elsif p_action = 'return' then
    update applications set status='returned', updated_at=now() where id=a.id returning * into a; act := 'إعادة للاستكمال';
  elsif p_action = 'advance' then
    if st.batch_only then raise exception 'هذه المرحلة تُنجز عبر السلفة التجميعية لا للطلب منفرداً'; end if;
    if a.stage = 9 and a.guarantee_type = 'mortgage' then
      select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
      if ref is null or ref.status not in ('clear','matched','annotated') then raise exception 'الإجراء الأولي للرهن: يلزم تأكيد خلو العقار ومطابقة السند من التسجيل العقاري'; end if;
    end if;
    if a.stage = 14 and a.fees_paid_at is null then raise exception 'أجور الكشف تُستوفى قبل إجراء الكشف (المرحلة 10)'; end if;
    if a.stage = 19 then
      lim := _setting('initial_validity_days')::int;
      if a.initial_approved_at is not null and now() - a.initial_approved_at > make_interval(days => lim) then
        raise exception 'مضت % يوماً على الموافقة المبدئية دون إكمال الضمانات — الموافقة لاغية حسب السياسة، ارفض الطلب مسبباً', lim; end if;
      if a.guarantee_type = 'mortgage' then
        select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
        if ref is null or ref.status <> 'annotated' then raise exception 'الإجراء النهائي للرهن: يلزم تأشير الرهن على السند'; end if;
      end if;
    end if;

    if a.stage = 8 then update applications set initial_approved_at = now() where id = a.id; end if;
    if a.stage = 10 then update applications set fees_paid_at = now() where id = a.id; end if;
    if a.stage = 32 then update applications set inspection_result = 'مطابق' where id = a.id; end if;
    if a.stage = 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0), disbursed = disbursed + a.amount where bank_id = a.bank_id;
    end if;

    if a.stage = 37 then
      update applications set status='completed', updated_at=now() where id=a.id returning * into a;
      act := 'حفظ العقود وإغلاق الملف — اكتمال الطلب';
    else
      update applications set stage = a.stage + 1, status='active', updated_at=now(), bank_unit=(select owner_label from stages where n = a.stage + 1)
      where id=a.id returning * into a;
      act := 'إنجاز: ' || st.name;
    end if;
  else raise exception 'إجراء غير معروف';
  end if;
  perform _ev(a.id, st.n, act, p_note);
  return a;
end $$;

-- 10) الرهن: الإجراء الأولي من الفرع، والنهائي (التأشير) بعد موافقة الإدارة العليا
create or replace function public.refer_mortgage(p_app uuid, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; r mortgage_referrals;
begin
  select * into me from profiles where id=auth.uid();
  select * into a from applications where id=p_app;
  if me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_cs','bank_initiatives','bank_legal') then raise exception 'الإحالة من خدمة الزبائن في الفرع أو قسم المبادرات'; end if;
  if a.property_id is null then raise exception 'لا يوجد عقار مرتبط بالطلب'; end if;
  if exists (select 1 from mortgage_referrals where application_id = a.id and status in ('pending','clear','matched','annotated')) then raise exception 'توجد إحالة قائمة لهذا الطلب'; end if;
  insert into mortgage_referrals(application_id, property_id, bank_id, debt_amount, note) values (a.id, a.property_id, a.bank_id, a.amount, p_note) returning * into r;
  perform _ev(a.id, a.stage, 'إحالة رهن إلى التسجيل العقاري', p_note);
  return r;
end $$;

create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare me profiles; r mortgage_referrals; p properties; act text; newst text; ast int;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  select stage into ast from applications where id = r.application_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك (الإجراء الأولي)';
  elsif p_action='annotate' then
    if r.status <> 'matched' then raise exception 'التأشير بعد المطابقة'; end if;
    if ast < 19 then raise exception 'التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)'; end if;
    newst:='annotated'; act:='تأشير الرهن على السند (الإجراء النهائي)';
    update properties set status='mortgaged' where id=p.id;
    update mortgage_referrals set annotation_no = 'ره-' || to_char(now(),'YYYY') || '-' || lpad((floor(random()*99999))::text,5,'0') where id=r.id;
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then newst:='rejected'; act:='رفض الإحالة';
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now() where id=r.id returning * into r;
  perform _ev(r.application_id, ast, act, p_note);
  return r;
end $$;

-- 11) السلفة التجميعية: إنشاء ← توقيع ← إرسال ← قرار المركزي
create or replace function public.batch_create(p_apps uuid[], p_note text default null) returns public.cbi_batches
language plpgsql security definer set search_path = public as $$
declare me profiles; b cbi_batches; tot bigint; cnt int; bad int; seq int;
begin
  select * into me from profiles where id = auth.uid();
  if me.role <> 'bank_initiatives' then raise exception 'التجميع من إداري قسم المبادرات'; end if;
  if coalesce(array_length(p_apps, 1), 0) = 0 then raise exception 'اختر طلباً واحداً على الأقل'; end if;
  select count(*) filter (where stage <> 20 or status <> 'active' or bank_id is distinct from me.org_id), count(*), coalesce(sum(amount), 0)
    into bad, cnt, tot from applications where id = any(p_apps);
  if cnt <> array_length(p_apps, 1) or bad > 0 then raise exception 'كل الطلبات يجب أن تكون في مرحلة التجميع ولمصرفك'; end if;
  if tot > _setting('batch_cap') then raise exception 'مجموع السلفة % يتجاوز السقف % دينار', to_char(tot, 'FM999,999,999,999'), to_char(_setting('batch_cap'), 'FM999,999,999,999'); end if;
  select count(*) + 1 into seq from cbi_batches where bank_id = me.org_id;
  insert into cbi_batches(code, bank_id, total, apps_count, created_by, created_by_name)
  values (coalesce((select split_part(code, '-', 1) from branches where bank_id = me.org_id order by is_main desc limit 1), 'BNK') || '-ST-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 3, '0'), me.org_id, tot, cnt, me.id, me.full_name)
  returning * into b;
  update applications set batch_id = b.id, stage = 21, updated_at = now(), bank_unit = (select owner_label from stages where n = 21) where id = any(p_apps);
  perform _ev(x, 20, 'إضافة إلى السلفة التجميعية ' || b.code, p_note) from unnest(p_apps) x;
  return b;
end $$;

create or replace function public.batch_action(p_batch uuid, p_action text, p_note text default null) returns public.cbi_batches
language plpgsql security definer set search_path = public as $$
declare me profiles; b cbi_batches; ids uuid[]; act text; avail bigint;
begin
  select * into me from profiles where id = auth.uid();
  select * into b from cbi_batches where id = p_batch for update;
  if b is null then raise exception 'السلفة غير موجودة'; end if;
  select array_agg(id) into ids from applications where batch_id = b.id and status = 'active';
  if p_action = 'dissolve' then
    if me.role <> 'bank_initiatives' or me.org_id <> b.bank_id or b.status <> 'draft' then raise exception 'فك السلفة لإداري المبادرات قبل التوقيع فقط'; end if;
    update applications set batch_id = null, stage = 20, updated_at = now() where batch_id = b.id;
    delete from cbi_batches where id = b.id; act := 'فك السلفة التجميعية ' || b.code;
    perform _ev(x, 21, act, p_note) from unnest(ids) x; return b;
  elsif p_action = 'sign' then
    if me.role <> 'bank_md' or me.org_id <> b.bank_id then raise exception 'التوقيع للإدارة العليا للمصرف'; end if;
    if b.status <> 'draft' then raise exception 'الكتاب موقّع مسبقاً'; end if;
    update cbi_batches set status = 'signed', signed_by_name = me.full_name, signed_at = now(),
      letter_ref = 'ك-' || to_char(now(), 'YYYY') || '-' || lpad((floor(random()*9999))::text, 4, '0') where id = b.id returning * into b;
    update applications set stage = 22, updated_at = now(), bank_unit = (select owner_label from stages where n = 22) where id = any(ids);
    act := 'توقيع كتاب طلب السلفة ' || b.code;
    perform _ev(x, 21, act, p_note) from unnest(ids) x;
  elsif p_action = 'send' then
    if me.role <> 'bank_admin' or me.org_id <> b.bank_id then raise exception 'الإرسال من قسم الإدارة'; end if;
    if b.status <> 'signed' then raise exception 'يُرسل الكتاب بعد توقيعه'; end if;
    update cbi_batches set status = 'sent', sent_by_name = me.full_name, sent_at = now() where id = b.id returning * into b;
    update applications set stage = 23, updated_at = now(), bank_unit = (select owner_label from stages where n = 23) where id = any(ids);
    act := 'إرسال كتاب السلفة إلى البنك المركزي ' || b.code;
    perform _ev(x, 22, act, p_note) from unnest(ids) x;
  elsif p_action in ('approve', 'reject') then
    if me.portal <> 'cbi' then raise exception 'القرار للبنك المركزي'; end if;
    if b.status <> 'sent' then raise exception 'لا يوجد كتاب مرسل بانتظار القرار'; end if;
    if p_action = 'reject' and coalesce(trim(p_note), '') = '' then raise exception 'اكتب أسباب الرفض ليُبلَّغ الفرع'; end if;
    if p_action = 'approve' then
      select allocated - reserved - disbursed into avail from bank_allocations where bank_id = b.bank_id;
      if coalesce(avail, 0) < b.total then raise exception 'حصة المصرف لا تكفي لهذه السلفة'; end if;
      update bank_allocations set reserved = reserved + b.total where bank_id = b.bank_id;
      update cbi_batches set status = 'approved', decided_by_name = me.full_name, decided_at = now(), decision_note = p_note where id = b.id returning * into b;
      update applications set stage = 24, cbi_approved_at = now(), updated_at = now(), bank_unit = (select owner_label from stages where n = 24) where id = any(ids);
      act := 'موافقة البنك المركزي على السلفة ' || b.code;
    else
      update cbi_batches set status = 'rejected', decided_by_name = me.full_name, decided_at = now(), decision_note = p_note where id = b.id returning * into b;
      update applications set stage = 19, status = 'returned', batch_id = null, updated_at = now(), bank_unit = (select owner_label from stages where n = 19) where id = any(ids);
      act := 'رفض البنك المركزي للسلفة ' || b.code || ' — إبلاغ الفرع لإكمال النواقص';
    end if;
    perform _ev(x, 23, act, p_note) from unnest(ids) x;
  else raise exception 'إجراء غير معروف'; end if;
  return b;
end $$;

-- 12) تحليل الأداء
-- نطاق الاطلاع: المركزي والنزاهة على الكل، إدارة المصرف على مصرفها، مدير الفرع على فرعه
create or replace function public._perf_scope(p_bank uuid, out o_bank uuid, out o_branch uuid, out o_all boolean)
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal in ('cbi','integrity') then o_bank := p_bank; o_all := p_bank is null;
  elsif me.portal = 'bank' and me.role in ('bank_md','bank_risk','bank_initiatives_mgr','bank_committee') then o_bank := me.org_id; o_all := false;
  elsif me.portal = 'bank' and me.role = 'bank_branch_mgr' then o_bank := me.org_id; o_branch := me.branch_id; o_all := false;
  else raise exception 'تحليل الأداء لإدارة المصرف والجهات الرقابية — راجع «أدائي»'; end if;
end $$;

create or replace function public.app_timeline(p_app uuid) returns jsonb
language sql stable security invoker set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
    'stage', l.stage, 'name', s.name, 'unit', s.owner_label, 'phase', s.phase, 'sla', s.sla_days,
    'entered_at', l.entered_at, 'finished_at', l.finished_at, 'outcome', l.outcome, 'returns', l.returns,
    'wd', _wd(l.entered_at, coalesce(l.finished_at, now())), 'open', l.finished_at is null,
    'by', case when my_portal() in ('citizen','supplier') then null else l.finished_by_name end
  ) order by l.entered_at, l.id), '[]'::jsonb)
  from stage_log l join stages s on s.n = l.stage where l.application_id = p_app
$$;

create or replace function public.perf_overview(p_bank uuid default null, p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare sc record; res jsonb;
begin
  select * into sc from _perf_scope(p_bank);
  with l as (
    select l.*, _wd(l.entered_at, coalesce(l.finished_at, now())) wd from stage_log l
    where l.stage >= 6 and l.entered_at >= now() - make_interval(days => p_days)
      and (sc.o_bank is null or l.bank_id = sc.o_bank) and (sc.o_branch is null or l.branch_id = sc.o_branch)),
  apps as (
    select a.* from applications a where a.bank_id is not null and a.stage >= 6
      and (sc.o_bank is null or a.bank_id = sc.o_bank) and (sc.o_branch is null or a.branch_id = sc.o_branch)),
  cyc as (
    select a.id, a.bank_id, a.branch_id, _wd(min(l.entered_at), max(l.finished_at)) wd from apps a join stage_log l on l.application_id = a.id and l.stage >= 6
    where a.status = 'completed' group by a.id, a.bank_id, a.branch_id)
  select jsonb_build_object(
    'scope', jsonb_build_object('bank', sc.o_bank, 'branch', sc.o_branch, 'all', sc.o_all, 'days', p_days),
    'totals', jsonb_build_object(
      'apps', (select count(*) from apps), 'completed', (select count(*) from apps where status = 'completed'),
      'active', (select count(*) from apps where status in ('active','returned')),
      'avg_cycle', (select round(avg(wd), 1) from cyc),
      'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 1) from l where finished_at is not null and sla_days > 0),
      'open_overdue', (select count(*) from l where finished_at is null and sla_days > 0 and wd > sla_days),
      'returns', (select coalesce(sum(returns), 0) from l)),
    'stages', (select coalesce(jsonb_agg(x order by x->>'n'), '[]') from (
      select jsonb_build_object('n', lpad(s.n::text, 2, '0'), 'stage', s.n, 'name', s.name, 'unit', s.owner_label, 'phase', s.phase, 'sla', s.sla_days,
        'done', count(l.*) filter (where l.finished_at is not null),
        'avg', round(avg(l.wd) filter (where l.finished_at is not null), 2),
        'max', round(max(l.wd) filter (where l.finished_at is not null), 2),
        'breach_pct', round(100.0 * count(*) filter (where l.finished_at is not null and l.wd > s.sla_days) / nullif(count(*) filter (where l.finished_at is not null), 0), 0),
        'open', count(l.*) filter (where l.finished_at is null),
        'open_overdue', count(l.*) filter (where l.finished_at is null and l.wd > s.sla_days)) x
      from stages s left join l on l.stage = s.n where s.n >= 6 group by s.n) q),
    'branches', (select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'bank', o.name,
        'apps', (select count(*) from apps a where a.branch_id = b.id),
        'avg_cycle', (select round(avg(wd), 1) from cyc where cyc.branch_id = b.id),
        'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 0) from l where l.branch_id = b.id and finished_at is not null and sla_days > 0),
        'open_overdue', (select count(*) from l where l.branch_id = b.id and finished_at is null and sla_days > 0 and wd > sla_days)) order by o.name, b.name), '[]')
      from branches b join orgs o on o.id = b.bank_id where (sc.o_bank is null or b.bank_id = sc.o_bank) and (sc.o_branch is null or b.id = sc.o_branch)),
    'banks', case when sc.o_all then (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name,
        'apps', (select count(*) from apps a where a.bank_id = o.id),
        'completed', (select count(*) from apps a where a.bank_id = o.id and a.status = 'completed'),
        'avg_cycle', (select round(avg(wd), 1) from cyc where cyc.bank_id = o.id),
        'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 0) from l where l.bank_id = o.id and finished_at is not null and sla_days > 0),
        'open_overdue', (select count(*) from l where l.bank_id = o.id and finished_at is null and sla_days > 0 and wd > sla_days),
        'cbi_wait', (select round(avg(wd), 1) from l where l.bank_id = o.id and stage = 23)) order by o.name), '[]')
      from orgs o where o.type = 'bank') end
  ) into res;
  return res;
end $$;

-- أداء الموظفين: الإنجاز، المدة، التأخير، الإعادات، العمل خارج الدوام، الخمول، والإنجاز السريع غير المعتاد
create or replace function public._perf_emp_rows(p_bank uuid, p_branch uuid, p_user uuid, p_days int) returns jsonb
language sql stable security definer set search_path = public as $$
  with staff as (
    select p.* from profiles p where p.portal = 'bank' and p.role not in ('bank_risk')
      and (p_bank is null or p.org_id = p_bank) and (p_branch is null or p.branch_id = p_branch) and (p_user is null or p.id = p_user)),
  done as (
    select l.finished_by uid, l.stage, l.finished_at, _wd(l.entered_at, l.finished_at) wd, l.sla_days, a.amount
    from stage_log l join applications a on a.id = l.application_id
    where l.finished_at is not null and l.finished_at >= now() - make_interval(days => p_days) and l.outcome in ('done','rejected')),
  ev as (
    select e.actor_id uid, e.action, e.created_at from application_events e where e.created_at >= now() - make_interval(days => p_days)),
  queue as (  -- ما ينتظر وحدة الموظف وفرعه الآن
    select st.id uid, count(*) open_items, count(*) filter (where _wd(l.entered_at, now()) > l.sla_days and l.sla_days > 0) overdue
    from staff st join stages s on s.owner_role = st.role
    join stage_log l on l.stage = s.n and l.finished_at is null and l.bank_id = st.org_id and (not s.branch_level or st.branch_id is null or l.branch_id = st.branch_id)
    group by st.id),
  m as (
    select st.id, st.full_name, st.role, st.branch_id, (select name from branches where id = st.branch_id) branch, (select name from orgs where id = st.org_id) bank,
      (select count(*) from done d where d.uid = st.id) actions,
      (select round(avg(wd), 2) from done d where d.uid = st.id) avg_wd,
      (select count(*) from done d where d.uid = st.id and d.sla_days > 0 and d.wd > d.sla_days) breaches,
      (select count(*) from done d where d.uid = st.id and d.wd < 0.02 and d.amount >= 10000000) fast_big,
      (select count(*) from ev where ev.uid = st.id and ev.action like 'إعادة%') returns_made,
      (select count(*) from ev where ev.uid = st.id and ev.action like 'رفض%') rejections,
      (select count(*) from ev where ev.uid = st.id and (extract(hour from ev.created_at at time zone 'Asia/Baghdad') not between 8 and 15
          or extract(isodow from ev.created_at at time zone 'Asia/Baghdad') in (5, 6))) after_hours,
      (select max(created_at) from ev where ev.uid = st.id) last_action,
      coalesce(q.open_items, 0) open_items, coalesce(q.overdue, 0) unit_overdue
    from staff st left join queue q on q.uid = st.id)
  select coalesce(jsonb_agg(to_jsonb(m) || jsonb_build_object(
      'breach_pct', case when actions > 0 then round(100.0 * breaches / actions) end,
      'idle_days', case when last_action is null then null else _wd(last_action, now()) end,
      'flags', to_jsonb(array_remove(array[
        case when actions >= 3 and breaches * 100.0 / actions >= 40 then 'تأخير متكرر' end,
        case when unit_overdue > 0 and (last_action is null or _wd(last_action, now()) >= 3) then 'خمول مع معاملات متأخرة بانتظاره' end,
        case when unit_overdue > 0 then 'معاملات متجاوزة للمدة في وحدته' end,
        case when after_hours >= 2 then 'إجراءات خارج أوقات الدوام' end,
        case when fast_big >= 2 then 'موافقات خلال دقائق على مبالغ كبيرة' end,
        case when actions >= 4 and returns_made * 1.0 / actions > 0.3 then 'نسبة إعادة مرتفعة' end], null))
    ) order by bank, branch nulls first, role, full_name), '[]')
  from m
$$;

create or replace function public.perf_employees(p_bank uuid default null, p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare sc record;
begin
  select * into sc from _perf_scope(p_bank);
  return _perf_emp_rows(sc.o_bank, sc.o_branch, null, p_days);
end $$;

create or replace function public.perf_me(p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'bank' then raise exception 'للموظفين فقط'; end if;
  return coalesce(_perf_emp_rows(me.org_id, null, me.id, p_days)->0, '{}'::jsonb);
end $$;

revoke all on function public._track_stage(), public._ev(uuid,int,text,text), public._perf_scope(uuid), public._perf_emp_rows(uuid,uuid,uuid,int) from public, anon, authenticated;
grant execute on function public._wd(timestamptz, timestamptz) to authenticated;
grant execute on function public.advance_application, public.refer_mortgage, public.registry_action, public.batch_create, public.batch_action,
  public.app_timeline, public.perf_overview, public.perf_employees, public.perf_me to authenticated;

-- 13) عند إرسال المواطن طلبه للمصرف: يُسند إلى الفرع (حسب المحافظة) وتُحسب عمولة المركزي لمرة واحدة
--     (بمشغّل قبل الحفظ، دون تعديل دالة citizen_step)
create or replace function public._assign_branch() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.bank_id is not null and (new.branch_id is null or (select bank_id from branches where id = new.branch_id) is distinct from new.bank_id) then
    new.branch_id := (select b.id from branches b where b.bank_id = new.bank_id order by (new.governorate = any(b.governorates)) desc, b.is_main desc limit 1);
  end if;
  if new.stage >= 6 and new.cbi_fee is null and new.amount is not null then
    new.cbi_fee := round(new.amount * case when new.amount <= _setting('sme_cap') then _setting('cbi_fee_small') else _setting('cbi_fee_large') end / 100);
  end if;
  return new;
end $$;
drop trigger if exists trg_assign_branch on public.applications;
create trigger trg_assign_branch before insert or update of bank_id, stage on public.applications for each row execute function public._assign_branch();
revoke all on function public._assign_branch() from public, anon, authenticated;

-- 14) تقييم المواطن بعد الكشف على التركيب واستلامه (المرحلة 32) بدل المرحلة 12 القديمة
create or replace function public.submit_review(p_app uuid, p_rating integer, p_quality integer, p_install integer, p_service integer, p_comment text)
 returns offer_reviews language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; r offer_reviews;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if not (a.status = 'completed' or a.stage >= 32) then raise exception 'التقييم بعد تركيب المنظومة وتشغيلها'; end if;
  if exists (select 1 from offer_reviews where application_id = a.id) then raise exception 'قيّمت هذه المنظومة مسبقاً'; end if;
  if p_rating not between 1 and 5 then raise exception 'اختر من 1 إلى 5 نجوم'; end if;
  insert into offer_reviews(offer_id, supplier_id, application_id, citizen_id, author_name, governorate, rating, quality, install, service, comment)
  values (a.offer_id, a.supplier_id, a.id, me.id, me.full_name, a.governorate, p_rating, p_quality, p_install, p_service, nullif(trim(p_comment), ''))
  returning * into r;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, 'تقييم المواطن للمنظومة', p_rating || ' من 5', me.id, me.full_name, me.role);
  return r;
end $function$;
