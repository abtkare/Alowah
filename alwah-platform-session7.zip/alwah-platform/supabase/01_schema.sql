-- ألواح — مخطط قاعدة البيانات (Supabase / PostgreSQL)
-- مطبَّق على المشروع alwah-platform (chjeqtjyywomtcenizxp). سجل الترحيلات الكامل محفوظ أيضاً في Supabase.
-- الترتيب: الجداول ← الدوال المساعدة ← سلسلة التدقيق ← الصلاحيات RLS ← محرك المراحل.

create extension if not exists pgcrypto;

create table public.orgs (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  type text not null check (type in ('bank','supplier','cbi','registry','integrity','platform')),
  name text not null, is_islamic boolean default false, meta jsonb default '{}'::jsonb, created_at timestamptz default now()
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null, full_name text not null, role text not null,
  portal text not null check (portal in ('citizen','bank','registry','cbi','supplier','integrity')),
  org_id uuid references public.orgs(id), phone text, national_id text, created_at timestamptz default now()
);
create table public.settings (key text primary key, value numeric not null, label text not null, circular_no text);
create table public.circulars (id uuid primary key default gen_random_uuid(), number text not null, title text not null, issued_on date not null, effective_on date not null, summary text);
create table public.capacity_tiers (id uuid primary key default gen_random_uuid(), kw numeric not null, program text not null default 'household', price_cap bigint not null, daily_kwh numeric, loads text, sort int default 0);
create table public.supplier_offers (
  id uuid primary key default gen_random_uuid(), supplier_id uuid not null references public.orgs(id), tier_id uuid not null references public.capacity_tiers(id),
  title text not null, price bigint not null, components jsonb not null default '[]'::jsonb, description text, warranty text, battery_kwh numeric,
  video_url text, image_url text, version int default 1,
  status text default 'published' check (status in ('draft','review','published','archived')), created_at timestamptz default now()
);
create table public.bank_terms (bank_id uuid primary key references public.orgs(id), margin numeric not null, file_fee bigint default 0, max_term_months int default 84, processing_days int default 7, single_approval_cap bigint default 15000000);
create table public.bank_allocations (bank_id uuid primary key references public.orgs(id), allocated bigint not null, reserved bigint default 0, disbursed bigint default 0, recovered bigint default 0);
create table public.properties (
  id uuid primary key default gen_random_uuid(), deed_no text unique not null, owner_name text not null, owner_national_id text,
  governorate text not null, district text not null, zone text, use_type text default 'سكني', land_area numeric, build_area numeric, ref_value bigint,
  status text default 'free' check (status in ('free','mortgaged','seized','frozen')), shares int default 1
);
create table public.applications (
  id uuid primary key default gen_random_uuid(), code text unique not null,
  citizen_id uuid references public.profiles(id), citizen_name text not null, ur_number text, ur_verified boolean default false,
  offer_id uuid references public.supplier_offers(id), supplier_id uuid references public.orgs(id), bank_id uuid references public.orgs(id),
  kw numeric, price bigint, amount bigint, term_months int default 60, margin numeric, monthly_installment bigint,
  guarantee_type text check (guarantee_type in ('single_salary','multi_salary','mortgage')), property_id uuid references public.properties(id),
  governorate text not null, city text, lat numeric, lng numeric,
  stage int not null default 1 check (stage between 1 and 14),
  status text not null default 'active' check (status in ('active','returned','rejected','completed','court_hold','cancelled')),
  bank_unit text, inspection_result text, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table public.application_events (
  id bigint generated always as identity primary key, application_id uuid not null references public.applications(id) on delete cascade,
  stage int not null, action text not null, note text, actor_id uuid, actor_name text, actor_role text, prev_hash text, hash text, created_at timestamptz default now()
);
create table public.mortgage_referrals (
  id uuid primary key default gen_random_uuid(), application_id uuid not null references public.applications(id) on delete cascade,
  property_id uuid not null references public.properties(id), bank_id uuid references public.orgs(id),
  status text not null default 'pending' check (status in ('pending','clear','encumbered','matched','annotated','released','rejected')),
  debt_amount bigint, annotation_no text, note text, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table public.integrity_alerts (
  id uuid primary key default gen_random_uuid(), type text not null, severity text not null check (severity in ('low','medium','high')),
  title text not null, details text, application_id uuid references public.applications(id) on delete set null, entity text, created_at timestamptz default now()
);
create table public.stages (n int primary key, name text not null, owner_role text not null, owner_label text not null);

-- دوال الهوية
create or replace function public.my_role()   returns text language sql stable security definer set search_path=public as $$ select role   from profiles where id = auth.uid() $$;
create or replace function public.my_portal() returns text language sql stable security definer set search_path=public as $$ select portal from profiles where id = auth.uid() $$;
create or replace function public.my_org()    returns uuid language sql stable security definer set search_path=public as $$ select org_id from profiles where id = auth.uid() $$;

-- سجل تدقيق متسلسل: كل حدث يحمل بصمة الحدث قبله
create or replace function public.chain_event() returns trigger language plpgsql set search_path=public, extensions as $$
declare ph text;
begin
  select hash into ph from application_events order by id desc limit 1;
  new.prev_hash := coalesce(ph, 'GENESIS');
  new.hash := encode(extensions.digest(new.prev_hash || new.application_id::text || new.stage::text || new.action || coalesce(new.note,'') || coalesce(new.actor_id::text,'') || new.created_at::text, 'sha256'), 'hex');
  return new;
end $$;
create trigger trg_chain before insert on public.application_events for each row execute function public.chain_event();

-- RLS: القراءة فقط عبر السياسات، والكتابة فقط عبر الدوال أدناه
alter table public.orgs enable row level security;              create policy read_orgs on public.orgs for select to authenticated using (true);
alter table public.profiles enable row level security;          create policy read_self on public.profiles for select to authenticated using (id = auth.uid() or my_portal() in ('cbi','integrity'));
alter table public.settings enable row level security;          create policy read_settings on public.settings for select to authenticated using (true);
alter table public.circulars enable row level security;         create policy read_circulars on public.circulars for select to authenticated using (true);
alter table public.capacity_tiers enable row level security;    create policy read_tiers on public.capacity_tiers for select to authenticated using (true);
alter table public.supplier_offers enable row level security;   create policy read_offers on public.supplier_offers for select to authenticated using (status='published' or supplier_id = my_org() or my_portal() in ('cbi','integrity'));
alter table public.bank_terms enable row level security;        create policy read_terms on public.bank_terms for select to authenticated using (true);
alter table public.bank_allocations enable row level security;  create policy read_alloc on public.bank_allocations for select to authenticated using (bank_id = my_org() or my_portal() in ('cbi','integrity'));
alter table public.properties enable row level security;        create policy read_props on public.properties for select to authenticated using (my_portal() in ('registry','cbi','integrity','bank'));
alter table public.applications enable row level security;
create policy read_apps on public.applications for select to authenticated using (
  citizen_id = auth.uid()
  or (my_portal()='bank' and bank_id = my_org())
  or (my_portal()='supplier' and supplier_id = my_org())
  or (my_portal()='registry' and exists (select 1 from mortgage_referrals m where m.application_id = applications.id))
  or my_portal() in ('cbi','integrity'));
alter table public.application_events enable row level security; create policy read_events on public.application_events for select to authenticated using (exists (select 1 from applications a where a.id = application_id));
alter table public.mortgage_referrals enable row level security;  create policy read_refs on public.mortgage_referrals for select to authenticated using (my_portal() in ('registry','cbi','integrity') or (my_portal()='bank' and bank_id = my_org()));
alter table public.integrity_alerts enable row level security;    create policy read_alerts on public.integrity_alerts for select to authenticated using (my_portal() in ('integrity','cbi'));
alter table public.stages enable row level security;              create policy read_stages on public.stages for select to authenticated using (true);

alter publication supabase_realtime add table public.applications, public.application_events, public.mortgage_referrals, public.integrity_alerts, public.bank_allocations;

insert into public.stages values
(1,'التحقق من الهوية (eKYC)','citizen','المواطن'),(2,'رقم «أور»','citizen','المواطن'),(3,'اختيار القدرة وعرض المورد','citizen','المواطن'),
(4,'الضمان وموافقة الكفلاء','citizen','المواطن'),(5,'اختيار المصرف','citizen','المواطن'),(6,'الامتثال وفتح الحساب','bank_compliance','الامتثال'),
(7,'الاستلام والتحقق من «أور»','bank_cs','خدمة العملاء'),(8,'التأييدات والرهن والدراسة','bank_credit','الائتمان'),(9,'القرار الائتماني','bank_committee','لجنة الائتمان'),
(10,'العقد والتأمين والرهن المؤشَّر','bank_legal','الشؤون القانونية'),(11,'التركيب','supplier_admin','المورد'),(12,'التشغيل والتدقيق الهندسي','supplier_admin','المورد والمدقق'),
(13,'إطلاق السيولة','cbi_admin','البنك المركزي'),(14,'الصرف للمورد والتحصيل','bank_ops','العمليات المصرفية');

-- محرك المراحل: الانتقال الوحيد المسموح، مع شروط الحوكمة
-- advance_application(طلب, 'advance'|'return'|'reject', ملاحظة)
--   يتحقق أن المستخدم صاحب دور المرحلة الحالية ومن جهة الطلب نفسها
--   المرحلة 8 برهن: يلزم تأكيد خلو العقار | المرحلة 9: يحجز المبلغ من حصة المصرف ويرفض إن لم تكفِ
--   المرحلة 10 برهن: يلزم تأشير الرهن | المرحلة 12: يسجل نتيجة التدقيق «مطابق» | المرحلة 14: ينقل المحجوز إلى المصروف ويغلق الطلب
-- refer_mortgage(طلب, ملاحظة): إحالة الرهن من الائتمان/القانونية إلى التسجيل العقاري
-- registry_action(إحالة, 'check'|'match'|'annotate'|'release'|'reject', ملاحظة): إجراءات التسجيل العقاري بالترتيب
-- (النص الكامل للدوال الثلاث في 02_functions.sql)
