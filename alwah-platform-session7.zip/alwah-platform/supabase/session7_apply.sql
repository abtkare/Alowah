-- ألواح — الجلسة 7: سجل مراجعة قراءة البطاقة الوطنية (ما قرأته البطاقة، وما عدّله المواطن، والحقول التي نُبّه إليها)
begin;
alter table profiles add column if not exists id_review jsonb;

create or replace function public.update_my_id_card(p jsonb)
 returns profiles language plpgsql security definer set search_path to 'public'
as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'citizen' then raise exception 'غير مسجل الدخول'; end if;
  if coalesce(p->>'national_id', '') !~ '^[0-9]{12}$' then raise exception 'رقم البطاقة الوطنية 12 رقماً'; end if;
  if me.national_id is not null and me.national_id <> p->>'national_id' then raise exception 'البطاقة المصوّرة لا تطابق الرقم الوطني المسجل في حسابك'; end if;
  if exists (select 1 from profiles where national_id = p->>'national_id' and id <> me.id) then raise exception 'رقم البطاقة الوطنية مسجل بحساب آخر'; end if;
  perform _id_fields_check(p);
  update profiles set national_id = p->>'national_id',
    full_name = case when me.kyc_status <> 'verified' and array_length(string_to_array(trim(coalesce(p->>'full_name', '')), ' '), 1) >= 3 then regexp_replace(trim(p->>'full_name'), '\s+', ' ', 'g') else full_name end,
    birth_date = coalesce(nullif(p->>'birth_date', '')::date, birth_date),
    mother_name = coalesce(nullif(trim(p->>'mother_name'), ''), mother_name), gender = coalesce(nullif(p->>'gender', ''), gender),
    place_of_birth = coalesce(nullif(trim(p->>'place_of_birth'), ''), place_of_birth), name_latin = coalesce(nullif(trim(p->>'name_latin'), ''), name_latin),
    blood_type = coalesce(nullif(p->>'blood_type', ''), blood_type),
    id_card_number = coalesce(nullif(trim(p->>'card_number'), ''), id_card_number), id_issue_date = coalesce(nullif(p->>'issue_date', '')::date, id_issue_date),
    id_expiry = coalesce(nullif(p->>'expiry_date', '')::date, id_expiry), id_issuer = coalesce(nullif(trim(p->>'issuer'), ''), id_issuer),
    family_number = coalesce(nullif(trim(p->>'family_number'), ''), family_number),
    id_review = case when jsonb_typeof(p->'id_review') = 'object' then p->'id_review' else id_review end,
    id_source = 'ocr', id_mrz_verified = coalesce((p->>'mrz_verified')::boolean, false), updated_at = now()
  where id = me.id returning * into me;
  return me;
end $function$;
commit;
