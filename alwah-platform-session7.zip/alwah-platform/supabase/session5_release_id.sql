-- ألواح — بطلب صاحبه: فك ارتباط البطاقة الوطنية 198740115512 بالحساب التجريبي القديم (07800000001)
-- ليتمكن من إنشاء حساب جديد. يُؤرشف الحساب بدل حذفه حفاظاً على سلسلة التحقق في سجل أحداث الطلبات.
do $$
declare pid uuid;
begin
  select id into pid from profiles where national_id = '198740115512';
  if pid is null then return; end if;
  update applications set status = 'cancelled', updated_at = now() where citizen_id = pid and status in ('active', 'returned');
  update profiles set national_id = null, phone = null, username = 'archived-' || left(pid::text, 8),
    full_name = full_name || ' (حساب مؤرشف)', id_card_number = null, family_number = null, updated_at = now()
  where id = pid;
  update auth.users set email = 'archived-' || pid::text || '@alwah.demo', phone = null, banned_until = '2999-01-01'::timestamptz where id = pid;
end $$;
