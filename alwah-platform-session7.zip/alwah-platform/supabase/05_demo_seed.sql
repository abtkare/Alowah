-- ألواح — الجلسة 4: بيانات العرض للمراحل الجديدة (الفروع، الموظفون الجدد، السجل الزمني الكامل لكل طلب)
-- كل الأسماء وهمية. يُعاد بناء أحداث الطلبات التجريبية فقط؛ أحداث الطلبات التي أنشأها مستخدمون حقيقيون تُحفظ كما هي.

-- 1) الفروع
insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone) values
((select id from orgs where code='bank1'),'SNB-01','الفرع الرئيسي — بغداد','{بغداد,ديالى,الأنبار,صلاح الدين,واسط,نينوى,كركوك,أربيل,السليمانية,دهوك,بابل,القادسية,الديوانية}',true,'07700100101'),
((select id from orgs where code='bank1'),'SNB-02','فرع البصرة','{البصرة,ذي قار,ميسان,المثنى}',false,'07700100102'),
((select id from orgs where code='bank2'),'WAH-01','الفرع الرئيسي — بغداد','{بغداد,ديالى,الأنبار,صلاح الدين,واسط,نينوى,كركوك,أربيل,السليمانية,دهوك,البصرة,ذي قار,ميسان}',true,'07700200201'),
((select id from orgs where code='bank2'),'WAH-02','فرع النجف','{النجف,كربلاء,بابل,القادسية,الديوانية,المثنى}',false,'07700200202'),
((select id from orgs where code='bank3'),'DJL-01','الفرع الرئيسي — بغداد','{}',true,'07700300301')
on conflict (code) do nothing;

-- 2) الموظفون: مسميات المراحل الجديدة وأسماء وهمية
update profiles set full_name = 'كرار نعمة — التحصيل والمتابعة' where username = 'snb.collect';
update profiles set full_name = 'رواء صباح — التحصيل والمتابعة' where username = 'wah.collect';
update profiles set full_name = 'زيد رياض — الامتثال وفتح الحسابات' where username = 'wah.compliance';
update profiles set full_name = 'مصطفى ناظم — الامتثال وفتح الحسابات' where username = 'snb.compliance';
update profiles set full_name = 'شهد عادل — ائتمان المبادرات' where username = 'wah.credit';
update profiles set full_name = 'دعاء فلاح — ائتمان المبادرات' where username = 'snb.credit';
update profiles set full_name = 'د. عمار ثامر — اللجنة الائتمانية العليا' where username = 'wah.committee';
update profiles set full_name = 'د. سلام هادي — اللجنة الائتمانية العليا' where username = 'snb.committee';
update profiles set full_name = 'رسل عباس — خدمة الزبائن', branch_id = (select id from branches where code='SNB-01') where username = 'snb.cs';
update profiles set full_name = 'سجى ماجد — خدمة الزبائن', branch_id = (select id from branches where code='WAH-01') where username = 'wah.cs';

do $$
declare r record;
begin
  for r in select * from (values
    ('snb.cs2','Snb@2026c2','لمى سالم — خدمة الزبائن','bank_cs','bank1','SNB-02'),
    ('snb.branch','Snb@2026br','قيصر عدنان — مدير الفرع الرئيسي','bank_branch_mgr','bank1','SNB-01'),
    ('snb.branch2','Snb@2026b2','منتظر كاظم — مدير فرع البصرة','bank_branch_mgr','bank1','SNB-02'),
    ('snb.teller','Snb@2026tl','سرى منذر — أمين الصندوق','bank_teller','bank1','SNB-01'),
    ('snb.teller2','Snb@2026t2','ميثم جليل — أمين الصندوق','bank_teller','bank1','SNB-02'),
    ('snb.init','Snb@2026in','تبارك ليث — إداري قسم المبادرات','bank_initiatives','bank1',null),
    ('snb.initmgr','Snb@2026im','أنمار رعد — مدير قسم المبادرات','bank_initiatives_mgr','bank1',null),
    ('snb.md','Snb@2026md','د. وسام ثامر — الإدارة العليا','bank_md','bank1',null),
    ('snb.inspect','Snb@2026ks','م. ديار شوكت — لجنة الكشف الموقعي','bank_inspection','bank1',null),
    ('snb.admin','Snb@2026ad','بان صلاح — قسم الإدارة','bank_admin','bank1',null),
    ('wah.cs2','Wah@2026c2','نبأ عصمت — خدمة الزبائن','bank_cs','bank2','WAH-02'),
    ('wah.branch','Wah@2026br','سيف عامر — مدير الفرع الرئيسي','bank_branch_mgr','bank2','WAH-01'),
    ('wah.branch2','Wah@2026b2','آية مروان — مديرة فرع النجف','bank_branch_mgr','bank2','WAH-02'),
    ('wah.teller','Wah@2026tl','كرار حامد — أمين الصندوق','bank_teller','bank2','WAH-01'),
    ('wah.teller2','Wah@2026t2','ياسمين طلال — أمينة الصندوق','bank_teller','bank2','WAH-02'),
    ('wah.init','Wah@2026in','رنا جاسم — إداري قسم المبادرات','bank_initiatives','bank2',null),
    ('wah.initmgr','Wah@2026im','مهند رافد — مدير قسم المبادرات','bank_initiatives_mgr','bank2',null),
    ('wah.md','Wah@2026md','د. لؤي سامي — الإدارة العليا','bank_md','bank2',null),
    ('wah.inspect','Wah@2026ks','م. زينة فؤاد — لجنة الكشف الموقعي','bank_inspection','bank2',null),
    ('wah.admin','Wah@2026ad','أوس ناجي — قسم الإدارة','bank_admin','bank2',null),
    ('djl.cs','Djl@2026cs','رغد حازم — خدمة الزبائن','bank_cs','bank3','DJL-01'),
    ('djl.compliance','Djl@2026co','نمير صادق — الامتثال وفتح الحسابات','bank_compliance','bank3',null),
    ('djl.branch','Djl@2026br','جنان وليد — مديرة الفرع الرئيسي','bank_branch_mgr','bank3','DJL-01'),
    ('djl.init','Djl@2026in','سلوان مثنى — إداري قسم المبادرات','bank_initiatives','bank3',null),
    ('djl.credit','Djl@2026cr','هالة ضرغام — ائتمان المبادرات','bank_credit','bank3',null),
    ('djl.inspect','Djl@2026ks','م. حارث نبيل — لجنة الكشف الموقعي','bank_inspection','bank3',null),
    ('djl.initmgr','Djl@2026im','ريام ستار — مديرة قسم المبادرات','bank_initiatives_mgr','bank3',null),
    ('djl.legal','Djl@2026lg','م. بشرى قحطان — القسم القانوني','bank_legal','bank3',null),
    ('djl.md','Djl@2026md','د. ثائر مجيد — الإدارة العليا','bank_md','bank3',null),
    ('djl.admin','Djl@2026ad','تيسير عادل — قسم الإدارة','bank_admin','bank3',null),
    ('djl.ops','Djl@2026op','شيماء رحيم — العمليات المصرفية','bank_ops','bank3',null),
    ('djl.teller','Djl@2026tl','غسان فيصل — أمين الصندوق','bank_teller','bank3','DJL-01')
  ) t(u, pw, nm, rl, org, br) loop
    if not exists (select 1 from profiles where username = r.u) then
      perform _mk_user(r.u, r.pw, r.nm, r.rl, 'bank', r.org);
    end if;
    update profiles set branch_id = (select id from branches where code = r.br) where username = r.u;
  end loop;
end $$;

-- 3) إعادة بناء السجل الزمني للطلبات التجريبية
create or replace function pg_temp.worktime(t timestamptz, after_hours boolean) returns timestamptz language plpgsql as $$
declare l timestamp := t at time zone 'Asia/Baghdad'; h int;
begin
  if after_hours then l := date_trunc('day', l) + interval '21 hours' + (random() * 50) * interval '1 minute';
  else
    h := extract(hour from l);
    if h < 8 then l := date_trunc('day', l) + interval '8 hours 30 minutes' + (random() * 60) * interval '1 minute';
    elsif h >= 15 then l := date_trunc('day', l) + interval '1 day 9 hours' + (random() * 90) * interval '1 minute'; end if;
  end if;
  while extract(isodow from l) in (5, 6) loop l := l + interval '1 day'; end loop;
  if extract(isodow from l) = 7 and not after_hours and extract(hour from l) not between 8 and 14 then l := date_trunc('day', l) + interval '10 hours'; end if;
  return l at time zone 'Asia/Baghdad';
end $$;

create or replace function pg_temp.actor(p_bank uuid, p_branch uuid, p_role text, p_supplier uuid, p_citizen uuid) returns profiles language sql as $$
  select * from profiles where
    case when p_role = 'citizen' then id = p_citizen
         when p_role = 'supplier_admin' then org_id = p_supplier and role = p_role
         when p_role = 'cbi_admin' then role = 'cbi_admin'
         else org_id = p_bank and role = p_role and (branch_id is null or branch_id = p_branch or p_branch is null) end
  order by (branch_id = p_branch) desc nulls last, username limit 1
$$;

do $$
declare
  a record; s record; me profiles; t timestamptz; fin timestamptz; d numeric; plan numeric[]; tot numeric; sc numeric; i int;
  tgt int; fstat text; open_age numeric; keep uuid[]; act text; fac numeric; ah boolean; br uuid; b cbi_batches; seq int := 0; ret boolean;
begin
  perform setseed(0.4242);
  alter table applications disable trigger trg_track_stage;
  alter table applications disable trigger trg_assign_branch;

  -- طلبات أنشأها مستخدمون حقيقيون (لا تُمس أحداثها)
  select coalesce(array_agg(a2.id), '{}') into keep from applications a2 join profiles p on p.id = a2.citizen_id where p.self_registered;

  create temp table ev_new (application_id uuid, stage int, action text, note text, actor_id uuid, actor_name text, actor_role text, created_at timestamptz) on commit drop;
  insert into ev_new select application_id, stage, action, note, actor_id, actor_name, actor_role, created_at from application_events where application_id = any(keep);
  delete from application_events;
  delete from stage_log; update applications set batch_id = null; delete from cbi_batches;
  delete from integrity_alerts where type in ('sla','behavior');

  -- الإسناد للفروع
  update applications x set branch_id = (select bb.id from branches bb where bb.bank_id = x.bank_id order by (x.governorate = any(bb.governorates)) desc, bb.is_main desc limit 1)
  where bank_id is not null;

  -- الهدف لكل طلب: المرحلة الحالية والحالة
  create temp table tg (code text, target int, st text, age numeric) on commit drop;
  insert into tg values
    ('ALW-2026-00030',23,'active',6), ('ALW-2026-00031',20,'active',2.5), ('ALW-2026-00032',31,'active',5),
    ('ALW-2026-00033',25,'active',1.2), ('ALW-2026-00034',14,'active',4), ('ALW-2026-00035',19,'active',3),
    ('ALW-2026-00036',6,'returned',3), ('ALW-2026-00037',11,'active',12), ('ALW-2026-00038',15,'rejected',0),
    ('ALW-2026-00101',6,'active',0.6), ('ALW-2026-00102',9,'active',2), ('ALW-2026-00103',16,'active',1.5);
  insert into tg select code, 37, 'completed', 0 from applications where status = 'completed' and code not in (select code from tg);

  for a in select x.*, tg.target, tg.st, tg.age from applications x join tg on tg.code = x.code where not (x.id = any(keep)) order by x.created_at loop
    tgt := a.target; fstat := a.st;
    -- مدة كل مرحلة (أيام تقويمية)
    plan := '{}'; tot := 0;
    for s in select * from stages order by n loop
      exit when s.n > tgt or (s.n = tgt and fstat <> 'completed' and fstat <> 'rejected');
      me := pg_temp.actor(a.bank_id, a.branch_id, s.owner_role, a.supplier_id, a.citizen_id);
      fac := 1;
      if me.username = 'snb.cs2' then fac := 2.7; end if;
      if me.username = 'snb.branch2' then fac := 2.3; end if;
      if me.username = 'wah.legal' then fac := 2.2; end if;
      if me.username = 'djl.inspect' then fac := 1.8; end if;
      d := case when s.n <= 5 then (0.01 + random() * 0.15)
                when s.n = 23 then 4 + random() * 9
                when s.n = 31 then 3 + random() * 8
                when me.username = 'wah.md' then 0.004 + random() * 0.008
                else greatest(0.04, s.sla_days * (0.15 + random() * 0.55) * fac * 1.2) end;
      plan := plan || d; tot := tot + d;
    end loop;

    if fstat = 'completed' then
      t := a.created_at;
      sc := least(1, extract(epoch from (now() - interval '2 days' - t)) / 86400 / greatest(tot, 0.1));
    else
      sc := 1;
      -- هامش لأيام العطل وانتقال المعاملة لليوم التالي بعد انتهاء الدوام
      t := now() - make_interval(secs => ((tot * 1.12 + greatest(tgt - 6, 0) * 0.35 + a.age) * 86400)::int);
    end if;
    update applications set created_at = t where id = a.id;
    insert into ev_new values (a.id, 1, 'بدء طلب تمويل جديد من الكتالوج', null, a.citizen_id, a.citizen_name, 'citizen', t);

    i := 0;
    for s in select * from stages order by n loop
      exit when s.n > tgt;
      me := pg_temp.actor(a.bank_id, a.branch_id, s.owner_role, a.supplier_id, a.citizen_id);
      if s.n = tgt and fstat in ('active','returned') then
        insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days, returns)
        values (a.id, s.n, a.bank_id, a.branch_id, t, s.sla_days, case when fstat = 'returned' then 1 else 0 end);
        if fstat = 'returned' then
          insert into ev_new values (a.id, s.n, 'إعادة للاستكمال', 'نقص في المستمسكات: بطاقة السكن غير مرفقة، واستمارة المتطلبات غير موقعة',
            me.id, coalesce(me.full_name, '—'), s.owner_role, pg_temp.worktime(t + interval '5 hours', false));
        end if;
        exit;
      end if;
      i := i + 1;
      ah := me.username = 'snb.ops' and random() < 0.6;
      fin := t + make_interval(secs => (plan[i] * sc * 86400)::int);
      if s.n > 5 and me.username <> 'wah.md' then fin := pg_temp.worktime(fin, ah); end if;
      if fin <= t then fin := t + interval '7 minutes'; end if;
      ret := s.n > 5 and s.owner_role like 'bank_%' and random() < 0.04;
      if ret then
        insert into ev_new values (a.id, s.n, 'إعادة للاستكمال', 'استكمال نقص في الإضبارة', me.id, me.full_name, me.role, least(pg_temp.worktime(t + (fin - t) / 3, false), fin - interval '5 minutes'));
      end if;
      act := case s.n when 1 then 'التحقق من الهوية بالسيلفي' when 2 then 'ربط رقم «أور» وتأكيده برمز التحقق' when 3 then 'تثبيت العرض المختار'
        when 4 then case when a.guarantee_type = 'mortgage' then 'تأكيد الضمان: رهن عقار' else 'تأكيد الضمان وموافقة الكفلاء' end
        when 5 then 'اختيار المصرف وتوقيع الطلب إلكترونياً'
        else case when s.n = tgt and fstat = 'rejected' then 'رفض مسبب' when s.n = 37 then 'حفظ العقود وإغلاق الملف — اكتمال الطلب' else 'إنجاز: ' || s.name end end;
      insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, finished_at, finished_by, finished_by_name, finished_by_role, outcome, returns, sla_days)
      values (a.id, s.n, case when s.n > 5 then a.bank_id end, case when s.n > 5 then a.branch_id end, t, fin, me.id, coalesce(me.full_name, a.citizen_name), s.owner_role,
        case when s.n = tgt and fstat = 'rejected' then 'rejected' else 'done' end, case when ret then 1 else 0 end, s.sla_days);
      insert into ev_new values (a.id, s.n, act,
        case when s.n = tgt and fstat = 'rejected' then 'الدراسة الائتمانية: القسط يتجاوز 40% من دخل المتقدم والكفيل غير مستوفٍ لشرط الخدمة' end,
        me.id, coalesce(me.full_name, a.citizen_name), s.owner_role, fin);
      if s.n = 8 then update applications set initial_approved_at = fin where id = a.id; end if;
      if s.n = 10 then update applications set fees_paid_at = fin where id = a.id; end if;
      if s.n = 23 then update applications set cbi_approved_at = fin where id = a.id; end if;
      t := fin;
    end loop;

    -- إن تجاوز آخر حدث الوقت الحالي (بسبب أيام العطل) يُزاح السجل كله بأسابيع كاملة للحفاظ على أيام الدوام وساعاته
    if t > now() - make_interval(secs => (a.age * 0.3 * 86400)::int) - interval '10 minutes' then
      fac := ceil(extract(epoch from (t - (now() - make_interval(secs => (a.age * 0.3 * 86400)::int) - interval '10 minutes'))) / 604800.0);
      update stage_log set entered_at = entered_at - fac * interval '7 days', finished_at = finished_at - fac * interval '7 days' where application_id = a.id;
      update ev_new set created_at = created_at - fac * interval '7 days' where application_id = a.id;
      update applications set created_at = created_at - fac * interval '7 days',
        initial_approved_at = initial_approved_at - fac * interval '7 days', fees_paid_at = fees_paid_at - fac * interval '7 days',
        cbi_approved_at = cbi_approved_at - fac * interval '7 days' where id = a.id;
      t := t - fac * interval '7 days';
    end if;
    update applications set stage = tgt, status = fstat, updated_at = t, bank_unit = (select owner_label from stages where n = tgt),
      inspection_result = case when tgt >= 33 then 'مطابق' end,
      cbi_fee = case when bank_id is not null then round(amount * case when amount <= 20000000 then 1.5 else 2 end / 100) end,
      margin = least(coalesce(margin, 2), 3.5), term_months = least(coalesce(term_months, 60), 60)
    where id = a.id;
  end loop;

  -- طلبات المستخدمين الحقيقيين: سجلها الزمني من أحداثها
  for a in select * from applications where id = any(keep) loop
    t := a.created_at;
    for s in select e.stage, max(e.created_at) fat, (array_agg(e.actor_name order by e.created_at desc))[1] nm, (array_agg(e.actor_id order by e.created_at desc))[1] uid
             from ev_new e where e.application_id = a.id and e.stage < a.stage group by e.stage order by e.stage loop
      insert into stage_log(application_id, stage, entered_at, finished_at, finished_by, finished_by_name, finished_by_role, outcome, sla_days)
      values (a.id, s.stage, t, s.fat, s.uid, s.nm, 'citizen', 'done', 0);
      t := s.fat;
    end loop;
    insert into stage_log(application_id, stage, entered_at, sla_days) values (a.id, a.stage, t, 0);
  end loop;

  -- السلف التجميعية التاريخية (لكل طلب تجاوز المرحلة 20)
  for a in select x.*, l20.finished_at f20, l21.finished_at f21, l22.finished_at f22, l23.finished_at f23,
             l21.finished_by_name n21, l22.finished_by_name n22, l23.finished_by_name n23, l20.finished_by_name n20
           from applications x join stage_log l20 on l20.application_id = x.id and l20.stage = 20 and l20.finished_at is not null
           left join stage_log l21 on l21.application_id = x.id and l21.stage = 21
           left join stage_log l22 on l22.application_id = x.id and l22.stage = 22
           left join stage_log l23 on l23.application_id = x.id and l23.stage = 23
           order by l20.finished_at loop
    seq := seq + 1;
    insert into cbi_batches(code, bank_id, total, apps_count, status, letter_ref, created_by_name, created_at, signed_by_name, signed_at, sent_by_name, sent_at, decided_by_name, decided_at)
    values ((select split_part(code, '-', 1) from branches where bank_id = a.bank_id order by is_main desc limit 1) || '-ST-2026-' || lpad(seq::text, 3, '0'),
      a.bank_id, a.amount, 1, case when a.f23 is not null then 'approved' when a.f22 is not null then 'sent' when a.f21 is not null then 'signed' else 'draft' end,
      'ك-2026-' || lpad((1000 + seq * 7)::text, 4, '0'), a.n20, a.f20, a.n21, a.f21, a.n22, a.f22, a.n23, a.f23)
    returning * into b;
    update applications set batch_id = b.id where id = a.id;
  end loop;

  -- الرهن: 00102 في الإجراء الأولي (يحيله موظف خدمة الزبائن)، و00035 جاهز للتأشير النهائي
  update mortgage_referrals set status = 'pending', annotation_no = null, updated_at = now(), created_at = now() - interval '1 day'
  where application_id = (select id from applications where code = 'ALW-2026-00102');
  update properties set status = 'free' where id in (select property_id from applications where code in ('ALW-2026-00102','ALW-2026-00035'));
  insert into mortgage_referrals(application_id, property_id, bank_id, status, debt_amount, note, created_at, updated_at)
  select id, property_id, bank_id, 'matched', amount, 'الإجراء الأولي مكتمل — بانتظار التأشير النهائي', now() - interval '12 days', now() - interval '9 days'
  from applications where code = 'ALW-2026-00035' and property_id is not null
    and not exists (select 1 from mortgage_referrals m where m.application_id = applications.id);

  -- دفتر الحصص: المحجوز = طلبات وافق عليها المركزي ولم تُصرف، المصروف = المكتملة
  update bank_allocations ba set
    reserved = coalesce((select sum(amount) from applications x where x.bank_id = ba.bank_id and x.status = 'active' and x.stage between 24 and 35), 0),
    disbursed = coalesce((select sum(amount) from applications x where x.bank_id = ba.bank_id and x.status = 'completed'), 0);

  -- الأحداث بترتيبها الزمني لتتسلسل البصمات
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role, created_at)
  select application_id, stage, action, note, actor_id, actor_name, actor_role, created_at from ev_new order by created_at;

  -- تنبيهات التأخير الكبير (أكثر من ضعفين ونصف المدة)
  insert into integrity_alerts(type, severity, title, details, application_id, entity, created_at)
  select 'sla', case when _wd(l.entered_at, l.finished_at) > l.sla_days * 3 then 'high' else 'medium' end,
    'تأخير في مرحلة «' || stg.name || '»',
    'استغرقت ' || _wd(l.entered_at, l.finished_at) || ' يوم دوام والمسموح ' || l.sla_days || '. المنفذ: ' || coalesce(l.finished_by_name, '—'),
    l.application_id, (select name from orgs where id = l.bank_id), l.finished_at
  from stage_log l join stages stg on stg.n = l.stage
  where l.finished_at is not null and l.sla_days > 0 and _wd(l.entered_at, l.finished_at) > l.sla_days * 2.5;

  insert into integrity_alerts(type, severity, title, details, entity, created_at) values
  ('behavior','high','موافقات خلال دقائق على مبالغ كبيرة','الإدارة العليا في أحد المصارف تعتمد طلبات تتجاوز 10 ملايين دينار خلال أقل من 15 دقيقة من وصولها، دون وقت كافٍ لمراجعة الدراسة والقرار القانوني.',(select name from orgs where code='bank2'), now() - interval '2 days'),
  ('behavior','medium','إجراءات تنفيذ خارج أوقات الدوام','قسم العمليات المصرفية في أحد المصارف نفّذ أوامر شراء وتنفيذ تمويل بعد الساعة التاسعة مساءً في عدة معاملات.',(select name from orgs where code='bank1'), now() - interval '3 days'),
  ('behavior','medium','تأخير متكرر في استقبال المستمسكات','خدمة الزبائن في أحد الفروع تتجاوز المدة المسموحة لتدقيق المستمسكات في أغلب المعاملات، مع معاملات متوقفة لدى مدير الفرع نفسه.',(select name from orgs where code='bank1'), now() - interval '1 day');

  alter table applications enable trigger trg_track_stage;
  alter table applications enable trigger trg_assign_branch;
end $$;
