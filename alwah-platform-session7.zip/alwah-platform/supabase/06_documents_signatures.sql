-- ألواح — الجلسة 4 (ب): الدفع قبل الإرسال، سند العقار بكاميرا الهاتف، إقرار الملكية ومطابقتها،
-- رفض التأشير بأسباب موثقة ودليل، ورمز تعريفي لكل موظف يرافق كل إجراء بمثابة التوقيع والختم.

-- ═══ 1) رمز الموظف ومنصبه ═══
alter table public.profiles add column if not exists staff_code text, add column if not exists position_title text;
create unique index if not exists profiles_staff_code_uq on public.profiles(staff_code) where staff_code is not null;

create or replace function public._role_abbr(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' else 'XX' end $$;
create or replace function public._role_title(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض' else r end $$;

-- يُمنح كل موظف رمزاً ثابتاً لا يتكرر: بادئة الجهة ـ الوظيفة ـ رقم
create or replace function public._staff_prefix(p_org uuid) returns text language sql stable set search_path = public as $$
  select coalesce((select split_part(code, '-', 1) from branches where bank_id = p_org order by is_main desc limit 1), upper((select code from orgs where id = p_org)), 'ALW')
$$;
create or replace function public._assign_staff_code() returns trigger language plpgsql security definer set search_path = public as $$
declare pre text; n int;
begin
  if new.portal = 'citizen' then return new; end if;
  new.position_title := _role_title(new.role) || coalesce(' — ' || (select name from branches where id = new.branch_id), '');
  if new.staff_code is null then
    pre := _staff_prefix(new.org_id) || '-' || _role_abbr(new.role) || '-';
    select coalesce(max(substring(staff_code from length(pre) + 1)::int), 0) + 1 into n from profiles where staff_code like pre || '%';
    new.staff_code := pre || lpad(n::text, 3, '0');
  end if;
  return new;
end $$;
drop trigger if exists trg_staff_code on public.profiles;
create trigger trg_staff_code before insert or update of role, branch_id, org_id on public.profiles for each row execute function public._assign_staff_code();
-- تعبئة الموجودين برقم تسلسلي حسب اسم المستخدم
with x as (select id, _staff_prefix(org_id) || '-' || _role_abbr(role) || '-' pre, username from profiles where portal <> 'citizen' and staff_code is null),
y as (select id, pre || lpad((row_number() over (partition by pre order by username))::text, 3, '0') code from x)
update public.profiles p set staff_code = y.code, position_title = _role_title(p.role) || coalesce(' — ' || (select name from branches where id = p.branch_id), '')
from y where y.id = p.id;

-- ═══ 2) توقيع كل إجراء: المنصب ظاهر لكل من يرى المعاملة، والرمز والختم للمخوّلين فقط ═══
alter table public.application_events add column if not exists actor_title text;
create table if not exists public.event_signatures (
  event_id bigint primary key references public.application_events(id) on delete cascade,
  application_id uuid not null, actor_id uuid, actor_code text, actor_title text, seal text not null, signed_at timestamptz default now()
);
alter table public.event_signatures enable row level security;
drop policy if exists read_signatures on public.event_signatures;
create policy read_signatures on public.event_signatures for select to authenticated using (
  actor_id = auth.uid()
  or my_portal() in ('cbi','integrity')
  or (my_portal() = 'bank' and my_role() in ('bank_md','bank_risk','bank_branch_mgr','bank_initiatives_mgr','bank_committee')
      and exists (select 1 from applications a where a.id = application_id and a.bank_id = my_org())));

create or replace function public._sign_event() returns trigger language plpgsql security definer set search_path = public, extensions as $$
declare p profiles;
begin
  select * into p from profiles where id = new.actor_id;
  if new.actor_title is null then new.actor_title := _role_title(coalesce(p.role, new.actor_role)) || coalesce(' — ' || (select name from branches where id = p.branch_id), ''); end if;
  return new;
end $$;
create or replace function public._seal_event() returns trigger language plpgsql security definer set search_path = public, extensions as $$
declare c text;
begin
  select staff_code into c from profiles where id = new.actor_id;
  insert into event_signatures(event_id, application_id, actor_id, actor_code, actor_title, seal, signed_at)
  values (new.id, new.application_id, new.actor_id, c, new.actor_title,
    upper(substr(encode(extensions.digest(coalesce(c, 'CITIZEN') || '|' || new.hash, 'sha256'), 'hex'), 1, 16)), new.created_at)
  on conflict (event_id) do nothing;
  return new;
end $$;
drop trigger if exists trg_a_title on public.application_events;
create trigger trg_a_title before insert on public.application_events for each row execute function public._sign_event();
drop trigger if exists trg_seal on public.application_events;
create trigger trg_seal after insert on public.application_events for each row execute function public._seal_event();
update public.application_events e set actor_title = _role_title(coalesce(p.role, e.actor_role)) || coalesce(' — ' || (select name from branches where id = p.branch_id), '')
from (select id, role, branch_id from profiles) p where p.id = e.actor_id and e.actor_title is null;
update public.application_events set actor_title = _role_title(actor_role) where actor_title is null;
insert into public.event_signatures(event_id, application_id, actor_id, actor_code, actor_title, seal, signed_at)
select e.id, e.application_id, e.actor_id, p.staff_code, e.actor_title,
  upper(substr(encode(extensions.digest(coalesce(p.staff_code, 'CITIZEN') || '|' || coalesce(e.hash, ''), 'sha256'), 'hex'), 1, 16)), e.created_at
from application_events e left join profiles p on p.id = e.actor_id on conflict (event_id) do nothing;
do $$ begin alter publication supabase_realtime add table public.event_signatures; exception when duplicate_object then null; end $$;

-- ═══ 3) المستندات: صور من الكاميرا تُحفظ مع الطلب ببصمتها ═══
create table if not exists public.app_documents (
  id uuid primary key default gen_random_uuid(), application_id uuid not null references public.applications(id) on delete cascade,
  referral_id uuid references public.mortgage_referrals(id) on delete set null,
  kind text not null check (kind in ('deed','owner_id_front','owner_id_back','evidence','other')),
  source text not null check (source in ('camera','file','demo')), mime text, data text not null, bytes int, sha256 text,
  meta jsonb default '{}'::jsonb, uploaded_by uuid, uploaded_by_title text, created_at timestamptz default now()
);
create index if not exists app_documents_app on public.app_documents(application_id);
alter table public.app_documents enable row level security;
drop policy if exists read_docs on public.app_documents;
create policy read_docs on public.app_documents for select to authenticated using (
  exists (select 1 from applications a where a.id = application_id)
  and (kind <> 'evidence' or my_portal() in ('bank','registry','cbi','integrity')));

create or replace function public.add_document(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb, p_referral uuid default null)
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare me profiles; a applications; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  if me.portal = 'citizen' then
    if a.citizen_id <> me.id then raise exception 'الطلب لا يخصك'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
    if p_kind not in ('deed','owner_id_front','owner_id_back') then raise exception 'نوع مستند غير مسموح'; end if;
    if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
      raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
    delete from app_documents where application_id = a.id and kind = p_kind;
  elsif me.portal = 'registry' then
    if p_kind <> 'evidence' or p_referral is null or not exists (select 1 from mortgage_referrals where id = p_referral and application_id = a.id) then raise exception 'المرفق دليل على إحالة رهن فقط'; end if;
  elsif me.portal = 'bank' then
    if a.bank_id <> me.org_id or p_kind not in ('evidence','other') then raise exception 'غير مخوّل'; end if;
  else raise exception 'غير مخوّل'; end if;
  insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_referral, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()), me.id, _role_title(me.role))
  returning id into did;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || case p_kind when 'deed' then 'صورة سند العقار' when 'owner_id_front' then 'هوية مالك العقار (الوجه)'
    when 'owner_id_back' then 'هوية مالك العقار (الظهر)' when 'evidence' then 'دليل قرار التسجيل العقاري' else 'مستند' end,
    case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $$;

-- ═══ 4) إقرار ملكية العقار ومطابقته مع المقترض أو المالك والسجل العقاري ═══
alter table public.applications add column if not exists ownership jsonb;

create or replace function public._name_norm(t text) returns text language sql immutable as $$
  select array_to_string((string_to_array(regexp_replace(translate(regexp_replace(coalesce(t, ''), '[ًٌٍَُِّْـ]', '', 'g'), 'أإآىة', 'ااايه'), '\s+', ' ', 'g'), ' '))[1:3], ' ')
$$;

create or replace function public.set_property_ownership(p_app uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; pr properties; own jsonb; is_owner boolean := coalesce((p_data->>'is_owner')::boolean, true);
  dn text := trim(coalesce(p_data->>'deed_no', '')); onm text; onid text; oph text; m text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.guarantee_type <> 'mortgage' or a.stage <> 4 then raise exception 'إقرار الملكية في مرحلة ضمان الرهن فقط'; end if;
  if dn = '' then raise exception 'اكتب رقم السند كما في الصورة'; end if;
  if not exists (select 1 from app_documents where application_id = a.id and kind = 'deed' and source = 'camera') then
    raise exception 'صوّر سند العقار بكاميرا الهاتف أولاً'; end if;
  select * into pr from properties where deed_no = dn;
  if is_owner then
    onm := me.full_name; onid := me.national_id;
  else
    onm := regexp_replace(trim(coalesce(p_data->>'owner_name', '')), '\s+', ' ', 'g'); onid := coalesce(p_data->>'owner_national_id', '');
    oph := _norm_phone(p_data->>'owner_phone');
    if array_length(string_to_array(onm, ' '), 1) < 3 then raise exception 'اكتب اسم مالك العقار الثلاثي كما في السند'; end if;
    if onid !~ '^[0-9]{12}$' then raise exception 'الرقم الوطني لمالك العقار 12 رقماً'; end if;
    if onid = me.national_id or oph = me.phone then raise exception 'بيانات المالك هي بياناتك — اختر «أنا مالك العقار»'; end if;
    if not exists (select 1 from app_documents where application_id = a.id and kind = 'owner_id_front' and source = 'camera') then
      raise exception 'صوّر البطاقة الوطنية لمالك العقار بالكاميرا'; end if;
    if not _otp_ok(p_data->>'owner_otp') then raise exception 'لم يوافق مالك العقار على رهنه برمز التحقق'; end if;
  end if;
  -- المطابقة مع السجل العقاري إن كان السند مسجلاً
  if pr.id is not null then
    if pr.owner_national_id is not null and pr.owner_national_id <> onid then
      raise exception '%', case when is_owner then 'السند مسجل في السجل العقاري باسم شخص آخر — اختر «لست مالك العقار» وأضف بيانات المالك وموافقته'
        else 'بيانات المالك لا تطابق المسجل في السجل العقاري لهذا السند' end; end if;
    if _name_norm(pr.owner_name) <> _name_norm(onm) then
      raise exception 'اسم المالك لا يطابق المسجل في السجل العقاري (%)', pr.owner_name; end if;
    m := 'matched';
  else
    m := 'pending_registry';   -- سند غير مسجل في المنصة: تطابقه دائرة التسجيل العقاري مع الصورة
  end if;
  own := jsonb_build_object('is_owner', is_owner, 'deed_no', dn, 'owner_name', onm, 'owner_national_id', onid, 'owner_phone', oph,
    'relation', p_data->>'relation', 'match', m, 'owner_consent_at', case when not is_owner then now() end, 'declared_at', now());
  update applications set ownership = own where id = a.id;
  perform _ev(a.id, 4, case when is_owner then 'إقرار ملكية العقار: المقترض هو المالك' else 'إقرار ملكية العقار: المالك شخص آخر وافق على الرهن' end,
    'سند ' || dn || ' · ' || case m when 'matched' then 'مطابق للسجل العقاري' else 'بانتظار مطابقة التسجيل العقاري' end);
  return own;
end $$;

-- ═══ 5) الدفع الإلكتروني قبل إرسال الطلب: رسم دراسة الملف للمصرف + أجور الكشف + عمولة المنصة ═══
insert into public.settings(key, value, label, circular_no) values
 ('inspection_fee', 100000, 'أجور الكشف الموقعي — تُدفع قبل إرسال الطلب (دينار)', 'سياسة التمويل: ثالثاً-هـ'),
 ('platform_fee', 25000, 'عمولة المنصة على الطلب (دينار)', 'المنصة')
on conflict (key) do nothing;

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(), application_id uuid not null references public.applications(id) on delete cascade,
  bank_id uuid references public.orgs(id), method text not null check (method in ('zaincash','visa','mastercard')),
  items jsonb not null, amount bigint not null, status text not null default 'paid' check (status in ('paid','refunded')),
  ref text unique, paid_by uuid, paid_at timestamptz default now()
);
alter table public.payments enable row level security;
drop policy if exists read_payments on public.payments;
create policy read_payments on public.payments for select to authenticated using (exists (select 1 from applications a where a.id = application_id) and my_portal() in ('citizen','bank','cbi','integrity'));

create or replace function public.fee_quote(p_bank uuid) returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_array(
    jsonb_build_object('key', 'bank_fee', 'label', 'رسم دراسة الملف — ' || (select name from orgs where id = p_bank), 'amount', coalesce((select file_fee from bank_terms where bank_id = p_bank), 0)),
    jsonb_build_object('key', 'inspection_fee', 'label', 'أجور الكشف الموقعي', 'amount', coalesce(_setting('inspection_fee'), 0)::bigint),
    jsonb_build_object('key', 'platform_fee', 'label', 'عمولة المنصة', 'amount', coalesce(_setting('platform_fee'), 0)::bigint))
$$;

create or replace function public.pay_application_fees(p_app uuid, p_bank uuid, p_method text, p_otp text) returns public.payments
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; pay payments; it jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.stage <> 5 or a.status not in ('active','returned') then raise exception 'الدفع عند اختيار المصرف وقبل إرسال الطلب'; end if;
  if not exists (select 1 from bank_terms where bank_id = p_bank) then raise exception 'اختر مصرفاً'; end if;
  if p_method not in ('zaincash','visa','mastercard') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  select * into pay from payments where application_id = a.id and bank_id = p_bank and status = 'paid';
  if pay.id is not null then return pay; end if;
  it := fee_quote(p_bank);
  insert into payments(application_id, bank_id, method, items, amount, ref, paid_by)
  values (a.id, p_bank, p_method, it, (select sum((x->>'amount')::bigint) from jsonb_array_elements(it) x),
    'PAY-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)), me.id)
  returning * into pay;
  perform _ev(a.id, 5, 'دفع رسوم الملف وأجور الكشف وعمولة المنصة إلكترونياً',
    to_char(pay.amount, 'FM999,999,999') || ' د.ع · ' || case p_method when 'zaincash' then 'زين كاش' when 'visa' then 'Visa' else 'Mastercard' end || ' · ' || pay.ref);
  return pay;
end $$;

-- ═══ 6) حراسة الانتقالات: لا يُرسل الطلب قبل الدفع، ولا يُقبل ضمان الرهن دون صورة السند وإقرار الملكية ═══
create or replace function public._guard_transition() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.stage = old.stage then return new; end if;
  if old.stage <= 4 and new.stage >= 5 and new.guarantee_type = 'mortgage' then
    if new.ownership is null then raise exception 'أجب عن سؤال ملكية العقار وصوّر السند قبل تأكيد الضمان'; end if;
    if not exists (select 1 from app_documents where application_id = new.id and kind = 'deed') then raise exception 'صوّر سند العقار بكاميرا الهاتف'; end if;
    if coalesce(new.guarantee->>'deed_no', new.ownership->>'deed_no') <> new.ownership->>'deed_no' then raise exception 'رقم السند لا يطابق السند المصوَّر وإقرار الملكية'; end if;
    -- العقار الجديد الذي أنشأه المواطن: يُسجَّل باسم المالك المُقر به لا باسم المقترض
    if (new.ownership->>'is_owner')::boolean is false then
      update properties set owner_name = new.ownership->>'owner_name', owner_national_id = new.ownership->>'owner_national_id'
      where id = new.property_id and owner_national_id is not distinct from (select national_id from profiles where id = new.citizen_id);
    end if;
  end if;
  if old.stage <= 5 and new.stage >= 6 and not exists (select 1 from payments where application_id = new.id and bank_id = new.bank_id and status = 'paid') then
    raise exception 'ادفع رسوم الملف وأجور الكشف وعمولة المنصة للمصرف المختار قبل إرسال الطلب';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_transition on public.applications;
create trigger trg_guard_transition before update of stage on public.applications for each row execute function public._guard_transition();

-- ═══ 7) قرارات التسجيل العقاري: رفض مسبب بقائمة أسباب ودليل مرفق، ومنصب متخذ القرار ═══
create table if not exists public.rejection_reasons (code text primary key, label text not null, ctx text not null default 'registry', sort int default 0);
insert into public.rejection_reasons(code, label, sort) values
 ('already_mortgaged','العقار مرهون لجهة أخرى',1),
 ('sale_statement','مفتوح بيان لبيع العقار',2),
 ('owner_mismatch','العقار مسجل باسم شخص آخر غير المُقر بملكيته',3),
 ('seizure','عليه حجز أو إشارة منع تصرف بقرار قضائي أو إداري',4),
 ('dispute','عليه دعوى أو نزاع قائم على الملكية',5),
 ('shared_no_consent','عقار مشاع ولم يوافق بقية الشركاء',6),
 ('deed_mismatch','بيانات السند المصوَّر لا تطابق السجل',7),
 ('deed_invalid','السند غير موجود في السجل أو يُشتبه بصحته',8),
 ('inheritance','تركة غير مقسومة أو حصر إرث غير مكتمل',9),
 ('state_waqf','عقار حكومي أو وقفي لا يقبل الرهن',10),
 ('agri_lease','أرض زراعية بعقد إيجار أو تخصيص لا يجوز رهنها',11),
 ('unpaid_dues','ضرائب أو رسوم عقارية غير مسددة',12),
 ('other','سبب آخر (يُكتب تفصيلاً)',99)
on conflict (code) do update set label = excluded.label, sort = excluded.sort;
alter table public.rejection_reasons enable row level security;
drop policy if exists read_reasons on public.rejection_reasons;
create policy read_reasons on public.rejection_reasons for select to authenticated using (true);

alter table public.mortgage_referrals
  add column if not exists reject_reason text references public.rejection_reasons(code),
  add column if not exists evidence_doc uuid references public.app_documents(id),
  add column if not exists decided_by_title text, add column if not exists decided_at timestamptz;

drop function if exists public.registry_action(uuid, text, text);
create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null, p_reason text default null, p_evidence uuid default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare me profiles; r mortgage_referrals; p properties; act text; newst text; ast int; own jsonb; rr rejection_reasons;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  select stage, ownership into ast, own from applications where id = r.application_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك (الإجراء الأولي)';
  elsif p_action='annotate' then
    if r.status <> 'matched' then raise exception 'التأشير بعد المطابقة'; end if;
    if ast < 19 then raise exception 'التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)'; end if;
    newst:='annotated'; act:='تأشير الرهن على السند (الإجراء النهائي)';
    update properties set status='mortgaged' where id=p.id;
    update mortgage_referrals set annotation_no = 'ره-' || to_char(now(),'YYYY') || '-' || lpad((floor(random()*99999))::text,5,'0') where id=r.id;
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then
    if r.status not in ('pending','clear','matched','encumbered') then raise exception 'لا يُرفض إلا إحالة قيد الإجراء'; end if;
    select * into rr from rejection_reasons where code = p_reason;
    if rr is null then raise exception 'اختر سبب الرفض من القائمة'; end if;
    if p_reason = 'other' and length(trim(coalesce(p_note, ''))) < 10 then raise exception 'اكتب تفصيل السبب'; end if;
    if p_evidence is null or not exists (select 1 from app_documents where id = p_evidence and referral_id = r.id and kind = 'evidence') then
      raise exception 'أرفق ما يثبت سبب الرفض (صورة أو ملف من السجل)'; end if;
    newst:='rejected'; act:='رفض تأشير الرهن: ' || rr.label;
    update mortgage_referrals set reject_reason = rr.code, evidence_doc = p_evidence where id = r.id;
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now(), decided_at = now(),
    decided_by_title = _role_title(me.role) where id=r.id returning * into r;
  perform _ev(r.application_id, ast, act, p_note);
  return r;
end $$;

-- لدائرة التسجيل: ترى صورة السند وإقرار الملكية للإحالات الواردة إليها فقط
create or replace function public.referral_dossier(p_ref uuid) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare me profiles; r mortgage_referrals; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from mortgage_referrals where id = p_ref;
  if r is null then raise exception 'غير موجودة'; end if;
  select * into a from applications where id = r.application_id;
  if not (me.portal in ('registry','cbi','integrity') or (me.portal = 'bank' and me.org_id = a.bank_id)) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('ownership', a.ownership, 'borrower', a.citizen_name,
    'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'source', d.source, 'data', d.data, 'mime', d.mime, 'sha256', d.sha256,
      'created_at', d.created_at, 'by', d.uploaded_by_title) order by d.created_at), '[]') from app_documents d where d.application_id = a.id and d.kind in ('deed','owner_id_front','owner_id_back','evidence')),
    'reason', (select label from rejection_reasons where code = r.reject_reason));
end $$;

-- ═══ 8) بيانات العرض: الدفع للطلبات المرسلة، وسند وإقرار ملكية للطلبات برهن ═══
alter table public.applications disable trigger trg_guard_transition;
insert into public.payments(application_id, bank_id, method, items, amount, ref, paid_by, paid_at)
select a.id, a.bank_id, (array['zaincash','visa','mastercard'])[1 + (abs(hashtext(a.code)) % 3)], fee_quote(a.bank_id),
  (select sum((x->>'amount')::bigint) from jsonb_array_elements(fee_quote(a.bank_id)) x),
  'PAY-' || to_char(coalesce(l.finished_at, a.created_at), 'YYMMDD') || '-' || upper(substr(md5(a.code), 1, 6)), a.citizen_id, coalesce(l.finished_at, a.created_at)
from applications a left join stage_log l on l.application_id = a.id and l.stage = 5
where a.bank_id is not null and a.stage >= 6 and not exists (select 1 from payments p where p.application_id = a.id);

update public.applications a set ownership = jsonb_build_object('is_owner', true, 'deed_no', pr.deed_no, 'owner_name', pr.owner_name,
  'owner_national_id', pr.owner_national_id, 'match', 'matched', 'declared_at', a.created_at)
from properties pr where pr.id = a.property_id and a.guarantee_type = 'mortgage' and a.ownership is null;
insert into public.app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by_title, created_at)
select a.id, 'deed', 'demo', 'image/svg+xml',
  'data:image/svg+xml;utf8,' || replace(replace(format('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 300"><rect width="420" height="300" fill="#f7f1e3"/><rect x="10" y="10" width="400" height="280" fill="none" stroke="#8a6d3b" stroke-width="3"/><text x="210" y="55" font-size="22" text-anchor="middle" font-family="sans-serif" fill="#5a4320">سند عقاري — نموذج عرض</text><text x="390" y="110" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">رقم السند: %s</text><text x="390" y="145" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">المالك: %s</text><text x="390" y="180" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">الموقع: %s — %s</text><text x="210" y="260" font-size="12" text-anchor="middle" font-family="sans-serif" fill="#999">بيانات وهمية للعرض</text></svg>',
    pr.deed_no, pr.owner_name, pr.governorate, pr.district), '#', '%23'), '"', '''') ,
  0, null, jsonb_build_object('demo', true), 'المقترض', a.created_at
from applications a join properties pr on pr.id = a.property_id
where a.guarantee_type = 'mortgage' and not exists (select 1 from app_documents d where d.application_id = a.id and d.kind = 'deed');
alter table public.applications enable trigger trg_guard_transition;

revoke all on function public._staff_prefix(uuid), public._assign_staff_code(), public._sign_event(), public._seal_event(), public._guard_transition() from public, anon, authenticated;
grant execute on function public.add_document, public.set_property_ownership, public.fee_quote, public.pay_application_fees,
  public.registry_action(uuid, text, text, text, uuid), public.referral_dossier to authenticated;
