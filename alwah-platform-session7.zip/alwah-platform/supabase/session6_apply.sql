-- ألواح — الجلسة 6: مبادرة تمويل مشاريع الأطباء البيطريين
-- يُطبَّق تلقائياً من server.js عند فتح /migrate (سطر الجلسة 6 في MIGRATIONS).
-- الجهات الجديدة: نقابة الأطباء البيطريين (تؤيد العضوية وسريان إجازة الممارسة فقط — لا تقرر الإقراض)
--                 دائرة البيطرة / وزارة الزراعة (الموافقة المبدئية على المشروع وموقعه قبل التقديم للمصرف، ثم إجازة النشاط بعد التشغيل)
--                 موردو الأجهزة البيطرية والمختبرية (عرض السعر، التوريد، التركيب، التشغيل)
-- مسار الطبيب: الهوية ← العضوية وتأييد النقابة ← المشروع والمصرف (موافقة دائرة البيطرة) ← الضمان ← الدفع والتوقيع
-- بعدها يسير الطلب في مراحل المصرف نفسها (6–37)، والصرف للمورد على ثلاث دفعات: توريد ← تركيب ← تشغيل وإجازة.
-- كل الأرقام إعدادات مبدئية يعدّلها البنك المركزي من لوحته حين يصدر التعميم.
-- يُصلح أيضاً خللين قائمين: طرق الدفع العراقية (كي كارد، FIB…) ووكالة مالك العقار كانت ترفضها قيود الجداول.

begin;

-- ═══ 0) إصلاح القيود القائمة ═══
alter table public.payments drop constraint if exists payments_method_check;
alter table public.payments add constraint payments_method_check check (method in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other'));
alter table public.app_documents drop constraint if exists app_documents_kind_check;
alter table public.app_documents add constraint app_documents_kind_check check (kind in ('deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site'));

-- ═══ 1) الجهات والبوابات الجديدة ═══
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type in ('bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept'));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal in ('citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept'));

insert into public.orgs(code, type, name, meta) values
  ('vsi', 'syndicate', 'نقابة الأطباء البيطريين', '{"short":"النقابة"}'),
  ('vetdept', 'vetdept', 'دائرة البيطرة — وزارة الزراعة', '{"short":"دائرة البيطرة"}'),
  ('sup4', 'supplier', 'الرافدين للتجهيزات المختبرية والبيطرية', '{"kind":"vet","legacy":false,"avg_days":12,"installs":38,"match_rate":96}'),
  ('sup5', 'supplier', 'آشور لخطوط إنتاج الأدوية البيطرية', '{"kind":"vet","legacy":true,"avg_days":30,"installs":11,"match_rate":98}')
on conflict (code) do nothing;

create or replace function public._role_abbr(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD' else 'XX' end $$;
create or replace function public._role_title(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات' else r end $$;

-- ═══ 2) إعدادات المبادرة (مبدئية — يعدّلها البنك المركزي) ═══
insert into public.settings(key, value, label, circular_no) values
  ('vet_initiative_total', 1000000000000, 'المبلغ المخصص لمشاريع أعضاء نقابة الأطباء البيطريين (دينار)', 'مبادرة التعليم والطب البيطري — قيمة مبدئية'),
  ('vet_rate', 3, 'الفائدة السنوية لمشاريع الطب البيطري % (حد أعلى)', 'مبادرة التعليم والطب البيطري'),
  ('vet_term_max_months', 120, 'أقصى مدة سداد لمشاريع الطب البيطري شاملة السماح (شهر)', 'مبادرة التعليم والطب البيطري'),
  ('vet_grace_max_months', 24, 'أقصى مدة سماح لمشاريع الطب البيطري (شهر)', 'مبادرة التعليم والطب البيطري'),
  ('vet_min_contribution_pct', 10, 'أدنى مساهمة للطبيب من كلفة المشروع % — مبدئي', 'بانتظار التعميم'),
  ('vet_guarantee_t1', 10000000, 'مشاريع بيطرية: حتى هذا المبلغ كفيل موظف واحد — مبدئي', 'بانتظار التعميم'),
  ('vet_guarantee_t2', 50000000, 'مشاريع بيطرية: حتى هذا المبلغ كفيلان، وفوقه رهن عقار — مبدئي', 'بانتظار التعميم'),
  ('vet_cap_lab', 150000000, 'سقف قرض المختبر البيطري (دينار) — مبدئي', 'بانتظار التعميم'),
  ('vet_cap_clinic', 100000000, 'سقف قرض العيادة البيطرية (دينار) — مبدئي', 'بانتظار التعميم'),
  ('vet_cap_hospital', 750000000, 'سقف قرض المستشفى البيطري (دينار) — مبدئي', 'بانتظار التعميم'),
  ('vet_cap_pharma', 1500000000, 'سقف قرض معمل الأدوية واللقاحات البيطرية (دينار) — مبدئي', 'بانتظار التعميم'),
  ('vet_cap_supplies', 1000000000, 'سقف قرض معمل المستلزمات البيطرية (دينار) — مبدئي', 'بانتظار التعميم'),
  ('vet_tranche1_pct', 40, 'الدفعة الأولى للمورد عند توريد الأجهزة %', 'المنصة'),
  ('vet_tranche2_pct', 40, 'الدفعة الثانية للمورد عند التركيب % (والباقي عند التشغيل وإجازة دائرة البيطرة)', 'المنصة')
on conflict (key) do nothing;

create table if not exists public.vet_project_types (
  code text primary key, label text not null, hint text, cap_key text not null, factory boolean not null default false, sort int default 0);
insert into public.vet_project_types(code, label, hint, cap_key, factory, sort) values
  ('lab', 'مختبر بيطري', 'شراء وتجهيز مختبر تحليلات وتشخيص بيطري', 'vet_cap_lab', false, 1),
  ('clinic', 'عيادة بيطرية', 'تجهيز عيادة بيطرية بالأجهزة والمعدات', 'vet_cap_clinic', false, 2),
  ('hospital', 'مستشفى بيطري', 'إنشاء أو تجهيز مستشفى بيطري', 'vet_cap_hospital', false, 3),
  ('pharma', 'معمل أدوية ولقاحات بيطرية', 'خط إنتاج علاجات أو لقاحات بيطرية', 'vet_cap_pharma', true, 4),
  ('supplies', 'معمل مستلزمات بيطرية', 'تصنيع المستلزمات والأدوات البيطرية', 'vet_cap_supplies', true, 5)
on conflict (code) do nothing;

-- ═══ 3) الجداول ═══
alter table public.applications add column if not exists program text not null default 'solar';
alter table public.applications drop constraint if exists applications_program_check;
alter table public.applications add constraint applications_program_check check (program in ('solar','vet'));

-- عضوية الطبيب في النقابة: واحدة لكل حساب، وتُجدَّد كل سنة مع إجازة الممارسة (تجدَّد في كانون الثاني)
create table if not exists public.vet_memberships (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles(id) on delete cascade,
  full_name text not null, national_id text,
  membership_no text, syndicate_branch text, license_no text, license_year int, graduation_year int, college text, specialty text,
  status text not null default 'draft' check (status in ('draft','pending','endorsed','returned','rejected')),
  note text, letter_no text unique, valid_until date, decided_by_title text, decided_at timestamptz,
  submitted_at timestamptz, created_at timestamptz default now(), updated_at timestamptz default now());

create table if not exists public.vet_member_docs (
  id uuid primary key default gen_random_uuid(),
  membership_id uuid not null references public.vet_memberships(id) on delete cascade,
  kind text not null check (kind in ('union_id','license','degree')),
  mime text not null, data text not null, bytes int, sha256 text, meta jsonb default '{}'::jsonb, created_at timestamptz default now(),
  unique (membership_id, kind));

-- دراسة المشروع البيطري: طلب واحد ← مشروع واحد
create table if not exists public.vet_projects (
  application_id uuid primary key references public.applications(id) on delete cascade,
  project_type text not null references public.vet_project_types(code),
  title text, site_governorate text, site_city text, site_address text,
  site_ownership text check (site_ownership in ('owned','rented')), site_area numeric,
  items jsonb not null default '[]'::jsonb, equipment_cost bigint default 0, other_cost bigint default 0, total_cost bigint default 0,
  contribution bigint default 0, revenue_monthly bigint, staff_count int, capacity text, products text, quote_no text,
  vetdept_status text not null default 'draft' check (vetdept_status in ('draft','pending','approved','returned','rejected')),
  vetdept_note text, vetdept_ref text unique, vetdept_by_title text, vetdept_at timestamptz,
  milestones jsonb not null default '{}'::jsonb,
  license_no text unique, license_by_title text, license_at timestamptz,
  created_at timestamptz default now(), updated_at timestamptz default now());

-- دفعات الصرف للمورد
create table if not exists public.vet_tranches (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  n int not null check (n between 1 and 3), label text not null, pct numeric not null, amount bigint not null,
  status text not null default 'pending' check (status in ('pending','ready','paid')),
  ready_at timestamptz, paid_at timestamptz, paid_by_title text, ref text unique,
  unique (application_id, n));

-- ═══ 4) الصلاحيات (قراءة فقط عبر السياسات، والكتابة عبر الدوال) ═══
drop policy if exists read_apps on public.applications;
create policy read_apps on public.applications for select to authenticated using (
  citizen_id = auth.uid()
  or (my_portal() = 'bank' and bank_id = my_org() and ((select p.branch_id from profiles p where p.id = auth.uid()) is null or branch_id = (select p.branch_id from profiles p where p.id = auth.uid())))
  or (my_portal() = 'supplier' and supplier_id = my_org() and stage >= 30)
  or (my_portal() = 'registry' and exists (select 1 from mortgage_referrals m where m.application_id = applications.id))
  or (my_portal() = 'vetdept' and program = 'vet')
  or my_portal() in ('cbi','integrity'));

alter table public.vet_project_types enable row level security;
drop policy if exists read_vet_types on public.vet_project_types;
create policy read_vet_types on public.vet_project_types for select to authenticated using (true);

alter table public.vet_memberships enable row level security;
drop policy if exists read_vet_members on public.vet_memberships;
create policy read_vet_members on public.vet_memberships for select to authenticated using (
  profile_id = auth.uid() or my_portal() in ('syndicate','cbi','integrity')
  or exists (select 1 from applications a where a.citizen_id = vet_memberships.profile_id and a.program = 'vet'));

alter table public.vet_member_docs enable row level security;
drop policy if exists read_vet_member_docs on public.vet_member_docs;
create policy read_vet_member_docs on public.vet_member_docs for select to authenticated using (
  exists (select 1 from vet_memberships m where m.id = vet_member_docs.membership_id));

alter table public.vet_projects enable row level security;
drop policy if exists read_vet_projects on public.vet_projects;
create policy read_vet_projects on public.vet_projects for select to authenticated using (
  exists (select 1 from applications a where a.id = vet_projects.application_id));

alter table public.vet_tranches enable row level security;
drop policy if exists read_vet_tranches on public.vet_tranches;
create policy read_vet_tranches on public.vet_tranches for select to authenticated using (
  exists (select 1 from applications a where a.id = vet_tranches.application_id));

do $$ begin
  begin alter publication supabase_realtime add table public.vet_memberships; exception when others then null; end;
  begin alter publication supabase_realtime add table public.vet_projects; exception when others then null; end;
  begin alter publication supabase_realtime add table public.vet_tranches; exception when others then null; end;
end $$;

-- ═══ 5) دوال مساعدة ═══
create or replace function public._vet_seq(p_prefix text, p_tbl text, p_col text) returns text language plpgsql security definer set search_path = public as $$
declare n int;
begin
  execute format('select coalesce(max(substring(%I from ''[0-9]+$'')::int), 0) + 1 from %I where %I like $1', p_col, p_tbl, p_col)
    into n using p_prefix || '-' || to_char(now(), 'YYYY') || '-%';
  return p_prefix || '-' || to_char(now(), 'YYYY') || '-' || lpad(n::text, 5, '0');
end $$;

-- نوع الضمان حسب مبلغ القرض البيطري
create or replace function public._vet_guarantee(p_amount bigint) returns text language sql stable security definer set search_path = public as $$
  select case when p_amount <= _setting('vet_guarantee_t1') then 'single_salary' when p_amount <= _setting('vet_guarantee_t2') then 'multi_salary' else 'mortgage' end $$;

-- القسط بعد مدة السماح: يُقسَّط المبلغ على (المدة − السماح) بفائدة المبادرة
create or replace function public._vet_installment(p_amount bigint, p_term int, p_grace int) returns bigint language sql stable security definer set search_path = public as $$
  select _installment(p_amount, _setting('vet_rate'), greatest(p_term - coalesce(p_grace, 0), 1)) $$;

-- صورة ملتقطة بالكاميرا: JPEG حي فقط
create or replace function public._camera_jpeg(p_data text, p_source text, p_meta jsonb) returns text language plpgsql immutable as $$
declare mime text := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
begin
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة فقط'; end if;
  if length(p_data) > 4000000 then raise exception 'حجم الصورة كبير — الحد 3 ميغابايت'; end if;
  if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
    raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
  return mime;
end $$;

-- ═══ 6) بدء طلب تمويل بيطري ═══
create or replace function public.start_vet_application(p_type text, p_governorate text, p_city text default null, p_lat numeric default null, p_lng numeric default null)
returns public.applications language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; t vet_project_types; v_code text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'citizen' then raise exception 'التقديم من بوابة المواطن فقط'; end if;
  if exists (select 1 from applications where citizen_id = me.id and status in ('active','returned')) then
    raise exception 'لديك طلب قائم — تابعه من «طلبي» أو ألغِه قبل تقديم طلب جديد'; end if;
  select * into t from vet_project_types where code = p_type;
  if t is null then raise exception 'اختر نوع المشروع البيطري'; end if;
  if coalesce(p_governorate, '') = '' then raise exception 'اختر محافظة موقع المشروع'; end if;
  v_code := _vet_seq('VET', 'applications', 'code');
  insert into applications(code, citizen_id, citizen_name, program, governorate, city, lat, lng, stage, status, bank_unit, term_months, grace_months)
  values (v_code, me.id, me.full_name, 'vet', p_governorate, coalesce(nullif(trim(p_city), ''), p_governorate), p_lat, p_lng, 1, 'active', 'المواطن', 120, 0)
  returning * into a;
  insert into vet_projects(application_id, project_type, site_governorate, site_city) values (a.id, t.code, p_governorate, nullif(trim(p_city), ''));
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, 1, 'بدء طلب تمويل مشروع بيطري — مبادرة أعضاء نقابة الأطباء البيطريين', t.label, me.id, me.full_name, me.role);
  return a;
end $$;

-- ═══ 7) مستندات العضوية (هوية النقابة، إجازة الممارسة، شهادة التخرج) بالكاميرا ═══
create or replace function public.vet_member_doc(p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $$
declare me profiles; m vet_memberships; mime text; did uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'citizen' then raise exception 'غير مخوّل'; end if;
  if p_kind not in ('union_id','license','degree') then raise exception 'نوع مستند غير مسموح'; end if;
  mime := _camera_jpeg(p_data, p_source, p_meta);
  select * into m from vet_memberships where profile_id = me.id;
  if m is null then
    insert into vet_memberships(profile_id, full_name, national_id) values (me.id, me.full_name, me.national_id) returning * into m;
  elsif m.status = 'pending' then raise exception 'عضويتك لدى النقابة للتأييد الآن — انتظر قرارها';
  end if;
  insert into vet_member_docs(membership_id, kind, mime, data, bytes, sha256, meta)
  values (m.id, p_kind, mime, p_data, length(p_data), encode(extensions.digest(p_data, 'sha256'), 'hex'), coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()))
  on conflict (membership_id, kind) do update set data = excluded.data, mime = excluded.mime, bytes = excluded.bytes, sha256 = excluded.sha256, meta = excluded.meta, created_at = now()
  returning id into did;
  -- تغيير مستند بعد التأييد يعيد العضوية للتأييد
  update vet_memberships set status = case when status in ('endorsed','returned','rejected') then 'draft' else status end, updated_at = now() where id = m.id;
  return did;
end $$;

-- ═══ 8) خطوات الطبيب البيطري (2–5) ═══
create or replace function public._vet_step(p_app uuid, p_step int, p_data jsonb) returns public.applications
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; vp vet_projects; t vet_project_types; m vet_memberships; bt bank_terms; pr properties;
  v_act text; v_note text; new_stage int; gt text; it jsonb; g jsonb; arr jsonb := '[]'::jsonb; phones text[] := '{}'; ph text;
  v_items jsonb := '[]'::jsonb; v_equip bigint := 0; v_other bigint; v_total bigint; v_contrib bigint; v_amount bigint; v_cap bigint;
  v_term int; v_grace int; v_sup orgs; inst bigint; need bigint; total bigint := 0; v_n int; v_val bigint; v_year int := extract(year from now())::int;
  changed boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  select * into vp from vet_projects where application_id = a.id for update;
  new_stage := greatest(a.stage, p_step + 1);

  if p_step = 2 then
    -- العضوية: تُرسل للنقابة للتأييد. يتابع الطبيب الخطوات أثناء انتظار التأييد، ولا يُرسل الطلب للمصرف قبله.
    if coalesce(trim(p_data->>'membership_no'), '') !~ '^[0-9A-Za-z/-]{2,20}$' then raise exception 'اكتب رقم العضوية في النقابة كما في هوية النقابة'; end if;
    if coalesce(trim(p_data->>'license_no'), '') = '' then raise exception 'اكتب رقم إجازة ممارسة المهنة'; end if;
    if coalesce((p_data->>'license_year')::int, 0) <> v_year then
      raise exception 'إجازة الممارسة يجب أن تكون مجددة لسنة % (تُجدَّد في كانون الثاني من كل سنة)', v_year; end if;
    if coalesce((p_data->>'graduation_year')::int, 0) not between 1960 and v_year then raise exception 'سنة التخرج غير صحيحة'; end if;
    if coalesce(trim(p_data->>'syndicate_branch'), '') = '' then raise exception 'اختر فرع النقابة المسجل فيه'; end if;
    select * into m from vet_memberships where profile_id = me.id for update;
    if m is null then raise exception 'صوّر هوية النقابة وإجازة الممارسة وشهادة التخرج أولاً'; end if;
    if (select count(*) from vet_member_docs where membership_id = m.id) < 3 then
      raise exception 'صوّر المستندات الثلاثة: هوية النقابة، إجازة الممارسة، شهادة التخرج'; end if;
    changed := m.status <> 'endorsed' or m.membership_no is distinct from trim(p_data->>'membership_no') or m.license_no is distinct from trim(p_data->>'license_no')
      or m.license_year is distinct from (p_data->>'license_year')::int;
    if m.status = 'pending' and not changed then
      v_act := 'تأكيد بيانات العضوية'; v_note := 'بانتظار تأييد النقابة';
    else
      update vet_memberships set full_name = me.full_name, national_id = me.national_id,
        membership_no = trim(p_data->>'membership_no'), syndicate_branch = trim(p_data->>'syndicate_branch'), license_no = trim(p_data->>'license_no'),
        license_year = (p_data->>'license_year')::int, graduation_year = (p_data->>'graduation_year')::int,
        college = nullif(trim(p_data->>'college'), ''), specialty = nullif(trim(p_data->>'specialty'), ''),
        status = case when changed then 'pending' else status end, note = case when changed then null else note end,
        submitted_at = case when changed then now() else submitted_at end, updated_at = now()
      where id = m.id returning * into m;
      v_act := case when m.status = 'endorsed' then 'تأكيد العضوية المؤيدة' else 'إرسال بيانات العضوية إلى نقابة الأطباء البيطريين للتأييد' end;
      v_note := 'عضوية ' || m.membership_no || ' · إجازة ' || m.license_no || ' لسنة ' || m.license_year;
    end if;

  elsif p_step = 3 then
    -- المشروع والمصرف: يحسب النظام الكلفة والقرض ويُرسل المشروع لدائرة البيطرة للموافقة المبدئية
    select * into t from vet_project_types where code = coalesce(nullif(p_data->>'project_type', ''), vp.project_type);
    if t is null then raise exception 'اختر نوع المشروع'; end if;
    if length(trim(coalesce(p_data->>'title', ''))) < 4 then raise exception 'اكتب اسم المشروع'; end if;
    if coalesce(p_data->>'site_governorate', '') = '' then raise exception 'اختر محافظة موقع المشروع'; end if;
    if length(trim(coalesce(p_data->>'site_address', ''))) < 4 then raise exception 'اكتب عنوان موقع المشروع'; end if;
    if coalesce(p_data->>'site_ownership', '') not in ('owned','rented') then raise exception 'حدّد ملكية الموقع: ملك أم إيجار'; end if;
    for it in select * from jsonb_array_elements(coalesce(p_data->'items', '[]'::jsonb)) loop
      if length(trim(coalesce(it->>'name', ''))) < 2 then raise exception 'اكتب اسم كل جهاز أو بند'; end if;
      if coalesce((it->>'qty')::int, 0) < 1 or coalesce((it->>'price')::bigint, 0) < 1000 then raise exception 'الكمية والسعر لكل بند (%)', it->>'name'; end if;
      v_equip := v_equip + (it->>'qty')::int * (it->>'price')::bigint;
      v_items := v_items || jsonb_build_object('name', trim(it->>'name'), 'qty', (it->>'qty')::int, 'price', (it->>'price')::bigint);
    end loop;
    if jsonb_array_length(v_items) = 0 then raise exception 'أضف الأجهزة أو خط الإنتاج كما في عرض سعر المورد'; end if;
    if jsonb_array_length(v_items) > 40 then raise exception '40 بنداً كحد أقصى — اجمع البنود المتشابهة'; end if;
    v_other := greatest(coalesce(nullif(regexp_replace(coalesce(p_data->>'other_cost', ''), '[^0-9]', '', 'g'), '')::bigint, 0), 0);
    v_total := v_equip + v_other;
    v_contrib := coalesce(nullif(regexp_replace(coalesce(p_data->>'contribution', ''), '[^0-9]', '', 'g'), '')::bigint, 0);
    if v_contrib < ceil(v_total * _setting('vet_min_contribution_pct') / 100) then
      raise exception 'مساهمتك لا تقل عن % بالمئة من كلفة المشروع (% د.ع)', _setting('vet_min_contribution_pct'), to_char(ceil(v_total * _setting('vet_min_contribution_pct') / 100), 'FM999,999,999,999'); end if;
    v_amount := v_total - v_contrib;
    if v_amount < 1000000 then raise exception 'مبلغ القرض أقل من الحد الأدنى'; end if;
    if v_amount > v_equip then
      raise exception 'القرض يُصرف للمورد فقط: لا يتجاوز كلفة الأجهزة (% د.ع) — غطِّ الأعمال الأخرى من مساهمتك', to_char(v_equip, 'FM999,999,999,999'); end if;
    v_cap := _setting(t.cap_key);
    if v_amount > v_cap then raise exception 'مبلغ القرض يتجاوز سقف % (% د.ع)', t.label, to_char(v_cap, 'FM999,999,999,999'); end if;
    select * into v_sup from orgs where id = nullif(p_data->>'supplier_id', '')::uuid and type = 'supplier' and meta->>'kind' = 'vet';
    if v_sup is null then raise exception 'اختر مورد الأجهزة من الموردين المعتمدين'; end if;
    if coalesce(trim(p_data->>'quote_no'), '') = '' then raise exception 'اكتب رقم عرض سعر المورد'; end if;
    if not exists (select 1 from app_documents where application_id = a.id and kind = 'quote') then raise exception 'صوّر عرض سعر المورد بالكاميرا'; end if;
    if t.factory and length(trim(coalesce(p_data->>'products', ''))) < 3 then raise exception 'اكتب منتجات المعمل'; end if;
    if t.factory and length(trim(coalesce(p_data->>'capacity', ''))) < 2 then raise exception 'اكتب الطاقة الإنتاجية للمعمل'; end if;
    select * into bt from bank_terms where bank_id = nullif(p_data->>'bank_id', '')::uuid;
    if bt is null then raise exception 'اختر مصرفاً من القائمة'; end if;
    if exists (select 1 from orgs where id = bt.bank_id and coalesce((meta->>'accepting')::boolean, true) = false) then raise exception 'هذا المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
    v_term := coalesce((p_data->>'term_months')::int, 120);
    v_grace := coalesce((p_data->>'grace_months')::int, 0);
    if v_term < 24 or v_term > _setting('vet_term_max_months') then raise exception 'مدة السداد بين 24 و% شهراً', _setting('vet_term_max_months')::int; end if;
    if v_grace < 0 or v_grace > _setting('vet_grace_max_months') or v_grace > v_term - 12 then raise exception 'مدة السماح حتى % شهراً وضمن مدة السداد', _setting('vet_grace_max_months')::int; end if;

    changed := vp.vetdept_status not in ('approved') or vp.project_type <> t.code or vp.total_cost is distinct from v_total or vp.contribution is distinct from v_contrib
      or vp.site_address is distinct from trim(p_data->>'site_address') or vp.site_governorate is distinct from p_data->>'site_governorate' or vp.items is distinct from v_items;
    update vet_projects set project_type = t.code, title = trim(p_data->>'title'), site_governorate = p_data->>'site_governorate', site_city = nullif(trim(p_data->>'site_city'), ''),
      site_address = trim(p_data->>'site_address'), site_ownership = p_data->>'site_ownership', site_area = nullif(regexp_replace(coalesce(p_data->>'site_area', ''), '[^0-9.]', '', 'g'), '')::numeric,
      items = v_items, equipment_cost = v_equip, other_cost = v_other, total_cost = v_total, contribution = v_contrib,
      revenue_monthly = nullif(regexp_replace(coalesce(p_data->>'revenue_monthly', ''), '[^0-9]', '', 'g'), '')::bigint,
      staff_count = nullif(regexp_replace(coalesce(p_data->>'staff_count', ''), '[^0-9]', '', 'g'), '')::int,
      capacity = nullif(trim(p_data->>'capacity'), ''), products = nullif(trim(p_data->>'products'), ''), quote_no = trim(p_data->>'quote_no'),
      vetdept_status = case when changed then 'pending' else vetdept_status end, vetdept_note = case when changed then null else vetdept_note end, updated_at = now()
    where application_id = a.id returning * into vp;

    gt := _vet_guarantee(v_amount);
    if gt is distinct from a.guarantee_type then
      update applications set guarantee = null, property_id = null, ownership = null where id = a.id;
      if new_stage > 4 then new_stage := 4; end if;
    end if;
    update applications set supplier_id = v_sup.id, price = v_total, amount = v_amount, guarantee_type = gt, term_months = v_term, grace_months = v_grace,
      margin = _setting('vet_rate'), monthly_installment = _vet_installment(v_amount, v_term, v_grace), governorate = p_data->>'site_governorate',
      city = coalesce(nullif(trim(p_data->>'site_city'), ''), p_data->>'site_governorate'),
      bank_choice = jsonb_build_object('bank_id', bt.bank_id, 'term_months', v_term, 'grace_months', v_grace, 'commission_pct', bt.commission_pct, 'at', now())
    where id = a.id;
    v_act := case when changed then 'تثبيت دراسة المشروع وإرسالها إلى دائرة البيطرة للموافقة المبدئية' else 'تثبيت المشروع والمصرف' end;
    v_note := t.label || ' · الكلفة ' || to_char(v_total, 'FM999,999,999,999') || ' · القرض ' || to_char(v_amount, 'FM999,999,999,999') || ' د.ع · '
      || (select name from orgs where id = bt.bank_id) || ' · ' || v_term || ' شهراً منها ' || v_grace || ' سماح';

  elsif p_step = 4 then
    if a.amount is null then raise exception 'ثبّت دراسة المشروع أولاً'; end if;
    inst := _vet_installment(a.amount, a.term_months, a.grace_months);
    if a.guarantee_type in ('single_salary','multi_salary') then
      v_n := jsonb_array_length(coalesce(p_data->'guarantors', '[]'::jsonb));
      if a.guarantee_type = 'single_salary' and v_n < 1 then raise exception 'أضف كفيلاً واحداً موظفاً'; end if;
      if a.guarantee_type = 'multi_salary' and v_n < 2 then raise exception 'هذا المبلغ يتطلب كفيلين موظفين على الأقل'; end if;
      if v_n > 3 then raise exception 'ثلاثة كفلاء كحد أقصى'; end if;
      for g in select * from jsonb_array_elements(p_data->'guarantors') loop
        if length(trim(coalesce(g->>'name', ''))) < 6 then raise exception 'اكتب الاسم الثلاثي لكل كفيل'; end if;
        ph := _norm_phone(g->>'phone');
        if ph = me.phone then raise exception 'لا يكفل المتقدم نفسه'; end if;
        if ph = any(phones) then raise exception 'رقم هاتف مكرر بين الكفلاء'; end if;
        phones := phones || ph;
        if coalesce(g->>'employer', '') = '' then raise exception 'اكتب جهة عمل كل كفيل'; end if;
        if coalesce((g->>'salary')::bigint, 0) < 250000 then raise exception 'راتب الكفيل غير صحيح'; end if;
        if not _otp_ok(g->>'otp') then raise exception 'لم يؤكد الكفيل % موافقته برمز التحقق', g->>'name'; end if;
        total := total + (g->>'salary')::bigint;
        arr := arr || jsonb_build_object('name', trim(g->>'name'), 'phone', ph, 'employer', g->>'employer', 'salary', (g->>'salary')::bigint,
          'relation', g->>'relation', 'consent', true, 'consent_at', now());
      end loop;
      need := ceil(inst * _setting('salary_safety'));
      if total < need then raise exception 'مجموع رواتب الكفلاء (% د.ع) أقل من القسط × % = % د.ع', to_char(total, 'FM999,999,999'), _setting('salary_safety'), to_char(need, 'FM999,999,999'); end if;
      update applications set guarantee = jsonb_build_object('type', a.guarantee_type, 'guarantors', arr, 'total_salary', total, 'required', need) where id = a.id;
      v_act := 'تأكيد الضمان وموافقة الكفلاء'; v_note := v_n || ' كفيل · مجموع الرواتب ' || to_char(total, 'FM999,999,999') || ' د.ع';
    else
      if coalesce(trim(p_data->>'deed_no'), '') = '' then raise exception 'اكتب رقم السند العقاري (رقم القطعة/المقاطعة)'; end if;
      select * into pr from properties where deed_no = trim(p_data->>'deed_no');
      if pr is null then
        v_val := coalesce(nullif(regexp_replace(coalesce(p_data->>'estimated_value', ''), '[^0-9]', '', 'g'), '')::bigint, 0);
        if v_val <= 0 then raise exception 'اكتب القيمة التقديرية للعقار'; end if;
        if coalesce(p_data->>'district', '') = '' then raise exception 'اكتب المنطقة أو المقاطعة'; end if;
        insert into properties(deed_no, owner_name, owner_national_id, governorate, district, use_type, land_area, ref_value, status)
        values (trim(p_data->>'deed_no'), me.full_name, me.national_id, coalesce(nullif(p_data->>'governorate', ''), a.governorate), p_data->>'district',
          coalesce(nullif(p_data->>'use_type', ''), 'سكني'), nullif(regexp_replace(coalesce(p_data->>'land_area', ''), '[^0-9.]', '', 'g'), '')::numeric, v_val, 'free')
        returning * into pr;
      end if;
      if pr.status <> 'free' and not exists (select 1 from mortgage_referrals mr where mr.property_id = pr.id and mr.application_id = a.id) then
        raise exception 'العقار عليه إشارة — لا يقبل ضماناً'; end if;
      if a.amount > pr.ref_value * _setting('ltv_max') / 100 then raise exception 'مبلغ القرض يتجاوز % بالمئة من قيمة العقار', _setting('ltv_max'); end if;
      update applications set property_id = pr.id, guarantee = jsonb_build_object('type', 'mortgage', 'deed_no', pr.deed_no, 'ref_value', pr.ref_value,
        'ltv', round(a.amount * 100.0 / pr.ref_value, 1)) where id = a.id;
      v_act := 'تأكيد الضمان: رهن عقار'; v_note := 'سند ' || pr.deed_no || ' · ' || pr.governorate || ' / ' || pr.district;
    end if;

  elsif p_step = 5 then
    select * into m from vet_memberships where profile_id = me.id;
    if m is null or m.status <> 'endorsed' then raise exception 'لم تؤيد نقابة الأطباء البيطريين عضويتك بعد — يُرسل الطلب للمصرف بعد التأييد'; end if;
    if m.license_year <> extract(year from now())::int or m.valid_until < current_date then
      raise exception 'تأييد النقابة منتهٍ — جدّد إجازة الممارسة لهذه السنة وأعد إرسال العضوية'; end if;
    if vp.vetdept_status <> 'approved' then raise exception 'لم توافق دائرة البيطرة على المشروع وموقعه بعد'; end if;
    select * into bt from bank_terms where bank_id = coalesce(nullif(p_data->>'bank_id', '')::uuid, (a.bank_choice->>'bank_id')::uuid);
    if bt is null then raise exception 'اختر مصرفاً من القائمة'; end if;
    if exists (select 1 from orgs where id = bt.bank_id and coalesce((meta->>'accepting')::boolean, true) = false) then raise exception 'هذا المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
    if not _otp_ok(p_data->>'otp') then raise exception 'رمز التوقيع الإلكتروني غير صحيح'; end if;
    inst := _vet_installment(a.amount, a.term_months, a.grace_months);
    update applications set bank_id = bt.bank_id, margin = _setting('vet_rate'), monthly_installment = inst, submitted_at = now() where id = a.id;
    -- دفعات الصرف للمورد (تُعاد عند كل إرسال قبل الصرف)
    delete from vet_tranches where application_id = a.id and status <> 'paid';
    insert into vet_tranches(application_id, n, label, pct, amount)
    select a.id, x.n, x.label, x.pct, case when x.n = 3 then a.amount - round(a.amount * _setting('vet_tranche1_pct') / 100) - round(a.amount * _setting('vet_tranche2_pct') / 100)
                                          else round(a.amount * x.pct / 100) end
    from (values (1, 'توريد الأجهزة وخط الإنتاج', _setting('vet_tranche1_pct')), (2, 'التركيب', _setting('vet_tranche2_pct')),
                 (3, 'التشغيل وإجازة دائرة البيطرة', 100 - _setting('vet_tranche1_pct') - _setting('vet_tranche2_pct'))) x(n, label, pct)
    on conflict (application_id, n) do nothing;
    v_act := 'اختيار المصرف وتوقيع الطلب إلكترونياً'; v_note := (select name from orgs where id = bt.bank_id) || ' · ' || a.term_months || ' شهراً (سماح ' || a.grace_months || ') · القسط ' || to_char(inst, 'FM999,999,999') || ' د.ع';
  end if;

  update applications set stage = new_stage, status = 'active', updated_at = now(),
    bank_unit = (select s.owner_label from stages s where s.n = new_stage) where id = a.id returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, p_step, v_act, v_note, me.id, me.full_name, me.role);
  return a;
end $$;

-- ═══ 9) موزّع خطوات المقترض: الطاقة الشمسية كما هي، والبيطري عبر _vet_step ═══
do $$ begin
  if to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)') is null then
    alter function public.citizen_step(uuid, integer, jsonb) rename to _citizen_step_solar;
  end if;
end $$;
revoke all on function public._citizen_step_solar(uuid, integer, jsonb) from public, anon, authenticated;

create or replace function public.citizen_step(p_app uuid, p_step int, p_data jsonb) returns public.applications
language plpgsql security definer set search_path = public as $$
-- مسار الطاقة الشمسية في _citizen_step_solar (يحفظ bank_choice واختيار المصرف كما في الجلسة 5)
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program = 'vet' then
    if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
    if p_step < 1 or p_step > 5 then raise exception 'مرحلة غير معروفة'; end if;
    if p_step > a.stage then raise exception 'أكمل المراحل السابقة أولاً'; end if;
    if p_step = 1 then return _citizen_step_solar(p_app, 1, p_data); end if;   -- التحقق من الهوية مشترك
    return _vet_step(p_app, p_step, p_data);
  end if;
  return _citizen_step_solar(p_app, p_step, p_data);
end $$;
revoke all on function public._vet_step(uuid, int, jsonb) from public, anon, authenticated;

-- ═══ 10) المستندات: عرض سعر المورد وصورة الموقع للمشروع البيطري ═══
create or replace function public.add_document(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb, p_referral uuid default null)
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare me profiles; a applications; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  if me.portal = 'citizen' then
    if a.citizen_id <> me.id then raise exception 'الطلب لا يخصك'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
    if p_kind not in ('deed','owner_id_front','owner_id_back','poa') and not (a.program = 'vet' and p_kind in ('quote','site')) then raise exception 'نوع مستند غير مسموح'; end if;
    if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
      raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
    delete from app_documents where application_id = a.id and kind = p_kind;
  elsif me.portal = 'registry' then
    if p_kind <> 'evidence' or p_referral is null or not exists (select 1 from mortgage_referrals where id = p_referral and application_id = a.id) then raise exception 'المرفق دليل على إحالة رهن فقط'; end if;
  elsif me.portal = 'bank' then
    if a.bank_id <> me.org_id or p_kind not in ('evidence','other') then raise exception 'غير مخوّل'; end if;
  else raise exception 'غير مخوّل'; end if;
  insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_referral, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()), me.id, _role_title(me.role))
  returning id into did;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || case p_kind when 'deed' then 'صورة سند العقار' when 'owner_id_front' then 'هوية مالك العقار (الوجه)'
    when 'poa' then 'وكالة مالك العقار بالرهن' when 'owner_id_back' then 'هوية مالك العقار (الظهر)' when 'evidence' then 'دليل قرار التسجيل العقاري'
    when 'quote' then 'عرض سعر المورد' when 'site' then 'صورة موقع المشروع' else 'مستند' end,
    case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $$;

-- ═══ 11) حارس الانتقالات: شروط الإرسال للمصرف، والتركيب والصرف على دفعات للبيطري ═══
create or replace function public._guard_transition() returns trigger language plpgsql security definer set search_path = public as $$
declare vp vet_projects; m vet_memberships;
begin
  if new.stage = old.stage then return new; end if;
  if old.stage <= 4 and new.stage >= 5 and new.guarantee_type = 'mortgage' then
    if new.ownership is null then raise exception 'أجب عن سؤال ملكية العقار وصوّر السند قبل تأكيد الضمان'; end if;
    if not exists (select 1 from app_documents where application_id = new.id and kind = 'deed') then raise exception 'صوّر سند العقار بكاميرا الهاتف'; end if;
    if coalesce(new.guarantee->>'deed_no', new.ownership->>'deed_no') <> new.ownership->>'deed_no' then raise exception 'رقم السند لا يطابق السند المصوَّر وإقرار الملكية'; end if;
    -- العقار الجديد الذي أنشأه المواطن: يُسجَّل باسم المالك المُقر به لا باسم المقترض
    if (new.ownership->>'is_owner')::boolean is false then
      update properties set owner_name = new.ownership->>'owner_name', owner_national_id = new.ownership->>'owner_national_id'
      where id = new.property_id and owner_national_id is not distinct from (select national_id from profiles where id = new.citizen_id);
    end if;
  end if;
  if old.stage <= 5 and new.stage >= 6 and not exists (select 1 from payments where application_id = new.id and bank_id = new.bank_id and status = 'paid') then
    raise exception 'ادفع عمولة المصرف والرسوم للمصرف المختار قبل إرسال الطلب';
  end if;
  if new.program = 'vet' then
    select * into vp from vet_projects where application_id = new.id;
    if old.stage <= 5 and new.stage >= 6 then
      select * into m from vet_memberships where profile_id = new.citizen_id;
      if m is null or m.status <> 'endorsed' or m.license_year <> extract(year from now())::int then raise exception 'يلزم تأييد نقابة الأطباء البيطريين للعضوية وإجازة الممارسة لهذه السنة'; end if;
      if vp.vetdept_status is distinct from 'approved' then raise exception 'يلزم موافقة دائرة البيطرة على المشروع وموقعه'; end if;
    end if;
    if old.stage = 31 and new.stage > 31 and not (vp.milestones ? 'delivered' and vp.milestones ? 'installed' and vp.milestones ? 'operating') then
      raise exception 'يوثّق المورد التوريد والتركيب والتشغيل قبل اعتماد المحضر'; end if;
    if old.stage = 35 and new.stage > 35 and exists (select 1 from vet_tranches where application_id = new.id and status <> 'paid') then
      raise exception 'تُصرف الدفعات الثلاث للمورد قبل إنجاز مرحلة الصرف (الأخيرة بعد إجازة دائرة البيطرة)'; end if;
  end if;
  return new;
end $$;

-- ═══ 12) نقابة الأطباء البيطريين: تأييد العضوية فقط ═══
create or replace function public.syndicate_action(p_member uuid, p_action text, p_note text default null) returns public.vet_memberships
language plpgsql security definer set search_path = public as $$
declare me profiles; m vet_memberships; a applications; act text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'syndicate_officer' then raise exception 'هذا الإجراء لنقابة الأطباء البيطريين'; end if;
  select * into m from vet_memberships where id = p_member for update;
  if m is null then raise exception 'العضوية غير موجودة'; end if;
  if m.status <> 'pending' then raise exception 'العضوية ليست بانتظار التأييد'; end if;
  if p_action in ('return','reject') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;
  if p_action = 'endorse' then
    if m.license_year <> extract(year from now())::int then raise exception 'إجازة الممارسة غير مجددة لهذه السنة — أعدها للاستكمال'; end if;
    update vet_memberships set status = 'endorsed', note = nullif(trim(p_note), ''), letter_no = coalesce(letter_no, _vet_seq('VSI', 'vet_memberships', 'letter_no')),
      valid_until = make_date(license_year, 12, 31), decided_by_title = _role_title(me.role), decided_at = now(), updated_at = now()
    where id = m.id returning * into m;
    act := 'تأييد نقابة الأطباء البيطريين: العضوية وإجازة الممارسة سارية — كتاب ' || m.letter_no;
  elsif p_action = 'return' then
    update vet_memberships set status = 'returned', note = trim(p_note), decided_by_title = _role_title(me.role), decided_at = now(), updated_at = now() where id = m.id returning * into m;
    act := 'إعادة بيانات العضوية للاستكمال من النقابة';
  elsif p_action = 'reject' then
    update vet_memberships set status = 'rejected', note = trim(p_note), decided_by_title = _role_title(me.role), decided_at = now(), updated_at = now() where id = m.id returning * into m;
    act := 'عدم تأييد العضوية من النقابة';
  else raise exception 'إجراء غير معروف'; end if;
  -- يظهر القرار في سجل كل طلب بيطري قائم للطبيب
  for a in select * from applications where citizen_id = m.profile_id and program = 'vet' and status in ('active','returned') loop
    perform _ev(a.id, a.stage, act, p_note);
  end loop;
  return m;
end $$;

-- ═══ 13) دائرة البيطرة: الموافقة المبدئية على المشروع، ثم إجازة النشاط بعد التشغيل ═══
create or replace function public.vetdept_action(p_app uuid, p_action text, p_note text default null) returns public.vet_projects
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; vp vet_projects; act text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'vetdept_officer' then raise exception 'هذا الإجراء لدائرة البيطرة'; end if;
  select * into a from applications where id = p_app for update;
  select * into vp from vet_projects where application_id = p_app for update;
  if a is null or vp is null or a.program <> 'vet' then raise exception 'الطلب غير موجود'; end if;
  if p_action in ('return','reject') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;
  if p_action in ('approve','return','reject') then
    if vp.vetdept_status <> 'pending' or a.stage > 5 or a.status not in ('active','returned') then raise exception 'المشروع ليس بانتظار الموافقة المبدئية'; end if;
    if p_action = 'approve' then
      update vet_projects set vetdept_status = 'approved', vetdept_note = nullif(trim(p_note), ''), vetdept_ref = coalesce(vetdept_ref, _vet_seq('VD', 'vet_projects', 'vetdept_ref')),
        vetdept_by_title = _role_title(me.role), vetdept_at = now(), updated_at = now() where application_id = a.id returning * into vp;
      act := 'موافقة دائرة البيطرة المبدئية على المشروع وموقعه — ' || vp.vetdept_ref;
    elsif p_action = 'return' then
      update vet_projects set vetdept_status = 'returned', vetdept_note = trim(p_note), vetdept_by_title = _role_title(me.role), vetdept_at = now(), updated_at = now()
      where application_id = a.id returning * into vp;
      act := 'إعادة دراسة المشروع للاستكمال من دائرة البيطرة';
    else
      update vet_projects set vetdept_status = 'rejected', vetdept_note = trim(p_note), vetdept_by_title = _role_title(me.role), vetdept_at = now(), updated_at = now()
      where application_id = a.id returning * into vp;
      update applications set status = 'rejected', updated_at = now() where id = a.id;
      act := 'رفض دائرة البيطرة للمشروع';
    end if;
  elsif p_action = 'license' then
    if a.stage < 31 or a.status <> 'active' then raise exception 'تُمنح الإجازة بعد تركيب الأجهزة وتشغيلها'; end if;
    if not (vp.milestones ? 'operating') then raise exception 'لم يوثّق المورد تشغيل المشروع بعد'; end if;
    if vp.license_no is not null then raise exception 'مُنحت الإجازة سابقاً'; end if;
    update vet_projects set license_no = _vet_seq('VL', 'vet_projects', 'license_no'), license_by_title = _role_title(me.role), license_at = now(), updated_at = now()
    where application_id = a.id returning * into vp;
    update vet_tranches set status = 'ready', ready_at = now() where application_id = a.id and n = 3 and status = 'pending';
    act := 'منح إجازة ممارسة النشاط البيطري بعد الكشف الفني — ' || vp.license_no;
  else raise exception 'إجراء غير معروف'; end if;
  perform _ev(a.id, a.stage, act, p_note);
  return vp;
end $$;

-- ═══ 14) المورد يوثّق: التوريد ← التركيب ← التشغيل (كل خطوة تفتح دفعتها) ═══
create or replace function public.vet_milestone(p_app uuid, p_key text, p_note text default null) returns public.vet_projects
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; vp vet_projects; lbl text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me is null or me.role <> 'supplier_admin' or a is null or a.supplier_id is distinct from me.org_id then raise exception 'الطلب لا يخص شركتك'; end if;
  if a.program <> 'vet' or a.stage <> 31 or a.status <> 'active' then raise exception 'التوثيق بعد أمر الشراء من المصرف (المرحلة 31)'; end if;
  select * into vp from vet_projects where application_id = a.id for update;
  if p_key not in ('delivered','installed','operating') then raise exception 'خطوة غير معروفة'; end if;
  if vp.milestones ? p_key then raise exception 'وُثّقت هذه الخطوة سابقاً'; end if;
  if p_key = 'installed' and not (vp.milestones ? 'delivered') then raise exception 'وثّق التوريد أولاً'; end if;
  if p_key = 'operating' and not (vp.milestones ? 'installed') then raise exception 'وثّق التركيب أولاً'; end if;
  update vet_projects set milestones = milestones || jsonb_build_object(p_key, jsonb_build_object('at', now(), 'by', me.full_name, 'note', nullif(trim(p_note), ''))), updated_at = now()
  where application_id = a.id returning * into vp;
  if p_key = 'delivered' then update vet_tranches set status = 'ready', ready_at = now() where application_id = a.id and n = 1 and status = 'pending'; lbl := 'توريد الأجهزة وخط الإنتاج'; end if;
  if p_key = 'installed' then update vet_tranches set status = 'ready', ready_at = now() where application_id = a.id and n = 2 and status = 'pending'; lbl := 'تركيب الأجهزة'; end if;
  if p_key = 'operating' then lbl := 'التشغيل التجريبي — بانتظار إجازة دائرة البيطرة'; end if;
  perform _ev(a.id, a.stage, 'توثيق المورد: ' || lbl, p_note);
  return vp;
end $$;

-- ═══ 15) أمين الصندوق يصرف الدفعة الجاهزة للمورد ═══
create or replace function public.vet_tranche_pay(p_app uuid, p_n int, p_note text default null) returns public.vet_tranches
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; tr vet_tranches;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me is null or me.role <> 'bank_teller' or a is null or a.bank_id is distinct from me.org_id then raise exception 'الصرف لأمين صندوق المصرف المانح'; end if;
  if me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  if a.program <> 'vet' or a.stage < 31 or a.stage > 35 or a.status <> 'active' then raise exception 'الصرف على دفعات بين أمر الشراء ومرحلة الصرف'; end if;
  select * into tr from vet_tranches where application_id = a.id and n = p_n for update;
  if tr is null then raise exception 'الدفعة غير موجودة'; end if;
  if tr.status = 'paid' then raise exception 'صُرفت هذه الدفعة سابقاً'; end if;
  if tr.status <> 'ready' then raise exception 'الدفعة غير مستحقة بعد — بانتظار توثيق المورد%', case when p_n = 3 then ' وإجازة دائرة البيطرة' else '' end; end if;
  update vet_tranches set status = 'paid', paid_at = now(), paid_by_title = _role_title(me.role),
    ref = 'TR-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)) where id = tr.id returning * into tr;
  perform _ev(a.id, a.stage, 'صرف الدفعة ' || tr.n || ' للمورد: ' || tr.label, to_char(tr.amount, 'FM999,999,999,999') || ' د.ع · ' || tr.ref || coalesce(' · ' || nullif(trim(p_note), ''), ''));
  return tr;
end $$;

-- ═══ 16) البنك المركزي يعدّل إعدادات المبادرة البيطرية حين يصدر التعميم ═══
create or replace function public.cbi_set_setting(p_key text, p_value numeric, p_circular text default null) returns public.settings
language plpgsql security definer set search_path = public as $$
declare me profiles; s settings;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'cbi_admin' then raise exception 'تعديل ضوابط المبادرة للبنك المركزي'; end if;
  if p_key not like 'vet\_%' then raise exception 'يُعدَّل من هنا ضوابط مبادرة الطب البيطري فقط'; end if;
  if p_value is null or p_value < 0 then raise exception 'قيمة غير صحيحة'; end if;
  if p_key in ('vet_rate','vet_min_contribution_pct','vet_tranche1_pct','vet_tranche2_pct') and p_value > 100 then raise exception 'النسبة بين 0 و100'; end if;
  update settings set value = p_value, circular_no = coalesce(nullif(trim(p_circular), ''), circular_no) where key = p_key returning * into s;
  if s is null then raise exception 'الإعداد غير موجود'; end if;
  if p_key like 'vet_tranche%' and _setting('vet_tranche1_pct') + _setting('vet_tranche2_pct') >= 100 then
    raise exception 'مجموع الدفعتين الأولى والثانية أقل من 100 — الباقي يُصرف بعد التشغيل والإجازة'; end if;
  insert into integrity_alerts(type, severity, title, details, entity)
  values ('settings', 'low', 'تعديل ضابط في مبادرة الطب البيطري', s.label || ': ' || p_value::text || coalesce(' · ' || nullif(trim(p_circular), ''), ''), me.full_name);
  return s;
end $$;

revoke all on function public._vet_seq(text, text, text) from public, anon, authenticated;
grant execute on function public.start_vet_application(text, text, text, numeric, numeric), public.vet_member_doc(text, text, text, jsonb),
  public.syndicate_action(uuid, text, text), public.vetdept_action(uuid, text, text), public.vet_milestone(uuid, text, text),
  public.vet_tranche_pay(uuid, int, text), public.cbi_set_setting(text, numeric, text), public.citizen_step(uuid, int, jsonb) to authenticated;

-- ═══ 17) حسابات العرض (كل الأسماء وهمية) ═══
do $$
declare r record; uid uuid; y int := extract(year from now())::int; mid uuid;
begin
  for r in select * from (values
    ('syndicate1', 'Vsi@2026sy', 'سلمى حميد ناصر', 'syndicate_officer', 'syndicate', 'vsi', null::text, null::text),
    ('vetdept1', 'Vet@2026vd', 'كريم جبار عودة', 'vetdept_officer', 'vetdept', 'vetdept', null, null),
    ('supplier4', 'Sup@2026s4', 'مدير حساب الرافدين للتجهيزات', 'supplier_admin', 'supplier', 'sup4', null, null),
    ('supplier5', 'Sup@2026s5', 'مدير حساب آشور لخطوط الإنتاج', 'supplier_admin', 'supplier', 'sup5', null, null),
    ('vet1', 'Alwah@2001', 'مصطفى عادل كاظم الجبوري', 'citizen', 'citizen', null, '07701112201', '199012345601'),
    ('vet2', 'Alwah@2002', 'نور الهدى سامي رحيم', 'citizen', 'citizen', null, '07701112202', '199212345602')
  ) v(u, pw, nm, rl, po, og, ph, nid) loop
    if not exists (select 1 from profiles where username = r.u) then
      uid := _mk_user(r.u, r.pw, r.nm, r.rl, r.po, r.og, r.ph, r.nid);
      if r.po = 'citizen' then
        update profiles set governorate = 'بغداد', city = 'الكرادة', employer = 'عمل حر — طبيب بيطري', employment_type = 'private', monthly_salary = 1800000,
          birth_date = '1990-03-14', kyc_status = 'none', self_registered = false where id = uid;
      end if;
    end if;
  end loop;
  -- vet1: عضوية مؤيدة لهذه السنة — يبدأ طلبه كاملاً من البداية
  select id into uid from profiles where username = 'vet1';
  if uid is not null and not exists (select 1 from vet_memberships where profile_id = uid) then
    insert into vet_memberships(profile_id, full_name, national_id, membership_no, syndicate_branch, license_no, license_year, graduation_year, college, specialty,
      status, letter_no, valid_until, decided_by_title, decided_at, submitted_at)
    values (uid, 'مصطفى عادل كاظم الجبوري', '199012345601', '4812', 'بغداد', 'BG-2231', y, 2013, 'كلية الطب البيطري — جامعة بغداد', 'أحياء مجهرية',
      'endorsed', _vet_seq('VSI', 'vet_memberships', 'letter_no'), make_date(y, 12, 31), _role_title('syndicate_officer'), now(), now() - interval '2 days')
    returning id into mid;
    insert into vet_member_docs(membership_id, kind, mime, data, bytes, meta) values
      (mid, 'union_id', 'image/jpeg', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 120, '{"demo":true}'),
      (mid, 'license', 'image/jpeg', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 120, '{"demo":true}'),
      (mid, 'degree', 'image/jpeg', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 120, '{"demo":true}');
  end if;
  -- vet2: عضوية بانتظار تأييد النقابة — تظهر في صندوق النقابة
  select id into uid from profiles where username = 'vet2';
  if uid is not null and not exists (select 1 from vet_memberships where profile_id = uid) then
    insert into vet_memberships(profile_id, full_name, national_id, membership_no, syndicate_branch, license_no, license_year, graduation_year, college, specialty, status, submitted_at)
    values (uid, 'نور الهدى سامي رحيم', '199212345602', '5307', 'بابل', 'BB-0914', y, 2015, 'كلية الطب البيطري — جامعة القاسم الخضراء', 'طب الدواجن', 'pending', now() - interval '5 hours')
    returning id into mid;
    insert into vet_member_docs(membership_id, kind, mime, data, bytes, meta)
    select mid, k, 'image/jpeg', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=', 120, '{"demo":true}'
    from unnest(array['union_id','license','degree']) k;
  end if;
end $$;

commit;
