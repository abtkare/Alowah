-- ألواح — الجلسة 2: حساب المواطن، رمز التحقق (وضع المطور)، مراحل الطلب 1–5، التقييمات، الملف الشخصي
-- مطبَّق على المشروع alwah-platform (chjeqtjyywomtcenizxp) بالترحيل session2_citizen

-- 1) أعمدة إضافية
alter table public.profiles
  add column if not exists governorate text, add column if not exists city text, add column if not exists address text,
  add column if not exists employer text, add column if not exists monthly_salary bigint, add column if not exists birth_date date,
  add column if not exists email text, add column if not exists self_registered boolean default false,
  add column if not exists kyc_status text default 'none', add column if not exists kyc_at timestamptz,
  add column if not exists updated_at timestamptz default now();
create unique index if not exists profiles_phone_uq on public.profiles(phone) where phone is not null;
create unique index if not exists profiles_nid_uq on public.profiles(national_id) where national_id is not null;

alter table public.applications
  add column if not exists kyc jsonb, add column if not exists guarantee jsonb, add column if not exists submitted_at timestamptz;

-- 2) وضع المطور: رمز التحقق الثابت 1234 لأي شاشة تطلب OTP (أوقفه بجعل القيمة 0)
insert into public.settings(key, value, label, circular_no)
values ('dev_mode', 1, 'وضع المطور: رمز التحقق OTP ثابت 1234', null)
on conflict (key) do nothing;

create or replace function public._otp_ok(p_code text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select value from settings where key = 'dev_mode'), 0) = 1 and trim(coalesce(p_code, '')) = '1234'
$$;

create or replace function public._norm_phone(p text) returns text
language plpgsql immutable as $$
declare d text := regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g');
begin
  if d like '00964%' then d := '0' || substr(d, 6);
  elsif d like '964%' then d := '0' || substr(d, 4);
  elsif d ~ '^7[0-9]{9}$' then d := '0' || d; end if;
  if d !~ '^07[3-9][0-9]{8}$' then raise exception 'رقم الهاتف غير صحيح — اكتبه بالصيغة 07XXXXXXXXX'; end if;
  return d;
end $$;

create or replace function public._installment(p_amount numeric, p_rate_pct numeric, p_months int) returns bigint
language sql immutable as $$
  select case when p_rate_pct <= 0 then round(p_amount / p_months)::bigint
    else round(p_amount * (p_rate_pct / 1200) / (1 - power(1 + p_rate_pct / 1200, -p_months)))::bigint end
$$;

create or replace function public._setting(p_key text) returns numeric
language sql stable security definer set search_path = public as $$ select value from settings where key = p_key $$;

-- إعدادات عامة يقرؤها المتصفح قبل الدخول
create or replace function public.public_config() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('dev_mode', coalesce(_setting('dev_mode'), 0) = 1,
                            'dev_otp', case when coalesce(_setting('dev_mode'), 0) = 1 then '1234' end)
$$;

-- التحقق من رمز OTP (المحاكاة: لا يُرسل SMS فعلياً)
create or replace function public.verify_otp(p_phone text, p_code text, p_purpose text default 'generic') returns boolean
language plpgsql security definer set search_path = public as $$
begin
  perform _norm_phone(p_phone);
  if not _otp_ok(p_code) then raise exception 'رمز التحقق غير صحيح'; end if;
  return true;
end $$;

-- 3) إنشاء حساب مواطن
create or replace function public.register_citizen(p_phone text, p_otp text, p_full_name text, p_national_id text,
  p_birth_date date, p_governorate text, p_password text) returns jsonb
language plpgsql security definer set search_path = public, auth, extensions as $$
declare ph text := _norm_phone(p_phone); nm text := regexp_replace(trim(coalesce(p_full_name, '')), '\s+', ' ', 'g'); uid uuid;
begin
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح'; end if;
  if array_length(string_to_array(nm, ' '), 1) < 3 then raise exception 'اكتب الاسم الثلاثي على الأقل كما في البطاقة الوطنية'; end if;
  if coalesce(p_national_id, '') !~ '^[0-9]{12}$' then raise exception 'رقم البطاقة الوطنية 12 رقماً'; end if;
  if p_birth_date is null or p_birth_date > (current_date - interval '18 years') then raise exception 'يجب أن يكون عمر المتقدم 18 سنة فأكثر'; end if;
  if coalesce(p_governorate, '') = '' then raise exception 'اختر المحافظة'; end if;
  if length(coalesce(p_password, '')) < 8 or p_password !~ '[0-9]' or p_password !~ '[A-Za-z]' then
    raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if exists (select 1 from profiles where phone = ph or username = ph) or exists (select 1 from auth.users where email = ph || '@alwah.demo') then
    raise exception 'رقم الهاتف مسجل مسبقاً — سجّل الدخول أو استعد كلمة المرور'; end if;
  if exists (select 1 from profiles where national_id = p_national_id) then raise exception 'رقم البطاقة الوطنية مسجل بحساب آخر'; end if;

  uid := _mk_user(ph, p_password, nm, 'citizen', 'citizen', null, ph, p_national_id);
  update profiles set birth_date = p_birth_date, governorate = p_governorate, self_registered = true where id = uid;
  return jsonb_build_object('username', ph);
end $$;

-- استعادة كلمة المرور برمز التحقق (للحسابات المنشأة من المنصة فقط)
create or replace function public.reset_password_otp(p_phone text, p_otp text, p_new_password text) returns boolean
language plpgsql security definer set search_path = public, auth, extensions as $$
declare ph text := _norm_phone(p_phone); uid uuid;
begin
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح'; end if;
  if length(coalesce(p_new_password, '')) < 8 or p_new_password !~ '[0-9]' or p_new_password !~ '[A-Za-z]' then
    raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  select id into uid from profiles where phone = ph and portal = 'citizen' and self_registered;
  if uid is null then raise exception 'لا يوجد حساب منشأ بهذا الرقم'; end if;
  update auth.users set encrypted_password = crypt(p_new_password, gen_salt('bf')), updated_at = now() where id = uid;
  return true;
end $$;

-- 4) الملف الشخصي
create or replace function public.update_my_profile(p jsonb) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  if p ? 'monthly_salary' and nullif(p->>'monthly_salary', '') is not null and (p->>'monthly_salary')::bigint < 0 then raise exception 'الراتب غير صحيح'; end if;
  if p ? 'email' and nullif(p->>'email', '') is not null and (p->>'email') !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'البريد الإلكتروني غير صحيح'; end if;
  update profiles set
    governorate   = case when p ? 'governorate' then nullif(p->>'governorate', '') else governorate end,
    city          = case when p ? 'city' then nullif(p->>'city', '') else city end,
    address       = case when p ? 'address' then nullif(p->>'address', '') else address end,
    employer      = case when p ? 'employer' then nullif(p->>'employer', '') else employer end,
    monthly_salary= case when p ? 'monthly_salary' then nullif(p->>'monthly_salary', '')::bigint else monthly_salary end,
    email         = case when p ? 'email' then nullif(p->>'email', '') else email end,
    full_name     = case when p ? 'full_name' and me.kyc_status <> 'verified' and length(trim(p->>'full_name')) > 5 then trim(p->>'full_name') else full_name end,
    updated_at = now()
  where id = me.id returning * into me;
  return me;
end $$;

create or replace function public.change_my_password(p_old text, p_new text) returns boolean
language plpgsql security definer set search_path = public, auth, extensions as $$
declare u auth.users;
begin
  select * into u from auth.users where id = auth.uid();
  if u is null then raise exception 'غير مسجل الدخول'; end if;
  if u.encrypted_password <> crypt(p_old, u.encrypted_password) then raise exception 'كلمة المرور الحالية غير صحيحة'; end if;
  if length(coalesce(p_new, '')) < 8 or p_new !~ '[0-9]' or p_new !~ '[A-Za-z]' then
    raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  update auth.users set encrypted_password = crypt(p_new, gen_salt('bf')), updated_at = now() where id = u.id;
  return true;
end $$;

-- تغيير رقم الهاتف برمز يُرسل إلى الرقم الجديد. للحسابات المنشأة من المنصة يتغير اسم الدخول أيضاً.
create or replace function public.change_my_phone(p_new_phone text, p_otp text) returns public.profiles
language plpgsql security definer set search_path = public, auth as $$
declare me profiles; ph text := _norm_phone(p_new_phone);
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح'; end if;
  if exists (select 1 from profiles where (phone = ph or username = ph) and id <> me.id) then raise exception 'الرقم مستخدم بحساب آخر'; end if;
  if me.self_registered then
    update auth.users set email = ph || '@alwah.demo', updated_at = now() where id = me.id;
    update auth.identities set identity_data = identity_data || jsonb_build_object('email', ph || '@alwah.demo') where user_id = me.id;
    update profiles set username = ph, phone = ph, updated_at = now() where id = me.id returning * into me;
  else
    update profiles set phone = ph, updated_at = now() where id = me.id returning * into me;
  end if;
  return me;
end $$;

-- 5) بدء الطلب من الكتالوج
create or replace function public.start_application(p_offer uuid, p_governorate text, p_city text default null,
  p_lat numeric default null, p_lng numeric default null) returns public.applications
language plpgsql security definer set search_path = public as $$
declare me profiles; o supplier_offers; a applications; v_kw numeric; v_code text; gt text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'citizen' then raise exception 'التقديم من بوابة المواطن فقط'; end if;
  if exists (select 1 from applications where citizen_id = me.id and status in ('active', 'returned')) then
    raise exception 'لديك طلب قائم — تابعه من «طلبي» أو ألغِه قبل تقديم طلب جديد'; end if;
  select * into o from supplier_offers where id = p_offer and status = 'published';
  if o is null then raise exception 'العرض غير متاح'; end if;
  if coalesce(p_governorate, '') = '' then raise exception 'اختر محافظة موقع التركيب'; end if;
  select kw into v_kw from capacity_tiers where id = o.tier_id;
  gt := case when o.price <= _setting('guarantee_t1') then 'single_salary' when o.price <= _setting('guarantee_t2') then 'multi_salary' else 'mortgage' end;
  select 'ALW-' || to_char(now(), 'YYYY') || '-' || lpad((coalesce(max(substring(code from '[0-9]+$')::int), 100) + 1)::text, 5, '0')
    into v_code from applications;
  insert into applications(code, citizen_id, citizen_name, offer_id, supplier_id, kw, price, amount, term_months, guarantee_type,
    governorate, city, lat, lng, stage, status, bank_unit)
  values (v_code, me.id, me.full_name, o.id, o.supplier_id, v_kw, o.price, o.price, 60, gt,
    p_governorate, coalesce(p_city, p_governorate), p_lat, p_lng, 1, 'active', 'المواطن')
  returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, 1, 'بدء طلب تمويل جديد من الكتالوج', o.title, me.id, me.full_name, me.role);
  return a;
end $$;

-- 6) مراحل المواطن 1–5 (كل مرحلة تتحقق من بياناتها ثم تنقل الطلب)
create or replace function public.citizen_step(p_app uuid, p_step int, p_data jsonb) returns public.applications
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; o supplier_offers; bt bank_terms; pr properties; g jsonb; arr jsonb := '[]'::jsonb;
  act text; note text; new_stage int; gt text; v_kw numeric; total bigint := 0; inst bigint; need bigint; n int; phones text[] := '{}';
  v_term int; v_val bigint; ph text; score numeric;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if p_step < 1 or p_step > 5 then raise exception 'مرحلة غير معروفة'; end if;
  if p_step > a.stage then raise exception 'أكمل المراحل السابقة أولاً'; end if;
  new_stage := greatest(a.stage, p_step + 1);

  if p_step = 1 then
    if coalesce(p_data->>'national_id', '') !~ '^[0-9]{12}$' then raise exception 'رقم البطاقة الوطنية 12 رقماً'; end if;
    if me.national_id is not null and me.national_id <> p_data->>'national_id' then raise exception 'رقم البطاقة لا يطابق الرقم المسجل في حسابك'; end if;
    if coalesce((p_data->>'liveness')::boolean, false) is not true then raise exception 'لم يكتمل فحص الحيوية — أعد التقاط السيلفي'; end if;
    score := coalesce((p_data->>'match_score')::numeric, 0);
    if score < 80 then raise exception 'نسبة مطابقة الوجه مع صورة البطاقة غير كافية — أعد الالتقاط في إضاءة جيدة'; end if;
    update applications set kyc = jsonb_build_object('national_id', p_data->>'national_id', 'match_score', score, 'liveness', true,
      'card_side', coalesce(p_data->>'card_side', 'front+back'), 'method', 'selfie', 'verified_at', now()) where id = a.id;
    update profiles set national_id = coalesce(national_id, p_data->>'national_id'), kyc_status = 'verified', kyc_at = now() where id = me.id;
    act := 'التحقق من الهوية بالسيلفي'; note := 'مطابقة الوجه ' || score || '% · فحص الحيوية ناجح';

  elsif p_step = 2 then
    if coalesce(p_data->>'ur_number', '') !~ '^[0-9]{10}$' then raise exception 'رقم «أور» 10 أرقام'; end if;
    if not _otp_ok(p_data->>'otp') then raise exception 'رمز التحقق من «أور» غير صحيح'; end if;
    update applications set ur_number = p_data->>'ur_number', ur_verified = false where id = a.id;
    act := 'ربط رقم «أور» وتأكيده برمز التحقق'; note := 'أور ' || (p_data->>'ur_number');

  elsif p_step = 3 then
    if p_data ? 'offer_id' and (p_data->>'offer_id')::uuid is distinct from a.offer_id then
      select * into o from supplier_offers where id = (p_data->>'offer_id')::uuid and status = 'published';
      if o is null then raise exception 'العرض غير متاح'; end if;
      select kw into v_kw from capacity_tiers where id = o.tier_id;
      gt := case when o.price <= _setting('guarantee_t1') then 'single_salary' when o.price <= _setting('guarantee_t2') then 'multi_salary' else 'mortgage' end;
      if gt is distinct from a.guarantee_type then
        update applications set guarantee = null, property_id = null where id = a.id;
        if new_stage > 4 then new_stage := 4; end if;
      end if;
      update applications set offer_id = o.id, supplier_id = o.supplier_id, kw = v_kw, price = o.price, amount = o.price, guarantee_type = gt where id = a.id;
      act := 'تغيير العرض المختار'; note := o.title;
    else
      select * into o from supplier_offers where id = a.offer_id;
      act := 'تثبيت العرض المختار'; note := o.title;
    end if;

  elsif p_step = 4 then
    -- التقدير بأعلى هامش مسموح ولمدة 60 شهراً، فيبقى الضمان كافياً مع أي مصرف
    inst := _installment(a.amount, _setting('cbi_rate') + _setting('margin_max'), 60);
    if a.guarantee_type in ('single_salary', 'multi_salary') then
      n := jsonb_array_length(coalesce(p_data->'guarantors', '[]'::jsonb));
      if a.guarantee_type = 'single_salary' and n < 1 then raise exception 'أضف كفيلاً واحداً موظفاً'; end if;
      if a.guarantee_type = 'multi_salary' and n < 2 then raise exception 'هذا المبلغ يتطلب كفيلين موظفين على الأقل'; end if;
      if n > 3 then raise exception 'ثلاثة كفلاء كحد أقصى'; end if;
      for g in select * from jsonb_array_elements(p_data->'guarantors') loop
        if length(trim(coalesce(g->>'name', ''))) < 6 then raise exception 'اكتب الاسم الثلاثي لكل كفيل'; end if;
        ph := _norm_phone(g->>'phone');
        if ph = me.phone then raise exception 'لا يكفل المتقدم نفسه'; end if;
        if ph = any(phones) then raise exception 'رقم هاتف مكرر بين الكفلاء'; end if;
        phones := phones || ph;
        if coalesce(g->>'employer', '') = '' then raise exception 'اكتب جهة عمل كل كفيل'; end if;
        if coalesce((g->>'salary')::bigint, 0) < 250000 then raise exception 'راتب الكفيل غير صحيح'; end if;
        if not _otp_ok(g->>'otp') then raise exception 'لم يؤكد الكفيل % موافقته برمز التحقق', g->>'name'; end if;
        total := total + (g->>'salary')::bigint;
        arr := arr || jsonb_build_object('name', trim(g->>'name'), 'phone', ph, 'employer', g->>'employer', 'salary', (g->>'salary')::bigint,
          'relation', g->>'relation', 'consent', true, 'consent_at', now());
      end loop;
      need := ceil(inst * _setting('salary_safety'));
      if total < need then raise exception 'مجموع رواتب الكفلاء (% د.ع) أقل من القسط × % = % د.ع', to_char(total, 'FM999,999,999'), _setting('salary_safety'), to_char(need, 'FM999,999,999'); end if;
      update applications set guarantee = jsonb_build_object('type', a.guarantee_type, 'guarantors', arr, 'total_salary', total, 'required', need) where id = a.id;
      act := 'تأكيد الضمان وموافقة الكفلاء'; note := n || ' كفيل · مجموع الرواتب ' || to_char(total, 'FM999,999,999') || ' د.ع';
    else
      if coalesce(trim(p_data->>'deed_no'), '') = '' then raise exception 'اكتب رقم السند العقاري (رقم القطعة/المقاطعة)'; end if;
      select * into pr from properties where deed_no = trim(p_data->>'deed_no');
      if pr is null then
        v_val := coalesce(nullif(p_data->>'estimated_value', '')::bigint, 0);
        if v_val <= 0 then raise exception 'اكتب القيمة التقديرية للعقار'; end if;
        if coalesce(p_data->>'district', '') = '' then raise exception 'اكتب المنطقة أو المقاطعة'; end if;
        insert into properties(deed_no, owner_name, owner_national_id, governorate, district, use_type, land_area, ref_value, status)
        values (trim(p_data->>'deed_no'), me.full_name, me.national_id, coalesce(p_data->>'governorate', a.governorate), p_data->>'district',
          coalesce(p_data->>'use_type', 'سكني'), nullif(p_data->>'land_area', '')::numeric, v_val, 'free')
        returning * into pr;
      end if;
      if pr.status <> 'free' and not exists (select 1 from mortgage_referrals m where m.property_id = pr.id and m.application_id = a.id) then
        raise exception 'العقار عليه إشارة (%) — لا يقبل ضماناً', case pr.status when 'mortgaged' then 'مرهون' when 'seized' then 'محجوز' else 'موقوف' end; end if;
      if a.amount > pr.ref_value * _setting('ltv_max') / 100 then
        raise exception 'مبلغ التمويل يتجاوز % بالمئة من قيمة العقار', _setting('ltv_max'); end if;
      update applications set property_id = pr.id, guarantee = jsonb_build_object('type', 'mortgage', 'deed_no', pr.deed_no, 'ref_value', pr.ref_value,
        'ltv', round(a.amount * 100.0 / pr.ref_value, 1)) where id = a.id;
      act := 'تأكيد الضمان: رهن عقار'; note := 'سند ' || pr.deed_no || ' · ' || pr.governorate || ' / ' || pr.district;
    end if;

  elsif p_step = 5 then
    select * into bt from bank_terms where bank_id = (p_data->>'bank_id')::uuid;
    if bt is null then raise exception 'اختر مصرفاً من القائمة'; end if;
    if exists (select 1 from orgs where id = bt.bank_id and coalesce((meta->>'accepting')::boolean, true) = false) then raise exception 'هذا المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
    v_term := coalesce((p_data->>'term_months')::int, 60);
    if v_term < 12 or v_term > least(bt.max_term_months, _setting('term_max_months')::int) then
      raise exception 'مدة السداد بين 12 و% شهراً لدى هذا المصرف', least(bt.max_term_months, _setting('term_max_months')::int); end if;
    if not _otp_ok(p_data->>'otp') then raise exception 'رمز التوقيع الإلكتروني غير صحيح'; end if;
    inst := _installment(a.amount, _setting('cbi_rate') + bt.margin, v_term);
    update applications set bank_id = bt.bank_id, term_months = v_term, margin = bt.margin, monthly_installment = inst, submitted_at = now() where id = a.id;
    act := 'اختيار المصرف وتوقيع الطلب إلكترونياً'; note := (select name from orgs where id = bt.bank_id) || ' · ' || v_term || ' شهراً · القسط ' || to_char(inst, 'FM999,999,999') || ' د.ع';
  end if;

  update applications set stage = new_stage, status = 'active', updated_at = now(),
    bank_unit = (select s.owner_label from stages s where s.n = new_stage) where id = a.id returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, p_step, act, note, me.id, me.full_name, me.role);
  return a;
end $$;

create or replace function public.cancel_my_application(p_app uuid, p_reason text default null) returns public.applications
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.stage > 5 or a.status <> 'active' then raise exception 'لا يُلغى الطلب بعد إرساله للمصرف — راجع المصرف'; end if;
  update applications set status = 'cancelled', updated_at = now() where id = a.id returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, 'إلغاء الطلب من المتقدم', p_reason, me.id, me.full_name, me.role);
  return a;
end $$;

-- 7) تقييمات المواطنين للمنظومات (يقيّم من رُكّبت منظومته فقط، مرة واحدة لكل طلب)
create table if not exists public.offer_reviews (
  id uuid primary key default gen_random_uuid(),
  offer_id uuid not null references public.supplier_offers(id) on delete cascade,
  supplier_id uuid references public.orgs(id),
  application_id uuid unique references public.applications(id) on delete set null,
  citizen_id uuid references public.profiles(id) on delete set null,
  author_name text not null, governorate text,
  rating int not null check (rating between 1 and 5),
  quality int check (quality between 1 and 5), install int check (install between 1 and 5), service int check (service between 1 and 5),
  comment text, verified boolean default true, created_at timestamptz default now()
);
alter table public.offer_reviews enable row level security;
drop policy if exists read_reviews on public.offer_reviews;
create policy read_reviews on public.offer_reviews for select to authenticated using (true);
create index if not exists offer_reviews_offer_idx on public.offer_reviews(offer_id);

create or replace function public.submit_review(p_app uuid, p_rating int, p_quality int, p_install int, p_service int, p_comment text)
returns public.offer_reviews language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; r offer_reviews;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if not (a.status = 'completed' or a.stage >= 12) then raise exception 'التقييم بعد تركيب المنظومة وتشغيلها'; end if;
  if exists (select 1 from offer_reviews where application_id = a.id) then raise exception 'قيّمت هذه المنظومة مسبقاً'; end if;
  if p_rating not between 1 and 5 then raise exception 'اختر من 1 إلى 5 نجوم'; end if;
  insert into offer_reviews(offer_id, supplier_id, application_id, citizen_id, author_name, governorate, rating, quality, install, service, comment)
  values (a.offer_id, a.supplier_id, a.id, me.id, me.full_name, a.governorate, p_rating, p_quality, p_install, p_service, nullif(trim(p_comment), ''))
  returning * into r;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, 'تقييم المواطن للمنظومة', p_rating || ' من 5', me.id, me.full_name, me.role);
  return r;
end $$;

-- 8) الصلاحيات
revoke all on function public._otp_ok(text), public._setting(text) from public, anon, authenticated;
revoke all on function public.register_citizen, public.reset_password_otp, public.verify_otp, public.public_config from public;
grant execute on function public.public_config(), public.verify_otp(text, text, text),
  public.register_citizen(text, text, text, text, date, text, text), public.reset_password_otp(text, text, text) to anon, authenticated;
revoke all on function public.update_my_profile, public.change_my_password, public.change_my_phone, public.start_application,
  public.citizen_step, public.cancel_my_application, public.submit_review from public, anon;
grant execute on function public.update_my_profile, public.change_my_password, public.change_my_phone, public.start_application,
  public.citizen_step, public.cancel_my_application, public.submit_review to authenticated;
revoke all on function public._mk_user, public._mk_app from public, anon, authenticated;

alter publication supabase_realtime add table public.offer_reviews;

-- 9) البيانات: صور وفيديوهات العروض (public/media/offers)، 114 تقييماً تجريبياً، بيانات المواطنين التجريبيين،
--    ومصرف دجلة لا يستقبل طلبات (orgs.meta.accepting=false) لأنه بلا حسابات دخول.
--    مطبّقة بالترحيل session2_seed_reviews_media.
-- 10) تحصين (session2_hardening): search_path للدالتين المساعدتين، ودوال المراحل للمستخدمين المسجلين فقط.
