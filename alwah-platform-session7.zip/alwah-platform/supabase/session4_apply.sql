-- ألواح — الجلسة 4: يُلصق كاملاً في محرر SQL في Supabase ويُشغَّل مرة واحدة
-- https://supabase.com/dashboard/project/chjeqtjyywomtcenizxp/sql/new

-- ألواح — الجلسة 4: مطابقة دورة الطلب مع إجراء تمويل المبادرة وسياسة التمويل في المصرف
-- (مسميات وظيفية عامة فقط — لا أسماء أشخاص ولا مصارف حقيقية ولا رموز وثائق داخلية)
-- مطبَّق على المشروع alwah-platform بالترحيل session4_procedure

-- 1) الفروع
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(), bank_id uuid not null references public.orgs(id),
  code text unique not null, name text not null, governorates text[] not null default '{}',
  is_main boolean default false, complaint_phone text, created_at timestamptz default now()
);
alter table public.branches enable row level security;
drop policy if exists read_branches on public.branches;
create policy read_branches on public.branches for select to authenticated using (true);

alter table public.profiles add column if not exists branch_id uuid references public.branches(id);

-- 2) أعمدة الطلب الجديدة
alter table public.applications drop constraint if exists applications_stage_check;
alter table public.applications add constraint applications_stage_check check (stage between 1 and 37);
alter table public.applications
  add column if not exists branch_id uuid references public.branches(id),
  add column if not exists batch_id uuid,
  add column if not exists initial_approved_at timestamptz,   -- الموافقة المبدئية لمدير الفرع (تبدأ مهلة 90 يوماً)
  add column if not exists cbi_approved_at timestamptz,       -- موافقة المركزي على السلفة (تبدأ مهلة التنفيذ)
  add column if not exists fees_paid_at timestamptz,          -- إيداع العمولات وأجور الكشف
  add column if not exists cbi_fee bigint,                    -- عمولة المركزي لمرة واحدة
  add column if not exists grace_months int default 0;

-- 3) المراحل: صاحب كل مرحلة، مدتها المسموحة بأيام الدوام، ومرجعها في الإجراء
alter table public.stages
  add column if not exists sla_days numeric default 0, add column if not exists proc_ref text,
  add column if not exists action_label text, add column if not exists branch_level boolean default false,
  add column if not exists batch_only boolean default false, add column if not exists phase text;

delete from public.stages;
insert into public.stages (n, name, owner_role, owner_label, sla_days, proc_ref, action_label, branch_level, batch_only, phase) values
(1,'التحقق من الهوية وتصوير المستمسكات','citizen','المواطن',0,'السياسة: المستمسكات الثبوتية','إكمال التحقق من الهوية',false,false,'المواطن'),
(2,'رقم «أور»','citizen','المواطن',0,null,'تأكيد رقم «أور»',false,false,'المواطن'),
(3,'اختيار القدرة والعرض','citizen','المواطن',0,null,'تثبيت العرض المختار',false,false,'المواطن'),
(4,'الضمان والكفلاء','citizen','المواطن',0,'السياسة: الضمانات المقبولة','تأكيد الضمان',false,false,'المواطن'),
(5,'اختيار المصرف والتوقيع الإلكتروني','citizen','المواطن',0,'السياسة: التقديم بالاستمارة الإلكترونية','تأكيد اختيار المصرف',false,false,'المواطن'),
(6,'الاستقبال وتدقيق المستمسكات والاستعلام الائتماني','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوتان 1–2','تأكيد اكتمال المستمسكات والاستعلام الائتماني',true,false,'الفرع'),
(7,'فتح الحساب والامتثال','bank_compliance','الامتثال وفتح الحسابات',2,'الإجراء: الخطوة 2 · السياسة: الخدمة لأصحاب الحسابات','تأكيد وجود الحساب واجتياز الامتثال',false,false,'الفرع'),
(8,'الموافقة المبدئية','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 3','الموافقة المبدئية والتوجيه بإجراء الضمان',true,false,'الفرع'),
(9,'إجراءات الضمان الأولية','bank_cs','خدمة الزبائن — العمليات الائتمانية',5,'الإجراء: الخطوة 4','تأكيد إنجاز إجراءات الضمان الأولية',true,false,'الفرع'),
(10,'الإضبارة الإلكترونية والوعد بالشراء وإيداع العمولات','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوة 5','فتح الإضبارة وتثبيت الوعد بالشراء وإيداع العمولات',true,false,'الفرع'),
(11,'قرار اللجنة الائتمانية في الفرع','bank_branch_mgr','مدير الفرع',2,'الإجراء: الخطوة 6','توقيع قرار اللجنة الائتمانية وختمه',true,false,'الفرع'),
(12,'استلام الإضبارة وقائمة التدقيق','bank_initiatives','إداري قسم المبادرات الائتمانية',2,'الإجراء: الخطوتان 7–8','إعداد قائمة تدقيق محتويات الإضبارة',false,false,'قسم المبادرات'),
(13,'التحقق من خلو الإضبارة من النواقص','bank_credit','مسؤول شعبة ائتمان المبادرات',1,'الإجراء: الخطوة 9','تأكيد خلو الإضبارة من النواقص',false,false,'قسم المبادرات'),
(14,'الكشف الموقعي وتقرير الجدارة الائتمانية','bank_inspection','لجنة الكشف الموقعي',7,'الإجراء: الخطوات 10–12 · السياسة: ثالثاً','رفع تقرير الكشف الموقعي والجدارة',false,false,'قسم المبادرات'),
(15,'الدراسة الائتمانية والتوصية','bank_credit','مسؤول شعبة ائتمان المبادرات',3,'الإجراء: الخطوة 13','رفع الدراسة الائتمانية والتوصية',false,false,'قسم المبادرات'),
(16,'قرار قسم المبادرات الائتمانية','bank_initiatives_mgr','مدير قسم المبادرات ومعاونه',2,'الإجراء: الخطوة 14','كتابة القرار وتوقيع الدراسة',false,false,'قسم المبادرات'),
(17,'رأي القسم القانوني','bank_legal','القسم القانوني',2,'الإجراء: الخطوة 15','كتابة القرار القانوني والتوقيع',false,false,'الإدارة العامة'),
(18,'موافقة الإدارة العليا ضمن الصلاحيات','bank_md','الإدارة العليا للمصرف',2,'الإجراء: الخطوة 16','الموافقة والتوقيع والختم',false,false,'الإدارة العامة'),
(19,'استكمال الضمان النهائي','bank_initiatives','إداري قسم المبادرات الائتمانية',5,'الإجراء: الخطوة 17 · السياسة: مهلة 3 أشهر','تأكيد استحصال الضمان النهائي',false,false,'قسم المبادرات'),
(20,'التجميع في سلفة تجميعية','bank_initiatives','إداري قسم المبادرات الائتمانية',5,'الإجراء: الخطوتان 18–19','إضافة إلى سلفة تجميعية',false,true,'البنك المركزي'),
(21,'توقيع كتاب طلب السلفة','bank_md','الإدارة العليا للمصرف',2,'الإجراء: الخطوة 20','توقيع الكتاب',false,true,'البنك المركزي'),
(22,'إرسال الكتاب إلى البنك المركزي','bank_admin','قسم الإدارة',1,'الإجراء: الخطوتان 21–22','إرسال الكتاب',false,true,'البنك المركزي'),
(23,'قرار البنك المركزي على السلفة','cbi_admin','البنك المركزي',15,'الإجراء: الخطوة 23','الموافقة على السلفة',false,true,'البنك المركزي'),
(24,'إبلاغ الفرع وفتح التسهيل','bank_credit','مسؤول شعبة ائتمان المبادرات',1,'الإجراء: الخطوة 24 · السياسة: التنفيذ خلال شهر','إبلاغ الفرع بتوقيع العقد وفتح التسهيل',false,false,'التنفيذ'),
(25,'توقيع عقد التمويل والكمبيالة','bank_cs','خدمة الزبائن — العمليات الائتمانية',3,'الإجراء: الخطوة 25','تأكيد توقيع العقد والكمبيالة واستمارة القبول',true,false,'التنفيذ'),
(26,'تدقيق العقد والكمبيالة','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 26','تدقيق العقد والكمبيالة والتوقيع',true,false,'التنفيذ'),
(27,'طلب تنفيذ التمويل','bank_credit','مسؤول شعبة ائتمان المبادرات',2,'الإجراء: الخطوة 27','تعبئة استمارة طلب التنفيذ',false,false,'التنفيذ'),
(28,'التحقق من مطابقة الطلب للسياسة','bank_initiatives_mgr','مدير قسم المبادرات ومعاونه',1,'الإجراء: الخطوة 28','تأكيد المطابقة للسياسة وتعليمات المركزي',false,false,'التنفيذ'),
(29,'اعتماد طلب التنفيذ','bank_md','الإدارة العليا للمصرف',1,'الإجراء: الخطوة 29','اعتماد طلب التنفيذ',false,false,'التنفيذ'),
(30,'تسجيل الطلب وأمر الشراء من المورد','bank_ops','قسم العمليات المصرفية',2,'الإجراء: الخطوات 30–33','إصدار أمر الشراء للمورد',false,false,'التنفيذ'),
(31,'التركيب وتوثيق التشغيل','supplier_admin','المورد',14,'ألواح: توثيق بالصورة والفيديو والموقع','اعتماد محضر التركيب وتوثيق التشغيل',false,false,'التنفيذ'),
(32,'الكشف على التركيب واستلام البضاعة','bank_inspection','لجنة الكشف الموقعي',3,'الإجراء: الخطوة 34','تأكيد المطابقة واستلام البضاعة',false,false,'التنفيذ'),
(33,'تنفيذ التمويل وجدول الأقساط','bank_ops','قسم العمليات المصرفية',2,'الإجراء: الخطوتان 34–35','تنفيذ التمويل وإصدار جدول الأقساط',false,false,'التنفيذ'),
(34,'تسليم جدول الأقساط وتوثيق الاستلام','bank_cs','خدمة الزبائن — العمليات الائتمانية',2,'الإجراء: الخطوة 36','تأكيد تسليم الجدول وتوقيع المقترض',true,false,'التنفيذ'),
(35,'صرف المبلغ للمورد','bank_teller','أمين الصندوق',1,'الإجراء: الخطوة 37','صرف المبلغ وتوقيع القيد',true,false,'التنفيذ'),
(36,'تدقيق القيد من مدير الفرع','bank_branch_mgr','مدير الفرع',1,'الإجراء: الخطوة 38','تدقيق القيد والموافقة',true,false,'التنفيذ'),
(37,'حفظ العقود في الخزنة وإغلاق الملف','bank_cs','خدمة الزبائن — العمليات الائتمانية',1,'الإجراء: الخطوة الأخيرة','حفظ العقود وإغلاق الملف',true,false,'التنفيذ');

-- 4) القواعد المالية حسب السياسة (قابلة للتعديل من لوحة المركزي)
update public.settings set value = 0, label = 'عائد سنوي إضافي للبنك المركزي % (لا يوجد — العمولة لمرة واحدة)', circular_no = 'سياسة التمويل' where key = 'cbi_rate';
update public.settings set value = 3.5, label = 'الحد الأعلى لعوائد المصرف السنوية % (متناقصة)', circular_no = 'سياسة التمويل' where key = 'margin_max';
update public.settings set value = 60, label = 'أقصى مدة سداد شاملة مدة السماح (شهر)', circular_no = 'سياسة التمويل' where key = 'term_max_months';
insert into public.settings(key, value, label, circular_no) values
 ('grace_max_months', 12, 'أقصى مدة سماح (شهر)', 'سياسة التمويل'),
 ('cbi_fee_small', 1.5, 'عمولة البنك المركزي لمرة واحدة % حتى 20 مليون — لا تُسترجع', 'سياسة التمويل'),
 ('cbi_fee_large', 2, 'عمولة البنك المركزي لمرة واحدة % فوق 20 مليون — لا تُسترجع', 'سياسة التمويل'),
 ('guarantor_permille', 0.006, 'أرباح الشركة الضامنة سنوياً (بالألف، متناقصة)', 'سياسة التمويل'),
 ('sme_cap', 20000000, 'سقف المشاريع الصغيرة والمتوسطة (دينار)', 'سياسة التمويل'),
 ('batch_cap', 200000000, 'سقف السلفة التجميعية الواحدة (دينار)', 'سياسة التمويل'),
 ('initial_validity_days', 90, 'مهلة إكمال الضمانات وإعلام المركزي من الموافقة المبدئية (يوم)', 'سياسة التمويل'),
 ('execution_window_days', 30, 'مهلة تنفيذ التمويل بعد تعزيز حساب المصرف (يوم)', 'سياسة التمويل'),
 ('late_penalty_pct', 5, 'غرامة عدم التنفيذ خلال 3 أشهر %', 'سياسة التمويل')
on conflict (key) do update set value = excluded.value, label = excluded.label, circular_no = excluded.circular_no;
update public.bank_terms set max_term_months = least(max_term_months, 60), margin = least(margin, 3.5);

-- 5) السلفة التجميعية
create table if not exists public.cbi_batches (
  id uuid primary key default gen_random_uuid(), code text unique not null, bank_id uuid not null references public.orgs(id),
  total bigint not null default 0, apps_count int not null default 0,
  status text not null default 'draft' check (status in ('draft','signed','sent','approved','rejected')),
  letter_ref text, created_by uuid, created_by_name text, signed_by_name text, signed_at timestamptz,
  sent_by_name text, sent_at timestamptz, decided_by_name text, decided_at timestamptz, decision_note text,
  created_at timestamptz default now()
);
alter table public.applications drop constraint if exists applications_batch_fk;
alter table public.applications add constraint applications_batch_fk foreign key (batch_id) references public.cbi_batches(id) on delete set null;
alter table public.cbi_batches enable row level security;
drop policy if exists read_batches on public.cbi_batches;
create policy read_batches on public.cbi_batches for select to authenticated using (bank_id = my_org() or my_portal() in ('cbi','integrity'));

-- 6) السجل الزمني لكل مرحلة (أساس تحليل الأداء)
create table if not exists public.stage_log (
  id bigint generated always as identity primary key,
  application_id uuid not null references public.applications(id) on delete cascade,
  stage int not null, bank_id uuid, branch_id uuid,
  entered_at timestamptz not null default now(), finished_at timestamptz,
  finished_by uuid, finished_by_name text, finished_by_role text,
  outcome text check (outcome in ('done','rejected','cancelled','sent_back')),
  returns int not null default 0, sla_days numeric
);
create index if not exists stage_log_app on public.stage_log(application_id);
create index if not exists stage_log_open on public.stage_log(stage) where finished_at is null;
alter table public.stage_log enable row level security;
drop policy if exists read_stage_log on public.stage_log;
create policy read_stage_log on public.stage_log for select to authenticated using (exists (select 1 from applications a where a.id = application_id));

-- أيام الدوام الفعلي بين وقتين (تُستثنى الجمعة والسبت، بتوقيت بغداد)
create or replace function public._wd(a timestamptz, b timestamptz) returns numeric
language sql stable set search_path = public as $$
  select case when b is null or a is null or b <= a then 0 else coalesce(round((sum(extract(epoch from (
      least(b, (g.d at time zone 'Asia/Baghdad') + interval '1 day') - greatest(a, g.d at time zone 'Asia/Baghdad')))) / 86400.0)::numeric, 2), 0) end
  from generate_series(date_trunc('day', a at time zone 'Asia/Baghdad'), date_trunc('day', b at time zone 'Asia/Baghdad'), interval '1 day') g(d)
  where extract(isodow from g.d) not in (5, 6)
$$;

-- يُسجَّل كل انتقال تلقائياً مهما كان مصدره (المواطن، المحرك، السلفة)
create or replace function public._track_stage() returns trigger
language plpgsql security definer set search_path = public as $$
declare me profiles; oc text; dur numeric; lim numeric;
begin
  if tg_op = 'INSERT' then
    insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days)
    values (new.id, new.stage, new.bank_id, new.branch_id, coalesce(new.created_at, now()), (select sla_days from stages where n = new.stage));
    return new;
  end if;
  select * into me from profiles where id = auth.uid();
  if new.status = 'returned' and old.status is distinct from 'returned' then
    update stage_log set returns = returns + 1 where application_id = new.id and stage = old.stage and finished_at is null;
  end if;
  if new.stage <> old.stage or (new.status <> old.status and new.status in ('completed','rejected','cancelled')) then
    oc := case when new.status = 'completed' then 'done' when new.status = 'rejected' then 'rejected' when new.status = 'cancelled' then 'cancelled'
               when new.stage > old.stage then 'done' else 'sent_back' end;
    update stage_log set finished_at = now(), finished_by = me.id, finished_by_name = me.full_name, finished_by_role = me.role, outcome = oc,
      bank_id = new.bank_id, branch_id = new.branch_id
    where application_id = new.id and stage = old.stage and finished_at is null
    returning _wd(entered_at, finished_at), sla_days into dur, lim;
    -- تأخير يتجاوز ضعف المدة المسموحة ← تنبيه آلي لهيئة النزاهة والمركزي
    if lim > 0 and dur > lim * 2 then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('sla', case when dur > lim * 3 then 'high' else 'medium' end,
        'تأخير في مرحلة «' || (select name from stages where n = old.stage) || '»',
        'استغرقت ' || dur || ' يوم دوام والمسموح ' || lim || '. المنفذ: ' || coalesce(me.full_name, '—'),
        new.id, (select name from orgs where id = new.bank_id));
    end if;
    if new.stage <> old.stage and new.status in ('active','returned') then
      insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days)
      values (new.id, new.stage, new.bank_id, new.branch_id, now(), (select sla_days from stages where n = new.stage));
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_track_stage on public.applications;
create trigger trg_track_stage after insert or update of stage, status on public.applications for each row execute function public._track_stage();

-- 7) صلاحية القراءة: موظفو الفرع يرون طلبات فرعهم فقط (سرية معلومات الزبائن)
drop policy if exists read_apps on public.applications;
create policy read_apps on public.applications for select to authenticated using (
  citizen_id = auth.uid()
  or (my_portal() = 'bank' and bank_id = my_org() and ((select branch_id from profiles where id = auth.uid()) is null or branch_id = (select branch_id from profiles where id = auth.uid())))
  or (my_portal() = 'supplier' and supplier_id = my_org() and stage >= 30)
  or (my_portal() = 'registry' and exists (select 1 from mortgage_referrals m where m.application_id = applications.id))
  or my_portal() in ('cbi','integrity'));

do $$ begin alter publication supabase_realtime add table public.cbi_batches, public.stage_log; exception when duplicate_object then null; end $$;

-- 8) سجل الحدث
create or replace function public._ev(p_app uuid, p_stage int, p_act text, p_note text) returns void
language sql security definer set search_path = public as $$
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  select p_app, p_stage, p_act, p_note, id, full_name, role from profiles where id = auth.uid()
$$;

-- 9) محرك المراحل — بشروط الإجراء والسياسة
create or replace function public.advance_application(p_app uuid, p_action text, p_note text default null)
returns public.applications language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; st stages; ref mortgage_referrals; act text; lim int;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  select * into a from applications where id = p_app for update;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  select * into st from stages where n = a.stage;

  if st.owner_role = 'citizen' then
    if a.citizen_id is distinct from me.id then raise exception 'هذه المرحلة لصاحب الطلب'; end if;
  else
    if me.role <> st.owner_role then raise exception 'هذه المرحلة من صلاحية: %', st.owner_label; end if;
    if me.portal = 'bank' and a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
    if me.portal = 'supplier' and a.supplier_id is distinct from me.org_id then raise exception 'الطلب لا يخص شركتك'; end if;
    if st.branch_level and me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  end if;
  if p_action in ('reject','return') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;

  if p_action = 'reject' then
    if a.cbi_approved_at is not null and a.stage < 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0) where bank_id = a.bank_id;
    end if;
    update applications set status='rejected', updated_at=now() where id=a.id returning * into a; act := 'رفض مسبب';
  elsif p_action = 'return' then
    update applications set status='returned', updated_at=now() where id=a.id returning * into a; act := 'إعادة للاستكمال';
  elsif p_action = 'advance' then
    if st.batch_only then raise exception 'هذه المرحلة تُنجز عبر السلفة التجميعية لا للطلب منفرداً'; end if;
    if a.stage = 9 and a.guarantee_type = 'mortgage' then
      select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
      if ref is null or ref.status not in ('clear','matched','annotated') then raise exception 'الإجراء الأولي للرهن: يلزم تأكيد خلو العقار ومطابقة السند من التسجيل العقاري'; end if;
    end if;
    if a.stage = 14 and a.fees_paid_at is null then raise exception 'أجور الكشف تُستوفى قبل إجراء الكشف (المرحلة 10)'; end if;
    if a.stage = 19 then
      lim := _setting('initial_validity_days')::int;
      if a.initial_approved_at is not null and now() - a.initial_approved_at > make_interval(days => lim) then
        raise exception 'مضت % يوماً على الموافقة المبدئية دون إكمال الضمانات — الموافقة لاغية حسب السياسة، ارفض الطلب مسبباً', lim; end if;
      if a.guarantee_type = 'mortgage' then
        select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
        if ref is null or ref.status <> 'annotated' then raise exception 'الإجراء النهائي للرهن: يلزم تأشير الرهن على السند'; end if;
      end if;
    end if;

    if a.stage = 8 then update applications set initial_approved_at = now() where id = a.id; end if;
    if a.stage = 10 then update applications set fees_paid_at = now() where id = a.id; end if;
    if a.stage = 32 then update applications set inspection_result = 'مطابق' where id = a.id; end if;
    if a.stage = 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0), disbursed = disbursed + a.amount where bank_id = a.bank_id;
    end if;

    if a.stage = 37 then
      update applications set status='completed', updated_at=now() where id=a.id returning * into a;
      act := 'حفظ العقود وإغلاق الملف — اكتمال الطلب';
    else
      update applications set stage = a.stage + 1, status='active', updated_at=now(), bank_unit=(select owner_label from stages where n = a.stage + 1)
      where id=a.id returning * into a;
      act := 'إنجاز: ' || st.name;
    end if;
  else raise exception 'إجراء غير معروف';
  end if;
  perform _ev(a.id, st.n, act, p_note);
  return a;
end $$;

-- 10) الرهن: الإجراء الأولي من الفرع، والنهائي (التأشير) بعد موافقة الإدارة العليا
create or replace function public.refer_mortgage(p_app uuid, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare a applications; me profiles; r mortgage_referrals;
begin
  select * into me from profiles where id=auth.uid();
  select * into a from applications where id=p_app;
  if me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_cs','bank_initiatives','bank_legal') then raise exception 'الإحالة من خدمة الزبائن في الفرع أو قسم المبادرات'; end if;
  if a.property_id is null then raise exception 'لا يوجد عقار مرتبط بالطلب'; end if;
  if exists (select 1 from mortgage_referrals where application_id = a.id and status in ('pending','clear','matched','annotated')) then raise exception 'توجد إحالة قائمة لهذا الطلب'; end if;
  insert into mortgage_referrals(application_id, property_id, bank_id, debt_amount, note) values (a.id, a.property_id, a.bank_id, a.amount, p_note) returning * into r;
  perform _ev(a.id, a.stage, 'إحالة رهن إلى التسجيل العقاري', p_note);
  return r;
end $$;

create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare me profiles; r mortgage_referrals; p properties; act text; newst text; ast int;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  select stage into ast from applications where id = r.application_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك (الإجراء الأولي)';
  elsif p_action='annotate' then
    if r.status <> 'matched' then raise exception 'التأشير بعد المطابقة'; end if;
    if ast < 19 then raise exception 'التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)'; end if;
    newst:='annotated'; act:='تأشير الرهن على السند (الإجراء النهائي)';
    update properties set status='mortgaged' where id=p.id;
    update mortgage_referrals set annotation_no = 'ره-' || to_char(now(),'YYYY') || '-' || lpad((floor(random()*99999))::text,5,'0') where id=r.id;
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then newst:='rejected'; act:='رفض الإحالة';
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now() where id=r.id returning * into r;
  perform _ev(r.application_id, ast, act, p_note);
  return r;
end $$;

-- 11) السلفة التجميعية: إنشاء ← توقيع ← إرسال ← قرار المركزي
create or replace function public.batch_create(p_apps uuid[], p_note text default null) returns public.cbi_batches
language plpgsql security definer set search_path = public as $$
declare me profiles; b cbi_batches; tot bigint; cnt int; bad int; seq int;
begin
  select * into me from profiles where id = auth.uid();
  if me.role <> 'bank_initiatives' then raise exception 'التجميع من إداري قسم المبادرات'; end if;
  if coalesce(array_length(p_apps, 1), 0) = 0 then raise exception 'اختر طلباً واحداً على الأقل'; end if;
  select count(*) filter (where stage <> 20 or status <> 'active' or bank_id is distinct from me.org_id), count(*), coalesce(sum(amount), 0)
    into bad, cnt, tot from applications where id = any(p_apps);
  if cnt <> array_length(p_apps, 1) or bad > 0 then raise exception 'كل الطلبات يجب أن تكون في مرحلة التجميع ولمصرفك'; end if;
  if tot > _setting('batch_cap') then raise exception 'مجموع السلفة % يتجاوز السقف % دينار', to_char(tot, 'FM999,999,999,999'), to_char(_setting('batch_cap'), 'FM999,999,999,999'); end if;
  select count(*) + 1 into seq from cbi_batches where bank_id = me.org_id;
  insert into cbi_batches(code, bank_id, total, apps_count, created_by, created_by_name)
  values (coalesce((select split_part(code, '-', 1) from branches where bank_id = me.org_id order by is_main desc limit 1), 'BNK') || '-ST-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 3, '0'), me.org_id, tot, cnt, me.id, me.full_name)
  returning * into b;
  update applications set batch_id = b.id, stage = 21, updated_at = now(), bank_unit = (select owner_label from stages where n = 21) where id = any(p_apps);
  perform _ev(x, 20, 'إضافة إلى السلفة التجميعية ' || b.code, p_note) from unnest(p_apps) x;
  return b;
end $$;

create or replace function public.batch_action(p_batch uuid, p_action text, p_note text default null) returns public.cbi_batches
language plpgsql security definer set search_path = public as $$
declare me profiles; b cbi_batches; ids uuid[]; act text; avail bigint;
begin
  select * into me from profiles where id = auth.uid();
  select * into b from cbi_batches where id = p_batch for update;
  if b is null then raise exception 'السلفة غير موجودة'; end if;
  select array_agg(id) into ids from applications where batch_id = b.id and status = 'active';
  if p_action = 'dissolve' then
    if me.role <> 'bank_initiatives' or me.org_id <> b.bank_id or b.status <> 'draft' then raise exception 'فك السلفة لإداري المبادرات قبل التوقيع فقط'; end if;
    update applications set batch_id = null, stage = 20, updated_at = now() where batch_id = b.id;
    delete from cbi_batches where id = b.id; act := 'فك السلفة التجميعية ' || b.code;
    perform _ev(x, 21, act, p_note) from unnest(ids) x; return b;
  elsif p_action = 'sign' then
    if me.role <> 'bank_md' or me.org_id <> b.bank_id then raise exception 'التوقيع للإدارة العليا للمصرف'; end if;
    if b.status <> 'draft' then raise exception 'الكتاب موقّع مسبقاً'; end if;
    update cbi_batches set status = 'signed', signed_by_name = me.full_name, signed_at = now(),
      letter_ref = 'ك-' || to_char(now(), 'YYYY') || '-' || lpad((floor(random()*9999))::text, 4, '0') where id = b.id returning * into b;
    update applications set stage = 22, updated_at = now(), bank_unit = (select owner_label from stages where n = 22) where id = any(ids);
    act := 'توقيع كتاب طلب السلفة ' || b.code;
    perform _ev(x, 21, act, p_note) from unnest(ids) x;
  elsif p_action = 'send' then
    if me.role <> 'bank_admin' or me.org_id <> b.bank_id then raise exception 'الإرسال من قسم الإدارة'; end if;
    if b.status <> 'signed' then raise exception 'يُرسل الكتاب بعد توقيعه'; end if;
    update cbi_batches set status = 'sent', sent_by_name = me.full_name, sent_at = now() where id = b.id returning * into b;
    update applications set stage = 23, updated_at = now(), bank_unit = (select owner_label from stages where n = 23) where id = any(ids);
    act := 'إرسال كتاب السلفة إلى البنك المركزي ' || b.code;
    perform _ev(x, 22, act, p_note) from unnest(ids) x;
  elsif p_action in ('approve', 'reject') then
    if me.portal <> 'cbi' then raise exception 'القرار للبنك المركزي'; end if;
    if b.status <> 'sent' then raise exception 'لا يوجد كتاب مرسل بانتظار القرار'; end if;
    if p_action = 'reject' and coalesce(trim(p_note), '') = '' then raise exception 'اكتب أسباب الرفض ليُبلَّغ الفرع'; end if;
    if p_action = 'approve' then
      select allocated - reserved - disbursed into avail from bank_allocations where bank_id = b.bank_id;
      if coalesce(avail, 0) < b.total then raise exception 'حصة المصرف لا تكفي لهذه السلفة'; end if;
      update bank_allocations set reserved = reserved + b.total where bank_id = b.bank_id;
      update cbi_batches set status = 'approved', decided_by_name = me.full_name, decided_at = now(), decision_note = p_note where id = b.id returning * into b;
      update applications set stage = 24, cbi_approved_at = now(), updated_at = now(), bank_unit = (select owner_label from stages where n = 24) where id = any(ids);
      act := 'موافقة البنك المركزي على السلفة ' || b.code;
    else
      update cbi_batches set status = 'rejected', decided_by_name = me.full_name, decided_at = now(), decision_note = p_note where id = b.id returning * into b;
      update applications set stage = 19, status = 'returned', batch_id = null, updated_at = now(), bank_unit = (select owner_label from stages where n = 19) where id = any(ids);
      act := 'رفض البنك المركزي للسلفة ' || b.code || ' — إبلاغ الفرع لإكمال النواقص';
    end if;
    perform _ev(x, 23, act, p_note) from unnest(ids) x;
  else raise exception 'إجراء غير معروف'; end if;
  return b;
end $$;

-- 12) تحليل الأداء
-- نطاق الاطلاع: المركزي والنزاهة على الكل، إدارة المصرف على مصرفها، مدير الفرع على فرعه
create or replace function public._perf_scope(p_bank uuid, out o_bank uuid, out o_branch uuid, out o_all boolean)
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal in ('cbi','integrity') then o_bank := p_bank; o_all := p_bank is null;
  elsif me.portal = 'bank' and me.role in ('bank_md','bank_risk','bank_initiatives_mgr','bank_committee') then o_bank := me.org_id; o_all := false;
  elsif me.portal = 'bank' and me.role = 'bank_branch_mgr' then o_bank := me.org_id; o_branch := me.branch_id; o_all := false;
  else raise exception 'تحليل الأداء لإدارة المصرف والجهات الرقابية — راجع «أدائي»'; end if;
end $$;

create or replace function public.app_timeline(p_app uuid) returns jsonb
language sql stable security invoker set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
    'stage', l.stage, 'name', s.name, 'unit', s.owner_label, 'phase', s.phase, 'sla', s.sla_days,
    'entered_at', l.entered_at, 'finished_at', l.finished_at, 'outcome', l.outcome, 'returns', l.returns,
    'wd', _wd(l.entered_at, coalesce(l.finished_at, now())), 'open', l.finished_at is null,
    'by', case when my_portal() in ('citizen','supplier') then null else l.finished_by_name end
  ) order by l.entered_at, l.id), '[]'::jsonb)
  from stage_log l join stages s on s.n = l.stage where l.application_id = p_app
$$;

create or replace function public.perf_overview(p_bank uuid default null, p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare sc record; res jsonb;
begin
  select * into sc from _perf_scope(p_bank);
  with l as (
    select l.*, _wd(l.entered_at, coalesce(l.finished_at, now())) wd from stage_log l
    where l.stage >= 6 and l.entered_at >= now() - make_interval(days => p_days)
      and (sc.o_bank is null or l.bank_id = sc.o_bank) and (sc.o_branch is null or l.branch_id = sc.o_branch)),
  apps as (
    select a.* from applications a where a.bank_id is not null and a.stage >= 6
      and (sc.o_bank is null or a.bank_id = sc.o_bank) and (sc.o_branch is null or a.branch_id = sc.o_branch)),
  cyc as (
    select a.id, a.bank_id, a.branch_id, _wd(min(l.entered_at), max(l.finished_at)) wd from apps a join stage_log l on l.application_id = a.id and l.stage >= 6
    where a.status = 'completed' group by a.id, a.bank_id, a.branch_id)
  select jsonb_build_object(
    'scope', jsonb_build_object('bank', sc.o_bank, 'branch', sc.o_branch, 'all', sc.o_all, 'days', p_days),
    'totals', jsonb_build_object(
      'apps', (select count(*) from apps), 'completed', (select count(*) from apps where status = 'completed'),
      'active', (select count(*) from apps where status in ('active','returned')),
      'avg_cycle', (select round(avg(wd), 1) from cyc),
      'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 1) from l where finished_at is not null and sla_days > 0),
      'open_overdue', (select count(*) from l where finished_at is null and sla_days > 0 and wd > sla_days),
      'returns', (select coalesce(sum(returns), 0) from l)),
    'stages', (select coalesce(jsonb_agg(x order by x->>'n'), '[]') from (
      select jsonb_build_object('n', lpad(s.n::text, 2, '0'), 'stage', s.n, 'name', s.name, 'unit', s.owner_label, 'phase', s.phase, 'sla', s.sla_days,
        'done', count(l.*) filter (where l.finished_at is not null),
        'avg', round(avg(l.wd) filter (where l.finished_at is not null), 2),
        'max', round(max(l.wd) filter (where l.finished_at is not null), 2),
        'breach_pct', round(100.0 * count(*) filter (where l.finished_at is not null and l.wd > s.sla_days) / nullif(count(*) filter (where l.finished_at is not null), 0), 0),
        'open', count(l.*) filter (where l.finished_at is null),
        'open_overdue', count(l.*) filter (where l.finished_at is null and l.wd > s.sla_days)) x
      from stages s left join l on l.stage = s.n where s.n >= 6 group by s.n) q),
    'branches', (select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'bank', o.name,
        'apps', (select count(*) from apps a where a.branch_id = b.id),
        'avg_cycle', (select round(avg(wd), 1) from cyc where cyc.branch_id = b.id),
        'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 0) from l where l.branch_id = b.id and finished_at is not null and sla_days > 0),
        'open_overdue', (select count(*) from l where l.branch_id = b.id and finished_at is null and sla_days > 0 and wd > sla_days)) order by o.name, b.name), '[]')
      from branches b join orgs o on o.id = b.bank_id where (sc.o_bank is null or b.bank_id = sc.o_bank) and (sc.o_branch is null or b.id = sc.o_branch)),
    'banks', case when sc.o_all then (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name,
        'apps', (select count(*) from apps a where a.bank_id = o.id),
        'completed', (select count(*) from apps a where a.bank_id = o.id and a.status = 'completed'),
        'avg_cycle', (select round(avg(wd), 1) from cyc where cyc.bank_id = o.id),
        'on_time_pct', (select round(100.0 * count(*) filter (where wd <= sla_days) / nullif(count(*), 0), 0) from l where l.bank_id = o.id and finished_at is not null and sla_days > 0),
        'open_overdue', (select count(*) from l where l.bank_id = o.id and finished_at is null and sla_days > 0 and wd > sla_days),
        'cbi_wait', (select round(avg(wd), 1) from l where l.bank_id = o.id and stage = 23)) order by o.name), '[]')
      from orgs o where o.type = 'bank') end
  ) into res;
  return res;
end $$;

-- أداء الموظفين: الإنجاز، المدة، التأخير، الإعادات، العمل خارج الدوام، الخمول، والإنجاز السريع غير المعتاد
create or replace function public._perf_emp_rows(p_bank uuid, p_branch uuid, p_user uuid, p_days int) returns jsonb
language sql stable security definer set search_path = public as $$
  with staff as (
    select p.* from profiles p where p.portal = 'bank' and p.role not in ('bank_risk')
      and (p_bank is null or p.org_id = p_bank) and (p_branch is null or p.branch_id = p_branch) and (p_user is null or p.id = p_user)),
  done as (
    select l.finished_by uid, l.stage, l.finished_at, _wd(l.entered_at, l.finished_at) wd, l.sla_days, a.amount
    from stage_log l join applications a on a.id = l.application_id
    where l.finished_at is not null and l.finished_at >= now() - make_interval(days => p_days) and l.outcome in ('done','rejected')),
  ev as (
    select e.actor_id uid, e.action, e.created_at from application_events e where e.created_at >= now() - make_interval(days => p_days)),
  queue as (  -- ما ينتظر وحدة الموظف وفرعه الآن
    select st.id uid, count(*) open_items, count(*) filter (where _wd(l.entered_at, now()) > l.sla_days and l.sla_days > 0) overdue
    from staff st join stages s on s.owner_role = st.role
    join stage_log l on l.stage = s.n and l.finished_at is null and l.bank_id = st.org_id and (not s.branch_level or st.branch_id is null or l.branch_id = st.branch_id)
    group by st.id),
  m as (
    select st.id, st.full_name, st.role, st.branch_id, (select name from branches where id = st.branch_id) branch, (select name from orgs where id = st.org_id) bank,
      (select count(*) from done d where d.uid = st.id) actions,
      (select round(avg(wd), 2) from done d where d.uid = st.id) avg_wd,
      (select count(*) from done d where d.uid = st.id and d.sla_days > 0 and d.wd > d.sla_days) breaches,
      (select count(*) from done d where d.uid = st.id and d.wd < 0.02 and d.amount >= 10000000) fast_big,
      (select count(*) from ev where ev.uid = st.id and ev.action like 'إعادة%') returns_made,
      (select count(*) from ev where ev.uid = st.id and ev.action like 'رفض%') rejections,
      (select count(*) from ev where ev.uid = st.id and (extract(hour from ev.created_at at time zone 'Asia/Baghdad') not between 8 and 15
          or extract(isodow from ev.created_at at time zone 'Asia/Baghdad') in (5, 6))) after_hours,
      (select max(created_at) from ev where ev.uid = st.id) last_action,
      coalesce(q.open_items, 0) open_items, coalesce(q.overdue, 0) unit_overdue
    from staff st left join queue q on q.uid = st.id)
  select coalesce(jsonb_agg(to_jsonb(m) || jsonb_build_object(
      'breach_pct', case when actions > 0 then round(100.0 * breaches / actions) end,
      'idle_days', case when last_action is null then null else _wd(last_action, now()) end,
      'flags', to_jsonb(array_remove(array[
        case when actions >= 3 and breaches * 100.0 / actions >= 40 then 'تأخير متكرر' end,
        case when unit_overdue > 0 and (last_action is null or _wd(last_action, now()) >= 3) then 'خمول مع معاملات متأخرة بانتظاره' end,
        case when unit_overdue > 0 then 'معاملات متجاوزة للمدة في وحدته' end,
        case when after_hours >= 2 then 'إجراءات خارج أوقات الدوام' end,
        case when fast_big >= 2 then 'موافقات خلال دقائق على مبالغ كبيرة' end,
        case when actions >= 4 and returns_made * 1.0 / actions > 0.3 then 'نسبة إعادة مرتفعة' end], null))
    ) order by bank, branch nulls first, role, full_name), '[]')
  from m
$$;

create or replace function public.perf_employees(p_bank uuid default null, p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare sc record;
begin
  select * into sc from _perf_scope(p_bank);
  return _perf_emp_rows(sc.o_bank, sc.o_branch, null, p_days);
end $$;

create or replace function public.perf_me(p_days int default 120) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'bank' then raise exception 'للموظفين فقط'; end if;
  return coalesce(_perf_emp_rows(me.org_id, null, me.id, p_days)->0, '{}'::jsonb);
end $$;

revoke all on function public._track_stage(), public._ev(uuid,int,text,text), public._perf_scope(uuid), public._perf_emp_rows(uuid,uuid,uuid,int) from public, anon, authenticated;
grant execute on function public._wd(timestamptz, timestamptz) to authenticated;
grant execute on function public.advance_application, public.refer_mortgage, public.registry_action, public.batch_create, public.batch_action,
  public.app_timeline, public.perf_overview, public.perf_employees, public.perf_me to authenticated;

-- 13) عند إرسال المواطن طلبه للمصرف: يُسند إلى الفرع (حسب المحافظة) وتُحسب عمولة المركزي لمرة واحدة
--     (بمشغّل قبل الحفظ، دون تعديل دالة citizen_step)
create or replace function public._assign_branch() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.bank_id is not null and (new.branch_id is null or (select bank_id from branches where id = new.branch_id) is distinct from new.bank_id) then
    new.branch_id := (select b.id from branches b where b.bank_id = new.bank_id order by (new.governorate = any(b.governorates)) desc, b.is_main desc limit 1);
  end if;
  if new.stage >= 6 and new.cbi_fee is null and new.amount is not null then
    new.cbi_fee := round(new.amount * case when new.amount <= _setting('sme_cap') then _setting('cbi_fee_small') else _setting('cbi_fee_large') end / 100);
  end if;
  return new;
end $$;
drop trigger if exists trg_assign_branch on public.applications;
create trigger trg_assign_branch before insert or update of bank_id, stage on public.applications for each row execute function public._assign_branch();
revoke all on function public._assign_branch() from public, anon, authenticated;

-- 14) تقييم المواطن بعد الكشف على التركيب واستلامه (المرحلة 32) بدل المرحلة 12 القديمة
create or replace function public.submit_review(p_app uuid, p_rating integer, p_quality integer, p_install integer, p_service integer, p_comment text)
 returns offer_reviews language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; r offer_reviews;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if not (a.status = 'completed' or a.stage >= 32) then raise exception 'التقييم بعد تركيب المنظومة وتشغيلها'; end if;
  if exists (select 1 from offer_reviews where application_id = a.id) then raise exception 'قيّمت هذه المنظومة مسبقاً'; end if;
  if p_rating not between 1 and 5 then raise exception 'اختر من 1 إلى 5 نجوم'; end if;
  insert into offer_reviews(offer_id, supplier_id, application_id, citizen_id, author_name, governorate, rating, quality, install, service, comment)
  values (a.offer_id, a.supplier_id, a.id, me.id, me.full_name, a.governorate, p_rating, p_quality, p_install, p_service, nullif(trim(p_comment), ''))
  returning * into r;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, 'تقييم المواطن للمنظومة', p_rating || ' من 5', me.id, me.full_name, me.role);
  return r;
end $function$;


-- ════════════ بيانات العرض ════════════

-- ألواح — الجلسة 4: بيانات العرض للمراحل الجديدة (الفروع، الموظفون الجدد، السجل الزمني الكامل لكل طلب)
-- كل الأسماء وهمية. يُعاد بناء أحداث الطلبات التجريبية فقط؛ أحداث الطلبات التي أنشأها مستخدمون حقيقيون تُحفظ كما هي.

-- 1) الفروع
insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone) values
((select id from orgs where code='bank1'),'SNB-01','الفرع الرئيسي — بغداد','{بغداد,ديالى,الأنبار,صلاح الدين,واسط,نينوى,كركوك,أربيل,السليمانية,دهوك,بابل,القادسية,الديوانية}',true,'07700100101'),
((select id from orgs where code='bank1'),'SNB-02','فرع البصرة','{البصرة,ذي قار,ميسان,المثنى}',false,'07700100102'),
((select id from orgs where code='bank2'),'WAH-01','الفرع الرئيسي — بغداد','{بغداد,ديالى,الأنبار,صلاح الدين,واسط,نينوى,كركوك,أربيل,السليمانية,دهوك,البصرة,ذي قار,ميسان}',true,'07700200201'),
((select id from orgs where code='bank2'),'WAH-02','فرع النجف','{النجف,كربلاء,بابل,القادسية,الديوانية,المثنى}',false,'07700200202'),
((select id from orgs where code='bank3'),'DJL-01','الفرع الرئيسي — بغداد','{}',true,'07700300301')
on conflict (code) do nothing;

-- 2) الموظفون: مسميات المراحل الجديدة وأسماء وهمية
update profiles set full_name = 'كرار نعمة — التحصيل والمتابعة' where username = 'snb.collect';
update profiles set full_name = 'رواء صباح — التحصيل والمتابعة' where username = 'wah.collect';
update profiles set full_name = 'زيد رياض — الامتثال وفتح الحسابات' where username = 'wah.compliance';
update profiles set full_name = 'مصطفى ناظم — الامتثال وفتح الحسابات' where username = 'snb.compliance';
update profiles set full_name = 'شهد عادل — ائتمان المبادرات' where username = 'wah.credit';
update profiles set full_name = 'دعاء فلاح — ائتمان المبادرات' where username = 'snb.credit';
update profiles set full_name = 'د. عمار ثامر — اللجنة الائتمانية العليا' where username = 'wah.committee';
update profiles set full_name = 'د. سلام هادي — اللجنة الائتمانية العليا' where username = 'snb.committee';
update profiles set full_name = 'رسل عباس — خدمة الزبائن', branch_id = (select id from branches where code='SNB-01') where username = 'snb.cs';
update profiles set full_name = 'سجى ماجد — خدمة الزبائن', branch_id = (select id from branches where code='WAH-01') where username = 'wah.cs';

do $$
declare r record;
begin
  for r in select * from (values
    ('snb.cs2','Snb@2026c2','لمى سالم — خدمة الزبائن','bank_cs','bank1','SNB-02'),
    ('snb.branch','Snb@2026br','قيصر عدنان — مدير الفرع الرئيسي','bank_branch_mgr','bank1','SNB-01'),
    ('snb.branch2','Snb@2026b2','منتظر كاظم — مدير فرع البصرة','bank_branch_mgr','bank1','SNB-02'),
    ('snb.teller','Snb@2026tl','سرى منذر — أمين الصندوق','bank_teller','bank1','SNB-01'),
    ('snb.teller2','Snb@2026t2','ميثم جليل — أمين الصندوق','bank_teller','bank1','SNB-02'),
    ('snb.init','Snb@2026in','تبارك ليث — إداري قسم المبادرات','bank_initiatives','bank1',null),
    ('snb.initmgr','Snb@2026im','أنمار رعد — مدير قسم المبادرات','bank_initiatives_mgr','bank1',null),
    ('snb.md','Snb@2026md','د. وسام ثامر — الإدارة العليا','bank_md','bank1',null),
    ('snb.inspect','Snb@2026ks','م. ديار شوكت — لجنة الكشف الموقعي','bank_inspection','bank1',null),
    ('snb.admin','Snb@2026ad','بان صلاح — قسم الإدارة','bank_admin','bank1',null),
    ('wah.cs2','Wah@2026c2','نبأ عصمت — خدمة الزبائن','bank_cs','bank2','WAH-02'),
    ('wah.branch','Wah@2026br','سيف عامر — مدير الفرع الرئيسي','bank_branch_mgr','bank2','WAH-01'),
    ('wah.branch2','Wah@2026b2','آية مروان — مديرة فرع النجف','bank_branch_mgr','bank2','WAH-02'),
    ('wah.teller','Wah@2026tl','كرار حامد — أمين الصندوق','bank_teller','bank2','WAH-01'),
    ('wah.teller2','Wah@2026t2','ياسمين طلال — أمينة الصندوق','bank_teller','bank2','WAH-02'),
    ('wah.init','Wah@2026in','رنا جاسم — إداري قسم المبادرات','bank_initiatives','bank2',null),
    ('wah.initmgr','Wah@2026im','مهند رافد — مدير قسم المبادرات','bank_initiatives_mgr','bank2',null),
    ('wah.md','Wah@2026md','د. لؤي سامي — الإدارة العليا','bank_md','bank2',null),
    ('wah.inspect','Wah@2026ks','م. زينة فؤاد — لجنة الكشف الموقعي','bank_inspection','bank2',null),
    ('wah.admin','Wah@2026ad','أوس ناجي — قسم الإدارة','bank_admin','bank2',null),
    ('djl.cs','Djl@2026cs','رغد حازم — خدمة الزبائن','bank_cs','bank3','DJL-01'),
    ('djl.compliance','Djl@2026co','نمير صادق — الامتثال وفتح الحسابات','bank_compliance','bank3',null),
    ('djl.branch','Djl@2026br','جنان وليد — مديرة الفرع الرئيسي','bank_branch_mgr','bank3','DJL-01'),
    ('djl.init','Djl@2026in','سلوان مثنى — إداري قسم المبادرات','bank_initiatives','bank3',null),
    ('djl.credit','Djl@2026cr','هالة ضرغام — ائتمان المبادرات','bank_credit','bank3',null),
    ('djl.inspect','Djl@2026ks','م. حارث نبيل — لجنة الكشف الموقعي','bank_inspection','bank3',null),
    ('djl.initmgr','Djl@2026im','ريام ستار — مديرة قسم المبادرات','bank_initiatives_mgr','bank3',null),
    ('djl.legal','Djl@2026lg','م. بشرى قحطان — القسم القانوني','bank_legal','bank3',null),
    ('djl.md','Djl@2026md','د. ثائر مجيد — الإدارة العليا','bank_md','bank3',null),
    ('djl.admin','Djl@2026ad','تيسير عادل — قسم الإدارة','bank_admin','bank3',null),
    ('djl.ops','Djl@2026op','شيماء رحيم — العمليات المصرفية','bank_ops','bank3',null),
    ('djl.teller','Djl@2026tl','غسان فيصل — أمين الصندوق','bank_teller','bank3','DJL-01')
  ) t(u, pw, nm, rl, org, br) loop
    if not exists (select 1 from profiles where username = r.u) then
      perform _mk_user(r.u, r.pw, r.nm, r.rl, 'bank', r.org);
    end if;
    update profiles set branch_id = (select id from branches where code = r.br) where username = r.u;
  end loop;
end $$;

-- 3) إعادة بناء السجل الزمني للطلبات التجريبية
create or replace function pg_temp.worktime(t timestamptz, after_hours boolean) returns timestamptz language plpgsql as $$
declare l timestamp := t at time zone 'Asia/Baghdad'; h int;
begin
  if after_hours then l := date_trunc('day', l) + interval '21 hours' + (random() * 50) * interval '1 minute';
  else
    h := extract(hour from l);
    if h < 8 then l := date_trunc('day', l) + interval '8 hours 30 minutes' + (random() * 60) * interval '1 minute';
    elsif h >= 15 then l := date_trunc('day', l) + interval '1 day 9 hours' + (random() * 90) * interval '1 minute'; end if;
  end if;
  while extract(isodow from l) in (5, 6) loop l := l + interval '1 day'; end loop;
  if extract(isodow from l) = 7 and not after_hours and extract(hour from l) not between 8 and 14 then l := date_trunc('day', l) + interval '10 hours'; end if;
  return l at time zone 'Asia/Baghdad';
end $$;

create or replace function pg_temp.actor(p_bank uuid, p_branch uuid, p_role text, p_supplier uuid, p_citizen uuid) returns profiles language sql as $$
  select * from profiles where
    case when p_role = 'citizen' then id = p_citizen
         when p_role = 'supplier_admin' then org_id = p_supplier and role = p_role
         when p_role = 'cbi_admin' then role = 'cbi_admin'
         else org_id = p_bank and role = p_role and (branch_id is null or branch_id = p_branch or p_branch is null) end
  order by (branch_id = p_branch) desc nulls last, username limit 1
$$;

do $$
declare
  a record; s record; me profiles; t timestamptz; fin timestamptz; d numeric; plan numeric[]; tot numeric; sc numeric; i int;
  tgt int; fstat text; open_age numeric; keep uuid[]; act text; fac numeric; ah boolean; br uuid; b cbi_batches; seq int := 0; ret boolean;
begin
  perform setseed(0.4242);
  alter table applications disable trigger trg_track_stage;
  alter table applications disable trigger trg_assign_branch;

  -- طلبات أنشأها مستخدمون حقيقيون (لا تُمس أحداثها)
  select coalesce(array_agg(a2.id), '{}') into keep from applications a2 join profiles p on p.id = a2.citizen_id where p.self_registered;

  create temp table ev_new (application_id uuid, stage int, action text, note text, actor_id uuid, actor_name text, actor_role text, created_at timestamptz) on commit drop;
  insert into ev_new select application_id, stage, action, note, actor_id, actor_name, actor_role, created_at from application_events where application_id = any(keep);
  delete from application_events;
  delete from stage_log; update applications set batch_id = null; delete from cbi_batches;
  delete from integrity_alerts where type in ('sla','behavior');

  -- الإسناد للفروع
  update applications x set branch_id = (select bb.id from branches bb where bb.bank_id = x.bank_id order by (x.governorate = any(bb.governorates)) desc, bb.is_main desc limit 1)
  where bank_id is not null;

  -- الهدف لكل طلب: المرحلة الحالية والحالة
  create temp table tg (code text, target int, st text, age numeric) on commit drop;
  insert into tg values
    ('ALW-2026-00030',23,'active',6), ('ALW-2026-00031',20,'active',2.5), ('ALW-2026-00032',31,'active',5),
    ('ALW-2026-00033',25,'active',1.2), ('ALW-2026-00034',14,'active',4), ('ALW-2026-00035',19,'active',3),
    ('ALW-2026-00036',6,'returned',3), ('ALW-2026-00037',11,'active',12), ('ALW-2026-00038',15,'rejected',0),
    ('ALW-2026-00101',6,'active',0.6), ('ALW-2026-00102',9,'active',2), ('ALW-2026-00103',16,'active',1.5);
  insert into tg select code, 37, 'completed', 0 from applications where status = 'completed' and code not in (select code from tg);

  for a in select x.*, tg.target, tg.st, tg.age from applications x join tg on tg.code = x.code where not (x.id = any(keep)) order by x.created_at loop
    tgt := a.target; fstat := a.st;
    -- مدة كل مرحلة (أيام تقويمية)
    plan := '{}'; tot := 0;
    for s in select * from stages order by n loop
      exit when s.n > tgt or (s.n = tgt and fstat <> 'completed' and fstat <> 'rejected');
      me := pg_temp.actor(a.bank_id, a.branch_id, s.owner_role, a.supplier_id, a.citizen_id);
      fac := 1;
      if me.username = 'snb.cs2' then fac := 2.7; end if;
      if me.username = 'snb.branch2' then fac := 2.3; end if;
      if me.username = 'wah.legal' then fac := 2.2; end if;
      if me.username = 'djl.inspect' then fac := 1.8; end if;
      d := case when s.n <= 5 then (0.01 + random() * 0.15)
                when s.n = 23 then 4 + random() * 9
                when s.n = 31 then 3 + random() * 8
                when me.username = 'wah.md' then 0.004 + random() * 0.008
                else greatest(0.04, s.sla_days * (0.15 + random() * 0.55) * fac * 1.2) end;
      plan := plan || d; tot := tot + d;
    end loop;

    if fstat = 'completed' then
      t := a.created_at;
      sc := least(1, extract(epoch from (now() - interval '2 days' - t)) / 86400 / greatest(tot, 0.1));
    else
      sc := 1;
      -- هامش لأيام العطل وانتقال المعاملة لليوم التالي بعد انتهاء الدوام
      t := now() - make_interval(secs => ((tot * 1.12 + greatest(tgt - 6, 0) * 0.35 + a.age) * 86400)::int);
    end if;
    update applications set created_at = t where id = a.id;
    insert into ev_new values (a.id, 1, 'بدء طلب تمويل جديد من الكتالوج', null, a.citizen_id, a.citizen_name, 'citizen', t);

    i := 0;
    for s in select * from stages order by n loop
      exit when s.n > tgt;
      me := pg_temp.actor(a.bank_id, a.branch_id, s.owner_role, a.supplier_id, a.citizen_id);
      if s.n = tgt and fstat in ('active','returned') then
        insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, sla_days, returns)
        values (a.id, s.n, a.bank_id, a.branch_id, t, s.sla_days, case when fstat = 'returned' then 1 else 0 end);
        if fstat = 'returned' then
          insert into ev_new values (a.id, s.n, 'إعادة للاستكمال', 'نقص في المستمسكات: بطاقة السكن غير مرفقة، واستمارة المتطلبات غير موقعة',
            me.id, coalesce(me.full_name, '—'), s.owner_role, pg_temp.worktime(t + interval '5 hours', false));
        end if;
        exit;
      end if;
      i := i + 1;
      ah := me.username = 'snb.ops' and random() < 0.6;
      fin := t + make_interval(secs => (plan[i] * sc * 86400)::int);
      if s.n > 5 and me.username <> 'wah.md' then fin := pg_temp.worktime(fin, ah); end if;
      if fin <= t then fin := t + interval '7 minutes'; end if;
      ret := s.n > 5 and s.owner_role like 'bank_%' and random() < 0.04;
      if ret then
        insert into ev_new values (a.id, s.n, 'إعادة للاستكمال', 'استكمال نقص في الإضبارة', me.id, me.full_name, me.role, least(pg_temp.worktime(t + (fin - t) / 3, false), fin - interval '5 minutes'));
      end if;
      act := case s.n when 1 then 'التحقق من الهوية بالسيلفي' when 2 then 'ربط رقم «أور» وتأكيده برمز التحقق' when 3 then 'تثبيت العرض المختار'
        when 4 then case when a.guarantee_type = 'mortgage' then 'تأكيد الضمان: رهن عقار' else 'تأكيد الضمان وموافقة الكفلاء' end
        when 5 then 'اختيار المصرف وتوقيع الطلب إلكترونياً'
        else case when s.n = tgt and fstat = 'rejected' then 'رفض مسبب' when s.n = 37 then 'حفظ العقود وإغلاق الملف — اكتمال الطلب' else 'إنجاز: ' || s.name end end;
      insert into stage_log(application_id, stage, bank_id, branch_id, entered_at, finished_at, finished_by, finished_by_name, finished_by_role, outcome, returns, sla_days)
      values (a.id, s.n, case when s.n > 5 then a.bank_id end, case when s.n > 5 then a.branch_id end, t, fin, me.id, coalesce(me.full_name, a.citizen_name), s.owner_role,
        case when s.n = tgt and fstat = 'rejected' then 'rejected' else 'done' end, case when ret then 1 else 0 end, s.sla_days);
      insert into ev_new values (a.id, s.n, act,
        case when s.n = tgt and fstat = 'rejected' then 'الدراسة الائتمانية: القسط يتجاوز 40% من دخل المتقدم والكفيل غير مستوفٍ لشرط الخدمة' end,
        me.id, coalesce(me.full_name, a.citizen_name), s.owner_role, fin);
      if s.n = 8 then update applications set initial_approved_at = fin where id = a.id; end if;
      if s.n = 10 then update applications set fees_paid_at = fin where id = a.id; end if;
      if s.n = 23 then update applications set cbi_approved_at = fin where id = a.id; end if;
      t := fin;
    end loop;

    -- إن تجاوز آخر حدث الوقت الحالي (بسبب أيام العطل) يُزاح السجل كله بأسابيع كاملة للحفاظ على أيام الدوام وساعاته
    if t > now() - make_interval(secs => (a.age * 0.3 * 86400)::int) - interval '10 minutes' then
      fac := ceil(extract(epoch from (t - (now() - make_interval(secs => (a.age * 0.3 * 86400)::int) - interval '10 minutes'))) / 604800.0);
      update stage_log set entered_at = entered_at - fac * interval '7 days', finished_at = finished_at - fac * interval '7 days' where application_id = a.id;
      update ev_new set created_at = created_at - fac * interval '7 days' where application_id = a.id;
      update applications set created_at = created_at - fac * interval '7 days',
        initial_approved_at = initial_approved_at - fac * interval '7 days', fees_paid_at = fees_paid_at - fac * interval '7 days',
        cbi_approved_at = cbi_approved_at - fac * interval '7 days' where id = a.id;
      t := t - fac * interval '7 days';
    end if;
    update applications set stage = tgt, status = fstat, updated_at = t, bank_unit = (select owner_label from stages where n = tgt),
      inspection_result = case when tgt >= 33 then 'مطابق' end,
      cbi_fee = case when bank_id is not null then round(amount * case when amount <= 20000000 then 1.5 else 2 end / 100) end,
      margin = least(coalesce(margin, 2), 3.5), term_months = least(coalesce(term_months, 60), 60)
    where id = a.id;
  end loop;

  -- طلبات المستخدمين الحقيقيين: سجلها الزمني من أحداثها
  for a in select * from applications where id = any(keep) loop
    t := a.created_at;
    for s in select e.stage, max(e.created_at) fat, (array_agg(e.actor_name order by e.created_at desc))[1] nm, (array_agg(e.actor_id order by e.created_at desc))[1] uid
             from ev_new e where e.application_id = a.id and e.stage < a.stage group by e.stage order by e.stage loop
      insert into stage_log(application_id, stage, entered_at, finished_at, finished_by, finished_by_name, finished_by_role, outcome, sla_days)
      values (a.id, s.stage, t, s.fat, s.uid, s.nm, 'citizen', 'done', 0);
      t := s.fat;
    end loop;
    insert into stage_log(application_id, stage, entered_at, sla_days) values (a.id, a.stage, t, 0);
  end loop;

  -- السلف التجميعية التاريخية (لكل طلب تجاوز المرحلة 20)
  for a in select x.*, l20.finished_at f20, l21.finished_at f21, l22.finished_at f22, l23.finished_at f23,
             l21.finished_by_name n21, l22.finished_by_name n22, l23.finished_by_name n23, l20.finished_by_name n20
           from applications x join stage_log l20 on l20.application_id = x.id and l20.stage = 20 and l20.finished_at is not null
           left join stage_log l21 on l21.application_id = x.id and l21.stage = 21
           left join stage_log l22 on l22.application_id = x.id and l22.stage = 22
           left join stage_log l23 on l23.application_id = x.id and l23.stage = 23
           order by l20.finished_at loop
    seq := seq + 1;
    insert into cbi_batches(code, bank_id, total, apps_count, status, letter_ref, created_by_name, created_at, signed_by_name, signed_at, sent_by_name, sent_at, decided_by_name, decided_at)
    values ((select split_part(code, '-', 1) from branches where bank_id = a.bank_id order by is_main desc limit 1) || '-ST-2026-' || lpad(seq::text, 3, '0'),
      a.bank_id, a.amount, 1, case when a.f23 is not null then 'approved' when a.f22 is not null then 'sent' when a.f21 is not null then 'signed' else 'draft' end,
      'ك-2026-' || lpad((1000 + seq * 7)::text, 4, '0'), a.n20, a.f20, a.n21, a.f21, a.n22, a.f22, a.n23, a.f23)
    returning * into b;
    update applications set batch_id = b.id where id = a.id;
  end loop;

  -- الرهن: 00102 في الإجراء الأولي (يحيله موظف خدمة الزبائن)، و00035 جاهز للتأشير النهائي
  update mortgage_referrals set status = 'pending', annotation_no = null, updated_at = now(), created_at = now() - interval '1 day'
  where application_id = (select id from applications where code = 'ALW-2026-00102');
  update properties set status = 'free' where id in (select property_id from applications where code in ('ALW-2026-00102','ALW-2026-00035'));
  insert into mortgage_referrals(application_id, property_id, bank_id, status, debt_amount, note, created_at, updated_at)
  select id, property_id, bank_id, 'matched', amount, 'الإجراء الأولي مكتمل — بانتظار التأشير النهائي', now() - interval '12 days', now() - interval '9 days'
  from applications where code = 'ALW-2026-00035' and property_id is not null
    and not exists (select 1 from mortgage_referrals m where m.application_id = applications.id);

  -- دفتر الحصص: المحجوز = طلبات وافق عليها المركزي ولم تُصرف، المصروف = المكتملة
  update bank_allocations ba set
    reserved = coalesce((select sum(amount) from applications x where x.bank_id = ba.bank_id and x.status = 'active' and x.stage between 24 and 35), 0),
    disbursed = coalesce((select sum(amount) from applications x where x.bank_id = ba.bank_id and x.status = 'completed'), 0);

  -- الأحداث بترتيبها الزمني لتتسلسل البصمات
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role, created_at)
  select application_id, stage, action, note, actor_id, actor_name, actor_role, created_at from ev_new order by created_at;

  -- تنبيهات التأخير الكبير (أكثر من ضعفين ونصف المدة)
  insert into integrity_alerts(type, severity, title, details, application_id, entity, created_at)
  select 'sla', case when _wd(l.entered_at, l.finished_at) > l.sla_days * 3 then 'high' else 'medium' end,
    'تأخير في مرحلة «' || stg.name || '»',
    'استغرقت ' || _wd(l.entered_at, l.finished_at) || ' يوم دوام والمسموح ' || l.sla_days || '. المنفذ: ' || coalesce(l.finished_by_name, '—'),
    l.application_id, (select name from orgs where id = l.bank_id), l.finished_at
  from stage_log l join stages stg on stg.n = l.stage
  where l.finished_at is not null and l.sla_days > 0 and _wd(l.entered_at, l.finished_at) > l.sla_days * 2.5;

  insert into integrity_alerts(type, severity, title, details, entity, created_at) values
  ('behavior','high','موافقات خلال دقائق على مبالغ كبيرة','الإدارة العليا في أحد المصارف تعتمد طلبات تتجاوز 10 ملايين دينار خلال أقل من 15 دقيقة من وصولها، دون وقت كافٍ لمراجعة الدراسة والقرار القانوني.',(select name from orgs where code='bank2'), now() - interval '2 days'),
  ('behavior','medium','إجراءات تنفيذ خارج أوقات الدوام','قسم العمليات المصرفية في أحد المصارف نفّذ أوامر شراء وتنفيذ تمويل بعد الساعة التاسعة مساءً في عدة معاملات.',(select name from orgs where code='bank1'), now() - interval '3 days'),
  ('behavior','medium','تأخير متكرر في استقبال المستمسكات','خدمة الزبائن في أحد الفروع تتجاوز المدة المسموحة لتدقيق المستمسكات في أغلب المعاملات، مع معاملات متوقفة لدى مدير الفرع نفسه.',(select name from orgs where code='bank1'), now() - interval '1 day');

  alter table applications enable trigger trg_track_stage;
  alter table applications enable trigger trg_assign_branch;
end $$;


-- ════════════ الدفع والمستندات والتواقيع ════════════

-- ألواح — الجلسة 4 (ب): الدفع قبل الإرسال، سند العقار بكاميرا الهاتف، إقرار الملكية ومطابقتها،
-- رفض التأشير بأسباب موثقة ودليل، ورمز تعريفي لكل موظف يرافق كل إجراء بمثابة التوقيع والختم.

-- ═══ 1) رمز الموظف ومنصبه ═══
alter table public.profiles add column if not exists staff_code text, add column if not exists position_title text;
create unique index if not exists profiles_staff_code_uq on public.profiles(staff_code) where staff_code is not null;

create or replace function public._role_abbr(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' else 'XX' end $$;
create or replace function public._role_title(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض' else r end $$;

-- يُمنح كل موظف رمزاً ثابتاً لا يتكرر: بادئة الجهة ـ الوظيفة ـ رقم
create or replace function public._staff_prefix(p_org uuid) returns text language sql stable set search_path = public as $$
  select coalesce((select split_part(code, '-', 1) from branches where bank_id = p_org order by is_main desc limit 1), upper((select code from orgs where id = p_org)), 'ALW')
$$;
create or replace function public._assign_staff_code() returns trigger language plpgsql security definer set search_path = public as $$
declare pre text; n int;
begin
  if new.portal = 'citizen' then return new; end if;
  new.position_title := _role_title(new.role) || coalesce(' — ' || (select name from branches where id = new.branch_id), '');
  if new.staff_code is null then
    pre := _staff_prefix(new.org_id) || '-' || _role_abbr(new.role) || '-';
    select coalesce(max(substring(staff_code from length(pre) + 1)::int), 0) + 1 into n from profiles where staff_code like pre || '%';
    new.staff_code := pre || lpad(n::text, 3, '0');
  end if;
  return new;
end $$;
drop trigger if exists trg_staff_code on public.profiles;
create trigger trg_staff_code before insert or update of role, branch_id, org_id on public.profiles for each row execute function public._assign_staff_code();
-- تعبئة الموجودين برقم تسلسلي حسب اسم المستخدم
with x as (select id, _staff_prefix(org_id) || '-' || _role_abbr(role) || '-' pre, username from profiles where portal <> 'citizen' and staff_code is null),
y as (select id, pre || lpad((row_number() over (partition by pre order by username))::text, 3, '0') code from x)
update public.profiles p set staff_code = y.code, position_title = _role_title(p.role) || coalesce(' — ' || (select name from branches where id = p.branch_id), '')
from y where y.id = p.id;

-- ═══ 2) توقيع كل إجراء: المنصب ظاهر لكل من يرى المعاملة، والرمز والختم للمخوّلين فقط ═══
alter table public.application_events add column if not exists actor_title text;
create table if not exists public.event_signatures (
  event_id bigint primary key references public.application_events(id) on delete cascade,
  application_id uuid not null, actor_id uuid, actor_code text, actor_title text, seal text not null, signed_at timestamptz default now()
);
alter table public.event_signatures enable row level security;
drop policy if exists read_signatures on public.event_signatures;
create policy read_signatures on public.event_signatures for select to authenticated using (
  actor_id = auth.uid()
  or my_portal() in ('cbi','integrity')
  or (my_portal() = 'bank' and my_role() in ('bank_md','bank_risk','bank_branch_mgr','bank_initiatives_mgr','bank_committee')
      and exists (select 1 from applications a where a.id = application_id and a.bank_id = my_org())));

create or replace function public._sign_event() returns trigger language plpgsql security definer set search_path = public, extensions as $$
declare p profiles;
begin
  select * into p from profiles where id = new.actor_id;
  if new.actor_title is null then new.actor_title := _role_title(coalesce(p.role, new.actor_role)) || coalesce(' — ' || (select name from branches where id = p.branch_id), ''); end if;
  return new;
end $$;
create or replace function public._seal_event() returns trigger language plpgsql security definer set search_path = public, extensions as $$
declare c text;
begin
  select staff_code into c from profiles where id = new.actor_id;
  insert into event_signatures(event_id, application_id, actor_id, actor_code, actor_title, seal, signed_at)
  values (new.id, new.application_id, new.actor_id, c, new.actor_title,
    upper(substr(encode(extensions.digest(coalesce(c, 'CITIZEN') || '|' || new.hash, 'sha256'), 'hex'), 1, 16)), new.created_at)
  on conflict (event_id) do nothing;
  return new;
end $$;
drop trigger if exists trg_a_title on public.application_events;
create trigger trg_a_title before insert on public.application_events for each row execute function public._sign_event();
drop trigger if exists trg_seal on public.application_events;
create trigger trg_seal after insert on public.application_events for each row execute function public._seal_event();
update public.application_events e set actor_title = _role_title(coalesce(p.role, e.actor_role)) || coalesce(' — ' || (select name from branches where id = p.branch_id), '')
from (select id, role, branch_id from profiles) p where p.id = e.actor_id and e.actor_title is null;
update public.application_events set actor_title = _role_title(actor_role) where actor_title is null;
insert into public.event_signatures(event_id, application_id, actor_id, actor_code, actor_title, seal, signed_at)
select e.id, e.application_id, e.actor_id, p.staff_code, e.actor_title,
  upper(substr(encode(extensions.digest(coalesce(p.staff_code, 'CITIZEN') || '|' || coalesce(e.hash, ''), 'sha256'), 'hex'), 1, 16)), e.created_at
from application_events e left join profiles p on p.id = e.actor_id on conflict (event_id) do nothing;
do $$ begin alter publication supabase_realtime add table public.event_signatures; exception when duplicate_object then null; end $$;

-- ═══ 3) المستندات: صور من الكاميرا تُحفظ مع الطلب ببصمتها ═══
create table if not exists public.app_documents (
  id uuid primary key default gen_random_uuid(), application_id uuid not null references public.applications(id) on delete cascade,
  referral_id uuid references public.mortgage_referrals(id) on delete set null,
  kind text not null check (kind in ('deed','owner_id_front','owner_id_back','evidence','other')),
  source text not null check (source in ('camera','file','demo')), mime text, data text not null, bytes int, sha256 text,
  meta jsonb default '{}'::jsonb, uploaded_by uuid, uploaded_by_title text, created_at timestamptz default now()
);
create index if not exists app_documents_app on public.app_documents(application_id);
alter table public.app_documents enable row level security;
drop policy if exists read_docs on public.app_documents;
create policy read_docs on public.app_documents for select to authenticated using (
  exists (select 1 from applications a where a.id = application_id)
  and (kind <> 'evidence' or my_portal() in ('bank','registry','cbi','integrity')));

create or replace function public.add_document(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb, p_referral uuid default null)
returns uuid language plpgsql security definer set search_path = public, extensions as $$
declare me profiles; a applications; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  if me.portal = 'citizen' then
    if a.citizen_id <> me.id then raise exception 'الطلب لا يخصك'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
    if p_kind not in ('deed','owner_id_front','owner_id_back') then raise exception 'نوع مستند غير مسموح'; end if;
    if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
      raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
    delete from app_documents where application_id = a.id and kind = p_kind;
  elsif me.portal = 'registry' then
    if p_kind <> 'evidence' or p_referral is null or not exists (select 1 from mortgage_referrals where id = p_referral and application_id = a.id) then raise exception 'المرفق دليل على إحالة رهن فقط'; end if;
  elsif me.portal = 'bank' then
    if a.bank_id <> me.org_id or p_kind not in ('evidence','other') then raise exception 'غير مخوّل'; end if;
  else raise exception 'غير مخوّل'; end if;
  insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_referral, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()), me.id, _role_title(me.role))
  returning id into did;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || case p_kind when 'deed' then 'صورة سند العقار' when 'owner_id_front' then 'هوية مالك العقار (الوجه)'
    when 'owner_id_back' then 'هوية مالك العقار (الظهر)' when 'evidence' then 'دليل قرار التسجيل العقاري' else 'مستند' end,
    case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $$;

-- ═══ 4) إقرار ملكية العقار ومطابقته مع المقترض أو المالك والسجل العقاري ═══
alter table public.applications add column if not exists ownership jsonb;

create or replace function public._name_norm(t text) returns text language sql immutable as $$
  select array_to_string((string_to_array(regexp_replace(translate(regexp_replace(coalesce(t, ''), '[ًٌٍَُِّْـ]', '', 'g'), 'أإآىة', 'ااايه'), '\s+', ' ', 'g'), ' '))[1:3], ' ')
$$;

create or replace function public.set_property_ownership(p_app uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; pr properties; own jsonb; is_owner boolean := coalesce((p_data->>'is_owner')::boolean, true);
  dn text := trim(coalesce(p_data->>'deed_no', '')); onm text; onid text; oph text; m text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.guarantee_type <> 'mortgage' or a.stage <> 4 then raise exception 'إقرار الملكية في مرحلة ضمان الرهن فقط'; end if;
  if dn = '' then raise exception 'اكتب رقم السند كما في الصورة'; end if;
  if not exists (select 1 from app_documents where application_id = a.id and kind = 'deed' and source = 'camera') then
    raise exception 'صوّر سند العقار بكاميرا الهاتف أولاً'; end if;
  select * into pr from properties where deed_no = dn;
  if is_owner then
    onm := me.full_name; onid := me.national_id;
  else
    onm := regexp_replace(trim(coalesce(p_data->>'owner_name', '')), '\s+', ' ', 'g'); onid := coalesce(p_data->>'owner_national_id', '');
    oph := _norm_phone(p_data->>'owner_phone');
    if array_length(string_to_array(onm, ' '), 1) < 3 then raise exception 'اكتب اسم مالك العقار الثلاثي كما في السند'; end if;
    if onid !~ '^[0-9]{12}$' then raise exception 'الرقم الوطني لمالك العقار 12 رقماً'; end if;
    if onid = me.national_id or oph = me.phone then raise exception 'بيانات المالك هي بياناتك — اختر «أنا مالك العقار»'; end if;
    if not exists (select 1 from app_documents where application_id = a.id and kind = 'owner_id_front' and source = 'camera') then
      raise exception 'صوّر البطاقة الوطنية لمالك العقار بالكاميرا'; end if;
    if not _otp_ok(p_data->>'owner_otp') then raise exception 'لم يوافق مالك العقار على رهنه برمز التحقق'; end if;
  end if;
  -- المطابقة مع السجل العقاري إن كان السند مسجلاً
  if pr.id is not null then
    if pr.owner_national_id is not null and pr.owner_national_id <> onid then
      raise exception '%', case when is_owner then 'السند مسجل في السجل العقاري باسم شخص آخر — اختر «لست مالك العقار» وأضف بيانات المالك وموافقته'
        else 'بيانات المالك لا تطابق المسجل في السجل العقاري لهذا السند' end; end if;
    if _name_norm(pr.owner_name) <> _name_norm(onm) then
      raise exception 'اسم المالك لا يطابق المسجل في السجل العقاري (%)', pr.owner_name; end if;
    m := 'matched';
  else
    m := 'pending_registry';   -- سند غير مسجل في المنصة: تطابقه دائرة التسجيل العقاري مع الصورة
  end if;
  own := jsonb_build_object('is_owner', is_owner, 'deed_no', dn, 'owner_name', onm, 'owner_national_id', onid, 'owner_phone', oph,
    'relation', p_data->>'relation', 'match', m, 'owner_consent_at', case when not is_owner then now() end, 'declared_at', now());
  update applications set ownership = own where id = a.id;
  perform _ev(a.id, 4, case when is_owner then 'إقرار ملكية العقار: المقترض هو المالك' else 'إقرار ملكية العقار: المالك شخص آخر وافق على الرهن' end,
    'سند ' || dn || ' · ' || case m when 'matched' then 'مطابق للسجل العقاري' else 'بانتظار مطابقة التسجيل العقاري' end);
  return own;
end $$;

-- ═══ 5) الدفع الإلكتروني قبل إرسال الطلب: رسم دراسة الملف للمصرف + أجور الكشف + عمولة المنصة ═══
insert into public.settings(key, value, label, circular_no) values
 ('inspection_fee', 100000, 'أجور الكشف الموقعي — تُدفع قبل إرسال الطلب (دينار)', 'سياسة التمويل: ثالثاً-هـ'),
 ('platform_fee', 25000, 'عمولة المنصة على الطلب (دينار)', 'المنصة')
on conflict (key) do nothing;

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(), application_id uuid not null references public.applications(id) on delete cascade,
  bank_id uuid references public.orgs(id), method text not null check (method in ('zaincash','visa','mastercard')),
  items jsonb not null, amount bigint not null, status text not null default 'paid' check (status in ('paid','refunded')),
  ref text unique, paid_by uuid, paid_at timestamptz default now()
);
alter table public.payments enable row level security;
drop policy if exists read_payments on public.payments;
create policy read_payments on public.payments for select to authenticated using (exists (select 1 from applications a where a.id = application_id) and my_portal() in ('citizen','bank','cbi','integrity'));

create or replace function public.fee_quote(p_bank uuid) returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_array(
    jsonb_build_object('key', 'bank_fee', 'label', 'رسم دراسة الملف — ' || (select name from orgs where id = p_bank), 'amount', coalesce((select file_fee from bank_terms where bank_id = p_bank), 0)),
    jsonb_build_object('key', 'inspection_fee', 'label', 'أجور الكشف الموقعي', 'amount', coalesce(_setting('inspection_fee'), 0)::bigint),
    jsonb_build_object('key', 'platform_fee', 'label', 'عمولة المنصة', 'amount', coalesce(_setting('platform_fee'), 0)::bigint))
$$;

create or replace function public.pay_application_fees(p_app uuid, p_bank uuid, p_method text, p_otp text) returns public.payments
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; pay payments; it jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.stage <> 5 or a.status not in ('active','returned') then raise exception 'الدفع عند اختيار المصرف وقبل إرسال الطلب'; end if;
  if not exists (select 1 from bank_terms where bank_id = p_bank) then raise exception 'اختر مصرفاً'; end if;
  if p_method not in ('zaincash','visa','mastercard') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  select * into pay from payments where application_id = a.id and bank_id = p_bank and status = 'paid';
  if pay.id is not null then return pay; end if;
  it := fee_quote(p_bank);
  insert into payments(application_id, bank_id, method, items, amount, ref, paid_by)
  values (a.id, p_bank, p_method, it, (select sum((x->>'amount')::bigint) from jsonb_array_elements(it) x),
    'PAY-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)), me.id)
  returning * into pay;
  perform _ev(a.id, 5, 'دفع رسوم الملف وأجور الكشف وعمولة المنصة إلكترونياً',
    to_char(pay.amount, 'FM999,999,999') || ' د.ع · ' || case p_method when 'zaincash' then 'زين كاش' when 'visa' then 'Visa' else 'Mastercard' end || ' · ' || pay.ref);
  return pay;
end $$;

-- ═══ 6) حراسة الانتقالات: لا يُرسل الطلب قبل الدفع، ولا يُقبل ضمان الرهن دون صورة السند وإقرار الملكية ═══
create or replace function public._guard_transition() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.stage = old.stage then return new; end if;
  if old.stage <= 4 and new.stage >= 5 and new.guarantee_type = 'mortgage' then
    if new.ownership is null then raise exception 'أجب عن سؤال ملكية العقار وصوّر السند قبل تأكيد الضمان'; end if;
    if not exists (select 1 from app_documents where application_id = new.id and kind = 'deed') then raise exception 'صوّر سند العقار بكاميرا الهاتف'; end if;
    if coalesce(new.guarantee->>'deed_no', new.ownership->>'deed_no') <> new.ownership->>'deed_no' then raise exception 'رقم السند لا يطابق السند المصوَّر وإقرار الملكية'; end if;
    -- العقار الجديد الذي أنشأه المواطن: يُسجَّل باسم المالك المُقر به لا باسم المقترض
    if (new.ownership->>'is_owner')::boolean is false then
      update properties set owner_name = new.ownership->>'owner_name', owner_national_id = new.ownership->>'owner_national_id'
      where id = new.property_id and owner_national_id is not distinct from (select national_id from profiles where id = new.citizen_id);
    end if;
  end if;
  if old.stage <= 5 and new.stage >= 6 and not exists (select 1 from payments where application_id = new.id and bank_id = new.bank_id and status = 'paid') then
    raise exception 'ادفع رسوم الملف وأجور الكشف وعمولة المنصة للمصرف المختار قبل إرسال الطلب';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_transition on public.applications;
create trigger trg_guard_transition before update of stage on public.applications for each row execute function public._guard_transition();

-- ═══ 7) قرارات التسجيل العقاري: رفض مسبب بقائمة أسباب ودليل مرفق، ومنصب متخذ القرار ═══
create table if not exists public.rejection_reasons (code text primary key, label text not null, ctx text not null default 'registry', sort int default 0);
insert into public.rejection_reasons(code, label, sort) values
 ('already_mortgaged','العقار مرهون لجهة أخرى',1),
 ('sale_statement','مفتوح بيان لبيع العقار',2),
 ('owner_mismatch','العقار مسجل باسم شخص آخر غير المُقر بملكيته',3),
 ('seizure','عليه حجز أو إشارة منع تصرف بقرار قضائي أو إداري',4),
 ('dispute','عليه دعوى أو نزاع قائم على الملكية',5),
 ('shared_no_consent','عقار مشاع ولم يوافق بقية الشركاء',6),
 ('deed_mismatch','بيانات السند المصوَّر لا تطابق السجل',7),
 ('deed_invalid','السند غير موجود في السجل أو يُشتبه بصحته',8),
 ('inheritance','تركة غير مقسومة أو حصر إرث غير مكتمل',9),
 ('state_waqf','عقار حكومي أو وقفي لا يقبل الرهن',10),
 ('agri_lease','أرض زراعية بعقد إيجار أو تخصيص لا يجوز رهنها',11),
 ('unpaid_dues','ضرائب أو رسوم عقارية غير مسددة',12),
 ('other','سبب آخر (يُكتب تفصيلاً)',99)
on conflict (code) do update set label = excluded.label, sort = excluded.sort;
alter table public.rejection_reasons enable row level security;
drop policy if exists read_reasons on public.rejection_reasons;
create policy read_reasons on public.rejection_reasons for select to authenticated using (true);

alter table public.mortgage_referrals
  add column if not exists reject_reason text references public.rejection_reasons(code),
  add column if not exists evidence_doc uuid references public.app_documents(id),
  add column if not exists decided_by_title text, add column if not exists decided_at timestamptz;

drop function if exists public.registry_action(uuid, text, text);
create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null, p_reason text default null, p_evidence uuid default null)
returns public.mortgage_referrals language plpgsql security definer set search_path=public as $$
declare me profiles; r mortgage_referrals; p properties; act text; newst text; ast int; own jsonb; rr rejection_reasons;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  select stage, ownership into ast, own from applications where id = r.application_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك (الإجراء الأولي)';
  elsif p_action='annotate' then
    if r.status <> 'matched' then raise exception 'التأشير بعد المطابقة'; end if;
    if ast < 19 then raise exception 'التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)'; end if;
    newst:='annotated'; act:='تأشير الرهن على السند (الإجراء النهائي)';
    update properties set status='mortgaged' where id=p.id;
    update mortgage_referrals set annotation_no = 'ره-' || to_char(now(),'YYYY') || '-' || lpad((floor(random()*99999))::text,5,'0') where id=r.id;
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then
    if r.status not in ('pending','clear','matched','encumbered') then raise exception 'لا يُرفض إلا إحالة قيد الإجراء'; end if;
    select * into rr from rejection_reasons where code = p_reason;
    if rr is null then raise exception 'اختر سبب الرفض من القائمة'; end if;
    if p_reason = 'other' and length(trim(coalesce(p_note, ''))) < 10 then raise exception 'اكتب تفصيل السبب'; end if;
    if p_evidence is null or not exists (select 1 from app_documents where id = p_evidence and referral_id = r.id and kind = 'evidence') then
      raise exception 'أرفق ما يثبت سبب الرفض (صورة أو ملف من السجل)'; end if;
    newst:='rejected'; act:='رفض تأشير الرهن: ' || rr.label;
    update mortgage_referrals set reject_reason = rr.code, evidence_doc = p_evidence where id = r.id;
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now(), decided_at = now(),
    decided_by_title = _role_title(me.role) where id=r.id returning * into r;
  perform _ev(r.application_id, ast, act, p_note);
  return r;
end $$;

-- لدائرة التسجيل: ترى صورة السند وإقرار الملكية للإحالات الواردة إليها فقط
create or replace function public.referral_dossier(p_ref uuid) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare me profiles; r mortgage_referrals; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from mortgage_referrals where id = p_ref;
  if r is null then raise exception 'غير موجودة'; end if;
  select * into a from applications where id = r.application_id;
  if not (me.portal in ('registry','cbi','integrity') or (me.portal = 'bank' and me.org_id = a.bank_id)) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('ownership', a.ownership, 'borrower', a.citizen_name,
    'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'source', d.source, 'data', d.data, 'mime', d.mime, 'sha256', d.sha256,
      'created_at', d.created_at, 'by', d.uploaded_by_title) order by d.created_at), '[]') from app_documents d where d.application_id = a.id and d.kind in ('deed','owner_id_front','owner_id_back','evidence')),
    'reason', (select label from rejection_reasons where code = r.reject_reason));
end $$;

-- ═══ 8) بيانات العرض: الدفع للطلبات المرسلة، وسند وإقرار ملكية للطلبات برهن ═══
alter table public.applications disable trigger trg_guard_transition;
insert into public.payments(application_id, bank_id, method, items, amount, ref, paid_by, paid_at)
select a.id, a.bank_id, (array['zaincash','visa','mastercard'])[1 + (abs(hashtext(a.code)) % 3)], fee_quote(a.bank_id),
  (select sum((x->>'amount')::bigint) from jsonb_array_elements(fee_quote(a.bank_id)) x),
  'PAY-' || to_char(coalesce(l.finished_at, a.created_at), 'YYMMDD') || '-' || upper(substr(md5(a.code), 1, 6)), a.citizen_id, coalesce(l.finished_at, a.created_at)
from applications a left join stage_log l on l.application_id = a.id and l.stage = 5
where a.bank_id is not null and a.stage >= 6 and not exists (select 1 from payments p where p.application_id = a.id);

update public.applications a set ownership = jsonb_build_object('is_owner', true, 'deed_no', pr.deed_no, 'owner_name', pr.owner_name,
  'owner_national_id', pr.owner_national_id, 'match', 'matched', 'declared_at', a.created_at)
from properties pr where pr.id = a.property_id and a.guarantee_type = 'mortgage' and a.ownership is null;
insert into public.app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by_title, created_at)
select a.id, 'deed', 'demo', 'image/svg+xml',
  'data:image/svg+xml;utf8,' || replace(replace(format('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 300"><rect width="420" height="300" fill="#f7f1e3"/><rect x="10" y="10" width="400" height="280" fill="none" stroke="#8a6d3b" stroke-width="3"/><text x="210" y="55" font-size="22" text-anchor="middle" font-family="sans-serif" fill="#5a4320">سند عقاري — نموذج عرض</text><text x="390" y="110" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">رقم السند: %s</text><text x="390" y="145" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">المالك: %s</text><text x="390" y="180" font-size="16" text-anchor="end" font-family="sans-serif" fill="#333">الموقع: %s — %s</text><text x="210" y="260" font-size="12" text-anchor="middle" font-family="sans-serif" fill="#999">بيانات وهمية للعرض</text></svg>',
    pr.deed_no, pr.owner_name, pr.governorate, pr.district), '#', '%23'), '"', '''') ,
  0, null, jsonb_build_object('demo', true), 'المقترض', a.created_at
from applications a join properties pr on pr.id = a.property_id
where a.guarantee_type = 'mortgage' and not exists (select 1 from app_documents d where d.application_id = a.id and d.kind = 'deed');
alter table public.applications enable trigger trg_guard_transition;

revoke all on function public._staff_prefix(uuid), public._assign_staff_code(), public._sign_event(), public._seal_event(), public._guard_transition() from public, anon, authenticated;
grant execute on function public.add_document, public.set_property_ownership, public.fee_quote, public.pay_application_fees,
  public.registry_action(uuid, text, text, text, uuid), public.referral_dossier to authenticated;
