-- ════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 5: عمولة كل مصرف، اختيار المصرف مع المنظومة،
-- طرق دفع عراقية، وكالة مالك العقار بدل بطاقته.
-- يُطبَّق تلقائياً من server.js (قائمة MIGRATIONS). آمن عند التكرار.
-- الدوال القائمة تُرقَّع على تعريفها الحي (لا تُستبدل بنسخة قديمة).
-- ════════════════════════════════════════════════════════════════

-- 1) نسبة عمولة كل مصرف من مبلغ التمويل (يحددها المصرف)
alter table bank_terms add column if not exists commission_pct numeric not null default 1
  check (commission_pct >= 0 and commission_pct <= 10);
update bank_terms set commission_pct = v.p
from (values ('مصرف السنابل التجاري', 1.0), ('مصرف الواحة الإسلامي', 0.75), ('مصرف دجلة للتنمية', 1.25)) v(n, p)
join orgs o on o.name = v.n
where bank_terms.bank_id = o.id and bank_terms.commission_pct = 1;

-- 2) اختيار المصرف والمدة مبدئياً عند اختيار المنظومة (لا يظهر الطلب للمصرف قبل الإرسال)
alter table applications add column if not exists bank_choice jsonb;

-- 3) عرض الرسوم مع عمولة المصرف محسوبة من مبلغ التمويل
create or replace function public.fee_quote(p_bank uuid, p_amount bigint)
returns jsonb language sql stable security definer set search_path to 'public' as $$
  select jsonb_build_array(
    jsonb_build_object('key', 'bank_commission', 'label', 'عمولة المصرف (' || coalesce(t.commission_pct, 0)::float8::text || '%) — ' || o.name,
      'amount', round(coalesce(p_amount, 0) * coalesce(t.commission_pct, 0) / 100)::bigint),
    jsonb_build_object('key', 'bank_fee', 'label', 'رسم دراسة الملف — ' || o.name, 'amount', coalesce(t.file_fee, 0)),
    jsonb_build_object('key', 'inspection_fee', 'label', 'أجور الكشف الموقعي', 'amount', coalesce(_setting('inspection_fee'), 0)::bigint),
    jsonb_build_object('key', 'platform_fee', 'label', 'عمولة المنصة', 'amount', coalesce(_setting('platform_fee'), 0)::bigint))
  from orgs o left join bank_terms t on t.bank_id = o.id where o.id = p_bank
$$;

-- 4) الدفع: زين كاش، كي كارد، آسيا باي، فاست باي، FIB، Visa، Mastercard، محفظة أو بطاقة أخرى
create or replace function public.pay_method_label(m text) returns text language sql immutable as $$
  select case m when 'zaincash' then 'زين كاش' when 'qicard' then 'كي كارد' when 'asiapay' then 'آسيا باي' when 'fastpay' then 'فاست باي'
    when 'fib' then 'FIB' when 'visa' then 'Visa' when 'mastercard' then 'Mastercard' when 'other' then 'بطاقة أو محفظة أخرى' else m end
$$;

create or replace function public.pay_application_fees(p_app uuid, p_bank uuid, p_method text, p_otp text)
returns payments language plpgsql security definer set search_path to 'public' as $$
declare me profiles; a applications; pay payments; it jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.stage <> 5 or a.status not in ('active','returned') then raise exception 'الدفع بعد تأكيد الضمان وقبل إرسال الطلب'; end if;
  if not exists (select 1 from bank_terms where bank_id = p_bank) then raise exception 'اختر مصرفاً'; end if;
  if p_method not in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  select * into pay from payments where application_id = a.id and bank_id = p_bank and status = 'paid';
  if pay.id is not null then return pay; end if;
  it := fee_quote(p_bank, a.amount);
  insert into payments(application_id, bank_id, method, items, amount, ref, paid_by)
  values (a.id, p_bank, p_method, it, (select sum((x->>'amount')::bigint) from jsonb_array_elements(it) x),
    'PAY-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)), me.id)
  returning * into pay;
  perform _ev(a.id, 5, 'دفع عمولة المصرف والرسوم إلكترونياً',
    to_char(pay.amount, 'FM999,999,999') || ' د.ع · ' || pay_method_label(p_method) || ' · ' || pay.ref);
  return pay;
end $$;

-- 5) ترقيع الدوال الحية
do $mig$
declare d text; o text; n text;
begin
  -- 5أ) citizen_step: المرحلة 5 تأخذ المصرف والمدة المختارين مسبقاً، والمرحلة 3 تحفظ اختيار المصرف
  d := pg_get_functiondef('public.citizen_step(uuid,integer,jsonb)'::regprocedure);
  if position('bank_choice' in d) = 0 then
    o := $p$  elsif p_step = 5 then
    select * into bt from bank_terms where bank_id = (p_data->>'bank_id')::uuid;$p$;
    n := $p$  elsif p_step = 5 then
    select * into bt from bank_terms where bank_id = coalesce(nullif(p_data->>'bank_id', '')::uuid, (a.bank_choice->>'bank_id')::uuid);$p$;
    if position(o in d) = 0 then raise exception 'citizen_step: لم يُعثر على موضع المرحلة 5'; end if;
    d := replace(d, o, n);
    o := $p$v_term := coalesce((p_data->>'term_months')::int, 60);$p$;
    n := $p$v_term := coalesce((p_data->>'term_months')::int, (a.bank_choice->>'term_months')::int, 60);$p$;
    if position(o in d) = 0 then raise exception 'citizen_step: لم يُعثر على موضع مدة السداد'; end if;
    d := replace(d, o, n);
    o := $p$act := 'تثبيت العرض المختار'; note := o.title;
    end if;$p$;
    n := $p$act := 'تثبيت العرض المختار'; note := o.title;
    end if;
    if nullif(p_data->>'bank_id', '') is not null then
      select * into bt from bank_terms where bank_id = (p_data->>'bank_id')::uuid;
      if bt is null then raise exception 'اختر مصرفاً من القائمة'; end if;
      if exists (select 1 from orgs where id = bt.bank_id and coalesce((meta->>'accepting')::boolean, true) = false) then
        raise exception 'هذا المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
      v_term := coalesce((p_data->>'term_months')::int, 60);
      if v_term < 12 or v_term > least(bt.max_term_months, _setting('term_max_months')::int) then
        raise exception 'مدة السداد بين 12 و% شهراً لدى هذا المصرف', least(bt.max_term_months, _setting('term_max_months')::int); end if;
      update applications set bank_choice = jsonb_build_object('bank_id', bt.bank_id, 'term_months', v_term, 'commission_pct', bt.commission_pct, 'at', now()) where id = a.id;
      note := note || ' · ' || (select name from orgs where id = bt.bank_id) || ' · عمولة ' || bt.commission_pct::float8 || '%';
    end if;$p$;
    if position(o in d) = 0 then raise exception 'citizen_step: لم يُعثر على موضع المرحلة 3'; end if;
    d := replace(d, o, n);
    execute d;
  end if;

  -- 5ب) add_document: قبول صورة الوكالة
  d := pg_get_functiondef('public.add_document(uuid,text,text,text,jsonb,uuid)'::regprocedure);
  if position('''poa''' in d) = 0 then
    o := $p$if p_kind not in ('deed','owner_id_front','owner_id_back') then$p$;
    n := $p$if p_kind not in ('deed','owner_id_front','owner_id_back','poa') then$p$;
    if position(o in d) = 0 then raise exception 'add_document: لم يُعثر على قائمة الأنواع'; end if;
    d := replace(d, o, n);
    o := $p$when 'owner_id_back' then$p$;
    n := $p$when 'poa' then 'وكالة مالك العقار بالرهن' when 'owner_id_back' then$p$;
    if position(o in d) = 0 then raise exception 'add_document: لم يُعثر على التسميات'; end if;
    d := replace(d, o, n);
    execute d;
  end if;

  -- 5ج) set_property_ownership: غير المالك يصوّر وكالة المالك بالرهن
  d := pg_get_functiondef('public.set_property_ownership(uuid,jsonb)'::regprocedure);
  if position('''poa''' in d) = 0 then
    o := $p$kind = 'owner_id_front' and source = 'camera') then
      raise exception 'صوّر البطاقة الوطنية لمالك العقار بالكاميرا'; end if;$p$;
    n := $p$kind = 'poa' and source = 'camera') then
      raise exception 'صوّر وكالة مالك العقار بالرهن بكاميرا الهاتف'; end if;$p$;
    if position(o in d) = 0 then raise exception 'set_property_ownership: لم يُعثر على شرط بطاقة المالك'; end if;
    d := replace(d, o, n);
    execute d;
  end if;

  -- 5ج2) ملف إحالة الرهن لدائرة التسجيل العقاري يتضمن الوكالة
  d := pg_get_functiondef('public.referral_dossier(uuid)'::regprocedure);
  if position('''poa''' in d) = 0 then
    o := $p$d.kind in ('deed','owner_id_front','owner_id_back','evidence')$p$;
    if position(o in d) = 0 then raise exception 'referral_dossier: لم يُعثر على قائمة المستندات'; end if;
    execute replace(d, o, $p$d.kind in ('deed','poa','owner_id_front','owner_id_back','evidence')$p$);
  end if;

  -- 5د) رسالة شرط الدفع قبل الإرسال
  d := pg_get_functiondef('public._guard_transition()'::regprocedure);
  o := 'ادفع رسوم الملف وأجور الكشف وعمولة المنصة للمصرف المختار قبل إرسال الطلب';
  if position(o in d) > 0 then execute replace(d, o, 'ادفع عمولة المصرف والرسوم للمصرف المختار قبل إرسال الطلب'); end if;
end $mig$;

-- ════════════════════════════════════════════════════════════════
-- 6) تصحيح دور البنك المركزي: جهة قطاعية رقابية — لا يوافق ولا يرفض ولا يقرر من يُقرض.
--    المصرف الوسيط له ائتمان لدى البنك المركزي، والسلفة التجميعية تُموَّل آلياً منه
--    عند إرسال كتابها إن كان كافياً. التدخل الرقابي في الحالات التي تستدعيه فقط، بسبب مكتوب.
-- ════════════════════════════════════════════════════════════════
alter table cbi_batches add column if not exists oversight_notes jsonb not null default '[]'::jsonb;

update stages set name = 'إرسال كتاب السلفة إلى البنك المركزي (سحب من ائتمان المصرف)', phase = 'التمويل من ائتمان المصرف' where n = 22;
update stages set name = 'تعزيز السلفة من ائتمان المصرف لدى البنك المركزي', owner_role = 'bank_admin',
  owner_label = 'قسم الإدارة — آلي من ائتمان المصرف', action_label = 'تعزيز السلفة من ائتمان المصرف', sla_days = 1, phase = 'التمويل من ائتمان المصرف'
where n = 23;

-- تمويل السلفة من ائتمان المصرف (داخلية): تعيد true إن عُزّزت
create or replace function public._fund_batch(p_batch uuid) returns boolean
language plpgsql security definer set search_path to 'public' as $$
declare b cbi_batches; ids uuid[]; avail bigint;
begin
  select * into b from cbi_batches where id = p_batch for update;
  if b.status <> 'sent' then return false; end if;
  select allocated - reserved - disbursed into avail from bank_allocations where bank_id = b.bank_id for update;
  select array_agg(id) into ids from applications where batch_id = b.id and status = 'active';
  if coalesce(avail, 0) < b.total then
    perform _ev(x, 23, 'ائتمان المصرف لدى البنك المركزي لا يكفي لتعزيز السلفة ' || b.code,
      'المتاح ' || to_char(coalesce(avail, 0), 'FM999,999,999,999') || ' د.ع والمطلوب ' || to_char(b.total, 'FM999,999,999,999') || ' د.ع — تُعزَّز حين يكفي الائتمان')
    from unnest(ids) x;
    return false;
  end if;
  update bank_allocations set reserved = reserved + b.total where bank_id = b.bank_id;
  update cbi_batches set status = 'approved', decided_by_name = 'آلي — ائتمان المصرف لدى البنك المركزي', decided_at = now(),
    decision_note = 'عُزّزت من ائتمان المصرف' where id = b.id;
  update applications set stage = 24, cbi_approved_at = now(), updated_at = now(), bank_unit = (select owner_label from stages where n = 24) where id = any(ids);
  perform _ev(x, 23, 'تعزيز السلفة ' || b.code || ' من ائتمان المصرف لدى البنك المركزي', 'حُجز المبلغ من ائتمان المصرف وبدأت مهلة التنفيذ') from unnest(ids) x;
  return true;
end $$;
revoke all on function public._fund_batch(uuid) from public, anon, authenticated;

create or replace function public.batch_action(p_batch uuid, p_action text, p_note text default null)
returns cbi_batches language plpgsql security definer set search_path to 'public' as $$
declare me profiles; b cbi_batches; ids uuid[]; act text;
begin
  select * into me from profiles where id = auth.uid();
  select * into b from cbi_batches where id = p_batch for update;
  if b is null then raise exception 'السلفة غير موجودة'; end if;
  select array_agg(id) into ids from applications where batch_id = b.id and status = 'active';
  if p_action = 'dissolve' then
    if me.role <> 'bank_initiatives' or me.org_id <> b.bank_id or b.status not in ('draft', 'sent') then raise exception 'فك السلفة لإداري المبادرات قبل التوقيع، أو بعد الإرسال ما دامت لم تُعزَّز'; end if;
    update applications set batch_id = null, stage = 20, updated_at = now(), bank_unit = (select owner_label from stages where n = 20) where batch_id = b.id;
    delete from cbi_batches where id = b.id; act := 'فك السلفة التجميعية ' || b.code;
    perform _ev(x, 21, act, p_note) from unnest(ids) x; return b;
  elsif p_action = 'sign' then
    if me.role <> 'bank_md' or me.org_id <> b.bank_id then raise exception 'التوقيع للإدارة العليا للمصرف'; end if;
    if b.status <> 'draft' then raise exception 'الكتاب موقّع مسبقاً'; end if;
    update cbi_batches set status = 'signed', signed_by_name = me.full_name, signed_at = now(),
      letter_ref = 'ك-' || to_char(now(), 'YYYY') || '-' || lpad((floor(random()*9999))::text, 4, '0') where id = b.id returning * into b;
    update applications set stage = 22, updated_at = now(), bank_unit = (select owner_label from stages where n = 22) where id = any(ids);
    perform _ev(x, 21, 'توقيع كتاب طلب السلفة ' || b.code, p_note) from unnest(ids) x;
  elsif p_action = 'send' then
    if me.role <> 'bank_admin' or me.org_id <> b.bank_id then raise exception 'الإرسال من قسم الإدارة'; end if;
    if b.status <> 'signed' then raise exception 'يُرسل الكتاب بعد توقيعه'; end if;
    update cbi_batches set status = 'sent', sent_by_name = me.full_name, sent_at = now() where id = b.id returning * into b;
    update applications set stage = 23, updated_at = now(), bank_unit = (select owner_label from stages where n = 23) where id = any(ids);
    perform _ev(x, 22, 'إرسال كتاب السلفة ' || b.code || ' إلى البنك المركزي للسحب من ائتمان المصرف', p_note) from unnest(ids) x;
    perform _fund_batch(b.id);
    select * into b from cbi_batches where id = b.id;
  elsif p_action = 'fund' then
    if me.role <> 'bank_admin' or me.org_id <> b.bank_id then raise exception 'إعادة محاولة التعزيز من قسم الإدارة'; end if;
    if b.status <> 'sent' then raise exception 'السلفة ليست بانتظار التعزيز'; end if;
    if not _fund_batch(b.id) then raise exception 'ائتمان المصرف لدى البنك المركزي لا يكفي بعد لهذه السلفة'; end if;
    select * into b from cbi_batches where id = b.id;
  elsif p_action in ('approve', 'reject') then
    raise exception 'البنك المركزي جهة رقابية: لا يوافق ولا يرفض طلبات الإقراض — قرار الإقراض للمصرف وحده';
  elsif p_action = 'intervene' then
    if me.portal <> 'cbi' then raise exception 'التدخل الرقابي للبنك المركزي'; end if;
    if length(coalesce(trim(p_note), '')) < 10 then raise exception 'اكتب سبب التدخل الرقابي بوضوح — يُسجَّل باسم منصبك'; end if;
    update cbi_batches set oversight_notes = oversight_notes || jsonb_build_array(jsonb_build_object('at', now(), 'by', _role_title(me.role), 'note', trim(p_note)))
    where id = b.id returning * into b;
    perform _ev(x, (select stage from applications where id = x), 'تدخل رقابي من البنك المركزي على السلفة ' || b.code, trim(p_note)) from unnest(ids) x;
  else raise exception 'إجراء غير معروف'; end if;
  return b;
end $$;

-- ملاحظة رقابية على طلب منفرد: تُسجَّل في سجل الطلب ولا تغيّر مرحلته ولا قراره
create or replace function public.cbi_oversight_note(p_app uuid, p_note text)
returns void language plpgsql security definer set search_path to 'public' as $$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'cbi' then raise exception 'الملاحظة الرقابية للبنك المركزي'; end if;
  select * into a from applications where id = p_app;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if length(coalesce(trim(p_note), '')) < 10 then raise exception 'اكتب سبب التدخل الرقابي بوضوح'; end if;
  perform _ev(a.id, a.stage, 'تدخل رقابي من البنك المركزي', trim(p_note));
end $$;
grant execute on function public.cbi_oversight_note(uuid, text) to authenticated;

grant execute on function public.fee_quote(uuid, bigint) to authenticated;
grant execute on function public.pay_method_label(text) to authenticated, anon;

notify pgrst, 'reload schema';
