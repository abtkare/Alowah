// ألواح — الجلسة 51: أيقونة التطبيق المثبّت = شعار الجهة الذي رفعه مشغّل النظام.
// يقرأ الشعار (PNG) ويضعه في وسط مربع أبيض بالحجم المطلوب (180 آيفون، 192 و512 أندرويد/حاسوب)،
// ويُخرج PNG. بلا مكتبات خارجية: فك PNG وتصغيره وترميزه بـ zlib المدمج في Node.
'use strict';
const zlib = require('zlib');

// ───── CRC لترميز PNG ─────
const CRC = new Int32Array(256);
for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; CRC[n] = c; }
function crc32(buf) { let c = -1; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; }

// ───── فك PNG إلى RGBA (غير المتداخل؛ كل أنواع الألوان وعمق 1–16) ─────
function decodePng(buf) {
  if (!buf || buf.length < 33 || buf.readUInt32BE(0) !== 0x89504e47) return null;
  let p = 8, w = 0, h = 0, depth = 0, ctype = 0, inter = 0, plte = null, trns = null; const idat = [];
  while (p + 8 <= buf.length) {
    const len = buf.readUInt32BE(p), type = buf.toString('latin1', p + 4, p + 8), d = buf.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); depth = d[8]; ctype = d[9]; inter = d[12]; }
    else if (type === 'PLTE') plte = d;
    else if (type === 'tRNS') trns = d;
    else if (type === 'IDAT') idat.push(d);
    else if (type === 'IEND') break;
    p += 12 + len;
  }
  if (!w || !h || inter !== 0 || w * h > 4e6) return null;
  const ch = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ctype]; if (!ch) return null;
  const bpp = Math.max(1, (ch * depth) >> 3), stride = (w * ch * depth + 7) >> 3;
  let raw; try { raw = zlib.inflateSync(Buffer.concat(idat)); } catch { return null; }
  if (raw.length < h * (stride + 1)) return null;
  const px = Buffer.alloc(h * stride); let prev = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)], src = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1)), cur = px.subarray(y * stride, (y + 1) * stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? cur[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0; let v = src[i];
      if (f === 1) v += a; else if (f === 2) v += b; else if (f === 3) v += (a + b) >> 1;
      else if (f === 4) { const pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }
      cur[i] = v & 255;
    }
    prev = cur;
  }
  const out = Buffer.alloc(w * h * 4), max = (1 << depth) - 1;
  const sample = (row, i) => { // القناة رقم i في السطر (مُطبَّعة إلى 0–255)
    if (depth === 8) return row[i]; if (depth === 16) return row[i * 2];
    const bit = i * depth, v = (row[bit >> 3] >> (8 - depth - (bit & 7))) & max; return ctype === 3 ? v : Math.round(v * 255 / max);
  };
  const raw16 = (row, i) => depth === 16 ? row.readUInt16BE(i * 2) : (depth === 8 ? row[i] : (row[(i * depth) >> 3] >> (8 - depth - ((i * depth) & 7))) & max);
  for (let y = 0; y < h; y++) {
    const row = px.subarray(y * stride, (y + 1) * stride);
    for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4; let r, g, b, al = 255;
      if (ctype === 3) { const k = sample(row, x); if (!plte || k * 3 + 2 >= plte.length) return null; r = plte[k * 3]; g = plte[k * 3 + 1]; b = plte[k * 3 + 2]; if (trns && k < trns.length) al = trns[k]; }
      else if (ctype === 0) { r = g = b = sample(row, x); if (trns && trns.length >= 2 && raw16(row, x) === trns.readUInt16BE(0)) al = 0; }
      else if (ctype === 4) { r = g = b = sample(row, x * 2); al = sample(row, x * 2 + 1); }
      else if (ctype === 2) { r = sample(row, x * 3); g = sample(row, x * 3 + 1); b = sample(row, x * 3 + 2);
        if (trns && trns.length >= 6 && raw16(row, x * 3) === trns.readUInt16BE(0) && raw16(row, x * 3 + 1) === trns.readUInt16BE(2) && raw16(row, x * 3 + 2) === trns.readUInt16BE(4)) al = 0; }
      else { r = sample(row, x * 4); g = sample(row, x * 4 + 1); b = sample(row, x * 4 + 2); al = sample(row, x * 4 + 3); }
      out[o] = r; out[o + 1] = g; out[o + 2] = b; out[o + 3] = al;
    }
  }
  return { w, h, data: out };
}

// ───── ترميز PNG (RGB) ─────
function encodePng(w, h, rgb) {
  const raw = Buffer.alloc(h * (w * 3 + 1));
  for (let y = 0; y < h; y++) rgb.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3);
  const chunk = (t, d) => { const b = Buffer.alloc(12 + d.length); b.writeUInt32BE(d.length, 0); b.write(t, 4, 'latin1'); d.copy(b, 8); b.writeUInt32BE(crc32(b.subarray(4, 8 + d.length)), 8 + d.length); return b; };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// ───── الشعار في وسط مربع أبيض ─────
// يُقصّ الفراغ الشفاف/الأبيض حول الشعار أولاً، ثم يُوضع بنسبة 72% من المربع (داخل المنطقة الآمنة
// لأيقونات أندرويد المقنّعة)، بتنعيم 4×4 عيّنات لكل بكسل.
function trimBox(img) {
  const { w, h, data } = img; let x0 = w, y0 = h, x1 = -1, y1 = -1;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const o = (y * w + x) * 4, a = data[o + 3];
    if (a > 16 && !(data[o] > 245 && data[o + 1] > 245 && data[o + 2] > 245)) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  }
  return x1 < 0 ? { x0: 0, y0: 0, x1: w - 1, y1: h - 1 } : { x0, y0, x1, y1 };
}
function compose(img, S, fill = 0.72) {
  const { w, data } = img, bx = trimBox(img), bw = bx.x1 - bx.x0 + 1, bh = bx.y1 - bx.y0 + 1;
  const k = (S * fill) / Math.max(bw, bh), dw = bw * k, dh = bh * k, ox = (S - dw) / 2, oy = (S - dh) / 2;
  const out = Buffer.alloc(S * S * 3, 255), N = 4;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    if (x + 1 < ox || x > ox + dw || y + 1 < oy || y > oy + dh) continue;
    let r = 0, g = 0, b = 0, a = 0;
    for (let sy = 0; sy < N; sy++) for (let sx = 0; sx < N; sx++) {
      const u = (x + (sx + 0.5) / N - ox) / k, v = (y + (sy + 0.5) / N - oy) / k;
      if (u < 0 || v < 0 || u >= bw || v >= bh) continue;
      const o = ((bx.y0 + (v | 0)) * w + bx.x0 + (u | 0)) * 4, al = data[o + 3];
      r += data[o] * al; g += data[o + 1] * al; b += data[o + 2] * al; a += al;
    }
    const T = N * N * 255, o = (y * S + x) * 3, cov = a / T;
    if (a > 0) { out[o] = Math.round(r / a * cov + 255 * (1 - cov)); out[o + 1] = Math.round(g / a * cov + 255 * (1 - cov)); out[o + 2] = Math.round(b / a * cov + 255 * (1 - cov)); }
  }
  return encodePng(S, S, out);
}

// ───── الواجهة: logoToIcon(buffer, size) → PNG أو null (صيغة غير مدعومة) ─────
const CACHE = new Map();
function logoToIcon(buf, size) {
  const key = crc32(buf) + ':' + buf.length + ':' + size;
  if (CACHE.has(key)) return CACHE.get(key);
  let png = null;
  try { const img = decodePng(buf); if (img) png = compose(img, size); } catch { png = null; }
  if (CACHE.size > 300) CACHE.clear();
  CACHE.set(key, png);
  return png;
}
module.exports = { logoToIcon, decodePng, encodePng };
