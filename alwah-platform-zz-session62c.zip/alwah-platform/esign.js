// ألواح — ربط خدمة التوقيع الإلكتروني (الجلسة 15). بلا حزم خارجية.
// المسارات:
//   POST /api/esign/start    (موظف خدمة الزبائن — بجلسته) يولّد العقد ويرسله للمقترض للتوقيع
//   POST /api/esign/cancel   (موظف خدمة الزبائن) يلغي طلب التوقيع المعلّق
//   POST /api/esign/webhook  (خدمة التوقيع) أحداث موقّعة HMAC: اكتمال التوقيع، الانتهاء، الإلغاء، التوقيع الحضوري
//   GET  /api/esign/health   حالة الربط (دون أسرار)
//   POST /api/esign/sharia/start  (رئيس الهيئة الشرعية — بجلسته) الجلسة 43: يرسل قرار الهيئة لتوقيعه إلكترونياً، ويعيد رابط التوقيع
// الجلسة 43: الطلب الإسلامي في المرحلة 25 يوقّع «التعهدات والضمانات» فقط (pledgeHtml) — لا عقد تمويل ولا كمبيالة بدين قبل تملّك المصرف
const crypto = require('crypto');

module.exports = function esign({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET, PUBLIC_URL }) {
  let CFG = null, CFG_AT = 0;

  async function rpc(fn, args, jwt) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${jwt || SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(args),
    });
    const t = await r.text();
    let j; try { j = t ? JSON.parse(t) : null; } catch { j = t; }
    if (!r.ok) { const e = new Error((j && (j.message || j.error)) || `rpc ${fn} ${r.status}`); e.status = r.status >= 500 ? 502 : 400; throw e; }
    return j;
  }

  async function config(force) {
    if (!DB_SECRET) throw Object.assign(new Error('لم يُضَف ESIGN_DB_SECRET إلى إعدادات الخادم'), { status: 503 });
    if (!force && CFG && Date.now() - CFG_AT < 60_000) return CFG;
    const c = await rpc('esign_config', { p_secret: DB_SECRET });
    if (!c || !c.base_url || !c.api_key) throw Object.assign(new Error('خدمة التوقيع الإلكتروني لم تُربط بعد بالمنصة (شغّل أمر التثبيت على الخادم)'), { status: 503 });
    CFG = c; CFG_AT = Date.now();
    return c;
  }

  async function svc(method, p, body, raw) {
    const c = await config();
    const r = await fetch(c.base_url + p, {
      method,
      headers: { Authorization: `Bearer ${c.api_key}`, ...(body ? { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID() } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(90_000),
    });
    if (raw) { if (!r.ok) throw new Error(`esign ${p} ${r.status}`); return Buffer.from(await r.arrayBuffer()); }
    const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = { error: t.slice(0, 200) }; }
    if (!r.ok) throw Object.assign(new Error(ERR[j.error] || `خدمة التوقيع: ${j.error || r.status}`), { status: r.status === 401 ? 502 : 400, code: j.error });
    return j;
  }

  const ERR = {
    reference_face_no_face: 'لم يُعثر على وجه في الصورة المرجعية — صوّر البطاقة الوطنية أو وجه المقترض بوضوح',
    reference_face_multiple_faces: 'الصورة المرجعية فيها أكثر من وجه — صوّر وجه المقترض وحده',
    reference_face_face_too_small: 'الوجه صغير جداً في الصورة المرجعية — قرّب الكاميرا من الصورة',
    reference_face_reference_not_frontal: 'الصورة المرجعية ليست أمامية — صوّر الوجه من الأمام',
    reference_face_invalid: 'الصورة المرجعية غير صالحة',
    active_session_exists_for_loan: 'يوجد طلب توقيع نشط لهذا العقد — ألغِه أولاً',
    document_too_large: 'حجم العقد كبير',
    unauthorized: 'مفتاح خدمة التوقيع غير صحيح — أعد ربط الخدمة',
  };

  // ───────── قالب العقد (نموذج — يعتمده القسم القانوني للمصرف) ─────────
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const n = v => Number(v || 0).toLocaleString('en-US');
  const iqd = v => `${n(v)} دينار عراقي`;
  const GUAR = { single_salary: 'كفالة راتب موظف واحد مع الاستقطاع المباشر', multi_salary: 'كفالة رواتب عدة موظفين مع الاستقطاع المباشر', mortgage: 'رهن عقار من الدرجة الأولى' };
  const day = d => new Date(d || Date.now()).toLocaleDateString('ar-IQ-u-nu-latn', { timeZone: 'Asia/Baghdad', year: 'numeric', month: 'long', day: 'numeric' });

  function contractHtml(p) {
    const a = p.app, b = p.borrower, vet = a.program === 'vet';
    const gs = (a.guarantee && a.guarantee.guarantors) || [];
    const amount = a.amount || a.price;
    const total = Number(a.monthly_installment || 0) * Number(a.term_months || 0);
    const row = (k, v) => `<tr><th>${esc(k)}</th><td>${v}</td></tr>`;
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{color:#111;font-size:10.5pt;line-height:1.6;margin:0}
h1{font-size:17pt;text-align:center;margin:0 0 2px}.sub{text-align:center;color:#555;font-size:9.5pt;margin-bottom:10px}
h2{font-size:12pt;color:#0f3d3e;border-bottom:1.5px solid #0f3d3e;margin:14px 0 6px;padding-bottom:2px}
table{width:100%;border-collapse:collapse;margin:4px 0}th,td{text-align:right;padding:2px 7px;border:1px solid #d9dee3;vertical-align:top}th{width:32%;background:#f4f7f7}
ol{margin:4px 0;padding-right:22px}li{margin:3px 0}.num{direction:ltr;unicode-bidi:embed}
.note{border:1px dashed #b45309;color:#7c2d12;background:#fff7ed;padding:6px 10px;border-radius:6px;font-size:9pt;margin-top:10px}
.page{page-break-before:always}.box{border:2px solid #0f3d3e;border-radius:8px;padding:14px 16px}
.sig{display:flex;gap:18px;margin-top:14px}.sig div{flex:1;border-top:1px solid #999;padding-top:4px;font-size:9.5pt;color:#444;text-align:center}
</style></head><body>
<h1>${vet ? 'عقد تمويل مشروع بيطري' : 'عقد تمويل منظومة طاقة شمسية'} بالتقسيط</h1>
<div class="sub">رقم الطلب <b class="num">${esc(a.code)}</b> · حُرِّر إلكترونياً عبر منصة «ألواح» في ${esc(day())}</div>
<h2>أولاً: الطرفان</h2>
<table>
${row('الطرف الأول (المصرف المموِّل)', `${esc(p.bank)}${p.branch ? ` — ${esc(p.branch)}` : ''}`)}
${row('الطرف الثاني (المقترض)', esc(b.full_name))}
${row('رقم البطاقة الوطنية الموحدة', `<span class="num">${esc(b.national_id || '—')}</span>`)}
${row('العنوان', esc([b.governorate, b.city, b.address].filter(Boolean).join(' — ') || '—'))}
${row('رقم الهاتف', `<span class="num">${esc(b.phone || '—')}</span>`)}
${a.bank_account ? row('رقم حساب المقترض لدى المصرف', `<span class="num">${esc(a.bank_account)}</span>`) : ''}
</table>
<h2>ثانياً: موضوع التمويل</h2>
<table>
${vet ? row('المشروع', 'مشروع بيطري ضمن مبادرة تمويل مشاريع الأطباء البيطريين') : row('المنظومة', `منظومة طاقة شمسية بقدرة <span class="num">${n(a.kw)}</span> كيلوواط`)}
${a.supplier ? row(vet ? 'المورّد' : 'المورّد المعتمد', esc(p.supplier)) : ''}
${a.price ? row('الكلفة الكلية', iqd(a.price)) : ''}
${row('مبلغ التمويل', `<b>${iqd(amount)}</b>`)}
${row('مدة السداد', `<span class="num">${n(a.term_months)}</span> شهراً${a.grace_months ? ` تتضمن مدة إمهال <span class="num">${n(a.grace_months)}</span> أشهر` : ''}`)}
${a.margin != null ? row('هامش الربح / الفائدة السنوي', `<span class="num">${esc(a.margin)}</span>٪`) : ''}
${row('القسط الشهري', `<b>${iqd(a.monthly_installment)}</b>`)}
${total ? row('مجموع الأقساط', iqd(total)) : ''}
${row('نوع الضمان', esc(GUAR[a.guarantee_type] || a.guarantee_type || '—'))}
${gs.length ? row('الكفلاء', gs.map((g, i) => `${i + 1}. ${esc(g.name)}${g.employer ? ` — ${esc(g.employer)}` : ''}`).join('<br>')) : ''}
</table>
<h2>ثالثاً: الشروط</h2>
<ol>
<li>يُصرف مبلغ التمويل مباشرةً إلى ${vet ? 'المورّد على دفعات مرتبطة بالتوريد والتركيب والتشغيل' : 'المورّد المعتمد بعد التركيب والكشف والتدقيق الهندسي المطابق'}، ولا يُسلَّم نقداً إلى المقترض.</li>
<li>يلتزم المقترض بسداد القسط الشهري في موعده المحدد في جدول الأقساط الذي يتسلمه بعد التنفيذ، ويخوّل المصرف قيد الأقساط على حسابه لديه.</li>
<li>يحق للمقترض السداد المبكر كلياً أو جزئياً وفق تعليمات المصرف النافذة.</li>
<li>عند التأخر عن سداد ثلاثة أقساط متتالية يحق للمصرف المطالبة بكامل الرصيد المتبقي والتنفيذ على الضمانات المقدَّمة.</li>
<li>يلتزم المقترض بالمحافظة على ${vet ? 'الأجهزة والمعدات الممولة' : 'المنظومة الممولة'} وعدم التصرف بها قبل سداد كامل التمويل، وبالتأمين عليها إن اشترط المصرف ذلك.</li>
<li>يقرّ المقترض بصحة البيانات المقدَّمة منه، وبأن أي بيان غير صحيح يجيز للمصرف فسخ العقد والمطالبة بكامل المبلغ.</li>
<li>يخضع هذا العقد للقوانين العراقية النافذة وتعليمات البنك المركزي العراقي، وتختص محاكم مركز المصرف بالنظر في أي نزاع ينشأ عنه.</li>
<li>يُوقَّع هذا العقد إلكترونياً، ويقرّ الطرفان بحجية التوقيع الإلكتروني وفق قانون التوقيع الإلكتروني والمعاملات الإلكترونية رقم 78 لسنة 2012، وتُعدّ شهادة إتمام التوقيع الملحقة جزءاً لا يتجزأ منه.</li>
</ol>
<div class="sig"><div>الطرف الأول — ${esc(p.bank)}<br>${esc(p.staff && p.staff.title || '')}${p.staff && p.staff.code ? ` · الرمز الوظيفي <span class="num">${esc(p.staff.code)}</span>` : ''}</div><div>الطرف الثاني — المقترض<br>${esc(b.full_name)} · توقيع إلكتروني (الملحق)</div></div>
<div class="note">نموذج عقد صادر من المنصة لأغراض التشغيل التجريبي — يُعتمد النص النهائي من القسم القانوني للمصرف.</div>

<div class="page"></div>
<h1>كمبيالة (سند لأمر)</h1>
<div class="sub">مرتبطة بعقد التمويل رقم <b class="num">${esc(a.code)}</b></div>
<div class="box">
<p>أتعهد أنا الموقِّع أدناه <b>${esc(b.full_name)}</b>، حامل البطاقة الوطنية الموحدة رقم <b class="num">${esc(b.national_id || '—')}</b>،
بأن أدفع لأمر <b>${esc(p.bank)}</b> مبلغاً قدره <b>${iqd(total || amount)}</b>
على أقساط شهرية قيمة كل منها <b>${iqd(a.monthly_installment)}</b> لمدة <b class="num">${n(a.term_months)}</b> شهراً وفق جدول الأقساط،
والقيمة وصلتني تمويلاً بموجب العقد أعلاه.</p>
<p>مكان الإنشاء: ${esc(p.branch || p.bank)} · تاريخ الإنشاء: ${esc(day())}</p>
<div class="sig"><div>المحرِّر (المدين): ${esc(b.full_name)} — توقيع إلكتروني (الملحق)</div><div>المستفيد: ${esc(p.bank)}</div></div>
</div>
</body></html>`;
  }

  // ───────── الجلسة 43: التعهدات والضمانات للطلب الإسلامي (المرحلة 25) ─────────
  // لا ينعقد هنا بيع ولا إجارة ولا يُنشأ دين: العقد المعتمد من الهيئة يوقّعه المقترض بعد أن يتملّك المصرف الأصل ويقبضه.
  const GUAR_ISL = { ...GUAR, gold: 'رهن ذهب' };
  function pledgeHtml(p) {
    const a = p.app, b = p.borrower, I = p.islamic, vet = a.program === 'vet', N = I.noun || (vet ? 'الأجهزة' : 'المنظومة');
    const gs = (a.guarantee && a.guarantee.guarantors) || [];
    const c = I.calc || {};
    const row = (k, v) => `<tr><th>${esc(k)}</th><td>${v}</td></tr>`;
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{color:#111;font-size:10.5pt;line-height:1.65;margin:0}
h1{font-size:16pt;text-align:center;margin:0 0 2px}.sub{text-align:center;color:#555;font-size:9.5pt;margin-bottom:10px}
h2{font-size:12pt;color:#0f3d3e;border-bottom:1.5px solid #0f3d3e;margin:14px 0 6px;padding-bottom:2px}
table{width:100%;border-collapse:collapse;margin:4px 0}th,td{text-align:right;padding:2px 7px;border:1px solid #d9dee3;vertical-align:top}th{width:34%;background:#f4f7f7}
ol{margin:4px 0;padding-right:22px}li{margin:4px 0}.num{direction:ltr;unicode-bidi:embed}
.isl{border:1.5px solid #0f3d3e;background:#f1f8f6;border-radius:8px;padding:8px 12px;margin:8px 0;font-size:10pt}
.note{border:1px dashed #b45309;color:#7c2d12;background:#fff7ed;padding:6px 10px;border-radius:6px;font-size:9pt;margin-top:10px}
.sig{display:flex;gap:18px;margin-top:14px}.sig div{flex:1;border-top:1px solid #999;padding-top:4px;font-size:9.5pt;color:#444;text-align:center}
</style></head><body>
<h1>التعهدات والضمانات</h1>
<div class="sub">تمويل إسلامي — ${esc(I.type_name || '')} · طلب رقم <b class="num">${esc(a.code)}</b> · حُرِّر إلكترونياً عبر منصة «ألواح» في ${esc(day())}</div>
<div class="isl"><b>هذه الوثيقة ليست عقد ${I.type === 'IJM' ? 'الإجارة' : 'البيع'} ولا تُنشئ ديناً.</b> يشتري المصرف ${esc(N)} من المورد باسمه ويقبضها أولاً، ثم يوقّع المقترض «${esc(I.contract_name || 'العقد المعتمد')}» بالنص المعتمد من ${esc(I.board || 'الهيئة الشرعية')} حرفياً${I.two_phase ? '' : ' (وُقّع عند إرسال الطلب)'}.</div>
<h2>أولاً: الطرفان</h2>
<table>
${row('المصرف', `${esc(p.bank)}${p.branch ? ` — ${esc(p.branch)}` : ''}`)}
${row('المتعامل', esc(b.full_name))}
${row('رقم البطاقة الوطنية الموحدة', `<span class="num">${esc(b.national_id || '—')}</span>`)}
${row('العنوان', esc([b.governorate, b.city, b.address].filter(Boolean).join(' — ') || '—'))}
${row('رقم الهاتف', `<span class="num">${esc(b.phone || '—')}</span>`)}
${a.bank_account ? row('رقم الحساب لدى المصرف', `<span class="num">${esc(a.bank_account)}</span>`) : ''}
</table>
<h2>ثانياً: المنتج المعتمد شرعاً</h2>
<table>
${row('المنتج', esc(I.product || '—'))}
${row('الصيغة', esc(I.type_name || I.type || '—'))}
${row('قرار الهيئة الشرعية', `<span class="num">${esc(I.resolution || '—')}</span>`)}
${row(vet ? 'الأجهزة' : 'المنظومة', esc(I.asset || '—'))}
${I.promise_code ? row(I.promise_title || 'الوعد غير الملزم', `موقّع في ${esc(day(I.promise_at))} · رمز التحقق <span class="num">${esc(I.promise_code)}</span>`) : ''}
${c.total ? row('الثمن المتوقع في العقد', `${iqd(c.total)} = كلفة ${iqd(c.cost)} + ربح معلوم ${iqd(c.profit)} — ${iqd(c.installment)} × <span class="num">${n(c.term)}</span> شهراً`) : ''}
</table>
<h2>ثالثاً: الضمانات</h2>
<table>
${row('نوع الضمان', esc(GUAR_ISL[a.guarantee_type] || a.guarantee_type || '—'))}
${gs.length ? row('الكفلاء', gs.map((g, i) => `${i + 1}. ${esc(g.name)}${g.employer ? ` — ${esc(g.employer)}` : ''}`).join('<br>')) : ''}
</table>
<h2>رابعاً: التعهدات</h2>
<ol>
<li>أقرّ بأن هذه الوثيقة ليست عقد ${I.type === 'IJM' ? 'إجارة' : 'بيع'} ولا سنداً بدين، وأن ${I.two_phase ? `العقد ينعقد بعد أن يتملّك المصرف ${esc(N)} ويقبضها، بالنص المعتمد بالقرار <span class="num">${esc(I.resolution || '—')}</span> حرفياً، وبالربح المعلن في الوعد دون زيادة` : `العقد المعتمد بالقرار <span class="num">${esc(I.resolution || '—')}</span> هو ما وقّعته عند إرسال الطلب`}.</li>
<li>تُقدَّم الضمانات المذكورة أعلاه الآن، وتكون ضماناً لما يثبت في ذمّتي بموجب العقد من تاريخ انعقاده، ولا يُستوفى منها إلا قدر الدين المستحق فعلاً.</li>
${gs.length ? '<li>يتعهد الكفلاء بكفالة ما يثبت في ذمّة المتعامل بموجب العقد عند انعقاده، ويُفعَّل الاستقطاع من رواتبهم للأقساط المستحقة بعد العقد فقط.</li>' : ''}
<li>أخوّل المصرف قيد الأقساط المستحقة بعد العقد على حسابي لديه وفق جدول الأقساط الذي أتسلّمه بعد التنفيذ.</li>
<li>أتعهد بالمحافظة على ${esc(N)} بعد تسلّمها وعدم التصرف بها قبل وفاء الثمن، وبالتأمين عليها إن اشترط المصرف ذلك.</li>
<li>لا تُضاف أي زيادة على الدين بسبب التأخر لمصلحة المصرف. ${esc(I.late_rule || 'للمصرف المطالبة بالأقساط المستحقة والرجوع إلى الضمانات بقدر الدين.')}</li>
<li>أقرّ بصحة البيانات المقدَّمة مني، وبحجية التوقيع الإلكتروني وفق قانون التوقيع الإلكتروني والمعاملات الإلكترونية رقم 78 لسنة 2012، وتُعدّ شهادة إتمام التوقيع الملحقة جزءاً من هذه الوثيقة.</li>
</ol>
<div class="sig"><div>المصرف — ${esc(p.bank)}<br>${esc(p.staff && p.staff.title || '')}${p.staff && p.staff.code ? ` · الرمز الوظيفي <span class="num">${esc(p.staff.code)}</span>` : ''}</div><div>المتعامل<br>${esc(b.full_name)} · توقيع إلكتروني (الملحق)</div></div>
<div class="note">لا تُحرَّر كمبيالة بمبلغ قبل انعقاد العقد. نموذج صادر من المنصة للتشغيل التجريبي — يُعتمد النص النهائي من القسم القانوني للمصرف وهيئته الشرعية.</div>
</body></html>`;
  }

  // ───────── الجلسة 43: قرار الهيئة الشرعية للتوقيع الإلكتروني من الرئيس ─────────
  function resolutionHtml(p) {
    const r = p.res, pr = p.product, bd = p.board, v = p.version, t = r.votes || {};
    const row = (k, val) => `<tr><th>${esc(k)}</th><td>${val}</td></tr>`;
    const dis = (r.dissent || []).map(d => `<li>${esc(d.name)}${d.reason ? ` — ${esc(d.reason)}` : ''}</li>`).join('');
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{color:#111;font-size:11pt;line-height:1.7;margin:0}
h1{font-size:16pt;text-align:center;margin:0}.sub{text-align:center;color:#555;font-size:10pt;margin:2px 0 12px}
h2{font-size:12pt;color:#0f3d3e;border-bottom:1.5px solid #0f3d3e;margin:14px 0 6px;padding-bottom:2px}
table{width:100%;border-collapse:collapse}th,td{text-align:right;padding:3px 8px;border:1px solid #d9dee3;vertical-align:top}th{width:32%;background:#f4f7f7}
.num{direction:ltr;unicode-bidi:embed}.code{font-family:monospace;font-size:8.5pt;word-break:break-all;direction:ltr}
.body{border:2px solid #0f3d3e;border-radius:8px;padding:12px 14px;margin:8px 0;white-space:pre-line}
.sig{margin-top:18px;border-top:1px solid #999;padding-top:6px;text-align:center;font-size:10pt;color:#333}
</style></head><body>
<h1>${esc(bd.name)}</h1>
<div class="sub">على ${esc(bd.madhhab)}${bd.marja ? ` · المرجع: ${esc(bd.marja)}` : ''}</div>
<h1 style="font-size:14pt">قرار رقم <span class="num">${esc(r.code)}</span> — ${esc(r.decision_label)}</h1>
<div class="sub">صدر في ${esc(day(r.issued_at))}</div>
<h2>موضوع القرار</h2>
<table>
${row('المنتج', esc(pr.name))}
${row('رمز المنتج', `<span class="num">${esc(pr.code)}</span>`)}
${row('الصيغة', esc(pr.type_name || pr.type))}
${row('القطاع', esc(pr.sector || '—'))}
${row('المصرف', esc(pr.bank || '—'))}
${row('نسخة العقد المعتمدة', `<span class="num">${esc(v.n)}</span>`)}
${row('عدد بنود العقد', `<span class="num">${esc(v.clauses)}</span>`)}
${row('بصمة نص العقد (SHA-256)', `<span class="code">${esc(r.version_sha256 || v.sha256 || '')}</span>`)}
</table>
<h2>نص القرار</h2>
<div class="body">${esc(r.body || '')}${r.conditions ? `\n\nالشروط:\n${esc(r.conditions)}` : ''}</div>
<h2>التصويت</h2>
<table>
${row('اعتماد', `<span class="num">${n(t.approve)}</span>`)}${row('اعتماد بشرط', `<span class="num">${n(t.approve_cond)}</span>`)}${row('رفض', `<span class="num">${n(t.reject)}</span>`)}
${row('المصوّتون / النصاب', `<span class="num">${n(t.cast)}</span> من <span class="num">${n(t.members)}</span> — النصاب <span class="num">${n(t.quorum)}</span>`)}
</table>
${dis ? `<h2>المخالفون</h2><ol>${dis}</ol>` : ''}
<h2>الختم الرقمي</h2>
<table>${row('ختم القرار', `<span class="code">${esc(r.seal || '')}</span>`)}${row('أُصدر', esc(r.signed_via || ''))}</table>
<div class="sig">رئيس الهيئة — ${esc(p.head.full_name)}${p.head.code ? ` · <span class="num">${esc(p.head.code)}</span>` : ''}<br>توقيع إلكتروني موثوق (شهادة الإتمام ملحقة)</div>
</body></html>`;
  }

  // ───────── أدوات HTTP ─────────
  const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(obj)); };
  const readBody = (req, max = 2e6) => new Promise((ok, bad) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > max) { bad(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', bad);
  });
  const jwtOf = req => { const h = String(req.headers.authorization || ''); return h.startsWith('Bearer ') ? h.slice(7).trim() : ''; };
  const isUuid = s => /^[0-9a-f-]{36}$/i.test(String(s || ''));
  const publicUrl = req => PUBLIC_URL || `https://${req.headers['x-forwarded-host'] || req.headers.host}`;

  async function start(req, res) {
    const jwt = jwtOf(req); if (!jwt) return json(res, 401, { error: 'سجّل الدخول أولاً' });
    const { app_id } = JSON.parse((await readBody(req, 1e4)).toString() || '{}');
    if (!isUuid(app_id)) return json(res, 400, { error: 'طلب غير صالح' });
    const p = await rpc('esign_prepare', { p_app: app_id }, jwt);
    if (p.request && p.request.status === 'sent') return json(res, 409, { error: 'العقد مُرسَل للتوقيع بالفعل — ألغِ الطلب الحالي لإرسال عقد جديد' });
    if (!p.face || !p.face.data) return json(res, 400, { error: 'أرفق أولاً الصورة المرجعية لوجه المقترض (صورة البطاقة الوطنية أو صورة حضورية)' });
    const a = p.app;
    const s = await svc('POST', '/v1/sessions', {
      loan_reference: a.code,
      document: p.islamic   // الجلسة 43
        ? { title: 'التعهدات والضمانات — تمويل إسلامي', filename: `${a.code}-pledges.pdf`, content_html: pledgeHtml(p) }
        : { title: a.program === 'vet' ? 'عقد تمويل مشروع بيطري' : 'عقد تمويل منظومة طاقة شمسية', filename: `${a.code}-contract.pdf`, content_html: contractHtml(p) },
      signer: { external_id: p.borrower.id, full_name: p.borrower.full_name, phone: p.borrower.phone || null, national_id: p.borrower.national_id || null },
      reference_face_base64: String(p.face.data).replace(/^data:[^,]+,/, ''),
      summary: { 'رقم الطلب': a.code, 'المصرف': p.bank || '', 'مبلغ التمويل': `${n(a.amount || a.price)} دينار`, 'مدة السداد': `${a.term_months} شهراً`, 'القسط الشهري': `${n(a.monthly_installment)} دينار` },
      expires_in_minutes: 60 * 72,
      callback_url: `${publicUrl(req)}/api/esign/webhook`,
    });
    await rpc('esign_record', { p_secret: DB_SECRET, p_app: app_id, p_data: { ...s, face_doc: p.face.id } }, jwt);
    json(res, 200, { ok: true, expires_at: s.expires_at });
  }

  // الجلسة 43: رئيس الهيئة يوقّع قراره — نص القرار ← مطابقة الوجه وكشف الحيوية ← بصمة الجهاز
  async function shariaStart(req, res) {
    const jwt = jwtOf(req); if (!jwt) return json(res, 401, { error: 'سجّل الدخول أولاً' });
    const { res_id } = JSON.parse((await readBody(req, 1e4)).toString() || '{}');
    if (!isUuid(res_id)) return json(res, 400, { error: 'طلب غير صالح' });
    const p = await rpc('sharia_esign_prepare', { p_res: res_id }, jwt);
    if (p.res.esign_status === 'signed') return json(res, 409, { error: 'وُقّع هذا القرار إلكترونياً سابقاً' });
    if (!p.face || !p.face.data) return json(res, 400, { error: 'أضف أولاً صورتك المرجعية للتوقيع من «الهيئة والإعدادات»' });
    const r = p.res;
    const s = await svc('POST', '/v1/sessions', {
      loan_reference: r.code,
      document: { title: `قرار الهيئة الشرعية ${r.code}`, filename: `${r.code}.pdf`, content_html: resolutionHtml(p) },
      signer: { external_id: p.head.id, full_name: p.head.full_name, phone: p.head.phone || null, national_id: p.head.national_id || null },
      reference_face_base64: String(p.face.data).replace(/^data:[^,]+,/, ''),
      summary: { 'رقم القرار': r.code, 'القرار': r.decision_label, 'المنتج': p.product.name, 'المصرف': p.product.bank || '' },
      expires_in_minutes: 60 * 24,
      callback_url: `${publicUrl(req)}/api/esign/webhook`,
    });
    await rpc('sharia_esign_record', { p_secret: DB_SECRET, p_res: res_id, p_data: s }, jwt);
    json(res, 200, { ok: true, signing_url: s.signing_url, expires_at: s.expires_at });
  }

  async function cancel(req, res) {
    const jwt = jwtOf(req); if (!jwt) return json(res, 401, { error: 'سجّل الدخول أولاً' });
    const { app_id, note } = JSON.parse((await readBody(req, 1e4)).toString() || '{}');
    if (!isUuid(app_id)) return json(res, 400, { error: 'طلب غير صالح' });
    const p = await rpc('esign_prepare', { p_app: app_id }, jwt);
    if (!p.request || p.request.status !== 'sent') return json(res, 400, { error: 'لا يوجد طلب توقيع معلّق' });
    try { await svc('POST', `/v1/sessions/${p.request.session_id}/cancel`, {}); }
    catch (e) { if (!/not_cancellable|not_found|404|409/.test(String(e.code || e.message))) throw e; }
    await rpc('esign_apply', { p_secret: DB_SECRET, p_session: p.request.session_id, p_event: 'session.cancelled', p_data: { note: String(note || '').slice(0, 300) || null } }, jwt);
    json(res, 200, { ok: true });
  }

  async function webhook(req, res) {
    const raw = await readBody(req, 1e5);
    const c = await config();
    const ts = String(req.headers['x-esign-timestamp'] || ''), sig = String(req.headers['x-esign-signature'] || '');
    const exp = 'sha256=' + crypto.createHmac('sha256', c.webhook_secret).update(ts + '.').update(raw).digest('hex');
    const okSig = sig.length === exp.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp));
    if (!okSig || !/^\d+$/.test(ts) || Math.abs(Date.now() / 1000 - Number(ts)) > 300) {
      CFG = null; // ربما تغيّرت المفاتيح — يُعاد تحميلها في المحاولة التالية
      return json(res, 401, { error: 'bad_signature' });
    }
    const ev = JSON.parse(raw.toString());
    const d = ev.data || {};
    if (!isUuid(d.session_id)) return json(res, 400, { error: 'bad_payload' });
    let pdf = null;
    if (ev.event === 'signature.completed') {
      const buf = await svc('GET', `/v1/sessions/${d.session_id}/signed-document`, null, true);
      if (buf.subarray(0, 5).toString('latin1') !== '%PDF-') throw new Error('signed document is not a PDF');
      pdf = 'data:application/pdf;base64,' + buf.toString('base64');
    }
    let r = await rpc('esign_apply', { p_secret: DB_SECRET, p_session: d.session_id, p_event: ev.event, p_data: d, p_pdf: pdf });
    // الجلسة 43: الجلسة ليست لعقد طلب — قد تكون لقرار الهيئة الشرعية
    if (r && r.ignored === 'unknown_session') r = await rpc('sharia_esign_apply', { p_secret: DB_SECRET, p_session: d.session_id, p_event: ev.event, p_data: d, p_pdf: pdf });
    json(res, 200, r || { ok: true });
  }

  async function health(req, res) {
    const out = { configured: !!DB_SECRET, linked: false, service: null };
    try {
      const c = await config(true); out.linked = true; out.base_url = c.base_url; out.registered_at = c.registered_at;
      const r = await fetch(c.base_url + '/health', { signal: AbortSignal.timeout(8000) }); out.service = r.ok ? 'ok' : `http ${r.status}`;
    } catch (e) { out.error = e.message; }
    json(res, 200, out);
  }

  // يعيد true إن عالج الطلب
  function handle(req, res, p) {
    if (!p.startsWith('/api/esign/')) return false;
    const route = { 'POST /api/esign/start': start, 'POST /api/esign/cancel': cancel, 'POST /api/esign/webhook': webhook, 'GET /api/esign/health': health, 'POST /api/esign/sharia/start': shariaStart }[`${req.method} ${p}`];
    if (!route) { json(res, 404, { error: 'not_found' }); return true; }
    route(req, res).catch(e => { console.error('[esign]', p, e.message); if (!res.headersSent) json(res, e.status || 500, { error: e.message || 'خطأ' }); });
    return true;
  }
  handle.contractHtml = contractHtml; // للمعاينة والاختبار
  handle.pledgeHtml = pledgeHtml; handle.resolutionHtml = resolutionHtml;
  return handle;
};
