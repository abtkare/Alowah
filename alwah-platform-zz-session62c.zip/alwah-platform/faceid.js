// ألواح — الجلسة 49: التحقق بالوجه (Face ID) لموظفي الجهات. بلا حزم خارجية.
// يعتمد WebAuthn: الجهاز يتحقق من وجه صاحبه (Face ID / بصمة الوجه أو الإصبع) ويوقّع «تحدياً» بمفتاح لا يغادر الجهاز،
// والخادم هنا يفحص التوقيع بالمفتاح العام المسجّل، ثم يسجّل في قاعدة البيانات «تحققاً» صالحاً لدقيقة ونصف يسمح بالإجراء.
// المسارات (بجلسة الموظف):
//   POST /api/face/options  { mode: 'register' | 'verify' }   → خيارات WebAuthn
//   POST /api/face/finish   { mode, challenge, id, clientDataJSON, authenticatorData, signature | publicKey+alg, device }
const crypto = require('crypto');

module.exports = function faceid({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET }) {
  async function rpc(fn, args, jwt) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${jwt}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(args),
    });
    const t = await r.text();
    let j; try { j = t ? JSON.parse(t) : null; } catch { j = t; }
    if (!r.ok) throw Object.assign(new Error((j && (j.message || j.error)) || `rpc ${fn} ${r.status}`), { status: 400 });
    return j;
  }
  const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(obj)); };
  const readBody = req => new Promise((ok, bad) => {
    const c = []; let n = 0;
    req.on('data', d => { n += d.length; if (n > 64e3) { bad(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); } else c.push(d); });
    req.on('end', () => ok(Buffer.concat(c).toString())); req.on('error', bad);
  });
  const jwtOf = req => { const h = String(req.headers.authorization || ''); return h.startsWith('Bearer ') ? h.slice(7).trim() : ''; };
  const b64u = s => Buffer.from(String(s || ''), 'base64url');
  const sha256 = b => crypto.createHash('sha256').update(b).digest();
  const hostOf = req => String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  const rpIdOf = req => hostOf(req).replace(/:\d+$/, '');
  const originOk = (o, req) => o === `https://${hostOf(req)}` || (/^(localhost|127\.0\.0\.1)$/.test(rpIdOf(req)) && o === `http://${hostOf(req)}`);
  const uuidBytes = u => Buffer.from(String(u).replace(/-/g, ''), 'hex').toString('base64url');
  const fail = (m, s = 400) => Object.assign(new Error(m), { status: s });

  async function options(req, res) {
    const jwt = jwtOf(req); if (!jwt) return json(res, 401, { error: 'سجّل الدخول أولاً' });
    if (!DB_SECRET) return json(res, 503, { error: 'لم يُضَف ESIGN_DB_SECRET إلى إعدادات الخادم' });
    const { mode } = JSON.parse((await readBody(req)) || '{}');
    if (!['register', 'verify'].includes(mode)) return json(res, 400, { error: 'طلب غير صالح' });
    let p;
    try { p = await rpc('face_begin', { p_secret: DB_SECRET, p_kind: mode }, jwt); }
    catch (e) { const m = String(e.message || ''); return json(res, m.startsWith('NO_FACE') ? 409 : 400, { error: m.replace(/^NO_FACE:\s*/, ''), code: m.startsWith('NO_FACE') ? 'no_face' : undefined }); }
    const rpId = rpIdOf(req);
    const creds = (p.creds || []).map(id => ({ type: 'public-key', id }));
    if (mode === 'register') return json(res, 200, { publicKey: {
      challenge: p.challenge, rp: { id: rpId, name: 'ألواح' },
      user: { id: uuidBytes(p.user_id), name: p.username, displayName: p.full_name || p.username },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -8 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'preferred' },
      excludeCredentials: creds, attestation: 'none', timeout: 90000 } });
    return json(res, 200, { publicKey: { challenge: p.challenge, rpId, allowCredentials: creds, userVerification: 'required', timeout: 90000 } });
  }

  async function finish(req, res) {
    const jwt = jwtOf(req); if (!jwt) return json(res, 401, { error: 'سجّل الدخول أولاً' });
    const b = JSON.parse((await readBody(req)) || '{}');
    const mode = b.mode;
    if (!['register', 'verify'].includes(mode) || !b.challenge || !b.id) throw fail('طلب غير صالح');
    const cdRaw = b64u(b.clientDataJSON), ad = b64u(b.authenticatorData);
    let cd; try { cd = JSON.parse(cdRaw.toString('utf8')); } catch { throw fail('بيانات التحقق غير صالحة'); }
    if (cd.type !== (mode === 'register' ? 'webauthn.create' : 'webauthn.get')) throw fail('نوع التحقق غير صحيح');
    if (cd.challenge !== b.challenge) throw fail('التحدي غير مطابق — أعد المحاولة');
    if (!originOk(cd.origin, req)) throw fail('مصدر التحقق غير معروف');
    if (ad.length < 37) throw fail('بيانات الجهاز ناقصة');
    if (!ad.subarray(0, 32).equals(sha256(rpIdOf(req)))) throw fail('النطاق غير مطابق');
    const flags = ad[32];
    if (!(flags & 0x01)) throw fail('لم يؤكد صاحب الجهاز حضوره');
    if (!(flags & 0x04)) throw fail('لم يتحقق الجهاز من وجهك — فعّل Face ID أو قفل الشاشة على جهازك');
    const signCount = ad.readUInt32BE(33);
    const device = String(b.device || '').slice(0, 80);

    if (mode === 'register') {
      if (!(flags & 0x40)) throw fail('لم يُرسل الجهاز مفتاحه');
      const len = ad.readUInt16BE(53), credId = ad.subarray(55, 55 + len);
      if (credId.toString('base64url') !== b.id) throw fail('معرّف المفتاح غير مطابق');
      let key; try { key = crypto.createPublicKey({ key: b64u(b.publicKey), format: 'der', type: 'spki' }); } catch { throw fail('مفتاح الجهاز غير صالح — حدّث المتصفح'); }
      const alg = Number(b.alg);
      if (![-7, -8, -257].includes(alg)) throw fail('نوع مفتاح غير مدعوم');
      const r = await rpc('face_done', { p_secret: DB_SECRET, p_challenge: b.challenge, p_kind: 'register',
        p_data: { id: b.id, public_key: key.export({ format: 'der', type: 'spki' }).toString('base64url'), alg, sign_count: signCount, device } }, jwt);
      return json(res, 200, r);
    }

    const k = await rpc('face_cred', { p_secret: DB_SECRET, p_challenge: b.challenge, p_cred: b.id }, jwt);
    const key = crypto.createPublicKey({ key: b64u(k.public_key), format: 'der', type: 'spki' });
    const data = Buffer.concat([ad, sha256(cdRaw)]);
    const sig = b64u(b.signature);
    const ok = k.alg === -8 ? crypto.verify(null, data, key, sig) : crypto.verify('sha256', data, key, sig);
    if (!ok) throw fail('لم يتطابق التوقيع — التحقق مرفوض', 403);
    if (signCount && Number(k.sign_count) && signCount <= Number(k.sign_count)) throw fail('عدّاد الجهاز غير متوقع — قد يكون المفتاح منسوخاً. اطلب من مديرك إعادة ضبط بصمة الوجه', 403);
    const r = await rpc('face_done', { p_secret: DB_SECRET, p_challenge: b.challenge, p_kind: 'verify', p_data: { id: b.id, sign_count: signCount } }, jwt);
    return json(res, 200, r);
  }

  // يعيد true إن عالج الطلب
  return function handle(req, res, p) {
    if (!p.startsWith('/api/face/')) return false;
    const fn = req.method === 'POST' && { '/api/face/options': options, '/api/face/finish': finish }[p];
    if (!fn) { json(res, 404, { error: 'not_found' }); return true; }
    fn(req, res).catch(e => { if (!res.headersSent) json(res, e.status || 500, { error: e.status ? e.message : 'تعذّر التحقق — أعد المحاولة' }); else res.end(); console.error('[face]', e.message); });
    return true;
  };
};
