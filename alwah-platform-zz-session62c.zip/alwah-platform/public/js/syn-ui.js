// الجلسة 60: نقابة الأطباء البيطريين — أدوات مشتركة بين بوابة الطبيب (/vets) وبوابة النقابة (/syndicate)
import { esc, badge } from './core.js';
import { qrSvg } from './qr.js';

export const SF_ST = {
  draft: ['مسودة', 'muted'], new: ['قسم العضوية والتسجيل', 'info'], audit: ['التدقيق والسجلات', 'info'], finance: ['الحسابات', 'info'],
  approval: ['اعتماد النقيب', 'warn'], print: ['الطباعة', 'warn'], ship: ['مع شركة التوصيل', 'warn'], done: ['أُنجزت', 'ok'],
  returned: ['أُعيدت للطبيب', 'warn'], rejected: ['مرفوضة', 'bad'], cancelled: ['ملغاة', 'muted'],
};
export const SF_KIND = { activate: ['تفعيل عضوية', '🔑'], join: ['انتساب جديد', '🎓'], renewal: ['تجديد الهوية', '🔄'] };
export const SM_ST = { pending: ['قيد الدراسة', 'warn'], active: ['نافذة', 'ok'], expired: ['منتهية', 'bad'], suspended: ['معلّقة', 'bad'], rejected: ['مرفوضة', 'bad'] };
export const DLV_ST = { new: ['لدى الشركة — بانتظار مندوب', 'info'], assigned: ['أُسندت لمندوب', 'info'], picked: ['استلمها المندوب', 'warn'], out: ['في الطريق إليك', 'warn'],
  delivered: ['سُلّمت', 'ok'], failed: ['تعذّر التسليم — محاولة أخرى', 'bad'], returned: ['أُعيدت للنقابة', 'bad'] };
export const DEGREE = { bachelor: 'بكالوريوس طب وجراحة بيطرية', diploma: 'دبلوم تقني بيطري', master: 'ماجستير', phd: 'دكتوراه' };
const STEP_T = { new: 'العضوية', audit: 'التدقيق', finance: 'الحسابات', approval: 'الاعتماد', print: 'الطباعة', ship: 'التوصيل', done: 'تم' };

export const sfBadge = s => badge(SF_ST[s] || [s, 'muted']);
export const smBadge = s => badge(SM_ST[s] || [s, 'muted']);
export const dlvBadge = s => badge(DLV_ST[s] || [s, 'muted']);
export const verifyUrl = code => `${location.origin}/v/${encodeURIComponent(code || '')}`;
export const day = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'medium' }) : '—';

// شريط مراحل المعاملة من قسم إلى قسم
export function sfSteps(f) {
  const path = f.path || [];
  if (!path.length || ['rejected', 'cancelled', 'draft'].includes(f.status)) return '';
  let i = f.status === 'returned' ? 0 : path.indexOf(f.status);
  if (f.status === 'done') i = path.length;
  return `<div class="ins-steps">${path.map((k, j) => `<span class="${j < i ? 'done' : j === i ? 'on' : ''}"><i>${j < i ? '✓' : j + 1}</i>${STEP_T[k] || k}</span>`).join('')}</div>`;
}

// هوية النقابة كما تظهر في الهاتف (والقابلة للطباعة)
export function synCard(m, { card = null, photo = null, org = 'نقابة الأطباء البيطريين' } = {}) {
  const valid = m.status === 'active' && m.valid_until && new Date(m.valid_until) >= new Date(new Date().toDateString());
  return `<div class="un-card vs-card ${valid ? '' : 'off'}">
    <div class="row"><b>${esc(org)}</b><span class="sp"></span>${smBadge(valid ? 'active' : m.status === 'active' ? 'expired' : m.status)}</div>
    <div class="un-cb">${photo ? `<img class="vs-ph" src="${photo}" alt="الصورة الشخصية">` : '<div class="vs-ph vs-ph0">🩺</div>'}
      <div style="flex:1;min-width:0"><small>رقم العضوية</small><div class="num un-no" dir="ltr">${esc(m.membership_no || '—')}</div>
        <div><b>${esc(m.full_name || '')}</b></div><div class="small">${esc(m.specialty || DEGREE[m.degree] || 'طبيب بيطري')} · فرع ${esc(m.governorate || '')}</div>
        <div class="small">${m.valid_until ? `${valid ? 'نافذة حتى' : 'انتهت في'} <b class="num">${esc(m.valid_until)}</b>` : ''}${card ? ` · الهوية <span class="num">${esc(card.card_no)}</span>` : ''}</div></div>
      ${card?.verify_code ? `<div>${qrSvg(verifyUrl(card.verify_code), { size: 84, label: 'رمز التحقق من الهوية' })}</div>` : ''}</div></div>`;
}

// نسخة الطباعة (وجه وظهر بمقاس البطاقة 85.6×54 ملم)
export function printCard({ body, card_no, verify_code, version }, photo) {
  const b = body || {};
  const w = window.open('', '_blank');
  if (!w) return false;
  w.document.write(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>هوية ${esc(card_no)}</title>
  <style>@page{size:85.6mm 54mm;margin:0}body{margin:0;font-family:system-ui,Tahoma,sans-serif}
  .c{width:85.6mm;height:54mm;box-sizing:border-box;padding:3.5mm 4mm;page-break-after:always;position:relative;overflow:hidden;color:#0b2e17;background:linear-gradient(135deg,#f3fbf5,#dff3e5)}
  .h{display:flex;justify-content:space-between;align-items:center;border-bottom:.6mm solid #15803d;padding-bottom:1.2mm;font-weight:800;font-size:3.2mm}
  .b{display:flex;gap:3mm;margin-top:2.4mm}.ph{width:18mm;height:23mm;border-radius:1.5mm;object-fit:cover;background:#cfe9d6}
  .f{font-size:2.6mm;line-height:1.55}.f b{font-size:3.4mm}.n{font-size:4.6mm;font-weight:900;letter-spacing:.3mm;direction:ltr;text-align:right}
  .q svg{width:20mm;height:20mm}.k{font-size:2.3mm;color:#3b5a45}.back{display:flex;flex-direction:column;justify-content:space-between}
  @media screen{body{background:#888;padding:10px}.c{margin:10px auto;box-shadow:0 2px 10px rgba(0,0,0,.4)}}</style>
  <div class="c"><div class="h"><span>نقابة الأطباء البيطريين — العراق</span><span class="k" dir="ltr">${esc(card_no)}</span></div>
    <div class="b">${photo ? `<img class="ph" src="${photo}">` : '<div class="ph"></div>'}<div class="f">
      <div class="k">رقم العضوية</div><div class="n">${esc(b.membership_no || '')}</div>
      <b>${esc(b.name || '')}</b><br>${esc(b.specialty || DEGREE[b.degree] || 'طبيب بيطري')}<br>فرع ${esc(b.governorate || '')}
      <br>تاريخ الإصدار <span dir="ltr">${esc(b.issued_on || '')}</span> · النفاذ حتى <span dir="ltr">${esc(b.valid_until || '')}</span></div></div></div>
  <div class="c back"><div class="h"><span>للتحقق من الهوية امسح الرمز</span><span class="k">النسخة ${esc(version || b.version || 1)}</span></div>
    <div class="b" style="align-items:center"><div class="q">${qrSvg(verifyUrl(verify_code), { size: 160, label: 'رمز التحقق' })}</div>
      <div class="f">رمز التحقق<div class="n">${esc(verify_code)}</div>${esc(b.college || '')}${b.graduation_year ? ` — ${esc(b.graduation_year)}` : ''}
        <div class="k" style="margin-top:2mm">هذه الهوية ملك النقابة. تُعاد عند انتهاء العضوية. صدرت إلكترونياً من منصة «ألواح».</div></div></div></div>
  <script>setTimeout(()=>print(),400)</script></html>`);
  w.document.close();
  return true;
}
