// الجلسة 40: «الجهات والشركات» في لوحة مشغّل النظام
// المشغّل يضيف الجهة بخطوة واحدة (الجهة + فرعها الرئيسي + حساب الإدارة العليا)، والإدارة العليا تُعدّ كل حسابات موظفيها من «فريقي».
import { esc, num, badge, rpc, toast, cleanErr, modal, GOVS, ago } from './core.js';
import { paintFaceBadges, faceResetForm } from './face.js';   // الجلسة 49

export const KINDS = [
  { k: 'bank', t: 'مصرف', ic: '🏦', type: 'bank', portal: 'bank', suffix: 'md', mgr: 'الإدارة العليا للمصرف',
    hint: 'يضيف فروعه ومديري الفروع وموظفي كل قسم من «فريقي».',
    next: 'اضبط عمولة المصرف وعوائده من تبويب «المصارف والعمولات» ثم فعّل «يستقبل طلبات عبر المنصة». حتى ذلك لا يظهر المصرف للمقترضين.' },
  { k: 'supplier_solar', t: 'مورد منظومات الطاقة الشمسية', ic: '☀️', type: 'supplier', kind: 'solar', portal: 'supplier', suffix: 'admin', mgr: 'مدير حساب المورد',
    hint: 'ينشر عروض المنظومات ويضيف فنيي التركيب.', next: 'تنشر الإدارة عروضها من بوابة المورد، وتضيف فنيي التركيب من «فريقي».' },
  { k: 'supplier_vet', t: 'مورد الأجهزة والمواد الطبية البيطرية', ic: '🩺', type: 'supplier', kind: 'vet', portal: 'supplier', suffix: 'admin', mgr: 'مدير حساب المورد',
    hint: 'يجهّز المختبرات والعيادات وخطوط الإنتاج البيطرية.', next: 'تضيف الإدارة عروض الأجهزة من بوابة المورد، وفنييها من «فريقي».' },
  { k: 'eng_audit', t: 'شركة فحص هندسي', ic: '🔍', type: 'eng_audit', portal: 'auditor', suffix: 'admin', mgr: 'مدير الشركة',
    hint: 'تكشف على المشاريع المنفّذة في موقعها.', next: 'يضيف المدير مهندسيه من «فريقي»، ثم يحدد تخصص كل مهندس من «الفريق والتخصصات». تصل أوامر الكشف آلياً حسب المحافظات المغطاة.' },
  { k: 'insurer', t: 'شركة تأمين', ic: '🛡️', type: 'insurer', portal: 'insurance', suffix: 'md', mgr: 'الإدارة العليا لشركة التأمين',
    hint: 'تؤمّن المشاريع الممولة وتعوّض أضرارها.', next: 'تضيف الإدارة العليا فروعها من «فريقي ← الفروع»، ثم مدير كل فرع وموظفي الاكتتاب والمعاينة والمطالبات والحسابات. وتراجع أسعار منتجَي التأمين من بوابتها.' },
  { k: 'courier', t: 'شركة توصيل معتمدة', ic: '🚚', type: 'courier', portal: 'courier', suffix: 'admin', mgr: 'مدير شركة التوصيل',
    hint: 'توصل ما تصدره الجهات (هويات النقابة أولاً) إلى أصحابها برمز استلام.', next: 'يضيف المدير مندوبيه من «فريقي» (لكل مندوب محافظته). تظهر الشركة لقسم الهويات في النقابة عند إرسال الهويات.' },
  { k: 'chamber', t: 'اتحاد الغرف التجارية', ic: '🏪', type: 'chamber', portal: 'chamber', suffix: 'pres', mgr: 'رئيس الاتحاد',
    hint: 'يمنح هوية الغرفة التجارية ويؤيد القروض التجارية بعد الكشف على المحل، عبر غرفة تجارة لكل محافظة.', next: 'يضيف رئيس الاتحاد من «فريقي ← غرف المحافظات» غرفة لكل محافظة ورئيسها، ويضيف رئيس كل غرفة موظف التسجيل ومفتش الغرفة. ولجنة التصنيف والحسابات في المقر.' },
  { k: 'union', t: 'اتحاد صناعات / غرفة صناعة', ic: '🏭', type: 'union', portal: 'union', suffix: 'sg', mgr: 'رئيس الاتحاد',
    hint: 'يمنح الهوية الصناعية ويؤيد القروض الصناعية بعد الكشف على المعمل.', next: 'يضيف رئيس الاتحاد من «فريقي» موظفي العضوية والتسجيل ومهندسي الكشف (مع محافظة كل مهندس) ولجنة الصنف والحسابات. تصل طلبات تأييد القروض الصناعية آلياً.' },
];
const kindOf = o => o.type === 'supplier' ? (o.meta?.kind === 'vet' ? 'supplier_vet' : 'supplier_solar') : o.type;
const K = k => KINDS.find(x => x.k === k);
const GOV_NAMES = GOVS.map(g => Array.isArray(g) ? g[0] : g);
const genPw = () => { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz'; let s = ''; for (let i = 0; i < 5; i++) s += c[Math.floor(Math.random() * c.length)]; return s + '@' + (1000 + Math.floor(Math.random() * 9000)); };
const copyBox = (l, v) => `<div class="field"><label>${l}</label><div class="row" style="gap:6px;flex-wrap:nowrap"><input class="input" dir="ltr" readonly value="${esc(v)}"><button type="button" class="btn ghost sm" data-copy="${esc(v)}">نسخ</button></div></div>`;
const wireCopy = root => root.querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); toast('نُسخ', 'ok'); } catch { b.previousElementSibling.select(); } });

// اختيار المحافظات: «كل المحافظات» أو بعضها
function govPicker(sel = [], { allLabel = 'كل المحافظات' } = {}) {
  const all = !sel.length;
  return `<div class="og-govs" data-govs><label class="chip ${all ? 'on' : ''}"><input type="checkbox" data-all ${all ? 'checked' : ''}>${esc(allLabel)}</label>
    ${GOV_NAMES.map(g => `<label class="chip ${sel.includes(g) ? 'on' : ''}"><input type="checkbox" value="${esc(g)}" ${sel.includes(g) ? 'checked' : ''}>${esc(g)}</label>`).join('')}</div>`;
}
function wireGovs(root) {
  root.querySelectorAll('[data-govs]').forEach(box => {
    const all = box.querySelector('[data-all]');
    const paint = () => box.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.querySelector('input').checked));
    all.onchange = () => { if (all.checked) box.querySelectorAll('input:not([data-all])').forEach(i => { i.checked = false; }); paint(); };
    box.querySelectorAll('input:not([data-all])').forEach(i => i.onchange = () => { all.checked = !box.querySelector('input:not([data-all]):checked'); paint(); });
  });
}
const readGovs = box => box ? [...box.querySelectorAll('input:not([data-all]):checked')].map(i => i.value) : [];

// ───────── القائمة ─────────
export function adminOrgsView(X, D, body, H) {
  // الجلسة 42: جاهزية كل جهة (تُجلب مرة وتُحدَّث بعد كل تعديل)
  if (!X.ready) { X.ready = {}; rpc(X.sb, 'admin_orgs_readiness').then(r => { X.ready = r || {}; if (body.isConnected) adminOrgsView(X, D, body, H); }).catch(() => {}); }
  const f = X.orgF = X.orgF || { k: '', q: '' };
  const list = (X.orgs || []).filter(o => KINDS.some(k => k.type === o.type) && (!f.k || kindOf(o) === f.k)
    && (!f.q || o.name.includes(f.q.trim()) || o.code.includes(f.q.trim().toLowerCase())));
  const count = k => (X.orgs || []).filter(o => kindOf(o) === k).length;
  body.innerHTML = `
    <div class="card mb og-intro"><div class="row" style="flex-wrap:wrap;gap:10px"><div style="flex:1;min-width:220px"><h3 style="margin:0">الجهات والشركات المشتركة في المنصة</h3>
      <p class="small muted" style="margin:4px 0 0">أضف الجهة بخطوة واحدة: بياناتها وفرعها الرئيسي وحساب إدارتها العليا. الإدارة العليا تُعدّ بعدها حسابات موظفيها كلهم من «فريقي» — يوزر وباسورد لكل موظف في كل قسم.</p></div>
      <button class="btn cyan" data-new>＋ إضافة جهة</button></div></div>
    <div class="og-filter"><label class="chip ${!f.k ? 'on' : ''}"><input type="radio" name="ogk" value="" ${!f.k ? 'checked' : ''}>الكل</label>
      ${KINDS.map(k => `<label class="chip ${f.k === k.k ? 'on' : ''}"><input type="radio" name="ogk" value="${k.k}" ${f.k === k.k ? 'checked' : ''}>${k.ic} ${esc(k.t)} <b class="num">${count(k.k)}</b></label>`).join('')}
      <input class="input sm" data-q placeholder="بحث بالاسم أو الرمز" value="${esc(f.q)}"></div>
    <div class="og-list">${list.map(o => card(o, X, D)).join('') || '<div class="card empty">لا توجد جهات بهذا التصنيف — أضف أول جهة.</div>'}</div>`;
  body.querySelector('[data-new]').onclick = () => wizard(X, D, body, H);
  body.querySelectorAll('input[name=ogk]').forEach(r => r.onchange = () => { f.k = r.value; adminOrgsView(X, D, body, H); });
  const q = body.querySelector('[data-q]'); q.onchange = () => { f.q = q.value; adminOrgsView(X, D, body, H); };
  body.querySelectorAll('[data-og]').forEach(c => {
    const o = X.orgs.find(x => x.id === c.dataset.og);
    c.querySelector('[data-addm]')?.addEventListener('click', () => managerForm(X, D, body, H, o));
    c.querySelector('[data-edit]')?.addEventListener('click', () => editForm(X, D, body, H, o));
    c.querySelector('[data-susp]')?.addEventListener('click', () => suspendForm(X, D, body, H, o));
    c.querySelectorAll('[data-pw]').forEach(b => b.onclick = () => H.resetPw(D.users.find(u => u.id === b.dataset.pw)));
    c.querySelectorAll('[data-fid]').forEach(b => b.onclick = () => faceResetForm(X.sb, D.users.find(u => u.id === b.dataset.fid), () => paintFaceBadges(X.sb, body)));
  });
  paintFaceBadges(X.sb, body);   // الجلسة 49: حالة بصمة الوجه للإدارة العليا
}

function card(o, X, D) {
  const k = K(kindOf(o)), m = o.meta || {}, susp = !!m.suspended;
  const staff = D.users.filter(u => u.org_id === o.id), active = staff.filter(u => !u.disabled);
  const mgrs = staff.filter(u => u.manage_scope === 'org');
  const brs = D.branches.filter(b => b.bank_id === o.id);
  const apps = o.type === 'bank' ? D.apps.filter(a => (a.bank_id || a.bank_choice?.bank_id) === o.id).length : o.type === 'supplier' ? D.apps.filter(a => a.supplier_id === o.id).length : null;
  const cover = ['eng_audit', 'insurer', 'courier'].includes(o.type) ? ((m.governorates || []).length ? m.governorates.join('، ') : 'كل المحافظات') : '';
  return `<div class="card og-card ${susp ? 'off' : ''}" data-og="${o.id}">
    <div class="og-h"><span class="og-ic">${k.ic}</span><div style="flex:1;min-width:0"><b>${esc(o.name)}</b>
      <div class="small muted">${esc(k.t)} · <span class="num" dir="ltr">${esc(o.code)}</span>${m.license ? ` · ترخيص <span class="num">${esc(m.license)}</span>` : ''}</div></div>
      ${susp ? badge(['موقوفة', 'bad']) : o.type === 'bank' && m.accepting === false ? badge(['لا يستقبل طلبات', 'warn']) : badge(['فعّالة', 'ok'])}${o.is_islamic ? ' ' + badge(['إسلامي', 'info']) : ''}${o.type === 'bank' ? ' ' + badge(m.link_mode === 'api' ? ['ربط آلي', 'info'] : ['بلا ربط تقني — يعمل من البوابة', 'muted']) : ''}</div>
    ${susp ? `<div class="notice warn small" style="margin:8px 0 0">أُوقفت: ${esc(m.suspend_reason || '')}</div>` : ''}
    <div class="og-stats"><span>الموظفون <b class="num">${active.length}</b>${staff.length > active.length ? ` <small class="muted">(+${staff.length - active.length} موقوف)</small>` : ''}</span>
      ${brs.length || ['bank', 'insurer'].includes(o.type) ? `<span>الفروع <b class="num">${brs.length}</b></span>` : ''}${apps != null ? `<span>الطلبات <b class="num">${num(apps)}</b></span>` : ''}${cover ? `<span class="og-cover">📍 ${esc(cover)}</span>` : ''}</div>
    ${readyBox(X.ready?.[o.id], susp)}
    <div class="og-mgrs"><small class="muted">${esc(k.mgr)}${mgrs.length ? '' : ' — لا يوجد حساب بعد'}</small>
      ${mgrs.map(u => `<div class="og-mgr"><div style="flex:1;min-width:0"><b>${esc(u.full_name)}</b><div class="small muted"><span dir="ltr" class="num">${esc(u.username)}</span> · ${u.disabled ? 'موقوف' : u.must_change_password ? 'لم يغيّر كلمة المرور المؤقتة' : u.last_sign_in_at ? 'آخر دخول ' + ago(u.last_sign_in_at) : 'لم يدخل بعد'}</div></div>
        <span data-face="${u.id}"></span><button class="btn ghost sm" data-pw="${u.id}">كلمة المرور</button><button class="btn ghost sm" data-fid="${u.id}" title="إعادة ضبط بصمة الوجه">Face ID</button></div>`).join('')}</div>
    <div class="og-acts">${susp ? '' : `<button class="btn ghost sm" data-addm>＋ حساب إدارة عليا</button>`}<button class="btn ghost sm" data-edit>تعديل البيانات</button>
      <span class="sp"></span><button class="btn sm ${susp ? 'ok' : 'bad'}" data-susp>${susp ? 'إعادة التفعيل' : 'إيقاف الجهة'}</button></div>
  </div>`;
}

// الجلسة 42: ما ينقص الجهة قبل أن يصلها العمل (تُكمله إدارتها العليا من «فريقي»)
function readyBox(R, susp) {
  if (!R || susp) return '';
  const miss = R.missing || [];
  if (!miss.length) return `<div class="og-ready ok">✓ مكتملة — يصلها العمل آلياً</div>`;
  const shown = miss.slice(0, 4).map(x => esc(x.t) + (x.branch_name ? ` <small>(${esc(x.branch_name)})</small>` : '')).join('، ');
  return `<div class="og-ready ${R.routable ? 'warn' : 'bad'}"><b>${R.routable ? 'تعمل جزئياً' : 'لا يصلها عمل بعد'}</b> — ينقصها: ${shown}${miss.length > 4 ? ` و${miss.length - 4} غيرها` : ''}
    <div class="small muted">تُكمله إدارتها العليا من «فريقي».</div></div>`;
}

// ───────── معالج الإضافة: النوع ← البيانات ← الإدارة العليا ─────────
function wizard(X, D, body, H) {
  const S = { step: 1, k: null, d: { name: '', code: '', license: '', phone: '', is_islamic: false, govs: [], bname: 'الفرع الرئيسي — بغداد', bgovs: [], bphone: '' },
    m: { full_name: '', phone: '', username: '', password: genPw() } };
  const m = modal('<div data-w></div>', { wide: true });
  const box = m.el.querySelector('[data-w]');
  const head = () => `<div class="og-steps">${['نوع الجهة', 'البيانات', 'الإدارة العليا'].map((t, i) => `<span class="${S.step === i + 1 ? 'on' : S.step > i + 1 ? 'done' : ''}"><i>${S.step > i + 1 ? '✓' : i + 1}</i>${t}</span>`).join('')}</div>`;
  const paint = () => {
    const k = K(S.k);
    if (S.step === 1) {
      box.innerHTML = `${head()}<h3 style="margin:6px 0 10px">ما نوع الجهة التي تضيفها؟</h3>
        <div class="og-kinds">${KINDS.map(x => `<button type="button" class="og-kind ${S.k === x.k ? 'on' : ''}" data-k="${x.k}"><span>${x.ic}</span><b>${esc(x.t)}</b><small>${esc(x.hint)}</small></button>`).join('')}</div>
        <div class="row mt"><button class="btn ghost" data-x>إلغاء</button></div>`;
      box.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { S.k = b.dataset.k; S.step = 2; paint(); });
      box.querySelector('[data-x]').onclick = m.close;
      return;
    }
    if (S.step === 2) {
      const hasBr = ['bank', 'insurer'].includes(k.type), cov = ['eng_audit', 'insurer', 'courier'].includes(k.type);
      box.innerHTML = `${head()}<h3 style="margin:6px 0 10px">${k.ic} بيانات ${esc(k.t)}</h3>
        <div class="field"><label>الاسم الرسمي كاملاً ★</label><input class="input" data-d="name" value="${esc(S.d.name)}" placeholder="${k.type === 'bank' ? 'مثال: مصرف الفرات الأهلي' : k.type === 'insurer' ? 'مثال: الرافدين الوطنية للتأمين' : ''}"></div>
        <div class="grid g2" style="gap:12px">
          <div class="field"><label>الرمز المختصر بالإنجليزي ★</label><input class="input" data-d="code" dir="ltr" maxlength="8" value="${esc(S.d.code)}" placeholder="مثال: frt"><small class="muted">2–8 حروف. يبدأ به اسم دخول موظفيها (${esc(S.d.code || 'frt')}.cs)${hasBr ? ' ورمز فروعها' : ''}.</small></div>
          <div class="field"><label>رقم الترخيص أو الإجازة</label><input class="input" data-d="license" dir="ltr" value="${esc(S.d.license)}"></div>
          <div class="field"><label>هاتف الجهة</label><input class="input" data-d="phone" dir="ltr" inputmode="tel" value="${esc(S.d.phone)}" placeholder="07XXXXXXXXX"></div>
          ${k.type === 'bank' ? `<label class="check" style="align-self:end"><input type="checkbox" data-isl ${S.d.is_islamic ? 'checked' : ''}> مصرف إسلامي (يعرض منتجات معتمدة من الهيئة الشرعية)</label>` : ''}
        </div>
        ${cov ? `<div class="field"><label>المحافظات التي ${k.type === 'insurer' ? 'تؤمّن فيها' : k.type === 'courier' ? 'توصل إليها (فارغ = كل المحافظات)' : 'تكشف فيها'}</label>${govPicker(S.d.govs)}</div>` : ''}
        ${hasBr ? `<div class="card og-sub"><b>الفرع الرئيسي</b><p class="small muted" style="margin:2px 0 8px">بقية الفروع تضيفها الإدارة العليا من «فريقي».</p>
          <div class="grid g2" style="gap:12px"><div class="field"><label>اسم الفرع</label><input class="input" data-d="bname" value="${esc(S.d.bname)}"></div>
          <div class="field"><label>هاتف الشكاوى</label><input class="input" data-d="bphone" dir="ltr" inputmode="tel" value="${esc(S.d.bphone)}"></div></div>
          <div class="field"><label>محافظات الفرع ${k.type === 'bank' ? '(تُوجَّه إليه طلبات هذه المحافظات)' : ''}</label>${govPicker(S.d.bgovs)}</div></div>` : ''}
        <div class="row mt"><button class="btn ghost" data-b>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-n>التالي: حساب الإدارة العليا</button></div>`;
      wireGovs(box);
      const read = () => {
        box.querySelectorAll('[data-d]').forEach(i => { S.d[i.dataset.d] = i.value.trim(); });
        S.d.code = S.d.code.toLowerCase(); S.d.is_islamic = !!box.querySelector('[data-isl]')?.checked;
        const g = box.querySelectorAll('[data-govs]'); if (cov) S.d.govs = readGovs(g[0]); if (hasBr) S.d.bgovs = readGovs(g[cov ? 1 : 0]);
      };
      box.querySelector('[data-b]').onclick = () => { read(); S.step = 1; paint(); };
      box.querySelector('[data-n]').onclick = () => {
        read();
        if (S.d.name.length < 3) return toast('اكتب اسم الجهة كاملاً', 'bad');
        if (!/^[a-z][a-z0-9]{1,7}$/.test(S.d.code)) return toast('الرمز المختصر: حروف إنجليزية صغيرة أو أرقام، يبدأ بحرف، من 2 إلى 8', 'bad');
        if (X.orgs.some(o => o.code === S.d.code)) return toast(`الرمز «${S.d.code}» مستخدم لجهة أخرى`, 'bad');
        if (!S.m.username || S.m.username.endsWith('.') || /^[a-z0-9]+\.(md|admin|sg|pres)$/.test(S.m.username)) S.m.username = `${S.d.code}.${k.suffix}`;
        S.step = 3; paint();
      };
      return;
    }
    box.innerHTML = `${head()}<h3 style="margin:6px 0 4px">حساب ${esc(k.mgr)}</h3>
      <p class="small muted" style="margin:0 0 10px">صاحب هذا الحساب يدير الجهة كلها: يضيف الموظفين${['bank', 'insurer'].includes(k.type) ? ' والفروع ومديري الفروع' : ''} ويوقفهم ويوزّع المهام. يُطلب منه تغيير كلمة المرور عند أول دخول، ثم تسجيل بصمة وجهه (Face ID) على هاتفه — ولا يُنفَّذ أي إجراء على معاملة دون التحقق منها.</p>
      <div class="grid g2" style="gap:12px">
        <div class="field"><label>الاسم الكامل ★</label><input class="input" data-m="full_name" value="${esc(S.m.full_name)}"></div>
        <div class="field"><label>الهاتف</label><input class="input" data-m="phone" dir="ltr" inputmode="tel" value="${esc(S.m.phone)}" placeholder="07XXXXXXXXX"></div>
        <div class="field"><label>اسم الدخول ★</label><input class="input" data-m="username" dir="ltr" value="${esc(S.m.username)}"></div>
        <div class="field"><label>كلمة المرور المؤقتة ★</label><div class="row" style="gap:6px;flex-wrap:nowrap"><input class="input" data-m="password" dir="ltr" value="${esc(S.m.password)}"><button type="button" class="btn ghost sm" data-gen>توليد</button></div></div>
      </div>
      <div class="og-sum small"><b>${k.ic} ${esc(S.d.name)}</b> · <span dir="ltr" class="num">${esc(S.d.code)}</span>${S.d.is_islamic ? ' · إسلامي' : ''}${['bank', 'insurer'].includes(k.type) ? ` · ${esc(S.d.bname)}` : ''}</div>
      <div class="row mt"><button class="btn ghost" data-b>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-s>إضافة الجهة وإنشاء الحساب</button></div>`;
    const read = () => box.querySelectorAll('[data-m]').forEach(i => { S.m[i.dataset.m] = i.value.trim(); });
    box.querySelector('[data-gen]').onclick = () => { box.querySelector('[data-m=password]').value = genPw(); };
    box.querySelector('[data-b]').onclick = () => { read(); S.step = 2; paint(); };
    box.querySelector('[data-s]').onclick = async e => {
      read(); S.m.username = S.m.username.toLowerCase();
      if (S.m.full_name.length < 3) return toast('اكتب اسم المسؤول', 'bad');
      e.target.disabled = true; e.target.textContent = 'جارِ الإضافة…';
      try {
        const r = await rpc(X.sb, 'admin_onboard_org', { p: { kind: S.k, name: S.d.name, code: S.d.code, license: S.d.license, phone: S.d.phone, is_islamic: S.d.is_islamic,
          governorates: S.d.govs, branch: { name: S.d.bname, governorates: S.d.bgovs, phone: S.d.bphone }, manager: S.m } });
        m.close();
        done(r, S.m.password, k);
        await H.reload();
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; e.target.textContent = 'إضافة الجهة وإنشاء الحساب'; }
    };
  };
  paint();
}

function done(r, pw, k) {
  const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h3 style="margin:4px 0">أُضيفت «${esc(r.org.name)}»</h3>
      <p class="small muted" style="margin:0">${esc(k.t)}${r.branch?.name ? ` · ${esc(r.branch.name)} (<span class="num">${esc(r.branch.code)}</span>)` : ''}</p></div>
    <p class="small" style="margin:12px 0 6px">أرسل هذه البيانات إلى <b>${esc(r.manager)}</b> بقناة آمنة:</p>
    ${copyBox('الرابط', `${location.origin}/${r.portal}`)}${copyBox('اسم المستخدم', r.username)}${copyBox('كلمة المرور المؤقتة', pw)}
    <div class="notice small" style="margin-top:8px"><span>ℹ</span><span><b>الخطوة التالية:</b> ${esc(k.next)}</span></div>
    <p class="small muted">هذه آخر مرة تظهر فيها كلمة المرور — انسخها الآن.</p>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-x>تم</button></div>`);
  wireCopy(m.el); m.el.querySelector('[data-x]').onclick = m.close;
}

// ───────── حساب إدارة عليا إضافي ─────────
function managerForm(X, D, body, H, o) {
  const k = K(kindOf(o)), pre = (D.users.find(u => u.org_id === o.id && u.username.includes('.'))?.username.split('.')[0]) || o.code;
  const m = modal(`<h3>حساب ${esc(k.mgr)} — ${esc(o.name)}</h3><p class="small muted">حساب إضافي بصلاحية مدير الجهة (مثلاً معاون المدير، أو بديل عن حساب موقوف).</p>
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>الاسم الكامل ★</label><input class="input" data-m="full_name"></div>
      <div class="field"><label>الهاتف</label><input class="input" data-m="phone" dir="ltr" inputmode="tel" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label>اسم الدخول ★</label><input class="input" data-m="username" dir="ltr" value="${esc(pre)}.${k.suffix}2"></div>
      <div class="field"><label>كلمة المرور المؤقتة ★</label><input class="input" data-m="password" dir="ltr" value="${genPw()}"></div></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>إنشاء الحساب</button></div>`, { wide: true });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const d = {}; m.el.querySelectorAll('[data-m]').forEach(i => { d[i.dataset.m] = i.value.trim(); }); d.username = d.username.toLowerCase();
    e.target.disabled = true;
    try { const r = await rpc(X.sb, 'admin_add_org_manager', { p_org: o.id, p: d }); m.close(); H.credsCard(r.username, d.password, r.portal); await H.reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

function editForm(X, D, body, H, o) {
  const k = K(kindOf(o)), mt = o.meta || {}, cov = ['eng_audit', 'insurer', 'courier'].includes(o.type);
  const m = modal(`<h3>تعديل ${esc(o.name)}</h3>
    <div class="field"><label>الاسم الرسمي</label><input class="input" data-d="name" value="${esc(o.name)}"></div>
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>رقم الترخيص</label><input class="input" data-d="license" dir="ltr" value="${esc(mt.license || '')}"></div>
      <div class="field"><label>هاتف الجهة</label><input class="input" data-d="phone" dir="ltr" value="${esc(mt.phone || '')}"></div>
      ${o.type === 'supplier' ? `<div class="field"><label>نوع المورد</label><select class="input" data-d="kind"><option value="solar" ${mt.kind !== 'vet' ? 'selected' : ''}>منظومات الطاقة الشمسية</option><option value="vet" ${mt.kind === 'vet' ? 'selected' : ''}>أجهزة ومواد طبية بيطرية</option></select></div>` : ''}
      ${o.type === 'bank' ? `<label class="check" style="align-self:end"><input type="checkbox" data-isl ${o.is_islamic ? 'checked' : ''}> مصرف إسلامي</label>` : ''}</div>
    ${cov ? `<div class="field"><label>المحافظات المغطاة</label>${govPicker(mt.governorates || [])}</div>` : ''}
    <p class="small muted">${esc(k.t)} · الرمز <span dir="ltr" class="num">${esc(o.code)}</span> (لا يتغير). شعار الجهة يُرفع من «الإعدادات ← شعارات الجهات».</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>حفظ</button></div>`, { wide: true });
  wireGovs(m.el);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const p = {}; m.el.querySelectorAll('[data-d]').forEach(i => { p[i.dataset.d] = i.value.trim(); });
    if (o.type === 'bank') p.is_islamic = m.el.querySelector('[data-isl]').checked;
    if (cov) p.governorates = readGovs(m.el.querySelector('[data-govs]'));
    e.target.disabled = true;
    try { await rpc(X.sb, 'admin_org_update', { p_org: o.id, p }); m.close(); toast('حُفظت بيانات الجهة', 'ok'); await H.reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

function suspendForm(X, D, body, H, o) {
  const on = !o.meta?.suspended, n = D.users.filter(u => u.org_id === o.id && !u.disabled).length;
  const m = modal(`<h3>${on ? 'إيقاف' : 'إعادة تفعيل'} ${esc(o.name)}</h3>
    <p class="muted">${on ? `تُوقف حسابات الجهة كلها (<b class="num">${n}</b> حساب) فوراً وتُغلق جلساتها${o.type === 'bank' ? '، ويتوقف المصرف عن استقبال الطلبات' : o.type === 'supplier' ? '، وتُسحب عروضه المنشورة من الكتالوج' : ''}. الطلبات والسجلات السابقة تبقى كما هي.`
      : 'تعود الحسابات التي أوقفها إيقاف الجهة فقط. الحساب الذي أُوقف لسبب آخر يبقى موقوفاً.'}</p>
    ${on ? '<div class="field"><label>السبب (يُحفظ في السجل الإداري) ★</label><input class="input" data-r placeholder="انتهاء الترخيص، طلب البنك المركزي…"></div>' : ''}
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn ${on ? 'bad' : 'ok'}" data-s>${on ? 'إيقاف الجهة' : 'إعادة التفعيل'}</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    e.target.disabled = true;
    try { const r = await rpc(X.sb, 'admin_org_suspend', { p_org: o.id, p_on: on, p_reason: m.el.querySelector('[data-r]')?.value.trim() || null });
      m.close(); toast(on ? `أُوقفت الجهة و${r.accounts} حساب` : `أُعيد تفعيل الجهة و${r.accounts} حساب`, 'ok'); await H.reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}
