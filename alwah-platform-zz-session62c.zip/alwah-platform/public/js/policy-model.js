// الجلسة 62: النموذج الداخلي لقراءة السياسة الائتمانية للمصرف
// يقرأ نص السياسة بالعربية جملةً جملة ويستخرج منه شروطاً منظّمة: { field, op, value, text }
// يعمل داخل المنصة بالكامل — نص السياسة وبيانات المقترض لا تخرج إلى أي خدمة خارجية.
// الشروط الناتجة تراجعها الإدارة العليا وتجرّبها ثم تعتمدها، والفحص النهائي في قاعدة البيانات (_policy_eval).

export const FIELDS = {
  age: { label: 'العمر', kind: 'num', unit: 'سنة' },
  age_end: { label: 'العمر عند آخر قسط', kind: 'num', unit: 'سنة' },
  salary: { label: 'الدخل الشهري', kind: 'num', unit: 'د.ع' },
  dti: { label: 'نسبة القسط من الدخل', kind: 'num', unit: '%' },
  installment: { label: 'القسط الشهري', kind: 'num', unit: 'د.ع' },
  amount: { label: 'مبلغ التمويل', kind: 'num', unit: 'د.ع' },
  term: { label: 'مدة السداد', kind: 'num', unit: 'شهراً' },
  employment: { label: 'نوع العمل', kind: 'set' },
  governorate: { label: 'المحافظة', kind: 'set' },
  sector: { label: 'نوع المشروع', kind: 'set' },
  guarantee: { label: 'الضمان', kind: 'set' },
};
export const OPS = { gte: 'لا يقل عن', lte: 'لا يزيد على', in: 'تقبل فقط', not_in: 'لا تقبل' };
export const GOV_LIST = ['بغداد', 'البصرة', 'نينوى', 'أربيل', 'النجف', 'كربلاء', 'بابل', 'ذي قار', 'الأنبار', 'ديالى', 'واسط', 'ميسان', 'الديوانية', 'صلاح الدين', 'كركوك', 'المثنى', 'السليمانية', 'دهوك'];
export const SET_VALUES = {
  employment: [['gov', 'موظف حكومي'], ['private', 'قطاع خاص'], ['self', 'عمل حر']],
  guarantee: [['single_salary', 'كفيل موظف واحد'], ['multi_salary', 'كفيلان موظفان أو أكثر'], ['mortgage', 'رهن عقار'], ['gold', 'رهن ذهب']],
  sector: [['residential', 'منظومة سكنية'], ['agricultural', 'منظومة لمشروع زراعي'], ['industrial', 'منظومة لمشروع صناعي'], ['project', 'منظومة لمشروع تجاري أو خدمي'],
    ['vet', 'منظومة لمشروع بيطري'], ['export', 'منظومة لمشروع تصدير'], ['other', 'منظومة لمشروع آخر'], ['vet_program', 'مبادرة الأطباء البيطريين'],
    ['export_program', 'قروض المصدّرين'], ['commercial_program', 'القروض التجارية'], ['ecommerce_program', 'التجارة الإلكترونية'], ['industrial_program', 'القروض الصناعية']],
  governorate: GOV_LIST.map(g => [g, g]),
};
export const valLabel = (f, v) => (SET_VALUES[f] || []).find(x => x[0] === v)?.[1] || v;
export function fmtVal(f, v) {
  const d = FIELDS[f];
  if (!d) return String(v);
  if (d.kind === 'set') return (Array.isArray(v) ? v : [v]).map(x => valLabel(f, x)).join('، ');
  const n = Number(v);
  return d.unit === '%' ? `${n}%` : `${n.toLocaleString('en-US')} ${d.unit}`;
}
// الجلسة 62b: نطاق الشرط — يُطبَّق على أنواع طلبات محددة فقط
export const SCOPES = [['', 'كل الطلبات', []], ['solar', 'المنظومات الشمسية فقط', ['residential', 'agricultural', 'industrial', 'project', 'vet', 'export', 'other']],
  ['programs', 'برامج المصارف فقط', ['export_program', 'commercial_program', 'ecommerce_program', 'industrial_program']], ['vetp', 'مبادرة الأطباء البيطريين فقط', ['vet_program']]];
export const scopeOf = r => { const s = (r.sectors || []).slice().sort().join(','); return s ? (SCOPES.find(x => x[2].slice().sort().join(',') === s)?.[0] ?? 'custom') : ''; };
export const scopeText = r => !(r.sectors || []).length ? '' : (SCOPES.find(x => x[0] === scopeOf(r))?.[1] || ('على: ' + r.sectors.map(v => valLabel('sector', v)).join('، ')));
export const ruleText = r => `${FIELDS[r.field]?.label || r.field} ${OPS[r.op] || r.op} ${fmtVal(r.field, r.value)}${scopeText(r) ? ` (${scopeText(r)})` : ''}`;

// ── التطبيع: أرقام هندية، همزات، تطويل ──
const AR_DIG = '٠١٢٣٤٥٦٧٨٩', FA_DIG = '۰۱۲۳۴۵۶۷۸۹';
export function norm(s) {
  return String(s || '')
    .replace(/[٠-٩]/g, d => AR_DIG.indexOf(d)).replace(/[۰-۹]/g, d => FA_DIG.indexOf(d))
    .replace(/٫/g, '.').replace(/٬/g, ',').replace(/ـ/g, '')
    .replace(/[ً-ْ]/g, '')               // التشكيل
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/[٪]/g, '%').replace(/\s+/g, ' ').trim();
}

// تقسيم النص إلى جمل: سطر جديد، نقطة ليست بين رقمين، فاصلة منقوطة. ترقيم البنود يُحذف.
export function sentences(text) {
  return String(text || '').replace(/\r/g, '')
    .split(/\n|؛|;|(?<!\d)\.(?!\d)|\.(?=\s)/)
    .map(s => s.replace(/^\s*(?:[-–•*]|\(?[0-9٠-٩]{1,2}[).\-–]|[أاب-ي][).\-–](?=\s))\s*/, '').trim())
    .filter(s => s.replace(/[^\p{L}\p{N}]/gu, '').length >= 4);
}

// ── الأرقام: «مليون»، «750 ألف»، «1.5 مليون»، «مليونين»، «نصف مليون» ──
const MULT = [[/^(مليار)/, 1e9], [/^(مليون|ملايين)/, 1e6], [/^(الف|الاف|آلاف)/, 1e3]];
export function numbers(s) {
  const out = [];
  const t = norm(s);
  const re = /(\d+(?:[.,]\d+)*)\s*(%|بالمي?ه|بالمائه|بالمئه|في المي?ه|في المائه|في المئه)?\s*(مليار|مليون|ملايين|الف|الاف)?\s*(سنه|سنوات|سنين|عام|اعوام|شهر|شهرا|اشهر|شهور)?/g;
  let m;
  while ((m = re.exec(t))) {
    const raw = m[1];
    let v = /,\d{3}(?!\d)/.test(raw) ? Number(raw.replace(/,/g, '')) : Number(raw.replace(',', '.'));
    if (!isFinite(v)) continue;
    const mu = m[3] ? MULT.find(([r]) => r.test(m[3]))?.[1] || 1 : 1;
    v *= mu;
    out.push({ v, pct: !!m[2], money: !!m[3] || v >= 10000, unit: m[4] ? (/شه|اشهر/.test(m[4]) ? 'month' : 'year') : null, at: m.index });
  }
  // كلمات بلا أرقام
  const words = [[/نصف مليون/, 5e5], [/ربع مليون/, 25e4], [/مليونين|مليونان/, 2e6], [/(?<![\d\s]\s?)\bمليون ونصف|مليون و نصف/, 15e5], [/(?:^|\s)مليون(?:\s|$|\s*دينار)/, 1e6]];
  for (const [r, v] of words) {
    const w = r.exec(t);
    if (w && !out.some(o => Math.abs(o.at - w.index) < 6)) { out.push({ v, pct: false, money: true, unit: null, at: w.index }); break; }
  }
  return out.sort((a, b) => a.at - b.at);
}

// ── المقارنة ──
const RX_MAX = /(لا يتجاوز|لا تتجاوز|لا يزيد|لا تزيد|ان لا يزيد|الا يزيد|الا تزيد|الا يتجاوز|الا تتجاوز|اقصي|اقصى|الحد الاعلي|الحد الاعلى|حد اعلي|سقف|اقل من|فاقل|فما دون|كحد اعلي|لغايه|حتي|لا يتعدي|لا يتعدى)/;
const RX_MIN = /(لا يقل|لا تقل|الا يقل|الا تقل|ادني|ادنى|الحد الادني|الحد الادنى|علي الاقل|على الاقل|اكثر من|يزيد عن|فاكثر|فما فوق|فما اكثر|كحد ادني|لا ينقص)/;
const RX_RANGE = /(بين|من)\s*(\d[\d.,]*)\s*(?:سنه|سنوات|مليون|الف|شهرا|شهر)?\s*(?:و|الي|إلى|الى|-|–)\s*(\d[\d.,]*)/;
const RX_NEG = /(لا يقبل|لا تقبل|لا نقبل|يستثني|يستثنى|مستثني|مستثنى|غير مقبول|غير مشمول|لا يمول|لا تمول|لا نمول|يمنع|ممنوع|عدا|باستثناء|ما عدا|لا يمنح|لا تمنح|لا يشمل|لا تشمل|يرفض|ترفض|محظور)/;

// ── الحقول ──
const FIELD_RX = [
  ['age_end', /(عمر|سن|سنه|عاما).{0,40}(عند (انتهاء|نهايه|اخر|استحقاق|اكتمال|تمام|سداد)|بنهايه|في نهايه|اخر قسط|اخر دفعه)|(عند|بنهايه|نهايه|انتهاء).{0,25}(التمويل|القرض|السداد).{0,30}(عمر|سن)/],
  ['age', /(عمر|سن المقترض|سن المتقدم|السن\b|من العمر|(?<!م)بلغ|يبلغ)/],
  ['dti', /(نسبه|%|بالمي|بالمائه|بالمئه|في المي|في المائه|في المئه).{0,60}(الراتب|الدخل|راتب|دخل)|(القسط|الاستقطاع|الالتزامات|الاقساط).{0,40}(%|نسبه|بالمي|بالمائه|بالمئه|في المي|في المائه|في المئه)/],
  ['installment', /(القسط|قسط)/],
  ['salary', /(الراتب|راتب|الدخل|دخل)/],
  ['term', /(مده|فتره)\s*(السداد|التمويل|القرض|الاسترداد|التسديد)|(اجل|مدة القرض|عدد الاقساط)/],
  ['amount', /(مبلغ|تمويل|قرض|السلفه|سلفه)/],
];

const EMP = [['gov', /(حكومي|حكوميه|القطاع العام|موظفي الدوله|موظف الدوله|الدوائر الرسميه|دوائر الدوله|المتقاعد|متقاعد|موظفين الحكومه|الموظفين|موظفي|الموظف)/],
  ['private', /(القطاع الخاص|قطاع خاص|الشركات الخاصه|شركه خاصه|الخاص)/], ['self', /(العمل الحر|عمل حر|الاعمال الحره|اعمال حره|الكسبه|اصحاب المهن|مهن حره|الحرفيين|اصحاب العمل|التجار)/]];
const GUA = [['single_salary', /(كفيل واحد|كفيل موظف|كفاله موظف|كفاله شخصيه|كفيل)/], ['multi_salary', /(كفيلين|كفيلان|اكثر من كفيل|كفلاء)/], ['mortgage', /(رهن عقار|عقار|رهن عقاري)/], ['gold', /(ذهب|رهن الذهب|مصوغات)/]];
const SEC = [['residential', /(سكني|سكنيه|منزلي|منزليه|المنازل|البيوت|منظومه سكنيه)/], ['agricultural', /(زراعي|زراعيه|الزراعه|المزارع)/], ['industrial', /(صناعي|صناعيه|المعامل|المصانع)/],
  ['project', /(تجاري|تجاريه|خدمي|خدميه|المحلات)/], ['vet', /(بيطري|بيطريه)/], ['export', /(تصدير|المصدرين)/], ['ecommerce_program', /(التجاره الالكترونيه|تجاره الكترونيه)/]];
const KURDISTAN = /(اقليم كردستان|الاقليم|محافظات الاقليم)/;

const setVals = (t, list) => list.filter(([, r]) => r.test(t)).map(([k]) => k);

function govs(t) {
  const out = GOV_LIST.filter(g => t.includes(norm(g)) || t.includes(norm(g).replace(/^ال/, '')));
  if (KURDISTAN.test(t)) out.push('أربيل', 'السليمانية', 'دهوك');
  if (/(جميع المحافظات|كل المحافظات|كافه المحافظات)/.test(t) && !out.length) return null;
  return [...new Set(out)];
}

// قراءة جملة واحدة → شروط
export function parseSentence(src) {
  const t = norm(src), rules = [];
  const add = (field, op, value) => rules.push({ field, op, value, text: src.trim() });
  const neg = RX_NEG.test(t);

  // 1) الحقول ذات القيم (قوائم)
  const gv = govs(t);
  if (gv && gv.length && (KURDISTAN.test(t) || /(محافظ|المحافظات|سكن|اقامه|يقيم|مقيم|ضمن|داخل|في)/.test(t)) && !/(عمر|راتب|دخل|قسط)/.test(t)) {
    add('governorate', neg ? 'not_in' : 'in', gv); return rules;
  }
  if (/(ضمان|ضمانات|كفيل|كفاله|كفلاء|رهن)/.test(t) && !/(عمر|راتب|دخل|%)/.test(t)) {
    const parts = t.split(/(?=و?\s*(?:لا يقبل|لا تقبل|لا نقبل|باستثناء|عدا|ما عدا|يمنع))/);
    let inc = [], exc = [];
    for (const p of parts) { let v = setVals(p, GUA); if (v.includes('multi_salary')) v = v.filter(x => x !== 'single_salary'); (RX_NEG.test(p) ? exc : inc).push(...v); }
    inc = [...new Set(inc)].filter(x => !exc.includes(x)); exc = [...new Set(exc)];
    if (inc.length) add('guarantee', 'in', inc); else if (exc.length) add('guarantee', 'not_in', exc);
    if (rules.length) return rules;
  }
  if (/(موظف|عمل|العاملين|القطاع|متقاعد|كسبه|المهن|تجار)/.test(t) && !/(عمر|سن\b|%|نسبه)/.test(t)) {
    // جملة مثل: «للموظفين في القطاع الحكومي والخاص فقط، ولا يُقبل أصحاب العمل الحر»
    const parts = t.split(/(?:،|,)?\s*(?=و?\s*(?:لا يقبل|لا تقبل|لا نقبل|يستثني|يستثنى|باستثناء|عدا|ما عدا|لا يمنح|لا يشمل|يمنع))/);
    let inc = [], exc = [];
    for (const p of parts) { const v = setVals(p, EMP); (RX_NEG.test(p) ? exc : inc).push(...v); }
    // «الحكومي والخاص» تأتي بعد كلمة القطاع
    if (/القطاع(ين)? (الحكومي|العام) و ?الخاص|القطاعين العام والخاص|القطاعين الحكومي والخاص/.test(t)) inc.push('gov', 'private');
    inc = [...new Set(inc)].filter(x => !exc.includes(x)); exc = [...new Set(exc)];
    if (inc.length && !/(جميع|كافه|كل)/.test(t)) add('employment', 'in', inc);
    else if (exc.length) add('employment', 'not_in', exc);
    if (rules.length) return rules;
  }
  const sv = setVals(t, SEC);
  if (sv.length && /(مشروع|مشاريع|منظوم|قطاع|تمويل|يمول|نمول|تمول|الغرض|لاغراض|الاغراض)/.test(t) && !/(عمر|راتب|دخل|%|مليون)/.test(t)) {
    const all = sv.flatMap(k => k === 'export' ? ['export', 'export_program'] : k === 'project' ? ['project', 'commercial_program'] : k === 'industrial' ? ['industrial', 'industrial_program'] : k === 'vet' ? ['vet', 'vet_program'] : [k]);
    add('sector', neg ? 'not_in' : 'in', [...new Set(all)]); return rules;
  }

  // 2) الحقول الرقمية
  const nums = numbers(src);
  if (!nums.length) return rules;
  let field = null;
  for (const [f, r] of FIELD_RX) if (r.test(t)) { field = f; break; }
  if (!field) {
    if (nums.some(n => n.pct)) field = 'dti';
    else if (nums.some(n => n.unit === 'year') && nums.every(n => n.v < 120)) field = 'age';
    else if (nums.some(n => n.unit === 'month')) field = 'term';
    else return rules;
  }
  // «مدة السداد 7 سنوات» → أشهر
  const sUnit = nums.find(n => n.unit)?.unit;
  const conv = n => { if (field !== 'term') return n.v; const u = n.unit || sUnit || (n.v <= 15 ? 'year' : 'month'); return u === 'year' ? n.v * 12 : n.v; };
  let pool = nums;
  if (field === 'dti') pool = nums.filter(n => n.pct).length ? nums.filter(n => n.pct) : nums.filter(n => n.v <= 100);
  if (field === 'age' || field === 'age_end') pool = nums.filter(n => n.v >= 15 && n.v <= 100);
  if (field === 'salary' || field === 'amount' || field === 'installment') pool = nums.filter(n => n.money || n.v >= 1000);
  if (!pool.length) return rules;

  const rg = RX_RANGE.exec(t);
  if (rg && pool.length >= 2) {
    const a = conv(pool[0]), b = conv(pool[1]);
    add(field, 'gte', Math.min(a, b)); add(field, 'lte', Math.max(a, b)); return rules;
  }
  // جملة فيها حدّان: «لا يقل عن 21 ولا يزيد على 60»
  const iMin = t.search(RX_MIN), iMax = t.search(RX_MAX);
  if (pool.length >= 2 && iMin >= 0 && iMax >= 0) {
    const after = i => pool.find(n => n.at > i);
    const lo = after(iMin) || pool[0], hi = pool.find(n => n.at > iMax && n !== lo) || pool.find(n => n !== lo);
    add(field, 'gte', conv(lo)); add(field, 'lte', conv(hi)); return rules;
  }
  const v = conv(pool[0]);
  if (iMax >= 0) add(field, 'lte', v);
  else if (iMin >= 0) add(field, 'gte', v);
  else if (field === 'dti' || field === 'installment' || field === 'amount' || field === 'term' || field === 'age_end') add(field, 'lte', v);   // الافتراض الأقرب لصياغة البنوك
  else if (field === 'salary') add(field, 'gte', v);
  else return rules;
  return rules;
}

// قراءة السياسة كاملة
export function parsePolicy(text) {
  const rules = [], unparsed = [], seen = new Set();
  for (const s of sentences(text)) {
    // جملة فيها شرطان مفصولان بفاصلة: «عمره بين 21 و65 سنة، وألا يتجاوز 70 سنة عند آخر قسط»
    const parts = s.split(/،|,(?!\d{3})/).map(x => x.trim()).filter(Boolean);
    let rs = [];
    if (parts.length > 1 && parts.filter(x => numbers(x).length).length > 1) {
      let ctx = '';
      for (const p of parts) { const r = parseSentence(/(عمر|سن|راتب|دخل|قسط|مبلغ|مده)/.test(norm(p)) ? p : (ctx + ' ' + p)); if (r.length) { r.forEach(x => x.text = s); rs.push(...r); } ctx = (norm(p).match(/(عمر|سن|راتب|دخل|قسط|مبلغ|مده)/) || [''])[0]; }
    }
    if (!rs.length) rs = parseSentence(s);
    // الجلسة 62b: نطاق الشرط من الجملة — «في تمويل المنظومات الشمسية»، «لمبادرة البيطريين»، «لبرامج المصرف»
    const ns = norm(s), sc = /(المنظومات الشمسيه|الطاقه الشمسيه|منظومات الطاقه)/.test(ns) ? 'solar' : /(مبادره (الاطباء )?البيطريين)/.test(ns) ? 'vetp' : /(برامج المصرف|البرامج التجاريه|برامج القروض)/.test(ns) ? 'programs' : '';
    if (sc) rs.filter(r => r.field !== 'sector').forEach(r => { r.sectors = SCOPES.find(x => x[0] === sc)[2].slice(); });
    if (!rs.length) { unparsed.push(s); continue; }
    for (const r of rs) {
      const k = `${r.field}|${r.op}|${JSON.stringify(r.value)}`;
      if (seen.has(k)) continue;
      seen.add(k); rules.push(r);
    }
  }
  // تعارض واضح: حدّ أدنى أكبر من الأعلى للحقل نفسه
  const warnings = [];
  for (const f of Object.keys(FIELDS)) {
    const lo = rules.filter(r => r.field === f && r.op === 'gte').map(r => r.value), hi = rules.filter(r => r.field === f && r.op === 'lte').map(r => r.value);
    if (lo.length && hi.length && Math.max(...lo) > Math.min(...hi)) warnings.push(`${FIELDS[f].label}: الحد الأدنى أكبر من الحد الأعلى — راجع الجملتين`);
  }
  return { rules, unparsed, warnings };
}
