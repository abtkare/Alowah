// الجلسة 40: التأمين — مكوّنات مشتركة، وقسم «التأمين على المشروع» في ملف الطلب لكل الجهات
import { esc, dt, badge, rpc, toast, cleanErr, modal, iqd, resultScreen } from './core.js';

export const POL_ST = { new: ['طلب وارد', 'info'], survey: ['قيد المعاينة', 'warn'], pricing: ['قيد التسعير', 'warn'], approval: ['بانتظار الاعتماد', 'warn'],
  payment: ['بانتظار القسط', 'warn'], active: ['وثيقة سارية', 'ok'], declined: ['اعتذرت الشركة', 'bad'], cancelled: ['ملغاة', 'muted'], expired: ['منتهية', 'muted'] };
export const CLM_ST = { reported: ['إبلاغ جديد', 'info'], survey: ['معاينة الضرر', 'warn'], assessment: ['قيد التقدير', 'warn'], approval: ['بانتظار الاعتماد', 'warn'],
  payment: ['بانتظار الصرف', 'warn'], paid: ['صُرف التعويض', 'ok'], rejected: ['مرفوضة', 'bad'] };
export const CAUSES = [['fire', 'حريق أو صاعقة', '🔥'], ['electrical', 'عطل كهربائي أو تماس', '⚡'], ['nature', 'عاصفة أو أمطار أو بَرَد', '🌪'],
  ['theft', 'سرقة أو سطو', '🔓'], ['accident', 'كسر أو ضرر عرضي', '💥'], ['liability', 'ضرر للغير', '👥'], ['other', 'أخرى', '…']];
export const RISK = { low: ['منخفض', 'ok'], medium: ['متوسط', 'warn'], high: ['عالٍ', 'bad'] };
export const POL_STEPS = [['new', 'الاكتتاب'], ['survey', 'المعاينة'], ['pricing', 'التسعير'], ['approval', 'الاعتماد'], ['payment', 'القسط'], ['active', 'سارية']];

export const polBadge = s => badge(POL_ST[s] || [s, 'muted']);
export const clmBadge = s => badge(CLM_ST[s] || [s, 'muted']);
const today = () => new Date().toISOString().slice(0, 10);

export async function insPhoto(sb, id) {
  try {
    const r = await rpc(sb, 'ins_photo', { p_doc: id });
    const m = modal(`<h3>${esc(r.label || 'صورة المعاينة')}</h3><img src="${esc(r.data)}" alt="" style="width:100%;border-radius:12px"><p class="small muted">${esc(r.by || '')} · ${dt(r.at)}</p>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-x>إغلاق</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

// نموذج الإبلاغ عن ضرر (المصرف، المقترض، موظف المطالبات)
export function claimForm(ctx, app, onDone) {
  let cause = '';
  const m = modal(`<h3>🛡️ الإبلاغ عن ضرر على المشروع</h3><p class="small muted" style="margin-top:0">يصل البلاغ فوراً لقسم المطالبات في شركة التأمين، فيرسل معايناً إلى الموقع.</p>
    <label class="lbl">ما الذي حدث؟</label><div class="ins-causes">${CAUSES.map(([k, t, ic]) => `<button type="button" class="ins-cause" data-c="${k}"><i>${ic}</i>${esc(t)}</button>`).join('')}</div>
    <div class="grid g2" style="gap:12px"><div class="field"><label>تاريخ الحادث</label><input class="input" type="date" data-d max="${today()}" value="${today()}"></div>
      <div class="field"><label>الكلفة التقديرية (اختياري)</label><input class="input" data-a inputmode="numeric" dir="ltr" placeholder="بالدينار"></div></div>
    <div class="field"><label>صف ما حدث بجملة واضحة</label><textarea class="input" rows="3" data-t placeholder="مثال: كسرت العاصفة لوحين وتوقف العاكس عن العمل"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>إرسال البلاغ</button></div>`);
  m.el.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { cause = b.dataset.c; m.el.querySelectorAll('[data-c]').forEach(x => x.classList.toggle('on', x === b)); });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    if (!cause) return toast('اختر ما الذي حدث', 'bad');
    e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'ins_claim_report', { p_app: app.id, p: { cause, incident_date: m.el.querySelector('[data-d]').value, description: m.el.querySelector('[data-t]').value.trim(), claimed: m.el.querySelector('[data-a]').value } });
      m.close();
      await resultScreen({ ok: true, title: 'وصل البلاغ لشركة التأمين', ref: r.code, msg: `«${r.company}» ستُرسل معايناً للموقع، ويصلك إشعار بكل خطوة حتى صرف التعويض.` });
      onDone && onDone(r);
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── قسم التأمين في ملف الطلب ─────────
export async function mountInsReport(ctx, app, box) {
  const { sb } = ctx;
  let R;
  try { R = await rpc(sb, 'ins_app_report', { p_app: app.id }); } catch { return; }   // قبل تطبيق تحديث الجلسة 40
  if (!R) return;
  const pols = R.policies || [], clms = R.claims || [];
  if (!pols.length && !R.can_request) return;
  const cur = pols[0];
  box.innerHTML = `<div class="card mb ins-rep"><h3>🛡️ التأمين على المشروع <span class="sp"></span>${cur ? polBadge(cur.status) : badge(['غير مؤمَّن', 'muted'])}</h3>
    ${pols.map((p, i) => polBlock(p, i === 0)).join('') || `<p class="small muted" style="margin:0">لم يُطلب تأمين على هذا المشروع بعد${R.required ? ' — وثيقة التأمين السارية شرط لصرف المبلغ للمورد' : ''}.</p>`}
    ${clms.length ? `<div class="ins-clms"><b class="small">المطالبات</b>${clms.map(c => `<div class="ins-crow"><div><b class="num">${esc(c.code)}</b> · ${esc(c.cause_label)} <div class="small muted">${esc(c.incident_date)} · أبلغ ${esc(c.reported_side || '')}${c.decision_note && c.status === 'rejected' ? ` · السبب: ${esc(c.decision_note)}` : ''}</div></div><span class="sp"></span>
      <div style="text-align:left">${clmBadge(c.status)}${c.payable != null ? `<div class="small">${iqd(c.payable)}</div>` : ''}</div></div>`).join('')}</div>` : ''}
    <div class="row mt" style="gap:8px;flex-wrap:wrap">${R.can_request ? `<button class="btn cyan sm" data-req>🛡️ ${pols.some(p => p.status === 'declined') ? 'طلب التأمين من شركة أخرى' : 'طلب التأمين على المشروع'}</button>` : ''}
      ${R.can_claim ? '<button class="btn warn sm" data-claim>⚠ الإبلاغ عن ضرر</button>' : ''}</div></div>`;
  box.querySelectorAll('[data-ph]').forEach(b => b.onclick = () => insPhoto(sb, b.dataset.ph));
  box.querySelectorAll('[data-more]').forEach(b => b.onclick = () => b.closest('.ins-p').classList.toggle('open'));
  const rq = box.querySelector('[data-req]');
  if (rq) rq.onclick = () => requestForm(ctx, app, R, () => mountInsReport(ctx, app, box));
  const cl = box.querySelector('[data-claim]');
  if (cl) cl.onclick = () => claimForm(ctx, app, () => mountInsReport(ctx, app, box));
}

function polBlock(p, open) {
  return `<div class="ins-p ${open ? 'open' : ''}"><button type="button" class="ins-ph" data-more><span><b class="num">${esc(p.policy_no || p.code)}</b> · ${esc(p.company)}</span><span class="sp"></span>${open ? '' : polBadge(p.status)}<i class="chev">⌄</i></button>
    <div class="ins-pb"><dl class="kv sm">
      <dt>الفرع</dt><dd>${esc(p.branch || '—')}</dd>
      ${p.sum_insured ? `<dt>مبلغ التأمين</dt><dd>${iqd(p.sum_insured)}</dd>` : ''}
      ${p.premium ? `<dt>القسط السنوي</dt><dd>${iqd(p.premium)}${p.deductible_pct != null ? ` · التحمّل <span class="num">${p.deductible_pct}%</span>` : ''}</dd>` : ''}
      ${p.start ? `<dt>المدة</dt><dd><span class="num">${esc(p.start)}</span> ← <span class="num">${esc(p.end)}</span></dd>` : ''}
      <dt>المستفيد الأول</dt><dd>${esc(p.beneficiary || 'المصرف')}</dd>
      ${(p.coverages || []).length ? `<dt>الأخطار المغطاة</dt><dd>${p.coverages.map(c => `<span class="tag">${esc(c)}</span>`).join(' ')}</dd>` : ''}
      ${p.survey ? `<dt>المعاينة</dt><dd>الخطر ${badge(RISK[p.survey.risk] || ['—', 'muted'])} · ${esc(p.survey.by || '')}${p.survey.photo ? ` · <button type="button" class="linkbtn" data-ph="${p.survey.photo}">📷 الصورة</button>` : ''}</dd>` : ''}
      ${p.close_reason ? `<dt>${p.status === 'declined' ? 'سبب الاعتذار' : 'سبب الإلغاء'}</dt><dd class="bad-t">${esc(p.close_reason)}</dd>` : ''}
      ${p.seal ? `<dt>البصمة</dt><dd class="num small" dir="ltr" style="word-break:break-all">${esc(p.seal)}</dd>` : ''}
      <dt>الطلب</dt><dd><span class="num">${esc(p.code)}</span> · ${p.origin === 'auto' ? 'آلي عند أمر الشراء' : p.origin === 'renewal' ? 'تجديد' : 'بطلب المصرف'} · ${dt(p.created_at)}</dd></dl></div></div>`;
}

function requestForm(ctx, app, R, onDone) {
  const ins = R.insurers || [];
  if (!ins.length) return toast('لا توجد شركة تأمين معتمدة في المنصة بعد', 'bad');
  const declined = (R.policies || []).filter(p => p.status === 'declined').map(p => p.company);
  const m = modal(`<h3>🛡️ طلب التأمين على المشروع</h3><p class="small muted" style="margin-top:0">يصل الطلب لفرع الشركة الذي يغطي محافظة المشروع (${esc(app.governorate || '')})، فيدرسه الاكتتاب ويرسل معايناً إن لزم.</p>
    <div class="field"><label>شركة التأمين</label><select class="input" data-o><option value="">تلقائي — الشركة الأقل انشغالاً التي تغطي المحافظة</option>
      ${ins.map(o => `<option value="${o.id}" ${!o.covers ? 'disabled' : ''}>${esc(o.name)}${!o.covers ? ' — لا تغطي المحافظة' : declined.includes(o.name) ? ' — اعتذرت سابقاً' : ''}</option>`).join('')}</select></div>
    <div class="field"><label>ملاحظة للشركة (اختياري)</label><input class="input" data-n placeholder="مثال: التأمين مطلوب قبل التنفيذ"></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>إرسال الطلب</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'ins_request', { p_app: app.id, p_org: m.el.querySelector('[data-o]').value || null, p_note: m.el.querySelector('[data-n]').value.trim() || null });
      m.close();
      await resultScreen({ ok: true, title: 'أُرسل طلب التأمين', ref: r.code, msg: `وصل «${r.company}» — ${r.branch}. يصلك إشعار حين تُعتمد الوثيقة ويُحدد القسط.` });
      onDone && onDone();
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}
