// الجلسة 56: «بوابة التجار» (/merchant) — للتجار وأصحاب المحال والشركات التجارية، مرتبطة باتحاد الغرف التجارية العراقية وغرفة تجارة المحافظة
// التاجر يسجّل الدخول بحسابه الشخصي (رقم الهاتف والبطاقة الوطنية)، ويرى فيها فقط: هويته التجارية، طلب الانتساب،
// التجديد، تحديث البيانات، كتب تأييد العضوية، البدل، معاملاته وكتبه لدى الاتحاد. القرض التجاري يبقى في «بوابة المقترض».
import { esc, rpc, toast, cleanErr, num } from '../core.js';
import { pageChamber } from '../chamber-citizen.js';

let C, seq = 0;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg') && !/^#chamber\/(apply|renew|update|cert|replace|cancel)/.test(location.hash);
const route = () => { const [r, id] = location.hash.slice(1).split('/'); return { r: r || 'chamber', id }; };
const ic = d => `<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;

export async function render(ctx) {
  C = ctx; C.merchant = true;
  if (!ctx.inInit) { ctx.inInit = true; window.addEventListener('hashchange', () => { window.scrollTo(0, 0); go(); }); }
  await go();
}

async function go() {
  const { r, id } = route(), { root } = C;
  if (!root.querySelector('.cz-shell')) {
    root.innerHTML = `<div class="cz-shell in-shell"><nav class="cz-nav" aria-label="أقسام بوابة التجار">
      <a href="#chamber" data-n="chamber">${ic('<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14.5 10h4M14.5 13.5h3"/>')}<span>هويتي</span></a>
      <a href="#services" data-n="services">${ic('<path d="M3 21h18M5 21V10l5 3V10l5 3V6l4 2v13"/>')}<span>خدماتي</span></a>
      <a href="#profile" data-n="profile">${ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>')}<span>حسابي</span></a></nav><div id="cz"></div></div>`;
    root.querySelectorAll('.cz-nav a').forEach(a => a.addEventListener('click', e => { if (a.getAttribute('href') === (location.hash || '#chamber')) { e.preventDefault(); go(); } }));
  }
  root.querySelector('.cz-shell').classList.toggle('cz-focus', r === 'chamber' && id === 'apply');
  const nk = r === 'chamber' && id && id !== 'docs' ? 'services' : r;
  root.querySelectorAll('.cz-nav a').forEach(a => { const on = a.dataset.n === nk; a.classList.toggle('on', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
  const n = ++seq, host = root.querySelector('#cz');
  const body = document.createElement('div'); body.className = 'cz-pg';
  body.innerHTML = '<div class="cz-load" role="status"><div class="spin"></div><span>جارِ التحميل…</span></div>';
  host.replaceChildren(body);
  try {
    if (r === 'profile') await pageProfile(body);
    else if (r === 'services') await pageServices(body);
    else await pageChamber(body, C);
  } catch (e) { console.error(e); if (n === seq) body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}

// خدماتي: كل الخدمات في شاشة واحدة
async function pageServices(body) {
  const U = await rpc(C.sb, 'chamber_my');
  const cur = (U.members || []).find(m => m.code), q = cur?.quote || {};
  const T = cur ? [
    ['renew', '🔄', 'تجديد الهوية', q.allowed ? (cur.status === 'expired' ? 'منتهية — جدّدها الآن' : 'متاح الآن') : q.early ? `يُفتح ${esc(q.opens_at || '')}` : q.pending ? 'طلبك قيد الدراسة' : 'غير متاح الآن'],
    ['cert', '📄', 'كتاب تأييد عضوية', cur.valid ? `فوري لأي جهة — ${num(U.fees?.cert)} د.ع` : 'يحتاج هوية نافذة'],
    ['update', '✏️', 'تحديث بيانات المحل', cur.open_update ? 'طلبك قيد الدراسة' : 'العنوان، البضائع، العاملون…'],
    ['docs', '🗂', 'مستمسكاتي', `${(cur.docs || []).length} مستند محفوظ`],
    ['replace', '🪪', 'بدل ضائع أو تالف', `${num(U.fees?.replace)} د.ع`],
    ...(!cur.open_cancel && cur.status !== 'suspended' ? [['cancel', '🚪', 'إلغاء الانتماء', 'بقرار رئيس الاتحاد مع براءة ذمة']] : [])]
    : [['apply', '🏪', U.draft ? 'أكمل طلب الانتساب' : 'طلب الانتساب', 'هوية الغرفة التجارية من هاتفك']];
  body.innerHTML = `<div class="page-head"><div><h1>خدماتي لدى الاتحاد</h1><p>${cur ? `الهوية <span class="num">${esc(cur.code)}</span> — ${esc(cur.factory_name)}` : 'لا هوية غرفة تجارية بعد'}</p></div></div>
    <div class="un-svc mb">${T.map(([k, i, t, d]) => `<a class="un-tile" href="#chamber/${k}"><span class="un-ti">${i}</span><b>${esc(t)}</b><small>${d}</small></a>`).join('')}</div>
    <div class="card mb"><b>تحتاج قرضاً تجارياً لمعدات أو بضاعة؟</b><p class="small muted" style="margin:4px 0 10px">قدّمه من «بوابة المقترض» — يصل طلبك إلى غرفة تجارة محافظتك آلياً للكشف والتأييد، وتتابعه هنا في «هويتي».</p>
      <a class="btn ghost sm" href="/citizen#biz">بوابة المقترض ←</a></div>`;
}

// حسابي
async function pageProfile(body) {
  const p = C.profile;
  body.innerHTML = `<div class="page-head"><div><h1>حسابي</h1><p>بوابة التجار — اتحاد الغرف التجارية العراقية</p></div></div>
    <div class="card mb"><dl class="kv sm"><dt>الاسم</dt><dd><b>${esc(p.full_name)}</b></dd><dt>الهاتف</dt><dd class="num" dir="ltr">${esc(p.phone || '—')}</dd>
      ${p.national_id ? `<dt>رقم البطاقة الوطنية</dt><dd class="num" dir="ltr">${esc(p.national_id)}</dd>` : ''}${p.governorate ? `<dt>المحافظة</dt><dd>${esc(p.governorate)}</dd>` : ''}</dl>
      <p class="small muted">الحساب نفسه يعمل في «بوابة المقترض» إن احتجت تمويلاً. تعديل الهاتف وكلمة المرور من هناك.</p></div>
    <div class="row mb" style="gap:8px"><a class="btn ghost" href="/citizen#profile">إعدادات الحساب ←</a><span class="sp"></span><button class="btn ghost bad" data-out>تسجيل الخروج</button></div>`;
  body.querySelector('[data-out]').onclick = async () => { try { await C.sb.auth.signOut(); } catch (e) { toast(cleanErr(e), 'bad'); } location.reload(); };
}
