// الجلسة 60: «بوابة الأطباء البيطريين» (/vets) — حساب شخصي (portal = citizen) مرتبط بنقابة الأطباء البيطريين
// #home      هويتي: الهوية النافذة، التذكير قبل الانتهاء، وتتبع الهوية مع شركة التوصيل ورمز الاستلام
// #activate  منتسب سابق: البطاقة الوطنية + هوية النقابة (رقم العضوية وتاريخا الإصدار والانتهاء) ← تفعيل الحساب
// #join      غير منتسب: شهادة التخرج والبطاقة الوطنية وبطاقة السكن والصورة وتأييد صدور الشهادة ← عنوان الاستلام ← الدفع
// #renew     تجديد الهوية: صورة شخصية جديدة ← عنوان الاستلام بالـGPS ← الدفع
// #files     معاملاتي (ومنها #fix/<id> لاستكمال معاملة أعادتها النقابة) · #profile حسابي
import { esc, dt, iqd, num, rpc, toast, cleanErr, modal, askOtp, govOptions, PAY_METHODS, PAY_LABEL, resultScreen } from '../core.js';
import { cameraCapture } from '../capture.js';
import { wizHead, wireWizHead } from '../wizard-ui.js';
import { SF_KIND, sfBadge, sfSteps, synCard, dlvBadge, DEGREE, day } from '../syn-ui.js';

let C, seq = 0;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg') && !/^#(activate|join|renew|fix)/.test(location.hash);
const route = () => { const [r, id] = location.hash.slice(1).split('/'); return { r: r || 'home', id }; };
const ic = d => `<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const head = (t, p) => `<div class="page-head"><div><h1>${t}</h1>${p ? `<p>${p}</p>` : ''}</div></div>`;
const back = (h = '#home', t = 'هويتي') => `<a class="linkbtn eng-back" href="${h}">→ ${esc(t)}</a>`;
const payGrid = () => `<div class="paygrid">${PAY_METHODS.map(([k, t, col], i) => `<button type="button" data-pm="${k}" class="${i === 0 ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>`;
function wirePay(box) {
  const st = { m: PAY_METHODS[0][0] };
  box.querySelectorAll('[data-pm]').forEach(b => b.onclick = () => { st.m = b.dataset.pm; box.querySelectorAll('[data-pm]').forEach(z => z.classList.toggle('on', z === b)); });
  return st;
}
const feeRows = items => `<dl class="kv sm">${(items || []).map(x => `<dt>${esc(x.t)}</dt><dd>${iqd(x.v)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd((items || []).reduce((a, x) => a + Number(x.v || 0), 0))}</b></dd></dl>`;
const RATIO = { photo: 0.8, id_front: 1.55, id_back: 1.55, syn_front: 1.55, syn_back: 1.55, residence: 1.55 };

export async function render(ctx) {
  C = ctx; C.vets = true;
  if (!ctx.vInit) { ctx.vInit = true; window.addEventListener('hashchange', () => { window.scrollTo(0, 0); go(); }); }
  await go();
}

async function go() {
  const { r, id } = route(), { root } = C;
  if (!root.querySelector('.cz-shell')) {
    root.innerHTML = `<div class="cz-shell in-shell"><nav class="cz-nav" aria-label="أقسام بوابة الأطباء البيطريين">
      <a href="#home" data-n="home">${ic('<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16c.6-1.6 1.8-2.4 3.2-2.4s2.6.8 3.2 2.4M14.5 10h4M14.5 13.5h3"/>')}<span>هويتي</span></a>
      <a href="#files" data-n="files">${ic('<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h4"/>')}<span>معاملاتي</span></a>
      <a href="#profile" data-n="profile">${ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>')}<span>حسابي</span></a></nav><div id="cz"></div></div>`;
    root.querySelectorAll('.cz-nav a').forEach(a => a.addEventListener('click', e => { if (a.getAttribute('href') === (location.hash || '#home')) { e.preventDefault(); go(); } }));
  }
  root.querySelector('.cz-shell').classList.toggle('cz-focus', ['activate', 'join', 'renew', 'fix'].includes(r));
  const nk = ['files', 'fix'].includes(r) ? 'files' : r === 'profile' ? 'profile' : 'home';
  root.querySelectorAll('.cz-nav a').forEach(a => { const on = a.dataset.n === nk; a.classList.toggle('on', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
  const n = ++seq, host = root.querySelector('#cz');
  const body = document.createElement('div'); body.className = 'cz-pg';
  body.innerHTML = '<div class="cz-load" role="status"><div class="spin"></div><span>جارِ التحميل…</span></div>';
  host.replaceChildren(body);
  try {
    if (r === 'profile') return pageProfile(body);
    const S = await rpc(C.sb, 'syn_my');
    if (n !== seq) return;
    if (r === 'activate' || r === 'join') return pageApply(body, S, r);
    if (r === 'renew') return pageRenew(body, S);
    if (r === 'files') return pageFiles(body, S);
    if (r === 'fix') return pageFix(body, S, id);
    return pageHome(body, S);
  } catch (e) { console.error(e); if (n === seq) body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}

// ───────── هويتي ─────────
function pageHome(body, S) {
  const m = S.member, files = S.files || [];
  const open = files.find(f => !['done', 'rejected', 'cancelled', 'draft'].includes(f.status));
  const draft = files.find(f => f.status === 'draft' && f.kind !== 'renewal');
  const ship = files.find(f => f.status === 'ship' && f.ship);
  let top = '';
  if (m && ['active', 'expired'].includes(m.status)) {
    const left = m.days_left, R = m.renew || {};
    const alert = m.status === 'expired' || left < 0 ? ['bad', `انتهت هويتك في <b class="num">${esc(m.valid_until)}</b>`, 'جدّدها الآن — وتصلك الهوية الجديدة إلى بابك.']
      : left <= Number(S.fees?.remind1 || 7) ? ['', left === 0 ? 'تنتهي هويتك اليوم' : `تنتهي هويتك بعد <b class="num">${left}</b> ${left === 1 ? 'يوم' : 'أيام'}`, 'جدّدها من هاتفك الآن بدقيقة.']
      : R.allowed ? ['info', 'يمكنك تجديد هويتك الآن', `تنتهي في <span class="num">${esc(m.valid_until)}</span>.`] : null;
    top = `<div class="mb">${synCard(m, { card: m.card, photo: m.photo, org: S.org?.name })}</div>
      ${ship ? shipCard(ship) : ''}
      ${alert && R.allowed ? `<div class="card mb un-alert ${alert[0]}"><b>${alert[1]}</b><p class="small" style="margin:4px 0 10px">${alert[2]}</p><a class="btn cyan" href="#renew">🔄 جدّد هويتي</a></div>` : ''}
      ${R.pending && !ship ? `<div class="card mb un-alert info"><b>طلب تجديدك قيد الإنجاز</b><p class="small" style="margin:4px 0 0">${esc(R.why)}</p></div>` : ''}
      <div class="card mb"><dl class="kv sm"><dt>الكلية</dt><dd>${esc(m.college || '—')}${m.graduation_year ? ` — <span class="num">${esc(m.graduation_year)}</span>` : ''}</dd>
        <dt>الشهادة</dt><dd>${esc(DEGREE[m.degree] || '—')}${m.specialty ? ` · ${esc(m.specialty)}` : ''}</dd><dt>فرع النقابة</dt><dd>${esc(m.governorate)}</dd>
        ${m.issued_on ? `<dt>تاريخ الإصدار</dt><dd class="num">${esc(m.issued_on)}</dd>` : ''}</dl>
        <p class="small muted" style="margin:8px 0 0">🔔 نذكّرك قبل انتهاء الهوية بـ<b class="num">${num(S.fees?.remind1)}</b> أيام ثم بيومين، برسالة وإشعار.</p></div>
      ${!R.allowed && R.early ? `<p class="small muted center">يُفتح التجديد في <b class="num">${esc(R.opens_at)}</b>.</p>` : ''}`;
  } else if (open) {
    top = `<div class="card mb un-alert info"><b>${SF_KIND[open.kind]?.[1] || ''} ${esc(open.kind_label)} — ${esc(open.status_label)}</b>
      ${sfSteps(open)}<p class="small muted" style="margin:6px 0 0">رقم المعاملة <span class="num">${esc(open.code)}</span> · تصلك كل خطوة إشعاراً.</p>
      ${open.status === 'returned' ? `<p class="small bad-t" style="margin:8px 0">${esc(open.return_note || '')}</p><a class="btn cyan" href="#fix/${open.id}">أكمل النواقص وأعد الإرسال ←</a>` : ''}</div>
      ${ship ? shipCard(ship) : ''}`;
  } else {
    top = `<div class="card mb vs-hero"><h2 style="margin:0 0 6px">أهلاً دكتور — هل أنت منتسب لنقابة الأطباء البيطريين؟</h2>
      <p class="small muted" style="margin:0 0 12px">اختر حالتك. كل شيء من هاتفك دون مراجعة النقابة.</p>
      <div class="un-svc">
        <a class="un-tile" href="#activate"><span class="un-ti">🔑</span><b>نعم، أنا منتسب</b><small>${draft?.kind === 'activate' ? 'أكمل طلب التفعيل' : 'فعّل حسابك برفع البطاقة الوطنية وهوية النقابة'}</small></a>
        <a class="un-tile" href="#join"><span class="un-ti">🎓</span><b>لا، أريد الانتساب</b><small>${draft?.kind === 'join' ? 'أكمل طلب الانتساب' : 'بشهادة التخرج ومستمسكاتك — وتصلك الهوية إلى بابك'}</small></a>
      </div></div>`;
  }
  body.innerHTML = `${head('هويتي في النقابة', esc(S.org?.name || 'نقابة الأطباء البيطريين'))}${top}
    <div class="card mb"><b>تحتاج تمويلاً لعيادة أو مختبر أو مشروع بيطري؟</b><p class="small muted" style="margin:4px 0 10px">عضويتك النافذة تؤيَّد آلياً في مبادرة تمويل الأطباء البيطريين — قدّم من «بوابة المقترض».</p>
      <a class="btn ghost sm" href="/citizen#vet">بوابة المقترض ←</a></div>`;
}

function shipCard(f) {
  const s = f.ship;
  return `<div class="card mb vs-ship"><div class="row"><b>🚚 هويتك مع ${esc(s.courier)}</b><span class="sp"></span>${dlvBadge(s.status)}</div>
    ${s.otp ? `<div class="vs-otp"><small>رمز الاستلام — أعطه للمندوب عند وصوله فقط</small><b class="num" dir="ltr">${esc(s.otp)}</b></div>` : ''}
    <dl class="kv sm"><dt>رقم الشحنة</dt><dd class="num">${esc(s.code)}</dd>${s.agent ? `<dt>المندوب</dt><dd>${esc(s.agent)}${s.agent_phone ? ` · <a href="tel:${esc(s.agent_phone)}" class="num" dir="ltr">${esc(s.agent_phone)}</a>` : ''}</dd>` : ''}
      <dt>العنوان</dt><dd>${esc(s.address || '')}</dd>${s.fail_note ? `<dt>ملاحظة</dt><dd class="bad-t">${esc(s.fail_note)}</dd>` : ''}</dl></div>`;
}

// ───────── التفعيل والانتساب ─────────
const STEPS = {
  activate: [['بياناتك', 'رقم العضوية والتواريخ'], ['المستمسكات', 'البطاقة الوطنية وهوية النقابة'], ['المراجعة', 'وأرسل للنقابة']],
  join: [['بياناتك', 'الكلية والتخرج'], ['المستمسكات', 'كما في المعاملة الورقية'], ['عنوان الاستلام', 'أين تصلك الهوية'], ['الدفع', 'وأرسل للنقابة']],
};
async function pageApply(body, S, kind) {
  const m = S.member;
  if (m && ['active', 'expired'].includes(m.status)) { location.hash = '#home'; return; }
  const busy = (S.files || []).find(f => ['activate', 'join'].includes(f.kind) && !['draft', 'done', 'rejected', 'cancelled'].includes(f.status));
  if (busy) { location.hash = busy.status === 'returned' ? `#fix/${busy.id}` : '#files'; return; }
  const D = (S.files || []).find(f => f.kind === kind && f.status === 'draft');
  const other = (S.files || []).find(f => f.kind !== kind && ['activate', 'join'].includes(f.kind) && f.status === 'draft');
  const steps = STEPS[kind], last = steps.length - 1;
  const missing = D ? (D.docs || []).filter(d => d.required && !d.doc) : [];
  const st = C.vAp = (C.vAp && C.vAp.kind === kind && D) ? C.vAp : { kind, step: D ? (missing.length ? 1 : 2) : 0, deliv: null };
  const reach = !D ? 0 : missing.length ? 1 : last;
  const go = st.go = n => { st.step = n; pageApply(body, S, kind); window.scrollTo(0, 0); };
  const reload = async () => { const S2 = await rpc(C.sb, 'syn_my'); return pageApply(body, S2, kind); };
  const d = D?.data || {};
  const title = kind === 'activate' ? 'تفعيل عضويتي في النقابة' : 'طلب الانتساب للنقابة';
  const wz = wizHead({ title, sub: D ? `<span class="num">${esc(D.code)}</span> · مسودة محفوظة` : '', steps, cur: st.step, done: !D ? 0 : missing.length ? 1 : Math.max(st.step, 2), reach, exit: '#home' });
  const f = (k, l, ph = '', a = '', v = d[k] ?? '') => `<div class="field"><label>${l}</label><input class="input" data-k="${k}" placeholder="${esc(ph)}" value="${esc(v)}" ${a}></div>`;

  if (st.step === 0) {
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      ${other ? `<p class="small muted" style="margin-top:0">لديك مسودة ${esc(other.kind_label)} — إن تابعت هنا تبقى محفوظة.</p>` : ''}
      ${kind === 'activate' ? `<p class="small muted" style="margin-top:0">انقل البيانات من هوية النقابة الورقية كما هي — يطابقها قسم العضوية مع سجل النقابة.</p>
        ${f('membership_no', 'رقم العضوية ★', 'كما في الهوية', 'dir="ltr" inputmode="numeric"')}
        <div class="grid g2" style="gap:12px">${f('issued_on', 'تاريخ إصدار الهوية ★', '', 'type="date" dir="ltr"')}${f('valid_until', 'تاريخ انتهاء الهوية ★', '', 'type="date" dir="ltr"')}</div>` : ''}
      <div class="field"><label>فرع النقابة (المحافظة) ★</label><select class="input" data-k="governorate">${govOptions(d.governorate || S.me?.governorate || '')}</select></div>
      ${f('college', 'الكلية ★', 'مثال: كلية الطب البيطري — جامعة بغداد')}
      <div class="grid g2" style="gap:12px">${f('graduation_year', `سنة التخرج${kind === 'join' ? ' ★' : ''}`, '', 'inputmode="numeric" dir="ltr" maxlength="4"')}
        <div class="field"><label>الشهادة</label><select class="input" data-k="degree">${Object.entries(DEGREE).map(([k, t]) => `<option value="${k}" ${(d.degree || 'bachelor') === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div></div>
      ${f('specialty', 'الاختصاص (إن وُجد)', 'مثال: الجراحة، الدواجن، الأمراض الباطنية')}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-next>التالي: المستمسكات ←</button></div></div></div>`;
    body.querySelector('[data-next]').onclick = async e => {
      const p = {}; body.querySelectorAll('[data-k]').forEach(i => p[i.dataset.k] = i.value.trim());
      if (!p.governorate || !p.college || (kind === 'join' && !p.graduation_year) || (kind === 'activate' && (!p.membership_no || !p.issued_on || !p.valid_until))) return toast('أكمل الحقول المعلَّمة ★', 'bad');
      e.target.disabled = true;
      try { await rpc(C.sb, 'syn_start', { p_kind: kind, p }); st.step = 1; await reload(); window.scrollTo(0, 0); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  } else if (st.step === 1) {
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">${docsList(D)}
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span>
        <button class="btn cyan ${missing.length ? 'is-off' : ''}" data-next>${missing.length ? `بقي ${missing.length} من المستمسكات` : `التالي: ${esc(steps[2][0])} ←`}</button></div></div></div>`;
    body.querySelector('[data-prev]').onclick = () => go(0);
    wireDocs(body, D, reload);
    body.querySelector('[data-next]').onclick = () => { if (missing.length) return toast(`بقي: ${missing.map(x => x.label).join('، ')}`, 'bad'); go(2); };
  } else if (kind === 'join' && st.step === 2) {
    return addressStep(body, wz, st, () => go(1), () => go(3));
  } else {
    const isJoin = kind === 'join';
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <dl class="kv sm">${isJoin ? '' : `<dt>رقم العضوية</dt><dd class="num">${esc(d.membership_no)}</dd><dt>الهوية</dt><dd>من <span class="num">${esc(d.issued_on)}</span> إلى <span class="num">${esc(d.valid_until)}</span></dd>`}
        <dt>فرع النقابة</dt><dd>${esc(d.governorate || '')}</dd><dt>الكلية</dt><dd>${esc(d.college || '')}${d.graduation_year ? ` — <span class="num">${esc(d.graduation_year)}</span>` : ''}</dd>
        <dt>المستمسكات</dt><dd>${(D.docs || []).filter(x => x.doc).length} مرفوعة ✓</dd>
        ${isJoin && st.deliv ? `<dt>الاستلام</dt><dd>${esc(st.deliv.address)} · 📍</dd>` : ''}</dl>
      ${isJoin ? `<div class="review mt">${feeRows(D.fee_items)}${payGrid()}</div>` : '<p class="small muted mt">التفعيل بلا رسوم. يدقق قسم العضوية ثم قسم التدقيق والسجلات بياناتك، ويصلك إشعار حين يُفعَّل حسابك.</p>'}
      <label class="row small mt" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" data-cf style="margin-top:4px"> <span>أقر بأن البيانات صحيحة وأن المستمسكات أصلية، وأتحمّل المسؤولية القانونية عن أي بيان غير صحيح.</span></label>
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-go>${isJoin ? 'ادفع وأرسل الطلب ←' : 'أرسل للنقابة ←'}</button></div>
      <p class="small" style="text-align:center;margin-top:10px"><button type="button" class="linkbtn muted" data-del>حذف المسودة والبدء من جديد</button></p></div></div>`;
    const pay = isJoin ? wirePay(body) : null;
    body.querySelector('[data-prev]').onclick = () => go(isJoin ? 2 : 1);
    body.querySelector('[data-del]').onclick = async () => { if (!window.confirm('حذف المسودة ومستمسكاتها؟')) return; try { await rpc(C.sb, 'syn_discard', { p_file: D.id }); C.vAp = null; location.hash = '#home'; } catch (e) { toast(cleanErr(e), 'bad'); } };
    body.querySelector('[data-go]').onclick = async e => {
      if (!body.querySelector('[data-cf]').checked) return toast('ضع علامة الإقرار أولاً', 'bad');
      if (isJoin && !st.deliv) { toast('حدّد عنوان الاستلام أولاً', 'bad'); return go(2); }
      let res;
      if (isJoin) {
        const total = (D.fee_items || []).reduce((a, x) => a + Number(x.v || 0), 0);
        const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: C.profile.phone, purpose: `رسوم الانتساب والهوية والتوصيل ${num(total)} د.ع`,
          verify: async c => { res = await rpc(C.sb, 'syn_submit', { p_file: D.id, p: { ...st.deliv, method: pay.m, otp: c, confirm: true } }); } });
        if (!ok) return;
      } else {
        e.target.disabled = true;
        try { res = await rpc(C.sb, 'syn_submit', { p_file: D.id, p: { confirm: true } }); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; return; }
      }
      C.vAp = null;
      await resultScreen({ ok: true, title: isJoin ? 'أُرسل طلب انتسابك' : 'أُرسل طلب التفعيل', ref: res?.code,
        msg: isJoin ? 'يمر طلبك على أقسام النقابة: العضوية ← التدقيق ← الحسابات ← قرار النقيب، ثم تُطبع هويتك وتصلك عبر شركة التوصيل.' : 'يدقق قسم العضوية مستمسكاتك ويطابقها مع سجل النقابة، ثم يُفعَّل حسابك وتصلك رسالة.',
        rows: isJoin ? [['المدفوع', iqd(res?.fee)], ['مرجع الدفع', `<span class="num" dir="ltr">${esc(res?.ref || '')}</span>`]] : [] });
      location.hash = '#home';
    };
  }
  wireWizHead(body, go);
}

function docsList(D) {
  return `<p class="small muted" style="margin-top:0">صوّر كل مستمسك بهاتفك في إضاءة جيدة، أو ارفعه ملفاً. المعلَّم ★ مطلوب.</p>
    ${(D.docs || []).map(x => `<div class="un-doc ${x.doc ? 'ok' : ''}"><span class="un-dk">${x.doc ? '✅' : x.required ? '⬜' : '▫️'}</span>
      <div style="flex:1"><b>${esc(x.label)}</b>${x.required ? ' <span class="small bad-t">★</span>' : ' <span class="small muted">(اختياري)</span>'}</div>
      ${x.doc ? `<button type="button" class="btn ghost sm" data-see="${x.doc}">عرض</button>` : ''}<button type="button" class="btn sm ${x.doc ? 'ghost' : 'cyan'}" data-up="${x.kind}" data-lbl="${esc(x.label)}">${x.doc ? 'استبدال' : '📷 صوّر'}</button></div>`).join('')}`;
}
function wireDocs(body, D, reload) {
  body.querySelectorAll('[data-see]').forEach(b => b.onclick = () => viewDoc(b.dataset.see));
  body.querySelectorAll('[data-up]').forEach(b => b.onclick = async () => {
    const kind = b.dataset.up;
    const shot = await cameraCapture({ title: `صوّر: ${b.dataset.lbl}`, hint: kind === 'photo' ? 'صورة حديثة بخلفية فاتحة، الوجه واضح ودون نظارة شمسية' : '', allowFile: kind !== 'photo',
      ratio: RATIO[kind] || 0.72, facing: kind === 'photo' ? 'user' : 'environment' });
    if (!shot) return;
    b.disabled = true;
    try { await rpc(C.sb, 'syn_doc_add', { p_file: D.id, p_kind: kind, p_data: shot.data, p_meta: shot.meta || {} }); toast('حُفظ ✓', 'ok'); await reload(); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
}
async function viewDoc(id) {
  try {
    const d = await rpc(C.sb, 'syn_doc', { p_id: id });
    modal(`<h3>${esc(d.label || '')}</h3>${String(d.mime || '').startsWith('image/') ? `<img src="${d.data}" alt="" style="width:100%;border-radius:10px">` : `<iframe src="${d.data}" style="width:100%;height:70vh;border:0"></iframe>`}
      <p class="small muted">رُفع ${dt(d.at)}</p>`, { wide: true });
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

// عنوان الاستلام: GPS + وصف + هاتف المستلم
function addressStep(body, wz, st, prev, next) {
  const v = st.deliv || { phone: C.profile.phone || '', recipient: C.profile.full_name || '' };
  const g = v.geo;
  body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
    <div class="eng-visit ${g ? 'ok' : ''}">${g ? `<div class="row"><span class="eng-pin">📍</span><div><b>ثُبّت موقع الاستلام</b><div class="small muted">دقة ±<span class="num">${num(g.acc)}</span> م — يصل المندوب بالخريطة مباشرة</div></div></div>`
      : '<b>أين تريد استلام الهوية؟</b><p class="small muted" style="margin:4px 0 10px">قف في مكان الاستلام (البيت أو العيادة) واضغط الزر — يصل مندوب شركة التوصيل بالخريطة.</p>'}
      <button class="btn ${g ? 'ghost' : 'cyan'} big-btn" data-gps>📍 ${g ? 'أعد التحديد' : 'حدّد موقعي الآن'}</button></div>
    <div class="field mt"><label>وصف العنوان ★</label><input class="input" data-a value="${esc(v.address || '')}" placeholder="المنطقة، الشارع، أقرب نقطة دالة، رقم الدار"></div>
    <div class="grid g2" style="gap:12px"><div class="field"><label>هاتف المستلم ★</label><input class="input" data-p dir="ltr" inputmode="tel" value="${esc(v.phone || '')}"></div>
      <div class="field"><label>اسم المستلم</label><input class="input" data-r value="${esc(v.recipient || '')}"></div></div>
    <p class="small muted">لا يُسلّم المندوب الهوية إلا برمز استلام يظهر في هاتفك فقط.</p>
    <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-next>التالي: الدفع ←</button></div></div></div>`;
  const read = () => ({ ...v, address: body.querySelector('[data-a]').value.trim(), phone: body.querySelector('[data-p]').value.replace(/\D/g, ''), recipient: body.querySelector('[data-r]').value.trim() });
  body.querySelector('[data-prev]').onclick = () => { st.deliv = read(); prev(); };
  body.querySelector('[data-gps]').onclick = async () => {
    const { gpsDialog } = await import('../geo.js');
    const gg = await gpsDialog({ title: 'موقع استلام الهوية', place: 'في مكان الاستلام (البيت أو العيادة)', want: 30, accMax: 150 });
    if (!gg) return;
    st.deliv = { ...read(), geo: { lat: gg.lat, lng: gg.lng, acc: gg.acc } };
    addressStep(body, wz, st, prev, next);
  };
  body.querySelector('[data-next]').onclick = () => {
    const x = read();
    if (!v.geo) return toast('حدّد موقع الاستلام بالـGPS أولاً', 'bad');
    if (x.address.length < 6) return toast('اكتب وصف العنوان', 'bad');
    if (!/^07[3-9]\d{8}$/.test(x.phone)) return toast('رقم الهاتف غير صحيح (07xxxxxxxxx)', 'bad');
    st.deliv = x; next();
  };
  if (st.go) wireWizHead(body, n => { st.deliv = read(); st.go(n); });
}

// ───────── التجديد ─────────
const RN_STEPS = [['الصورة الجديدة', 'صورة شخصية حديثة'], ['عنوان الاستلام', 'أين تصلك الهوية'], ['الدفع', 'وأرسل للنقابة']];
async function pageRenew(body, S) {
  const m = S.member;
  if (!m || !['active', 'expired'].includes(m.status)) { location.hash = '#home'; return; }
  let D = (S.files || []).find(f => f.kind === 'renewal' && f.status === 'draft');
  if (!D) {
    if (!m.renew?.allowed) { body.innerHTML = `${back()}${head('🔄 تجديد الهوية')}<div class="card"><b>التجديد غير متاح الآن</b><p class="small">${esc(m.renew?.why || '')}</p></div>`; return; }
    try { await rpc(C.sb, 'syn_start', { p_kind: 'renewal', p: {} }); const S2 = await rpc(C.sb, 'syn_my'); D = (S2.files || []).find(f => f.kind === 'renewal' && f.status === 'draft'); }
    catch (e) { body.innerHTML = `${back()}<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  }
  const photo = (D.docs || []).find(x => x.kind === 'photo');
  const st = C.vRn = (C.vRn && C.vRn.id === D.id) ? C.vRn : { id: D.id, step: photo?.doc ? 1 : 0, deliv: null };
  const go = st.go = n => { st.step = n; pageRenew(body, S); window.scrollTo(0, 0); };
  const reload = async () => { const S2 = await rpc(C.sb, 'syn_my'); return pageRenew(body, S2); };
  const wz = wizHead({ title: 'تجديد هوية النقابة', sub: `<span class="num">${esc(m.membership_no)}</span> · ${m.status === 'expired' || m.days_left < 0 ? 'منتهية' : `تنتهي ${esc(m.valid_until)}`}`,
    steps: RN_STEPS, cur: st.step, done: photo?.doc ? (st.deliv ? 2 : 1) : 0, reach: photo?.doc ? (st.deliv ? 2 : 1) : 0, exit: '#home' });
  if (st.step === 0) {
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <div class="vs-selfie">${photo?.doc ? '<div class="vs-ph vs-ph0">✅</div>' : '<div class="vs-ph vs-ph0">🙂</div>'}<div><b>صورة شخصية حديثة للهوية</b>
        <p class="small muted" style="margin:4px 0 0">بالكاميرا الأمامية، خلفية فاتحة، الوجه واضح ومستقيم.</p></div></div>
      <div class="row mt" style="gap:8px">${photo?.doc ? `<button class="btn ghost" data-see="${photo.doc}">عرض الصورة</button>` : ''}<button class="btn ${photo?.doc ? 'ghost' : 'cyan'}" data-up="photo" data-lbl="الصورة الشخصية">📷 ${photo?.doc ? 'التقط من جديد' : 'التقط صورتك'}</button>
        <span class="sp"></span><button class="btn cyan ${photo?.doc ? '' : 'is-off'}" data-next>التالي: عنوان الاستلام ←</button></div></div></div>`;
    wireDocs(body, D, reload);
    body.querySelector('[data-next]').onclick = () => photo?.doc ? go(1) : toast('التقط صورتك أولاً', 'bad');
  } else if (st.step === 1) {
    return addressStep(body, wz, st, () => go(0), () => go(2));
  } else {
    const total = (D.fee_items || []).reduce((a, x) => a + Number(x.v || 0), 0);
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <dl class="kv sm"><dt>رقم العضوية</dt><dd class="num">${esc(m.membership_no)}</dd><dt>النفاذ الجديد</dt><dd>حتى <b class="num">${esc(m.renew?.new_valid || '')}</b> (بعد اعتماد النقابة)</dd>
        <dt>الاستلام</dt><dd>${esc(st.deliv?.address || '')} · 📍</dd></dl>
      <div class="review mt">${feeRows(D.fee_items)}${payGrid()}</div>
      <label class="row small mt" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" data-cf style="margin-top:4px"> <span>أقر بأن بياناتي لدى النقابة لم تتغير، وأن الصورة صورتي الحديثة.</span></label>
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-go>ادفع ${num(total)} د.ع وجدّد ←</button></div></div></div>`;
    const pay = wirePay(body);
    body.querySelector('[data-prev]').onclick = () => go(1);
    body.querySelector('[data-go]').onclick = async () => {
      if (!st.deliv?.geo) { toast('حدّد عنوان الاستلام أولاً', 'bad'); return go(1); }
      if (!body.querySelector('[data-cf]').checked) return toast('ضع علامة الإقرار أولاً', 'bad');
      let res;
      const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: C.profile.phone, purpose: `تجديد هوية النقابة والتوصيل ${num(total)} د.ع`,
        verify: async c => { res = await rpc(C.sb, 'syn_submit', { p_file: D.id, p: { ...st.deliv, method: pay.m, otp: c, confirm: true } }); } });
      if (!ok) return;
      C.vRn = null;
      await resultScreen({ ok: true, title: 'وصل طلب التجديد للنقابة', ref: res?.code, msg: 'يمر على قسم العضوية ← الحسابات ← الاعتماد، ثم تُطبع هويتك الجديدة وتصلك عبر شركة التوصيل. تصلك كل خطوة إشعاراً.',
        rows: [['المدفوع', iqd(res?.fee)], ['مرجع الدفع', `<span class="num" dir="ltr">${esc(res?.ref || '')}</span>`]] });
      location.hash = '#home';
    };
  }
  wireWizHead(body, go);
}

// ───────── معاملاتي ─────────
function pageFiles(body, S) {
  const files = (S.files || []).filter(f => f.status !== 'draft');
  body.innerHTML = `${head('معاملاتي لدى النقابة', 'كل معاملة تنتقل من قسم إلى قسم — وتصلك كل خطوة إشعاراً')}
    ${files.map(f => `<div class="card mb"><div class="row"><b>${SF_KIND[f.kind]?.[1] || ''} ${esc(f.kind_label)}</b><span class="sp"></span>${sfBadge(f.status)}</div>
      <div class="small muted"><span class="num">${esc(f.code)}</span> · ${dt(f.submitted_at || f.created_at)}${f.fee_paid_at ? ` · مدفوع ${iqd(f.fee)}` : ''}</div>
      ${sfSteps(f)}
      ${f.status === 'returned' ? `<div class="un-alert card mt" style="padding:10px"><b>ما تطلبه النقابة:</b><p class="small" style="margin:4px 0 8px">${esc(f.return_note || '')}</p><a class="btn cyan sm" href="#fix/${f.id}">أكمل وأعد الإرسال ←</a></div>` : ''}
      ${f.status === 'rejected' ? `<p class="small bad-t">السبب: ${esc(f.reason || '')}</p>` : ''}
      ${f.status === 'ship' && f.ship ? shipCard(f) : ''}
      <details class="small mt"><summary>سجل المعاملة</summary><ul class="vs-log">${(f.log || []).map(l => `<li><b>${esc(l.a)}</b><span class="muted"> — ${esc(l.by || '')} · ${dt(l.at)}</span>${l.note ? `<div>${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details></div>`).join('')
      || '<div class="card empty">لا معاملات بعد. ابدأ من «هويتي».</div>'}`;
}

// استكمال معاملة أعادتها النقابة
async function pageFix(body, S, id) {
  const F = (S.files || []).find(f => f.id === id);
  if (!F || F.status !== 'returned') { location.hash = '#files'; return; }
  const missing = (F.docs || []).filter(d => d.required && !d.doc);
  body.innerHTML = `${back('#files', 'معاملاتي')}${head('استكمال المعاملة', `<span class="num">${esc(F.code)}</span> — ${esc(F.kind_label)}`)}
    <div class="card mb un-alert"><b>ما تطلبه النقابة</b><p class="small" style="margin:4px 0 0">${esc(F.return_note || '')}</p></div>
    <div class="card">${docsList(F)}
      <label class="row small mt" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" data-cf style="margin-top:4px"> <span>أقر بأني أكملت ما طُلب وأن المستمسكات أصلية.</span></label>
      <div class="row mt"><span class="sp"></span><button class="btn cyan ${missing.length ? 'is-off' : ''}" data-go>أعد الإرسال للنقابة ←</button></div></div>`;
  wireDocs(body, F, async () => { const S2 = await rpc(C.sb, 'syn_my'); return pageFix(body, S2, id); });
  body.querySelector('[data-go]').onclick = async e => {
    if (missing.length) return toast(`بقي: ${missing.map(x => x.label).join('، ')}`, 'bad');
    if (!body.querySelector('[data-cf]').checked) return toast('ضع علامة الإقرار أولاً', 'bad');
    e.target.disabled = true;
    try { const r = await rpc(C.sb, 'syn_submit', { p_file: F.id, p: { confirm: true } }); toast(`أُعيدت المعاملة ${r.code} للنقابة ✓`, 'ok'); location.hash = '#files'; }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── حسابي ─────────
function pageProfile(body) {
  const p = C.profile;
  body.innerHTML = `${head('حسابي', 'بوابة الأطباء البيطريين — نقابة الأطباء البيطريين')}
    <div class="card mb"><dl class="kv sm"><dt>الاسم</dt><dd><b>${esc(p.full_name)}</b></dd><dt>الهاتف</dt><dd class="num" dir="ltr">${esc(p.phone || '—')}</dd>
      ${p.national_id ? `<dt>رقم البطاقة الوطنية</dt><dd class="num" dir="ltr">${esc(p.national_id)}</dd>` : ''}${p.governorate ? `<dt>المحافظة</dt><dd>${esc(p.governorate)}</dd>` : ''}</dl>
      <p class="small muted">الحساب نفسه يعمل في «بوابة المقترض» إن احتجت تمويلاً. تعديل الهاتف وكلمة المرور من هناك.</p></div>
    <div class="row mb" style="gap:8px"><a class="btn ghost" href="/citizen#profile">إعدادات الحساب ←</a><span class="sp"></span><button class="btn ghost bad" data-out>تسجيل الخروج</button></div>`;
  body.querySelector('[data-out]').onclick = async () => { try { await C.sb.auth.signOut(); } catch (e) { toast(cleanErr(e), 'bad'); } location.reload(); };
}
