// الجلسة 60: «بوابة شركات التوصيل» (/courier) — شحنات الجهات المرتبطة بالمنصة (هويات نقابة الأطباء البيطريين أولاً)
// مدير الشركة: يرى كل الشحنات ويسندها للمندوب. المندوب: يرى شحناته — استلمتُ من الجهة ← في الطريق ← سلّمتُ برمز الاستلام.
// رمز الاستلام يظهر في هاتف المستلم فقط؛ لا يُغلق التسليم دونه.
import { esc, num, dt, ago, kpi, tabs, rpc, toast, cleanErr, modal, iqd, mapsLink } from '../core.js';
import { dlvBadge } from '../syn-ui.js';

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  const X = await rpc(sb, 'courier_inbox');
  const items = X.items || [], admin = X.role === 'courier_admin';
  const open = items.filter(d => !['delivered', 'returned'].includes(d.status));
  const todo = admin ? items.filter(d => d.status === 'new') : open;
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'شركة التوصيل')}</h1><p>${admin ? 'مدير الشركة — تسند الشحنات للمندوبين وتتابعها' : `المندوب ${esc(profile.full_name)} — ${esc(profile.governorate || '')}`}</p></div></div>
    <div class="grid g4 mb">
      ${kpi(admin ? 'بانتظار مندوب' : 'شحناتي المفتوحة', `<span class="num">${todo.length}</span>`, admin ? 'أسندها الآن' : 'استلم وسلّم', true)}
      ${kpi('في الطريق', `<span class="num">${items.filter(d => ['picked', 'out'].includes(d.status)).length}</span>`)}
      ${kpi('متأخرة', `<span class="num">${items.filter(d => d.late).length}</span>`, 'تجاوزت مدة التسليم')}
      ${kpi('سُلّمت', `<span class="num">${items.filter(d => d.status === 'delivered').length}</span>`)}
    </div><div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'open', label: admin ? 'الشحنات المفتوحة' : 'شحناتي', count: open.length }, { key: 'done', label: 'المنتهية' }, ...(admin ? [{ key: 'agents', label: 'المندوبون' }] : [])];
  ctx.crTab = defs.some(d => d.key === ctx.crTab) ? ctx.crTab : 'open';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.crTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.crTab));

  function show(k) {
    if (k === 'agents') {
      body.innerHTML = `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المندوب</th><th>المحافظة</th><th>الهاتف</th><th>شحنات مفتوحة</th></tr></thead><tbody>
        ${(X.agents || []).map(a => `<tr><td><b>${esc(a.name)}</b></td><td>${esc(a.governorate || '—')}</td><td class="num" dir="ltr">${esc(a.phone || '—')}</td><td class="num">${num(a.open)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">لا مندوبين — أضفهم من «فريقي».</td></tr>'}</tbody></table></div></div>`;
      return;
    }
    const list = k === 'open' ? open : items.filter(d => ['delivered', 'returned'].includes(d.status));
    body.innerHTML = list.length ? `<div class="cr-list">${list.map(d => `<button type="button" class="card cr-item ${d.late ? 'late' : ''}" data-d="${d.id}">
        <div class="row"><b>${esc(d.recipient)}</b><span class="sp"></span>${dlvBadge(d.status)}</div>
        <div class="small">${esc(d.item)}</div>
        <div class="small muted">📍 ${esc(d.governorate || '')} — ${esc(d.address)}</div>
        <div class="small muted"><span class="num">${esc(d.code)}</span> · من ${esc(d.source || '')} · ${ago(d.created_at)}${d.agent ? ` · المندوب ${esc(d.agent)}` : ''}${d.late ? ' · <b class="bad-t">متأخرة</b>' : ''}</div></button>`).join('')}</div>`
      : '<div class="card empty">لا شحنات هنا الآن.</div>';
    body.querySelectorAll('[data-d]').forEach(b => b.onclick = () => openItem(ctx, X, items.find(x => x.id === b.dataset.d)));
  }
  show(ctx.crTab);
  if (ctx.crOpen) { const d = items.find(x => x.id === ctx.crOpen); ctx.crOpen = null; if (d) openItem(ctx, X, d); }   // من جرس الإشعارات
}

function openItem(ctx, X, d) {
  const admin = X.role === 'courier_admin';
  const canAssign = admin && ['new', 'assigned', 'failed'].includes(d.status);
  const md = modal(`<h3>شحنة <span class="num">${esc(d.code)}</span> ${dlvBadge(d.status)}</h3>
    <dl class="kv sm"><dt>المحتوى</dt><dd>${esc(d.item)}</dd>
      <dt>الاستلام من</dt><dd>${esc(d.pickup?.name || d.source || '')} — ${esc(d.pickup?.branch || '')}${d.pickup?.phone ? ` · <span class="num" dir="ltr">${esc(d.pickup.phone)}</span>` : ''}</dd>
      <dt>المستلم</dt><dd><b>${esc(d.recipient)}</b>${d.phone ? ` · <a class="num" dir="ltr" href="tel:${esc(d.phone)}">${esc(d.phone)}</a>` : ''}</dd>
      <dt>العنوان</dt><dd>${esc(d.governorate || '')} — ${esc(d.address)}${d.geo ? `<div><a class="btn ghost sm mt" href="${mapsLink(d.geo)}" target="_blank" rel="noopener">📍 افتح الموقع في الخرائط</a></div>` : ''}</dd>
      <dt>أجور التوصيل</dt><dd>${iqd(d.fee)} <span class="small muted">(مدفوعة إلكترونياً مع المعاملة)</span></dd>
      ${d.attempts ? `<dt>محاولات فاشلة</dt><dd class="num">${num(d.attempts)}${d.fail_note ? ` — ${esc(d.fail_note)}` : ''}</dd>` : ''}
      <dt>مدة التسليم</dt><dd>حتى ${dt(d.due_at)}</dd></dl>
    ${canAssign ? `<div class="card mt"><div class="field"><label>المندوب</label><select class="input" data-ag>${[...(X.agents || [])].sort((a, b) => (b.governorate === d.governorate) - (a.governorate === d.governorate)).map(a => `<option value="${a.id}" ${a.id === d.agent_id ? 'selected' : ''}>${esc(a.name)} — ${esc(a.governorate || '')} (${num(a.open)} مفتوحة)</option>`).join('')}</select></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-a="assign">${d.agent_id ? 'غيّر المندوب' : 'أسند للمندوب'}</button></div></div>` : ''}
    <div class="card mt" data-acts></div>
    <details class="small mt"><summary>مسار الشحنة</summary><ul class="vs-log">${(d.events || []).map(e => `<li><b>${esc((dlvLabel(e.s)))}</b><span class="muted"> — ${esc(e.by || '')} · ${dt(e.at)}</span>${e.note ? `<div>${esc(e.note)}</div>` : ''}</li>`).join('')}</ul></details>`, { wide: true });
  const acts = md.el.querySelector('[data-acts]');
  const B = [];
  if (['assigned', 'new'].includes(d.status) && (d.agent_id || !admin)) B.push(['pickup', '📦 استلمتُ الشحنة من الجهة', 'cyan']);
  if (['picked', 'failed'].includes(d.status)) B.push(['out', '🚚 انطلقتُ للتسليم', 'cyan']);
  if (['out', 'picked', 'failed'].includes(d.status)) B.push(['deliver', '✅ سلّمتُ — أدخل رمز الاستلام', 'ok']);
  if (['out', 'picked'].includes(d.status)) B.push(['fail', 'تعذّر التسليم', 'warn']);
  if (['picked', 'out', 'failed'].includes(d.status)) B.push(['return', 'إعادة للجهة', 'ghost bad']);
  acts.innerHTML = B.length ? `<div class="row" style="gap:8px;flex-wrap:wrap">${B.map(([k, t, c]) => `<button class="btn ${c}" data-a="${k}">${t}</button>`).join('')}</div>` : `<p class="small muted" style="margin:0">${d.status === 'delivered' ? `سُلّمت ${dt(d.delivered_at)}.` : d.status === 'returned' ? 'أُعيدت للجهة.' : 'بانتظار إسناد مندوب.'}</p>`;
  if (!B.length && !canAssign) acts.remove();
  md.el.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
    const a = b.dataset.a, p = {};
    if (a === 'assign') p.agent = md.el.querySelector('[data-ag]')?.value;
    if (a === 'fail' || a === 'return') {
      p.note = window.prompt(a === 'fail' ? 'سبب تعذّر التسليم (مثلاً: الهاتف مغلق، العنوان غير موجود)' : 'سبب الإعادة للجهة');
      if (!p.note) return;
    }
    if (a === 'deliver') {
      const r = await deliverDialog(d);
      if (!r) return;
      Object.assign(p, r);
    }
    b.disabled = true;
    try {
      await rpc(ctx.sb, 'courier_act', { p_id: d.id, p_action: a, p });
      md.close(); toast(a === 'deliver' ? 'سُلّمت الشحنة ✓ — أُبلغ المستلم والجهة' : 'سُجّل ✓', 'ok'); ctx.refresh();
    } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
}
const dlvLabel = s => ({ new: 'سلّمت الجهة الشحنة للشركة', assigned: 'أُسندت لمندوب', picked: 'استلمها المندوب', out: 'في الطريق', delivered: 'سُلّمت للمستلم', failed: 'تعذّر التسليم', returned: 'أُعيدت للجهة' }[s] || s);

// التسليم: رمز الاستلام من هاتف المستلم + الموقع (اختياري)
function deliverDialog(d) {
  return new Promise(resolve => {
    let geo = null, done = false;
    const end = v => { if (done) return; done = true; resolve(v); };
    const m = modal(`<h3>تسليم الشحنة <span class="num">${esc(d.code)}</span></h3>
      <p class="small muted">اطلب من <b>${esc(d.recipient)}</b> رمز الاستلام (4 أرقام) الظاهر في هاتفه داخل «بوابة الأطباء البيطريين». لا تسلّم دونه.</p>
      <div class="field"><label>رمز الاستلام</label><input class="input num" data-o inputmode="numeric" maxlength="4" dir="ltr" style="font-size:24px;letter-spacing:8px;text-align:center"></div>
      <div class="field"><label>اسم من استلم (إن لم يكن صاحب الشحنة)</label><input class="input" data-r></div>
      <div class="row" style="gap:8px"><button type="button" class="btn ghost sm" data-g>📍 ثبّت موقع التسليم</button><span class="small muted" data-gs></span><span class="sp"></span><button class="btn ok" data-ok>تأكيد التسليم</button></div>`,
      { onClose: () => end(null) });
    m.el.querySelector('[data-g]').onclick = () => {
      const s = m.el.querySelector('[data-gs]'); s.textContent = 'جارِ التحديد…';
      navigator.geolocation?.getCurrentPosition(p => { geo = { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }; s.textContent = `✓ ±${Math.round(p.coords.accuracy)} م`; },
        () => { s.textContent = 'تعذّر التحديد — يمكن المتابعة دونه'; }, { enableHighAccuracy: true, timeout: 15000 });
    };
    m.el.querySelector('[data-ok]').onclick = () => {
      const otp = m.el.querySelector('[data-o]').value.replace(/\D/g, '');
      if (otp.length !== 4) return toast('اكتب رمز الاستلام (4 أرقام)', 'bad');
      end({ otp, geo, receiver: m.el.querySelector('[data-r]').value.trim() || null }); m.close();
    };
  });
}

export const shouldRefresh = () => !document.querySelector('.mdl-bg');
