// الجلسة 40: بوابة شركات التأمين — دورة الوثيقة على المشروع الممول داخل الشركة، والمطالبات
// الاكتتاب: يستلم الطلب ويحيله للمعاينة أو يسعّره · المعاين: يثبّت زيارته بالـGPS ويسجّل الخطر بصورة
// مدير الفرع: يعتمد ضمن سقف فرعه · الإدارة العليا: ما فوق السقف والأسعار والإلغاء · الحسابات: القسط والتعويض
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, mapsLink, iqd, num, resultScreen, VET_TYPES } from '../core.js';
import { POL_ST, CLM_ST, CAUSES, RISK, POL_STEPS, polBadge, clmBadge, insPhoto, claimForm } from '../ins-ui.js';

let D;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg,.ins-act');

const ROLE_IC = { ins_md: '🏛', ins_branch_mgr: '🏢', ins_underwriter: '📝', ins_surveyor: '📍', ins_claims: '🧾', ins_finance: '💳' };
const money = v => String(v ?? '').replace(/[^0-9]/g, '');
const fmt = v => v ? Number(v).toLocaleString('en-US') : '';

// ما ينتظر هذا الموظف تحديداً
function mine(me) {
  const r = me.role;
  const P = D.policies.filter(p =>
    (p.status === 'new' && ['ins_underwriter', 'ins_branch_mgr', 'ins_md'].includes(r)) ||
    (p.status === 'survey' && p.surveyor_id === me.id) ||
    (p.status === 'pricing' && ['ins_underwriter', 'ins_branch_mgr'].includes(r)) ||
    (p.status === 'approval' && ((r === 'ins_branch_mgr' && p.approver_level === 'branch') || (r === 'ins_md' && p.approver_level === 'md'))) ||
    (p.status === 'payment' && r === 'ins_finance'));
  const C = D.claims.filter(c =>
    (c.status === 'reported' && ['ins_claims', 'ins_branch_mgr'].includes(r)) ||
    (c.status === 'survey' && c.surveyor_id === me.id) ||
    (c.status === 'assessment' && ['ins_claims', 'ins_branch_mgr'].includes(r)) ||
    (c.status === 'approval' && ((r === 'ins_branch_mgr' && c.approver_level !== 'md') || r === 'ins_md')) ||
    (c.status === 'payment' && r === 'ins_finance'));
  return { P, C };
}

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'ins_inbox');
  if (ctx.insOpen) return ctx.insOpen.t === 'c' ? claimDetail(ctx, ctx.insOpen.id) : policyDetail(ctx, ctx.insOpen.id);
  const me = D.me, my = mine(me);
  const act = D.policies.filter(p => p.status === 'active');
  const late = D.policies.filter(p => p.late).length;
  const openC = D.claims.filter(c => !['paid', 'rejected'].includes(c.status));
  const tabs = [['todo', `مهامي (${my.P.length + my.C.length})`], ['pol', 'الوثائق'], ['clm', `المطالبات (${openC.length})`],
    ...(['ins_md', 'ins_branch_mgr', 'ins_finance'].includes(me.role) ? [['dash', 'لوحة الشركة']] : []), ...(me.md ? [['prod', 'المنتجات والأسعار']] : [])];
  const tab = tabs.some(t => t[0] === ctx.insTab) ? ctx.insTab : 'todo';
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(D.org.name)}</h1>
      <p>${ROLE_IC[me.role] || ''} ${esc(me.role_title)} — ${esc(me.branch || 'الإدارة العامة')}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظارك', `<span class="num">${my.P.length + my.C.length}</span>`, `${my.P.length} وثيقة · ${my.C.length} مطالبة`, true)}
      ${kpi('قيد الإصدار', `<span class="num">${D.policies.filter(p => ['new', 'survey', 'pricing', 'approval', 'payment'].includes(p.status)).length}</span>`, late ? `<span style="color:var(--bad)">${late} متأخر عن المهلة</span>` : 'ضمن المهلة')}
      ${kpi('وثائق سارية', `<span class="num">${act.length}</span>`, `مبلغ التأمين ${(act.reduce((s, p) => s + Number(p.sum_insured || 0), 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })} مليون`)}
      ${kpi('مطالبات مفتوحة', `<span class="num">${openC.length}</span>`, `${D.claims.filter(c => c.status === 'paid').length} مسددة`)}
    </div>
    <div class="eng-tabs seg ins-tabs" role="tablist">${tabs.map(([k, t]) => `<label class="${tab === k ? 'on' : ''}"><input type="radio" name="it" value="${k}" ${tab === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('input[name=it]').forEach(r => r.onchange = () => { ctx.insTab = r.value; render(ctx); });
  const body = root.querySelector('[data-body]');
  if (tab === 'dash') return dashView(ctx, body);
  if (tab === 'prod') return prodView(ctx, body);
  if (tab === 'todo') {
    body.innerHTML = my.P.length + my.C.length ? `<div class="eng-cards">${my.P.map(pCard).join('')}${my.C.map(cCard).join('')}</div>`
      : `<div class="card empty">لا شيء بانتظارك الآن ✓<div class="small muted" style="margin-top:6px">${hint(me.role)}</div></div>`;
  } else if (tab === 'pol') {
    const f = ctx.insPF || '';
    const list = D.policies.filter(p => !f || p.status === f);
    body.innerHTML = `<div class="og-filter"><label class="chip ${!f ? 'on' : ''}"><input type="radio" name="pf" value="" ${!f ? 'checked' : ''}>الكل <b class="num">${D.policies.length}</b></label>
      ${Object.entries(POL_ST).filter(([k]) => D.policies.some(p => p.status === k)).map(([k, v]) => `<label class="chip ${f === k ? 'on' : ''}"><input type="radio" name="pf" value="${k}" ${f === k ? 'checked' : ''}>${esc(v[0])} <b class="num">${D.policies.filter(p => p.status === k).length}</b></label>`).join('')}</div>
      ${list.length ? `<div class="eng-cards">${list.map(pCard).join('')}</div>` : '<div class="card empty">لا وثائق — تصل طلبات التأمين آلياً حين يصل الطلب إلى أمر الشراء من المورد، أو بطلب من المصرف.</div>'}`;
    body.querySelectorAll('input[name=pf]').forEach(r => r.onchange = () => { ctx.insPF = r.value; render(ctx); });
  } else {
    body.innerHTML = D.claims.length ? `<div class="eng-cards">${D.claims.map(cCard).join('')}</div>` : '<div class="card empty">لا مطالبات.</div>';
  }
  body.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { ctx.insOpen = { t: 'p', id: b.dataset.p }; window.scrollTo(0, 0); render(ctx); });
  body.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { ctx.insOpen = { t: 'c', id: b.dataset.c }; window.scrollTo(0, 0); render(ctx); });
}

const hint = r => ({ ins_underwriter: 'تصلك طلبات التأمين الجديدة لفرعك، وما اكتملت معاينته للتسعير.', ins_surveyor: 'تصلك المعاينات المسندة إليك — للوثائق الجديدة ولأضرار المطالبات.',
  ins_branch_mgr: 'يصلك ما يحتاج اعتمادك ضمن سقف الفرع.', ins_md: 'يصلك ما يتجاوز سقف الفروع.', ins_claims: 'تصلك بلاغات الأضرار، وما اكتملت معاينته للتقدير.', ins_finance: 'تصلك الأقساط المستحقة والتعويضات المعتمدة للصرف.' }[r] || '');

const proj = a => a?.program === 'vet' ? '🩺 مشروع بيطري' : `☀️ منظومة شمسية <span class="num">${a?.kw ?? '—'}</span> kW`;
function pCard(p) {
  return `<button type="button" class="eng-card ins-card ${p.late ? 'late' : ''}" data-p="${p.id}">
    <div class="row"><b class="num">${esc(p.policy_no || p.code)}</b>${p.origin === 'renewal' ? '<span class="tag">تجديد</span>' : ''}${p.claims_open ? `<span class="tag bad-t">⚠ ${p.claims_open} مطالبة</span>` : ''}<span class="sp"></span>${polBadge(p.status)}</div>
    <div class="eng-proj">${proj(p.app)} · ${esc(p.insured || '')}</div>
    <div class="small muted">📍 ${esc(p.app?.governorate || '')} · ${esc(p.branch || '')} · المستفيد ${esc(p.beneficiary || '')}</div>
    <div class="row small"><span>مبلغ التأمين ${iqd(p.sum_insured)}</span><span class="sp"></span>${p.premium ? `<span>القسط ${iqd(p.premium)}</span>` : ''}</div>
    <div class="row small muted"><span>${p.status === 'survey' && p.surveyor ? `📍 ${esc(p.surveyor)}` : p.status === 'approval' ? (p.approver_level === 'md' ? 'اعتماد الإدارة العليا' : 'اعتماد مدير الفرع') : ''}</span><span class="sp"></span>
      ${p.status === 'active' ? `<span>حتى <span class="num">${esc(p.end)}</span></span>` : ['new', 'survey', 'pricing', 'approval'].includes(p.status) ? `<span class="${p.late ? 'bad-t' : ''}">${p.late ? '⚠ تجاوز المهلة' : `المهلة ${dt(p.due_at)}`}</span>` : `<span>${dt(p.updated_at)}</span>`}</div></button>`;
}
function cCard(c) {
  const ic = CAUSES.find(x => x[0] === c.cause)?.[2] || '⚠';
  return `<button type="button" class="eng-card ins-card clm" data-c="${c.id}">
    <div class="row"><b class="num">${esc(c.code)}</b><span class="tag">مطالبة</span><span class="sp"></span>${clmBadge(c.status)}</div>
    <div class="eng-proj">${ic} ${esc(c.cause_label)} · ${esc(c.insured || '')}</div>
    <div class="small muted">📍 ${esc(c.app?.governorate || '')} · ${esc(c.branch || '')} · وثيقة <span class="num">${esc(c.policy_no || '')}</span></div>
    <div class="row small"><span>الحادث ${esc(c.incident_date)}</span><span class="sp"></span>${c.payable != null ? `<span>التعويض ${iqd(c.payable)}</span>` : c.claimed ? `<span>المطلوب ${iqd(c.claimed)}</span>` : ''}</div></button>`;
}

const back = (ctx, root) => { root.querySelector('[data-back]').onclick = () => { ctx.insOpen = null; render(ctx); }; };
const surveyorSelect = (sel, branchId) => {
  const xs = (D.surveyors || []).filter(s => !branchId || !s.branch_id || s.branch_id === branchId);
  return `<select class="input" data-sv><option value="">تلقائي — الأقل انشغالاً في الفرع</option>${xs.map(s => `<option value="${s.id}" ${s.id === sel ? 'selected' : ''}>${esc(s.name)} (${s.open} مفتوحة)</option>`).join('')}</select>`;
};
const siteBlock = s => {
  const g = s.install_geo || s.site_geo;
  return `<dt>المؤمَّن له</dt><dd>${esc(s.borrower || '—')}${s.phone ? ` · <a href="tel:${esc(s.phone)}" class="num">📞 ${esc(s.phone)}</a>` : ''}</dd>
    <dt>العنوان</dt><dd>${esc(s.governorate || '')}${s.city ? ` — ${esc(s.city)}` : ''}${g ? `<div>📍 <a href="${mapsLink(g)}" target="_blank" rel="noopener">${s.install_geo ? 'موقع التركيب' : 'عنوان المقترض'} — افتح الخريطة للوصول</a></div>` : ''}</dd>
    <dt>المصرف</dt><dd>${esc(s.bank || '—')}${s.bank_branch ? ` — ${esc(s.bank_branch)}` : ''}</dd>`;
};
const logBlock = L => (L || []).length ? `<details class="card mb"><summary><b>سجل المعاملة</b> <span class="small muted">(${L.length})</span></summary>${L.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')} <span class="num">${esc(l.code || '')}</span> · ${dt(l.at)}</div></div>`).join('')}</details>` : '';
const confirmBox = (word, key) => `<div class="field"><label>للتأكيد اكتب: <b>${word}</b></label><input class="input" data-${key}><button type="button" class="btn ghost sm" style="margin-top:6px" data-fill-${key}>✍ ${word}</button></div>`;
const wireFill = (root, word, key) => { const b = root.querySelector(`[data-fill-${key}]`); if (b) b.onclick = () => { root.querySelector(`[data-${key}]`).value = word; }; };

// ───────── ملف الوثيقة ─────────
async function policyDetail(ctx, id) {
  const { sb, root } = ctx;
  let P;
  try { P = await rpc(sb, 'ins_policy', { p_id: id }); } catch (e) { ctx.insOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const s = P.site || {}, a = P.asset || {}, c = P.can, pr = P.product || {};
  const stepI = POL_STEPS.findIndex(x => x[0] === P.status);
  root.innerHTML = `
    <button type="button" class="linkbtn eng-back" data-back>→ كل المعاملات</button>
    <div class="card mb eng-head">
      <div class="row"><h2 class="num" style="margin:0">${esc(P.policy_no || P.code)}</h2>${P.origin === 'renewal' ? '<span class="tag">تجديد</span>' : ''}<span class="sp"></span>${polBadge(P.status)}</div>
      ${stepI >= 0 ? `<div class="ins-steps">${POL_STEPS.map(([k, t], i) => `<span class="${i < stepI ? 'done' : i === stepI ? 'on' : ''}"><i>${i < stepI ? '✓' : i + 1}</i>${t}</span>`).join('')}</div>` : ''}
      <div class="eng-proj big">${a.program === 'vet' ? `🩺 ${esc(VET_TYPES[a.vet_type] || 'مشروع بيطري')}${a.title ? ` — ${esc(a.title)}` : ''}` : `☀️ منظومة شمسية <span class="num">${a.kw ?? '—'}</span> kW${a.offer ? ` — ${esc(a.offer)}` : ''}`}</div>
      <dl class="kv sm">${siteBlock(s)}
        <dt>المورد</dt><dd>${esc(s.supplier || a.supplier || '—')}</dd>
        <dt>الطلب</dt><dd><span class="num">${esc(P.app?.code)}</span> · المرحلة <span class="num">${s.stage}</span> ${esc(s.stage_name || '')}${s.audit_status ? ` · التدقيق الهندسي: ${esc({ conforming: 'مطابق', conditional: 'مطابق بملاحظات', non_conforming: 'غير مطابق', pending: 'بانتظار' }[s.audit_status] || s.audit_status)}` : ''}</dd>
        <dt>مبلغ التمويل</dt><dd>${iqd(s.amount)} · <span class="num">${s.term_months}</span> شهراً</dd>
        <dt>مبلغ التأمين</dt><dd>${iqd(P.sum_insured)}${P.premium ? ` · القسط ${iqd(P.premium)}` : ''}</dd>
        <dt>المستفيد الأول</dt><dd>${esc(P.beneficiary || '—')}</dd>
        <dt>الفرع</dt><dd>${esc(P.branch || '—')}${P.underwriter ? ` · الاكتتاب: ${esc(P.underwriter)}` : ''}</dd>
        ${P.origin_note ? `<dt>ملاحظة المصرف</dt><dd>${esc(P.origin_note)}</dd>` : ''}
        ${['new', 'survey', 'pricing', 'approval'].includes(P.status) ? `<dt>المهلة</dt><dd class="${P.late ? 'bad-t' : ''}">${dt(P.due_at)}${P.late ? ' — متأخر' : ''}</dd>` : ''}</dl>
    </div>
    <div data-act></div>
    ${P.survey ? `<div class="card mb"><h3>📍 المعاينة <span class="sp"></span>${badge(RISK[P.survey.risk] || ['—', 'muted'])}</h3><dl class="kv sm">
      <dt>المعاين</dt><dd>${esc(P.survey.by || '')} <span class="num">${esc(P.survey.code || '')}</span> · ${dt(P.survey.at)}</dd>
      ${P.survey.gps ? `<dt>الزيارة</dt><dd>📍 <a href="${mapsLink(P.survey.gps)}" target="_blank" rel="noopener">على الخريطة</a> · ±<span class="num">${P.survey.gps.acc}</span> م</dd>` : ''}
      ${(P.survey.checks || []).length ? `<dt>الفحص</dt><dd>${P.survey.checks.map(x => `<span class="tag">✓ ${esc(x)}</span>`).join(' ')}</dd>` : ''}
      ${P.survey.note ? `<dt>الملاحظات</dt><dd>${esc(P.survey.note)}</dd>` : ''}
      ${P.survey.photo ? `<dt>الصورة</dt><dd><button type="button" class="linkbtn" data-ph="${P.survey.photo}">📷 عرض</button></dd>` : ''}</dl></div>` : ''}
    ${P.status === 'active' || P.issued_at ? `<div class="card mb eng-final conforming"><div class="eng-big conforming"><span>✓</span><div><small>وثيقة صادرة</small><b class="num">${esc(P.policy_no)}</b></div></div>
      <dl class="kv sm"><dt>المدة</dt><dd><span class="num">${esc(P.start)}</span> ← <span class="num">${esc(P.end)}</span></dd>
        <dt>الأخطار المغطاة</dt><dd>${(P.coverages || []).filter(x => x.on).map(x => `<span class="tag">${esc(x.label)}</span>`).join(' ')}</dd>
        <dt>التحمّل</dt><dd><span class="num">${P.deductible_pct}%</span> من كل مطالبة</dd>
        <dt>اعتمدها</dt><dd>${esc(P.approved_by || '')} <span class="num">${esc(P.approved_code || '')}</span> · ${dt(P.approved_at)}</dd>
        <dt>القسط</dt><dd>وصل <span class="num">${esc(P.paid_ref || '')}</span> · ${esc(P.paid_by || '')} · ${dt(P.paid_at)}</dd>
        ${P.seal ? `<dt>البصمة</dt><dd class="num small" dir="ltr" style="word-break:break-all">${esc(P.seal)}</dd>` : ''}</dl></div>` : ''}
    ${P.close_reason ? `<div class="notice warn mb"><b>${P.status === 'declined' ? 'سبب الاعتذار' : 'سبب الإلغاء'}:</b> ${esc(P.close_reason)}</div>` : ''}
    ${(P.claims || []).length ? `<div class="card mb"><h3>المطالبات على الوثيقة</h3>${P.claims.map(x => `<button type="button" class="ins-crow linkrow" data-c="${x.id}"><div><b class="num">${esc(x.code)}</b> · ${esc(x.cause_label)}<div class="small muted">${esc(x.incident_date)}</div></div><span class="sp"></span>${clmBadge(x.status)}</button>`).join('')}</div>` : ''}
    ${(P.history || []).length ? `<div class="card mb"><h3>وثائق أخرى على المشروع نفسه</h3>${P.history.map(x => `<button type="button" class="ins-crow linkrow" data-p="${x.id}"><span class="num">${esc(x.policy_no || x.code)}</span><span class="sp"></span>${polBadge(x.status)}</button>`).join('')}</div>` : ''}
    ${logBlock(P.log)}`;
  back(ctx, root);
  root.querySelectorAll('[data-ph]').forEach(b => b.onclick = () => insPhoto(sb, b.dataset.ph));
  root.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { ctx.insOpen = { t: 'c', id: b.dataset.c }; window.scrollTo(0, 0); render(ctx); });
  root.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { ctx.insOpen = { t: 'p', id: b.dataset.p }; window.scrollTo(0, 0); render(ctx); });
  const box = root.querySelector('[data-act]');
  const run = async (p, okTitle, msg) => {
    try {
      const r = await rpc(sb, 'ins_policy_act', { p_id: P.id, p });
      await resultScreen({ ok: true, title: okTitle(r), ref: r.policy_no || r.code || P.code, msg: msg ? msg(r) : '', chips: r.sent || [], seal: r.seal || '' });
      if (r.status === 'payment' && p.action === 'renew' && r.id) { ctx.insOpen = { t: 'p', id: r.id }; }
      render(ctx); return true;
    } catch (er) { resultScreen({ ok: false, title: 'لم يُنفَّذ الإجراء', msg: cleanErr(er), ref: P.code }); return false; }
  };

  // الاكتتاب: الاستلام
  if (c.accept) {
    box.innerHTML = `<div class="card mb ins-act"><h3>📝 استلام طلب التأمين</h3>
      <p class="small muted" style="margin-top:0">${P.needs_survey ? `مبلغ التأمين يتجاوز حد المعاينة (${iqd(pr.survey_above)})${pr.survey_above === 0 ? '' : ''} — المعاينة في الموقع إلزامية.` : 'المبلغ دون حد المعاينة — يمكنك التسعير مباشرة، أو طلب معاينة إن رأيت ذلك.'}</p>
      ${P.needs_survey ? '' : '<label class="check"><input type="checkbox" data-want> أطلب معاينة في الموقع رغم ذلك</label>'}
      <div class="field" data-svw ${P.needs_survey ? '' : 'hidden'}><label>المعاين</label>${surveyorSelect('', P.branch_id)}</div>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn cyan big-btn" data-go>${P.needs_survey ? '📍 إحالة للمعاينة' : '✓ استلام والتسعير الآن'}</button><span class="sp"></span><button class="btn ghost sm" data-dec>اعتذار عن التأمين</button></div></div>`;
    const want = box.querySelector('[data-want]');
    if (want) want.onchange = () => { box.querySelector('[data-svw]').hidden = !want.checked; box.querySelector('[data-go]').textContent = want.checked ? '📍 إحالة للمعاينة' : '✓ استلام والتسعير الآن'; };
    box.querySelector('[data-go]').onclick = e => { e.target.disabled = true;
      const sv = P.needs_survey || want?.checked;
      run({ action: 'accept', survey: !!want?.checked, surveyor: sv ? box.querySelector('[data-sv]').value || null : null }, r => r.status === 'survey' ? `أُحيل للمعاينة — ${r.surveyor}` : 'استُلم الطلب — سعّره الآن', r => r.status === 'survey' ? 'وصل المعاين إشعار. يثبّت زيارته في الموقع ثم يسجّل المعاينة.' : '').then(ok => { if (!ok) e.target.disabled = false; }); };
    box.querySelector('[data-dec]').onclick = () => declineForm(ctx, P);
    return;
  }
  // المعاينة في الموقع
  if (c.survey) return surveyPanel(ctx, P, box, false);
  // التسعير
  if (c.price) return pricePanel(ctx, P, box, run);
  // الاعتماد
  if (c.approve) {
    box.innerHTML = `<div class="card mb ins-act"><h3>${P.approver_level === 'md' ? '🏛 اعتماد الإدارة العليا (فوق سقف الفرع)' : '🏢 اعتماد مدير الفرع'}</h3>
      <div class="ins-quote"><div><small>القسط السنوي</small><b>${iqd(P.premium)}</b></div><div><small>مبلغ التأمين</small><b>${iqd(P.sum_insured)}</b></div><div><small>النسبة · التحمّل</small><b><span class="num">${P.rate_pct}%</span> · <span class="num">${P.deductible_pct}%</span></b></div></div>
      <div class="small" style="margin:8px 0">${(P.coverages || []).filter(x => x.on).map(x => `<span class="tag">✓ ${esc(x.label)}</span>`).join(' ')}</div>
      ${P.survey ? `<p class="small">المعاينة: الخطر ${badge(RISK[P.survey.risk])}${P.survey.note ? ` — ${esc(P.survey.note)}` : ''}</p>` : '<p class="small muted">بلا معاينة (دون حدها).</p>'}
      <div class="field"><label>ملاحظة (اختيارية)</label><input class="input" data-n></div>
      ${confirmBox('أعتمد الوثيقة', 'cf')}
      <button class="btn cyan block big-btn" data-ok>اعتماد الوثيقة وإبلاغ المصرف بالقسط</button>
      <div class="row mt" style="gap:8px"><button class="btn ghost sm" data-ret>إعادة للتسعير</button><span class="sp"></span><button class="btn ghost sm" data-dec>اعتذار عن التأمين</button></div></div>`;
    wireFill(box, 'أعتمد الوثيقة', 'cf');
    box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true;
      run({ action: 'approve', confirm: box.querySelector('[data-cf]').value.trim(), note: box.querySelector('[data-n]').value.trim() }, () => 'اعتُمدت الوثيقة — بانتظار القسط', () => 'وصل المصرف إشعار بالقسط المستحق، ووصل الحسابات لتسجيل القبض.').then(ok => { if (!ok) e.target.disabled = false; }); };
    box.querySelector('[data-ret]').onclick = () => noteForm('إعادة للتسعير', 'اكتب ما يجب تعديله — يصل لموظف الاكتتاب.', 'إعادة', n => run({ action: 'return', note: n }, () => 'أُعيدت للتسعير'));
    box.querySelector('[data-dec]').onclick = () => declineForm(ctx, P);
    return;
  }
  // القسط ← الإصدار
  if (c.pay) {
    box.innerHTML = `<div class="card mb ins-act"><h3>💳 تسجيل القسط وإصدار الوثيقة</h3>
      <div class="ins-quote"><div><small>القسط المستحق</small><b>${iqd(P.premium)}</b></div><div><small>المستفيد الأول</small><b style="font-size:14px">${esc(P.beneficiary || '')}</b></div></div>
      <div class="field mt"><label>رقم وصل القبض أو الحوالة ★</label><input class="input" data-ref dir="ltr" placeholder="RCPT-…"></div>
      <button class="btn cyan block big-btn" data-ok>تأكيد القبض وإصدار الوثيقة</button></div>`;
    box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true;
      run({ action: 'pay', ref: box.querySelector('[data-ref]').value.trim() }, r => `صدرت الوثيقة ${r.policy_no}`, r => `سارية من ${r.start} إلى ${r.end}، خُتمت بالبصمة وسُجلت في ملف الطلب.`).then(ok => { if (!ok) e.target.disabled = false; }); };
    if (c.cancel) box.insertAdjacentHTML('beforeend', '<div class="row mb"><span class="sp"></span><button class="btn ghost sm" data-cancel>إلغاء الوثيقة</button></div>');
  }
  if (c.reassign && !c.survey) {
    box.innerHTML = `<div class="card mb ins-act"><h3>📍 المعاينة لدى ${esc(P.surveyor || '')}</h3><div class="field"><label>تغيير المعاين</label>${surveyorSelect(P.surveyor_id, P.branch_id)}</div>
      <div class="row"><button class="btn ghost sm" data-rs>حفظ المعاين</button><span class="sp"></span><button class="btn ghost sm" data-dec>اعتذار عن التأمين</button></div></div>`;
    box.querySelector('[data-rs]').onclick = () => run({ action: 'reassign', surveyor: box.querySelector('[data-sv]').value || null }, r => `أُسندت المعاينة إلى ${r.surveyor}`);
    box.querySelector('[data-dec]').onclick = () => declineForm(ctx, P);
  }
  if (c.claim || c.renew || (c.cancel && !c.pay)) {
    box.insertAdjacentHTML('beforeend', `<div class="card mb ins-act"><div class="row" style="gap:8px;flex-wrap:wrap">
      ${c.claim ? '<button class="btn warn" data-claim>⚠ تسجيل بلاغ ضرر</button>' : ''}${c.renew ? '<button class="btn cyan" data-renew>↻ تجديد الوثيقة سنة</button>' : ''}<span class="sp"></span>${c.cancel ? '<button class="btn ghost sm" data-cancel>إلغاء الوثيقة</button>' : ''}</div>
      ${c.renew ? '<p class="small muted" style="margin:8px 0 0">يُفتح التجديد قبل 30 يوماً من النهاية: وثيقة جديدة بالشروط نفسها تبدأ من نهاية الحالية، بانتظار القسط.</p>' : ''}</div>`);
  }
  const cl = box.querySelector('[data-claim]'); if (cl) cl.onclick = () => claimForm(ctx, { id: P.app.id }, () => render(ctx));
  const rn = box.querySelector('[data-renew]'); if (rn) rn.onclick = e => { e.target.disabled = true; run({ action: 'renew' }, r => `فُتح التجديد ${r.code}`, () => 'وصل المصرف إشعار بقسط التجديد.'); };
  const cn = box.querySelector('[data-cancel]'); if (cn) cn.onclick = () => noteForm('إلغاء الوثيقة', 'اكتب سبب الإلغاء (مثل السداد المبكر للقرض) — يصل للمصرف.', 'إلغاء الوثيقة', n => run({ action: 'cancel', note: n }, () => 'أُلغيت الوثيقة'), 'bad');
}

function noteForm(title, hint, okLabel, fn, kind = 'warn') {
  const m = modal(`<h3>${esc(title)}</h3><p class="muted small">${esc(hint)}</p><div class="field"><textarea class="input" rows="3" data-n></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn ${kind}" data-y>${esc(okLabel)}</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-y]').onclick = async e => {
    const n = m.el.querySelector('[data-n]').value.trim();
    if (n.length < 5) return toast('اكتب السبب بوضوح', 'bad');
    e.target.disabled = true; m.close(); await fn(n);
  };
}
function declineForm(ctx, P) {
  noteForm('اعتذار عن تأمين المشروع', 'اكتب السبب — يصل للمصرف، ويمكنه طلب التأمين من شركة أخرى.', 'اعتذار', async n => {
    try { await rpc(ctx.sb, 'ins_policy_act', { p_id: P.id, p: { action: 'decline', note: n } }); await resultScreen({ ok: true, title: 'سُجّل الاعتذار وأُبلغ المصرف', ref: P.code }); ctx.insOpen = null; render(ctx); }
    catch (er) { resultScreen({ ok: false, title: 'لم يُسجَّل', msg: cleanErr(er) }); }
  }, 'bad');
}

// المعاينة (للوثيقة أو للمطالبة)
const CHECKS = ['التركيب ثابت ومحكم', 'التأريض والحماية الكهربائية موجودة', 'الموقع محمي من السرقة', 'لا مصادر حريق قريبة', 'مطابق لما في الطلب'];
function surveyPanel(ctx, X, box, isClaim) {
  const st = { gps: null, photo: null, risk: '' };
  box.innerHTML = `<div class="card mb ins-act"><h3>📍 ${isClaim ? 'معاينة الضرر في الموقع' : 'المعاينة في الموقع'}</h3>
    <div class="eng-visit" data-gpsbox><b>١. ثبّت موقعك وأنت في مكان المشروع</b><p class="small muted" style="margin:4px 0 10px">لا تُقبل المعاينة دون موقع بدقة ±150 م أو أفضل.</p><button class="btn cyan big-btn" data-gps>📍 ثبّت موقعي الآن</button></div>
    ${isClaim ? `<div class="field mt"><label>تقدير كلفة الإصلاح أو الاستبدال (د.ع) ★</label><input class="input" data-est inputmode="numeric" dir="ltr" value="${fmt(X.claimed)}"></div>
      <label class="check"><input type="checkbox" data-cov checked> الضرر من الأخطار المغطاة بالوثيقة</label>`
      : `<label class="lbl mt">٢. درجة الخطر</label><div class="ins-risk">${Object.entries(RISK).map(([k, v]) => `<button type="button" class="ins-r ${k}" data-rk="${k}">${esc(v[0])}</button>`).join('')}</div>
      <label class="lbl">ما تحققت منه</label><div class="chips">${CHECKS.map(t => `<label class="chip"><input type="checkbox" value="${esc(t)}">${esc(t)}</label>`).join('')}</div>`}
    <div class="field"><label>${isClaim ? 'وصف الضرر كما رأيته ★' : 'الملاحظات'}</label><textarea class="input" rows="2" data-note></textarea></div>
    <div class="eng-photo" data-phbox><button type="button" class="btn ${isClaim ? 'cyan' : 'ghost'} block" data-cam>📷 ${isClaim ? 'صوّر الضرر (إلزامي)' : 'صورة الموقع (إلزامية عند الخطر العالي)'}</button></div>
    <button class="btn ok block big-btn" data-save>حفظ المعاينة</button></div>`;
  box.querySelectorAll('.chips input').forEach(i => i.onchange = () => i.closest('.chip').classList.toggle('on', i.checked));
  box.querySelectorAll('[data-rk]').forEach(b => b.onclick = () => { st.risk = b.dataset.rk; box.querySelectorAll('[data-rk]').forEach(x => x.classList.toggle('on', x === b)); });
  box.querySelector('[data-gps]').onclick = async () => {
    const { gpsDialog } = await import('../geo.js');
    const g = await gpsDialog({ title: 'تثبيت زيارة الموقع', hint: 'قف في مكان المشروع أو بجانب المنظومة.', want: 25, accMax: 150 });
    if (!g) return;
    st.gps = g;
    box.querySelector('[data-gpsbox]').classList.add('ok');
    box.querySelector('[data-gpsbox]').innerHTML = `<div class="row"><span class="eng-pin">📍</span><div><b>ثُبّت موقعك</b><div class="small muted">دقة ±<span class="num">${Math.round(g.acc)}</span> م</div></div></div>`;
  };
  box.querySelector('[data-cam]').onclick = async () => {
    const { cameraCapture } = await import('../capture.js');
    const c = await cameraCapture({ title: isClaim ? 'صورة الضرر' : 'صورة الموقع', hint: '', ratio: 0.75 });
    if (!c) return;
    if (!c.meta?.live) return toast('تُلتقط الصورة بالكاميرا مباشرة', 'bad');
    st.photo = c.data;
    box.querySelector('[data-phbox]').innerHTML = `<div class="eng-thumb"><img src="${c.data}" alt=""><span>✓ الصورة جاهزة</span></div>`;
  };
  box.querySelector('[data-save]').onclick = async e => {
    if (!st.gps) return toast('ثبّت موقعك أولاً', 'bad');
    const note = box.querySelector('[data-note]').value.trim();
    e.target.disabled = true;
    try {
      if (isClaim) {
        await rpc(ctx.sb, 'ins_claim_act', { p_id: X.id, p: { action: 'survey', gps: st.gps, photo: st.photo, note, estimate: money(box.querySelector('[data-est]').value), covered: box.querySelector('[data-cov]').checked } });
      } else {
        await rpc(ctx.sb, 'ins_policy_act', { p_id: X.id, p: { action: 'survey', gps: st.gps, photo: st.photo, note, risk: st.risk, checks: [...box.querySelectorAll('.chips input:checked')].map(i => i.value) } });
      }
      await resultScreen({ ok: true, title: 'حُفظت المعاينة', ref: X.code, msg: isClaim ? 'وصلت لموظف المطالبات للتقدير.' : 'وصلت لموظف الاكتتاب للتسعير.' });
      ctx.insOpen = null; render(ctx);
    } catch (er) { resultScreen({ ok: false, title: 'لم تُحفظ المعاينة', msg: cleanErr(er), ref: X.code }); e.target.disabled = false; }
  };
}

function pricePanel(ctx, P, box, run) {
  const pr = P.product;
  box.innerHTML = `<div class="card mb ins-act"><h3>🧮 التسعير</h3>
    <div class="grid g3" style="gap:12px">
      <div class="field"><label>مبلغ التأمين (د.ع)</label><input class="input" data-sum inputmode="numeric" dir="ltr" value="${fmt(P.sum_insured)}"></div>
      <div class="field"><label>نسبة القسط السنوي %</label><input class="input" data-rate inputmode="decimal" dir="ltr" value="${P.rate_pct ?? pr.rate_pct}"></div>
      <div class="field"><label>التحمّل من كل مطالبة %</label><input class="input" data-ded inputmode="decimal" dir="ltr" value="${P.deductible_pct ?? pr.deductible_pct}"></div></div>
    <label class="lbl">الأخطار المغطاة</label><div class="chips" data-cov>${(P.coverages || pr.coverages || []).map(x => `<label class="chip ${x.on ? 'on' : ''}"><input type="checkbox" value="${esc(x.k)}" data-l="${esc(x.label)}" ${x.on ? 'checked' : ''}>${esc(x.label)}</label>`).join('')}</div>
    <div class="ins-quote mt" data-q></div>
    <div class="field"><label>ملاحظة (اختيارية)</label><input class="input" data-n></div>
    <button class="btn cyan block big-btn" data-ok>إرسال للاعتماد</button>
    <div class="row mt"><span class="sp"></span><button class="btn ghost sm" data-dec>اعتذار عن التأمين</button></div></div>`;
  const q = () => {
    const sum = Number(money(box.querySelector('[data-sum]').value)), rate = Number(box.querySelector('[data-rate]').value), prem = Math.max(pr.min_premium, Math.round(sum * rate / 100));
    const md = sum > pr.branch_limit;
    box.querySelector('[data-q]').innerHTML = `<div><small>القسط السنوي</small><b>${iqd(prem)}</b></div><div><small>يعتمده</small><b style="font-size:14px">${md ? '🏛 الإدارة العليا' : '🏢 مدير الفرع'}</b></div>
      <div class="small muted" style="grid-column:1/-1">الحد الأدنى للقسط ${iqd(pr.min_premium)} · سقف الفرع ${iqd(pr.branch_limit)}</div>`;
  };
  box.querySelector('[data-sum]').oninput = e => { const v = money(e.target.value); e.target.value = fmt(v); q(); };
  box.querySelector('[data-rate]').oninput = q;
  box.querySelectorAll('[data-cov] input').forEach(i => i.onchange = () => i.closest('.chip').classList.toggle('on', i.checked));
  q();
  box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true;
    const cov = [...box.querySelectorAll('[data-cov] input')].map(i => ({ k: i.value, label: i.dataset.l, on: i.checked }));
    run({ action: 'price', sum_insured: money(box.querySelector('[data-sum]').value), rate_pct: box.querySelector('[data-rate]').value, deductible_pct: box.querySelector('[data-ded]').value, coverages: cov, note: box.querySelector('[data-n]').value.trim() },
      r => `أُرسلت للاعتماد — القسط ${Number(r.premium).toLocaleString('en-US')} د.ع`, r => r.level === 'md' ? 'المبلغ فوق سقف الفرع، فوصلت للإدارة العليا.' : 'وصلت لمدير الفرع للاعتماد.').then(ok => { if (!ok) e.target.disabled = false; }); };
  box.querySelector('[data-dec]').onclick = () => declineForm(ctx, P);
}

// ───────── ملف المطالبة ─────────
async function claimDetail(ctx, id) {
  const { sb, root } = ctx;
  let C;
  try { C = await rpc(sb, 'ins_claim', { p_id: id }); } catch (e) { ctx.insOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const p = C.policy, s = C.site || {}, c = C.can;
  const ic = CAUSES.find(x => x[0] === C.cause)?.[2] || '⚠';
  root.innerHTML = `
    <button type="button" class="linkbtn eng-back" data-back>→ كل المعاملات</button>
    <div class="card mb eng-head"><div class="row"><h2 class="num" style="margin:0">${esc(C.code)}</h2><span class="tag">مطالبة</span><span class="sp"></span>${clmBadge(C.status)}</div>
      <div class="eng-proj big">${ic} ${esc(C.cause_label)}</div>
      <dl class="kv sm"><dt>ما حدث</dt><dd>${esc(C.description || '')}</dd><dt>تاريخ الحادث</dt><dd>${esc(C.incident_date)}</dd>
        <dt>أبلغ</dt><dd>${esc(C.reported_side || '')} — ${esc(C.reported_by || '')} · ${dt(C.created_at)}</dd>
        ${C.claimed ? `<dt>المطلوب</dt><dd>${iqd(C.claimed)}</dd>` : ''}${siteBlock(s)}
        <dt>الوثيقة</dt><dd><button type="button" class="linkbtn num" data-p="${p.id}">${esc(p.policy_no || '')}</button> · مبلغ التأمين ${iqd(p.sum_insured)} · التحمّل <span class="num">${p.deductible_pct}%</span>${p.paid_before ? ` · صُرف سابقاً ${iqd(p.paid_before)}` : ''}</dd>
        <dt>المستفيد</dt><dd>${esc(p.beneficiary || '')}</dd></dl></div>
    <div data-act></div>
    ${C.survey ? `<div class="card mb"><h3>📍 معاينة الضرر</h3><dl class="kv sm"><dt>المعاين</dt><dd>${esc(C.survey.by || '')} · ${dt(C.survey.at)}</dd>
      ${C.survey.gps ? `<dt>الزيارة</dt><dd>📍 <a href="${mapsLink(C.survey.gps)}" target="_blank" rel="noopener">على الخريطة</a> · ±<span class="num">${C.survey.gps.acc}</span> م</dd>` : ''}
      <dt>التقدير</dt><dd>${iqd(C.survey.estimate)}${C.survey.covered === false ? ' · <b class="bad-t">رأى المعاين أنه خارج الأخطار المغطاة</b>' : ''}</dd><dt>الوصف</dt><dd>${esc(C.survey.note || '')}</dd>
      ${C.survey.photo ? `<dt>الصورة</dt><dd><button type="button" class="linkbtn" data-ph="${C.survey.photo}">📷 عرض</button></dd>` : ''}</dl></div>` : ''}
    ${C.payable != null ? `<div class="card mb"><h3>🧮 التقدير</h3><div class="ins-quote"><div><small>الضرر المقبول</small><b>${iqd(C.assessed)}</b></div><div><small>التحمّل</small><b>${iqd(C.deductible)}</b></div><div><small>التعويض</small><b>${iqd(C.payable)}</b></div></div>
      <p class="small muted">${esc(C.assessed_by || '')}${C.assess_note ? ` — ${esc(C.assess_note)}` : ''}${C.approved_by ? ` · اعتمده ${esc(C.approved_by)} ${dt(C.approved_at)}` : ''}</p></div>` : ''}
    ${C.status === 'paid' ? `<div class="card mb eng-final conforming"><div class="eng-big conforming"><span>✓</span><div><small>صُرف التعويض</small><b>${iqd(C.payable)}</b></div></div>
      <dl class="kv sm"><dt>إلى</dt><dd>${esc(C.paid_to || '')}</dd><dt>المرجع</dt><dd class="num">${esc(C.paid_ref || '')} · ${esc(C.paid_by || '')} · ${dt(C.paid_at)}</dd>
      ${C.seal ? `<dt>البصمة</dt><dd class="num small" dir="ltr" style="word-break:break-all">${esc(C.seal)}</dd>` : ''}</dl></div>` : ''}
    ${C.status === 'rejected' ? `<div class="notice warn mb"><b>سبب الرفض:</b> ${esc(C.decision_note || '')}</div>` : ''}
    ${logBlock(C.log)}`;
  back(ctx, root);
  root.querySelectorAll('[data-ph]').forEach(b => b.onclick = () => insPhoto(sb, b.dataset.ph));
  root.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { ctx.insOpen = { t: 'p', id: b.dataset.p }; window.scrollTo(0, 0); render(ctx); });
  const box = root.querySelector('[data-act]');
  const run = async (pp, title, msg) => {
    try { const r = await rpc(sb, 'ins_claim_act', { p_id: C.id, p: pp }); await resultScreen({ ok: true, title: title(r), ref: C.code, msg: msg ? msg(r) : '', chips: r.sent || [], seal: r.seal || '' }); render(ctx); return true; }
    catch (er) { resultScreen({ ok: false, title: 'لم يُنفَّذ الإجراء', msg: cleanErr(er), ref: C.code }); return false; }
  };
  const rejBtn = c.reject ? '<button class="btn ghost sm" data-rej>رفض المطالبة</button>' : '';
  if (c.assign) {
    box.innerHTML = `<div class="card mb ins-act"><h3>🧾 إحالة لمعاينة الضرر</h3><div class="field"><label>المعاين</label>${surveyorSelect(C.surveyor_id, C.branch_id)}</div>
      <button class="btn cyan block big-btn" data-go>📍 إحالة للمعاين</button><div class="row mt"><span class="sp"></span>${rejBtn}</div></div>`;
    box.querySelector('[data-go]').onclick = e => { e.target.disabled = true; run({ action: 'assign', surveyor: box.querySelector('[data-sv]').value || null }, r => `أُحيلت إلى ${r.surveyor}`).then(ok => { if (!ok) e.target.disabled = false; }); };
  } else if (c.survey) { surveyPanel(ctx, C, box, true); }
  else if (c.assess) {
    const est = C.survey?.estimate || C.claimed || '';
    box.innerHTML = `<div class="card mb ins-act"><h3>🧮 تقدير التعويض</h3>
      <div class="field"><label>مبلغ الضرر المقبول (د.ع)</label><input class="input" data-as inputmode="numeric" dir="ltr" value="${fmt(est)}"></div>
      <div class="ins-quote" data-q></div>
      <div class="field mt"><label>ملاحظة التقدير</label><input class="input" data-n placeholder="مثال: تُستبعد كلفة النقل"></div>
      <button class="btn cyan block big-btn" data-ok>إرسال للاعتماد</button><div class="row mt"><span class="sp"></span>${rejBtn}</div></div>`;
    const q = () => { const v = Math.min(Number(money(box.querySelector('[data-as]').value)), Math.max(0, p.sum_insured - (p.paid_before || 0))), d = Math.round(v * (p.deductible_pct || 0) / 100);
      box.querySelector('[data-q]').innerHTML = `<div><small>الضرر</small><b>${iqd(v)}</b></div><div><small>التحمّل <span class="num">${p.deductible_pct}%</span></small><b>${iqd(d)}</b></div><div><small>التعويض</small><b>${iqd(Math.max(0, v - d))}</b></div>
        <div class="small muted" style="grid-column:1/-1">${Math.max(0, v - d) > (p.branch_limit || 0) ? 'فوق سقف الفرع — يعتمده الإدارة العليا' : 'يعتمده مدير الفرع'}</div>`; };
    box.querySelector('[data-as]').oninput = e => { e.target.value = fmt(money(e.target.value)); q(); }; q();
    box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true; run({ action: 'assess', assessed: money(box.querySelector('[data-as]').value), note: box.querySelector('[data-n]').value.trim() }, r => `التعويض ${Number(r.payable).toLocaleString('en-US')} د.ع — بانتظار الاعتماد`).then(ok => { if (!ok) e.target.disabled = false; }); };
  } else if (c.approve) {
    box.innerHTML = `<div class="card mb ins-act"><h3>${C.approver_level === 'md' ? '🏛 اعتماد الإدارة العليا' : '🏢 اعتماد مدير الفرع'}</h3>
      <p>التعويض <b>${iqd(C.payable)}</b> إلى <b>${esc(p.beneficiary || '')}</b></p>${confirmBox('أعتمد التعويض', 'cf')}
      <button class="btn cyan block big-btn" data-ok>اعتماد التعويض</button><div class="row mt" style="gap:8px"><button class="btn ghost sm" data-ret>إعادة للتقدير</button><span class="sp"></span>${rejBtn}</div></div>`;
    wireFill(box, 'أعتمد التعويض', 'cf');
    box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true; run({ action: 'approve', confirm: box.querySelector('[data-cf]').value.trim() }, () => 'اعتُمد التعويض — بانتظار الصرف').then(ok => { if (!ok) e.target.disabled = false; }); };
    box.querySelector('[data-ret]').onclick = () => noteForm('إعادة للتقدير', 'اكتب ما يجب مراجعته.', 'إعادة', n => run({ action: 'return', note: n }, () => 'أُعيدت للتقدير'));
  } else if (c.pay) {
    box.innerHTML = `<div class="card mb ins-act"><h3>💳 صرف التعويض</h3><div class="ins-quote"><div><small>التعويض</small><b>${iqd(C.payable)}</b></div></div>
      <div class="field mt"><label>يُصرف إلى</label><input class="input" data-to value="${esc(p.beneficiary || '')}"></div>
      <div class="field"><label>رقم الحوالة أو الصك ★</label><input class="input" data-ref dir="ltr"></div>
      <button class="btn cyan block big-btn" data-ok>تأكيد الصرف</button></div>`;
    box.querySelector('[data-ok]').onclick = e => { e.target.disabled = true; run({ action: 'pay', ref: box.querySelector('[data-ref]').value.trim(), paid_to: box.querySelector('[data-to]').value.trim() }, r => `صُرف التعويض إلى ${r.paid_to}`, () => 'خُتم بالبصمة وسُجل في ملف الطلب، ووصل الإشعار للمصرف والمقترض.').then(ok => { if (!ok) e.target.disabled = false; }); };
  } else if (c.reject) box.innerHTML = `<div class="row mb"><span class="sp"></span>${rejBtn}</div>`;
  const rj = box.querySelector('[data-rej]');
  if (rj) rj.onclick = () => noteForm('رفض المطالبة', 'اكتب السبب (مثل: خارج الأخطار المغطاة) — يصل للمصرف والمقترض.', 'رفض المطالبة', n => run({ action: 'reject', note: n }, () => 'رُفضت المطالبة'), 'bad');
}

// ───────── لوحة الشركة ─────────
async function dashView(ctx, body) {
  body.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  let S;
  try { S = await rpc(ctx.sb, 'ins_dashboard'); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  const ratio = S.premiums ? Math.round(S.claims_paid / S.premiums * 100) : 0;
  body.innerHTML = `<div class="grid g4 mb">${kpi('وثائق سارية', `<span class="num">${S.active}</span>`, '')}${kpi('مبلغ التأمين القائم', `<span class="num">${(S.sum_insured / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`, '')}
      ${kpi('الأقساط المحصّلة', iqd(S.premiums), '')}${kpi('التعويضات المصروفة', iqd(S.claims_paid), `نسبة الخسارة <span class="num">${ratio}%</span>`)}</div>
    <div class="og-list">${S.branches.map(b => `<div class="card og-card"><div class="row"><b>🏢 ${esc(b.name)}</b><span class="sp"></span>${b.late ? badge([`${b.late} متأخرة`, 'bad']) : ''}</div>
      <div class="og-stats"><span>قيد الإصدار <b class="num">${b.pipeline}</b></span><span>سارية <b class="num">${b.active}</b></span><span>الموظفون <b class="num">${b.staff}</b></span></div>
      <div class="og-stats"><span>الأقساط ${iqd(b.premiums)}</span><span>التعويضات ${iqd(b.claims)}</span></div></div>`).join('') || '<div class="card empty">لا فروع.</div>'}</div>
    ${D.me.md ? '<p class="small muted">الفروع والموظفون تُدار من <a href="#team">«فريقي»</a>.</p>' : ''}`;
}

// ───────── المنتجات والأسعار (الإدارة العليا) ─────────
function prodView(ctx, body) {
  body.innerHTML = `<div class="card mb"><p class="small muted" style="margin:0">هذه الأسعار تُقترح آلياً على موظف الاكتتاب، ويمكنه تعديلها لكل وثيقة. <b>سقف الفرع</b>: ما يزيد مبلغ تأمينه عليه يصل للإدارة العليا للاعتماد. <b>حد المعاينة</b>: ما يزيد عليه يُعاين في الموقع إلزامياً (0 = كل الطلبات).</p></div>
    ${(D.products || []).map(x => `<form class="card mb ins-prod" data-id="${x.id}" novalidate><h3>${x.line === 'vet' ? '🩺' : '☀️'} <input class="input" name="name" value="${esc(x.name)}" style="flex:1"></h3>
      <div class="grid g3" style="gap:12px">
        <div class="field"><label>نسبة القسط السنوي %</label><input class="input" name="rate_pct" inputmode="decimal" dir="ltr" value="${x.rate_pct}"></div>
        <div class="field"><label>الحد الأدنى للقسط</label><input class="input" name="min_premium" inputmode="numeric" dir="ltr" value="${x.min_premium}"></div>
        <div class="field"><label>التحمّل %</label><input class="input" name="deductible_pct" inputmode="decimal" dir="ltr" value="${x.deductible_pct}"></div>
        <div class="field"><label>حد المعاينة الإلزامية</label><input class="input" name="survey_above" inputmode="numeric" dir="ltr" value="${x.survey_above}"></div>
        <div class="field"><label>سقف اعتماد الفرع</label><input class="input" name="branch_limit" inputmode="numeric" dir="ltr" value="${x.branch_limit}"></div>
        <label class="check" style="align-self:end"><input type="checkbox" name="active" ${x.active ? 'checked' : ''}> المنتج فعّال</label></div>
      <label class="lbl">الأخطار المغطاة افتراضياً</label><div class="chips">${(x.coverages || []).map(c => `<label class="chip ${c.on ? 'on' : ''}"><input type="checkbox" value="${esc(c.k)}" data-l="${esc(c.label)}" ${c.on ? 'checked' : ''}>${esc(c.label)}</label>`).join('')}</div>
      <div class="row mt"><span class="small muted">${x.updated_by ? `آخر تعديل: ${esc(x.updated_by)}` : ''}</span><span class="sp"></span><button class="btn cyan sm">حفظ</button></div></form>`).join('')}`;
  body.querySelectorAll('.chips input').forEach(i => i.onchange = () => i.closest('.chip').classList.toggle('on', i.checked));
  body.querySelectorAll('form[data-id]').forEach(f => f.onsubmit = async e => {
    e.preventDefault();
    const p = { id: f.dataset.id, name: f.name.value.trim(), active: f.active.checked, coverages: [...f.querySelectorAll('.chips input')].map(i => ({ k: i.value, label: i.dataset.l, on: i.checked })) };
    ['rate_pct', 'min_premium', 'deductible_pct', 'survey_above', 'branch_limit'].forEach(k => { p[k] = String(f[k].value).replace(/,/g, ''); });
    const b = f.querySelector('button'); b.disabled = true;
    try { await rpc(ctx.sb, 'ins_product_save', { p }); toast('حُفظت أسعار المنتج', 'ok'); D = await rpc(ctx.sb, 'ins_inbox'); }
    catch (er) { toast(cleanErr(er), 'bad'); }
    b.disabled = false;
  });
}
