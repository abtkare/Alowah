// بوابة نقابة الأطباء البيطريين
// الجلسة 60: معاملات الأعضاء تنتقل من قسم إلى قسم — العضوية والتسجيل (فرع المحافظة) ← التدقيق والسجلات ← الحسابات ← اعتماد النقيب
//            ← الهويات والطباعة ← شركة التوصيل المعتمدة. وسجل الأعضاء ومواعيد انتهاء هوياتهم. «فريقي» للنقيب ورؤساء الفروع.
// الجلسة 6: تأييد العضوية لمبادرة تمويل الأطباء البيطريين (تبويب «تأييد القروض») — باقٍ كما هو.
import { esc, num, dt, ago, badge, kpi, tabs, rpc, toast, cleanErr, modal, iqd, mapsLink, MEMBER_STATUS } from '../core.js';
import { SF_KIND, sfBadge, sfSteps, smBadge, dlvBadge, DEGREE, synCard, printCard } from '../syn-ui.js';

const ACT = { new: ['دُقّقت المستمسكات — أحِل', 'syn_reg'], audit: ['طابق السجل — أحِل', 'syn_audit'], finance: ['الرسوم مستوفاة — أحِل', 'syn_fin'],
  approval: ['اعتمد', 'syn_head'], print: ['اطبع الهوية وسلّمها لشركة التوصيل', 'syn_cards'] };
const DESK = { syn_head: 'النقيب — ترى كل المعاملات وتعتمد', syn_branch_head: 'رئيس الفرع — تعتمد تجديدات محافظتك', syn_reg: 'قسم العضوية والتسجيل — تدقق المستمسكات الواردة',
  syn_audit: 'قسم التدقيق والسجلات — تطابق البيانات مع سجل النقابة', syn_fin: 'قسم الحسابات — تتأكد من استيفاء الرسوم', syn_cards: 'قسم الهويات — تطبع الهوية وتسلّمها لشركة التوصيل',
  syndicate_officer: 'لجنة التسجيل — تأييد عضوية المقترضين في مبادرة التمويل' };

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  const X = await rpc(sb, 'syn_inbox');
  const files = X.files || [], mine = files.filter(f => f.mine), late = files.filter(f => f.late);
  const showLoans = ['syndicate_officer', 'syn_head', 'syn_reg'].includes(profile.role);
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'نقابة الأطباء البيطريين')}</h1><p>${esc(DESK[profile.role] || X.role_title)}${X.branch ? ` · <b>${esc(X.branch)}</b>` : ' · المقر العام'}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('في قسمك الآن', `<span class="num">${mine.length}</span>`, 'معاملات بانتظار إجرائك', true)}
      ${kpi('متأخرة', `<span class="num">${late.length}</span>`, 'تجاوزت مدة القسم')}
      ${kpi('أعضاء نافذون', `<span class="num">${num(X.counts?.active)}</span>`, `تنتهي خلال أسبوع: ${num(X.counts?.soon)}`)}
      ${kpi('هويات منتهية', `<span class="num">${num(X.counts?.expired)}</span>`, 'وصلهم تذكير التجديد')}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'inbox', label: 'وارد قسمي', count: mine.length }, { key: 'all', label: 'كل المعاملات' }, { key: 'members', label: 'سجل الأعضاء' },
    ...(showLoans ? [{ key: 'loans', label: 'تأييد قروض المبادرة' }] : []), { key: 'geo', label: '📍 خريطة المشاريع' }];
  ctx.synTab = defs.some(d => d.key === ctx.synTab) ? ctx.synTab : 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.synTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.synTab));

  const table = list => list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>المعاملة</th><th>الطبيب</th><th>الفرع</th><th>الحالة</th><th>الوصول</th></tr></thead><tbody>
    ${list.map(f => `<tr class="click" data-f="${f.id}"><td>${SF_KIND[f.kind]?.[1] || ''} <b>${esc(f.kind_label)}</b><div class="small num muted">${esc(f.code)}</div></td>
      <td><b>${esc(f.name)}</b>${f.membership_no ? `<div class="small num muted">عضوية ${esc(f.membership_no)}</div>` : ''}</td><td>${esc(f.governorate)}</td>
      <td>${sfBadge(f.status)}${f.mine ? ' <span class="tag">لديك</span>' : ''}${f.late ? ' <span class="tag bad-t">متأخرة</span>' : ''}${f.ship ? `<div class="small muted">${esc(f.ship.courier)} · ${esc(f.ship.code)}</div>` : ''}</td>
      <td class="small muted">${f.submitted_at ? ago(f.submitted_at) : '—'}</td></tr>`).join('')}</tbody></table></div>`
    : '<div class="empty">لا معاملات هنا الآن.</div>';

  async function show(k) {
    if (k === 'geo') return import('../projects-map.js').then(m => m.mountProjectsMap(ctx, body));   // الجلسة 59
    if (k === 'loans') return loansTab(ctx, body);
    if (k === 'members') return membersTab(ctx, body);
    if (k === 'inbox') {
      body.innerHTML = `<div class="notice">المعاملات التي تنتظر قسمك. افتح المعاملة، راجع المستمسكات، ثم «أحِل» إلى القسم التالي — أو أعدها لقسم سابق أو للطبيب بسبب مكتوب.</div><div class="card flush">${table(mine)}</div>`;
    } else {
      const F = ctx.synF || 'open';
      const FL = { open: ['قيد الإنجاز', f => !['done', 'rejected', 'cancelled'].includes(f.status)], ship: ['مع التوصيل', f => f.status === 'ship'], done: ['أُنجزت', f => f.status === 'done'], rejected: ['مرفوضة', f => f.status === 'rejected'], all: ['الكل', () => true] };
      body.innerHTML = `<div class="chips mb">${Object.entries(FL).map(([key, [t, fn]]) => `<button type="button" class="chip ${F === key ? 'on' : ''}" data-fl="${key}">${t} <span class="num">${files.filter(fn).length}</span></button>`).join('')}</div>
        <div class="card flush">${table(files.filter(FL[F][1]))}</div>`;
      body.querySelectorAll('[data-fl]').forEach(b => b.onclick = () => { ctx.synF = b.dataset.fl; show('all'); });
    }
    body.querySelectorAll('[data-f]').forEach(tr => tr.onclick = () => openFile(ctx, tr.dataset.f));
  }
  show(ctx.synTab);
  if (ctx.synOpen) { const id = ctx.synOpen; ctx.synOpen = null; openFile(ctx, id); }   // من جرس الإشعارات
}

// ───────── المعاملة ─────────
async function openFile(ctx, id) {
  let R;
  try { R = await rpc(ctx.sb, 'syn_file', { p_id: id }); } catch (e) { return toast(cleanErr(e), 'bad'); }
  const f = R.file, m = R.member, d = f.data || {}, dl = f.delivery;
  const docs = R.docs || [];
  const act = ACT[f.status];
  const isAudAct = f.kind === 'activate' && f.status === 'audit' && R.can;
  const md = modal(`<h3>${SF_KIND[f.kind]?.[1] || ''} ${esc(f.kind_label)} <span class="num small muted">${esc(f.code)}</span> ${sfBadge(f.status)}</h3>
    ${sfSteps(f)}
    <div class="grid g2" style="gap:14px;align-items:start">
      <div>${synCard(m, { photo: m.photo, card: R.card ? { card_no: R.card.card_no, verify_code: R.card.verify_code } : null })}
        ${(R.dup || []).length ? `<div class="card mt un-alert bad" style="padding:10px"><b>⚠️ تطابق في السجل</b>${R.dup.map(x => `<div class="small">${esc(x.name)} · عضوية <span class="num">${esc(x.no || '—')}</span> · ${esc(x.gov)} · ${smBadge(x.status)}</div>`).join('')}</div>` : ''}</div>
      <dl class="kv sm">
        ${f.kind === 'activate' ? `<dt>رقم العضوية (كتبه الطبيب)</dt><dd class="num">${esc(d.membership_no || '—')}</dd><dt>هوية النقابة</dt><dd>إصدار <span class="num">${esc(d.issued_on || '—')}</span> · انتهاء <span class="num">${esc(d.valid_until || '—')}</span></dd>` : ''}
        <dt>الطبيب</dt><dd><b>${esc(m.full_name)}</b> · <span class="num" dir="ltr">${esc(m.phone || '')}</span></dd>
        <dt>الرقم الوطني</dt><dd class="num" dir="ltr">${esc(m.national_id ? '••••••••' + String(m.national_id).slice(-4) : '—')}</dd>
        <dt>الكلية</dt><dd>${esc(m.college || '—')}${m.graduation_year ? ` — <span class="num">${esc(m.graduation_year)}</span>` : ''}</dd>
        <dt>الشهادة</dt><dd>${esc(DEGREE[m.degree] || '—')}${m.specialty ? ` · ${esc(m.specialty)}` : ''}</dd><dt>فرع النقابة</dt><dd>${esc(m.governorate)}</dd>
        ${f.fee ? `<dt>الرسوم</dt><dd>${iqd(f.fee)} ${f.fee_paid_at ? badge(['مدفوعة إلكترونياً', 'ok']) : badge(['غير مدفوعة', 'bad'])}${f.fee_ref ? `<div class="small num muted" dir="ltr">${esc(f.fee_ref)}</div>` : ''}</dd>` : ''}
        ${dl ? `<dt>الاستلام</dt><dd>${esc(dl.address)}${dl.geo ? ` · <a href="${mapsLink(dl.geo)}" target="_blank" rel="noopener">📍 الخريطة</a>` : ''}<div class="small num" dir="ltr">${esc(dl.phone || '')}</div></dd>` : ''}
        ${f.return_note ? `<dt>آخر إعادة</dt><dd>${esc(f.return_note)}</dd>` : ''}${f.reason ? `<dt>سبب الرفض</dt><dd class="bad-t">${esc(f.reason)}</dd>` : ''}
      </dl></div>
    <h4 style="margin:14px 0 6px">المستمسكات ${(R.missing || []).length ? `<span class="badge bad">ناقص: ${esc(R.missing.join('، '))}</span>` : ''}</h4>
    <div class="un-grid">${docs.map(x => `<button type="button" class="un-ph" data-doc="${x.id}">${x.thumb ? `<img src="${x.thumb}" alt="">` : '<div style="height:110px;display:grid;place-items:center">📄</div>'}<span>${esc(x.label)}</span></button>`).join('') || '<p class="small muted">لا مستمسكات.</p>'}</div>
    ${R.card ? `<div class="card mt"><div class="row"><b>🪪 الهوية ${esc(R.card.card_no)}</b><span class="sp"></span><button type="button" class="btn ghost sm" data-print>🖨 طباعة / إعادة طباعة</button></div>
      ${R.ship ? `<div class="small mt">${esc(R.ship.courier)} · شحنة <span class="num">${esc(R.ship.code)}</span> ${dlvBadge(R.ship.status)}${R.ship.agent ? ` · المندوب ${esc(R.ship.agent)}` : ''}</div>` : ''}</div>` : ''}
    ${R.can && act ? `<div class="card mt"><h4 style="margin:0 0 8px">إجراء قسمك</h4>
      ${isAudAct ? `<p class="small muted" style="margin-top:0">طابق مع سجل النقابة. صحّح إن اختلف ما كتبه الطبيب عن السجل:</p><div class="grid g3" style="gap:10px">
        <div class="field"><label>رقم العضوية</label><input class="input" data-fx="membership_no" dir="ltr" value="${esc(d.membership_no || '')}"></div>
        <div class="field"><label>تاريخ الإصدار</label><input class="input" type="date" data-fx="issued_on" dir="ltr" value="${esc(d.issued_on || '')}"></div>
        <div class="field"><label>تاريخ الانتهاء</label><input class="input" type="date" data-fx="valid_until" dir="ltr" value="${esc(d.valid_until || '')}"></div></div>` : ''}
      ${f.status === 'print' ? `<div class="field"><label>شركة التوصيل المعتمدة ★</label><select class="input" data-cr>${(R.couriers || []).map(c => `<option value="${c.id}">${esc(c.name)}${(c.covers || []).length ? ` — ${esc(c.covers.join('، '))}` : ' — كل المحافظات'}${c.agents ? '' : ' (بلا مندوب بعد)'}</option>`).join('') || '<option value="">لا توجد شركة توصيل معتمدة</option>'}</select></div>` : ''}
      <div class="field"><label>ملاحظة (إلزامية للإعادة والرفض)</label><textarea class="input" rows="2" data-n></textarea></div>
      <div class="row" style="gap:8px;flex-wrap:wrap">${['new', 'audit', 'approval'].includes(f.status) ? '<button class="btn bad" data-a="reject">رفض</button>' : ''}
        ${['new', 'audit'].includes(f.status) ? '<button class="btn warn" data-a="return">إعادة للطبيب للاستكمال</button>' : ''}
        ${f.prev ? `<button class="btn ghost" data-a="back">إعادة إلى ${esc(f.prev_label)}</button>` : ''}<span class="sp"></span>
        <button class="btn ok" data-a="forward">${esc(act[0])}${f.next && f.status !== 'print' ? ` ← ${esc(f.next === 'done' ? (f.kind === 'activate' ? 'تفعيل الحساب' : 'إنجاز') : f.next_label)}` : ''}</button></div></div>`
      : `<p class="small muted mt">${['done', 'rejected', 'cancelled'].includes(f.status) ? 'المعاملة مغلقة.' : f.status === 'ship' ? 'المعاملة مع شركة التوصيل — تُغلق آلياً عند تسليم الهوية برمز الاستلام.' : `المعاملة الآن لدى: ${esc(f.status_label)}.`}</p>`}
    <details class="small mt" open><summary>سجل المعاملة (من قسم إلى قسم)</summary><ul class="vs-log">${(R.log || []).map(l => `<li><b>${esc(l.action)}</b><span class="muted"> — ${esc(l.actor_name || '')} · ${esc(l.actor_title || '')} · ${dt(l.created_at)}</span>${l.note ? `<div>${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>
    ${(R.history || []).length ? `<details class="small"><summary>معاملات سابقة للطبيب</summary>${R.history.map(h => `<div>${esc(h.kind)} · <span class="num">${esc(h.code)}</span> · ${esc(h.status)} · ${dt(h.at)}</div>`).join('')}</details>` : ''}`, { wide: true });
  md.el.querySelectorAll('[data-doc]').forEach(b => b.onclick = async () => {
    try { const x = await rpc(ctx.sb, 'syn_doc', { p_id: b.dataset.doc }); modal(`<h3>${esc(x.label)}</h3>${String(x.mime).startsWith('image/') ? `<div class="docview"><img src="${x.data}" alt=""></div>` : `<iframe src="${x.data}" style="width:100%;height:70vh;border:0"></iframe>`}`, { wide: true }); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  });
  const pb = md.el.querySelector('[data-print]');
  if (pb) pb.onclick = () => { if (!printCard(R.card, m.photo)) toast('اسمح بالنوافذ المنبثقة للطباعة', 'bad'); };
  md.el.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
    const a = b.dataset.a, note = md.el.querySelector('[data-n]').value.trim();
    if (a !== 'forward' && !note) return toast('اكتب السبب أولاً', 'bad');
    const p = { note };
    md.el.querySelectorAll('[data-fx]').forEach(i => { if (i.value) p[i.dataset.fx] = i.value.trim(); });
    if (a === 'forward' && f.status === 'print') { p.courier = md.el.querySelector('[data-cr]')?.value; if (!p.courier) return toast('اختر شركة التوصيل', 'bad'); }
    md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = true);
    try {
      const r = await rpc(ctx.sb, 'syn_act', { p_file: f.id, p_action: a, p });
      md.close();
      if (r.card) {
        toast(`طُبعت الهوية ${r.card} وسُلّمت للشحنة ${r.delivery}`, 'ok');
        const R2 = await rpc(ctx.sb, 'syn_file', { p_id: f.id }).catch(() => null);
        if (R2?.card) printCard(R2.card, R2.member?.photo);
      } else toast(a === 'forward' ? `أُحيلت — ${r.status_label}` : a === 'return' ? 'أُعيدت للطبيب وأُبلغ' : a === 'back' ? `أُعيدت إلى ${r.status_label}` : 'سُجّل الرفض وأُبلغ الطبيب', 'ok');
      ctx.refresh();
    } catch (e) { toast(cleanErr(e), 'bad'); md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = false); }
  });
}

// ───────── سجل الأعضاء ─────────
async function membersTab(ctx, body) {
  body.innerHTML = `<div class="row mb" style="gap:8px"><input class="input" data-q placeholder="ابحث بالاسم أو رقم العضوية أو الرقم الوطني" style="flex:1"><button class="btn ghost" data-go>بحث</button></div><div data-l><div class="loading"><div class="spin"></div></div></div>`;
  const load = async () => {
    const box = body.querySelector('[data-l]');
    try {
      const L = await rpc(ctx.sb, 'syn_members_list', { p_q: body.querySelector('[data-q]').value.trim() || null });
      box.innerHTML = L.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الطبيب</th><th>رقم العضوية</th><th>الفرع</th><th>الحالة</th><th>النفاذ</th><th>التذكير</th></tr></thead><tbody>
        ${L.map(x => `<tr><td><b>${esc(x.name)}</b><div class="small muted">${esc(x.specialty || x.college || '')}</div></td><td class="num">${esc(x.membership_no || '—')}</td><td>${esc(x.governorate)}</td>
          <td>${smBadge(x.status)}${x.source === 'activation' ? ' <span class="tag">مفعّل</span>' : ' <span class="tag">انتساب جديد</span>'}</td>
          <td>${x.valid_until ? `<span class="num">${esc(x.valid_until)}</span>${x.days_left != null && x.days_left >= 0 && x.days_left <= 30 ? `<div class="small warn-t">بعد <span class="num">${x.days_left}</span> يوم</div>` : ''}` : '—'}</td>
          <td class="small">${(x.reminded || '').split(',').filter(Boolean).map(k => ({ d1: 'قبل أسبوع ✓', d2: 'قبل يومين ✓', exp: 'عند الانتهاء ✓' }[k.split(':')[0]] || '')).join('<br>') || '—'}</td></tr>`).join('')}</tbody></table></div></div>`
        : '<div class="card empty">لا أعضاء مطابقين.</div>';
    } catch (e) { box.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
  };
  body.querySelector('[data-go]').onclick = load;
  body.querySelector('[data-q]').onkeydown = e => { if (e.key === 'Enter') load(); };
  load();
}

// ───────── تأييد قروض المبادرة (الجلسة 6) ─────────
async function loansTab(ctx, body) {
  const { sb } = ctx;
  const members = (await sb.from('vet_memberships').select('*').order('submitted_at', { ascending: false, nullsFirst: false })).data || [];
  const y = new Date().getFullYear();
  const pending = members.filter(m => m.status === 'pending');
  const list = ctx.loanAll ? members.filter(m => m.status !== 'draft') : pending;
  body.innerHTML = `<div class="notice">مبادرة تمويل مشاريع أعضاء النقابة: تؤيد النقابة عضوية الطبيب وسريان إجازة ممارسته لسنة <span class="num">${y}</span>. العضو الذي هويته نافذة في «سجل الأعضاء» يُؤيَّد آلياً.</div>
    <div class="chips mb"><button type="button" class="chip ${ctx.loanAll ? '' : 'on'}" data-v="p">بانتظار التأييد <span class="num">${pending.length}</span></button><button type="button" class="chip ${ctx.loanAll ? 'on' : ''}" data-v="a">كل الأعضاء</button></div>
    <div class="card flush">${list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الطبيب</th><th>رقم العضوية</th><th>الفرع</th><th>إجازة الممارسة</th><th>الحالة</th><th>الإرسال</th></tr></thead><tbody>
    ${list.map(m => `<tr class="click" data-m="${m.id}"><td><b>${esc(m.full_name)}</b><div class="small muted">${esc(m.college || '')}</div></td><td class="num">${esc(m.membership_no || '—')}</td><td>${esc(m.syndicate_branch || '—')}</td>
      <td><span class="num">${esc(m.license_no || '—')}</span> · <span class="num">${esc(m.license_year || '')}</span></td>
      <td>${badge(MEMBER_STATUS[m.status] || [m.status, 'muted'])}${m.letter_no ? `<div class="small num muted">${esc(m.letter_no)}</div>` : ''}</td><td class="small muted">${m.submitted_at ? ago(m.submitted_at) : '—'}</td></tr>`).join('')}</tbody></table></div>`
    : '<div class="empty">لا طلبات هنا الآن.</div>'}</div>`;
  body.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { ctx.loanAll = b.dataset.v === 'a'; loansTab(ctx, body); });
  body.querySelectorAll('[data-m]').forEach(tr => tr.onclick = () => openMember(ctx, members.find(m => m.id === tr.dataset.m)));
}

async function openMember(ctx, m) {
  const { sb } = ctx, y = new Date().getFullYear();
  const docs = (await sb.from('vet_member_docs').select('kind,data,meta,created_at').eq('membership_id', m.id)).data || [];
  const D = { union_id: 'هوية النقابة', license: 'إجازة ممارسة المهنة', degree: 'شهادة التخرج' };
  const can = m.status === 'pending';
  const md = modal(`<h3>${esc(m.full_name)} ${badge(MEMBER_STATUS[m.status])}</h3>
    <dl class="kv"><dt>رقم العضوية</dt><dd class="num">${esc(m.membership_no || '—')}</dd><dt>فرع النقابة</dt><dd>${esc(m.syndicate_branch || '—')}</dd>
      <dt>إجازة الممارسة</dt><dd><span class="num">${esc(m.license_no || '—')}</span> لسنة <span class="num">${esc(m.license_year || '')}</span> ${Number(m.license_year) === y ? badge(['مجددة', 'ok']) : badge(['غير مجددة لهذه السنة', 'bad'])}</dd>
      <dt>الكلية</dt><dd>${esc(m.college || '—')}</dd><dt>سنة التخرج</dt><dd class="num">${esc(m.graduation_year || '—')}</dd><dt>الاختصاص</dt><dd>${esc(m.specialty || '—')}</dd>
      ${m.letter_no ? `<dt>كتاب التأييد</dt><dd><span class="num">${esc(m.letter_no)}</span> · ساري حتى <span class="num">${esc(m.valid_until)}</span></dd>` : ''}
      ${m.note ? `<dt>ملاحظة</dt><dd>${esc(m.note)}</dd>` : ''}${m.decided_at ? `<dt>القرار</dt><dd>${esc(m.decided_by_title || '')} · ${dt(m.decided_at)}</dd>` : ''}</dl>
    <div class="mdocs">${['union_id', 'license', 'degree'].map(k => { const d = docs.find(x => x.kind === k); return `<figure><div>${d ? `<img src="${d.data}" alt="${esc(D[k])}">` : '<span class="muted small">لم يُصوَّر</span>'}</div><figcaption>${esc(D[k])}</figcaption></figure>`; }).join('')}</div>
    ${can ? `<div class="field mt"><label>ملاحظة أو سبب (إلزامي للإعادة وعدم التأييد)</label><textarea class="input" rows="2" data-n></textarea></div>
    <div class="row"><button class="btn bad" data-a="reject">عدم التأييد</button><button class="btn warn" data-a="return">إعادة للاستكمال</button><span class="sp"></span><button class="btn ok" data-a="endorse">تأييد العضوية وإصدار الكتاب</button></div>` : ''}`, { wide: true });
  md.el.querySelectorAll('.mdocs img').forEach(i => i.onclick = () => modal(`<div class="docview"><img src="${i.src}" alt=""></div>`, { wide: true }));
  md.el.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => {
    const note = md.el.querySelector('[data-n]').value.trim() || null;
    if (b.dataset.a !== 'endorse' && !note) return toast('اكتب السبب أولاً', 'bad');
    md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = true);
    try { const r = await rpc(sb, 'syndicate_action', { p_member: m.id, p_action: b.dataset.a, p_note: note }); md.close();
      toast(b.dataset.a === 'endorse' ? `أُيدت العضوية — كتاب ${r.letter_no}` : 'سُجّل القرار وأُبلغ الطبيب', 'ok'); ctx.refresh(); }
    catch (e) { toast(cleanErr(e), 'bad'); md.el.querySelectorAll('[data-a]').forEach(x => x.disabled = false); }
  });
}

export const shouldRefresh = ctx => !['geo', 'members'].includes(ctx?.synTab) && !document.querySelector('.mdl-bg');
