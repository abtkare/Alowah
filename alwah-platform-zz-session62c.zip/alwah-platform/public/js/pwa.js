// ألواح — تثبيت البوابة تطبيقاً على الشاشة (الجلسة 50، أُعيد تصميم الإشعار في الجلسة 51).
// ملف مستقل لا يغيّر منطق البوابة: يسجّل ملف الخدمة، ويعرض بعد الدخول فقط بطاقة صغيرة
// تصعد من أسفل منتصف الشاشة «ثبّت التطبيق». ✕ يخفيها 3 دقائق ثم تعود ما لم يُثبَّت التطبيق.
// الأيقونة = شعار جهة المستخدم الذي رفعه مشغّل النظام (المصرف/شركة التأمين)، وإلا شعار البوابة.
(function () {
  'use strict';
  try {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {}); });
    }

    const standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
    if (standalone) return;   // مثبّت ويعمل كتطبيق — لا حاجة لأي شيء

    const seg = location.pathname.split('/')[1] || '';
    const KEY = 'alwah-pwa-snooze-' + seg;
    const SNOOZE = 3 * 60 * 1000;              // ✕ = إخفاء 3 دقائق
    const ua = navigator.userAgent || '';
    const isIOS = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    const isMacSafari = !isIOS && /Macintosh/.test(ua) && /Safari\//.test(ua) && !/Chrome|Chromium|Edg|Firefox/.test(ua);
    const name = ((document.querySelector('meta[name="apple-mobile-web-app-title"]') || {}).content || 'البوابة').replace(/[<>&"]/g, '');
    let who = 'portal';                        // أو معرّف جهة المستخدم بعد الدخول
    const iconUrl = s => '/app/icon/' + seg + '/' + who + '-' + s + '.png';

    let deferred = null, bar = null, timer = null, gapTimer = null;
    const until = () => { try { return Number(localStorage.getItem(KEY) || 0); } catch (e) { return 0; } };
    const hidden = () => Date.now() < until();
    const hideFor = ms => { try { localStorage.setItem(KEY, String(Date.now() + ms)); } catch (e) {} };

    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; check(); });
    window.addEventListener('appinstalled', () => { deferred = null; remove(); hideFor(3650 * 864e5); });

    // بعد الدخول: أيقونة جهة المستخدم في ملف التعريف وأيقونة آيفون
    function setOrg(org) {
      who = org && /^[0-9a-f-]{36}$/.test(org) ? org : 'portal';
      const t = document.querySelector('link[rel="apple-touch-icon"]'); if (t) t.href = iconUrl(180);
      const m = document.querySelector('link[rel="manifest"]');
      if (m && /^\/app\//.test(new URL(m.href, location.href).pathname)) m.href = '/app/' + seg + '.webmanifest' + (who !== 'portal' ? '?o=' + who : '');
      const img = bar && bar.querySelector('img'); if (img) img.src = iconUrl(180);
    }
    window.addEventListener('alwah:login', e => setOrg(e.detail && e.detail.org));
    if (window.ALWAH_ME) setOrg(window.ALWAH_ME.org);

    // يظهر بعد الدخول فقط: لا شاشة الدخول (.lx) ولا شاشة التحميل
    function loggedIn() {
      const app = document.getElementById('app');
      return !!app && !app.querySelector('.lx') && !app.querySelector('.loading') && app.children.length > 0;
    }
    function canOffer() { return !!deferred || isIOS || isMacSafari; }
    function check() {
      if (bar || !canOffer() || !loggedIn()) return;
      if (hidden()) { schedule(); return; }
      show();
    }
    function schedule() { clearTimeout(timer); timer = setTimeout(check, Math.max(1000, until() - Date.now() + 200)); }
    function remove() {
      clearInterval(gapTimer);
      if (!bar) return;
      const b = bar; bar = null;
      b.style.transform = 'translate(-50%, 140%)'; b.style.opacity = '0';
      setTimeout(() => b.remove(), 260);
    }

    // لا تغطي الشريط السفلي للبوابة أو زر «التالي» الثابت: ترتفع فوق أي عنصر ثابت أسفل الشاشة
    function bottomGap() {
      let gap = 0;
      [0.5, 0.2, 0.8].forEach(fx => {
        let el = document.elementFromPoint(innerWidth * fx, innerHeight - 3);
        while (el && el !== document.body && el !== document.documentElement) {
          if (bar && bar.contains(el)) break;
          const cs = getComputedStyle(el);
          if (cs.position === 'fixed' || cs.position === 'sticky') { gap = Math.max(gap, innerHeight - el.getBoundingClientRect().top); break; }
          el = el.parentElement;
        }
      });
      return Math.min(gap, innerHeight * 0.4);
    }
    function place() { if (bar) bar.style.bottom = 'calc(' + (14 + bottomGap()) + 'px + env(safe-area-inset-bottom,0px))'; }

    function show() {
      bar = document.createElement('div');
      bar.setAttribute('dir', 'rtl'); bar.setAttribute('role', 'dialog'); bar.setAttribute('aria-label', 'تثبيت التطبيق');
      bar.style.cssText = 'position:fixed;left:50%;bottom:14px;z-index:2147483000;width:calc(100% - 24px);max-width:420px;box-sizing:border-box;' +
        'display:flex;align-items:center;gap:12px;padding:12px 12px 12px 10px;border-radius:18px;pointer-events:auto;' +
        'background:#0b1220;color:#fff;box-shadow:0 12px 36px rgba(0,0,0,.38);font:600 14px/1.45 Cairo,system-ui,sans-serif;' +
        'transform:translate(-50%,140%);opacity:0;transition:transform .32s cubic-bezier(.2,.9,.3,1.2),opacity .25s,bottom .2s';
      bar.innerHTML =
        '<img src="' + iconUrl(180) + '" alt="" width="46" height="46" style="flex:none;width:46px;height:46px;border-radius:12px;background:#fff;object-fit:cover">' +
        '<span style="flex:1;min-width:0"><b style="display:block;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">ثبّت «' + name + '»</b>' +
        '<span style="display:block;font-weight:500;font-size:12.5px;color:#a9b3c7">على شاشتك ويفتح كتطبيق</span></span>' +
        '<button type="button" data-a="go" style="flex:none;font:700 14px Cairo,system-ui,sans-serif;border:0;border-radius:12px;padding:10px 16px;background:#05DBF3;color:#050810;cursor:pointer">ثبّت</button>' +
        '<button type="button" data-a="x" aria-label="إغلاق" style="flex:none;border:0;background:rgba(255,255,255,.08);color:#c9d1e0;width:34px;height:34px;border-radius:50%;font-size:16px;line-height:34px;padding:0;cursor:pointer">✕</button>';
      bar.addEventListener('click', async ev => {
        const btn = ev.target.closest('button'); const a = btn && btn.dataset.a;
        if (a === 'x') { hideFor(SNOOZE); remove(); schedule(); }
        if (a === 'go') {
          if (deferred) {
            deferred.prompt();
            let ok = false; try { const r = await deferred.userChoice; ok = r && r.outcome === 'accepted'; } catch (e) {}
            deferred = null; remove();
            if (ok) hideFor(3650 * 864e5); else { hideFor(SNOOZE); schedule(); }
          } else { remove(); help(); }
        }
      });
      document.body.appendChild(bar);
      place();
      requestAnimationFrame(() => requestAnimationFrame(() => { if (bar) { bar.style.transform = 'translate(-50%,0)'; bar.style.opacity = '1'; } }));
      clearInterval(gapTimer); gapTimer = setInterval(place, 700);
    }

    // آيفون وماك سفاري: لا يسمح النظام بالتثبيت بزر — نعرض الخطوتين
    function help() {
      const ios = isIOS;
      const box = document.createElement('div');
      box.setAttribute('dir', 'rtl');
      box.style.cssText = 'position:fixed;inset:0;z-index:2147483001;background:rgba(5,8,16,.6);display:flex;align-items:flex-end;justify-content:center';
      const share = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0a84ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px"><path d="M12 3v12"/><path d="M8 7l4-4 4 4"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/></svg>';
      const steps = ios
        ? '<li>اضغط زر المشاركة ' + share + ' في شريط Safari</li><li>اختر «إضافة إلى الشاشة الرئيسية» ثم «إضافة»</li>'
        : '<li>من شريط القوائم في الأعلى اختر «ملف» (File)</li><li>اختر «إضافة إلى Dock» (Add to Dock) ثم «إضافة»</li>';
      const btn = 'font:inherit;font-weight:700;flex:1;border:0;border-radius:12px;padding:12px;cursor:pointer;';
      box.innerHTML = '<div style="background:#fff;color:#0b1220;width:100%;max-width:440px;border-radius:18px 18px 0 0;padding:20px 20px calc(20px + env(safe-area-inset-bottom,0px));font:15px/1.8 Cairo,system-ui,sans-serif">' +
        '<div style="display:flex;align-items:center;gap:12px;margin:0 0 10px"><img src="' + iconUrl(180) + '" alt="" width="52" height="52" style="width:52px;height:52px;border-radius:13px;box-shadow:0 0 0 1px #e3e7ef">' +
        '<p style="margin:0;font-weight:800;font-size:17px">تثبيت «' + name + '»</p></div>' +
        '<ol style="margin:0 0 14px;padding-inline-start:20px">' + steps + '</ol>' +
        '<div style="display:flex;gap:8px"><button type="button" data-a="done" style="' + btn + 'background:#0b1220;color:#fff">ثبّتُّه ✓</button>' +
        '<button type="button" data-a="later" style="' + btn + 'background:#eef1f6;color:#0b1220">لاحقاً</button></div></div>';
      box.addEventListener('click', ev => {
        const b = ev.target.closest('button');
        if (ev.target !== box && !b) return;
        if (b && b.dataset.a === 'done') hideFor(3650 * 864e5); else { hideFor(SNOOZE); schedule(); }
        box.remove();
      });
      document.body.appendChild(box);
    }

    // البوابة تبني شاشاتها ديناميكياً — نراقب #app لنعرض البطاقة بعد الدخول ونخفيها عند الخروج
    function watch() {
      const app = document.getElementById('app');
      if (!app) return;
      new MutationObserver(() => { if (loggedIn()) check(); else { remove(); clearTimeout(timer); } }).observe(app, { childList: true });
      check();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch); else watch();
  } catch (e) { /* أي خطأ هنا لا يؤثر على البوابة */ }
})();
