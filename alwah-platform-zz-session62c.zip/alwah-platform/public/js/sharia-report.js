// الجلسة 43: تقرير الامتثال الشرعي الدوري للبنك المركزي
// يُحسب آلياً لأي فترة من الطلبات ووثائقها الموقّعة وقرارات الهيئة. يراه البنك المركزي والهيئة والجهات الرقابية،
// ويصدره رئيس الهيئة لفترة منتهية نسخةً مختومة (SCR-…) لا تتغير، تصل البنك المركزي إشعاراً.
import { esc, dt, badge, rpc, toast, cleanErr, kpi, askOtp, resultScreen, iqd } from './core.js';

const TYPE = { MRB: 'المرابحة', IJM: 'الإجارة المنتهية بالتمليك', MSN: 'المشاركة المتناقصة', SLM: 'السَّلَم', IST: 'الاستصناع', MDR: 'المضاربة', DMN: 'خطاب الضمان' };
const DOCK = { promise: 'وعود موقّعة (غير ملزمة)', invoice: 'فواتير المورد باسم المصرف', receipt: 'محاضر استلام وقبض', contract: 'عقود موقّعة بالنص المعتمد', shares: 'سجلات حصص', share_sale: 'عقود بيع حصص' };
const ESIGN = { signed: ['موقّع إلكترونياً ✓', 'ok'], sent: ['أُرسل للتوقيع', 'warn'], none: ['رمز تحقق فقط', 'muted'], expired: ['انتهى الرابط', 'bad'], cancelled: ['أُلغي', 'muted'], failed: ['تعذّر', 'bad'], manual_review: ['حضورياً', 'warn'] };
const LATE = { claim: 'المطالبة والرجوع إلى الضمانات', damage: 'تعويض عن ضرر فعلي تقرّه الهيئة', charity: 'التزام بالتبرع لصندوق خيري' };

const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const MONTHS = ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];
function presets() {
  const now = new Date(), y = now.getFullYear(), m = now.getMonth(), q = Math.floor(m / 3);
  const P = (k, l, a, b) => ({ k, l, from: iso(a), to: iso(b) });
  return [
    P('pm', `الشهر الماضي (${MONTHS[(m + 11) % 12]})`, new Date(y, m - 1, 1), new Date(y, m, 0)),
    P('cm', `الشهر الحالي (${MONTHS[m]})`, new Date(y, m, 1), now),
    P('pq', 'الربع الماضي', new Date(y, (q - 1) * 3, 1), new Date(y, q * 3, 0)),
    P('cq', 'الربع الحالي', new Date(y, q * 3, 1), now),
    P('cy', `سنة ${y} حتى اليوم`, new Date(y, 0, 1), now),
  ];
}

// الجلسة 44: pickBoard — للبنك المركزي والهيئة المركزية: كل الهيئات أو هيئة مصرف واحدة. هيئة المصرف ترى تقريرها فقط.
export async function mountShariaReport(ctx, box, { canIssue = false, pickBoard = false } = {}) {
  const st = ctx.shReport || (ctx.shReport = { k: 'pm', ...presets()[0], view: null, board: null });
  const opts = { canIssue, pickBoard };
  const issuable = canIssue && !st.board;
  const today = iso(new Date());
  box.innerHTML = `<div class="card mb scr-bar no-print">
      <div class="row" style="flex-wrap:wrap;gap:8px"><h3 style="margin:0">تقرير الامتثال الشرعي الدوري</h3><span class="sp"></span>
        <button type="button" class="btn ghost sm" data-print>🖨 طباعة / PDF</button><button type="button" class="btn ghost sm" data-csv>⬇ CSV</button></div>
      <p class="small muted" style="margin:4px 0 10px">يُحسب آلياً من الطلبات الإسلامية ووثائقها الموقّعة وقرارات الهيئة — لا يُدخل يدوياً. اختر الفترة:</p>
      <div class="seg sm scr-pre">${presets().map(p => `<button type="button" class="${st.k === p.k ? 'on' : ''}" data-p="${p.k}">${esc(p.l)}</button>`).join('')}</div>
      <div class="row mt" style="gap:8px;flex-wrap:wrap"><label class="small">من <input class="input sm" type="date" data-from value="${st.from}" max="${today}"></label>
        <label class="small">إلى <input class="input sm" type="date" data-to value="${st.to}" max="${today}"></label><button type="button" class="btn sm" data-go>عرض</button>
        ${pickBoard ? '<label class="small">الهيئة <select class="input sm" data-board><option value="">كل الهيئات والمصارف</option></select></label>' : ''}</div>
    </div>
    <div data-rep><div class="cz-load"><div class="spin"></div><span>جارِ احتساب التقرير…</span></div></div>
    <div data-issued class="no-print"></div>${pickBoard ? '<div data-fitreg class="no-print" style="margin-top:12px"></div>' : ''}`;
  const rep = box.querySelector('[data-rep]');
  const load = async () => {
    rep.innerHTML = '<div class="cz-load"><div class="spin"></div><span>جارِ احتساب التقرير…</span></div>';
    try {
      const R = st.view ? await rpc(ctx.sb, 'sharia_compliance_get', { p_id: st.view })
        : await rpc(ctx.sb, 'sharia_compliance_report', { p_from: st.from, p_to: st.to, ...(st.board ? { p_board: st.board } : {}) });
      st.data = R; draw(R);
      const sel = box.querySelector('[data-board]');
      if (sel && R.board_filter && sel.options.length === 1) {
        sel.insertAdjacentHTML('beforeend', R.board_filter.filter(b => b.scope === 'bank').map(b => `<option value="${b.id}" ${st.board === b.id ? 'selected' : ''}>${esc(b.name)}</option>`).join(''));
        sel.onchange = () => { st.board = sel.value || null; st.view = null; mountShariaReport(ctx, box, opts); };
      }
    } catch (e) { rep.innerHTML = `<div class="notice warn"><span>⚠</span><span>${esc(cleanErr(e))}</span></div>`; }
  };
  const draw = R => {
    const T = R.totals, ended = R.to < today, I = R.issued;
    const issuedBox = st.view && I ? `<div class="notice ok-n"><span>🔏</span><span><b>نسخة مختومة — ${esc(I.code)}</b>${I.label ? ` (${esc(I.label)})` : ''} · صدرت ${dt(I.issued_at)}${I.issued_by ? ` — ${esc(I.issued_by)}` : ''}
        · ${I.intact ? '<b>سليمة: لم تتغير منذ الإصدار</b>' : '<b style="color:var(--bad)">البصمة لا تطابق!</b>'}<br><span class="small muted">البصمة <code dir="ltr">${esc((I.sha256 || '').slice(0, 32))}…</code></span>
        <br><button type="button" class="linkbtn" data-live>← عرض الاحتساب الحي للفترة نفسها</button></span></div>`
      : I ? `<div class="notice"><span>🔏</span><span>صدر تقرير هذه الفترة <b class="num">${esc(I.code)}</b> في ${dt(I.issued_at)} — <button type="button" class="linkbtn" data-open-issued>افتح النسخة المختومة</button></span></div>`
      : issuable ? `<div class="notice scr-issue ${ended ? 'warn' : ''} no-print"><span>📤</span><span>${ended ? '<b>الفترة منتهية:</b> أصدر التقرير نسخةً مختومة تصل البنك المركزي ولا تتغير بعد إصدارها.' : 'الفترة لم تنتهِ بعد — يُصدر التقرير بعد نهايتها. ما تراه احتساب حي.'}</span>
          ${ended ? '<button type="button" class="btn cyan sm" data-issue>إصدار التقرير للبنك المركزي</button>' : ''}</div>` : '';
    rep.innerHTML = `${issuedBox}
      <div class="card mb scr-head"><h2 style="margin:0">${esc(R.board || 'الهيئة الشرعية')}</h2>
        <p class="small muted" style="margin:2px 0 0">${R.scope === 'bank' ? `تقرير الامتثال الشرعي — ${esc(R.bank || '')}` : 'تقرير الامتثال الشرعي الجامع للمصارف الإسلامية وهيئاتها'} — إلى البنك المركزي العراقي · على ${esc(R.madhhab || '')}${R.marja ? ` · المرجع: ${esc(R.marja)}` : ''}</p>
        <p style="margin:6px 0 0">الفترة: من <b class="num">${esc(R.from)}</b> إلى <b class="num">${esc(R.to)}</b> · احتُسب ${dt(R.generated_at)}</p></div>
      <div class="grid g4 mb">
        ${kpi('مخالفات للضوابط', `<span class="num">${T.violations}</span>`, T.violations ? '<span class="warn-t">تحتاج إجراءً</span>' : 'لا مخالفة — الحرّاس الآليون منعوها', !!T.violations)}
        ${kpi('ملاحظات', `<span class="num">${T.warnings}</span>`, 'مراجعة دورية أو توقيع إلكتروني')}
        ${kpi('طلبات تمويل إسلامي', `<span class="num">${T.apps}</span>`, `جديدة في الفترة <span class="num">${T.apps_new}</span>${T.vet ? ` · بيطري <span class="num">${T.vet}</span>` : ''}`)}
        ${kpi('منتجات نافذة', `<span class="num">${T.products_live}</span>`, `قرارات الفترة <span class="num">${T.resolutions}</span>`)}
      </div>
      <div class="card mb"><h3>1. فحوص الامتثال</h3><div class="scr-checks">${R.checks.map(c => {
        const ok = !c.count, cls = ok ? 'ok' : c.kind === 'guard' ? 'bad' : 'warn';
        return `<div class="scr-ck ${cls}"><i>${ok ? '✓' : c.kind === 'guard' ? '✗' : '!'}</i><div><b>${esc(c.label)}</b>
          ${c.count ? `<div class="small"><span class="num">${c.count}</span>: ${c.items.map(x => `<span class="num">${esc(x)}</span>`).join('، ')}</div>` : ''}${c.note ? `<div class="small muted">${esc(c.note)}</div>` : ''}</div>
          <span class="sp"></span>${badge(ok ? ['مستوفى', 'ok'] : [c.kind === 'guard' ? 'مخالفة' : 'ملاحظة', cls])}</div>`; }).join('')}</div></div>
      <div class="card mb flush"><h3>2. المصارف الإسلامية</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>منتجات نافذة</th><th>طلبات إسلامية</th><th>جديدة في الفترة</th><th>عقود موقّعة في الفترة</th><th>تمويل منفّذ</th><th>حسب الصيغة</th></tr></thead><tbody>
        ${R.banks.map(b => `<tr><td><b>${esc(b.bank)}</b></td><td class="num">${b.products_live} / ${b.products_all}</td><td class="num">${b.apps_islamic}${b.apps > b.apps_islamic ? ` <span class="small muted">(+${b.apps - b.apps_islamic} قبل المنتجات)</span>` : ''}</td><td class="num">${b.apps_new}</td><td class="num">${b.contracts}</td><td>${iqd(b.financed)}</td>
          <td class="small">${Object.entries(b.by_type || {}).map(([k, v]) => `${esc(TYPE[k] || k)} <span class="num">${v}</span>`).join(' · ') || '—'}</td></tr>`).join('') || '<tr><td colspan="7" class="muted">لا مصارف إسلامية</td></tr>'}</tbody></table></div></div>
      <div class="grid g2 mb">
        <div class="card"><h3>3. الوثائق الموقّعة في الفترة</h3><dl class="kv">${Object.entries(DOCK).map(([k, l]) => `<dt>${esc(l)}</dt><dd class="num">${R.docs?.[k] || 0}</dd>`).join('')}</dl>
          <p class="small muted" style="margin:6px 0 0">كل وثيقة محفوظة بنصها حرفياً وبصمتها ورمز تحقق عام (/v/…).</p></div>
        <div class="card"><h3>4. التأخر في السداد</h3><dl class="kv"><dt>المعالجة المعتمدة</dt><dd>${esc(LATE[R.late.kind] || R.late.kind || '—')}</dd>
          <dt>أقساط متأخرة (عدد / مبلغ)</dt><dd><span class="num">${R.late.overdue_count}</span> · ${iqd(R.late.overdue_amount)}</dd>
          <dt>المحصّل في الفترة</dt><dd>${iqd(R.late.paid_in_period)}</dd>
          <dt>تبرعات للصندوق الخيري</dt><dd><span class="num">${R.late.charity_count}</span> · ${iqd(R.late.charity_amount)} <span class="small muted">خارج إيرادات المصرف</span></dd>
          <dt>زيادة على المتأخر</dt><dd>${badge(['ممنوعة آلياً', 'ok'])}</dd></dl>${R.late.rule ? `<p class="small muted" style="margin:6px 0 0">${esc(R.late.rule)}</p>` : ''}</div></div>
      <div class="card mb flush"><h3>5. قرارات الهيئة في الفترة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القرار</th><th>الحكم</th><th>المنتج</th><th>المصرف</th><th>التاريخ</th><th>توقيع الرئيس</th></tr></thead><tbody>
        ${R.resolutions.map(r => `<tr><td class="num"><b>${esc(r.code)}</b></td><td>${esc(r.decision_label)}</td><td>${esc(r.product)}</td><td>${esc(r.bank)}</td><td>${dt(r.issued_at)}</td><td>${badge(ESIGN[r.esign] || [r.esign, 'muted'])}${r.cert ? ` <span class="small muted num">${esc(r.cert)}</span>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">لا قرارات في الفترة</td></tr>'}</tbody></table></div></div>
      <div class="card mb flush"><h3>6. سجل المنتجات</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المنتج</th><th>المصرف</th><th>الهيئة</th><th>الصيغة</th><th>القطاع</th><th>الحالة</th><th>القرار</th><th>المراجعة الدورية</th></tr></thead><tbody>
        ${R.products.map(p => `<tr><td><span class="num">${esc(p.code)}</span> ${esc(p.name)}</td><td>${esc(p.bank)}</td><td class="small">${esc(p.board || '—')}${p.inherited ? ' <span class="tag">موروث</span>' : ''}</td><td>${esc(TYPE[p.type] || p.type)}</td><td class="small">${esc(p.sector)}</td><td>${esc(p.status_label)}</td><td class="num">${esc(p.resolution || '—')}</td>
          <td class="num ${p.review_due && p.review_due < R.to && ['approved', 'conditional'].includes(p.status) ? 'warn-t' : ''}">${esc(p.review_due || '—')}</td></tr>`).join('')}</tbody></table></div></div>
      ${(R.boards || []).length ? `<div class="card mb flush"><h3>7. الهيئات الشرعية</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الهيئة</th><th>المصرف</th><th>الأعضاء بملاءمة</th><th>بانتظار الملاءمة</th><th>المصوّتون / النصاب</th><th>تعتمد الآن</th><th>منتجات نافذة</th><th>قرارات الفترة</th><th>تقريرها للفترة</th></tr></thead><tbody>
        ${R.boards.map(b => `<tr><td><b>${esc(b.name)}</b> <span class="small muted num">${esc(b.code)}</span></td><td>${b.scope === 'central' ? '<span class="small muted">مركزية — إشراف</span>' : esc(b.bank || '')}</td><td class="num">${b.members}</td><td class="num ${b.fit_pending ? 'warn-t' : ''}">${b.fit_pending}</td>
          <td class="num">${b.voters} / ${b.quorum}</td><td>${badge(b.active ? ['نعم', 'ok'] : b.ready ? ['مكتملة', 'warn'] : ['غير مكتملة', 'warn'])}</td><td class="num">${b.products_live}</td><td class="num">${b.resolutions}</td>
          <td class="small">${b.report ? `<b class="num">${esc(b.report.code)}</b> · مخالفات <span class="num">${b.report.violations}</span>` : '<span class="muted">—</span>'}</td></tr>`).join('')}</tbody></table></div></div>` : ''}`;
    rep.querySelector('[data-live]')?.addEventListener('click', () => { st.view = null; st.from = R.from; st.to = R.to; st.k = null; load(); });
    rep.querySelector('[data-open-issued]')?.addEventListener('click', () => openIssued(I.code));
    rep.querySelector('[data-issue]')?.addEventListener('click', issue);
  };
  const issue = async () => {
    const lbl = presets().find(p => p.k === st.k)?.l?.replace(/\s*\(.*\)/, '') || '';
    let r = null;
    const ok = await askOtp({ kind: 'sign', title: 'إصدار تقرير الامتثال الشرعي', phone: ctx.profile.phone || '', purpose: `الفترة ${st.from} — ${st.to}`,
      ...(ctx.profile.phone ? {} : { sb: { rpc: async fn => fn === 'otp_request' ? { data: { mode: 'dev' } } : { data: null } } }),
      verify: async otp => { r = await rpc(ctx.sb, 'sharia_compliance_issue', { p_from: st.from, p_to: st.to, p_label: lbl, p_otp: otp }); } });
    if (!ok || !r) return;
    await resultScreen({ title: 'صدر التقرير ووصل البنك المركزي', ref: r.code, msg: 'نسخة مختومة لا تتغير بعد إصدارها — يراها البنك المركزي في «الامتثال الشرعي».', seal: r.sha256, chips: ['البنك المركزي العراقي'] });
    mountShariaReport(ctx, box, opts);
  };
  let list = [];
  const openIssued = code => { const x = list.find(l => l.code === code); if (x) { st.view = x.id; load(); window.scrollTo(0, 0); } };
  const drawList = () => {
    const ib = box.querySelector('[data-issued]');
    ib.innerHTML = `<div class="card flush"><h3>التقارير الصادرة (نسخ مختومة)</h3>${list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الرقم</th><th>الهيئة</th><th>الفترة</th><th>مخالفات</th><th>ملاحظات</th><th>صدر</th><th>اطلاع البنك المركزي</th></tr></thead><tbody>
      ${list.map(r => `<tr data-o="${esc(r.code)}" style="cursor:pointer"><td class="num"><b>${esc(r.code)}</b></td><td class="small">${esc(r.board || '')}</td><td>${esc(r.label || '')} <span class="small muted num">${esc(r.from)} — ${esc(r.to)}</span></td><td class="num">${r.violations}</td><td class="num">${r.warnings}</td><td>${dt(r.issued_at)}</td><td>${r.cbi_seen_at ? badge([`اطّلع ${dt(r.cbi_seen_at)}`, 'ok']) : badge(['لم يُفتح بعد', 'muted'])}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="empty">لم يصدر تقرير بعد.</div>'}</div>`;
    ib.querySelectorAll('[data-o]').forEach(t => t.onclick = () => openIssued(t.dataset.o));
  };
  // الجلسة 45: سجل الملاءمة — القرار للهيئة المركزية، والبنك المركزي يطّلع فقط
  const FITB = { pending: ['بانتظار الملاءمة', 'warn'], approved: ['ملاءمة معتمدة', 'ok'], rejected: ['لم تُعتمد', 'bad'], revoked: ['سُحبت الملاءمة', 'bad'] };
  const fb = box.querySelector('[data-fitreg]');
  if (fb) rpc(ctx.sb, 'sharia_fit_register').then(F => {
    const cbi = F.viewer === 'cbi', M = F.members || [], fresh = M.filter(m => !m.cbi_seen_at).length;
    fb.innerHTML = `<div class="card flush"><div class="row" style="flex-wrap:wrap;gap:8px;padding:12px 14px 0"><h3 style="margin:0">سجل ملاءمة أعضاء هيئات المصارف</h3><span class="sp"></span>${badge(['للاطلاع فقط', 'muted'])}</div>
      <p class="small muted" style="margin:4px 14px 8px">${cbi ? `تقرر الهيئة المركزية ملاءمة كل عضو، ويصلكم كل ترشيح وقرار هنا وإشعاراً.${fresh ? ` <b>جديد: <span class="num">${fresh}</span></b>` : ''}` : 'قراركم وحدكم. يظهر هنا متى اطّلع البنك المركزي على كل قرار.'}</p>
      ${M.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>العضو</th><th>الهيئة</th><th>الملاءمة</th><th>رقم القرار</th><th>التاريخ</th><th>قرار</th><th>${cbi ? '' : 'اطلاع البنك المركزي'}</th></tr></thead><tbody>
      ${M.map(m => `<tr><td><b>${esc(m.name)}</b><div class="small muted">${esc(m.role_title)}${m.specialty ? ' · ' + esc(m.specialty) : ''}</div></td><td class="small">${esc(m.bank || m.board)}</td>
        <td>${badge(FITB[m.fit_status] || [m.fit_label, 'muted'])}${cbi && !m.cbi_seen_at ? ' <span class="tag">جديد</span>' : ''}${m.fit_note ? `<div class="small muted">${esc(m.fit_note)}</div>` : ''}</td>
        <td class="num">${esc(m.fit_code || '—')}</td><td>${dt(m.fit_at || m.nominated_at)}</td><td class="small">${esc(m.fit_by || '—')}</td>
        <td class="small">${cbi ? '' : m.cbi_seen_at ? badge([`اطّلع ${dt(m.cbi_seen_at)}`, 'ok']) : badge(['لم يُفتح بعد', 'muted'])}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا أعضاء في هيئات المصارف بعد.</div>'}
      ${(F.log || []).length ? `<details style="padding:0 14px 12px"><summary class="small"><b>تسلسل الترشيحات والقرارات</b></summary><ul class="sh-log">${F.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.actor || '')}</b> — ${esc(l.action)} <span class="small muted">· ${esc(l.board)}</span>${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>` : ''}</div>`;
  }).catch(() => { fb.innerHTML = ''; });
  rpc(ctx.sb, 'sharia_compliance_list').then(x => { list = x || []; drawList(); }).catch(() => {});
  box.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { const p = presets().find(x => x.k === b.dataset.p); Object.assign(st, { k: p.k, from: p.from, to: p.to, view: null }); mountShariaReport(ctx, box, opts); });
  box.querySelector('[data-go]').onclick = () => {
    const f = box.querySelector('[data-from]').value, t = box.querySelector('[data-to]').value;
    if (!f || !t || t < f) return toast('اختر فترة صحيحة', 'bad');
    Object.assign(st, { k: null, from: f, to: t, view: null }); mountShariaReport(ctx, box, opts);
  };
  box.querySelector('[data-print]').onclick = () => window.print();
  box.querySelector('[data-csv]').onclick = () => {
    const R = st.data; if (!R) return;
    const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const rows = [['تقرير الامتثال الشرعي', R.from, R.to], [], ['الفحص', 'النوع', 'العدد', 'الطلبات/المنتجات'], ...R.checks.map(c => [c.label, c.kind === 'guard' ? 'ضابط' : 'ملاحظة', c.count, c.items.join(' ')]),
      [], ['المصرف', 'منتجات نافذة', 'طلبات إسلامية', 'جديدة', 'عقود الفترة', 'تمويل منفّذ'], ...R.banks.map(b => [b.bank, b.products_live, b.apps_islamic, b.apps_new, b.contracts, b.financed]),
      [], ['القرار', 'الحكم', 'المنتج', 'المصرف', 'التاريخ', 'توقيع الرئيس'], ...R.resolutions.map(r => [r.code, r.decision_label, r.product, r.bank, r.issued_at, r.esign])];
    const blob = new Blob(['﻿' + rows.map(r => r.map(q).join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `sharia-compliance-${R.from}_${R.to}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };
  load();
}
