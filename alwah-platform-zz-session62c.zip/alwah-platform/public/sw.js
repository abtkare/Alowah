// ألواح — الجلسة 50: ملف الخدمة (Service Worker) لتثبيت البوابات تطبيقاتٍ على الشاشة.
// لا يخزّن أي صفحة أو بيانات: كل طلب يذهب للخادم كما هو، فلا تظهر نسخة قديمة بعد أي تحديث.
// عند انقطاع الإنترنت فقط تظهر رسالة بسيطة بدل صفحة الخطأ.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

const OFFLINE = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ألواح — لا يوجد اتصال</title><body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#050810;color:#fff;font-family:system-ui,sans-serif;text-align:center;padding:24px">
<div><p style="font-size:20px;font-weight:700">لا يوجد اتصال بالإنترنت</p><p style="color:#9aa4b8">تحقق من الاتصال ثم اضغط الزر</p>
<button onclick="location.reload()" style="font:inherit;font-size:17px;padding:12px 28px;border:0;border-radius:12px;background:#05DBF3;color:#050810;font-weight:700">إعادة المحاولة</button></div></body></html>`;

self.addEventListener('fetch', e => {
  if (e.request.mode !== 'navigate') return;   // الملفات والبيانات لا يلمسها ملف الخدمة إطلاقاً
  e.respondWith(fetch(e.request).catch(() => new Response(OFFLINE, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
});
