-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 43: الهيئة الشرعية — الحزمة 3
--  (أ) المرحلة 25 للطلب الإسلامي: «التعهدات والضمانات» فقط — لا عقد تمويل ولا كمبيالة بدين قبل أن يتملّك المصرف ويقبض.
--  (ب) منتجات إسلامية لمسار البيطري: اختيار المنتج في المعالج البيطري، والحرّاس نفسها (الوعد، فاتورة المورد باسم المصرف،
--      محضر القبض، العقد بعد القبض، الجدول = الثمن).
--  (ج) توقيع رئيس الهيئة قراراته عبر خدمة التوقيع الإلكتروني (alwah-esign): تحقق من الوجه وبصمة الجهاز وشهادة توقيع.
--  (د) تقرير الامتثال الشرعي الدوري للبنك المركزي: يُحسب آلياً لأي فترة، ويصدره رئيس الهيئة نسخة مختومة تصل البنك المركزي.
-- الملف آمن للتكرار. الدوال المعاد تعريفها منسوخة من نسختها الحية (مطابقة بالـmd5 في 15 تشرين الثاني 2026) مع التعديل فقط.
-- ═══════════════════════════════════════════════════════════════════════

-- ── أدوات مشتركة ──
-- اسم الأصل في الوثائق: المنظومة (الطاقة الشمسية) أو الأجهزة (البيطري)
create or replace function public._isl_noun(a applications) returns text
language sql immutable as $f$ select case when a.program = 'vet' then 'الأجهزة' else 'المنظومة' end $f$;

-- وصف الأصل المموَّل: عنوان عرض المورد، أو مشروع البيطري وبنوده
create or replace function public._isl_asset(a applications) returns text
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    (select title from supplier_offers where id = a.offer_id),
    (select coalesce(nullif(vp.title, ''), t.label, 'المشروع البيطري') || ' — ' ||
        coalesce((select string_agg((i->>'qty') || ' × ' || (i->>'name'), '، ') from jsonb_array_elements(coalesce(vp.items, '[]'::jsonb)) i), 'الأجهزة والمعدات')
        || coalesce(' (عرض المورد رقم ' || nullif(vp.quote_no, '') || ')', '')
     from vet_projects vp left join vet_project_types t on t.code = vp.project_type where vp.application_id = a.id),
    case when a.program = 'vet' then 'الأجهزة والمعدات حسب عرض المورد' else 'المنظومة المختارة' end) $f$;

-- ما يحتاجه مستند المرحلة 25 للطلب الإسلامي
create or replace function public._isl_esign_info(a applications) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare t text; p islamic_products; ty sharia_contract_types; pr islamic_app_docs; b sharia_boards;
begin
  t := _isl_type(a);
  if t is null then return null; end if;
  select * into p from islamic_products where id = a.product_id;
  select * into ty from sharia_contract_types where code = t;
  select * into b from sharia_boards where id = p.board_id;
  pr := _isl_doc(a.id, 'promise');
  return jsonb_build_object('type', t, 'type_name', ty.name, 'product', p.name, 'resolution', a.sharia_resolution, 'two_phase', _isl_two_phase(t),
    'noun', _isl_noun(a), 'asset', _isl_asset(a), 'board', b.name, 'late_rule', b.late_rule,
    'promise_code', pr.verify_code, 'promise_at', pr.at, 'promise_title', pr.title, 'calc', pr.body->'calc',
    'contract_name', case t when 'MRB' then 'عقد بيع المرابحة' when 'IJM' then 'عقد الإجارة المنتهية بالتمليك' else 'العقد المعتمد' end);
end $f$;

-- ═══ (أ) المرحلة 25 للطلب الإسلامي: التعهدات والضمانات ═══
-- (أ-2) المرحلة 25 للطلب الإسلامي
CREATE OR REPLACE FUNCTION public.esign_prepare(p_app uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a applications; me profiles; c profiles; r esign_requests; fd app_documents;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  if me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
  if me.role not in ('bank_cs','bank_branch_mgr') then raise exception 'إرسال العقد للتوقيع من صلاحية خدمة الزبائن — العمليات الائتمانية'; end if;
  if me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.status not in ('active','returned') or a.stage <> 25 then raise exception 'التوقيع الإلكتروني للعقد في المرحلة 25 فقط'; end if;
  select * into c from profiles where id = a.citizen_id;
  select * into r from esign_requests where application_id = a.id order by created_at desc limit 1;
  select * into fd from app_documents where application_id = a.id and kind = 'kyc_face' order by created_at desc limit 1;
  return jsonb_build_object(
    'app', to_jsonb(a) - 'kyc',
    'borrower', jsonb_build_object('id', c.id, 'full_name', c.full_name, 'phone', c.phone, 'national_id', c.national_id,
      'governorate', c.governorate, 'city', c.city, 'address', c.address, 'employer', c.employer, 'mother_name', c.mother_name, 'birth_date', c.birth_date),
    'bank', (select name from orgs where id = a.bank_id),
    'branch', (select name from branches where id = a.branch_id),
    'supplier', (select name from orgs where id = a.supplier_id),
    'staff', jsonb_build_object('id', me.id, 'title', _role_title(me.role), 'code', me.staff_code),
    'islamic', _isl_esign_info(a),   -- الجلسة 43: الطلب الإسلامي يوقّع التعهدات والضمانات فقط
    'face', case when fd.id is null then null else jsonb_build_object('id', fd.id, 'data', fd.data) end,
    'request', case when r.id is null then null else jsonb_build_object('id', r.id, 'session_id', r.session_id, 'status',
      case when r.status = 'sent' and r.expires_at < now() then 'expired' else r.status end) end);
end $function$;

CREATE OR REPLACE FUNCTION public.esign_record(p_secret text, p_app uuid, p_data jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a applications; me profiles; rid uuid;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  update esign_requests set status = 'superseded', updated_at = now() where application_id = a.id and status = 'sent';
  insert into esign_requests(application_id, session_id, status, signing_url, expires_at, document_sha256, face_doc, created_by, created_by_title)
  values (a.id, (p_data->>'session_id')::uuid, 'sent', p_data->>'signing_url', (p_data->>'expires_at')::timestamptz, p_data->>'document_sha256',
    nullif(p_data->>'face_doc', '')::uuid, me.id, _role_title(me.role))
  returning id into rid;
  perform _ev(a.id, a.stage, case when _isl_type(a) is not null then 'إرسال التعهدات والضمانات إلى المقترض للتوقيع الإلكتروني (تمويل إسلامي — العقد بعد التملّك والقبض)' else 'إرسال عقد التمويل والكمبيالة إلى المقترض للتوقيع الإلكتروني' end,
    'يوقّع المقترض من هاتفه: القراءة والموافقة، التحقق من الوجه وكشف الحيوية، ثم بصمة الجهاز — بصمة العقد ' || left(coalesce(p_data->>'document_sha256', ''), 16));
  return jsonb_build_object('id', rid);
end $function$;

CREATE OR REPLACE FUNCTION public.esign_apply(p_secret text, p_session uuid, p_event text, p_data jsonb DEFAULT '{}'::jsonb, p_pdf text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare r esign_requests; a applications; c profiles; did uuid; act text; nt text;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into r from esign_requests where session_id = p_session for update;
  if r.id is null then return jsonb_build_object('ok', true, 'ignored', 'unknown_session'); end if;
  if r.status in ('completed') then return jsonb_build_object('ok', true, 'ignored', 'already_completed'); end if;
  select * into a from applications where id = r.application_id;
  select * into c from profiles where id = a.citizen_id;

  if p_event = 'signature.completed' then
    if p_pdf is null or p_pdf !~ '^data:application/pdf;base64,' then raise exception 'العقد الموقّع مفقود'; end if;
    insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
    values (a.id, 'contract_signed', 'esign', 'application/pdf', p_pdf, length(p_pdf), encode(extensions.digest(p_pdf, 'sha256'), 'hex'),
      jsonb_build_object('session_id', p_session, 'signed_document_sha256', p_data->>'signed_document_sha256', 'certificate_serial', p_data->>'certificate_serial',
        'qualified', coalesce((p_data->>'qualified_certificate')::boolean, false), 'server_at', now(),
        'title', case when _isl_type(a) is not null then 'التعهدات والضمانات — موقّعة إلكترونياً' end),
      c.id, 'المقترض — توقيع إلكتروني')
    returning id into did;
    update esign_requests set status = 'completed', signed_doc = did, signed_sha256 = p_data->>'signed_document_sha256', certificate_serial = p_data->>'certificate_serial',
      qualified = coalesce((p_data->>'qualified_certificate')::boolean, false), completed_at = coalesce((p_data->>'completed_at')::timestamptz, now()), updated_at = now()
    where id = r.id;
    act := case when _isl_type(a) is not null then 'توقيع المقترض التعهدات والضمانات إلكترونياً' else 'توقيع المقترض عقد التمويل والكمبيالة إلكترونياً' end;
    nt := 'تحقق من الوجه وكشف الحيوية وبصمة الجهاز — شهادة التوقيع ' || coalesce(p_data->>'certificate_serial', '') ||
      case when coalesce((p_data->>'qualified_certificate')::boolean, false) then '' else ' (جهة تصديق تجريبية)' end || ' — المستند الموقّع في «المستندات»';
  elsif p_event in ('session.expired','session.cancelled','session.manual_review','session.failed') then
    update esign_requests set status = case p_event when 'session.expired' then 'expired' when 'session.cancelled' then 'cancelled'
      when 'session.manual_review' then 'manual_review' else 'failed' end, note = coalesce(p_data->>'note', note), updated_at = now() where id = r.id;
    if r.status <> 'sent' then return jsonb_build_object('ok', true); end if;
    act := case p_event when 'session.expired' then 'انتهت صلاحية رابط التوقيع الإلكتروني دون توقيع'
      when 'session.cancelled' then 'إلغاء طلب التوقيع الإلكتروني' when 'session.manual_review' then 'طلب المقترض توقيع العقد حضورياً في الفرع'
      else 'تعذّر إتمام التوقيع الإلكتروني' end;
    nt := p_data->>'note';
  else return jsonb_build_object('ok', true, 'ignored', p_event); end if;

  if auth.uid() is not null then perform _ev(a.id, a.stage, act, nt);
  else
    insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role, actor_title)
    values (a.id, a.stage, act, nt, c.id, c.full_name, 'citizen', 'المقترض — عبر خدمة التوقيع الإلكتروني');
  end if;
  update applications set updated_at = now() where id = a.id;
  return jsonb_build_object('ok', true, 'doc', did);
end $function$;

CREATE OR REPLACE FUNCTION public._borrower_esign_ask()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a applications;
begin
  if new.status <> 'sent' then return new; end if;
  select * into a from applications where id = new.application_id;
  if a.citizen_id is null then return new; end if;
  insert into notifications(user_id, kind, title, body, ref_id)
  values (a.citizen_id, 'esign', case when _isl_type(a) is not null then 'التعهدات والضمانات جاهزة للتوقيع الإلكتروني' else 'عقد تمويلك جاهز للتوقيع الإلكتروني' end,
    'افتح «طلبي» ووقّع من هاتفك' || coalesce(' قبل ' || to_char(new.expires_at at time zone 'Asia/Baghdad', 'YYYY-MM-DD'), '') || '.', a.id);
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.esign_status(p_app uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a applications; me profiles; r esign_requests; face uuid;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  if not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('cbi','integrity', 'audit','admin')) then raise exception 'غير مخوّل'; end if;
  select * into r from esign_requests where application_id = p_app order by created_at desc limit 1;
  select id into face from app_documents where application_id = p_app and kind = 'kyc_face' order by created_at desc limit 1;
  if r.status = 'sent' and r.expires_at < now() then r.status := 'expired'; end if;
  return jsonb_build_object('face_doc', face, 'islamic', _isl_type(a) is not null, 'request', case when r.id is null then null else jsonb_build_object(
    'id', r.id, 'status', r.status, 'expires_at', r.expires_at, 'created_at', r.created_at, 'created_by_title', r.created_by_title,
    'completed_at', r.completed_at, 'signed_doc', r.signed_doc, 'certificate_serial', r.certificate_serial, 'qualified', r.qualified,
    'document_sha256', r.document_sha256, 'signed_sha256', r.signed_sha256, 'note', r.note) end);
end $function$;

-- (أ-4) نص تأكيد الإنجاز في المرحلتين 25 و26 للطلب الإسلامي
CREATE OR REPLACE FUNCTION public.stage_confirm_text(p_app uuid)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select case when a.stage in (25, 26) and _isl_type(a) is not null
    then case a.stage when 25 then 'تم توقيع التعهدات والضمانات' else 'تم تدقيق التعهدات والضمانات' end
    else replace(s.confirm_text, '{pay}', coalesce((
    select case p.method when 'zaincash' then 'زين كاش' when 'qicard' then 'كي كارد' when 'asiapay' then 'آسيا باي'
      when 'fastpay' then 'فاست باي' when 'fib' then 'FIB' when 'visa' then 'Visa' when 'mastercard' then 'Mastercard' else 'وسيلة الدفع الإلكتروني' end
    from payments p where p.application_id = a.id and p.status = 'paid' order by p.paid_at desc limit 1), 'وسيلة الدفع')) end
  from applications a join stages s on s.n = a.stage where a.id = p_app $function$;

-- ═══ (ب) المنتجات الإسلامية في مسار البيطري ═══
-- (ب-1) الحرّاس على المسارين
CREATE OR REPLACE FUNCTION public._isl_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_isl boolean; p islamic_products; v islamic_contract_versions; t text; k jsonb; rc islamic_app_docs; ct islamic_app_docs;
begin
  if new.stage <= old.stage then return new; end if;   -- الجلسة 43: مسارا الطاقة الشمسية والبيطري
  select coalesce(is_islamic, false) into v_isl from orgs where id = new.bank_id;
  if not coalesce(v_isl, false) then return new; end if;

  -- (أ) الإرسال إلى المصرف الإسلامي
  if old.stage <= 5 and new.stage > 5 then
    if new.product_id is null then
      raise exception 'لا يُرسل الطلب إلى مصرف إسلامي دون منتج معتمد شرعاً — اختر صيغة التمويل في خطوة «المصرف»'; end if;
    select * into p from islamic_products where id = new.product_id;
    if p.status not in ('approved', 'conditional') then
      raise exception 'المنتج «%» لم يعد معتمداً شرعاً (%) — اختر منتجاً آخر', p.name, _sh_status_label(p.status); end if;
    if p.sector is distinct from (case when new.program = 'vet' then 'vet' else 'pv' end) then
      raise exception 'المنتج «%» ليس من منتجات %', p.name, case when new.program = 'vet' then 'المشاريع البيطرية' else 'الطاقة الشمسية' end; end if;
    if new.contract_version_id is distinct from p.approved_version_id then
      raise exception 'اعتمدت الهيئة نسخة جديدة من عقد «%» — افتح «اقرأ العقد» واختر المنتج من جديد', p.name; end if;
    select * into v from islamic_contract_versions where id = new.contract_version_id;
    if new.contract_sha256 is distinct from v.sha256 or _sh_sha(v.clauses) is distinct from v.sha256 then
      raise exception 'بصمة العقد في الطلب لا تطابق النسخة المعتمدة'; end if;
    if _isl_two_phase(p.contract_type) then
      if not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'promise' and not void and version_id = v.id) then
        raise exception 'وقّع % أولاً', case when p.contract_type = 'IJM' then 'الوعد بالاستئجار' else 'طلب الشراء والوعد غير الملزم' end; end if;
    elsif not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'contract' and not void and version_id = v.id) then
      raise exception 'وقّع العقد المعتمد أولاً'; end if;
    -- القسط والمدة من تسعير المنتج نفسه، فيكون جدول الأقساط = الثمن المكتوب في العقد
    k := _sh_calc(p, new.amount, new.term_months);
    new.term_months := (k->>'term')::int; new.monthly_installment := round((k->>'installment')::numeric);
    -- الجلسة 43: في البيطري الإسلامي الثمن ثابت في العقد ويُقسَّط على المدة كلها (لا مهلة تغيّر الثمن)
    if new.program = 'vet' then new.grace_months := 0; new.margin := (k->>'rate')::numeric; end if;
  end if;

  if new.product_id is null then return new; end if;   -- طلبات قديمة قبل الجلسة 39
  t := (select contract_type from islamic_products where id = new.product_id);

  -- (ب) لا يبيع المصرف ما لا يملك: فاتورة المورد باسم المصرف قبل إنجاز التركيب
  if _isl_two_phase(t) and old.stage <= 31 and new.stage > 31
     and not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'invoice' and not void) then
    raise exception 'صيغة %: لا يُنجز التركيب قبل فاتورة المورد باسم المصرف — يصدرها المورد من ملف الطلب', case t when 'IJM' then 'الإجارة' else 'المرابحة' end; end if;

  -- (ج) تنفيذ التمويل وجدول الأقساط بعد عقد البيع/الإجارة الموقّع بعد القبض
  if old.stage <= 33 and new.stage > 33 then
    ct := _isl_doc(new.id, 'contract');
    if ct.id is null then
      raise exception '%', case when _isl_two_phase(t) then 'لم يوقّع المقترض ' || case t when 'IJM' then 'عقد الإجارة' else 'عقد بيع المرابحة' end
        || ' بعد — وصله إشعار «' || _isl_noun(new) || ' صارت ملك المصرف — وقّع»، ويوقّعه من «طلبي». لا يُنفَّذ التمويل قبله' else 'لا يوجد عقد موقّع على هذا الطلب' end; end if;
    if _isl_two_phase(t) then
      rc := _isl_doc(new.id, 'receipt');
      if rc.id is null or ct.at < rc.at then raise exception 'العقد يجب أن يُوقَّع بعد محضر القبض — لا قبله'; end if;
    end if;
    if t = 'MSN' and (_isl_doc(new.id, 'shares')).id is null then raise exception 'صيغة المشاركة: سجّل حصة كل طرف أولاً'; end if;
  end if;
  return new;
end $function$;

-- (ب-2) محضر القبض والتحقق من الجدول على المسارين
CREATE OR REPLACE FUNCTION public._isl_after()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t text; me profiles; ct islamic_app_docs; rc islamic_app_docs; inv islamic_app_docs; tot numeric; cnt int; first_due date; tol numeric; body jsonb; bank text;
begin
  if new.stage <= old.stage or new.product_id is null then return new; end if;   -- الجلسة 43: والبيطري
  t := _isl_type(new);
  if t is null then return new; end if;
  select * into me from profiles where id = auth.uid();
  if _isl_two_phase(t) and old.stage <= 32 and new.stage > 32 and (_isl_doc(new.id, 'receipt')).id is null then
    inv := _isl_doc(new.id, 'invoice'); bank := (select name from orgs where id = new.bank_id);
    body := jsonb_build_object('asset', _isl_asset(new), 'supplier', (select name from orgs where id = new.supplier_id),
      'owner', bank, 'invoice_no', inv.body->>'invoice_no', 'site', concat_ws(' — ', new.governorate, new.city), 'by', me.full_name, 'by_title', _role_title(me.role),
      'date', to_char(now() at time zone 'Asia/Baghdad', 'YYYY-MM-DD'),
      'statement', replace(case when t = 'IJM' then 'استلم المصرف المنظومة وسُجّلت باسمه، وسُلّمت للمستأجر في موقعها' else 'استلم المصرف المنظومة وقبضها، وصارت ملكه وفي ضمانه' end, 'المنظومة', _isl_noun(new)));
    insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title)
    values (new.id, 'receipt', case when t = 'IJM' then 'محضر استلام وتسجيل الأصل باسم المصرف وتسليمه' else 'محضر استلام وقبض — ' || _isl_noun(new) || ' ملك المصرف' end,
      new.product_id, new.contract_version_id, new.contract_sha256, body, _isl_sha(body), new.amount, _isl_code(), me.id, me.full_name, _role_title(me.role));
    perform _ev(new.id, 32, case when t = 'IJM' then 'تسجيل الأصل باسم المصرف وتسليمه' else 'محضر القبض: ' || _isl_noun(new) || ' صارت ملك المصرف' end, 'بانتظار توقيع المقترض للعقد');
    insert into notifications(user_id, kind, title, body, ref_id)
    values (new.citizen_id, 'islamic', _isl_noun(new) || case when t = 'IJM' then ' صارت ملك المصرف — وقّع عقد الإجارة' else ' صارت ملك المصرف — وقّع عقد الشراء' end,
      'افتح «طلبي» واضغط «وقّع» — يستغرق دقيقة', new.id);
  end if;
  if old.stage <= 33 and new.stage > 33 then
    ct := _isl_doc(new.id, 'contract');
    select count(*), coalesce(sum(amount), 0), min(due_date) into cnt, tot, first_due from installments where application_id = new.id;
    if cnt > 0 and ct.id is not null then
      tol := greatest(cnt * 2, (ct.body->'calc'->>'total')::numeric * 0.0005);
      if abs(tot - (ct.body->'calc'->>'total')::numeric) > tol then
        raise exception 'مجموع الأقساط (%) لا يساوي الثمن المكتوب في العقد الموقّع (%) — لا يُصدر الجدول', _sh_fmt(tot), _sh_fmt((ct.body->'calc'->>'total')::numeric); end if;
      if t = 'IJM' then
        rc := _isl_doc(new.id, 'receipt');
        if first_due <= (rc.at at time zone 'Asia/Baghdad')::date then raise exception 'صيغة الإجارة: الأجرة تبدأ بعد التسليم لا قبله'; end if;
      end if;
      perform _ev(new.id, 33, 'تحقق آلي: جدول الأقساط = الثمن في العقد الموقّع', _sh_fmt(tot) || ' د.ع على ' || cnt || ' قسطاً · العقد ' || ct.verify_code);
    end if;
  end if;
  return new;
end $function$;

-- (ب-3) نص الوعد للمسارين
CREATE OR REPLACE FUNCTION public._isl_promise(a applications)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare p islamic_products; v islamic_contract_versions; k jsonb; o supplier_offers; bank text; sup text; res text; asset text; cl jsonb;
begin
  select * into p from islamic_products where id = a.product_id;
  select * into v from islamic_contract_versions where id = a.contract_version_id;
  select * into o from supplier_offers where id = a.offer_id;
  k := _sh_calc(p, a.amount, _isl_term(a));
  bank := (select name from orgs where id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid)); sup := coalesce((select name from orgs where id = a.supplier_id), 'المورد المعتمد');
  asset := _isl_asset(a);
  res := coalesce(a.sharia_resolution, (select code from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1), '—');
  if p.contract_type = 'IJM' then
    cl := jsonb_build_array(
      jsonb_build_object('n', 1, 'title', 'موضوع الوعد', 'text', format('أرغب أنا %s في أن يشتري %s «%s» من %s، ثم يؤجّرها لي إجارةً تنتهي بالتمليك بعد أن يتملّكها ويسلّمها.', a.citizen_name, bank, asset, sup)),
      jsonb_build_object('n', 2, 'title', 'الوعد غير ملزم', 'text', 'هذا وعد مني غير ملزم، ولا تنعقد الإجارة به. تنعقد الإجارة بعقد مستقل أوقّعه بعد أن تصير المنظومة ملك المصرف ومسجّلة باسمه وتُسلَّم لي.'),
      jsonb_build_object('n', 3, 'title', 'الأجرة المتوقعة', 'text', format('الأجرة الشهرية %s د.ع × %s شهراً، تبدأ بعد التسليم لا قبله. وتنتقل إليّ الملكية في آخر المدة بالشرط المذكور في عقد الإجارة.', _sh_fmt((k->>'installment')::numeric), k->>'term')),
      jsonb_build_object('n', 4, 'title', 'ضمان المنظومة قبل العقد', 'text', 'تبقى المنظومة في ضمان المصرف حتى توقيع عقد الإجارة، ويتحمّل المالك تلفها ما لم أتعدَّ أو أفرّط.'),
      jsonb_build_object('n', 5, 'title', 'المرجع', 'text', format('منتج «%s» المعتمد بقرار الهيئة الشرعية %s — نسخة العقد %s.', p.name, res, v.n)));
  else
    cl := jsonb_build_array(
      jsonb_build_object('n', 1, 'title', 'موضوع الوعد', 'text', format('أرغب أنا %s في أن يشتري %s «%s» من %s، ثم يبيعها لي مرابحةً بعد أن يتملّكها ويقبضها.', a.citizen_name, bank, asset, sup)),
      jsonb_build_object('n', 2, 'title', 'الوعد غير ملزم', 'text', 'هذا وعد مني غير ملزم، ولا ينعقد البيع به. ينعقد البيع بعقد مستقل أوقّعه بعد أن تصير المنظومة ملك المصرف وفي قبضه، وتصدر فاتورة المورد باسم المصرف.'),
      jsonb_build_object('n', 3, 'title', 'الكلفة والربح المعلن', 'text', format('كلفة المنظومة %s د.ع، والربح المعلن %s د.ع، فيكون ثمن البيع %s د.ع يُدفع %s د.ع شهرياً × %s شهراً. لا يتغير الربح المعلن عند العقد.',
        _sh_fmt((k->>'cost')::numeric), _sh_fmt((k->>'profit')::numeric), _sh_fmt((k->>'total')::numeric), _sh_fmt((k->>'installment')::numeric), k->>'term')),
      jsonb_build_object('n', 4, 'title', 'ضمان المنظومة قبل البيع', 'text', 'تبقى المنظومة في ملك المصرف وضمانه حتى أوقّع عقد البيع.'),
      jsonb_build_object('n', 5, 'title', 'المرجع', 'text', format('منتج «%s» المعتمد بقرار الهيئة الشرعية %s — نسخة العقد %s.', p.name, res, v.n)));
  end if;
  if a.program = 'vet' then cl := replace(cl::text, 'المنظومة', 'الأجهزة')::jsonb; end if;   -- الجلسة 43
  return jsonb_build_object('title', case when p.contract_type = 'IJM' then 'وعد بالاستئجار (غير ملزم)' else 'طلب شراء ووعد بالشراء (غير ملزم)' end,
    'clauses', cl, 'calc', k, 'product', p.name, 'type', p.contract_type, 'version', v.n, 'resolution', res);
end $function$;

-- (ب-4) معاينة العقد: الأجهزة والمورد في البيطري
CREATE OR REPLACE FUNCTION public.islamic_contract_preview(p_product uuid, p_amount numeric, p_term integer, p_offer uuid, p_app uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare p islamic_products; v islamic_contract_versions; t sharia_contract_types; b sharia_boards; me profiles; a applications; o supplier_offers; k jsonb; vars jsonb; res sharia_resolutions; v_place text;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'سجّل الدخول أولاً'; end if;
  select * into p from islamic_products where id = p_product;
  if p.id is null then raise exception 'المنتج غير موجود'; end if;
  if p_app is not null then
    select * into a from applications where id = p_app;
    if a.id is null or (a.citizen_id <> me.id and me.portal = 'citizen') then raise exception 'الطلب غير موجود'; end if;
    select * into v from islamic_contract_versions where id = coalesce(a.contract_version_id, p.approved_version_id);
    p_amount := coalesce(p_amount, a.amount); p_term := coalesce(p_term, a.term_months, (a.bank_choice->>'term_months')::int); p_offer := coalesce(p_offer, a.offer_id);
  else
    if p.status not in ('approved', 'conditional') then raise exception 'هذا المنتج غير معتمد شرعاً حالياً'; end if;
    select * into v from islamic_contract_versions where id = p.approved_version_id;
  end if;
  select * into t from sharia_contract_types where code = p.contract_type;
  select * into b from sharia_boards where id = p.board_id;
  select * into o from supplier_offers where id = p_offer;
  select * into res from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  k := _sh_calc(p, coalesce(p_amount, o.price, 0), p_term);
  v_place := coalesce(nullif(concat_ws(' — ', a.governorate, a.city), ''), nullif(concat_ws(' — ', me.governorate, me.city), ''), 'العنوان الذي يحدده المقترض في طلبه');
  vars := jsonb_build_object(
    'borrower_name', coalesce(a.citizen_name, me.full_name), 'borrower_nid', coalesce('••••' || right(coalesce(me.national_id, ''), 4), '—'),
    'bank_name', (select name from orgs where id = p.bank_id), 'asset', coalesce(o.title, case when a.id is not null then _isl_asset(a) end, case when p.sector = 'vet' then 'الأجهزة والمعدات حسب عرض المورد' end, 'المنظومة المختارة'),
    'supplier', coalesce((select name from orgs where id = coalesce(o.supplier_id, a.supplier_id)), 'المورد المعتمد'), 'place', v_place,
    'cost', _sh_fmt((k->>'cost')::numeric), 'profit', _sh_fmt((k->>'profit')::numeric), 'price_total', _sh_fmt((k->>'total')::numeric),
    'installment', _sh_fmt((k->>'installment')::numeric), 'term', k->>'term', 'rate', to_char((k->>'rate')::numeric, 'FM990.00'),
    'residual', _sh_fmt((k->>'residual')::numeric), 'board', b.name, 'resolution', coalesce(res.code, 'بانتظار القرار'), 'product', p.name,
    'date', to_char(now(), 'YYYY/MM/DD'), 'madhhab', _sh_madhhab_label(b.madhhab));
  return jsonb_build_object('product', p.name, 'type', t.code, 'type_name', t.name, 'bank', vars->>'bank_name', 'board', b.name, 'madhhab', _sh_madhhab_label(b.madhhab), 'marja', b.marja,
    'resolution', res.code, 'resolution_at', res.issued_at, 'conditions', res.conditions, 'conditional', res.decision = 'conditional',
    'version', v.n, 'sha256', v.sha256, 'calc', k,
    'summary', jsonb_build_array(
      jsonb_build_object('k', 'own', 'label', 'ما تملكه', 'text', _sh_fill(t.rules->'summary'->>'own', vars)),
      jsonb_build_object('k', 'when', 'label', 'متى تملكه', 'text', _sh_fill(t.rules->'summary'->>'when', vars)),
      jsonb_build_object('k', 'pay', 'label', 'ما تدفعه', 'text', _sh_fill(t.rules->'summary'->>'pay', vars)),
      jsonb_build_object('k', 'late', 'label', 'إن تأخرت', 'text', _sh_fill(t.rules->'summary'->>'late', vars)),
      jsonb_build_object('k', 'damage', 'label', 'من يتحمّل التلف', 'text', _sh_fill(t.rules->'summary'->>'damage', vars))),
    'clauses', coalesce((select jsonb_agg(jsonb_build_object('n', (c->>'n')::int, 'title', c->>'title', 'text', _sh_fill(c->>'text', vars)) order by (c->>'n')::int)
      from jsonb_array_elements(v.clauses) c), '[]'::jsonb));
end $function$;

-- (ب-5) فاتورة المورد باسم المصرف للمسارين
CREATE OR REPLACE FUNCTION public.islamic_supplier_invoice(p_app uuid, p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare me profiles; a applications; t text; v_no text := upper(trim(coalesce(p->>'invoice_no', ''))); v_amt numeric; d islamic_app_docs; bank text; body jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me.portal <> 'supplier' or me.org_id is distinct from a.supplier_id then raise exception 'الفاتورة يصدرها المورد صاحب العرض'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.role not in ('supplier_admin') then raise exception 'إصدار الفاتورة لمدير حساب المورد'; end if;
  t := _isl_type(a);
  if t is null or not _isl_two_phase(t) then raise exception 'هذا الطلب لا يحتاج فاتورة باسم المصرف'; end if;
  if a.stage not in (30, 31) then raise exception 'تُصدر الفاتورة بعد أمر الشراء من المصرف وقبل إنجاز التركيب'; end if;
  if length(v_no) < 3 then raise exception 'اكتب رقم الفاتورة'; end if;
  v_amt := coalesce(nullif(regexp_replace(coalesce(p->>'amount', ''), '[^0-9]', '', 'g'), '')::numeric, a.amount);
  if v_amt is distinct from a.amount::numeric then
    raise exception 'مبلغ الفاتورة يجب أن يساوي كلفة % الممولة في الطلب (%) د.ع', _isl_noun(a), _sh_fmt(a.amount); end if;
  bank := (select name from orgs where id = a.bank_id);
  body := jsonb_build_object('invoice_no', v_no, 'buyer', bank, 'seller', (select name from orgs where id = a.supplier_id),
    'asset', _isl_asset(a), 'amount', v_amt, 'date', to_char(now() at time zone 'Asia/Baghdad', 'YYYY-MM-DD'),
    'note', 'المشتري: ' || bank || ' — لا المقترض. يبيعها المصرف للمقترض بعد تملّكها وقبضها.');
  update islamic_app_docs set void = true, void_note = 'استُبدلت بفاتورة أحدث' where application_id = a.id and kind = 'invoice' and not void;
  insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title)
  values (a.id, 'invoice', 'فاتورة المورد باسم ' || bank, a.product_id, a.contract_version_id, a.contract_sha256, body, _isl_sha(body), v_amt, _isl_code(),
    me.id, me.full_name, _role_title(me.role)) returning * into d;
  perform _ev(a.id, a.stage, 'فاتورة المورد باسم المصرف', 'رقم ' || v_no || ' · ' || _sh_fmt(v_amt) || ' د.ع · المشتري ' || bank);
  perform _notify(a.bank_id, 'bank', 'islamic', 'فاتورة المورد باسم المصرف — ' || a.code, 'رقم ' || v_no || ' · ' || _sh_fmt(v_amt) || ' د.ع', a.id);
  return jsonb_build_object('id', d.id, 'invoice_no', v_no, 'amount', v_amt, 'verify_code', d.verify_code);
end $function$;

-- (ب-6) اختيار المنتج: من قطاع الطلب نفسه
CREATE OR REPLACE FUNCTION public.app_choose_product(p_app uuid, p_product uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a applications; p islamic_products; v islamic_contract_versions; v_bank uuid; res text;
begin
  select * into a from applications where id = p_app for update;
  if a.id is null or a.citizen_id <> auth.uid() then raise exception 'الطلب غير موجود'; end if;
  if a.stage > 5 then raise exception 'لا يمكن تغيير المنتج بعد إرسال الطلب للمصرف'; end if;
  v_bank := coalesce(nullif(a.bank_choice->>'bank_id', '')::uuid, a.bank_id);
  if p_product is null then
    update applications set product_id = null, contract_version_id = null, contract_sha256 = null, sharia_resolution = null, updated_at = now() where id = a.id;
    update islamic_app_docs set void = true, void_note = 'غيّر المقترض المنتج' where application_id = a.id and kind in ('promise', 'contract') and not void;
    return jsonb_build_object('ok', true);
  end if;
  select * into p from islamic_products where id = p_product;
  if p.id is null or p.bank_id is distinct from v_bank then raise exception 'المنتج لا يخص المصرف المختار في طلبك'; end if;
  if p.status not in ('approved', 'conditional') then raise exception 'هذا المنتج غير معتمد شرعاً حالياً — اختر منتجاً آخر'; end if;
  if p.sector is distinct from (case when a.program = 'vet' then 'vet' else 'pv' end) then   -- الجلسة 43
    raise exception 'هذا المنتج ليس من منتجات %', case when a.program = 'vet' then 'المشاريع البيطرية' else 'الطاقة الشمسية' end; end if;
  select * into v from islamic_contract_versions where id = p.approved_version_id;
  select code into res from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  -- تغيير المنتج أو نسخته يُبطل التوقيع السابق قبل الإرسال
  if a.product_id is distinct from p.id or a.contract_version_id is distinct from v.id then
    update islamic_app_docs set void = true, void_note = 'غيّر المقترض المنتج أو نسخة العقد' where application_id = a.id and kind in ('promise', 'contract') and not void;
  end if;
  update applications set product_id = p.id, contract_version_id = v.id, contract_sha256 = v.sha256, sharia_resolution = res, updated_at = now() where id = a.id;
  insert into application_events(application_id, stage, action, actor_name, note)
  select a.id, a.stage, 'اختيار المنتج الإسلامي: ' || p.name, a.citizen_name, 'نسخة العقد ' || v.n || ' · قرار ' || coalesce(res, '—') || ' · البصمة ' || left(v.sha256, 16) || '…'
  where to_regclass('public.application_events') is not null;
  return jsonb_build_object('ok', true, 'product', p.name, 'resolution', res, 'version', v.n, 'sha256', v.sha256);
end $function$;

-- (ب-9) التوقيع: رسالة الأصل للمسارين
CREATE OR REPLACE FUNCTION public.islamic_sign(p_app uuid, p_kind text, p_otp text, p_data jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
declare me profiles; a applications; p islamic_products; v islamic_contract_versions; t text; txt jsonb; body jsonb; d islamic_app_docs;
  pr islamic_app_docs; inv islamic_app_docs; rc islamic_app_docs; v_code text; v_title text; spec jsonb; f text; v_client numeric; v_pct numeric;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a.id is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح — لم يتم التوقيع'; end if;
  t := _isl_type(a);
  if t is null then raise exception 'ليس طلب تمويل إسلامي — اختر منتجاً معتمداً شرعاً أولاً'; end if;
  select * into p from islamic_products where id = a.product_id;
  select * into v from islamic_contract_versions where id = a.contract_version_id;
  -- النسخة في الطلب يجب أن تكون سليمة (بصمتها = بصمة بنودها) ومطابقة لما حُفظ لحظة الاختيار
  if v.id is null or v.sha256 is distinct from a.contract_sha256 or _sh_sha(v.clauses) is distinct from v.sha256 then
    raise exception 'بصمة نسخة العقد في طلبك لا تطابق النسخة المعتمدة — اختر المنتج من جديد'; end if;

  if p_kind = 'promise' then
    if not _isl_two_phase(t) then raise exception 'هذه الصيغة توقّع عقدها مباشرة دون وعد'; end if;
    if a.stage > 5 then raise exception 'وُقّع الوعد وأُرسل الطلب'; end if;
  elsif p_kind = 'contract' then
    if _isl_two_phase(t) then
      pr := _isl_doc(a.id, 'promise'); inv := _isl_doc(a.id, 'invoice'); rc := _isl_doc(a.id, 'receipt');
      if pr.id is null then raise exception 'لا يوجد وعد موقّع على هذا الطلب'; end if;
      if inv.id is null or rc.id is null or a.stage < 33 then
        raise exception 'يُوقَّع العقد بعد أن يتملّك المصرف % ويقبضها (فاتورة المورد باسم المصرف ومحضر الاستلام) — سنخبرك فور ذلك', _isl_noun(a); end if;
      if (_isl_doc(a.id, 'contract')).id is not null then raise exception 'وقّعت العقد سابقاً'; end if;
    else
      if a.stage > 5 then raise exception 'يُوقَّع العقد عند إرسال الطلب'; end if;
    end if;
  else raise exception 'نوع التوقيع غير معروف'; end if;

  -- عند الإرسال: المنتج يجب أن يكون معتمداً ونافذاً ونسخته هي المعتمدة الآن
  if a.stage <= 5 then
    if p.status not in ('approved', 'conditional') then raise exception 'المنتج «%» لم يعد معتمداً شرعاً (%) — اختر منتجاً آخر', p.name, _sh_status_label(p.status); end if;
    if p.approved_version_id is distinct from v.id then
      raise exception 'اعتمدت الهيئة نسخة جديدة من عقد «%» — افتح «اقرأ العقد» واختر المنتج من جديد', p.name; end if;
  end if;

  txt := islamic_sign_text(a.id, p_kind);
  -- المرابحة: الثمن في العقد = الكلفة (فاتورة المورد) + الربح المعلن في الوعد
  if p_kind = 'contract' and _isl_two_phase(t) then
    if (txt->'calc'->>'cost')::numeric is distinct from inv.amount then
      raise exception 'كلفة المنظومة في العقد (%) لا تطابق فاتورة المورد (%) — راجع المصرف', _sh_fmt((txt->'calc'->>'cost')::numeric), _sh_fmt(inv.amount); end if;
    if round((txt->'calc'->>'profit')::numeric) is distinct from round((pr.body->'calc'->>'profit')::numeric)
       or round((txt->'calc'->>'total')::numeric) is distinct from round((txt->'calc'->>'cost')::numeric + (txt->'calc'->>'profit')::numeric) then
      raise exception 'الثمن في العقد لا يساوي الكلفة + الربح المعلن في الوعد — راجع المصرف'; end if;
  end if;
  -- السَّلَم: السلعة موصوفة بالحقول الإلزامية
  if p_kind = 'contract' and t = 'SLM' then
    spec := coalesce(p_data->'spec', '{}'::jsonb);
    foreach f in array array['goods', 'qty', 'quality', 'delivery_date', 'delivery_place'] loop
      if length(trim(coalesce(spec->>f, ''))) < 1 then
        raise exception 'صف السلعة كاملة: % ناقص', case f when 'goods' then 'النوع' when 'qty' then 'الكمية' when 'quality' then 'الجودة' when 'delivery_date' then 'موعد التسليم' else 'مكان التسليم' end; end if;
    end loop;
    txt := txt || jsonb_build_object('spec', spec);
  end if;
  -- المشاركة المتناقصة: حصة كل طرف
  if p_kind = 'contract' and t = 'MSN' then
    v_client := nullif(regexp_replace(coalesce(p_data->>'client_share', ''), '[^0-9]', '', 'g'), '')::numeric;
    if v_client is null or v_client <= 0 then raise exception 'اكتب حصتك في رأس مال الشركة بالدينار'; end if;
    v_pct := round(a.amount * 100.0 / (a.amount + v_client), 2);
    txt := txt || jsonb_build_object('shares', jsonb_build_object('bank', a.amount, 'client', v_client, 'bank_pct', v_pct, 'client_pct', 100 - v_pct, 'units', a.term_months));
  end if;

  body := jsonb_build_object('title', txt->>'title', 'clauses', txt->'clauses', 'calc', txt->'calc', 'spec', txt->'spec', 'shares', txt->'shares',
    'borrower', a.citizen_name, 'app', a.code, 'bank', (select name from orgs where id = a.bank_id), 'product', p.name, 'type', t, 'version', v.n, 'signed_at', now());
  update islamic_app_docs set void = true, void_note = 'استُبدل بتوقيع أحدث' where application_id = a.id and kind = p_kind and not void;
  v_code := _isl_code(); v_title := txt->>'title';
  insert into islamic_app_docs(application_id, kind, n, title, product_id, version_id, version_sha256, resolution, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title, signed_via)
  values (a.id, p_kind, coalesce((select max(n) from islamic_app_docs where application_id = a.id and kind = p_kind), 0) + 1, v_title, p.id, v.id, v.sha256,
    coalesce(a.sharia_resolution, txt->>'resolution'), body, _isl_sha(body), (txt->'calc'->>'total')::numeric, v_code, me.id, me.full_name, 'المقترض', 'رمز تحقق على هاتف المقترض')
  returning * into d;
  if t = 'MSN' and p_kind = 'contract' then
    update islamic_app_docs set void = true where application_id = a.id and kind = 'shares' and not void;
    insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, actor_id, actor_name, actor_title)
    values (a.id, 'shares', 'سجل حصص الشركة', p.id, v.id, v.sha256, txt->'shares', _isl_sha(txt->'shares'), a.amount, me.id, me.full_name, 'المقترض');
  end if;
  perform _ev(a.id, a.stage, 'توقيع ' || v_title,
    'المنتج ' || p.name || ' · نسخة العقد ' || v.n || ' · قرار ' || coalesce(d.resolution, '—') || ' · بصمة النص ' || left(d.doc_sha256, 16) || '… · رمز التحقق ' || v_code);
  if p_kind = 'contract' and _isl_two_phase(t) then
    perform _notify(a.bank_id, 'bank', 'islamic', 'وقّع المقترض ' || v_title || ' — ' || a.code, 'يمكن الآن تنفيذ التمويل وإصدار جدول الأقساط (المرحلة 33)', a.id);
  end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'title', d.title, 'verify_code', d.verify_code, 'doc_sha256', d.doc_sha256, 'at', d.at);
end $function$;

-- ═══ (ج) توقيع رئيس الهيئة قراراته عبر خدمة التوقيع الإلكتروني ═══
-- القرار يصدر ونافذ برمز التحقق (كما في الجلسة 39). ثم يوقّعه الرئيس توقيعاً إلكترونياً موثوقاً:
-- قراءة نص القرار ← مطابقة الوجه مع صورته المرجعية وكشف الحيوية ← بصمة الجهاز ← شهادة توقيع ونسخة PDF موقّعة.
alter table public.sharia_resolutions add column if not exists esign_status text;
alter table public.sharia_resolutions add column if not exists esign_session uuid;
alter table public.sharia_resolutions add column if not exists esign_url text;
alter table public.sharia_resolutions add column if not exists esign_expires timestamptz;
alter table public.sharia_resolutions add column if not exists esign_doc_sha256 text;
alter table public.sharia_resolutions add column if not exists esign_signed_sha256 text;
alter table public.sharia_resolutions add column if not exists esign_cert text;
alter table public.sharia_resolutions add column if not exists esign_qualified boolean;
alter table public.sharia_resolutions add column if not exists esign_at timestamptz;
alter table public.sharia_resolutions add column if not exists esign_note text;
do $$ begin
  alter table public.sharia_resolutions add constraint sharia_resolutions_esign_status_check
    check (esign_status is null or esign_status in ('sent', 'signed', 'expired', 'cancelled', 'failed', 'manual_review'));
exception when duplicate_object then null; end $$;
create unique index if not exists sharia_resolutions_esign_session on public.sharia_resolutions(esign_session) where esign_session is not null;

-- النسخة الموقّعة (PDF) — تُحفظ كما وصلت من خدمة التوقيع
create table if not exists public.sharia_resolution_pdfs (
  resolution_id uuid primary key references public.sharia_resolutions(id) on delete cascade,
  data text not null, bytes int, sha256 text, at timestamptz not null default now());
alter table public.sharia_resolution_pdfs enable row level security;

-- الصورة المرجعية لوجه الرئيس (صورة البطاقة الوطنية أو صورة حضورية) — تُستخدم للمطابقة عند كل توقيع
create table if not exists public.sharia_signer_faces (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  data text not null, sha256 text, at timestamptz not null default now());
alter table public.sharia_signer_faces enable row level security;

create or replace function public.sharia_face_set(p_data text) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'الصورة المرجعية للتوقيع لرئيس الهيئة'; end if;
  if coalesce(p_data, '') !~ '^data:image/(jpeg|png|webp);base64,' then raise exception 'الصورة المرجعية يجب أن تكون صورة'; end if;
  if length(p_data) > 3000000 then raise exception 'الصورة كبيرة — صوّرها من جديد'; end if;
  insert into sharia_signer_faces(profile_id, data, sha256, at) values (me.id, p_data, encode(extensions.digest(p_data, 'sha256'), 'hex'), now())
  on conflict (profile_id) do update set data = excluded.data, sha256 = excluded.sha256, at = now();
  return jsonb_build_object('ok', true, 'at', now());
end $f$;

create or replace function public.sharia_face_status() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; f sharia_signer_faces;
begin
  me := _sh_me();
  select * into f from sharia_signer_faces where profile_id = me.id;
  return jsonb_build_object('has', f.profile_id is not null, 'at', f.at, 'data', case when me.role = 'sharia_head' then f.data end);
end $f$;

-- ما يحتاجه الخادم لتوليد مستند القرار وإرساله للتوقيع
create or replace function public.sharia_esign_prepare(p_res uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; r sharia_resolutions; p islamic_products; b sharia_boards; v islamic_contract_versions; f sharia_signer_faces;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'توقيع القرارات لرئيس الهيئة'; end if;
  select * into r from sharia_resolutions where id = p_res;
  if r.id is null then raise exception 'القرار غير موجود'; end if;
  if r.signed_by is distinct from me.id then raise exception 'يوقّع القرار الرئيس الذي أصدره'; end if;
  select * into p from islamic_products where id = r.product_id;
  select * into b from sharia_boards where id = r.board_id;
  select * into v from islamic_contract_versions where id = r.version_id;
  select * into f from sharia_signer_faces where profile_id = me.id;
  return jsonb_build_object(
    'res', jsonb_build_object('id', r.id, 'code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision), 'body', r.body,
      'conditions', r.conditions, 'votes', r.votes, 'dissent', r.dissent, 'version_sha256', r.version_sha256, 'seal', r.seal, 'issued_at', r.issued_at,
      'signed_via', r.signed_via, 'esign_status', case when r.esign_status = 'sent' and r.esign_expires < now() then 'expired' else r.esign_status end,
      'esign_session', r.esign_session),
    'product', jsonb_build_object('code', p.code, 'name', p.name, 'type', p.contract_type, 'type_name', (select name from sharia_contract_types where code = p.contract_type),
      'sector', _sh_sector_label(p.sector, p.subsector), 'bank', (select name from orgs where id = p.bank_id)),
    'version', jsonb_build_object('n', v.n, 'sha256', v.sha256, 'clauses', coalesce(jsonb_array_length(v.clauses), 0)),
    'board', jsonb_build_object('name', b.name, 'madhhab', _sh_madhhab_label(b.madhhab), 'marja', b.marja),
    'head', jsonb_build_object('id', me.id, 'full_name', me.full_name, 'phone', me.phone, 'national_id', me.national_id, 'code', me.staff_code),
    'face', case when f.profile_id is null then null else jsonb_build_object('data', f.data, 'at', f.at) end);
end $f$;

create or replace function public.sharia_esign_record(p_secret text, p_res uuid, p_data jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; r sharia_resolutions;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  me := _sh_me();
  select * into r from sharia_resolutions where id = p_res for update;
  if r.id is null or me.role <> 'sharia_head' or r.signed_by is distinct from me.id then raise exception 'غير مخوّل'; end if;
  update sharia_resolutions set esign_status = 'sent', esign_session = (p_data->>'session_id')::uuid, esign_url = p_data->>'signing_url',
    esign_expires = (p_data->>'expires_at')::timestamptz, esign_doc_sha256 = p_data->>'document_sha256', esign_note = null
  where id = r.id;
  perform _sh_log(r.product_id, 'إرسال القرار ' || r.code || ' للتوقيع الإلكتروني', 'بصمة المستند ' || left(coalesce(p_data->>'document_sha256', ''), 16));
  return jsonb_build_object('ok', true);
end $f$;

-- أحداث خدمة التوقيع لقرارات الهيئة (يستدعيها الخادم بعد التحقق من توقيع HMAC)
create or replace function public.sharia_esign_apply(p_secret text, p_session uuid, p_event text, p_data jsonb default '{}'::jsonb, p_pdf text default null) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare r sharia_resolutions; p islamic_products;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into r from sharia_resolutions where esign_session = p_session for update;
  if r.id is null then return jsonb_build_object('ok', true, 'ignored', 'unknown_session'); end if;
  if r.esign_status = 'signed' then return jsonb_build_object('ok', true, 'ignored', 'already_signed'); end if;
  select * into p from islamic_products where id = r.product_id;
  if p_event = 'signature.completed' then
    if p_pdf is null or p_pdf !~ '^data:application/pdf;base64,' then raise exception 'القرار الموقّع مفقود'; end if;
    insert into sharia_resolution_pdfs(resolution_id, data, bytes, sha256, at) values (r.id, p_pdf, length(p_pdf), encode(extensions.digest(p_pdf, 'sha256'), 'hex'), now())
    on conflict (resolution_id) do update set data = excluded.data, bytes = excluded.bytes, sha256 = excluded.sha256, at = now();
    update sharia_resolutions set esign_status = 'signed', esign_signed_sha256 = p_data->>'signed_document_sha256', esign_cert = p_data->>'certificate_serial',
      esign_qualified = coalesce((p_data->>'qualified_certificate')::boolean, false), esign_at = coalesce((p_data->>'completed_at')::timestamptz, now()), esign_url = null
    where id = r.id;
    insert into sharia_log(product_id, at, actor_name, actor_side, action, note)
    values (r.product_id, now(), r.signed_by_name, 'board', 'توقيع إلكتروني موثوق للقرار ' || r.code,
      'تحقق من الوجه وكشف الحيوية وبصمة الجهاز — شهادة ' || coalesce(p_data->>'certificate_serial', '') ||
      case when coalesce((p_data->>'qualified_certificate')::boolean, false) then '' else ' (جهة تصديق تجريبية)' end);
    perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_resolution', 'وُقّع القرار ' || r.code || ' إلكترونياً من رئيس الهيئة', p.name, r.product_id);
    perform _sh_notify(p.bank_id, 'bank', array['bank_islamic_products', 'bank_md'], 'sharia_bank', 'وُقّع القرار ' || r.code || ' إلكترونياً', p.name || ' — النسخة الموقّعة في سجل المنتج', r.product_id);
  elsif p_event in ('session.expired', 'session.cancelled', 'session.manual_review', 'session.failed') then
    update sharia_resolutions set esign_status = case p_event when 'session.expired' then 'expired' when 'session.cancelled' then 'cancelled'
      when 'session.manual_review' then 'manual_review' else 'failed' end, esign_note = p_data->>'note', esign_url = null where id = r.id;
  else return jsonb_build_object('ok', true, 'ignored', p_event); end if;
  return jsonb_build_object('ok', true, 'resolution', r.code);
end $f$;

-- من يرى النسخة الموقّعة: الهيئة، البنك المركزي، الجهات الرقابية، ومصرف المنتج
create or replace function public._sh_res_can_see(r sharia_resolutions) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from profiles me where me.id = auth.uid() and not coalesce(me.disabled, false) and (
    me.portal in ('sharia', 'cbi', 'audit', 'integrity', 'admin')
    or (me.portal = 'bank' and me.org_id = (select bank_id from islamic_products where id = r.product_id)))) $f$;

create or replace function public.sharia_resolution_pdf(p_res uuid) returns text
language plpgsql stable security definer set search_path to 'public' as $f$
declare r sharia_resolutions; d text;
begin
  select * into r from sharia_resolutions where id = p_res;
  if r.id is null or not _sh_res_can_see(r) then raise exception 'غير مخوّل'; end if;
  select data into d from sharia_resolution_pdfs where resolution_id = r.id;
  if d is null then raise exception 'لم يُوقَّع هذا القرار إلكترونياً بعد'; end if;
  return d;
end $f$;

-- حالة التوقيع الإلكتروني لكل القرارات (للهيئة والبنك المركزي)
create or replace function public.sharia_esign_list() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal not in ('sharia', 'cbi', 'audit', 'integrity', 'admin') then raise exception 'غير مخوّل'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code,
      'status', case when r.esign_status = 'sent' and r.esign_expires < now() then 'expired' else r.esign_status end,
      'at', r.esign_at, 'cert', r.esign_cert, 'qualified', r.esign_qualified, 'expires', r.esign_expires,
      'url', case when me.id = r.signed_by and r.esign_status = 'sent' and r.esign_expires > now() then r.esign_url end,
      'mine', me.id = r.signed_by) order by r.issued_at desc) from sharia_resolutions r), '[]'::jsonb);
end $f$;

revoke all on function public.sharia_face_set(text), public.sharia_face_status(), public.sharia_esign_prepare(uuid), public.sharia_esign_record(text, uuid, jsonb),
  public.sharia_esign_apply(text, uuid, text, jsonb, text), public.sharia_resolution_pdf(uuid), public.sharia_esign_list(), public._sh_res_can_see(sharia_resolutions) from public, anon;
grant execute on function public.sharia_face_set(text), public.sharia_face_status(), public.sharia_esign_prepare(uuid), public.sharia_esign_record(text, uuid, jsonb),
  public.sharia_resolution_pdf(uuid), public.sharia_esign_list() to authenticated;
-- أحداث خدمة التوقيع تصل الخادم بلا جلسة مستخدم: الدالة محمية بسرّ الخادم (كما في esign_apply)
grant execute on function public.sharia_esign_apply(text, uuid, text, jsonb, text) to anon, authenticated;

-- ═══ (د) تقرير الامتثال الشرعي الدوري للبنك المركزي ═══
-- يُحسب آلياً من الطلبات ووثائقها (islamic_app_docs) وقرارات الهيئة، لأي فترة. يراه البنك المركزي والهيئة والجهات الرقابية.
-- ورئيس الهيئة «يصدر» تقرير الفترة نسخةً مختومة (SCR-…) تصل البنك المركزي ولا تتغير بعد إصدارها.
create table if not exists public.sharia_compliance_reports (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  board_id uuid references public.sharia_boards(id),
  period_from date not null, period_to date not null, period_label text,
  body jsonb not null, sha256 text not null,
  issued_by uuid references public.profiles(id), issued_by_name text, signed_via text,
  issued_at timestamptz not null default now(),
  cbi_seen_at timestamptz, cbi_seen_by text);
alter table public.sharia_compliance_reports enable row level security;

create or replace function public._scr_can() returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or coalesce(me.disabled, false) or me.portal not in ('sharia', 'cbi', 'audit', 'integrity', 'admin') then
    raise exception 'تقرير الامتثال الشرعي للهيئة الشرعية والبنك المركزي والجهات الرقابية'; end if;
  return me;
end $f$;

create or replace function public._scr_build(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path to 'public' as $f$
declare t0 timestamptz := (p_from::timestamp at time zone 'Asia/Baghdad'); t1 timestamptz := ((p_to + 1)::timestamp at time zone 'Asia/Baghdad');
  b sharia_boards; checks jsonb := '[]'; banks jsonb; prods jsonb; ress jsonb; docs jsonb; late jsonb; n int; lst jsonb; tot jsonb;
begin
  if p_from is null or p_to is null or p_to < p_from then raise exception 'اختر فترة صحيحة'; end if;
  if p_to - p_from > 400 then raise exception 'الفترة سنة واحدة كحد أقصى'; end if;
  select * into b from sharia_boards where scope = 'central' order by created_at limit 1;

  -- الطلبات الإسلامية: منتج إسلامي لدى مصرف إسلامي
  create temp table if not exists _scr_apps (id uuid, code text, bank_id uuid, program text, t text, stage int, status text, amount numeric,
    submitted_at timestamptz, product_id uuid) on commit drop;
  truncate _scr_apps;
  insert into _scr_apps
  select a.id, a.code, a.bank_id, coalesce(a.program, 'solar'), _isl_type(a), a.stage, a.status, a.amount, a.submitted_at, a.product_id
  from applications a join orgs o on o.id = a.bank_id where coalesce(o.is_islamic, false) and a.stage > 5 and a.status <> 'cancelled';

  -- ── الفحوص: كل فحص {k, label, kind: guard|warn|info, count, items:[رقم الطلب…], note}
  -- 1) أُرسل إلى مصرف إسلامي دون منتج معتمد (خلال الفترة)
  select count(*), coalesce(jsonb_agg(code), '[]') into n, lst from _scr_apps where product_id is null and submitted_at >= t0 and submitted_at < t1;
  checks := checks || jsonb_build_object('k', 'no_product', 'label', 'طلبات أُرسلت إلى مصرف إسلامي دون منتج معتمد شرعاً', 'kind', 'guard', 'count', n, 'items', lst,
    'note', (select case when count(*) > 0 then count(*) || ' طلب قديم أُرسل قبل الفترة أو قبل تفعيل المنتجات (الجلسة 39) — لا يدخل في العدّ' end from _scr_apps where product_id is null and (submitted_at < t0 or submitted_at is null)));
  -- 2) عقد بيع/إجارة وُقّع قبل محضر القبض
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where _isl_two_phase(x.t) and (_isl_doc(x.id, 'contract')).at < coalesce((_isl_doc(x.id, 'receipt')).at, 'infinity');
  checks := checks || jsonb_build_object('k', 'contract_before_receipt', 'label', 'المرابحة والإجارة: عقد وُقّع قبل تملّك المصرف وقبضه', 'kind', 'guard', 'count', n, 'items', lst);
  -- 3) تنفيذ التمويل (بعد المرحلة 33) دون عقد موقّع
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x where x.t is not null and x.stage > 33 and (_isl_doc(x.id, 'contract')).id is null;
  checks := checks || jsonb_build_object('k', 'exec_no_contract', 'label', 'تمويل نُفّذ دون عقد معتمد موقّع', 'kind', 'guard', 'count', n, 'items', lst);
  -- 4) إنجاز التركيب دون فاتورة المورد باسم المصرف
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x where _isl_two_phase(x.t) and x.stage > 31 and (_isl_doc(x.id, 'invoice')).id is null;
  checks := checks || jsonb_build_object('k', 'no_invoice', 'label', 'المرابحة والإجارة: تركيب أُنجز دون فاتورة المورد باسم المصرف', 'kind', 'guard', 'count', n, 'items', lst);
  -- 5) جدول الأقساط لا يساوي الثمن المكتوب في العقد
  select count(*), coalesce(jsonb_agg(z.code), '[]') into n, lst from (
    select x.code from _scr_apps x cross join lateral (select (_isl_doc(x.id, 'contract')).body->'calc'->>'total' tot) c
      cross join lateral (select count(*) cnt, coalesce(sum(i.amount), 0) s from installments i where i.application_id = x.id) i
    where c.tot is not null and i.cnt > 0 and abs(i.s - c.tot::numeric) > greatest(i.cnt * 2, c.tot::numeric * 0.0005)) z;
  checks := checks || jsonb_build_object('k', 'schedule_mismatch', 'label', 'جدول أقساط لا يساوي الثمن في العقد الموقّع', 'kind', 'guard', 'count', n, 'items', lst);
  -- 6) الإجارة: أجرة قبل التسليم
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where x.t = 'IJM' and (select min(due_date) from installments where application_id = x.id) <= ((_isl_doc(x.id, 'receipt')).at at time zone 'Asia/Baghdad')::date;
  checks := checks || jsonb_build_object('k', 'rent_before_delivery', 'label', 'الإجارة: أجرة مستحقة قبل تسليم الأصل', 'kind', 'guard', 'count', n, 'items', lst);
  -- 7) منتجات نافذة تجاوزت موعد المراجعة الدورية
  select count(*), coalesce(jsonb_agg(p.code || ' ' || p.name), '[]') into n, lst from islamic_products p
  where p.status in ('approved', 'conditional') and p.review_due < p_to;
  checks := checks || jsonb_build_object('k', 'review_overdue', 'label', 'منتجات نافذة تجاوزت موعد المراجعة الدورية', 'kind', 'warn', 'count', n, 'items', lst);
  -- 8) قرارات الفترة لم يوقّعها الرئيس توقيعاً إلكترونياً موثوقاً بعد
  select count(*), coalesce(jsonb_agg(r.code), '[]') into n, lst from sharia_resolutions r
  where r.issued_at >= t0 and r.issued_at < t1 and r.esign_status is distinct from 'signed';
  checks := checks || jsonb_build_object('k', 'res_unsigned', 'label', 'قرارات الفترة دون توقيع إلكتروني موثوق من الرئيس (نافذة برمز التحقق)', 'kind', 'warn', 'count', n, 'items', lst);
  -- 9) المرحلة 25: التعهدات والضمانات (لا عقد تمويل ولا كمبيالة قبل التملّك)
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where x.t is not null and exists (select 1 from application_events e where e.application_id = x.id and e.action = 'إرسال عقد التمويل والكمبيالة إلى المقترض للتوقيع الإلكتروني' and e.created_at >= t0 and e.created_at < t1);
  checks := checks || jsonb_build_object('k', 'kambiala', 'label', 'طلبات إسلامية أُرسل فيها «عقد التمويل والكمبيالة» بدل التعهدات والضمانات', 'kind', 'guard', 'count', n, 'items', lst);
  -- 10) الضابط العام: لا زيادة على المتأخر (يمنعه مشغّل قاعدة البيانات)
  checks := checks || jsonb_build_object('k', 'no_late_increase', 'label', 'زيادة على قسط متأخر لمصلحة المصرف', 'kind', 'guard', 'count', 0, 'items', '[]'::jsonb,
    'note', 'ممنوعة آلياً بمشغّل على جدول الأقساط — لا يمكن تسجيلها');

  -- ── لكل مصرف إسلامي
  select coalesce(jsonb_agg(jsonb_build_object('bank', o.name, 'bank_id', o.id,
      'products_live', (select count(*) from islamic_products p where p.bank_id = o.id and p.status in ('approved', 'conditional')),
      'products_all', (select count(*) from islamic_products p where p.bank_id = o.id and p.status not in ('draft')),
      'apps', (select count(*) from _scr_apps x where x.bank_id = o.id),
      'apps_islamic', (select count(*) from _scr_apps x where x.bank_id = o.id and x.t is not null),
      'apps_new', (select count(*) from _scr_apps x where x.bank_id = o.id and x.submitted_at >= t0 and x.submitted_at < t1),
      'financed', (select coalesce(sum(x.amount), 0) from _scr_apps x where x.bank_id = o.id and x.t is not null and x.stage > 33),
      'contracts', (select count(*) from islamic_app_docs d join _scr_apps x on x.id = d.application_id where x.bank_id = o.id and d.kind = 'contract' and not d.void and d.at >= t0 and d.at < t1),
      'by_type', (select coalesce(jsonb_object_agg(t, c), '{}') from (select x.t, count(*) c from _scr_apps x where x.bank_id = o.id and x.t is not null group by x.t) z))
    order by o.name), '[]') into banks
  from orgs o where o.type = 'bank' and coalesce(o.is_islamic, false);

  -- ── المنتجات حسب الحالة
  select coalesce(jsonb_agg(jsonb_build_object('code', p.code, 'name', p.name, 'bank', (select name from orgs where id = p.bank_id), 'type', p.contract_type,
      'sector', _sh_sector_label(p.sector, p.subsector), 'status', p.status, 'status_label', _sh_status_label(p.status), 'review_due', p.review_due,
      'resolution', (select code from sharia_resolutions where id = p.resolution_id)) order by p.code), '[]') into prods
  from islamic_products p where p.status <> 'draft';

  -- ── قرارات الفترة
  select coalesce(jsonb_agg(jsonb_build_object('code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision), 'product', p.name,
      'bank', (select name from orgs where id = p.bank_id), 'issued_at', r.issued_at, 'esign', coalesce(r.esign_status, 'none'), 'cert', r.esign_cert) order by r.issued_at), '[]') into ress
  from sharia_resolutions r join islamic_products p on p.id = r.product_id where r.issued_at >= t0 and r.issued_at < t1;

  -- ── الوثائق الموقّعة والمسجّلة في الفترة
  select coalesce(jsonb_object_agg(kind, c), '{}') into docs from (
    select d.kind, count(*) c from islamic_app_docs d where not d.void and d.at >= t0 and d.at < t1 group by d.kind) z;

  -- ── التأخر في السداد ومعالجته
  late := jsonb_build_object('kind', b.late_kind, 'rule', b.late_rule,
    'overdue_count', (select count(*) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at is null and i.due_date < least(p_to, current_date)),
    'overdue_amount', (select coalesce(sum(i.amount), 0) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at is null and i.due_date < least(p_to, current_date)),
    'charity_count', (select count(*) from islamic_charity c where c.at >= t0 and c.at < t1),
    'charity_amount', (select coalesce(sum(c.amount), 0) from islamic_charity c where c.at >= t0 and c.at < t1),
    'paid_in_period', (select coalesce(sum(i.amount), 0) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at >= t0 and i.paid_at < t1));

  tot := jsonb_build_object('apps', (select count(*) from _scr_apps where t is not null), 'apps_new', (select count(*) from _scr_apps where t is not null and submitted_at >= t0 and submitted_at < t1),
    'vet', (select count(*) from _scr_apps where t is not null and program = 'vet'),
    'products_live', (select count(*) from islamic_products where status in ('approved', 'conditional')),
    'resolutions', jsonb_array_length(ress),
    'violations', (select coalesce(sum((c->>'count')::int), 0) from jsonb_array_elements(checks) c where c->>'kind' = 'guard'),
    'warnings', (select coalesce(sum((c->>'count')::int), 0) from jsonb_array_elements(checks) c where c->>'kind' = 'warn'));

  return jsonb_build_object('from', p_from, 'to', p_to, 'generated_at', now(), 'board', b.name, 'madhhab', _sh_madhhab_label(b.madhhab), 'marja', b.marja,
    'totals', tot, 'checks', checks, 'banks', banks, 'products', prods, 'resolutions', ress, 'docs', docs, 'late', late);
end $f$;

create or replace function public.sharia_compliance_report(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path to 'public' as $f$
begin
  perform _scr_can();
  return _scr_build(p_from, p_to) || jsonb_build_object('issued', (select jsonb_build_object('code', code, 'issued_at', issued_at, 'sha256', sha256)
    from sharia_compliance_reports where period_from = p_from and period_to = p_to order by issued_at desc limit 1));
end $f$;

-- رئيس الهيئة يصدر تقرير الفترة: نسخة مختومة لا تتغير، تصل البنك المركزي
create or replace function public.sharia_compliance_issue(p_from date, p_to date, p_label text, p_otp text) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; body jsonb; v_code text; v_sha text; r sharia_compliance_reports; v_n int;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إصدار التقرير الدوري لرئيس الهيئة'; end if;
  if not _otp_ok(p_otp, me.phone) then raise exception 'رمز التحقق غير صحيح — لم يصدر التقرير'; end if;
  if p_to >= (now() at time zone 'Asia/Baghdad')::date then raise exception 'يصدر التقرير بعد انتهاء الفترة — اختر فترة منتهية'; end if;
  if exists (select 1 from sharia_compliance_reports where period_from = p_from and period_to = p_to) then raise exception 'صدر تقرير هذه الفترة سابقاً'; end if;
  perform pg_advisory_xact_lock(hashtext('sharia_compliance_reports'));
  body := _scr_build(p_from, p_to);
  select count(*) + 1 into v_n from sharia_compliance_reports where extract(year from issued_at) = extract(year from now());
  v_code := 'SCR-' || to_char(now(), 'YYYY') || '-' || lpad(v_n::text, 3, '0');
  v_sha := encode(extensions.digest(v_code || '|' || body::text, 'sha256'), 'hex');
  insert into sharia_compliance_reports(code, board_id, period_from, period_to, period_label, body, sha256, issued_by, issued_by_name, signed_via)
  values (v_code, (select id from sharia_boards where scope = 'central' order by created_at limit 1), p_from, p_to, nullif(trim(coalesce(p_label, '')), ''),
    body, v_sha, me.id, me.full_name, 'رمز تحقق على هاتف الرئيس') returning * into r;
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_report', 'تقرير الامتثال الشرعي ' || v_code || coalesce(' — ' || r.period_label, ''),
    'المخالفات ' || (body->'totals'->>'violations') || ' · الملاحظات ' || (body->'totals'->>'warnings') || ' · من ' || p_from || ' إلى ' || p_to, r.id);
  return jsonb_build_object('code', v_code, 'sha256', v_sha, 'issued_at', r.issued_at);
end $f$;

create or replace function public.sharia_compliance_list() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
begin
  perform _scr_can();
  return coalesce((select jsonb_agg(jsonb_build_object('id', id, 'code', code, 'from', period_from, 'to', period_to, 'label', period_label, 'sha256', sha256,
    'issued_at', issued_at, 'issued_by', issued_by_name, 'violations', body->'totals'->'violations', 'warnings', body->'totals'->'warnings',
    'cbi_seen_at', cbi_seen_at) order by issued_at desc) from sharia_compliance_reports), '[]'::jsonb);
end $f$;

-- قراءة تقرير صادر كما خُتم (ويُسجَّل اطلاع البنك المركزي أول مرة)
create or replace function public.sharia_compliance_get(p_id uuid) returns jsonb
language plpgsql volatile security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; r sharia_compliance_reports;
begin
  me := _scr_can();
  select * into r from sharia_compliance_reports where id = p_id;
  if r.id is null then raise exception 'التقرير غير موجود'; end if;
  if me.portal = 'cbi' and r.cbi_seen_at is null then
    update sharia_compliance_reports set cbi_seen_at = now(), cbi_seen_by = me.full_name || ' — ' || _role_title(me.role) where id = r.id;
  end if;
  return r.body || jsonb_build_object('issued', jsonb_build_object('code', r.code, 'issued_at', r.issued_at, 'issued_by', r.issued_by_name, 'sha256', r.sha256,
    'intact', encode(extensions.digest(r.code || '|' || r.body::text, 'sha256'), 'hex') = r.sha256, 'label', r.period_label));
end $f$;

revoke all on function public._scr_can(), public._scr_build(date, date) from public, anon, authenticated;
revoke all on function public.sharia_compliance_report(date, date), public.sharia_compliance_issue(date, date, text, text), public.sharia_compliance_list(), public.sharia_compliance_get(uuid) from public, anon;
grant execute on function public.sharia_compliance_report(date, date), public.sharia_compliance_issue(date, date, text, text), public.sharia_compliance_list(), public.sharia_compliance_get(uuid) to authenticated;

-- ═══ (أ-3) رسالة المقترض عند المرحلة 25 في الطلب الإسلامي (تعديل موضعي آمن على _borrower_asks) ═══
do $$
declare d text;
  o text := 'b := ''المطلوب منك: توقيع عقد التمويل والكمبيالة'' || coalesce('' في '' || br, '''') || ''، أو إلكترونياً من «طلبي» حين يصلك رابط التوقيع.'';';
  n text := 'b := ''المطلوب منك: توقيع '' || case when _isl_type(a) is not null then ''التعهدات والضمانات (العقد نفسه توقّعه بعد أن يتملّك المصرف '' || _isl_noun(a) || '')'' else ''عقد التمويل والكمبيالة'' end || coalesce('' في '' || br, '''') || ''، أو إلكترونياً من «طلبي» حين يصلك رابط التوقيع.'';';
begin
  d := pg_get_functiondef(to_regprocedure('public._borrower_asks()'));
  if d is null or position('_isl_type(a)' in d) > 0 then return; end if;
  if position(o in d) = 0 then raise notice 'الجلسة 43: لم يُعثر على نص المرحلة 25 في _borrower_asks — تُرك كما هو'; return; end if;
  execute replace(d, o, n);
end $$;

-- ═══ (ب-7) منتج إسلامي معتمد لمسار البيطري لدى مصرف الواحة الإسلامي ═══
-- «أجهزة البيطري بالمرابحة» — مرابحة على مرحلتين مثل منتج الطاقة الشمسية: وعد غير ملزم ← فاتورة المورد باسم المصرف ← محضر القبض ← عقد البيع.
-- (المنتج IP-2026-0004 يبقى «معاداً» كما هو لعرض دورة الإعادة)
do $$
declare bk uuid; bd uuid; hd uuid; m1 uuid; m2 uuid; m3 uuid; p uuid; v uuid; r uuid; c jsonb; v_code text; v_res text; t1 timestamptz := now() - interval '1 day';
begin
  select id into bk from orgs where code = 'bank2' and coalesce(is_islamic, false);
  select id into bd from sharia_boards where scope = 'central' order by created_at limit 1;
  select id into hd from profiles where username = 'sharia.head';
  select id into m1 from profiles where username = 'sharia.m1';
  select id into m2 from profiles where username = 'sharia.m2';
  select id into m3 from profiles where username = 'sharia.m3';
  if bk is null or bd is null or hd is null then raise notice 'الجلسة 43: لا يوجد مصرف الواحة أو الهيئة — لم يُنشأ منتج البيطري'; return; end if;
  if exists (select 1 from islamic_products where bank_id = bk and sector = 'vet' and name = 'أجهزة البيطري بالمرابحة') then return; end if;
  c := $j$[
    {"n":1,"title":"الأطراف","text":"الطرف الأول (البائع): {{bank_name}}، ويمثله المخوّل بالتوقيع. الطرف الثاني (المشتري): الطبيب البيطري {{borrower_name}}، رقم البطاقة الوطنية {{borrower_nid}}."},
    {"n":2,"title":"التمهيد والوعد بالشراء","text":"تقدّم المشتري بطلب شراء ووعد بشراء الأجهزة الموصوفة في هذا العقد، ووعده غير ملزم له. واشترى البائع الأجهزة من المورد {{supplier}} لنفسه، وصدرت فاتورتها باسمه، واستلمها بموجب محضر قبض قبل هذا العقد."},
    {"n":3,"title":"المبيع","text":"أجهزة ومعدات المشروع البيطري: {{asset}}، بأرقامها التسلسلية المذكورة في عرض المورد ومحضر القبض الملحقين بهذا العقد، في {{place}}."},
    {"n":4,"title":"الثمن","text":"رأس مال المبيع (كلفة شرائه على البائع) {{cost}} دينار، والربح المعلوم {{profit}} دينار، فيكون ثمن البيع {{price_total}} دينار. والثمن ثابت لا يزيد بعد هذا العقد لأي سبب. ومساهمة المشتري في كلفة المشروع يدفعها للمورد مباشرة ولا تدخل في الثمن."},
    {"n":5,"title":"السداد","text":"يُدفع الثمن على {{term}} قسطاً شهرياً متساوياً، قيمة كل قسط {{installment}} دينار، يُستحق أولها بعد شهر من تنفيذ العقد."},
    {"n":6,"title":"انتقال الملك وتبعة التلف","text":"يملك المشتري المبيع بتمام هذا العقد، ويتحمّل تبعة هلاكه بعد قبضه. وما يتلف قبل التسليم فعلى البائع."},
    {"n":7,"title":"التأخر في السداد","text":"لا يُضاف إلى الثمن أي مبلغ بسبب التأخر أو التأجيل. وللبائع المطالبة بالأقساط المستحقة والرجوع إلى الضمانات بقدر الدين."},
    {"n":8,"title":"الضمانات","text":"يقدّم المشتري الضمان المختار في طلبه (كفالة راتب أو رهن عقار) ضماناً للثمن المؤجل، ولا يُستوفى منه إلا قدر الدين المستحق."},
    {"n":9,"title":"السداد المبكر","text":"للمشتري تعجيل ما بقي من الأقساط. وما يتنازل عنه البائع من الربح عند التعجيل تبرّع منه غير مشروط في هذا العقد."},
    {"n":10,"title":"المرجعية الشرعية","text":"صيغ هذا العقد على {{madhhab}}، واعتمدته {{board}} بالقرار {{resolution}}. وأي تعديل في نصه يحتاج اعتماداً جديداً من الهيئة."}]$j$::jsonb;
  select 'IP-' || to_char(now(), 'YYYY') || '-' || lpad((coalesce(max(substring(code from '\d+$')::int), 0) + 1)::text, 4, '0') into v_code
  from islamic_products where code like 'IP-' || to_char(now(), 'YYYY') || '-%';
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, submitted_at, created_at, updated_at)
  values (v_code, bk, bd, 'MRB', 'أجهزة البيطري بالمرابحة', 'vet', null, 'يشتري المصرف أجهزة مشروعك ثم يبيعها لك بربح معلوم تدفعه أقساطاً',
    '{"profit_min": 4, "profit_max": 8, "term_min": 24, "term_max": 60}', '{single_salary,multi_salary,mortgage}', '{طلب شراء ووعد غير ملزم,فاتورة المورد باسم المصرف,محضر قبض واستلام,جدول الأقساط}',
    'approved', t1 - interval '3 days', t1 - interval '4 days', t1) returning id into p;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p, 1, c, _sh_sha(c), 'approved', 'النسخة الأولى — بعد استكمال بنود الوعد والتملّك والقبض التي طلبتها الهيئة في IP-2026-0004', 'رقية عادل الشمري', t1 - interval '4 days') returning id into v;
  update islamic_products set current_version_id = v, approved_version_id = v where id = p;
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, at)
  select p, v, x.id, x.full_name, x.role = 'sharia_head', 'approve', t1 - interval '6 hours' from profiles x where x.id in (hd, m1, m2, m3);
  v_res := _sh_next_code();
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, votes, dissent, version_sha256, seal, signed_by, signed_by_name, signed_by_code, signed_via, issued_at)
  values (v_res, bd, p, v, 'approved', 'اعتمدت الهيئة المنتج «أجهزة البيطري بالمرابحة» ونموذج عقده بالنسخة 1 على المذهب الجعفري.',
    '{"approve": 4, "approve_cond": 0, "reject": 0, "cast": 4, "members": 5, "quorum": 3, "quorum_ok": true, "proposed": "approved"}', '[]', _sh_sha(c),
    encode(extensions.digest(v_res || '|' || _sh_sha(c) || '|approved|' || t1::text, 'sha256'), 'hex'), hd, (select full_name from profiles where id = hd),
    (select staff_code from profiles where id = hd), 'رمز تحقق على هاتف الرئيس', t1) returning id into r;
  update islamic_products set resolution_id = r, review_due = (t1 + interval '12 months')::date where id = p;
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values
    (p, t1 - interval '4 days', 'رقية عادل الشمري', 'bank', 'إنشاء المنتج', 'لمسار مبادرة الأطباء البيطريين'),
    (p, t1 - interval '3 days', 'رقية عادل الشمري', 'bank', 'تقديم للهيئة — النسخة 1', null),
    (p, t1 - interval '2 days', 'م. سارة فاضل الربيعي', 'board', 'إحالة للأعضاء للمداولة والتصويت', 'الملف مكتمل'),
    (p, t1, (select full_name from profiles where id = hd), 'board', 'قرار ' || v_res || ': اعتماد', null);
exception when others then raise notice 'الجلسة 43: تعذّر إنشاء منتج البيطري التجريبي (%)', sqlerrm;
end $$;

-- ═══ (ب-8) حساب عرض: vet3 — طبيبة بيطرية طلبها عند خطوة الإرسال لدى مصرف الواحة الإسلامي ═══
-- العضوية مؤيدة، ودائرة البيطرة وافقت، والكفيل وافق — بقي: اختيار صيغة التمويل ← دفع العمولة ← توقيع الوعد والإرسال.
-- يُبنى الطلب بدوال المنصة نفسها. آمن للتكرار: لا يفعل شيئاً إن كان لـ vet3 طلب.
do $$
declare uid uuid; vd uuid; a applications; bk uuid; sup uuid; y int := extract(year from now())::int; mid uuid;
  img text := 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=';
begin
  select id into bk from orgs where code = 'bank2' and coalesce(is_islamic, false);
  select id into sup from orgs where type = 'supplier' and meta->>'kind' = 'vet' order by code limit 1;
  select id into vd from profiles where username = 'vetdept1';
  if bk is null or sup is null or vd is null then raise notice 'الجلسة 43: لا مصرف إسلامي أو مورد بيطري — لم يُنشأ vet3'; return; end if;
  if not exists (select 1 from islamic_products where bank_id = bk and sector = 'vet' and status in ('approved', 'conditional')) then return; end if;
  select id into uid from profiles where username = 'vet3';
  if uid is null then
    uid := _mk_user('vet3', 'Alwah@2003', 'زهراء كريم عبد الأمير', 'citizen', 'citizen', null, '07701112203', '199305212003');
    update profiles set governorate = 'بغداد', city = 'المنصور', employer = 'عمل حر — طبيبة بيطرية', employment_type = 'private', monthly_salary = 1600000,
      birth_date = '1993-05-21', kyc_status = 'none', self_registered = false where id = uid;
  end if;
  if exists (select 1 from applications where citizen_id = uid) then return; end if;
  if not exists (select 1 from vet_memberships where profile_id = uid) then
    insert into vet_memberships(profile_id, full_name, national_id, membership_no, syndicate_branch, license_no, license_year, graduation_year, college, specialty,
      status, letter_no, valid_until, decided_by_title, decided_at, submitted_at)
    values (uid, 'زهراء كريم عبد الأمير', '199305212003', '6120', 'بغداد', 'BG-3307', y, 2016, 'كلية الطب البيطري — جامعة بغداد', 'جراحة الحيوانات الصغيرة',
      'endorsed', _vet_seq('VSI', 'vet_memberships', 'letter_no'), make_date(y, 12, 31), _role_title('syndicate_officer'), now(), now() - interval '3 days')
    returning id into mid;
    insert into vet_member_docs(membership_id, kind, mime, data, bytes, meta)
    select mid, k, 'image/jpeg', img, length(img), '{"demo":true}' from unnest(array['union_id','license','degree']) k;
  end if;

  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);
  a := start_vet_application('clinic', 'بغداد', 'المنصور', 33.3152, 44.3661);
  perform citizen_step(a.id, 1, jsonb_build_object('national_id', '199305212003', 'liveness', true, 'match_score', 95, 'card_side', 'front+back', 'id_source', 'manual'));
  perform citizen_step(a.id, 2, jsonb_build_object('membership_no', '6120', 'license_no', 'BG-3307', 'license_year', y, 'graduation_year', 2016, 'syndicate_branch', 'بغداد',
    'college', 'كلية الطب البيطري — جامعة بغداد', 'specialty', 'جراحة الحيوانات الصغيرة'));
  perform add_document(a.id, 'quote', img, 'camera', '{"live": true, "demo": true}'::jsonb);
  perform citizen_step(a.id, 3, jsonb_build_object('project_type', 'clinic', 'title', 'عيادة الرحمة البيطرية', 'site_governorate', 'بغداد', 'site_city', 'المنصور',
    'site_address', 'شارع 14 رمضان قرب ساحة الرواد', 'site_ownership', 'rented', 'site_area', '120',
    'items', jsonb_build_array(jsonb_build_object('name', 'جهاز سونار بيطري محمول', 'qty', 1, 'price', 6500000),
                               jsonb_build_object('name', 'طاولة عمليات هيدروليكية', 'qty', 1, 'price', 2500000),
                               jsonb_build_object('name', 'جهاز تخدير بالاستنشاق', 'qty', 1, 'price', 2000000)),
    'other_cost', '1000000', 'contribution', '2500000', 'revenue_monthly', '2500000', 'staff_count', '3',
    'supplier_id', sup, 'quote_no', 'Q-RF-2026-118', 'bank_id', bk, 'term_months', 60, 'grace_months', 0));
  perform set_config('request.jwt.claims', json_build_object('sub', vd, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', vd::text, true);
  perform vetdept_action(a.id, 'approve', 'الموقع مناسب لعيادة بيطرية — عرض المرافق مطابق');
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);
  perform citizen_step(a.id, 4, jsonb_build_object('guarantors', jsonb_build_array(jsonb_build_object('name', 'علي كريم عبد الأمير', 'phone', '07701112293',
    'employer', 'وزارة الصحة', 'salary', 1250000, 'relation', 'أخ', 'otp', '1234'))));
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
exception when others then
  -- حساب العرض اختياري: لا يُفشل التحديث كله إن تعذّر بناؤه
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  raise notice 'الجلسة 43: تعذّر بناء طلب vet3 (%)', sqlerrm;
end $$;

revoke all on function public._isl_noun(applications), public._isl_asset(applications), public._isl_esign_info(applications) from public, anon, authenticated;
