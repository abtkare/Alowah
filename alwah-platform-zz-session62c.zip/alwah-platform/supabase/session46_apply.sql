-- ألواح — الجلسة 46
-- 1) رقم حساب المقترض يكتبه موظف المصرف بعد فتح الحساب فعلاً (لا يولّده النظام)
-- 2) المصارف بلا ربط تقني: «وضع البوابة» — موظفو المصرف ينجزون كل شيء من بوابة ألواح
-- 3) برامج التمويل لكل مصرف (الطاقة الشمسية، البيطري، المصدّرون، التجاري، التجارة الإلكترونية)
-- 4) إضافة المصرف الصناعي العراقي ومصرف TPI مع حساباتهما
-- آمن للتكرار.

-- ═══ 1) رقم الحساب: يُكتب يدوياً ═══
alter table public.applications add column if not exists bank_account_by text;
alter table public.applications add column if not exists bank_account_src text;
update public.applications set bank_account_src = 'auto_legacy' where bank_account is not null and bank_account_src is null;

-- لا توليد آلي بعد اليوم. الانتقال من المرحلة 7 يتطلب رقماً كتبه موظف المصرف.
create or replace function public._open_account() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.stage > 7 and old.stage <= 7 and new.bank_id is not null and coalesce(trim(new.bank_account), '') = '' and auth.uid() is not null then
    raise exception 'اكتب رقم حساب المقترض الذي فتحه المصرف أولاً (حقل «رقم حساب المقترض» في ملف الطلب)';
  end if;
  return new;
end $$;
drop trigger if exists trg_open_account on public.applications;
create trigger trg_open_account before update of stage on public.applications for each row execute function public._open_account();

create or replace function public.bank_set_account(p_app uuid, p_account text, p_note text default null) returns applications
language plpgsql security definer set search_path = public as $$
declare a applications; me profiles; v text; v_old text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a.id is null then raise exception 'الطلب غير موجود'; end if;
  if me.id is null or me.portal <> 'bank' or me.org_id is distinct from a.bank_id or coalesce(me.disabled, false) then
    raise exception 'رقم الحساب يكتبه موظف المصرف صاحب الطلب فقط'; end if;
  if me.role not in ('bank_cs', 'bank_compliance', 'bank_branch_mgr', 'bank_ops', 'bank_md') then
    raise exception 'رقم الحساب يكتبه موظف خدمة الزبائن أو الامتثال أو مدير الفرع'; end if;
  if a.status in ('rejected', 'cancelled', 'completed') then raise exception 'الطلب مغلق'; end if;
  if a.stage < 6 then raise exception 'لم يصل الطلب إلى المصرف بعد'; end if;
  v := upper(regexp_replace(coalesce(p_account, ''), '[\s]', '', 'g'));
  v := translate(v, '٠١٢٣٤٥٦٧٨٩', '0123456789');
  if v !~ '^[A-Z0-9-]{4,34}$' or length(regexp_replace(v, '[^0-9]', '', 'g')) < 4 then
    raise exception 'رقم الحساب غير صحيح — أرقام (ويجوز حروف إنجليزية أو شرطة)، من 4 إلى 34 خانة';
  end if;
  if exists (select 1 from applications x where x.bank_id = a.bank_id and x.id <> a.id and x.bank_account = v and x.citizen_id is distinct from a.citizen_id) then
    raise exception 'هذا الرقم مسجّل لمقترض آخر في المصرف نفسه — تأكد منه';
  end if;
  v_old := a.bank_account;
  if v_old is not null and v_old = v then return a; end if;
  -- بعد المرحلة 7 التصحيح لمدير الفرع أو العمليات أو الإدارة العليا وبسبب مكتوب
  if a.stage > 7 and v_old is not null then
    if me.role not in ('bank_branch_mgr', 'bank_ops', 'bank_md') then raise exception 'تصحيح رقم الحساب بعد فتحه لمدير الفرع أو العمليات المصرفية'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'اكتب سبب تصحيح رقم الحساب'; end if;
  end if;
  update applications set bank_account = v, account_opened_at = coalesce(account_opened_at, now()),
    bank_account_by = me.full_name || coalesce(' — ' || _role_title(me.role), ''), bank_account_src = 'staff', updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, a.stage, case when v_old is null then 'account_set' else 'account_fix' end,
    case when v_old is null then 'سُجّل رقم حساب المقترض: ' || v else 'صُحّح رقم الحساب من ' || v_old || ' إلى ' || v || ' — السبب: ' || trim(p_note) end);
  insert into notifications(user_id, portal, kind, title, body, ref_id)
  values (a.citizen_id, 'citizen', 'account', case when v_old is null then 'فُتح حسابك في المصرف' else 'صُحّح رقم حسابك في المصرف' end,
    'رقم حسابك: ' || v || ' — يظهر في «طلبي ← التفاصيل».', a.id);
  return a;
end $$;
revoke all on function public.bank_set_account(uuid, text, text) from public, anon;
grant execute on function public.bank_set_account(uuid, text, text) to authenticated;

-- نص المرحلة 7: خدمة الزبائن/الامتثال تفتح الحساب في نظام المصرف ثم تكتب رقمه
update public.stages set action_label = 'كتابة رقم الحساب المفتوح وتأكيد الامتثال', confirm_text = 'تم فتح الحساب وكتابة رقمه'
where n = 7 and confirm_text is distinct from 'تم فتح الحساب وكتابة رقمه';

-- ═══ 2 و3) وضع الربط وبرامج التمويل لكل مصرف ═══
update public.orgs set meta = coalesce(meta, '{}') || '{"link_mode":"portal"}'::jsonb where type = 'bank' and not coalesce(meta, '{}') ? 'link_mode';
update public.orgs set meta = coalesce(meta, '{}') || '{"programs":["solar","vet"]}'::jsonb where type = 'bank' and not coalesce(meta, '{}') ? 'programs';

-- البرامج الجديدة مسموحة في الطلبات (مسار المقترض لها يُبنى بعد اعتماد التحليل)
alter table public.applications drop constraint if exists applications_program_check;
alter table public.applications add constraint applications_program_check check (program = any (array['solar', 'vet', 'export', 'commercial', 'ecommerce']));

create or replace function public._program_label(p text) returns text language sql immutable as $$
  select case p when 'solar' then 'منظومات الطاقة الشمسية' when 'vet' then 'مشاريع الأطباء البيطريين' when 'export' then 'قروض المصدّرين'
    when 'commercial' then 'القروض التجارية' when 'ecommerce' then 'قروض التجارة الإلكترونية' else p end
$$;

create or replace function public.admin_set_bank_mode(p_bank uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o orgs; v_pr text[]; v_mode text;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into o from orgs where id = p_bank and type = 'bank';
  if o.id is null then raise exception 'المصرف غير موجود'; end if;
  if p ? 'programs' then
    select coalesce(array_agg(distinct x), '{}') into v_pr from jsonb_array_elements_text(coalesce(p->'programs', '[]'::jsonb)) x;
    if exists (select 1 from unnest(v_pr) x where x not in ('solar', 'vet', 'export', 'commercial', 'ecommerce')) then raise exception 'برنامج تمويل غير معروف'; end if;
    if cardinality(v_pr) = 0 then raise exception 'اختر برنامج تمويل واحداً على الأقل'; end if;
    update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('programs', to_jsonb(v_pr)) where id = o.id;
  end if;
  if p ? 'link_mode' then
    v_mode := p->>'link_mode';
    if v_mode not in ('portal', 'api') then raise exception 'وضع الربط غير معروف'; end if;
    update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('link_mode', v_mode) where id = o.id;
  end if;
  perform _audit('برامج المصرف ووضع الربط', o.name, p);
  return (select meta from orgs where id = o.id);
end $$;
revoke all on function public.admin_set_bank_mode(uuid, jsonb) from public, anon;
grant execute on function public.admin_set_bank_mode(uuid, jsonb) to authenticated;

-- ═══ 4) المصرف الصناعي العراقي ومصرف TPI ═══
create or replace function public._s46_bank(p_code text, p_name text, p_short text, p_color text, p_programs text[], p_accepting boolean,
  p_pw text, p_staff jsonb, p_margin numeric, p_comm numeric, p_fee bigint, p_cap bigint, p_alloc bigint) returns void
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare o orgs; br branches; s jsonb; uid uuid; pre text := upper(p_code);
begin
  select * into o from orgs where code = p_code;
  if o.id is null then
    insert into orgs(code, type, name, is_islamic, meta)
    values (p_code, 'bank', p_name, false, jsonb_build_object('kind', 'bank', 'color', p_color, 'short', p_short, 'accepting', false,
      'link_mode', 'portal', 'programs', to_jsonb(p_programs), 'onboarded_at', now(), 'onboarded_by', 'مشغّل النظام — الجلسة 46'))
    returning * into o;
  end if;
  select * into br from branches where code = pre || '-01';
  if br.id is null then
    insert into branches(bank_id, code, name, governorates, is_main, complaint_phone)
    values (o.id, pre || '-01', 'الفرع الرئيسي — بغداد',
      array['بغداد','البصرة','نينوى','أربيل','النجف','كربلاء','بابل','ذي قار','الأنبار','ديالى','كركوك','صلاح الدين','واسط','ميسان','المثنى','القادسية','الديوانية','السليمانية','دهوك'],
      true, null) returning * into br;
  end if;
  insert into bank_terms(bank_id, margin, commission_pct, file_fee, max_term_months, processing_days, single_approval_cap)
  values (o.id, p_margin, p_comm, p_fee, 60, 10, p_cap) on conflict do nothing;
  if to_regclass('public.bank_allocations') is not null then
    insert into bank_allocations(bank_id, allocated) values (o.id, p_alloc) on conflict do nothing;
  end if;
  for s in select * from jsonb_array_elements(p_staff) loop
    if not exists (select 1 from profiles where username = s->>'u') then
      uid := _mk_user(s->>'u', p_pw || (s->>'s'), s->>'n', s->>'r', 'bank', p_code, null, null);
      update profiles set
        branch_id = case when s->>'r' in ('bank_cs', 'bank_branch_mgr', 'bank_teller') then br.id end,
        manage_scope = case s->>'r' when 'bank_admin' then 'org' when 'bank_branch_mgr' then 'branch' when 'bank_initiatives_mgr' then 'dept' else manage_scope end,
        position_title = coalesce(position_title, _role_title(s->>'r')),
        staff_code = coalesce(staff_code, pre || '-' || upper(s->>'s') || '-001'),
        must_change_password = false
      where id = uid;
    end if;
  end loop;
  -- يُفعَّل الاستقبال فقط إن اكتمل المصرف (الجلسة 42)
  if p_accepting and coalesce((o.meta->>'accepting')::boolean, false) = false and coalesce((_org_readiness(o.id)->>'ok')::boolean, false) then
    update orgs set meta = meta || '{"accepting": true}'::jsonb where id = o.id;
  end if;
end $f$;
revoke all on function public._s46_bank from public, anon, authenticated;

select public._s46_bank('ind', 'المصرف الصناعي العراقي', 'الصناعي', '#B45309', array['solar'], true, 'Ind@2026',
  '[{"u":"ind.admin","s":"ad","r":"bank_admin","n":"مدير الجهة — المصرف الصناعي"},
    {"u":"ind.md","s":"md","r":"bank_md","n":"الإدارة العليا — المصرف الصناعي"},
    {"u":"ind.branch","s":"br","r":"bank_branch_mgr","n":"مدير الفرع الرئيسي — المصرف الصناعي"},
    {"u":"ind.cs","s":"cs","r":"bank_cs","n":"خدمة الزبائن — المصرف الصناعي"},
    {"u":"ind.compliance","s":"co","r":"bank_compliance","n":"الامتثال وفتح الحسابات — المصرف الصناعي"},
    {"u":"ind.init","s":"in","r":"bank_initiatives","n":"إداري قسم المبادرات — المصرف الصناعي"},
    {"u":"ind.initmgr","s":"im","r":"bank_initiatives_mgr","n":"مدير قسم المبادرات — المصرف الصناعي"},
    {"u":"ind.credit","s":"cr","r":"bank_credit","n":"شعبة الائتمان — المصرف الصناعي"},
    {"u":"ind.inspect","s":"ks","r":"bank_inspection","n":"لجنة الكشف الموقعي — المصرف الصناعي"},
    {"u":"ind.committee","s":"cm","r":"bank_committee","n":"اللجنة الائتمانية العليا — المصرف الصناعي"},
    {"u":"ind.risk","s":"rk","r":"bank_risk","n":"المخاطر والتدقيق الداخلي — المصرف الصناعي"},
    {"u":"ind.legal","s":"lg","r":"bank_legal","n":"الشؤون القانونية — المصرف الصناعي"},
    {"u":"ind.ops","s":"op","r":"bank_ops","n":"العمليات المصرفية — المصرف الصناعي"},
    {"u":"ind.teller","s":"tl","r":"bank_teller","n":"أمين الصندوق — المصرف الصناعي"},
    {"u":"ind.collect","s":"cl","r":"bank_collection","n":"التحصيل والمتابعة — المصرف الصناعي"},
    {"u":"ind.payroll","s":"pr","r":"bank_payroll","n":"توطين الرواتب — المصرف الصناعي"}]'::jsonb,
  1.5, 1, 50000, 25000000, 500000000);

select public._s46_bank('tpi', 'مصرف TPI', 'TPI', '#0F766E', array['export', 'commercial', 'ecommerce'], false, 'Tpi@2026',
  '[{"u":"tpi.admin","s":"ad","r":"bank_admin","n":"مدير الجهة — مصرف TPI"},
    {"u":"tpi.md","s":"md","r":"bank_md","n":"الإدارة العليا — مصرف TPI"},
    {"u":"tpi.branch","s":"br","r":"bank_branch_mgr","n":"مدير الفرع الرئيسي — مصرف TPI"},
    {"u":"tpi.cs","s":"cs","r":"bank_cs","n":"خدمة الزبائن — مصرف TPI"},
    {"u":"tpi.compliance","s":"co","r":"bank_compliance","n":"الامتثال وفتح الحسابات — مصرف TPI"},
    {"u":"tpi.init","s":"in","r":"bank_initiatives","n":"إداري قسم المبادرات — مصرف TPI"},
    {"u":"tpi.initmgr","s":"im","r":"bank_initiatives_mgr","n":"مدير قسم المبادرات — مصرف TPI"},
    {"u":"tpi.credit","s":"cr","r":"bank_credit","n":"شعبة الائتمان — مصرف TPI"},
    {"u":"tpi.inspect","s":"ks","r":"bank_inspection","n":"لجنة الكشف الموقعي — مصرف TPI"},
    {"u":"tpi.committee","s":"cm","r":"bank_committee","n":"اللجنة الائتمانية العليا — مصرف TPI"},
    {"u":"tpi.risk","s":"rk","r":"bank_risk","n":"المخاطر والتدقيق الداخلي — مصرف TPI"},
    {"u":"tpi.legal","s":"lg","r":"bank_legal","n":"الشؤون القانونية — مصرف TPI"},
    {"u":"tpi.ops","s":"op","r":"bank_ops","n":"العمليات المصرفية — مصرف TPI"},
    {"u":"tpi.teller","s":"tl","r":"bank_teller","n":"أمين الصندوق — مصرف TPI"},
    {"u":"tpi.collect","s":"cl","r":"bank_collection","n":"التحصيل والمتابعة — مصرف TPI"},
    {"u":"tpi.payroll","s":"pr","r":"bank_payroll","n":"توطين الرواتب — مصرف TPI"}]'::jsonb,
  2, 1, 75000, 50000000, 1000000000);
