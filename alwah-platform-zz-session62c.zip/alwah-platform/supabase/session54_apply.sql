-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 54: «بوابة الصناعيين» (/industry) مستقلة عن بوابة المقترض
--  خدمات الهوية الصناعية (الانتساب، التجديد، الكتب، البدل، التحديث، الإلغاء) صارت في بوابة الصناعيين.
--  هذا الملف يحدّث نصوص الرسائل التي كانت تحيل إلى صفحة «اتحاد الصناعات» في بوابة المقترض. آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════
do $mig$
declare fn text; src text;
begin
  foreach fn in array array['public._un_scan()', 'public.union_act(uuid,jsonb)', 'public._un_sync(uuid)', 'public._ind_step(uuid,integer,jsonb)'] loop
    if to_regprocedure(fn) is null then continue; end if;
    src := pg_get_functiondef(fn::regprocedure);
    if position('صفحة «اتحاد الصناعات»' in src) = 0 then continue; end if;
    execute replace(replace(src, 'من صفحة «اتحاد الصناعات»', 'من «بوابة الصناعيين»'), 'صفحة «اتحاد الصناعات»', '«بوابة الصناعيين»');
  end loop;
end $mig$;
