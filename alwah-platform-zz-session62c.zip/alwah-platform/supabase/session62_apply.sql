-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 62: فحص سياسة المصرف الائتمانية على بيانات المقترض بالنموذج الداخلي
--  1) كل مصرف يكتب سياسته الائتمانية نصاً عربياً (الإدارة العليا). النموذج الداخلي في المنصة
--     (public/js/policy-model.js) يقرأ النص ويحوّله إلى شروط منظّمة (حقل، مقارنة، قيمة، الجملة المصدر)
--     تراجعها الإدارة العليا وتجرّبها على مقترض افتراضي وعلى طلبات المصرف السابقة، ثم تعتمدها بإصدار وبصمة.
--  2) محرّك الإسقاط (في القاعدة): يبني ملف المقترض (العمر، الدخل، نوع العمل، المحافظة، المبلغ، المدة، القسط،
--     نسبة القسط من الدخل، العمر عند آخر قسط، القطاع، الضمان) ويطبّق شروط السياسة عليه.
--  3) المقترض يرى عند اختيار المصرف أي المصارف يطابق طلبه سياستها، وإن تعارض طلبه مع سياسة المصرف
--     يُرفض التقديم فوراً مع السبب، ويُنصح بالمصارف التي يطابق سياستها.
--  4) حارس على الطلبات (trg_a2_policy_gate) عند اختيار المصرف أو تغييره وعند الإرسال: لا يمر طلب يخالف السياسة
--     النافذة لمصرفه، أياً كان المسار (شمسي، بيطري، برامج المصارف). يُوقف من الإعداد policy_gate = 0.
--  5) سجل الفحوص (policy_checks) للمصرف والبنك المركزي: كم طلباً فُحص، كم رُفض، وأكثر أسباب الرفض.
-- الملف آمن للتكرار. لا يعدّل أي دالة قائمة.
-- ═══════════════════════════════════════════════════════════════════════
set check_function_bodies = off;

-- ───────── 1) الجداول ─────────
create table if not exists public.bank_policies (
  id uuid primary key default gen_random_uuid(),
  bank_id uuid not null references public.orgs(id),
  version int not null,
  status text not null default 'active' check (status in ('active', 'superseded', 'disabled')),
  title text,
  policy_text text not null,
  rules jsonb not null default '[]'::jsonb,
  unparsed jsonb not null default '[]'::jsonb,
  sha256 text,
  created_by uuid, created_by_name text,
  created_at timestamptz not null default now(),
  ended_at timestamptz, ended_by_name text,
  unique (bank_id, version)
);
create unique index if not exists bank_policies_one_active on public.bank_policies(bank_id) where status = 'active';

create table if not exists public.policy_checks (
  id bigint generated always as identity primary key,
  bank_id uuid references public.orgs(id),
  policy_id uuid references public.bank_policies(id),
  citizen_id uuid,
  application_id uuid,
  kind text not null default 'preview' check (kind in ('preview', 'final', 'gate')),
  result text not null check (result in ('pass', 'fail', 'no_policy')),
  fails jsonb not null default '[]'::jsonb,
  ctx jsonb,
  created_at timestamptz not null default now()
);
create index if not exists policy_checks_bank on public.policy_checks(bank_id, created_at desc);

alter table public.bank_policies enable row level security;
alter table public.policy_checks enable row level security;
drop policy if exists read_bank_policies on public.bank_policies;
create policy read_bank_policies on public.bank_policies for select to authenticated
  using (bank_id = my_org() or my_portal() in ('cbi', 'admin', 'integrity', 'audit'));
drop policy if exists read_policy_checks on public.policy_checks;
create policy read_policy_checks on public.policy_checks for select to authenticated
  using (bank_id = my_org() or citizen_id = auth.uid() or my_portal() in ('cbi', 'admin', 'integrity', 'audit'));
grant select on public.bank_policies, public.policy_checks to authenticated;

-- الإعداد: تشغيل الحارس (1) أو إيقافه (0)
insert into public.settings(key, value, label) values ('policy_gate', 1, 'رفض التقديم المخالف لسياسة المصرف الائتمانية (1 تشغيل، 0 إيقاف)')
on conflict (key) do nothing;

-- ───────── 2) قاموس الحقول ─────────
create or replace function public._policy_fields() returns jsonb language sql immutable as $$
  select '{
    "age":         {"label": "العمر", "kind": "num", "unit": "سنة"},
    "age_end":     {"label": "العمر عند آخر قسط", "kind": "num", "unit": "سنة"},
    "salary":      {"label": "الدخل الشهري", "kind": "num", "unit": "د.ع"},
    "dti":         {"label": "نسبة القسط من الدخل", "kind": "num", "unit": "%"},
    "installment": {"label": "القسط الشهري", "kind": "num", "unit": "د.ع"},
    "amount":      {"label": "مبلغ التمويل", "kind": "num", "unit": "د.ع"},
    "term":        {"label": "مدة السداد", "kind": "num", "unit": "شهراً"},
    "employment":  {"label": "نوع العمل", "kind": "set"},
    "governorate": {"label": "المحافظة", "kind": "set"},
    "sector":      {"label": "نوع المشروع", "kind": "set"},
    "guarantee":   {"label": "الضمان", "kind": "set"}
  }'::jsonb $$;

create or replace function public._policy_val_label(p_field text, p_val text) returns text language sql immutable as $$
  select coalesce(case p_field
    when 'employment' then case p_val when 'gov' then 'موظف حكومي' when 'private' then 'قطاع خاص' when 'self' then 'عمل حر' end
    when 'guarantee' then case p_val when 'single_salary' then 'كفيل موظف واحد' when 'multi_salary' then 'كفيلان موظفان أو أكثر' when 'mortgage' then 'رهن عقار' when 'gold' then 'رهن ذهب' end
    when 'sector' then case p_val when 'residential' then 'منظومة سكنية' when 'industrial' then 'منظومة لمشروع صناعي' when 'project' then 'منظومة لمشروع تجاري أو خدمي'
      when 'agricultural' then 'منظومة لمشروع زراعي' when 'vet' then 'منظومة لمشروع بيطري' when 'export' then 'منظومة لمشروع تصدير' when 'other' then 'منظومة لمشروع آخر'
      when 'vet_program' then 'مبادرة الأطباء البيطريين' when 'export_program' then 'قروض المصدّرين' when 'commercial_program' then 'القروض التجارية'
      when 'ecommerce_program' then 'التجارة الإلكترونية' when 'industrial_program' then 'القروض الصناعية' end
  end, p_val) $$;

create or replace function public._policy_fmt(p_field text, p_v jsonb) returns text language plpgsql immutable as $$
declare f jsonb := _policy_fields() -> p_field; n numeric;
begin
  if p_v is null or jsonb_typeof(p_v) = 'null' then return '—'; end if;
  if jsonb_typeof(p_v) = 'array' then
    return (select string_agg(_policy_val_label(p_field, x), '، ') from jsonb_array_elements_text(p_v) x);
  end if;
  if f->>'kind' = 'num' then
    n := (p_v #>> '{}')::numeric;
    return case when f->>'unit' = '%' then trim(to_char(n, 'FM990.0')) || '%'
      else to_char(round(n), 'FM999,999,999,999') || ' ' || (f->>'unit') end;
  end if;
  return _policy_val_label(p_field, p_v #>> '{}');
end $$;

-- ───────── 3) تصنيف نوع العمل من جهة العمل (جزء من النموذج الداخلي) ─────────
create or replace function public._policy_emp_class(p_employer text, p_type text) returns text language plpgsql immutable as $$
declare e text := coalesce(p_employer, '');
begin
  if e ~ '(عمل حر|صاحب|كاسب|كسبة|مهنة حرة|أعمال حرة|اعمال حرة|مقاول|تاجر|متقاعد)' then return case when e ~ 'متقاعد' then 'gov' else 'self' end; end if;
  if e ~ '(وزارة|دائرة|مديرية|جامعة|هيئة|حكوم|محافظة|مجلس|مستشفى|مدرسة|شركة عامة|الشركة العامة|القطاع العام|الجيش|الشرطة|قوى الأمن|البنك المركزي|مصرف الرافدين|مصرف الرشيد)' then return 'gov'; end if;
  if e ~ '(شركة|القطاع الخاص|خاص|أهلي|اهلي|منظمة|مكتب)' then return 'private'; end if;
  return case lower(coalesce(p_type, '')) when 'gov' then 'gov' when 'public' then 'gov' when 'government' then 'gov'
    when 'private' then 'private' when 'self' then 'self' when 'freelance' then 'self' else null end;
end $$;

create or replace function public._policy_installment(p_amount numeric, p_rate numeric, p_months int) returns numeric language sql immutable as $$
  select case when coalesce(p_amount, 0) <= 0 or coalesce(p_months, 0) <= 0 then null
    when coalesce(p_rate, 0) = 0 then round(p_amount / p_months)
    else round(p_amount * (p_rate / 1200) / (1 - power(1 + p_rate / 1200, -p_months))) end $$;

-- ───────── 4) ملف المقترض للفحص ─────────
-- p: amount, term, installment, rate, program, purpose, sector, guarantee
create or replace function public._policy_ctx(p_citizen uuid, p_bank uuid, p jsonb) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me profiles; v_amount numeric; v_term int; v_rate numeric; v_ins numeric; v_age numeric; v_sector text; v_sal numeric;
begin
  select * into me from profiles where id = p_citizen;
  v_amount := nullif(p->>'amount', '')::numeric;
  v_term := nullif(p->>'term', '')::int;
  v_rate := coalesce(nullif(p->>'rate', '')::numeric,
    coalesce(_setting('cbi_rate'), 0) + (select margin from bank_terms where bank_id = p_bank));
  v_ins := coalesce(nullif(p->>'installment', '')::numeric, _policy_installment(v_amount, v_rate, v_term));
  v_age := case when me.birth_date is null then null else floor(extract(epoch from age(current_date, me.birth_date)) / 31557600) end;
  v_sal := nullif(me.monthly_salary, 0);
  v_sector := coalesce(nullif(p->>'sector', ''), case when p ? 'program' or p ? 'purpose' then _app_sector(nullif(p->>'program', ''), nullif(p->>'purpose', '')) end);
  return jsonb_strip_nulls(jsonb_build_object(
    'age', v_age,
    'age_end', case when v_age is not null and v_term is not null then round(v_age + v_term / 12.0, 1) end,
    'salary', v_sal,
    'dti', case when v_sal is not null and v_ins is not null then round(v_ins * 100 / v_sal, 1) end,
    'installment', v_ins,
    'amount', v_amount,
    'term', v_term,
    'employment', _policy_emp_class(me.employer, me.employment_type),
    'governorate', coalesce(nullif(p->>'governorate', ''), me.governorate),
    'sector', v_sector,
    'guarantee', nullif(p->>'guarantee', '')));
end $$;

-- ملف المقترض من طلب قائم
create or replace function public._policy_ctx_app(a applications, p_bank uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  return _policy_ctx(a.citizen_id, p_bank, jsonb_build_object(
    'amount', coalesce(a.amount, a.price, nullif(a.biz->>'amount', '')::bigint),
    'term', coalesce(a.term_months, (a.bank_choice->>'term_months')::int),
    'installment', a.monthly_installment,
    'rate', case when a.program_id is not null then a.margin end,
    'program', a.program, 'purpose', a.purpose,
    'governorate', a.governorate,
    'guarantee', a.guarantee_type));
end $$;

-- ───────── 5) إسقاط الشروط على الملف ─────────
create or replace function public._policy_eval(p_rules jsonb, p_ctx jsonb) returns jsonb
language plpgsql immutable as $$
declare r jsonb; f text; op text; v jsonb; lim numeric; x numeric; ok boolean; lbl text;
  fails jsonb := '[]'; unknown jsonb := '[]'; n int := 0; passed int := 0;
begin
  for r in select * from jsonb_array_elements(coalesce(p_rules, '[]'::jsonb)) loop
    f := r->>'field'; op := r->>'op'; v := p_ctx -> f; n := n + 1;
    lbl := coalesce(_policy_fields() -> f ->> 'label', f);
    if v is null or jsonb_typeof(v) = 'null' then
      unknown := unknown || jsonb_build_object('field', f, 'label', lbl, 'text', r->>'text'); continue;
    end if;
    if op in ('gte', 'lte') then
      x := (v #>> '{}')::numeric; lim := (r->>'value')::numeric;
      ok := case op when 'gte' then x >= lim else x <= lim end;
    elsif op = 'in' then ok := coalesce(r->'value', '[]') ? (v #>> '{}');
    elsif op = 'not_in' then ok := not (coalesce(r->'value', '[]') ? (v #>> '{}'));
    else continue; end if;
    if ok then passed := passed + 1;
    else
      fails := fails || jsonb_build_object('field', f, 'label', lbl, 'op', op, 'value', r->'value', 'actual', v, 'text', r->>'text',
        'msg', lbl || ' ' || _policy_fmt(f, v) || ' — ' || case op
          when 'gte' then 'السياسة تشترط ألا يقل عن ' || _policy_fmt(f, r->'value')
          when 'lte' then 'السياسة تشترط ألا يزيد على ' || _policy_fmt(f, r->'value')
          when 'in' then 'السياسة تقبل فقط: ' || _policy_fmt(f, r->'value')
          else 'السياسة لا تقبل: ' || _policy_fmt(f, r->'value') end);
    end if;
  end loop;
  return jsonb_build_object('result', case when n = 0 then 'no_policy' when jsonb_array_length(fails) > 0 then 'fail' else 'pass' end,
    'rules', n, 'passed', passed, 'fails', fails, 'unknown', unknown);
end $$;

-- التحقق من صحة الشروط قبل الحفظ أو التجربة
create or replace function public._policy_norm(p_rules jsonb) returns jsonb language plpgsql immutable as $$
declare r jsonb; f text; op text; k text; out jsonb := '[]'; i int := 0; vals jsonb;
begin
  if p_rules is null or jsonb_typeof(p_rules) <> 'array' then raise exception 'الشروط غير صحيحة'; end if;
  for r in select * from jsonb_array_elements(p_rules) loop
    i := i + 1; f := r->>'field'; op := r->>'op'; k := _policy_fields() -> f ->> 'kind';
    if k is null then raise exception 'الشرط %: حقل غير معروف «%»', i, coalesce(f, '—'); end if;
    if k = 'num' then
      if op not in ('gte', 'lte') then raise exception 'الشرط % (%): المقارنة «لا يقل عن» أو «لا يزيد على»', i, _policy_fields() -> f ->> 'label'; end if;
      if coalesce(r->>'value', '') !~ '^[0-9]+(\.[0-9]+)?$' then raise exception 'الشرط % (%): اكتب رقماً', i, _policy_fields() -> f ->> 'label'; end if;
      out := out || jsonb_build_object('field', f, 'op', op, 'value', (r->>'value')::numeric, 'text', left(coalesce(r->>'text', ''), 400));
    else
      if op not in ('in', 'not_in') then raise exception 'الشرط % (%): المقارنة «تقبل فقط» أو «لا تقبل»', i, _policy_fields() -> f ->> 'label'; end if;
      select coalesce(jsonb_agg(distinct x), '[]') into vals from jsonb_array_elements_text(case when jsonb_typeof(r->'value') = 'array' then r->'value' else '[]' end) x where trim(x) <> '';
      if jsonb_array_length(vals) = 0 then raise exception 'الشرط % (%): اختر قيمة واحدة على الأقل', i, _policy_fields() -> f ->> 'label'; end if;
      out := out || jsonb_build_object('field', f, 'op', op, 'value', vals, 'text', left(coalesce(r->>'text', ''), 400));
    end if;
  end loop;
  if jsonb_array_length(out) > 60 then raise exception 'السياسة تتجاوز 60 شرطاً'; end if;
  return out;
end $$;

create or replace function public._policy_active(p_bank uuid) returns bank_policies language sql stable security definer set search_path = public as $$
  select * from bank_policies where bank_id = p_bank and status = 'active' limit 1 $$;

-- برنامج الطلب كما في orgs.meta.programs
create or replace function public._policy_prog_key(p_program text) returns text language sql immutable as $$
  select case when p_program is null or p_program in ('solar', 'household') then 'solar' else p_program end $$;

-- المصارف التي يطابق الملف سياستها (للنصيحة)
create or replace function public._policy_alternatives(p_citizen uuid, p_exclude uuid, p jsonb) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare b orgs; pol bank_policies; ev jsonb; out jsonb := '[]'; k text := _policy_prog_key(p->>'program');
begin
  for b in select * from orgs o where o.type = 'bank' and o.id is distinct from p_exclude
      and coalesce((o.meta->>'accepting')::boolean, true)
      and (jsonb_typeof(o.meta->'programs') is distinct from 'array' or (o.meta->'programs') ? k)
      and (k <> 'solar' or exists (select 1 from bank_terms t where t.bank_id = o.id))
    order by o.name loop
    pol := _policy_active(b.id);
    ev := _policy_eval(pol.rules, _policy_ctx(p_citizen, b.id, p));
    if ev->>'result' <> 'fail' then
      out := out || jsonb_build_object('bank_id', b.id, 'name', b.name, 'result', ev->>'result', 'policy_version', pol.version);
    end if;
  end loop;
  return out;
end $$;

-- ───────── 6) واجهات المقترض ─────────
-- يعيد لكل مصرف يستقبل الطلبات: النتيجة والأسباب. p.final = true يسجّل الفحص (قبل بدء الطلب) — للمصرف p.log_bank فقط إن وُجد.
create or replace function public.policy_check(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me profiles; b orgs; pol bank_policies; ctx jsonb; ev jsonb; out jsonb := '[]'; k text := _policy_prog_key(p->>'program');
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'citizen' then raise exception 'فحص السياسة من بوابة المقترض'; end if;
  for b in select * from orgs o where o.type = 'bank' and coalesce((o.meta->>'accepting')::boolean, true)
      and (nullif(p->>'bank', '') is null or o.id = (p->>'bank')::uuid)
      and (jsonb_typeof(o.meta->'programs') is distinct from 'array' or (o.meta->'programs') ? k)
    order by o.name loop
    pol := _policy_active(b.id);
    ctx := _policy_ctx(me.id, b.id, p);
    ev := _policy_eval(pol.rules, ctx);
    if coalesce((p->>'final')::boolean, false) and (nullif(p->>'log_bank', '') is null or b.id = (p->>'log_bank')::uuid) then
      insert into policy_checks(bank_id, policy_id, citizen_id, kind, result, fails, ctx)
      values (b.id, pol.id, me.id, 'final', ev->>'result', ev->'fails', ctx);
    end if;
    out := out || (ev || jsonb_build_object('bank_id', b.id, 'name', b.name, 'policy_version', pol.version, 'policy_at', pol.created_at, 'ctx', ctx));
  end loop;
  return out;
end $$;

-- ───────── 7) الحارس على الطلبات ─────────
create or replace function public._policy_gate() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_bank uuid; v_old uuid; v_submit boolean := false; pol bank_policies; ctx jsonb; ev jsonb; alts jsonb; v_name text; p jsonb;
begin
  if coalesce((select value from settings where key = 'policy_gate'), 1) = 0 then return new; end if;
  if auth.uid() is null or new.citizen_id is null or auth.uid() <> new.citizen_id then return new; end if;
  if new.status not in ('active', 'returned') then return new; end if;
  v_bank := coalesce(nullif(new.bank_choice->>'bank_id', '')::uuid, new.bank_id);
  if v_bank is null then return new; end if;
  if tg_op = 'UPDATE' then
    v_old := coalesce(nullif(old.bank_choice->>'bank_id', '')::uuid, old.bank_id);
    v_submit := old.stage <= 5 and new.stage >= 6;
    if v_bank is not distinct from v_old and not v_submit then return new; end if;
  end if;
  pol := _policy_active(v_bank);
  if pol.id is null then return new; end if;
  ctx := _policy_ctx_app(new, v_bank);
  -- الضمان يُفحص عند الإرسال فقط (يُختار في الخطوة 4)
  if not v_submit then ctx := ctx - 'guarantee'; end if;
  ev := _policy_eval(pol.rules, ctx);
  if ev->>'result' = 'fail' then
    p := jsonb_build_object('amount', ctx->'amount', 'term', ctx->'term', 'program', new.program, 'purpose', new.purpose, 'governorate', new.governorate,
      'guarantee', case when v_submit then new.guarantee_type end);
    alts := _policy_alternatives(new.citizen_id, v_bank, p);
    select name into v_name from orgs where id = v_bank;
    raise exception 'POLICY_REJECT: طلبك لا يطابق السياسة الائتمانية لدى «%» (الإصدار %): %.%', v_name, pol.version,
      (select string_agg(x->>'msg', '؛ ') from jsonb_array_elements(ev->'fails') x),
      case when jsonb_array_length(alts) > 0 then ' ننصحك بالتقديم لدى: ' || (select string_agg('«' || (x->>'name') || '»', '، ') from jsonb_array_elements(alts) x) || '.'
        else ' لا يوجد الآن مصرف آخر يطابق طلبك سياسته — جرّب مبلغاً أقل أو مدة أطول.' end
      using errcode = 'P0001';
  end if;
  insert into policy_checks(bank_id, policy_id, citizen_id, application_id, kind, result, fails, ctx)
  values (v_bank, pol.id, new.citizen_id, case when tg_op = 'UPDATE' then new.id end, 'gate', ev->>'result', '[]', ctx);
  return new;
end $$;
drop trigger if exists trg_a2_policy_gate on public.applications;
create trigger trg_a2_policy_gate before insert or update on public.applications for each row execute function public._policy_gate();

-- ───────── 8) واجهات المصرف ─────────
create or replace function public._policy_me(p_md boolean default false) returns profiles
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'bank' or coalesce(me.disabled, false) then raise exception 'السياسة الائتمانية لموظفي المصرف'; end if;
  if p_md and me.role <> 'bank_md' then raise exception 'اعتماد السياسة الائتمانية صلاحية الإدارة العليا للمصرف'; end if;
  return me;
end $$;

-- تجربة شروط (محفوظة أو غير محفوظة) على مقترض افتراضي
create or replace function public.policy_simulate(p_rules jsonb, p_ctx jsonb) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me profiles := _policy_me(); ctx jsonb; sal numeric; ins numeric; age numeric; term int; rate numeric;
begin
  ctx := jsonb_strip_nulls(p_ctx);
  term := nullif(ctx->>'term', '')::int; sal := nullif(ctx->>'salary', '')::numeric; age := nullif(ctx->>'age', '')::numeric;
  rate := coalesce(_setting('cbi_rate'), 0) + coalesce((select margin from bank_terms where bank_id = me.org_id), 0);
  ins := coalesce(nullif(ctx->>'installment', '')::numeric, _policy_installment(nullif(ctx->>'amount', '')::numeric, rate, term));
  if ins is not null then ctx := ctx || jsonb_build_object('installment', ins); end if;
  if ins is not null and sal > 0 and not ctx ? 'dti' then ctx := ctx || jsonb_build_object('dti', round(ins * 100 / sal, 1)); end if;
  if age is not null and term is not null and not ctx ? 'age_end' then ctx := ctx || jsonb_build_object('age_end', round(age + term / 12.0, 1)); end if;
  return _policy_eval(_policy_norm(p_rules), ctx) || jsonb_build_object('ctx', ctx);
end $$;

-- اختبار رجعي: ماذا لو طُبّقت الشروط على طلبات المصرف (آخر 500 طلب)
create or replace function public.policy_backtest(p_rules jsonb) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me profiles := _policy_me(); a applications; rules jsonb := _policy_norm(p_rules); ev jsonb; n int := 0; nf int := 0;
  samples jsonb := '[]'; reasons jsonb := '{}'; x jsonb;
begin
  for a in select * from applications where coalesce(nullif(bank_choice->>'bank_id', '')::uuid, bank_id) = me.org_id and citizen_id is not null
      order by created_at desc limit 500 loop
    ev := _policy_eval(rules, _policy_ctx_app(a, me.org_id));
    n := n + 1;
    if ev->>'result' = 'fail' then
      nf := nf + 1;
      for x in select * from jsonb_array_elements(ev->'fails') loop
        reasons := jsonb_set(reasons, array[x->>'label'], to_jsonb(coalesce((reasons->>(x->>'label'))::int, 0) + 1));
      end loop;
      if jsonb_array_length(samples) < 15 then
        samples := samples || jsonb_build_object('code', a.code, 'name', a.citizen_name, 'stage', a.stage, 'status', a.status,
          'fails', (select jsonb_agg(f->>'msg') from jsonb_array_elements(ev->'fails') f));
      end if;
    end if;
  end loop;
  return jsonb_build_object('total', n, 'fail', nf, 'pass', n - nf, 'reasons', reasons, 'samples', samples);
end $$;

create or replace function public.bank_policy_save(p_text text, p_rules jsonb, p_unparsed jsonb default '[]'::jsonb, p_title text default null) returns bank_policies
language plpgsql security definer set search_path = public, extensions as $$
declare me profiles := _policy_me(true); rules jsonb := _policy_norm(p_rules); pol bank_policies; v int;
begin
  if length(trim(coalesce(p_text, ''))) < 20 then raise exception 'اكتب نص السياسة الائتمانية (20 حرفاً على الأقل)'; end if;
  if jsonb_array_length(rules) = 0 then raise exception 'لا شروط في السياسة — حلّلها بالنموذج أو أضف شرطاً'; end if;
  perform 1 from orgs where id = me.org_id for update;
  select coalesce(max(version), 0) + 1 into v from bank_policies where bank_id = me.org_id;
  update bank_policies set status = 'superseded', ended_at = now(), ended_by_name = me.full_name where bank_id = me.org_id and status = 'active';
  insert into bank_policies(bank_id, version, status, title, policy_text, rules, unparsed, sha256, created_by, created_by_name)
  values (me.org_id, v, 'active', nullif(left(trim(coalesce(p_title, '')), 120), ''), trim(p_text), rules,
    coalesce(case when jsonb_typeof(p_unparsed) = 'array' then p_unparsed end, '[]'),
    encode(extensions.digest(trim(p_text) || rules::text, 'sha256'), 'hex'), me.id, me.full_name)
  returning * into pol;
  return pol;
end $$;

create or replace function public.bank_policy_disable(p_note text) returns boolean
language plpgsql security definer set search_path = public as $$
declare me profiles := _policy_me(true);
begin
  if length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب سبب إيقاف السياسة'; end if;
  update bank_policies set status = 'disabled', ended_at = now(), ended_by_name = me.full_name || ' — ' || trim(p_note)
  where bank_id = me.org_id and status = 'active';
  return found;
end $$;

-- إحصاء الفحوص لمصرف (المصرف لنفسه، والبنك المركزي والمشغّل لأي مصرف)
create or replace function public.policy_stats(p_bank uuid default null, p_days int default 30) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_bank uuid := coalesce(p_bank, my_org()); r jsonb;
begin
  if not (v_bank = my_org() or my_portal() in ('cbi', 'admin', 'integrity', 'audit')) then raise exception 'لا صلاحية'; end if;
  select jsonb_build_object(
    'total', count(*), 'fail', count(*) filter (where result = 'fail'), 'pass', count(*) filter (where result = 'pass'),
    'citizens', count(distinct citizen_id),
    'reasons', coalesce((select jsonb_object_agg(l, c) from (select f->>'label' l, count(*) c from policy_checks pc2, jsonb_array_elements(pc2.fails) f
        where pc2.bank_id = v_bank and pc2.kind in ('final', 'gate') and pc2.created_at > now() - make_interval(days => p_days) group by 1) z), '{}'))
  into r from policy_checks where bank_id = v_bank and kind in ('final', 'gate') and created_at > now() - make_interval(days => p_days);
  return r;
end $$;

-- ───────── 9) التحقق بالوجه على تعديل السياسة (الجلسة 49) ─────────
do $$ begin
  if to_regprocedure('public._face_gate()') is not null then
    execute 'drop trigger if exists trg_zz_face_gate on public.bank_policies';
    execute 'create trigger trg_zz_face_gate after insert or update or delete on public.bank_policies for each row execute function public._face_gate()';
  end if;
end $$;

-- ───────── 10) الصلاحيات ─────────
revoke all on function public._policy_ctx(uuid, uuid, jsonb), public._policy_ctx_app(applications, uuid), public._policy_alternatives(uuid, uuid, jsonb),
  public._policy_active(uuid), public._policy_me(boolean), public._policy_gate() from public, anon, authenticated;
revoke all on function public.policy_check(jsonb), public.policy_simulate(jsonb, jsonb), public.policy_backtest(jsonb),
  public.bank_policy_save(text, jsonb, jsonb, text), public.bank_policy_disable(text), public.policy_stats(uuid, int) from public, anon;
grant execute on function public.policy_check(jsonb), public.policy_simulate(jsonb, jsonb), public.policy_backtest(jsonb),
  public.bank_policy_save(text, jsonb, jsonb, text), public.bank_policy_disable(text), public.policy_stats(uuid, int),
  public._policy_fields(), public._policy_val_label(text, text), public._policy_fmt(text, jsonb), public._policy_eval(jsonb, jsonb), public._policy_norm(jsonb) to authenticated;

-- ───────── 11) سياسات العرض للمصارف الأربعة، ومقترضة تجريبية citizen11 ─────────
do $$
declare b uuid; u uuid;
begin
  -- مصرف السنابل التجاري: لا يمول العمل الحر، دخل لا يقل عن مليون
  select id into b from orgs where code = 'bank1';
  if b is not null and not exists (select 1 from bank_policies where bank_id = b) then
    insert into bank_policies(bank_id, version, status, title, policy_text, rules, sha256, created_by_name) values (b, 1, 'active', 'سياسة الائتمان الشخصي 2026',
$t$1. يُشترط ألا يقل عمر المقترض عن 21 سنة ولا يزيد على 60 سنة عند تقديم الطلب.
2. ألا يتجاوز عمر المقترض 65 سنة عند انتهاء التمويل.
3. ألا يقل الدخل الشهري الصافي عن مليون دينار.
4. ألا يتجاوز القسط الشهري 50% من الدخل.
5. يُمنح التمويل للموظفين في القطاع الحكومي والقطاع الخاص فقط، ولا يُقبل أصحاب العمل الحر.
6. الحد الأعلى للتمويل 30 مليون دينار.$t$,
      '[{"field":"age","op":"gte","value":21,"text":"يُشترط ألا يقل عمر المقترض عن 21 سنة"},{"field":"age","op":"lte","value":60,"text":"ولا يزيد على 60 سنة عند تقديم الطلب"},
        {"field":"age_end","op":"lte","value":65,"text":"ألا يتجاوز عمر المقترض 65 سنة عند انتهاء التمويل"},{"field":"salary","op":"gte","value":1000000,"text":"ألا يقل الدخل الشهري الصافي عن مليون دينار"},
        {"field":"dti","op":"lte","value":50,"text":"ألا يتجاوز القسط الشهري 50% من الدخل"},{"field":"employment","op":"in","value":["gov","private"],"text":"يُمنح التمويل للموظفين في القطاع الحكومي والقطاع الخاص فقط، ولا يُقبل أصحاب العمل الحر"},
        {"field":"amount","op":"lte","value":30000000,"text":"الحد الأعلى للتمويل 30 مليون دينار"}]'::jsonb,
      null, 'الإدارة العليا — مصرف السنابل التجاري');
  end if;
  -- مصرف الواحة الإسلامي: أوسع
  select id into b from orgs where code = 'bank2';
  if b is not null and not exists (select 1 from bank_policies where bank_id = b) then
    insert into bank_policies(bank_id, version, status, title, policy_text, rules, created_by_name) values (b, 1, 'active', 'ضوابط التمويل الإسلامي للأفراد',
$t$- عمر المتعامل بين 21 و65 سنة، وألا يتجاوز 70 سنة عند آخر قسط.
- ألا يقل الدخل الشهري عن 600 ألف دينار.
- ألا تزيد نسبة القسط من الدخل على 60%.
- نقبل الموظفين والقطاع الخاص وأصحاب العمل الحر.
- أقصى مبلغ تمويل 40 مليون دينار.$t$,
      '[{"field":"age","op":"gte","value":21,"text":"عمر المتعامل بين 21 و65 سنة"},{"field":"age","op":"lte","value":65,"text":"عمر المتعامل بين 21 و65 سنة"},
        {"field":"age_end","op":"lte","value":70,"text":"ألا يتجاوز 70 سنة عند آخر قسط"},{"field":"salary","op":"gte","value":600000,"text":"ألا يقل الدخل الشهري عن 600 ألف دينار"},
        {"field":"dti","op":"lte","value":60,"text":"ألا تزيد نسبة القسط من الدخل على 60%"},{"field":"employment","op":"in","value":["gov","private","self"],"text":"نقبل الموظفين والقطاع الخاص وأصحاب العمل الحر"},
        {"field":"amount","op":"lte","value":40000000,"text":"أقصى مبلغ تمويل 40 مليون دينار"}]'::jsonb, 'الإدارة العليا — مصرف الواحة الإسلامي');
  end if;
  -- المصرف الصناعي: مشاريع، بلا نسبة دخل
  select id into b from orgs where code = 'ind';
  if b is not null and not exists (select 1 from bank_policies where bank_id = b) then
    insert into bank_policies(bank_id, version, status, title, policy_text, rules, created_by_name) values (b, 1, 'active', 'سياسة تمويل المشاريع',
$t$عمر صاحب المشروع لا يقل عن 21 سنة ولا يزيد على 65 سنة.
الحد الأعلى للتمويل 500 مليون دينار.
الحد الأدنى للدخل الشهري 500 ألف دينار.$t$,
      '[{"field":"age","op":"gte","value":21,"text":"عمر صاحب المشروع لا يقل عن 21 سنة"},{"field":"age","op":"lte","value":65,"text":"ولا يزيد على 65 سنة"},
        {"field":"amount","op":"lte","value":500000000,"text":"الحد الأعلى للتمويل 500 مليون دينار"},{"field":"salary","op":"gte","value":500000,"text":"الحد الأدنى للدخل الشهري 500 ألف دينار"}]'::jsonb,
      'الإدارة العليا — المصرف الصناعي العراقي');
  end if;
  select id into b from orgs where code = 'tpi';
  if b is not null and not exists (select 1 from bank_policies where bank_id = b) then
    insert into bank_policies(bank_id, version, status, title, policy_text, rules, created_by_name) values (b, 1, 'active', 'سياسة البرامج التجارية',
$t$يُشترط ألا يقل عمر المقترض عن 21 سنة ولا يزيد على 65 سنة.
الحد الأعلى للتمويل 300 مليون دينار.$t$,
      '[{"field":"age","op":"gte","value":21,"text":"يُشترط ألا يقل عمر المقترض عن 21 سنة"},{"field":"age","op":"lte","value":65,"text":"ولا يزيد على 65 سنة"},
        {"field":"amount","op":"lte","value":300000000,"text":"الحد الأعلى للتمويل 300 مليون دينار"}]'::jsonb, 'الإدارة العليا — مصرف TPI');
  end if;
  update bank_policies set sha256 = encode(extensions.digest(policy_text || rules::text, 'sha256'), 'hex') where sha256 is null;

  -- citizen11: عمل حر ودخل 800 ألف — يرفضها السنابل ويُنصح بالواحة
  if not exists (select 1 from profiles where username = 'citizen11') and not exists (select 1 from profiles where phone = '07701239011') then
    u := _mk_user('citizen11', 'Alwah@1011', 'زينب حسين العبودي', 'citizen', 'citizen', null, '07701239011', '198105200911');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'البصرة', city = 'العشار', employer = 'عمل حر — مشغل خياطة',
      monthly_salary = 800000, birth_date = '1981-05-20', must_change_password = false where id = u;
  end if;
end $$;

reset check_function_bodies;
