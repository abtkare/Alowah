-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 40: إضافة الجهات وشركات التأمين
--  1) مشغّل النظام يضيف أي جهة (مصرف، مورد منظومات شمسية، مورد أجهزة ومواد بيطرية، شركة فحص هندسي، شركة تأمين)
--     بخطوة واحدة: الجهة + فرعها الرئيسي + حساب الإدارة العليا (مدير الجهة). ويضيف إدارة عليا ثانية، ويوقف الجهة أو يعيدها.
--  2) الإدارة العليا تُعِدّ كل حسابات موظفيها من «فريقي» (يوزر وباسورد لكل موظف قسم)، وتضيف فروعها وتعيّن مديري الفروع.
--  3) بوابة شركات التأمين (/insurance): دورة الوثيقة على المشروع الممول داخل الشركة
--     طلب وارد ← الاكتتاب ← المعاينة بالـGPS ← التسعير ← الاعتماد (مدير الفرع ضمن سقفه أو الإدارة العليا) ← تسديد القسط ← وثيقة سارية ببصمة
--     ← تجديد سنوي أو إلغاء. والمطالبات: إبلاغ ← معاينة الضرر ← التقدير ← الاعتماد ← الصرف للمستفيد (المصرف).
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة ونوع المستند ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance','trade','eng_audit','sharia','insurer']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance','trade','auditor','sharia','insurance']));
alter table public.app_documents drop constraint if exists app_documents_kind_check;
alter table public.app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site','mortgage_letter','annotation_mark','dd_letter','dd_auth','kyc_face','contract_signed','feasibility','expert_report','install_panels','install_inverter','install_video','eng_photo','ins_photo']));

-- ملخص التأمين على الطلب نفسه (تقرؤه لوحات الجهات مباشرة)
alter table public.applications add column if not exists insurance_status text;   -- requested | underwriting | payment | active | declined | cancelled | expired
alter table public.applications add column if not exists insurance jsonb;          -- {org, policy_no, premium, start, end, code}

insert into public.settings(key, value, label, circular_no) values
  ('ins_auto', 1, 'طلب التأمين آلياً عند وصول الطلب إلى المرحلة 30 (1 = نعم)', null),
  ('ins_required', 0, 'لا يُصرف للمورد (المرحلة 35) قبل وثيقة تأمين سارية (1 = إلزامي)', null),
  ('ins_sla_days', 5, 'مهلة شركة التأمين لإصدار الوثيقة (أيام)', null)
on conflict (key) do nothing;

-- ───────── 2) الأدوار ─────────
-- شركة التأمين: الإدارة العليا (مدير الجهة) ← مدير الفرع ← الاكتتاب، المعاينة، المطالبات، الحسابات
create or replace function public._org_roles(p_type text) returns text[] language sql immutable as $f$
  select case p_type
    when 'bank' then array['bank_cs','bank_compliance','bank_branch_mgr','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection',
                           'bank_legal','bank_md','bank_admin','bank_ops','bank_teller','bank_collection','bank_risk','bank_committee','bank_payroll','bank_islamic_products']
    when 'cbi' then array['cbi_admin'] when 'supplier' then array['supplier_admin', 'supplier_tech'] when 'syndicate' then array['syndicate_officer']
    when 'vetdept' then array['vetdept_officer'] when 'registry' then array['registry_officer'] when 'integrity' then array['integrity_viewer']
    when 'expert' then array['expert'] when 'audit' then array['audit_viewer'] when 'planning' then array['planning_officer'] when 'finance' then array['finance_officer'] when 'trade' then array['trade_hr', 'trade_payroll', 'trade_guarantees', 'trade_admin', 'trade_signer', 'trade_officer'] when 'eng_audit' then array['auditor_engineer', 'auditor_admin'] when 'sharia' then array['sharia_member', 'sharia_secretary', 'sharia_head']
    when 'insurer' then array['ins_branch_mgr', 'ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance', 'ins_md']
    else array[]::text[] end $f$;

create or replace function public._portal_of_role(r text) returns text language sql immutable as $f$
  select case when r like 'bank\_%' then 'bank' when r = 'cbi_admin' then 'cbi' when r = 'registry_officer' then 'registry'
    when r in ('supplier_admin', 'supplier_tech') then 'supplier' when r = 'integrity_viewer' then 'integrity' when r = 'syndicate_officer' then 'syndicate'
    when r = 'vetdept_officer' then 'vetdept' when r = 'platform_admin' then 'admin' when r = 'expert' then 'expert' when r = 'audit_viewer' then 'audit' when r = 'planning_officer' then 'planning' when r = 'finance_officer' then 'finance' when r in ('trade_officer', 'trade_hr', 'trade_payroll', 'trade_guarantees', 'trade_admin', 'trade_signer') then 'trade' when r in ('auditor_admin', 'auditor_engineer') then 'auditor' when r in ('sharia_head', 'sharia_member', 'sharia_secretary') then 'sharia'
    when r in ('ins_md', 'ins_branch_mgr', 'ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance') then 'insurance'
    when r = 'citizen' then 'citizen' end $f$;

create or replace function public._org_type_of_portal(p text) returns text language sql immutable as $f$
  select case p when 'bank' then 'bank' when 'cbi' then 'cbi' when 'registry' then 'registry' when 'supplier' then 'supplier'
    when 'integrity' then 'integrity' when 'syndicate' then 'syndicate' when 'vetdept' then 'vetdept' when 'admin' then 'platform' when 'expert' then 'expert'
    when 'audit' then 'audit' when 'planning' then 'planning' when 'finance' then 'finance' when 'trade' then 'trade' when 'auditor' then 'eng_audit' when 'sharia' then 'sharia'
    when 'insurance' then 'insurer' end $f$;

create or replace function public._role_abbr(r text) returns text language sql immutable as $f$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'bank_payroll' then 'PR' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'supplier_tech' then 'TC' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'expert' then 'EX' when 'audit_viewer' then 'FA' when 'planning_officer' then 'PL' when 'finance_officer' then 'MF' when 'trade_officer' then 'MT' when 'trade_hr' then 'MH' when 'trade_payroll' then 'MP' when 'trade_guarantees' then 'MG' when 'trade_admin' then 'MA' when 'trade_signer' then 'MS' when 'auditor_admin' then 'EA' when 'auditor_engineer' then 'EN' when 'sharia_head' then 'SH' when 'sharia_member' then 'SM' when 'sharia_secretary' then 'SS' when 'bank_islamic_products' then 'IP'
    when 'ins_md' then 'GM' when 'ins_branch_mgr' then 'BM' when 'ins_underwriter' then 'UW' when 'ins_surveyor' then 'SV' when 'ins_claims' then 'CL' when 'ins_finance' then 'FN'
    when 'platform_admin' then 'SA' else 'XX' end $f$;

create or replace function public._role_title(r text) returns text language sql immutable as $f$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'bank_payroll' then 'موظف توطين الرواتب — الاستقطاع المباشر'
    when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'supplier_tech' then 'الفني المختص — فريق التركيب لدى المورد'
    when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'expert' then 'خبير معتمد — دراسات الجدوى'
    when 'audit_viewer' then 'مراقب مالي — ديوان الرقابة المالية الاتحادي' when 'planning_officer' then 'مخطط — وزارة التخطيط' when 'finance_officer' then 'محلل مالي — وزارة المالية' when 'trade_officer' then 'مدير الجهة — وزارة التجارة (المتابعة والفريق)' when 'trade_hr' then 'موظف الموارد البشرية وشؤون الموظفين — وزارة التجارة' when 'trade_payroll' then 'موظف الحسابات والرواتب — وزارة التجارة' when 'trade_guarantees' then 'موظف وحدة الكفالات والالتزامات — وزارة التجارة' when 'trade_admin' then 'المسؤول الإداري المخوَّل — وزارة التجارة' when 'trade_signer' then 'صاحب الصلاحية (المدير العام) — وزارة التجارة' when 'auditor_admin' then 'مدير شركة التدقيق الهندسي' when 'auditor_engineer' then 'مهندس فاحص — شركة التدقيق الهندسي' when 'sharia_head' then 'رئيس الهيئة الشرعية' when 'sharia_member' then 'عضو الهيئة الشرعية' when 'sharia_secretary' then 'أمين سر الهيئة الشرعية' when 'bank_islamic_products' then 'مسؤول المنتجات الإسلامية'
    when 'ins_md' then 'الإدارة العليا لشركة التأمين' when 'ins_branch_mgr' then 'مدير فرع شركة التأمين' when 'ins_underwriter' then 'موظف الاكتتاب والتسعير'
    when 'ins_surveyor' then 'المعاين الفني — الكشف على الأخطار والأضرار' when 'ins_claims' then 'موظف المطالبات والتعويضات' when 'ins_finance' then 'موظف الحسابات — الأقساط والتعويضات'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $f$;

-- أدوار الفرع حسب نوع الجهة (يمنحها مدير الفرع)، ومدير الفرع لكل نوع
create or replace function public._branch_roles_of(p_type text) returns text[] language sql immutable as $f$
  select case p_type when 'bank' then _branch_roles() when 'insurer' then array['ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance'] else array[]::text[] end $f$;
create or replace function public._is_branch_mgr_role(r text) returns boolean language sql immutable as $f$
  select r in ('bank_branch_mgr', 'ins_branch_mgr') $f$;
-- الجهات التي لها فروع
create or replace function public._has_branches(p_type text) returns boolean language sql immutable as $f$
  select p_type in ('bank', 'insurer') $f$;

create or replace function public._mgr_roles(m profiles) returns text[] language sql stable security definer set search_path to 'public' as $f$
  select case m.manage_scope
    when 'org' then _org_roles((select type from orgs where id = m.org_id))
    when 'branch' then _branch_roles_of((select type from orgs where id = m.org_id))
    when 'dept' then _dept_roles(m.role)
    else array[]::text[] end $f$;

-- ───────── 3) «فريقي»: مدير الفرع في شركات التأمين، والفروع ─────────
create or replace function public.team_meta() returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare m profiles := _mgr(); o orgs;
begin
  select * into o from orgs where id = m.org_id;
  return jsonb_build_object(
    'scope', m.manage_scope, 'scope_title', _scope_title(m.manage_scope), 'org_id', o.id, 'org_name', o.name, 'org_type', o.type, 'branch_id', m.branch_id,
    'roles', (select coalesce(jsonb_agg(jsonb_build_object('role', r, 'title', _role_title(r)) order by ord), '[]') from unnest(_mgr_roles(m)) with ordinality x(r, ord)),
    'branches', case when m.manage_scope = 'branch' then (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name)), '[]') from branches where id = m.branch_id)
                     when m.manage_scope = 'org' then (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name) order by is_main desc, code), '[]') from branches where bank_id = m.org_id)
                     else '[]'::jsonb end,
    'can_grant', case when m.manage_scope = 'org' and o.type = 'bank' then '["branch","dept"]'::jsonb
                      when m.manage_scope = 'org' and o.type = 'insurer' then '["branch"]'::jsonb else '[]'::jsonb end,
    'branch_mgr_role', case o.type when 'bank' then 'bank_branch_mgr' when 'insurer' then 'ins_branch_mgr' end,
    'can_branches', m.manage_scope = 'org' and _has_branches(o.type),
    'stages', (select coalesce(jsonb_agg(jsonb_build_object('n', n, 'name', name, 'owner_role', owner_role, 'owner_label', owner_label, 'branch_level', branch_level) order by n), '[]')
               from stages where owner_role = any(_mgr_roles(m)) and not batch_only
                 and (m.manage_scope <> 'branch' or branch_level or owner_role = any(_branch_roles()))));
end $f$;

create or replace function public.team_create_user(p jsonb) returns profiles
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare m profiles := _mgr(); v_user text := lower(trim(coalesce(p->>'username', ''))); v_role text := p->>'role'; v_br uuid; v_scope text := nullif(p->>'manage_scope', '');
  uid uuid; pr profiles; o orgs;
begin
  select * into o from orgs where id = m.org_id;
  if not (v_role = any(_mgr_roles(m))) then raise exception 'هذا الدور خارج صلاحيتك — الأدوار المسموحة لك تظهر في القائمة'; end if;
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم مستخدم مسبقاً'; end if;
  if length(coalesce(p->>'password', '')) < 8 or (p->>'password') !~ '[0-9]' or (p->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if length(trim(coalesce(p->>'full_name', ''))) < 3 then raise exception 'اكتب الاسم الكامل'; end if;
  -- الفرع حسب النطاق: مدير الفرع ← فرعه حتماً، مدير القسم ← الإدارة العامة، مدير الجهة ← أي فرع من جهته
  v_br := case m.manage_scope when 'branch' then m.branch_id when 'dept' then null else nullif(p->>'branch_id', '')::uuid end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = m.org_id) then raise exception 'الفرع لا يتبع جهتك'; end if;
  if o.type = 'bank' and v_role in ('bank_cs', 'bank_teller', 'bank_branch_mgr') and v_br is null then raise exception 'هذا الدور في الفرع — اختر الفرع'; end if;
  if o.type = 'insurer' and v_role = 'ins_branch_mgr' and v_br is null then raise exception 'مدير الفرع مربوط بفرع — اختر الفرع'; end if;
  if v_scope is not null then
    if m.manage_scope <> 'org' then raise exception 'نطاق الإدارة يمنحه مدير الجهة فقط'; end if;
    if v_scope = 'org' then raise exception 'مدير الجهة يعيّنه مشغّل النظام فقط'; end if;
    if v_scope = 'branch' and (not _is_branch_mgr_role(v_role) or v_br is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
    if v_scope = 'dept' and (cardinality(_dept_roles(v_role)) = 0 or v_br is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  end if;
  uid := _mk_user(v_user, p->>'password', trim(p->>'full_name'), v_role, _portal_of_role(v_role), o.code, _opt_phone(p->>'phone'), null);
  update profiles set branch_id = v_br, manage_scope = v_scope, must_change_password = true, managed_by = m.id where id = uid returning * into pr;
  perform _taudit('إنشاء موظف', v_user, jsonb_build_object('role', _role_title(v_role), 'branch', (select name from branches where id = v_br), 'manage', _scope_title(v_scope)), m.org_id, v_br);
  return pr;
end $f$;

create or replace function public.team_update_user(p_user uuid, p jsonb) returns profiles
language plpgsql security definer set search_path to 'public' as $f$
declare m profiles := _mgr(); t profiles; v_role text; v_br uuid; v_scope text; ch jsonb := '{}';
begin
  select * into t from profiles where id = p_user;
  if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if;
  v_role := coalesce(nullif(p->>'role', ''), t.role);
  if not (v_role = any(_mgr_roles(m))) then raise exception 'هذا الدور خارج صلاحيتك'; end if;
  v_br := case m.manage_scope when 'branch' then m.branch_id when 'dept' then null
               else case when p ? 'branch_id' then nullif(p->>'branch_id', '')::uuid else t.branch_id end end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = m.org_id) then raise exception 'الفرع لا يتبع جهتك'; end if;
  v_scope := case when p ? 'manage_scope' then nullif(p->>'manage_scope', '') else t.manage_scope end;
  if v_scope is distinct from t.manage_scope or (v_scope is not null and (v_role <> t.role or v_br is distinct from t.branch_id)) then
    if m.manage_scope <> 'org' then raise exception 'نطاق الإدارة يغيّره مدير الجهة فقط'; end if;
    if v_scope = 'org' then raise exception 'مدير الجهة يعيّنه مشغّل النظام فقط'; end if;
    if v_scope = 'branch' and (not _is_branch_mgr_role(v_role) or v_br is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
    if v_scope = 'dept' and (cardinality(_dept_roles(v_role)) = 0 or v_br is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  end if;
  if v_role <> t.role then ch := ch || jsonb_build_object('role', _role_title(t.role) || ' ← ' || _role_title(v_role)); end if;
  if v_br is distinct from t.branch_id then ch := ch || jsonb_build_object('branch', coalesce((select name from branches where id = t.branch_id), 'الإدارة العامة') || ' ← ' || coalesce((select name from branches where id = v_br), 'الإدارة العامة')); end if;
  if v_scope is distinct from t.manage_scope then ch := ch || jsonb_build_object('manage', coalesce(_scope_title(t.manage_scope), 'بلا') || ' ← ' || coalesce(_scope_title(v_scope), 'بلا')); end if;
  if nullif(trim(p->>'full_name'), '') is distinct from null and trim(p->>'full_name') <> t.full_name then ch := ch || jsonb_build_object('name', trim(p->>'full_name')); end if;
  if p ? 'phone' and _opt_phone(p->>'phone') is distinct from t.phone then ch := ch || jsonb_build_object('phone', 'تحديث'); end if;
  update profiles set full_name = coalesce(nullif(trim(p->>'full_name'), ''), full_name), role = v_role, branch_id = v_br, manage_scope = v_scope,
    phone = case when p ? 'phone' then _opt_phone(p->>'phone') else phone end, updated_at = now()
  where id = p_user returning * into t;
  -- المسند إليه مرحلة بدور غير دوره بعد التعديل: يُزال الإسناد
  delete from stage_assignments s using stages st where st.n = s.stage and s.user_id = t.id and st.owner_role <> t.role;
  update stage_assignments s set backup_id = null from stages st where st.n = s.stage and s.backup_id = t.id and st.owner_role <> t.role;
  -- نُقل إلى فرع آخر: يُزال من إسنادات فرعه القديم
  delete from stage_assignments s where s.user_id = t.id and s.branch_id is not null and s.branch_id is distinct from t.branch_id;
  update stage_assignments s set backup_id = null where s.backup_id = t.id and s.branch_id is not null and s.branch_id is distinct from t.branch_id;
  perform _taudit('تعديل موظف', t.username, ch, m.org_id, t.branch_id);
  return t;
end $f$;

create or replace function public.admin_set_manage_scope(p_user uuid, p_scope text) returns profiles
language plpgsql security definer set search_path to 'public' as $f$
declare t profiles; v text := nullif(p_scope, '');
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into t from profiles where id = p_user;
  if t is null or t.portal in ('citizen', 'admin') then raise exception 'اختر موظفاً في جهة'; end if;
  if v is not null and v not in ('org', 'branch', 'dept') then raise exception 'نطاق غير معروف'; end if;
  if v = 'branch' and (not _is_branch_mgr_role(t.role) or t.branch_id is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
  if v = 'dept' and (cardinality(_dept_roles(t.role)) = 0 or t.branch_id is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  update profiles set manage_scope = v, updated_at = now() where id = p_user returning * into t;
  perform _taudit(case when v is null then 'سحب صلاحية الإدارة' else 'تعيين ' || _scope_title(v) end, t.username, null, t.org_id, t.branch_id);
  return t;
end $f$;

-- الفروع: الإدارة العليا للمصرف أو لشركة التأمين تضيف فروعها وتعدّلها
create or replace function public.team_branches() returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare m profiles := _mgr();
begin
  return (select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'code', b.code, 'name', b.name, 'governorates', to_jsonb(coalesce(b.governorates, '{}')), 'is_main', b.is_main,
      'phone', b.complaint_phone, 'staff', (select count(*) from profiles p where p.branch_id = b.id and not coalesce(p.disabled, false)),
      'manager', (select full_name from profiles p where p.branch_id = b.id and p.manage_scope = 'branch' and not coalesce(p.disabled, false) limit 1))
    order by b.is_main desc, b.code), '[]') from branches b where b.bank_id = m.org_id and (m.manage_scope = 'org' or b.id = m.branch_id));
end $f$;

create or replace function public.team_save_branch(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare m profiles := _mgr(); o orgs; b branches; v_govs text[]; pre text; n int; v_name text := trim(coalesce(p->>'name', ''));
begin
  select * into o from orgs where id = m.org_id;
  if m.manage_scope <> 'org' or not _has_branches(o.type) then raise exception 'إضافة الفروع للإدارة العليا للمصرف أو لشركة التأمين فقط'; end if;
  if length(v_name) < 3 then raise exception 'اكتب اسم الفرع'; end if;
  select coalesce(array_agg(x), '{}') into v_govs from jsonb_array_elements_text(coalesce(p->'governorates', '[]'::jsonb)) x;
  if nullif(p->>'id', '') is not null then
    select * into b from branches where id = (p->>'id')::uuid and bank_id = o.id for update;
    if b.id is null then raise exception 'الفرع لا يتبع جهتك'; end if;
    update branches set name = v_name, governorates = v_govs, complaint_phone = _opt_phone(p->>'phone') where id = b.id returning * into b;
    perform _taudit('تعديل فرع', v_name, jsonb_build_object('governorates', array_to_string(v_govs, '، ')), o.id, b.id);
  else
    if exists (select 1 from branches where bank_id = o.id and name = v_name) then raise exception 'يوجد فرع بهذا الاسم'; end if;
    pre := _staff_prefix(o.id);
    select coalesce(max(nullif(regexp_replace(code, '^.*-', ''), '')::int), 0) + 1 into n from branches where code like pre || '-%' and regexp_replace(code, '^.*-', '') ~ '^[0-9]+$';
    insert into branches(bank_id, code, name, governorates, is_main, complaint_phone)
    values (o.id, pre || '-' || lpad(n::text, 2, '0'), v_name, v_govs, not exists (select 1 from branches where bank_id = o.id), _opt_phone(p->>'phone')) returning * into b;
    perform _taudit('إضافة فرع', v_name, jsonb_build_object('governorates', array_to_string(v_govs, '، ')), o.id, b.id);
  end if;
  return to_jsonb(b);
end $f$;

-- ───────── 4) مشغّل النظام: إضافة جهة بخطوة واحدة ─────────
-- الأنواع: bank | supplier_solar | supplier_vet | eng_audit | insurer
create or replace function public._onboard_kind(k text) returns jsonb language sql immutable as $f$
  select case k
    when 'bank'           then '{"type":"bank","portal":"bank","role":"bank_md","title":"مصرف"}'::jsonb
    when 'supplier_solar' then '{"type":"supplier","portal":"supplier","role":"supplier_admin","kind":"solar","title":"مورد منظومات الطاقة الشمسية"}'::jsonb
    when 'supplier_vet'   then '{"type":"supplier","portal":"supplier","role":"supplier_admin","kind":"vet","title":"مورد الأجهزة والمواد الطبية البيطرية"}'::jsonb
    when 'eng_audit'      then '{"type":"eng_audit","portal":"auditor","role":"auditor_admin","title":"شركة فحص هندسي"}'::jsonb
    when 'insurer'        then '{"type":"insurer","portal":"insurance","role":"ins_md","title":"شركة تأمين"}'::jsonb
  end $f$;

-- حساب الإدارة العليا (مدير الجهة) — يُستخدم عند الإضافة، ولإضافة مدير ثانٍ لاحقاً
create or replace function public._onboard_manager(o orgs, m jsonb) returns profiles
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare v_user text := lower(trim(coalesce(m->>'username', ''))); v_role text; uid uuid; pr profiles;
begin
  v_role := case o.type when 'bank' then 'bank_md' when 'supplier' then 'supplier_admin' when 'eng_audit' then 'auditor_admin' when 'insurer' then 'ins_md' end;
  if v_role is null then raise exception 'هذه الجهة لا تُدار من هنا'; end if;
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم «%» مستخدم مسبقاً', v_user; end if;
  if length(coalesce(m->>'password', '')) < 8 or (m->>'password') !~ '[0-9]' or (m->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if length(trim(coalesce(m->>'full_name', ''))) < 3 then raise exception 'اكتب اسم المسؤول في الإدارة العليا'; end if;
  uid := _mk_user(v_user, m->>'password', trim(m->>'full_name'), v_role, _portal_of_role(v_role), o.code, _opt_phone(m->>'phone'), null);
  update profiles set manage_scope = 'org', must_change_password = true where id = uid returning * into pr;
  if o.type = 'eng_audit' and to_regclass('public.eng_staff') is not null then
    execute 'insert into public.eng_staff(profile_id, specialties) values ($1, ''{}'') on conflict do nothing' using uid;
  end if;
  return pr;
end $f$;

create or replace function public.admin_onboard_org(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare k jsonb := _onboard_kind(p->>'kind'); v_code text := lower(trim(coalesce(p->>'code', ''))); v_name text := trim(coalesce(p->>'name', ''));
  o orgs; b branches; pr profiles; v_govs text[]; v_bgovs text[]; meta jsonb; pre text;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if k is null then raise exception 'اختر نوع الجهة'; end if;
  if length(v_name) < 3 then raise exception 'اكتب اسم الجهة كاملاً'; end if;
  if v_code !~ '^[a-z][a-z0-9]{1,7}$' then raise exception 'الرمز المختصر: 2 إلى 8 حروف إنجليزية أو أرقام، يبدأ بحرف (مثال: rfd)'; end if;
  if exists (select 1 from orgs where code = v_code) then raise exception 'الرمز «%» مستخدم لجهة أخرى — اختر غيره', v_code; end if;
  if exists (select 1 from orgs where type = k->>'type' and name = v_name) then raise exception 'توجد جهة بهذا الاسم'; end if;
  pre := upper(v_code);
  if _has_branches(k->>'type') and exists (select 1 from branches where code like pre || '-%') then raise exception 'رمز الفروع «%» مستخدم — اختر رمزاً آخر', pre; end if;
  select coalesce(array_agg(x), '{}') into v_govs from jsonb_array_elements_text(coalesce(p->'governorates', '[]'::jsonb)) x;
  meta := jsonb_strip_nulls(jsonb_build_object('kind', k->>'kind', 'license', nullif(trim(coalesce(p->>'license', '')), ''), 'phone', nullif(trim(coalesce(p->>'phone', '')), ''),
    'color', nullif(trim(coalesce(p->>'color', '')), ''), 'onboarded_at', now(), 'onboarded_by', (select full_name from profiles where id = auth.uid())));
  if k->>'type' in ('eng_audit', 'insurer') then meta := meta || jsonb_build_object('governorates', to_jsonb(v_govs)); end if;
  if k->>'type' = 'bank' then meta := meta || '{"accepting": false}'::jsonb; end if;
  insert into orgs(code, type, name, is_islamic, meta) values (v_code, k->>'type', v_name, k->>'type' = 'bank' and coalesce((p->>'is_islamic')::boolean, false), meta) returning * into o;

  -- الفرع الرئيسي (المصارف وشركات التأمين)
  if _has_branches(o.type) then
    select coalesce(array_agg(x), '{}') into v_bgovs from jsonb_array_elements_text(coalesce(p->'branch'->'governorates', '[]'::jsonb)) x;
    insert into branches(bank_id, code, name, governorates, is_main, complaint_phone)
    values (o.id, pre || '-01', coalesce(nullif(trim(p->'branch'->>'name'), ''), 'الفرع الرئيسي — بغداد'), coalesce(nullif(v_bgovs, '{}'), v_govs), true, _opt_phone(p->'branch'->>'phone'))
    returning * into b;
  end if;
  -- المصرف: شروط مبدئية (لا يستقبل طلبات حتى يضبط المشغّل عمولته وعوائده)، وحصة ائتمان صفرية يحددها البنك المركزي
  if o.type = 'bank' then
    insert into bank_terms(bank_id, margin, commission_pct) values (o.id, 0, 0) on conflict do nothing;
    if to_regclass('public.bank_allocations') is not null then insert into bank_allocations(bank_id, allocated) values (o.id, 0) on conflict do nothing; end if;
  end if;
  -- شركة التأمين: منتجا التأمين الافتراضيان (تعدّلهما الإدارة العليا)
  if o.type = 'insurer' then perform _ins_default_products(o.id); end if;

  pr := _onboard_manager(o, p->'manager');
  perform _taudit('إضافة جهة: ' || (k->>'title'), v_name, jsonb_build_object('code', v_code, 'manager', pr.username, 'branch', b.name), o.id, null);
  return jsonb_build_object('org', to_jsonb(o), 'branch', to_jsonb(b), 'username', pr.username, 'portal', k->>'portal', 'manager', pr.full_name, 'title', k->>'title');
end $f$;

create or replace function public.admin_add_org_manager(p_org uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare o orgs; pr profiles;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into o from orgs where id = p_org;
  if o.id is null then raise exception 'الجهة غير موجودة'; end if;
  if coalesce((o.meta->>'suspended')::boolean, false) then raise exception 'الجهة موقوفة — أعد تفعيلها أولاً'; end if;
  pr := _onboard_manager(o, p);
  perform _taudit('إضافة حساب إدارة عليا', pr.username, jsonb_build_object('org', o.name), o.id, null);
  return jsonb_build_object('username', pr.username, 'portal', pr.portal, 'manager', pr.full_name);
end $f$;

create or replace function public.admin_org_update(p_org uuid, p jsonb) returns orgs
language plpgsql security definer set search_path to 'public' as $f$
declare o orgs; v_govs text[];
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into o from orgs where id = p_org for update;
  if o.id is null or o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then raise exception 'الجهة غير موجودة'; end if;
  if p ? 'name' and length(trim(p->>'name')) < 3 then raise exception 'اكتب اسم الجهة'; end if;
  if p ? 'governorates' then
    select coalesce(array_agg(x), '{}') into v_govs from jsonb_array_elements_text(coalesce(p->'governorates', '[]'::jsonb)) x;
  end if;
  update orgs set name = coalesce(nullif(trim(p->>'name'), ''), name),
    is_islamic = case when type = 'bank' and p ? 'is_islamic' then (p->>'is_islamic')::boolean else is_islamic end,
    meta = coalesce(meta, '{}') || jsonb_strip_nulls(jsonb_build_object(
      'license', case when p ? 'license' then trim(p->>'license') end, 'phone', case when p ? 'phone' then trim(p->>'phone') end,
      'color', case when p ? 'color' then trim(p->>'color') end,
      'kind', case when type = 'supplier' and p->>'kind' in ('solar', 'vet') then p->>'kind' end,
      'governorates', case when p ? 'governorates' and type in ('eng_audit', 'insurer') then to_jsonb(v_govs) end))
  where id = p_org returning * into o;
  perform _taudit('تعديل بيانات جهة', o.name, p - 'governorates', o.id, null);
  return o;
end $f$;

-- إيقاف الجهة: تُوقف كل حساباتها وتُحفظ قائمتهم، والإعادة تفعّل من أوقفهم الإيقاف فقط
create or replace function public.admin_org_suspend(p_org uuid, p_on boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth' as $f$
declare o orgs; ids uuid[];
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into o from orgs where id = p_org for update;
  if o.id is null or o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then raise exception 'الجهة غير موجودة'; end if;
  if p_on then
    if coalesce((o.meta->>'suspended')::boolean, false) then raise exception 'الجهة موقوفة مسبقاً'; end if;
    if length(trim(coalesce(p_reason, ''))) < 5 then raise exception 'اكتب سبب الإيقاف'; end if;
    select coalesce(array_agg(id), '{}') into ids from profiles where org_id = o.id and not coalesce(disabled, false);
    update profiles set disabled = true, updated_at = now() where id = any(ids);
    update auth.users set banned_until = 'infinity' where id = any(ids);
    begin delete from auth.sessions where user_id = any(ids); exception when others then null; end;
    update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('suspended', true, 'suspended_users', to_jsonb(ids), 'suspend_reason', trim(p_reason), 'suspended_at', now())
      || case when o.type = 'bank' then '{"accepting": false}'::jsonb else '{}'::jsonb end where id = o.id;
    if o.type = 'supplier' then update supplier_offers set status = 'archived' where supplier_id = o.id and status = 'published'; end if;
    perform _taudit('إيقاف جهة', o.name, jsonb_build_object('reason', trim(p_reason), 'accounts', cardinality(ids)), o.id, null);
    return jsonb_build_object('suspended', true, 'accounts', cardinality(ids));
  else
    if not coalesce((o.meta->>'suspended')::boolean, false) then raise exception 'الجهة ليست موقوفة'; end if;
    select coalesce(array_agg(x::uuid), '{}') into ids from jsonb_array_elements_text(coalesce(o.meta->'suspended_users', '[]'::jsonb)) x;
    update profiles set disabled = false, updated_at = now() where id = any(ids);
    update auth.users set banned_until = null where id = any(ids);
    update orgs set meta = (coalesce(meta, '{}') - 'suspended' - 'suspended_users' - 'suspend_reason' - 'suspended_at') where id = o.id;
    perform _taudit('إعادة تفعيل جهة', o.name, jsonb_build_object('accounts', cardinality(ids)), o.id, null);
    return jsonb_build_object('suspended', false, 'accounts', cardinality(ids));
  end if;
end $f$;

-- شعار شاشة الدخول: المصارف وشركات التأمين تُعرض بشعاراتها، وتُتعرّف من بادئة اسم المستخدم
create or replace function public.public_brand(p_portal text) returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object(
    'logo', (select image from brand_logos where key = 'portal:' || p_portal),
    'banks', case when p_portal in ('bank', 'insurance') then (
      select coalesce(jsonb_agg(jsonb_build_object(
        'id', o.id, 'name', o.name, 'islamic', o.is_islamic,
        'logo', (select image from brand_logos where key = 'org:' || o.id),
        'prefix', (select min(split_part(p.username, '.', 1)) from profiles p where p.org_id = o.id and p.username like '%.%')
      ) order by o.code), '[]'::jsonb) from orgs o where o.type = case p_portal when 'bank' then 'bank' else 'insurer' end and not coalesce((o.meta->>'suspended')::boolean, false)) end,
    'stats', jsonb_build_object(
      'banks', (select count(*) from orgs where type = 'bank'),
      'suppliers', (select count(*) from orgs where type = 'supplier'),
      'insurers', (select count(*) from orgs where type = 'insurer'),
      'gov', (select count(*) from orgs where type in ('cbi','registry','integrity','audit','syndicate','vetdept','planning','finance','trade','sharia')))
  ) $f$;

-- ───────── 5) التأمين: الجداول ─────────
create table if not exists public.ins_products (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id),
  line text not null default 'solar',            -- solar | vet
  name text not null,
  coverages jsonb not null default '[]',          -- [{k,label,on}]
  rate_pct numeric not null default 0.75,         -- نسبة القسط السنوي من مبلغ التأمين
  min_premium bigint not null default 50000,
  deductible_pct numeric not null default 5,      -- التحمّل من كل مطالبة
  survey_above bigint not null default 10000000,  -- معاينة إلزامية إذا تجاوز مبلغ التأمين هذا الحد (0 = دائماً)
  branch_limit bigint not null default 25000000,  -- سقف اعتماد مدير الفرع (مبلغ التأمين)، وما فوقه للإدارة العليا
  active boolean not null default true,
  updated_at timestamptz default now(), updated_by text,
  unique (org_id, line)
);
create sequence if not exists public.ins_req_seq;
create sequence if not exists public.ins_pol_seq;
create sequence if not exists public.ins_clm_seq;
create table if not exists public.ins_policies (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                       -- رقم الطلب INR-2026-00001
  policy_no text unique,                           -- رقم الوثيقة بعد الإصدار
  org_id uuid not null references public.orgs(id),
  branch_id uuid references public.branches(id),
  application_id uuid not null references public.applications(id),
  product_id uuid references public.ins_products(id),
  prev_id uuid references public.ins_policies(id), -- الوثيقة السابقة عند التجديد
  origin text not null default 'auto',             -- auto | bank | renewal
  origin_note text, requested_by_title text,
  status text not null default 'new',              -- new | survey | pricing | approval | payment | active | declined | cancelled | expired
  insured_name text, beneficiary text, asset jsonb,
  sum_insured bigint, rate_pct numeric, premium bigint, deductible_pct numeric, coverages jsonb,
  start_date date, end_date date,
  underwriter_id uuid, underwriter_name text,
  surveyor_id uuid, surveyor_name text, survey jsonb,
  approver_level text,                             -- branch | md
  approved_by_name text, approved_by_code text, approved_at timestamptz,
  paid_ref text, paid_at timestamptz, paid_by_name text,
  issued_at timestamptz, seal text,
  decision_note text, close_reason text,
  due_at timestamptz,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create index if not exists ins_policies_app on public.ins_policies(application_id);
create index if not exists ins_policies_org on public.ins_policies(org_id, status);
create table if not exists public.ins_claims (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  policy_id uuid not null references public.ins_policies(id),
  org_id uuid not null references public.orgs(id),
  branch_id uuid references public.branches(id),
  application_id uuid not null references public.applications(id),
  status text not null default 'reported',         -- reported | survey | assessment | approval | payment | paid | rejected
  cause text not null, incident_date date not null, description text, claimed bigint,
  reported_by_name text, reported_by_side text,
  surveyor_id uuid, surveyor_name text, survey jsonb,
  assessed bigint, deductible bigint, payable bigint, assess_note text, assessed_by_name text,
  approver_level text, approved_by_name text, approved_at timestamptz,
  paid_ref text, paid_at timestamptz, paid_to text, paid_by_name text, seal text,
  decision_note text,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create index if not exists ins_claims_policy on public.ins_claims(policy_id);
create table if not exists public.ins_log (
  id bigserial primary key,
  policy_id uuid references public.ins_policies(id),
  claim_id uuid references public.ins_claims(id),
  at timestamptz default now(), actor_name text, actor_code text, action text not null, note text
);
create index if not exists ins_log_policy on public.ins_log(policy_id);

alter table public.ins_products enable row level security;
alter table public.ins_policies enable row level security;
alter table public.ins_claims enable row level security;
alter table public.ins_log enable row level security;
-- القراءة المباشرة لموظفي الشركة نفسها فقط (للتحديث اللحظي)؛ الكتابة عبر الدوال فقط، والجهات الأخرى تقرأ عبر ins_app_report
drop policy if exists ins_products_read on public.ins_products;
create policy ins_products_read on public.ins_products for select using (org_id = (select org_id from profiles where id = auth.uid()));
drop policy if exists ins_policies_read on public.ins_policies;
create policy ins_policies_read on public.ins_policies for select using (org_id = (select org_id from profiles where id = auth.uid() and portal = 'insurance'));
drop policy if exists ins_claims_read on public.ins_claims;
create policy ins_claims_read on public.ins_claims for select using (org_id = (select org_id from profiles where id = auth.uid() and portal = 'insurance'));
grant select on public.ins_products, public.ins_policies, public.ins_claims to authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'ins_policies') then
      alter publication supabase_realtime add table public.ins_policies; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'ins_claims') then
      alter publication supabase_realtime add table public.ins_claims; end if;
  end if;
end $$;

-- ───────── 6) التأمين: أدوات ─────────
create or replace function public._ins_status_label(s text) returns text language sql immutable as $f$
  select case s when 'new' then 'طلب وارد — بانتظار الاكتتاب' when 'survey' then 'قيد المعاينة' when 'pricing' then 'قيد التسعير'
    when 'approval' then 'بانتظار الاعتماد' when 'payment' then 'بانتظار تسديد القسط' when 'active' then 'وثيقة سارية'
    when 'declined' then 'اعتذرت الشركة عن التأمين' when 'cancelled' then 'ملغاة' when 'expired' then 'منتهية' else s end $f$;
create or replace function public._ins_claim_label(s text) returns text language sql immutable as $f$
  select case s when 'reported' then 'إبلاغ جديد' when 'survey' then 'معاينة الضرر' when 'assessment' then 'قيد التقدير'
    when 'approval' then 'بانتظار الاعتماد' when 'payment' then 'بانتظار الصرف' when 'paid' then 'صُرف التعويض' when 'rejected' then 'مرفوضة' else s end $f$;
create or replace function public._ins_cause_label(s text) returns text language sql immutable as $f$
  select case s when 'fire' then 'حريق أو صاعقة' when 'electrical' then 'عطل كهربائي أو تماس' when 'nature' then 'عاصفة أو أمطار أو بَرَد'
    when 'theft' then 'سرقة أو سطو' when 'accident' then 'كسر أو ضرر عرضي' when 'liability' then 'ضرر للغير' else 'أخرى' end $f$;

create or replace function public._ins_coverages(p_line text) returns jsonb language sql immutable as $f$
  select case when p_line = 'vet' then '[{"k":"fire","label":"الحريق والصواعق","on":true},{"k":"electrical","label":"الأعطال الكهربائية وتلف الأجهزة","on":true},{"k":"theft","label":"السرقة والسطو","on":true},{"k":"nature","label":"العواصف والفيضانات","on":true},{"k":"accident","label":"الكسر والضرر العرضي","on":true},{"k":"liability","label":"المسؤولية تجاه الغير","on":false}]'::jsonb
    else '[{"k":"fire","label":"الحريق والصواعق","on":true},{"k":"electrical","label":"الأعطال الكهربائية والتماس","on":true},{"k":"nature","label":"العواصف والأمطار والبَرَد","on":true},{"k":"theft","label":"سرقة الألواح والبطاريات","on":true},{"k":"accident","label":"الكسر والضرر العرضي","on":true},{"k":"liability","label":"المسؤولية تجاه الغير","on":false}]'::jsonb end $f$;

create or replace function public._ins_default_products(p_org uuid) returns void language sql security definer set search_path to 'public' as $f$
  insert into ins_products(org_id, line, name, coverages, rate_pct, min_premium, deductible_pct, survey_above, branch_limit) values
    (p_org, 'solar', 'تأمين المنظومة الشمسية الممولة — جميع الأخطار', _ins_coverages('solar'), 0.75, 50000, 5, 10000000, 25000000),
    (p_org, 'vet', 'تأمين أجهزة ومعدات المشروع البيطري', _ins_coverages('vet'), 1.0, 100000, 10, 0, 40000000)
  on conflict (org_id, line) do nothing $f$;

-- الموظف الحالي في شركة التأمين
create or replace function public._ins_me() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'insurance' or coalesce(me.disabled, false) then raise exception 'هذه الشاشة لموظفي شركات التأمين'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  return me;
end $f$;
-- يرى الموظف معاملات فرعه، والإدارة العامة (بلا فرع) ترى كل الشركة
create or replace function public._ins_in_scope(me profiles, p_org uuid, p_branch uuid) returns boolean language sql stable as $f$
  select me.org_id = p_org and (me.branch_id is null or me.branch_id is not distinct from p_branch) $f$;

create or replace function public._ins_log(p_pol uuid, p_clm uuid, p_action text, p_note text) returns void language sql security definer set search_path to 'public' as $f$
  insert into ins_log(policy_id, claim_id, actor_name, actor_code, action, note)
  select p_pol, p_clm, coalesce((select full_name from profiles where id = auth.uid()), 'النظام'), (select staff_code from profiles where id = auth.uid()), p_action, nullif(trim(coalesce(p_note, '')), '') $f$;

-- إشعار أدوار في الشركة: موظفو الفرع نفسه ومن في الإدارة العامة (وإن لم يوجد أحد: إشعار عام للشركة)
create or replace function public._ins_notify(p_org uuid, p_branch uuid, p_roles text[], p_kind text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  if p_org is null then return; end if;
  insert into notifications(user_id, kind, title, body, ref_id)
  select id, p_kind, p_title, p_body, p_ref from profiles
  where org_id = p_org and role = any(p_roles) and not coalesce(disabled, false) and (branch_id is null or p_branch is null or branch_id = p_branch);
  if not found then perform _notify(p_org, 'insurance', p_kind, p_title, p_body, p_ref); end if;
end $f$;

-- الشركة: المعتمدة غير الموقوفة التي تغطي المحافظة (governorates فارغة = كل المحافظات)، والأقل انشغالاً
create or replace function public._ins_pick_org(p_gov text) returns uuid language sql stable security definer set search_path to 'public' as $f$
  select o.id from orgs o where o.type = 'insurer' and not coalesce((o.meta->>'suspended')::boolean, false)
    and (jsonb_array_length(coalesce(o.meta->'governorates', '[]')) = 0 or o.meta->'governorates' ? p_gov)
  order by (select count(*) from ins_policies x where x.org_id = o.id and x.status in ('new', 'survey', 'pricing', 'approval')), o.created_at limit 1 $f$;
-- الفرع: الذي يغطي المحافظة، وإلا الرئيسي
create or replace function public._ins_pick_branch(p_org uuid, p_gov text) returns uuid language sql stable security definer set search_path to 'public' as $f$
  select id from branches where bank_id = p_org order by (p_gov = any(coalesce(governorates, '{}'))) desc, is_main desc, code limit 1 $f$;

-- إنشاء طلب تأمين على مشروع ممول
create or replace function public._ins_create(p_app uuid, p_org uuid, p_origin text, p_note text, p_by text) returns ins_policies
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; o orgs; pr ins_products; pol ins_policies; v_br uuid; v_asset jsonb; v_sum bigint; vp record;
begin
  select * into a from applications where id = p_app;
  select * into o from orgs where id = p_org and type = 'insurer';
  if a.id is null then raise exception 'الطلب غير موجود'; end if;
  if o.id is null then raise exception 'لا توجد شركة تأمين معتمدة تغطي محافظة %', coalesce(a.governorate, ''); end if;
  if coalesce((o.meta->>'suspended')::boolean, false) then raise exception 'شركة التأمين موقوفة'; end if;
  if exists (select 1 from ins_policies where application_id = a.id and status in ('new', 'survey', 'pricing', 'approval', 'payment', 'active')) then
    raise exception 'للمشروع طلب تأمين أو وثيقة قائمة'; end if;
  perform _ins_default_products(o.id);
  select * into pr from ins_products where org_id = o.id and line = case when a.program = 'vet' then 'vet' else 'solar' end and active;
  if pr.id is null then raise exception 'لا يوجد لدى الشركة منتج تأمين فعّال لهذا النوع من المشاريع'; end if;
  v_br := _ins_pick_branch(o.id, a.governorate);
  if a.program = 'vet' and to_regclass('public.vet_projects') is not null then
    select project_type, title, total_cost, items into vp from vet_projects where application_id = a.id;
    v_asset := jsonb_strip_nulls(jsonb_build_object('program', 'vet', 'vet_type', vp.project_type, 'title', vp.title, 'items', jsonb_array_length(coalesce(vp.items, '[]')), 'cost', vp.total_cost));
    v_sum := coalesce(vp.total_cost, a.price, a.amount);
  else
    v_asset := jsonb_strip_nulls(jsonb_build_object('program', 'solar', 'kw', a.kw, 'supplier', (select name from orgs where id = a.supplier_id),
      'offer', (select title from supplier_offers where id = a.offer_id), 'site', a.site_type));
    v_sum := coalesce(a.price, a.amount);
  end if;
  insert into ins_policies(code, org_id, branch_id, application_id, product_id, origin, origin_note, requested_by_title, status, insured_name, beneficiary, asset,
    sum_insured, rate_pct, deductible_pct, coverages, due_at)
  values ('INR-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_req_seq')::text, 5, '0'), o.id, v_br, a.id, pr.id, p_origin, nullif(trim(coalesce(p_note, '')), ''), p_by, 'new',
    a.citizen_name, (select name from orgs where id = a.bank_id), v_asset, v_sum, pr.rate_pct, pr.deductible_pct, pr.coverages,
    now() + make_interval(days => coalesce(_setting('ins_sla_days'), 5)::int))
  returning * into pol;
  update applications set insurance_status = 'requested', insurance = jsonb_build_object('org', o.name, 'code', pol.code) where id = a.id;
  perform _ins_log(pol.id, null, case p_origin when 'auto' then 'طلب تأمين آلي عند المرحلة 30' when 'renewal' then 'تجديد' else 'طلب تأمين من المصرف' end, p_note);
  perform _ins_notify(o.id, v_br, array['ins_underwriter', 'ins_branch_mgr'], 'ins_new', 'طلب تأمين جديد ' || pol.code,
    coalesce(a.citizen_name, '') || ' · ' || coalesce(a.governorate, '') || ' · ' || case when a.program = 'vet' then 'مشروع بيطري' else 'منظومة شمسية ' || coalesce(a.kw::text, '') || ' kW' end
    || ' · مبلغ التأمين ' || to_char(v_sum, 'FM999,999,999,999') || ' د.ع', pol.id);
  return pol;
end $f$;

-- وصول الطلب إلى المرحلة 30 (أمر الشراء من المورد) ← طلب تأمين آلي
create or replace function public._ins_on_stage() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare v_org uuid;
begin
  if new.stage = 30 and coalesce(old.stage, 0) < 30 and new.status in ('active', 'returned') and coalesce(_setting('ins_auto'), 1) = 1
     and not exists (select 1 from ins_policies where application_id = new.id and status not in ('declined', 'cancelled', 'expired')) then
    v_org := _ins_pick_org(new.governorate);
    if v_org is not null then
      begin perform _ins_create(new.id, v_org, 'auto', null, 'آلي — المرحلة 30'); exception when others then raise warning 'ins auto: %', sqlerrm; end;
    end if;
  end if;
  return null;
end $f$;
drop trigger if exists trg_ins_on_stage on public.applications;
create trigger trg_ins_on_stage after update of stage on public.applications for each row execute function public._ins_on_stage();

-- لا يُصرف للمورد قبل وثيقة سارية (إن فُعّل الإعداد ins_required)
create or replace function public._guard_ins() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  if old.stage = 35 and new.stage > 35 and coalesce(_setting('ins_required'), 0) = 1
     and not exists (select 1 from ins_policies where application_id = new.id and status = 'active') then
    raise exception 'لا يُصرف المبلغ للمورد قبل إصدار وثيقة تأمين سارية على المشروع';
  end if;
  return new;
end $f$;
drop trigger if exists trg_guard_ins on public.applications;
create trigger trg_guard_ins before update of stage on public.applications for each row execute function public._guard_ins();

-- تنتهي الوثائق بانقضاء مدتها
create or replace function public._ins_expire() returns void language sql security definer set search_path to 'public' as $f$
  with x as (update ins_policies set status = 'expired', updated_at = now() where status = 'active' and end_date < current_date returning id, application_id)
  update applications a set insurance_status = 'expired' from x where a.id = x.application_id
    and not exists (select 1 from ins_policies p where p.application_id = a.id and p.status = 'active') $f$;

-- ───────── 7) التأمين: بوابة الشركة ─────────
create or replace function public._ins_row(p ins_policies) returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', p.id, 'code', p.code, 'policy_no', p.policy_no, 'status', p.status, 'status_label', _ins_status_label(p.status),
    'branch', (select name from branches where id = p.branch_id), 'branch_id', p.branch_id, 'origin', p.origin,
    'insured', p.insured_name, 'beneficiary', p.beneficiary, 'asset', p.asset, 'sum_insured', p.sum_insured, 'premium', p.premium,
    'start', p.start_date, 'end', p.end_date, 'surveyor_id', p.surveyor_id, 'surveyor', p.surveyor_name, 'underwriter', p.underwriter_name,
    'approver_level', p.approver_level, 'due_at', p.due_at, 'late', p.status in ('new', 'survey', 'pricing', 'approval') and p.due_at < now(),
    'created_at', p.created_at, 'updated_at', p.updated_at,
    'app', (select jsonb_build_object('id', a.id, 'code', a.code, 'governorate', a.governorate, 'city', a.city, 'kw', a.kw, 'program', a.program, 'stage', a.stage) from applications a where a.id = p.application_id),
    'claims_open', (select count(*) from ins_claims c where c.policy_id = p.id and c.status not in ('paid', 'rejected'))) $f$;

create or replace function public._ins_claim_row(c ins_claims) returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', c.id, 'code', c.code, 'status', c.status, 'status_label', _ins_claim_label(c.status), 'policy_id', c.policy_id,
    'policy_no', (select policy_no from ins_policies where id = c.policy_id), 'branch', (select name from branches where id = c.branch_id), 'branch_id', c.branch_id,
    'cause', c.cause, 'cause_label', _ins_cause_label(c.cause), 'incident_date', c.incident_date, 'description', c.description, 'claimed', c.claimed,
    'assessed', c.assessed, 'deductible', c.deductible, 'payable', c.payable, 'surveyor_id', c.surveyor_id, 'surveyor', c.surveyor_name,
    'reported_by', c.reported_by_name, 'reported_side', c.reported_by_side, 'created_at', c.created_at, 'updated_at', c.updated_at,
    'insured', (select insured_name from ins_policies where id = c.policy_id),
    'app', (select jsonb_build_object('id', a.id, 'code', a.code, 'governorate', a.governorate, 'program', a.program, 'kw', a.kw) from applications a where a.id = c.application_id)) $f$;

create or replace function public.ins_inbox() returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _ins_me(); o orgs;
begin
  perform _ins_expire();
  select * into o from orgs where id = me.org_id;
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'name', me.full_name, 'role', me.role, 'role_title', _role_title(me.role), 'code', me.staff_code,
      'branch_id', me.branch_id, 'branch', (select name from branches where id = me.branch_id), 'md', me.role = 'ins_md'),
    'org', jsonb_build_object('id', o.id, 'name', o.name, 'governorates', coalesce(o.meta->'governorates', '[]')),
    'branches', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name) order by is_main desc, code), '[]') from branches where bank_id = o.id),
    'products', (select coalesce(jsonb_agg(to_jsonb(x) order by x.line), '[]') from ins_products x where x.org_id = o.id),
    'surveyors', (select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'branch_id', p.branch_id,
        'open', (select count(*) from ins_policies x where x.surveyor_id = p.id and x.status = 'survey') + (select count(*) from ins_claims c where c.surveyor_id = p.id and c.status = 'survey')) order by p.full_name), '[]')
      from profiles p where p.org_id = o.id and p.role in ('ins_surveyor', 'ins_branch_mgr') and not coalesce(p.disabled, false)
        and (me.branch_id is null or p.branch_id is not distinct from me.branch_id or p.branch_id is null)),
    'policies', (select coalesce(jsonb_agg(_ins_row(p) order by p.updated_at desc), '[]') from ins_policies p
      where _ins_in_scope(me, p.org_id, p.branch_id) and (me.role <> 'ins_surveyor' or p.surveyor_id = me.id)
        and (p.status not in ('declined', 'cancelled', 'expired') or p.updated_at > now() - interval '120 days')),
    'claims', (select coalesce(jsonb_agg(_ins_claim_row(c) order by c.updated_at desc), '[]') from ins_claims c
      where _ins_in_scope(me, c.org_id, c.branch_id) and (me.role <> 'ins_surveyor' or c.surveyor_id = me.id)
        and (c.status not in ('paid', 'rejected') or c.updated_at > now() - interval '180 days')));
end $f$;

create or replace function public.ins_policy(p_id uuid) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles := _ins_me(); p ins_policies; a applications; pr ins_products; r text := me.role; v_lim bigint; can jsonb;
begin
  select * into p from ins_policies where id = p_id;
  if p.id is null or not _ins_in_scope(me, p.org_id, p.branch_id) or (r = 'ins_surveyor' and p.surveyor_id is distinct from me.id) then raise exception 'الوثيقة خارج نطاقك'; end if;
  select * into a from applications where id = p.application_id;
  select * into pr from ins_products where id = p.product_id;
  v_lim := coalesce(pr.branch_limit, 0);
  can := jsonb_build_object(
    'accept', p.status = 'new' and r in ('ins_underwriter', 'ins_branch_mgr', 'ins_md'),
    'survey', p.status = 'survey' and (p.surveyor_id = me.id),
    'reassign', p.status = 'survey' and r in ('ins_branch_mgr', 'ins_md', 'ins_underwriter'),
    'price', p.status = 'pricing' and r in ('ins_underwriter', 'ins_branch_mgr', 'ins_md'),
    'approve', p.status = 'approval' and (r = 'ins_md' or (r = 'ins_branch_mgr' and p.approver_level = 'branch')),
    'decline', p.status in ('new', 'survey', 'pricing', 'approval') and r in ('ins_underwriter', 'ins_branch_mgr', 'ins_md'),
    'pay', p.status = 'payment' and r in ('ins_finance', 'ins_md'),
    'cancel', p.status in ('payment', 'active') and r = 'ins_md',
    'renew', p.status in ('active', 'expired') and r in ('ins_finance', 'ins_md') and p.end_date <= current_date + 30
             and not exists (select 1 from ins_policies n where n.prev_id = p.id and n.status not in ('declined', 'cancelled')),
    'claim', p.status = 'active' and r in ('ins_claims', 'ins_branch_mgr', 'ins_md'));
  return _ins_row(p) || jsonb_build_object(
    'rate_pct', p.rate_pct, 'deductible_pct', p.deductible_pct, 'coverages', p.coverages, 'survey', p.survey, 'seal', p.seal, 'issued_at', p.issued_at,
    'approved_by', p.approved_by_name, 'approved_code', p.approved_by_code, 'approved_at', p.approved_at, 'paid_ref', p.paid_ref, 'paid_at', p.paid_at, 'paid_by', p.paid_by_name,
    'decision_note', p.decision_note, 'close_reason', p.close_reason, 'origin_note', p.origin_note, 'requested_by', p.requested_by_title,
    'product', jsonb_build_object('name', pr.name, 'rate_pct', pr.rate_pct, 'min_premium', pr.min_premium, 'deductible_pct', pr.deductible_pct,
      'survey_above', pr.survey_above, 'branch_limit', pr.branch_limit, 'coverages', pr.coverages),
    'needs_survey', pr.survey_above = 0 or coalesce(p.sum_insured, 0) > pr.survey_above,
    'over_branch_limit', coalesce(p.sum_insured, 0) > v_lim,
    'site', jsonb_build_object('borrower', a.citizen_name, 'phone', (select phone from profiles where id = a.citizen_id), 'governorate', a.governorate, 'city', a.city,
      'bank', (select name from orgs where id = a.bank_id), 'bank_branch', (select name from branches where id = a.branch_id), 'supplier', (select name from orgs where id = a.supplier_id),
      'amount', a.amount, 'price', a.price, 'term_months', a.term_months, 'site_geo', a.site_geo, 'install_geo', a.install_geo, 'audit_status', a.audit_status, 'stage', a.stage,
      'stage_name', (select name from stages where n = a.stage)),
    'claims', (select coalesce(jsonb_agg(_ins_claim_row(c) order by c.created_at desc), '[]') from ins_claims c where c.policy_id = p.id),
    'history', (select coalesce(jsonb_agg(jsonb_build_object('code', x.code, 'policy_no', x.policy_no, 'status', x.status, 'status_label', _ins_status_label(x.status), 'start', x.start_date, 'end', x.end_date, 'id', x.id) order by x.created_at desc), '[]')
      from ins_policies x where x.application_id = p.application_id and x.id <> p.id),
    'log', (select coalesce(jsonb_agg(jsonb_build_object('at', l.at, 'by', l.actor_name, 'code', l.actor_code, 'action', l.action, 'note', l.note) order by l.id), '[]') from ins_log l where l.policy_id = p.id and l.claim_id is null),
    'can', can);
end $f$;

-- اختيار المعاين: المحدد، أو معاين الفرع الأقل انشغالاً
create or replace function public._ins_pick_surveyor(p_org uuid, p_branch uuid, p_want uuid) returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare s profiles;
begin
  if p_want is not null then
    select * into s from profiles where id = p_want and org_id = p_org and role in ('ins_surveyor', 'ins_branch_mgr') and not coalesce(disabled, false)
      and (branch_id is null or branch_id is not distinct from p_branch);
    if s.id is null then raise exception 'المعاين المختار ليس من فريق هذا الفرع'; end if;
    return s;
  end if;
  select * into s from profiles p where p.org_id = p_org and p.role = 'ins_surveyor' and not coalesce(p.disabled, false) and not coalesce(p.away_until > now(), false)
    and (p.branch_id is null or p.branch_id is not distinct from p_branch)
  order by (p.branch_id is not distinct from p_branch) desc,
    (select count(*) from ins_policies x where x.surveyor_id = p.id and x.status = 'survey') + (select count(*) from ins_claims c where c.surveyor_id = p.id and c.status = 'survey'), p.full_name limit 1;
  if s.id is null then raise exception 'لا يوجد معاين فعّال في هذا الفرع — أضفه من «فريقي»'; end if;
  return s;
end $f$;

-- قراءة الموقع والصورة من إجراء المعاينة
create or replace function public._ins_gps(g jsonb) returns jsonb language plpgsql immutable as $f$
begin
  if g is null or (g->>'lat') is null or (g->>'lng') is null then raise exception 'ثبّت موقعك في مكان المشروع (GPS) قبل حفظ المعاينة'; end if;
  if coalesce((g->>'acc')::numeric, 9999) > 150 then raise exception 'دقة الموقع ضعيفة (±% م) — اقترب من مكان مفتوح وأعد المحاولة', round((g->>'acc')::numeric); end if;
  return jsonb_build_object('lat', (g->>'lat')::numeric, 'lng', (g->>'lng')::numeric, 'acc', round((g->>'acc')::numeric), 'at', now());
end $f$;
create or replace function public._ins_photo_save(p_app uuid, p_data text, p_label text) returns uuid language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare d uuid;
begin
  if p_data is null or p_data = '' then return null; end if;
  if p_data !~ '^data:image/(jpeg|png|webp);base64,' then raise exception 'صيغة الصورة غير مقبولة'; end if;
  if length(p_data) > 2800000 then raise exception 'الصورة كبيرة — أعد التصوير'; end if;
  insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (p_app, 'ins_photo', 'camera', substring(p_data from '^data:([^;]+);'), p_data, length(p_data) * 3 / 4,
    encode(extensions.digest(convert_to(p_data, 'UTF8'), 'sha256'), 'hex'), jsonb_build_object('label', p_label),
    auth.uid(), (select position_title from profiles where id = auth.uid()))
  returning id into d;
  return d;
end $f$;

-- إجراءات دورة الوثيقة داخل الشركة
create or replace function public.ins_policy_act(p_id uuid, p jsonb) returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles := _ins_me(); pol ins_policies; a applications; pr ins_products; act text := p->>'action'; r text := me.role; s profiles;
  v_sum bigint; v_rate numeric; v_ded numeric; v_prem bigint; v_cov jsonb; v_lvl text; v_photo uuid; v_gps jsonb; v_seal text; v_no text; n ins_policies; ttl text; body text; sent text[] := '{}';
  v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  select * into pol from ins_policies where id = p_id for update;
  if pol.id is null or not _ins_in_scope(me, pol.org_id, pol.branch_id) then raise exception 'الوثيقة خارج نطاقك'; end if;
  select * into a from applications where id = pol.application_id;
  select * into pr from ins_products where id = pol.product_id;

  -- 1) الاكتتاب: استلام الطلب ← معاينة أو تسعير مباشرة
  if act = 'accept' then
    if pol.status <> 'new' or r not in ('ins_underwriter', 'ins_branch_mgr', 'ins_md') then raise exception 'استلام الطلب لموظف الاكتتاب أو مدير الفرع'; end if;
    if (pr.survey_above = 0 or coalesce(pol.sum_insured, 0) > pr.survey_above) or coalesce((p->>'survey')::boolean, false) then
      s := _ins_pick_surveyor(pol.org_id, pol.branch_id, nullif(p->>'surveyor', '')::uuid);
      update ins_policies set status = 'survey', underwriter_id = me.id, underwriter_name = me.full_name, surveyor_id = s.id, surveyor_name = s.full_name, updated_at = now() where id = pol.id;
      update applications set insurance_status = 'underwriting' where id = a.id;
      perform _ins_log(pol.id, null, 'استلام الطلب وإحالته للمعاينة — ' || s.full_name, v_note);
      insert into notifications(user_id, kind, title, body, ref_id) values (s.id, 'ins_task', 'معاينة جديدة: ' || pol.code,
        coalesce(a.citizen_name, '') || ' · ' || coalesce(a.governorate, '') || coalesce(' — ' || a.city, '') || ' · ثبّت زيارتك في الموقع ثم سجّل المعاينة', pol.id);
      return jsonb_build_object('ok', true, 'status', 'survey', 'surveyor', s.full_name, 'code', pol.code);
    end if;
    update ins_policies set status = 'pricing', underwriter_id = me.id, underwriter_name = me.full_name, updated_at = now() where id = pol.id;
    update applications set insurance_status = 'underwriting' where id = a.id;
    perform _ins_log(pol.id, null, 'استلام الطلب — التسعير مباشرة (دون حد المعاينة)', v_note);
    return jsonb_build_object('ok', true, 'status', 'pricing', 'code', pol.code);
  end if;

  if act = 'reassign' then
    if pol.status <> 'survey' or r not in ('ins_underwriter', 'ins_branch_mgr', 'ins_md') then raise exception 'تغيير المعاين لموظف الاكتتاب أو مدير الفرع'; end if;
    s := _ins_pick_surveyor(pol.org_id, pol.branch_id, nullif(p->>'surveyor', '')::uuid);
    update ins_policies set surveyor_id = s.id, surveyor_name = s.full_name, updated_at = now() where id = pol.id;
    perform _ins_log(pol.id, null, 'إسناد المعاينة إلى ' || s.full_name, v_note);
    insert into notifications(user_id, kind, title, body, ref_id) values (s.id, 'ins_task', 'معاينة مسندة إليك: ' || pol.code, coalesce(a.citizen_name, '') || ' · ' || coalesce(a.governorate, ''), pol.id);
    return jsonb_build_object('ok', true, 'surveyor', s.full_name);
  end if;

  -- 2) المعاينة في الموقع
  if act = 'survey' then
    if pol.status <> 'survey' or pol.surveyor_id is distinct from me.id then raise exception 'المعاينة للمعاين المسند إليه الطلب'; end if;
    if coalesce(p->>'risk', '') not in ('low', 'medium', 'high') then raise exception 'اختر درجة الخطر'; end if;
    if p->>'risk' <> 'low' and v_note is null then raise exception 'اكتب ملاحظات المعاينة'; end if;
    v_gps := _ins_gps(p->'gps');
    v_photo := _ins_photo_save(a.id, p->>'photo', 'معاينة ' || pol.code);
    if v_photo is null and p->>'risk' = 'high' then raise exception 'صوّر سبب الخطر العالي'; end if;
    update ins_policies set status = 'pricing', survey = jsonb_build_object('risk', p->>'risk', 'note', v_note, 'gps', v_gps, 'photo', v_photo, 'by', me.full_name, 'code', me.staff_code, 'at', now(),
      'checks', coalesce(p->'checks', '[]')), updated_at = now() where id = pol.id;
    perform _ins_log(pol.id, null, 'معاينة الموقع — الخطر ' || case p->>'risk' when 'low' then 'منخفض' when 'medium' then 'متوسط' else 'عالٍ' end, v_note);
    perform _ins_notify(pol.org_id, pol.branch_id, array['ins_underwriter', 'ins_branch_mgr'], 'ins_task', 'اكتملت معاينة ' || pol.code || ' — جاهزة للتسعير', coalesce(a.citizen_name, ''), pol.id);
    return jsonb_build_object('ok', true, 'status', 'pricing', 'code', pol.code);
  end if;

  -- 3) التسعير ← الاعتماد
  if act = 'price' then
    if pol.status <> 'pricing' or r not in ('ins_underwriter', 'ins_branch_mgr', 'ins_md') then raise exception 'التسعير لموظف الاكتتاب أو مدير الفرع'; end if;
    v_sum := coalesce(nullif(p->>'sum_insured', '')::bigint, pol.sum_insured);
    v_rate := coalesce(nullif(p->>'rate_pct', '')::numeric, pr.rate_pct);
    v_ded := coalesce(nullif(p->>'deductible_pct', '')::numeric, pr.deductible_pct);
    v_cov := coalesce(p->'coverages', pol.coverages);
    if v_sum is null or v_sum < 100000 then raise exception 'مبلغ التأمين غير صحيح'; end if;
    if v_sum > coalesce(a.price, a.amount, v_sum) * 1.2 then raise exception 'مبلغ التأمين يتجاوز قيمة المشروع بأكثر من 20%%'; end if;
    if v_rate <= 0 or v_rate > 10 then raise exception 'نسبة القسط بين 0 و10%%'; end if;
    if v_ded < 0 or v_ded > 50 then raise exception 'نسبة التحمّل بين 0 و50%%'; end if;
    if not exists (select 1 from jsonb_array_elements(v_cov) c where (c->>'on')::boolean) then raise exception 'اختر خطراً واحداً مغطى على الأقل'; end if;
    v_prem := greatest(pr.min_premium, round(v_sum * v_rate / 100));
    v_lvl := case when v_sum > pr.branch_limit then 'md' else 'branch' end;
    update ins_policies set status = 'approval', sum_insured = v_sum, rate_pct = v_rate, deductible_pct = v_ded, premium = v_prem, coverages = v_cov,
      approver_level = v_lvl, underwriter_id = coalesce(underwriter_id, me.id), underwriter_name = coalesce(underwriter_name, me.full_name), updated_at = now() where id = pol.id;
    perform _ins_log(pol.id, null, 'التسعير: القسط السنوي ' || to_char(v_prem, 'FM999,999,999') || ' د.ع', 'مبلغ التأمين ' || to_char(v_sum, 'FM999,999,999,999') || ' · النسبة ' || v_rate || '% · التحمّل ' || v_ded || '%' || coalesce(' · ' || v_note, ''));
    if v_lvl = 'md' then
      perform _ins_notify(pol.org_id, null, array['ins_md'], 'ins_task', 'وثيقة فوق سقف الفرع بانتظار اعتمادك: ' || pol.code, coalesce(a.citizen_name, '') || ' · مبلغ التأمين ' || to_char(v_sum, 'FM999,999,999,999'), pol.id);
    else
      perform _ins_notify(pol.org_id, pol.branch_id, array['ins_branch_mgr'], 'ins_task', 'وثيقة بانتظار اعتمادك: ' || pol.code, coalesce(a.citizen_name, '') || ' · القسط ' || to_char(v_prem, 'FM999,999,999'), pol.id);
    end if;
    return jsonb_build_object('ok', true, 'status', 'approval', 'premium', v_prem, 'level', v_lvl, 'code', pol.code);
  end if;

  -- 4) الاعتماد أو الإعادة للتسعير
  if act in ('approve', 'return') then
    if pol.status <> 'approval' or not (r = 'ins_md' or (r = 'ins_branch_mgr' and pol.approver_level = 'branch')) then
      raise exception '%', case when pol.approver_level = 'md' then 'مبلغ التأمين فوق سقف الفرع — الاعتماد للإدارة العليا' else 'الاعتماد لمدير الفرع أو الإدارة العليا' end; end if;
    if act = 'return' then
      if v_note is null then raise exception 'اكتب سبب الإعادة'; end if;
      update ins_policies set status = 'pricing', updated_at = now() where id = pol.id;
      perform _ins_log(pol.id, null, 'إعادة للتسعير', v_note);
      if pol.underwriter_id is not null then insert into notifications(user_id, kind, title, body, ref_id) values (pol.underwriter_id, 'ins_task', 'أُعيدت للتسعير: ' || pol.code, v_note, pol.id); end if;
      return jsonb_build_object('ok', true, 'status', 'pricing');
    end if;
    if trim(coalesce(p->>'confirm', '')) <> 'أعتمد الوثيقة' then raise exception 'اكتب «أعتمد الوثيقة» للتأكيد'; end if;
    update ins_policies set status = 'payment', approved_by_name = me.full_name, approved_by_code = me.staff_code, approved_at = now(), decision_note = v_note, updated_at = now() where id = pol.id;
    update applications set insurance_status = 'payment', insurance = coalesce(insurance, '{}') || jsonb_build_object('premium', pol.premium) where id = a.id;
    perform _ins_log(pol.id, null, 'اعتماد الوثيقة — بانتظار تسديد القسط', v_note);
    ttl := 'قسط التأمين مستحق: ' || a.code;
    body := (select name from orgs where id = pol.org_id) || ' · القسط السنوي ' || to_char(pol.premium, 'FM999,999,999') || ' د.ع · مبلغ التأمين ' || to_char(pol.sum_insured, 'FM999,999,999,999') || ' · المستفيد الأول ' || coalesce(pol.beneficiary, 'المصرف');
    perform _ins_notify(pol.org_id, pol.branch_id, array['ins_finance'], 'ins_task', 'قسط بانتظار التسديد: ' || pol.code, body, pol.id); sent := array_append(sent, 'حسابات الشركة');
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', ttl, body, a.id); sent := array_append(sent, 'المصرف');
    if a.citizen_id is not null then
      insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, 'ins_result', 'وافقت شركة التأمين على تأمين مشروعك', body, a.id); sent := array_append(sent, 'المقترض');
    end if;
    return jsonb_build_object('ok', true, 'status', 'payment', 'sent', to_jsonb(sent), 'code', pol.code, 'premium', pol.premium);
  end if;

  -- اعتذار عن التأمين
  if act = 'decline' then
    if pol.status not in ('new', 'survey', 'pricing', 'approval') or r not in ('ins_underwriter', 'ins_branch_mgr', 'ins_md') then raise exception 'الاعتذار لموظف الاكتتاب أو المدير'; end if;
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الاعتذار — يصل للمصرف'; end if;
    update ins_policies set status = 'declined', close_reason = v_note, updated_at = now() where id = pol.id;
    update applications set insurance_status = 'declined' where id = a.id;
    perform _ins_log(pol.id, null, 'اعتذار الشركة عن التأمين', v_note);
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', 'اعتذرت شركة التأمين عن تأمين ' || a.code,
      (select name from orgs where id = pol.org_id) || ' · السبب: ' || v_note || ' — يمكن طلب التأمين من شركة أخرى من ملف الطلب', a.id);
    return jsonb_build_object('ok', true, 'status', 'declined');
  end if;

  -- 5) تسديد القسط ← إصدار الوثيقة
  if act = 'pay' then
    if pol.status <> 'payment' or r not in ('ins_finance', 'ins_md') then raise exception 'تسجيل القسط لموظف الحسابات'; end if;
    if length(trim(coalesce(p->>'ref', ''))) < 3 then raise exception 'اكتب رقم وصل القبض أو الحوالة'; end if;
    v_no := 'POL-' || upper((select code from orgs where id = pol.org_id)) || '-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_pol_seq')::text, 5, '0');
    v_seal := encode(extensions.digest(convert_to(jsonb_build_object('policy', v_no, 'request', pol.code, 'app', a.code, 'insured', pol.insured_name, 'beneficiary', pol.beneficiary,
      'sum', pol.sum_insured, 'premium', pol.premium, 'rate', pol.rate_pct, 'deductible', pol.deductible_pct, 'coverages', pol.coverages, 'survey', pol.survey,
      'start', current_date, 'end', (current_date + interval '1 year' - interval '1 day')::date, 'approved', pol.approved_by_code, 'paid', trim(p->>'ref'), 'by', me.staff_code, 'at', now())::text, 'UTF8'), 'sha256'), 'hex');
    update ins_policies set status = 'active', policy_no = v_no, paid_ref = trim(p->>'ref'), paid_at = now(), paid_by_name = me.full_name,
      start_date = coalesce(case when pol.prev_id is not null then (select end_date + 1 from ins_policies where id = pol.prev_id) end, current_date),
      end_date = (coalesce(case when pol.prev_id is not null then (select end_date + 1 from ins_policies where id = pol.prev_id) end, current_date) + interval '1 year' - interval '1 day')::date,
      issued_at = now(), seal = v_seal, updated_at = now() where id = pol.id returning * into pol;
    update applications set insurance_status = 'active', insurance = jsonb_build_object('org', (select name from orgs where id = pol.org_id), 'code', pol.code, 'policy_no', v_no,
      'premium', pol.premium, 'sum', pol.sum_insured, 'start', pol.start_date, 'end', pol.end_date) where id = a.id;
    perform _ins_log(pol.id, null, 'تسديد القسط وإصدار الوثيقة ' || v_no, 'وصل ' || trim(p->>'ref') || ' · البصمة ' || left(v_seal, 16) || '…');
    perform _ev(a.id, a.stage, 'وثيقة تأمين ' || v_no, (select name from orgs where id = pol.org_id) || ' · مبلغ التأمين ' || to_char(pol.sum_insured, 'FM999,999,999,999')
      || ' · القسط ' || to_char(pol.premium, 'FM999,999,999') || ' · من ' || pol.start_date || ' إلى ' || pol.end_date || ' · بصمة ' || left(v_seal, 16));
    ttl := 'صدرت وثيقة التأمين ' || v_no;
    body := a.code || ' · ' || (select name from orgs where id = pol.org_id) || ' · سارية حتى ' || pol.end_date || ' · المستفيد الأول ' || coalesce(pol.beneficiary, 'المصرف');
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr', 'bank_teller'], 'ins_result', ttl, body, a.id); sent := array_append(sent, 'المصرف');
    if a.citizen_id is not null then
      insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, 'ins_result', 'مشروعك مؤمَّن الآن — وثيقة ' || v_no, 'سارية حتى ' || pol.end_date || '. عند أي ضرر أبلغ مصرفك أو شركة التأمين.', a.id);
      sent := array_append(sent, 'المقترض');
    end if;
    perform _ins_notify(pol.org_id, pol.branch_id, array['ins_underwriter', 'ins_branch_mgr'], 'ins_result', ttl, body, pol.id); sent := array_append(sent, 'الاكتتاب');
    return jsonb_build_object('ok', true, 'status', 'active', 'policy_no', v_no, 'seal', v_seal, 'sent', to_jsonb(sent), 'start', pol.start_date, 'end', pol.end_date);
  end if;

  -- إلغاء الوثيقة (الإدارة العليا)
  if act = 'cancel' then
    if pol.status not in ('payment', 'active') or r <> 'ins_md' then raise exception 'الإلغاء للإدارة العليا'; end if;
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الإلغاء'; end if;
    if exists (select 1 from ins_claims where policy_id = pol.id and status not in ('paid', 'rejected')) then raise exception 'على الوثيقة مطالبة مفتوحة — أنهها أولاً'; end if;
    update ins_policies set status = 'cancelled', close_reason = v_note, updated_at = now() where id = pol.id;
    update applications set insurance_status = 'cancelled' where id = a.id and not exists (select 1 from ins_policies x where x.application_id = a.id and x.status = 'active' and x.id <> pol.id);
    perform _ins_log(pol.id, null, 'إلغاء الوثيقة', v_note);
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', 'أُلغيت وثيقة التأمين على ' || a.code, coalesce(pol.policy_no, pol.code) || ' · السبب: ' || v_note, a.id);
    return jsonb_build_object('ok', true, 'status', 'cancelled');
  end if;

  -- التجديد السنوي: وثيقة جديدة بالشروط نفسها، بانتظار القسط
  if act = 'renew' then
    if pol.status not in ('active', 'expired') or r not in ('ins_finance', 'ins_md') then raise exception 'التجديد لموظف الحسابات أو الإدارة العليا'; end if;
    if pol.end_date > current_date + 30 then raise exception 'يُفتح التجديد قبل 30 يوماً من نهاية الوثيقة'; end if;
    if exists (select 1 from ins_policies x where x.prev_id = pol.id and x.status not in ('declined', 'cancelled')) then raise exception 'جُدّدت هذه الوثيقة مسبقاً'; end if;
    insert into ins_policies(code, org_id, branch_id, application_id, product_id, prev_id, origin, requested_by_title, status, insured_name, beneficiary, asset,
      sum_insured, rate_pct, premium, deductible_pct, coverages, approver_level, approved_by_name, approved_by_code, approved_at, survey, due_at)
    values ('INR-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_req_seq')::text, 5, '0'), pol.org_id, pol.branch_id, pol.application_id, pol.product_id, pol.id, 'renewal', me.position_title, 'payment',
      pol.insured_name, pol.beneficiary, pol.asset, pol.sum_insured, pol.rate_pct, pol.premium, pol.deductible_pct, pol.coverages, pol.approver_level, me.full_name, me.staff_code, now(), pol.survey, now() + interval '30 days')
    returning * into n;
    perform _ins_log(n.id, null, 'تجديد الوثيقة ' || coalesce(pol.policy_no, pol.code) || ' — بانتظار القسط', v_note);
    perform _ins_log(pol.id, null, 'فُتح التجديد ' || n.code, null);
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops'], 'ins_result', 'تجديد تأمين ' || a.code || ' — القسط مستحق', (select name from orgs where id = pol.org_id) || ' · ' || to_char(n.premium, 'FM999,999,999') || ' د.ع', a.id);
    return jsonb_build_object('ok', true, 'id', n.id, 'code', n.code, 'status', 'payment');
  end if;

  raise exception 'إجراء غير معروف';
end $f$;

-- ───────── 8) المطالبات ─────────
-- الإبلاغ: المصرف صاحب الطلب، أو المقترض نفسه، أو موظف المطالبات في الشركة
create or replace function public.ins_claim_report(p_app uuid, p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pol ins_policies; a applications; c ins_claims; v_side text; v_date date;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me.id is null or a.id is null then raise exception 'غير مخوّل'; end if;
  select * into pol from ins_policies where application_id = a.id and status = 'active' order by start_date desc limit 1;
  if pol.id is null then raise exception 'لا توجد وثيقة تأمين سارية على هذا المشروع'; end if;
  v_side := case when me.portal = 'bank' and me.org_id = a.bank_id then 'المصرف'
                 when me.id = a.citizen_id then 'المقترض'
                 when me.portal = 'insurance' and me.org_id = pol.org_id and me.role in ('ins_claims', 'ins_branch_mgr', 'ins_md') and _ins_in_scope(me, pol.org_id, pol.branch_id) then 'شركة التأمين' end;
  if v_side is null then raise exception 'الإبلاغ للمصرف صاحب الطلب أو المقترض أو موظف المطالبات'; end if;
  if coalesce(p->>'cause', '') not in ('fire', 'electrical', 'nature', 'theft', 'accident', 'liability', 'other') then raise exception 'اختر سبب الضرر'; end if;
  v_date := nullif(p->>'incident_date', '')::date;
  if v_date is null or v_date > current_date then raise exception 'تاريخ الحادث غير صحيح'; end if;
  if v_date < pol.start_date or v_date > pol.end_date then raise exception 'تاريخ الحادث خارج مدة الوثيقة (% — %)', pol.start_date, pol.end_date; end if;
  if length(trim(coalesce(p->>'description', ''))) < 10 then raise exception 'صف ما حدث بجملة واضحة'; end if;
  if exists (select 1 from ins_claims where policy_id = pol.id and incident_date = v_date and cause = p->>'cause' and status not in ('rejected')) then raise exception 'أُبلغ عن هذا الحادث مسبقاً'; end if;
  insert into ins_claims(code, policy_id, org_id, branch_id, application_id, cause, incident_date, description, claimed, reported_by_name, reported_by_side)
  values ('CLM-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_clm_seq')::text, 5, '0'), pol.id, pol.org_id, pol.branch_id, a.id, p->>'cause', v_date, trim(p->>'description'),
    nullif(regexp_replace(coalesce(p->>'claimed', ''), '[^0-9]', '', 'g'), '')::bigint, me.full_name, v_side)
  returning * into c;
  perform _ins_log(pol.id, c.id, 'إبلاغ عن ضرر ' || c.code || ' — ' || _ins_cause_label(c.cause), v_side || ' · ' || c.description);
  perform _ins_notify(pol.org_id, pol.branch_id, array['ins_claims', 'ins_branch_mgr'], 'ins_claim', 'مطالبة جديدة ' || c.code || ': ' || _ins_cause_label(c.cause),
    coalesce(a.citizen_name, '') || ' · ' || coalesce(pol.policy_no, '') || ' · أبلغ ' || v_side, c.id);
  if v_side <> 'المصرف' then
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', 'مطالبة تأمين على ' || a.code, _ins_cause_label(c.cause) || ' · ' || c.code, a.id);
  end if;
  return jsonb_build_object('ok', true, 'code', c.code, 'id', c.id, 'company', (select name from orgs where id = pol.org_id));
end $f$;

create or replace function public.ins_claim(p_id uuid) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles := _ins_me(); c ins_claims; pol ins_policies; r text := me.role; lim bigint;
begin
  select * into c from ins_claims where id = p_id;
  if c.id is null or not _ins_in_scope(me, c.org_id, c.branch_id) or (r = 'ins_surveyor' and c.surveyor_id is distinct from me.id) then raise exception 'المطالبة خارج نطاقك'; end if;
  select * into pol from ins_policies where id = c.policy_id;
  select branch_limit into lim from ins_products where id = pol.product_id;
  return _ins_claim_row(c) || jsonb_build_object('survey', c.survey, 'assess_note', c.assess_note, 'assessed_by', c.assessed_by_name, 'approver_level', c.approver_level,
    'approved_by', c.approved_by_name, 'approved_at', c.approved_at, 'paid_ref', c.paid_ref, 'paid_at', c.paid_at, 'paid_to', c.paid_to, 'paid_by', c.paid_by_name, 'seal', c.seal, 'decision_note', c.decision_note,
    'policy', jsonb_build_object('id', pol.id, 'policy_no', pol.policy_no, 'sum_insured', pol.sum_insured, 'deductible_pct', pol.deductible_pct, 'coverages', pol.coverages,
      'beneficiary', pol.beneficiary, 'start', pol.start_date, 'end', pol.end_date, 'asset', pol.asset, 'branch_limit', lim,
      'paid_before', (select coalesce(sum(payable), 0) from ins_claims x where x.policy_id = pol.id and x.status = 'paid' and x.id <> c.id)),
    'site', (select jsonb_build_object('borrower', a.citizen_name, 'phone', (select phone from profiles where id = a.citizen_id), 'governorate', a.governorate, 'city', a.city,
      'site_geo', a.site_geo, 'install_geo', a.install_geo, 'bank', (select name from orgs where id = a.bank_id)) from applications a where a.id = c.application_id),
    'log', (select coalesce(jsonb_agg(jsonb_build_object('at', l.at, 'by', l.actor_name, 'code', l.actor_code, 'action', l.action, 'note', l.note) order by l.id), '[]') from ins_log l where l.claim_id = c.id),
    'can', jsonb_build_object(
      'assign', c.status = 'reported' and r in ('ins_claims', 'ins_branch_mgr', 'ins_md'),
      'survey', c.status = 'survey' and c.surveyor_id = me.id,
      'assess', c.status = 'assessment' and r in ('ins_claims', 'ins_branch_mgr', 'ins_md'),
      'reject', c.status in ('reported', 'survey', 'assessment', 'approval') and r in ('ins_claims', 'ins_branch_mgr', 'ins_md'),
      'approve', c.status = 'approval' and (r = 'ins_md' or (r = 'ins_branch_mgr' and c.approver_level = 'branch')),
      'pay', c.status = 'payment' and r in ('ins_finance', 'ins_md')));
end $f$;

create or replace function public.ins_claim_act(p_id uuid, p jsonb) returns jsonb language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles := _ins_me(); c ins_claims; pol ins_policies; a applications; lim bigint; act text := p->>'action'; r text := me.role; s profiles;
  v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_gps jsonb; v_photo uuid; v_est bigint; v_ass bigint; v_ded bigint; v_pay bigint; v_room bigint; v_seal text; ttl text; body text; sent text[] := '{}';
begin
  select * into c from ins_claims where id = p_id for update;
  if c.id is null or not _ins_in_scope(me, c.org_id, c.branch_id) then raise exception 'المطالبة خارج نطاقك'; end if;
  select * into pol from ins_policies where id = c.policy_id;
  select * into a from applications where id = c.application_id;
  select branch_limit into lim from ins_products where id = pol.product_id;

  if act = 'assign' then
    if c.status not in ('reported', 'survey') or r not in ('ins_claims', 'ins_branch_mgr', 'ins_md') then raise exception 'إسناد المعاينة لموظف المطالبات أو المدير'; end if;
    s := _ins_pick_surveyor(c.org_id, c.branch_id, nullif(p->>'surveyor', '')::uuid);
    update ins_claims set status = 'survey', surveyor_id = s.id, surveyor_name = s.full_name, updated_at = now() where id = c.id;
    perform _ins_log(pol.id, c.id, 'إحالة لمعاينة الضرر — ' || s.full_name, v_note);
    insert into notifications(user_id, kind, title, body, ref_id) values (s.id, 'ins_claim', 'معاينة ضرر: ' || c.code, _ins_cause_label(c.cause) || ' · ' || coalesce(a.citizen_name, '') || ' · ' || coalesce(a.governorate, ''), c.id);
    return jsonb_build_object('ok', true, 'status', 'survey', 'surveyor', s.full_name);
  end if;

  if act = 'survey' then
    if c.status <> 'survey' or c.surveyor_id is distinct from me.id then raise exception 'المعاينة للمعاين المسند إليه'; end if;
    v_est := nullif(regexp_replace(coalesce(p->>'estimate', ''), '[^0-9]', '', 'g'), '')::bigint;
    if v_est is null then raise exception 'اكتب تقدير كلفة الإصلاح أو الاستبدال'; end if;
    if v_note is null then raise exception 'اكتب وصف الضرر كما رأيته'; end if;
    v_gps := _ins_gps(p->'gps');
    v_photo := _ins_photo_save(a.id, p->>'photo', 'معاينة ضرر ' || c.code);
    if v_photo is null then raise exception 'صوّر الضرر — الصورة دليل إلزامي'; end if;
    update ins_claims set status = 'assessment', survey = jsonb_build_object('note', v_note, 'estimate', v_est, 'gps', v_gps, 'photo', v_photo, 'by', me.full_name, 'code', me.staff_code, 'at', now(),
      'covered', coalesce((p->>'covered')::boolean, true)), updated_at = now() where id = c.id;
    perform _ins_log(pol.id, c.id, 'معاينة الضرر — التقدير ' || to_char(v_est, 'FM999,999,999,999') || ' د.ع', v_note);
    perform _ins_notify(c.org_id, c.branch_id, array['ins_claims'], 'ins_claim', 'اكتملت معاينة ' || c.code || ' — جاهزة للتقدير', coalesce(a.citizen_name, ''), c.id);
    return jsonb_build_object('ok', true, 'status', 'assessment');
  end if;

  if act = 'assess' then
    if c.status <> 'assessment' or r not in ('ins_claims', 'ins_branch_mgr', 'ins_md') then raise exception 'التقدير لموظف المطالبات أو المدير'; end if;
    v_ass := nullif(regexp_replace(coalesce(p->>'assessed', ''), '[^0-9]', '', 'g'), '')::bigint;
    if v_ass is null or v_ass <= 0 then raise exception 'اكتب مبلغ الضرر المقبول'; end if;
    v_room := greatest(0, pol.sum_insured - (select coalesce(sum(payable), 0) from ins_claims x where x.policy_id = pol.id and x.status = 'paid'));
    v_ass := least(v_ass, v_room);
    v_ded := round(v_ass * coalesce(pol.deductible_pct, 0) / 100);
    v_pay := greatest(0, v_ass - v_ded);
    update ins_claims set status = 'approval', assessed = v_ass, deductible = v_ded, payable = v_pay, assess_note = v_note, assessed_by_name = me.full_name,
      approver_level = case when v_pay > coalesce(lim, 0) then 'md' else 'branch' end, updated_at = now() where id = c.id returning * into c;
    perform _ins_log(pol.id, c.id, 'التقدير: التعويض ' || to_char(v_pay, 'FM999,999,999,999') || ' د.ع', 'الضرر المقبول ' || to_char(v_ass, 'FM999,999,999,999') || ' − التحمّل ' || to_char(v_ded, 'FM999,999,999') || coalesce(' · ' || v_note, ''));
    perform _ins_notify(c.org_id, case when c.approver_level = 'md' then null else c.branch_id end, array[case when c.approver_level = 'md' then 'ins_md' else 'ins_branch_mgr' end], 'ins_claim',
      'تعويض بانتظار اعتمادك: ' || c.code, to_char(v_pay, 'FM999,999,999,999') || ' د.ع · ' || coalesce(a.citizen_name, ''), c.id);
    return jsonb_build_object('ok', true, 'status', 'approval', 'payable', v_pay, 'deductible', v_ded, 'assessed', v_ass, 'level', c.approver_level);
  end if;

  if act = 'reject' then
    if c.status not in ('reported', 'survey', 'assessment', 'approval') or r not in ('ins_claims', 'ins_branch_mgr', 'ins_md') then raise exception 'الرفض لموظف المطالبات أو المدير'; end if;
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الرفض — يصل للمصرف والمقترض'; end if;
    update ins_claims set status = 'rejected', decision_note = v_note, updated_at = now() where id = c.id;
    perform _ins_log(pol.id, c.id, 'رفض المطالبة', v_note);
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', 'رُفضت مطالبة التأمين ' || c.code, a.code || ' · السبب: ' || v_note, a.id);
    if a.citizen_id is not null then insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, 'ins_result', 'لم تُقبل مطالبة التأمين ' || c.code, v_note, a.id); end if;
    return jsonb_build_object('ok', true, 'status', 'rejected');
  end if;

  if act in ('approve', 'return') then
    if c.status <> 'approval' or not (r = 'ins_md' or (r = 'ins_branch_mgr' and c.approver_level = 'branch')) then
      raise exception '%', case when c.approver_level = 'md' then 'التعويض فوق سقف الفرع — الاعتماد للإدارة العليا' else 'الاعتماد لمدير الفرع أو الإدارة العليا' end; end if;
    if act = 'return' then
      if v_note is null then raise exception 'اكتب سبب الإعادة'; end if;
      update ins_claims set status = 'assessment', updated_at = now() where id = c.id;
      perform _ins_log(pol.id, c.id, 'إعادة للتقدير', v_note);
      return jsonb_build_object('ok', true, 'status', 'assessment');
    end if;
    if trim(coalesce(p->>'confirm', '')) <> 'أعتمد التعويض' then raise exception 'اكتب «أعتمد التعويض» للتأكيد'; end if;
    update ins_claims set status = 'payment', approved_by_name = me.full_name, approved_at = now(), decision_note = v_note, updated_at = now() where id = c.id;
    perform _ins_log(pol.id, c.id, 'اعتماد التعويض — بانتظار الصرف', v_note);
    perform _ins_notify(c.org_id, c.branch_id, array['ins_finance'], 'ins_claim', 'تعويض بانتظار الصرف: ' || c.code, to_char(c.payable, 'FM999,999,999,999') || ' د.ع للمستفيد ' || coalesce(pol.beneficiary, ''), c.id);
    return jsonb_build_object('ok', true, 'status', 'payment');
  end if;

  if act = 'pay' then
    if c.status <> 'payment' or r not in ('ins_finance', 'ins_md') then raise exception 'الصرف لموظف الحسابات'; end if;
    if length(trim(coalesce(p->>'ref', ''))) < 3 then raise exception 'اكتب رقم الحوالة أو الصك'; end if;
    v_seal := encode(extensions.digest(convert_to(jsonb_build_object('claim', c.code, 'policy', pol.policy_no, 'app', a.code, 'cause', c.cause, 'incident', c.incident_date,
      'assessed', c.assessed, 'deductible', c.deductible, 'payable', c.payable, 'survey', c.survey, 'paid_to', coalesce(nullif(trim(p->>'paid_to'), ''), pol.beneficiary),
      'ref', trim(p->>'ref'), 'by', me.staff_code, 'at', now())::text, 'UTF8'), 'sha256'), 'hex');
    update ins_claims set status = 'paid', paid_ref = trim(p->>'ref'), paid_at = now(), paid_to = coalesce(nullif(trim(p->>'paid_to'), ''), pol.beneficiary), paid_by_name = me.full_name, seal = v_seal, updated_at = now()
    where id = c.id returning * into c;
    perform _ins_log(pol.id, c.id, 'صرف التعويض ' || to_char(c.payable, 'FM999,999,999,999') || ' د.ع إلى ' || c.paid_to, 'مرجع ' || c.paid_ref || ' · البصمة ' || left(v_seal, 16) || '…');
    perform _ev(a.id, a.stage, 'تعويض تأمين ' || c.code, _ins_cause_label(c.cause) || ' · ' || to_char(c.payable, 'FM999,999,999,999') || ' د.ع إلى ' || c.paid_to || ' · بصمة ' || left(v_seal, 16));
    ttl := 'صُرف تعويض التأمين ' || c.code;
    body := a.code || ' · ' || to_char(c.payable, 'FM999,999,999,999') || ' د.ع إلى ' || c.paid_to || ' · مرجع ' || c.paid_ref;
    perform _eng_notify_roles(a.bank_id, 'bank', array['bank_ops', 'bank_branch_mgr'], 'ins_result', ttl, body, a.id); sent := array_append(sent, 'المصرف');
    if a.citizen_id is not null then insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, 'ins_result', ttl, body, a.id); sent := array_append(sent, 'المقترض'); end if;
    return jsonb_build_object('ok', true, 'status', 'paid', 'seal', v_seal, 'sent', to_jsonb(sent), 'payable', c.payable, 'paid_to', c.paid_to);
  end if;

  raise exception 'إجراء غير معروف';
end $f$;

-- ───────── 9) الإدارة العليا للشركة: المنتجات والأسعار ─────────
create or replace function public.ins_product_save(p jsonb) returns ins_products language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _ins_me(); x ins_products;
begin
  if me.role <> 'ins_md' then raise exception 'أسعار المنتجات للإدارة العليا'; end if;
  select * into x from ins_products where id = (p->>'id')::uuid and org_id = me.org_id for update;
  if x.id is null then raise exception 'المنتج غير موجود'; end if;
  if (p->>'rate_pct')::numeric <= 0 or (p->>'rate_pct')::numeric > 10 then raise exception 'نسبة القسط بين 0 و10%%'; end if;
  if (p->>'deductible_pct')::numeric < 0 or (p->>'deductible_pct')::numeric > 50 then raise exception 'نسبة التحمّل بين 0 و50%%'; end if;
  update ins_products set name = coalesce(nullif(trim(p->>'name'), ''), name), rate_pct = (p->>'rate_pct')::numeric, min_premium = coalesce((p->>'min_premium')::bigint, min_premium),
    deductible_pct = (p->>'deductible_pct')::numeric, survey_above = coalesce((p->>'survey_above')::bigint, survey_above), branch_limit = coalesce((p->>'branch_limit')::bigint, branch_limit),
    coverages = coalesce(p->'coverages', coverages), active = coalesce((p->>'active')::boolean, active), updated_at = now(), updated_by = me.full_name
  where id = x.id returning * into x;
  perform _taudit('تعديل منتج تأمين', x.name, jsonb_build_object('rate', x.rate_pct, 'deductible', x.deductible_pct, 'limit', x.branch_limit), me.org_id, null);
  return x;
end $f$;

-- لوحة الإدارة العليا: الأرقام حسب الفرع
create or replace function public.ins_dashboard() returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles := _ins_me();
begin
  if me.role not in ('ins_md', 'ins_branch_mgr', 'ins_finance') then raise exception 'اللوحة للإدارة والحسابات'; end if;
  return jsonb_build_object(
    'active', (select count(*) from ins_policies where org_id = me.org_id and status = 'active' and _ins_in_scope(me, org_id, branch_id)),
    'sum_insured', (select coalesce(sum(sum_insured), 0) from ins_policies where org_id = me.org_id and status = 'active' and _ins_in_scope(me, org_id, branch_id)),
    'premiums', (select coalesce(sum(premium), 0) from ins_policies where org_id = me.org_id and paid_at is not null and _ins_in_scope(me, org_id, branch_id)),
    'claims_paid', (select coalesce(sum(payable), 0) from ins_claims where org_id = me.org_id and status = 'paid' and _ins_in_scope(me, org_id, branch_id)),
    'claims_open', (select count(*) from ins_claims where org_id = me.org_id and status not in ('paid', 'rejected') and _ins_in_scope(me, org_id, branch_id)),
    'branches', (select coalesce(jsonb_agg(jsonb_build_object('name', b.name,
        'pipeline', (select count(*) from ins_policies p where p.branch_id = b.id and p.status in ('new', 'survey', 'pricing', 'approval', 'payment')),
        'active', (select count(*) from ins_policies p where p.branch_id = b.id and p.status = 'active'),
        'late', (select count(*) from ins_policies p where p.branch_id = b.id and p.status in ('new', 'survey', 'pricing', 'approval') and p.due_at < now()),
        'premiums', (select coalesce(sum(premium), 0) from ins_policies p where p.branch_id = b.id and p.paid_at is not null),
        'claims', (select coalesce(sum(payable), 0) from ins_claims c where c.branch_id = b.id and c.status = 'paid'),
        'staff', (select count(*) from profiles x where x.branch_id = b.id and not coalesce(x.disabled, false))) order by b.is_main desc, b.code), '[]')
      from branches b where b.bank_id = me.org_id and (me.branch_id is null or b.id = me.branch_id)));
end $f$;

-- صورة المعاينة لمن يحق له رؤية الوثيقة
create or replace function public.ins_photo(p_doc uuid) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare d app_documents; me profiles;
begin
  select * into me from profiles where id = auth.uid();
  select * into d from app_documents where id = p_doc and kind = 'ins_photo';
  if d.id is null or me.id is null then raise exception 'الصورة غير موجودة'; end if;
  if not (me.portal = 'admin'
      or exists (select 1 from ins_policies x where x.application_id = d.application_id and x.org_id = me.org_id and me.portal = 'insurance')
      or exists (select 1 from applications a where a.id = d.application_id and (a.bank_id = me.org_id or a.citizen_id = me.id))
      or me.portal in ('cbi', 'integrity', 'audit')) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('data', d.data, 'label', d.meta->>'label', 'at', d.created_at, 'by', d.uploaded_by_title);
end $f$;

-- ───────── 10) التأمين في ملف الطلب (المصرف، البنك المركزي، الرقابة، المقترض) ─────────
create or replace function public.ins_app_report(p_app uuid) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; a applications; ok boolean; bank_staff boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me.id is null or a.id is null then return null; end if;
  bank_staff := me.portal = 'bank' and me.org_id = a.bank_id;
  ok := bank_staff or me.id = a.citizen_id or me.portal in ('admin', 'cbi', 'integrity', 'audit')
     or (me.portal = 'insurance' and exists (select 1 from ins_policies x where x.application_id = a.id and x.org_id = me.org_id));
  if not ok then return null; end if;
  return jsonb_build_object(
    'policies', (select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'code', x.code, 'policy_no', x.policy_no, 'status', x.status, 'status_label', _ins_status_label(x.status),
        'company', (select name from orgs where id = x.org_id), 'branch', (select name from branches where id = x.branch_id), 'sum_insured', x.sum_insured, 'premium', x.premium,
        'deductible_pct', x.deductible_pct, 'start', x.start_date, 'end', x.end_date, 'beneficiary', x.beneficiary, 'seal', x.seal, 'close_reason', x.close_reason, 'origin', x.origin,
        'coverages', (select coalesce(jsonb_agg(c->>'label'), '[]') from jsonb_array_elements(coalesce(x.coverages, '[]')) c where (c->>'on')::boolean),
        'survey', case when x.survey is not null then jsonb_build_object('risk', x.survey->>'risk', 'at', x.survey->>'at', 'by', x.survey->>'by', 'photo', x.survey->>'photo') end,
        'created_at', x.created_at) order by x.created_at desc), '[]') from ins_policies x where x.application_id = a.id),
    'claims', (select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'code', c.code, 'status', c.status, 'status_label', _ins_claim_label(c.status), 'cause_label', _ins_cause_label(c.cause),
        'incident_date', c.incident_date, 'claimed', c.claimed, 'payable', c.payable, 'paid_at', c.paid_at, 'paid_to', c.paid_to, 'decision_note', c.decision_note, 'reported_side', c.reported_by_side) order by c.created_at desc), '[]')
      from ins_claims c where c.application_id = a.id),
    'can_request', bank_staff and a.status in ('active', 'returned', 'completed') and a.stage >= 8
      and not exists (select 1 from ins_policies x where x.application_id = a.id and x.status in ('new', 'survey', 'pricing', 'approval', 'payment', 'active')),
    'can_claim', (bank_staff or me.id = a.citizen_id) and exists (select 1 from ins_policies x where x.application_id = a.id and x.status = 'active'),
    'insurers', case when bank_staff then (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name,
        'covers', jsonb_array_length(coalesce(o.meta->'governorates', '[]')) = 0 or o.meta->'governorates' ? a.governorate) order by o.name), '[]')
      from orgs o where o.type = 'insurer' and not coalesce((o.meta->>'suspended')::boolean, false)) end,
    'required', coalesce(_setting('ins_required'), 0) = 1);
end $f$;

-- المصرف يطلب التأمين يدوياً (أو من شركة أخرى بعد اعتذار الأولى)
create or replace function public.ins_request(p_app uuid, p_org uuid, p_note text) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; v_org uuid := p_org; pol ins_policies;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me.portal <> 'bank' or me.org_id is distinct from a.bank_id or coalesce(me.disabled, false) then raise exception 'طلب التأمين لموظفي المصرف صاحب الطلب'; end if;
  if a.stage < 8 then raise exception 'يُطلب التأمين بعد الموافقة المبدئية'; end if;
  if v_org is null then v_org := _ins_pick_org(a.governorate); end if;
  if v_org is null then raise exception 'لا توجد شركة تأمين معتمدة تغطي محافظة %', coalesce(a.governorate, ''); end if;
  pol := _ins_create(a.id, v_org, 'bank', p_note, me.position_title);
  perform _ev(a.id, a.stage, 'طلب تأمين ' || pol.code, (select name from orgs where id = v_org) || coalesce(' · ' || nullif(trim(coalesce(p_note, '')), ''), ''));
  return jsonb_build_object('ok', true, 'code', pol.code, 'company', (select name from orgs where id = v_org), 'branch', (select name from branches where id = pol.branch_id));
end $f$;

-- ───────── 11) الصلاحيات على الدوال ─────────
revoke all on function public._ins_me(), public._ins_log(uuid, uuid, text, text), public._ins_notify(uuid, uuid, text[], text, text, text, uuid),
  public._ins_pick_org(text), public._ins_pick_branch(uuid, text), public._ins_create(uuid, uuid, text, text, text), public._ins_default_products(uuid),
  public._ins_pick_surveyor(uuid, uuid, uuid), public._ins_photo_save(uuid, text, text), public._ins_expire(), public._ins_row(ins_policies), public._ins_claim_row(ins_claims),
  public._onboard_manager(orgs, jsonb) from public, anon, authenticated;
revoke all on function public.ins_inbox(), public.ins_policy(uuid), public.ins_policy_act(uuid, jsonb), public.ins_claim_report(uuid, jsonb), public.ins_claim(uuid),
  public.ins_claim_act(uuid, jsonb), public.ins_product_save(jsonb), public.ins_dashboard(), public.ins_photo(uuid), public.ins_app_report(uuid), public.ins_request(uuid, uuid, text),
  public.admin_onboard_org(jsonb), public.admin_add_org_manager(uuid, jsonb), public.admin_org_update(uuid, jsonb), public.admin_org_suspend(uuid, boolean, text),
  public.team_branches(), public.team_save_branch(jsonb) from public, anon;
grant execute on function public.ins_inbox(), public.ins_policy(uuid), public.ins_policy_act(uuid, jsonb), public.ins_claim_report(uuid, jsonb), public.ins_claim(uuid),
  public.ins_claim_act(uuid, jsonb), public.ins_product_save(jsonb), public.ins_dashboard(), public.ins_photo(uuid), public.ins_app_report(uuid), public.ins_request(uuid, uuid, text),
  public.admin_onboard_org(jsonb), public.admin_add_org_manager(uuid, jsonb), public.admin_org_update(uuid, jsonb), public.admin_org_suspend(uuid, boolean, text),
  public.team_branches(), public.team_save_branch(jsonb) to authenticated;

-- ───────── 12) بيانات العرض: «الأمان للتأمين» بفرعين وفريق كامل، ووثائق في مراحل مختلفة ─────────
insert into public.orgs(code, type, name, meta)
select 'amn', 'insurer', 'الأمان للتأمين', '{"governorates": [], "license": "ISB-2026-007", "demo": true}'::jsonb
where not exists (select 1 from public.orgs where code = 'amn');
insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone)
select (select id from public.orgs where code = 'amn'), 'AMN-01', 'الفرع الرئيسي — بغداد',
  '{بغداد,ديالى,الأنبار,صلاح الدين,واسط,نينوى,كركوك,أربيل,السليمانية,دهوك,بابل,كربلاء,النجف,القادسية}', true, '07700900901'
where not exists (select 1 from public.branches where code = 'AMN-01');
insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone)
select (select id from public.orgs where code = 'amn'), 'AMN-02', 'فرع البصرة', '{البصرة,ذي قار,ميسان,المثنى}', false, '07700900902'
where not exists (select 1 from public.branches where code = 'AMN-02');
select public._ins_default_products((select id from public.orgs where code = 'amn'));

do $$
declare r text[]; rows text[][] := array[
  -- اسم الدخول، كلمة المرور، الاسم، الدور، الفرع، نطاق الإدارة
  ['ins.md',      'Ins@2026md', 'سامر عبد الأمير الحسناوي', 'ins_md',          '',       'org'],
  ['ins.branch',  'Ins@2026br', 'رغد فاضل الجنابي',          'ins_branch_mgr',  'AMN-01', 'branch'],
  ['ins.uw',      'Ins@2026uw', 'حيدر صباح الزيدي',          'ins_underwriter', 'AMN-01', ''],
  ['ins.sv',      'Ins@2026sv', 'م. مصطفى جاسم العبيدي',     'ins_surveyor',    'AMN-01', ''],
  ['ins.cl',      'Ins@2026cl', 'آمنة كريم الساعدي',          'ins_claims',      'AMN-01', ''],
  ['ins.fn',      'Ins@2026fn', 'علي حسن الربيعي',            'ins_finance',     '',       ''],
  ['ins.branch2', 'Ins@2026b2', 'كاظم عبد الواحد البصري',    'ins_branch_mgr',  'AMN-02', 'branch'],
  ['ins.sv2',     'Ins@2026s2', 'م. زينب عادل التميمي',      'ins_surveyor',    'AMN-02', '']];
  i int; uid uuid; md uuid;
begin
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'insurance', 'amn', null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    select id into md from public.profiles where username = 'ins.md';
    update public.profiles set branch_id = (select id from public.branches where code = nullif(rows[i][5], '')),
      manage_scope = nullif(rows[i][6], ''), managed_by = case when rows[i][1] <> 'ins.md' then coalesce(managed_by, md) end
    where id = uid;
  end loop;
end $$;

-- وثائق العرض (مرة واحدة)
do $$
declare o uuid := (select id from public.orgs where code = 'amn'); p1 ins_policies; p2 ins_policies; p3 ins_policies; p4 ins_policies; c1 ins_claims;
  sv uuid := (select id from public.profiles where username = 'ins.sv'); uw uuid := (select id from public.profiles where username = 'ins.uw');
  a1 uuid := (select id from public.applications where code = 'ALW-2026-00032'); a2 uuid := (select id from public.applications where code = 'ALW-2026-00011');
  a3 uuid := (select id from public.applications where code = 'ALW-2026-00010'); a4 uuid := (select id from public.applications where code = 'ALW-2026-00012');
begin
  if o is null or exists (select 1 from public.ins_policies where org_id = o) then return; end if;
  -- 1) طلب وارد بانتظار الاكتتاب (بغداد)
  if a1 is not null then p1 := public._ins_create(a1, o, 'auto', null, 'آلي — المرحلة 30'); end if;
  -- 2) مسعّرة بانتظار اعتماد مدير الفرع (بغداد)
  if a2 is not null then
    p2 := public._ins_create(a2, o, 'bank', 'تأمين المنظومة قبل التسليم', 'مدير الفرع');
    update public.ins_policies set status = 'approval', underwriter_id = uw, underwriter_name = 'حيدر صباح الزيدي', premium = greatest(50000, round(sum_insured * rate_pct / 100)), approver_level = 'branch', updated_at = now() where id = p2.id;
    update public.applications set insurance_status = 'underwriting' where id = a2;
    insert into public.ins_log(policy_id, actor_name, actor_code, action, note) values (p2.id, 'حيدر صباح الزيدي', 'AMN-UW-001', 'التسعير', 'تسعير بالنسبة المعتمدة دون معاينة (دون حد المعاينة)');
  end if;
  -- 3) وثيقة سارية عليها مطالبة بانتظار معاينة الضرر (بغداد)
  if a3 is not null then
    p3 := public._ins_create(a3, o, 'auto', null, 'آلي — المرحلة 30');
    update public.ins_policies set status = 'active', policy_no = 'POL-AMN-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_pol_seq')::text, 5, '0'),
      premium = greatest(50000, round(sum_insured * rate_pct / 100)), approver_level = 'branch', approved_by_name = 'رغد فاضل الجنابي', approved_at = now() - interval '40 days',
      paid_ref = 'RCPT-58812', paid_at = now() - interval '39 days', paid_by_name = 'علي حسن الربيعي', issued_at = now() - interval '39 days',
      start_date = current_date - 39, end_date = current_date - 39 + 364, underwriter_name = 'حيدر صباح الزيدي',
      seal = encode(extensions.digest(convert_to('demo-' || p3.code, 'UTF8'), 'sha256'), 'hex'), updated_at = now() where id = p3.id returning * into p3;
    update public.applications set insurance_status = 'active', insurance = jsonb_build_object('org', 'الأمان للتأمين', 'code', p3.code, 'policy_no', p3.policy_no, 'premium', p3.premium, 'sum', p3.sum_insured, 'start', p3.start_date, 'end', p3.end_date) where id = a3;
    insert into public.ins_claims(code, policy_id, org_id, branch_id, application_id, status, cause, incident_date, description, claimed, reported_by_name, reported_by_side, surveyor_id, surveyor_name)
    values ('CLM-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_clm_seq')::text, 5, '0'), p3.id, o, p3.branch_id, a3, 'survey', 'nature', current_date - 3,
      'عاصفة ترابية مع بَرَد كسرت لوحين من ألواح المنظومة وتوقف العاكس عن العمل', 1200000, 'موظف العمليات المصرفية', 'المصرف', sv, 'م. مصطفى جاسم العبيدي') returning * into c1;
    insert into public.ins_log(policy_id, claim_id, actor_name, action, note) values (p3.id, c1.id, 'آمنة كريم الساعدي', 'إحالة لمعاينة الضرر — م. مصطفى جاسم العبيدي', null);
    insert into public.notifications(user_id, kind, title, body, ref_id) values (sv, 'ins_claim', 'معاينة ضرر: ' || c1.code, 'عاصفة أو أمطار أو بَرَد · بغداد', c1.id);
  end if;
  -- 4) وثيقة سارية (فرع البصرة)
  if a4 is not null then
    p4 := public._ins_create(a4, o, 'auto', null, 'آلي — المرحلة 30');
    update public.ins_policies set status = 'active', policy_no = 'POL-AMN-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('ins_pol_seq')::text, 5, '0'),
      premium = greatest(50000, round(sum_insured * rate_pct / 100)), approver_level = 'branch', approved_by_name = 'كاظم عبد الواحد البصري', approved_at = now() - interval '20 days',
      paid_ref = 'RCPT-60341', paid_at = now() - interval '19 days', paid_by_name = 'علي حسن الربيعي', issued_at = now() - interval '19 days',
      start_date = current_date - 19, end_date = current_date - 19 + 364,
      seal = encode(extensions.digest(convert_to('demo-' || p4.code, 'UTF8'), 'sha256'), 'hex'), updated_at = now() where id = p4.id returning * into p4;
    update public.applications set insurance_status = 'active', insurance = jsonb_build_object('org', 'الأمان للتأمين', 'code', p4.code, 'policy_no', p4.policy_no, 'premium', p4.premium, 'sum', p4.sum_insured, 'start', p4.start_date, 'end', p4.end_date) where id = a4;
  end if;
end $$;
