-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 53: اتحاد الصناعات — الفريق وإدارة علاقة المنتسب
--  1) فريق الاتحاد: مكاتب المحافظات (فروع الاتحاد) يضيفها الأمين العام من «فريقي»، ولكل موظف مكتبه ومحافظته،
--     وجاهزية الاتحاد (ما ينقص كل مكتب)، وتوجيه المعاملات والكشوف إلى مكتب المحافظة آلياً.
--  2) طلب الانتساب بخطوات: بيانات المعمل ← المستمسكات (إلزامية قبل الدفع) ← موقع المعمل ← المراجعة والدفع.
--  3) تجديد الهوية آلياً حسب مدة الانتهاء: فوري (حتى 90 يوماً بعد الانتهاء) ← مراجعة قسم العضوية (حتى سنة) ← كشف موقعي (أكثر من سنة)،
--     مع بدلات السنوات المتأخرة وغرامة التأخير، وتحديث عقد الإيجار المنتهي.
--  4) خدمات المنتسب: تحديث البيانات، كتاب تأييد عضوية فوري لأي جهة، بدل ضائع للهوية، إلغاء الانتماء، والتذكير الآلي قبل الانتهاء.
--  5) إصلاح: تجديد الهوية في الجلسة 52 لم يحدّث بصمتها فتظهر «بياناتها تغيرت» في صفحة التحقق.
-- الملف آمن للتكرار. تعديل الدوال القائمة من جلسات أخرى يتم داخل القاعدة باستبدال نص يقع مرة واحدة.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) الجداول والقيود ─────────
alter table public.union_files drop constraint if exists union_files_kind_check;
alter table public.union_files add constraint union_files_kind_check check (kind = any (array['membership','endorse','install','production','followup',
  'renewal','update','certificate','replace','cancel']));
alter table public.union_files drop constraint if exists union_files_status_check;
alter table public.union_files add constraint union_files_status_check check (status = any (array['draft','new','returned','inspection','committee','signing',
  'issued','delivered','done','rejected','cancelled']));
alter table public.union_files add column if not exists meta jsonb not null default '{}'::jsonb;

alter table public.union_letters drop constraint if exists union_letters_kind_check;
alter table public.union_letters add constraint union_letters_kind_check check (kind = any (array['membership','endorse','install','production','followup',
  'renewal','update','certificate','replace','cancel']));

alter table public.union_members drop constraint if exists union_members_status_check;
alter table public.union_members add constraint union_members_status_check check (status = any (array['pending','approved','rejected','suspended','expired','cancelled']));
alter table public.union_members add column if not exists card_version int not null default 1;
alter table public.union_members add column if not exists old_codes text[] not null default '{}';
alter table public.union_members add column if not exists reminders jsonb not null default '{}'::jsonb;
alter table public.union_members add column if not exists renewed_at timestamptz;

alter table public.union_docs add column if not exists valid_until date;
create index if not exists union_docs_member on public.union_docs(member_id);

insert into public.settings(key, value, label, circular_no) values
  ('union_renew_early_days', 60, 'اتحاد الصناعات: يُفتح تجديد الهوية قبل انتهائها بـ (يوماً)', null),
  ('union_renew_grace_days', 90, 'اتحاد الصناعات: التجديد الفوري دون مراجعة حتى (يوماً) بعد الانتهاء', null),
  ('union_renew_insp_days', 365, 'اتحاد الصناعات: بعد (يوماً) من الانتهاء يتطلب التجديد كشفاً موقعياً', null),
  ('union_late_fee_month', 5000, 'اتحاد الصناعات: غرامة تأخير التجديد عن كل شهر (د.ع)', null),
  ('union_late_fee_max', 60000, 'اتحاد الصناعات: أعلى غرامة تأخير (د.ع)', null),
  ('union_arrears_max_years', 5, 'اتحاد الصناعات: أقصى عدد سنوات متأخرة تُستوفى بدلاتها', null),
  ('union_cert_fee', 10000, 'اتحاد الصناعات: أجور كتاب تأييد العضوية (د.ع)', null),
  ('union_cert_days', 30, 'اتحاد الصناعات: مدة نفاذ كتاب تأييد العضوية (أيام)', null),
  ('union_replace_fee', 10000, 'اتحاد الصناعات: أجور بدل الهوية الضائعة أو التالفة (د.ع)', null),
  ('union_remind_days', 30, 'اتحاد الصناعات: تذكير المنتسب قبل انتهاء هويته بـ (يوماً)', null)
on conflict (key) do nothing;

-- ───────── 2) الفريق: مكاتب المحافظات والجاهزية (استبدال داخل الدوال الحية) ─────────
do $mig$
declare r record; src text; n int;
begin
  for r in select * from (values
    ('public._has_branches(text)',
     $x$select p_type in ('bank', 'insurer')$x$,
     $x$select p_type in ('bank', 'insurer', 'union')$x$),
    ('public.team_readiness()',
     $x$if o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then return null; end if;$x$,
     $x$if o.type not in ('bank', 'supplier', 'eng_audit', 'insurer', 'union') then return null; end if;$x$),
    ('public.team_save_branch(jsonb)',
     $x$'إضافة الفروع للإدارة العليا للمصرف أو لشركة التأمين فقط'$x$,
     $x$'إضافة الفروع للإدارة العليا للمصرف أو لشركة التأمين، ومكاتب المحافظات للأمين العام لاتحاد الصناعات'$x$),
    ('public._org_readiness(uuid)',
     $x$  elsif o.type = 'supplier' then$x$,
     $x$  elsif o.type = 'union' then   -- الجلسة 53: اتحاد الصناعات — أقسام المقر العام، ومكتب كل محافظة
    foreach r in array array['union_reg','union_eng','union_committee','union_fin'] loop
      if _org_has(o.id, r) then done := done || jsonb_build_array(_role_title(r));
      else miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r)); end if;
    end loop;
    for b in select id, name from branches where bank_id = o.id order by is_main desc, code loop
      foreach r in array array['union_reg','union_eng'] loop
        if not _org_has(o.id, r, b.id, false) then miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r, 'branch', b.id, 'branch_name', b.name)); end if;
      end loop;
    end loop;
    if not exists (select 1 from branches where bank_id = o.id) then
      warn := warn || '["لا توجد مكاتب محافظات — كل المعاملات يديرها المقر العام. أضفها من «فريقي ← مكاتب المحافظات»"]'::jsonb; end if;
    if (select count(*) from profiles where org_id = o.id and role = 'union_committee' and not coalesce(disabled, false)) < 3 then
      warn := warn || '["لجنة الصنف فيها أقل من 3 أعضاء — يكفي عضو واحد لرفع التوصية، ويُستحسن 3"]'::jsonb; end if;
    v_routable := jsonb_array_length(miss) = 0;

  elsif o.type = 'supplier' then$x$)
  ) v(fn, old, new) loop
    if to_regprocedure(r.fn) is null then raise exception 'الجلسة 53: الدالة % غير موجودة', r.fn; end if;
    src := pg_get_functiondef(r.fn::regprocedure);
    if position(r.new in src) > 0 then continue; end if;   -- طُبّق سابقاً
    n := (length(src) - length(replace(src, r.old, ''))) / length(r.old);
    if n <> 1 then raise exception 'الجلسة 53: النص المطلوب استبداله في % وُجد % مرة (المتوقع مرة واحدة)', r.fn, n; end if;
    execute replace(src, r.old, r.new);
  end loop;
end $mig$;

-- محافظة موظف الاتحاد تتبع مكتبه (تُستعمل لإسناد الكشوف وتوجيه الوارد)
create or replace function public._un_staff_gov() returns trigger language plpgsql security definer set search_path = public as $f$
declare g text[];
begin
  if new.portal <> 'union' then return new; end if;
  if new.branch_id is not null then
    select governorates into g from branches where id = new.branch_id;
    if cardinality(g) > 0 and not (coalesce(new.governorate, '') = any(g)) then new.governorate := g[1]; end if;
  elsif new.governorate is null then
    new.governorate := 'بغداد';
  end if;
  return new;
end $f$;
drop trigger if exists trg_un_staff_gov on public.profiles;
create trigger trg_un_staff_gov before insert or update of branch_id, portal on public.profiles for each row execute function public._un_staff_gov();

-- المكتب الذي يخدم المحافظة (إن وُجد)
create or replace function public._un_office(p_gov text) returns branches language sql stable security definer set search_path = public as $f$
  select b.* from branches b where b.bank_id = _un_org() and p_gov = any(coalesce(b.governorates, '{}')) order by b.is_main desc, b.code limit 1 $f$;

-- المهندس: المحدد، أو مهندس مكتب المحافظة الأقل انشغالاً، ثم مهندسو المقر العام، ثم أي مهندس
create or replace function public._un_pick_eng(p_gov text, p_want uuid) returns profiles language plpgsql stable security definer set search_path = public as $f$
declare e profiles; ob branches := _un_office(p_gov);
begin
  if p_want is not null then
    select * into e from profiles where id = p_want and role = 'union_eng' and org_id = _un_org() and not coalesce(disabled, false);
    if e.id is null then raise exception 'المهندس غير موجود في الاتحاد'; end if;
    return e;
  end if;
  select p.* into e from profiles p where p.role = 'union_eng' and p.org_id = _un_org() and not coalesce(p.disabled, false)
    and (p.away_until is null or p.away_until <= now())
  order by coalesce(ob.id is not null and p.branch_id = ob.id, false) desc, (p.branch_id is null) desc, (p.governorate is not distinct from p_gov) desc,
    (select count(*) from union_files f where f.engineer_id = p.id and f.status = 'inspection'), p.created_at limit 1;
  if e.id is null then
    select p.* into e from profiles p where p.role = 'union_eng' and p.org_id = _un_org() and not coalesce(p.disabled, false)
    order by (select count(*) from union_files f where f.engineer_id = p.id and f.status = 'inspection'), p.created_at limit 1;
  end if;
  return e;
end $f$;

-- إشعار أدوار في مكتب المحافظة (وإن لم يوجد فيه أحد: المقر العام، ثم إشعار عام للجهة)
create or replace function public._un_notify_gov(p_roles text[], p_gov text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path = public as $f$
declare o uuid := _un_org(); ob branches := _un_office(p_gov); n int := 0;
begin
  if o is null then return; end if;
  if ob.id is not null then
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
    select o, p.id, 'union', 'union', p_title, p_body, p_ref from profiles p
    where p.org_id = o and p.role = any(p_roles) and p.branch_id = ob.id and not coalesce(p.disabled, false);
    get diagnostics n = row_count;
  end if;
  if n = 0 then
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
    select o, p.id, 'union', 'union', p_title, p_body, p_ref from profiles p
    where p.org_id = o and p.role = any(p_roles) and p.branch_id is null and not coalesce(p.disabled, false);
    get diagnostics n = row_count;
  end if;
  if n = 0 then perform _un_notify(p_roles, p_title, p_body, p_ref); end if;
end $f$;

-- ───────── 3) أدوات العضوية ─────────
create or replace function public._un_status_label(s text) returns text language sql immutable as $f$
  select case s when 'draft' then 'مسودة — لم تُقدَّم بعد' when 'new' then 'وارد — قسم العضوية والتسجيل' when 'returned' then 'أُعيد للصناعي لاستكمال النواقص'
    when 'inspection' then 'الكشف الموقعي' when 'committee' then 'لجنة الصنف' when 'signing' then 'بانتظار قرار الأمين العام' when 'issued' then 'صدر الكتاب'
    when 'delivered' then 'استلمه المصرف' when 'done' then 'أُنجز' when 'rejected' then 'مرفوض' when 'cancelled' then 'ملغى' else s end $f$;
create or replace function public._un_kind_label(k text) returns text language sql immutable as $f$
  select case k when 'membership' then 'انتماء وهوية صناعية' when 'endorse' then 'تأييد صناعي لقرض' when 'install' then 'تأييد نصب المكائن'
    when 'production' then 'تأييد بدء الإنتاج' when 'followup' then 'كشف متابعة' when 'renewal' then 'تجديد الهوية الصناعية'
    when 'update' then 'تحديث بيانات المنتسب' when 'certificate' then 'كتاب تأييد عضوية' when 'replace' then 'بدل ضائع أو تالف للهوية'
    when 'cancel' then 'إلغاء الانتماء' else k end $f$;

-- مستمسكات المنتسب
create or replace function public._un_doc_label(k text) returns text language sql immutable as $f$
  select case k when 'id_front' then 'البطاقة الوطنية — الوجه' when 'id_back' then 'البطاقة الوطنية — الظهر' when 'id_card' then 'البطاقة الوطنية لصاحب المعمل'
    when 'residence' then 'بطاقة السكن' when 'photo' then 'صورة شخصية حديثة' when 'ind_trade_name' then 'شهادة تسجيل الاسم التجاري لدى غرفة الصناعة'
    when 'ind_lease' then 'عقد إيجار أرض المعمل أو سند ملكيتها' when 'ind_dev_license' then 'إجازة التأسيس من المديرية العامة للتنمية الصناعية'
    when 'factory_photo' then 'صورة واجهة المعمل من الخارج' when 'company_contract' then 'عقد تأسيس الشركة وشهادة تسجيلها'
    when 'env_approval' then 'الموافقة البيئية' when 'machines_list' then 'قائمة المكائن وصورها' when 'other' then 'مستند آخر' end $f$;

-- المستمسكات الإلزامية لطلب الانتساب
create or replace function public._un_req_docs(m union_members) returns text[] language sql immutable as $f$
  select array['id_front','id_back','residence','photo','ind_trade_name','ind_lease','factory_photo']
    || case when coalesce(m.dev_license_no, '') <> '' then array['ind_dev_license'] else array[]::text[] end
    || case when m.legal_form = 'company' then array['company_contract'] else array[]::text[] end $f$;

-- قائمة المستمسكات مع حالة كل منها في المعاملة (أو آخر نسخة لدى المنتسب)
create or replace function public._un_docs_check(p_file uuid) returns jsonb language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(jsonb_build_object('kind', k, 'label', _un_doc_label(k), 'required', k = any(_un_req_docs(m)),
      'doc', (select d.id from union_docs d where d.member_id = m.id and (d.kind = k or (k = 'id_front' and d.kind = 'id_card'))
              and (d.file_id = f.id or d.file_id is null or exists (select 1 from union_files x where x.id = d.file_id and x.status not in ('draft', 'cancelled')))
              order by (d.file_id = f.id) desc, d.created_at desc limit 1),
      'valid_until', (select d.valid_until from union_docs d where d.member_id = m.id and d.kind = k order by d.created_at desc limit 1)) order by ord), '[]'::jsonb)
  from union_files f join union_members m on m.id = f.member_id,
    unnest(array['id_front','id_back','residence','photo','ind_trade_name','ind_lease','ind_dev_license','factory_photo','company_contract','env_approval','machines_list'])
      with ordinality u(k, ord)
  where f.id = p_file and (k = any(_un_req_docs(m)) or k in ('env_approval', 'machines_list')) $f$;

create or replace function public._un_docs_missing(p_file uuid) returns text[] language sql stable security definer set search_path = public as $f$
  select coalesce(array_agg(x->>'label'), '{}') from jsonb_array_elements(_un_docs_check(p_file)) x where (x->>'required')::boolean and x->>'doc' is null $f$;

-- سجل مستمسكات المنتسب: آخر نسخة من كل نوع (عدا المسودات)
create or replace function public._un_member_docs(p_member uuid) returns jsonb language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', coalesce(d.label, _un_doc_label(d.kind)), 'at', d.created_at, 'valid_until', d.valid_until,
      'expired', d.valid_until < current_date) order by d.created_at), '[]'::jsonb)
  from (select distinct on (d.kind) d.* from union_docs d
        where d.member_id = p_member and d.kind <> 'visit_photo'
          and (d.file_id is null or exists (select 1 from union_files x where x.id = d.file_id and x.status not in ('draft', 'cancelled')))
        order by d.kind, d.created_at desc) d $f$;

-- بصمة الهوية — تُحدَّث في كل تغيير مشروع لبياناتها (إصلاح: تجديد الجلسة 52 لم يحدّثها)
create or replace function public._un_seal_of(m union_members) returns text language sql immutable set search_path = public, extensions as $f$
  select encode(extensions.digest(convert_to(jsonb_build_object('code', m.code, 'owner', m.owner_name, 'nid', m.national_id, 'factory', m.factory_name,
    'category', m.category, 'joined', m.joined_at, 'valid', m.valid_until)::text, 'UTF8'), 'sha256'), 'hex') $f$;
create or replace function public._un_reseal(p_id uuid) returns void language plpgsql security definer set search_path = public as $f$
declare m union_members;
begin
  select * into m from union_members where id = p_id;
  if m.code is not null then update union_members set seal = _un_seal_of(m) where id = m.id and seal is distinct from _un_seal_of(m); end if;
end $f$;

-- إصدار كتاب ببصمة ورمز تحقق. إن طلبه المنتسب نفسه (كتاب تأييد عضوية) يصدر آلياً باسم الأمين العام
create or replace function public._un_issue_letter(f union_files, p_title text, p_body jsonb, p_valid date) returns union_letters
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; l union_letters; v_no text; v_code text := _un_vcode(); v_body jsonb; v_n int; v_auto boolean := false;
begin
  select * into me from profiles where id = auth.uid() and portal = 'union';
  if me.id is null then
    v_auto := true;
    select * into me from profiles where org_id = coalesce(f.org_id, _un_org()) and role = 'union_sg' and not coalesce(disabled, false) order by created_at limit 1;
  end if;
  select count(*) + 1 into v_n from union_letters where no like 'IFI/OUT/' || to_char(now(), 'YYYY') || '/%';
  v_no := 'IFI/OUT/' || to_char(now(), 'YYYY') || '/' || lpad(v_n::text, 5, '0');
  v_body := p_body || jsonb_build_object('no', v_no, 'issued_at', now(), 'issuer', me.full_name,
    'issuer_title', _role_title(me.role) || case when v_auto then ' — صدر آلياً من المنصة' else '' end, 'issuer_code', me.staff_code,
    'file', f.code, 'verify', v_code, 'valid_until', p_valid, 'auto', v_auto);
  insert into union_letters(no, file_id, member_id, application_id, bank_id, kind, title, body, sha256, verify_code, issued_by, issued_by_name, issued_by_title, valid_until)
  values (v_no, f.id, f.member_id, f.application_id,
    (select coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid) from applications a where a.id = f.application_id),
    f.kind, p_title, v_body, encode(extensions.digest(convert_to(v_body::text, 'UTF8'), 'sha256'), 'hex'), v_code, me.id, me.full_name,
    _role_title(me.role) || case when v_auto then ' — صدر آلياً' else '' end, p_valid)
  returning * into l;
  perform _un_log(f.id, f.member_id, l.id, 'إصدار الكتاب ' || v_no, p_title);
  return l;
end $f$;

-- فتح المعاملة: الوارد يصل قسم العضوية في مكتب محافظة المعمل (والأمين العام)، والمسودة لا تصل أحداً
create or replace function public._un_new_file(p_kind text, p_member uuid, p_app uuid, p_status text, p_amount bigint, p_fee bigint, p_origin text, p_note text, p_eng uuid)
returns union_files language plpgsql security definer set search_path = public as $f$
declare f union_files; e profiles; m union_members;
begin
  select * into m from union_members where id = p_member;
  if p_status = 'inspection' then e := _un_pick_eng(m.governorate, p_eng); end if;
  insert into union_files(code, org_id, kind, member_id, application_id, status, engineer_id, engineer_name, amount, fee, origin, note, due_at, created_by_name, closed_at)
  values (_vet_seq('UF', 'union_files', 'code'), coalesce(_un_org(), m.org_id), p_kind, p_member, p_app, p_status, e.id, e.full_name, p_amount, coalesce(p_fee, 0), p_origin, p_note,
    case when p_kind = 'production' then now() + make_interval(days => coalesce(_setting('union_prod_days'), 90)::int)
         else now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int) end,
    coalesce((select full_name from profiles where id = auth.uid()), 'النظام'), case when p_status = 'done' then now() end)
  returning * into f;
  if p_status <> 'draft' then
    perform _un_log(f.id, f.member_id, null, 'فتح معاملة: ' || _un_kind_label(p_kind), coalesce(p_origin, '') || coalesce(' — ' || p_note, ''));
  end if;
  if p_status = 'new' then
    perform _un_notify_gov(array['union_reg'], m.governorate, 'معاملة واردة ' || f.code || ': ' || _un_kind_label(p_kind), m.factory_name || ' — ' || m.governorate, f.id);
    perform _un_notify(array['union_sg'], 'معاملة واردة ' || f.code || ': ' || _un_kind_label(p_kind), m.factory_name || ' — ' || m.governorate, f.id);
  elsif e.id is not null then
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
    values (f.org_id, e.id, 'union', 'union', 'كشف موقعي مسند إليك: ' || f.code, _un_kind_label(p_kind) || ' — ' || m.factory_name || ' · ' || m.governorate, f.id);
  end if;
  return f;
end $f$;

-- مرجع دفع إلكتروني
create or replace function public._un_pay_ref(p_prefix text, p_method text) returns text language sql volatile as $f$
  select p_prefix || '-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)) || ' · ' || p_method $f$;
create or replace function public._un_pay_check(p_method text, p_otp text) returns void language plpgsql stable security definer set search_path = public as $f$
begin
  if coalesce(p_method, '') not in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
end $f$;

-- ───────── 4) تجديد الهوية: الحساب الآلي ─────────
-- mode: auto (فوري) · review (مراجعة قسم العضوية) · inspection (كشف موقعي ثم قرار الأمين العام)
create or replace function public._un_renew_quote(m union_members, p_file uuid default null) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare d int; yrs int; lm int; fee bigint := coalesce(_setting('union_member_fee'), 50000)::bigint; late bigint := 0; mode text := 'auto'; why jsonb := '[]';
  v_lease date; v_new_lease boolean; v_early int := coalesce(_setting('union_renew_early_days'), 60)::int;
  v_grace int := coalesce(_setting('union_renew_grace_days'), 90)::int; v_insp int := coalesce(_setting('union_renew_insp_days'), 365)::int;
begin
  if m.id is null or m.code is null then return jsonb_build_object('allowed', false, 'why', jsonb_build_array('لا هوية صادرة بعد')); end if;
  if m.status = 'suspended' then return jsonb_build_object('allowed', false, 'why', jsonb_build_array('العضوية معلّقة بقرار الأمين العام' || coalesce(': ' || m.reason, '') || ' — راجع الاتحاد')); end if;
  if m.status = 'cancelled' then return jsonb_build_object('allowed', false, 'why', jsonb_build_array('أُلغي الانتماء — قدّم طلب انتساب جديد')); end if;
  if m.status not in ('approved', 'expired') then return jsonb_build_object('allowed', false, 'why', jsonb_build_array('الهوية ليست صادرة')); end if;
  if exists (select 1 from union_files x where x.member_id = m.id and x.kind = 'renewal' and x.status in ('new', 'returned', 'inspection', 'signing')) then
    return jsonb_build_object('allowed', false, 'pending', true, 'why', jsonb_build_array('لديك طلب تجديد قيد الدراسة في الاتحاد')); end if;
  d := current_date - coalesce(m.valid_until, current_date);
  if d < -v_early then
    return jsonb_build_object('allowed', false, 'early', true, 'valid_until', m.valid_until, 'opens_at', m.valid_until - v_early,
      'why', jsonb_build_array('هويتك نافذة — يُفتح التجديد قبل انتهائها بـ' || v_early || ' يوماً')); end if;
  yrs := case when d <= 0 then 1 else least(1 + floor((d - 1) / 365.0)::int, coalesce(_setting('union_arrears_max_years'), 5)::int) end;
  lm := case when d > 0 then ceil(d / 30.0)::int else 0 end;
  late := least(lm * coalesce(_setting('union_late_fee_month'), 5000)::bigint, coalesce(_setting('union_late_fee_max'), 60000)::bigint);
  if d > v_insp then
    mode := 'inspection'; why := why || jsonb_build_array('انتهت هويتك منذ أكثر من ' || v_insp || ' يوماً — يكشف مهندس الاتحاد على معملك قبل التجديد');
  elsif d > v_grace then
    mode := 'review'; why := why || jsonb_build_array('مضى على انتهاء هويتك أكثر من ' || v_grace || ' يوماً — يراجع قسم العضوية طلبك');
  end if;
  -- عقد الإيجار المسجّل: إن كان منتهياً يُرفع الجديد، ويراجعه قسم العضوية
  select d2.valid_until into v_lease from union_docs d2 where d2.member_id = m.id and d2.kind = 'ind_lease'
    and (d2.file_id is null or d2.file_id = p_file or exists (select 1 from union_files x where x.id = d2.file_id and x.status not in ('draft', 'cancelled')))
    order by d2.created_at desc limit 1;
  v_new_lease := p_file is not null and exists (select 1 from union_docs d2 where d2.file_id = p_file and d2.kind = 'ind_lease');
  if v_new_lease then
    if mode = 'auto' then mode := 'review'; end if;
    why := why || jsonb_build_array('رفعت عقد إيجار جديداً — يطابقه قسم العضوية');
  elsif v_lease is not null and v_lease < current_date then
    if mode = 'auto' then mode := 'review'; end if;
    why := why || jsonb_build_array('عقد إيجار المعمل المسجّل لديك انتهى في ' || v_lease || ' — ارفع العقد الجديد');
  end if;
  return jsonb_build_object('allowed', true, 'mode', mode, 'why', why, 'days_expired', greatest(d, 0), 'days_left', greatest(-d, 0), 'valid_until', m.valid_until,
    'years', yrs, 'fee_year', fee, 'arrears', fee * (yrs - 1), 'late_months', lm, 'late_fee', late, 'total', fee * yrs + late,
    'lease_until', v_lease, 'lease_expired', v_lease < current_date and not coalesce(v_new_lease, false), 'new_lease', coalesce(v_new_lease, false),
    'new_valid', case when d <= 0 then m.valid_until + interval '1 year' else current_date + interval '1 year' end);
end $f$;

-- تطبيق التجديد على الهوية وإغلاق المعاملة
create or replace function public._un_apply_renewal(p_file uuid, p_note text) returns union_members language plpgsql security definer set search_path = public as $f$
declare f union_files; m union_members; me profiles;
begin
  select * into f from union_files where id = p_file;
  select * into me from profiles where id = auth.uid();
  update union_members set status = 'approved', reason = null, renewed_at = now(), reminders = '{}'::jsonb, updated_at = now(),
    valid_until = case when valid_until >= current_date then valid_until + interval '1 year' else current_date + interval '1 year' end
  where id = f.member_id returning * into m;
  perform _un_reseal(m.id);
  update union_files set status = 'done', closed_at = now(), updated_at = now(),
    decision = coalesce(decision, '{}'::jsonb) || jsonb_build_object('result', 'ok', 'note', p_note, 'by', case when me.portal = 'union' then me.full_name else 'آلياً' end, 'at', now(), 'valid_until', m.valid_until)
  where id = f.id;
  perform _un_log(f.id, m.id, null, 'تجديد الهوية الصناعية ' || m.code || ' حتى ' || m.valid_until, p_note);
  perform _un_tell_citizen(m.id, 'جُدّدت هويتك الصناعية ' || m.code, 'نافذة حتى ' || m.valid_until || ' — امسح رمزها للتحقق في أي وقت', f.id);
  return m;
end $f$;

-- تطبيق تحديث البيانات المعتمد
create or replace function public._un_apply_update(p_file uuid, p_note text) returns union_members language plpgsql security definer set search_path = public as $f$
declare f union_files; m union_members; me profiles; c jsonb;
begin
  select * into f from union_files where id = p_file;
  select * into me from profiles where id = auth.uid();
  c := coalesce(f.meta->'changes', '{}'::jsonb);
  update union_members set
    factory_name = coalesce(c->'factory_name'->>'to', factory_name), category = coalesce(c->'category'->>'to', category),
    legal_form = coalesce(c->'legal_form'->>'to', legal_form), governorate = coalesce(c->'governorate'->>'to', governorate),
    city = coalesce(c->'city'->>'to', city), address = coalesce(c->'address'->>'to', address), trade_name_no = coalesce(c->'trade_name_no'->>'to', trade_name_no),
    dev_license_no = coalesce(c->'dev_license_no'->>'to', dev_license_no), dev_license_kind = coalesce(c->'dev_license_kind'->>'to', dev_license_kind),
    site_geo = case when (f.meta->>'needs_insp')::boolean and f.inspection ? 'gps' then f.inspection->'gps' else site_geo end, updated_at = now()
  where id = f.member_id returning * into m;
  perform _un_reseal(m.id);
  update union_files set status = 'done', closed_at = now(), updated_at = now(),
    decision = coalesce(decision, '{}'::jsonb) || jsonb_build_object('result', 'ok', 'note', p_note, 'by', case when me.portal = 'union' then me.full_name else 'آلياً' end, 'at', now()) where id = f.id;
  perform _un_log(f.id, m.id, null, 'اعتماد تحديث بيانات المنتسب', (select string_agg(_un_field_label(k) || ': ' || coalesce(v->>'to', ''), ' · ') from jsonb_each(c) x(k, v)));
  perform _un_tell_citizen(m.id, 'اعتمد الاتحاد تحديث بياناتك', m.factory_name, f.id);
  return m;
end $f$;

create or replace function public._un_field_label(k text) returns text language sql immutable as $f$
  select case k when 'factory_name' then 'اسم المعمل' when 'category' then 'الصنف' when 'legal_form' then 'الشكل القانوني' when 'governorate' then 'المحافظة'
    when 'city' then 'المدينة' when 'address' then 'العنوان' when 'trade_name_no' then 'رقم الاسم التجاري' when 'dev_license_no' then 'رقم إجازة التنمية'
    when 'dev_license_kind' then 'نوع الإجازة' when 'phone' then 'الهاتف' when 'products' then 'المنتجات' when 'capacity' then 'الطاقة الإنتاجية'
    when 'workers' then 'العاملون' when 'capital' then 'رأس المال' else k end $f$;

-- ───────── 5) التذكير الآلي وانتهاء الهويات ─────────
create or replace function public._un_scan() returns void language plpgsql security definer set search_path = public as $f$
declare m record; v_days int := coalesce(_setting('union_remind_days'), 30)::int; v_grace int := coalesce(_setting('union_renew_grace_days'), 90)::int; k text;
begin
  update union_members set status = 'expired', updated_at = now() where status = 'approved' and valid_until < current_date;
  for m in select * from union_members where code is not null and citizen_id is not null and status in ('approved', 'expired') loop
    k := null;
    if m.status = 'approved' and m.valid_until <= current_date + v_days and not (m.reminders ? ('pre:' || m.valid_until)) then
      k := 'pre:' || m.valid_until;
      perform _un_tell_citizen(m.id, 'تنتهي هويتك الصناعية ' || m.code || ' في ' || m.valid_until, 'جدّدها من هاتفك الآن بدقيقة — صفحة «اتحاد الصناعات» ← «جدّد هويتي»', m.id);
    elsif m.status = 'expired' and not (m.reminders ? ('exp:' || m.valid_until)) then
      k := 'exp:' || m.valid_until;
      perform _un_tell_citizen(m.id, 'انتهت هويتك الصناعية ' || m.code, 'جدّدها خلال ' || v_grace || ' يوماً من انتهائها فيتم التجديد فوراً دون مراجعة', m.id);
    elsif m.status = 'expired' and current_date - m.valid_until between v_grace - 14 and v_grace and not (m.reminders ? ('grace:' || m.valid_until)) then
      k := 'grace:' || m.valid_until;
      perform _un_tell_citizen(m.id, 'بقي أقل من أسبوعين للتجديد الفوري لهويتك ' || m.code, 'بعدها يحتاج التجديد مراجعة قسم العضوية', m.id);
    end if;
    if k is not null then update union_members set reminders = reminders || jsonb_build_object(k, now()) where id = m.id; end if;
  end loop;
end $f$;

-- ───────── 6) المنتسب (بوابة المقترض) ─────────
create or replace function public.union_my() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; dr union_files;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'سجّل الدخول'; end if;
  perform set_config('alwah.face_skip', '1', true); perform _un_scan(); perform set_config('alwah.face_skip', '', true);
  select f.* into dr from union_files f join union_members m on m.id = f.member_id where m.citizen_id = me.id and f.kind = 'membership' and f.status = 'draft'
    order by f.created_at desc limit 1;
  return jsonb_build_object(
    'org', (select jsonb_build_object('id', id, 'name', name) from orgs where id = _un_org()),
    'me', jsonb_build_object('name', me.full_name, 'phone', me.phone, 'governorate', me.governorate, 'national_id', me.national_id),
    'fees', jsonb_build_object('member', coalesce(_setting('union_member_fee'), 50000), 'appeal_days', coalesce(_setting('union_appeal_days'), 30),
      'insp', coalesce(_setting('union_insp_min'), 50000), 'cert', coalesce(_setting('union_cert_fee'), 10000), 'replace', coalesce(_setting('union_replace_fee'), 10000),
      'cert_days', coalesce(_setting('union_cert_days'), 30), 'grace', coalesce(_setting('union_renew_grace_days'), 90), 'insp_days', coalesce(_setting('union_renew_insp_days'), 365),
      'late_month', coalesce(_setting('union_late_fee_month'), 5000)),
    'members', coalesce((select jsonb_agg(to_jsonb(m) - 'seal' - 'reminders' - 'old_codes' || jsonb_build_object('category_label', _un_cat_label(m.category),
        'valid', _un_member_ok(m), 'quote', _un_renew_quote(m), 'docs', _un_member_docs(m.id),
        'open_update', exists (select 1 from union_files x where x.member_id = m.id and x.kind = 'update' and x.status in ('new', 'returned', 'inspection', 'signing')),
        'open_cancel', exists (select 1 from union_files x where x.member_id = m.id and x.kind = 'cancel' and x.status in ('new', 'returned', 'signing')))
        order by m.created_at desc) from union_members m where m.citizen_id = me.id and m.status <> 'cancelled'), '[]'),
    'draft', case when dr.id is not null then jsonb_build_object('id', dr.id, 'code', dr.code, 'fee', dr.fee, 'docs', _un_docs_check(dr.id),
        'member', (select to_jsonb(m) - 'seal' - 'reminders' - 'old_codes' from union_members m where m.id = dr.member_id)) end,
    'files', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _un_kind_label(f.kind), 'status', f.status,
        'status_label', _un_status_label(f.status), 'return_note', f.return_note, 'reason', f.decision->>'reason', 'appeal', f.appeal, 'fee', f.fee, 'fee_paid_at', f.fee_paid_at,
        'app', (select code from applications where id = f.application_id), 'application_id', f.application_id, 'updated_at', f.updated_at, 'created_at', f.created_at,
        'meta', f.meta, 'can_appeal', f.status = 'rejected' and f.appeal is null and f.updated_at > now() - make_interval(days => coalesce(_setting('union_appeal_days'), 30)::int),
        'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label)), '[]') from union_docs d where d.file_id = f.id and d.kind <> 'visit_photo'),
        'checklist', case when f.kind = 'membership' and f.status in ('new', 'returned') then _un_docs_check(f.id) end)
        order by f.created_at desc) from union_files f join union_members m on m.id = f.member_id where m.citizen_id = me.id and f.status <> 'draft'), '[]'),
    'letters', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'no', l.no, 'kind', l.kind, 'title', l.title, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
        'verify_code', l.verify_code, 'revoked_at', l.revoked_at, 'revoke_reason', l.revoke_reason, 'ack_at', l.ack_at, 'body', l.body, 'sha256', l.sha256) order by l.issued_at desc)
        from union_letters l join union_members m on m.id = l.member_id where m.citizen_id = me.id), '[]'));
end $f$;

-- طلب الانتساب — الخطوة 1: بيانات المعمل (مسودة لا تصل الاتحاد قبل رفع المستمسكات والدفع)
create or replace function public.union_member_draft(p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; v_cat text := p->>'category'; v_lf text := coalesce(nullif(p->>'legal_form', ''), 'individual'); v_geo jsonb := p->'site_geo';
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'citizen' then raise exception 'التقديم من بوابة المقترض'; end if;
  if _un_org() is null then raise exception 'اتحاد الصناعات غير مضاف إلى المنصة بعد'; end if;
  if exists (select 1 from union_members where citizen_id = me.id and status = 'approved' and valid_until >= current_date) then raise exception 'لديك هوية صناعية نافذة'; end if;
  if exists (select 1 from union_files uf join union_members x on x.id = uf.member_id where x.citizen_id = me.id and uf.kind in ('membership', 'endorse')
     and uf.status in ('new', 'returned', 'inspection', 'committee', 'signing')) then raise exception 'لديك معاملة انتماء قيد الدراسة — تابعها من هذه الصفحة'; end if;
  if _un_cat_label(v_cat) is null then raise exception 'اختر صنف الصناعة'; end if;
  if v_lf not in ('individual', 'company') then raise exception 'اختر: فرد أم شركة'; end if;
  if length(trim(coalesce(p->>'factory_name', ''))) < 3 then raise exception 'اكتب اسم المعمل'; end if;
  if length(trim(coalesce(p->>'products', ''))) < 3 then raise exception 'اكتب المنتجات'; end if;
  if length(trim(coalesce(p->>'trade_name_no', ''))) < 2 then raise exception 'اكتب رقم تسجيل الاسم التجاري لدى غرفة الصناعة (شرط الانتماء)'; end if;
  if coalesce(p->>'governorate', '') = '' then raise exception 'اختر محافظة المعمل'; end if;
  if length(trim(coalesce(p->>'address', ''))) < 4 then raise exception 'اكتب عنوان المعمل'; end if;
  if v_geo is not null and jsonb_typeof(v_geo) = 'object' and (v_geo->>'lat') is not null then
    v_geo := jsonb_build_object('lat', (v_geo->>'lat')::numeric, 'lng', (v_geo->>'lng')::numeric, 'acc', round(coalesce((v_geo->>'acc')::numeric, 0)), 'by', 'owner', 'at', now());
  else v_geo := null; end if;
  select f2.* into f from union_files f2 join union_members x on x.id = f2.member_id where x.citizen_id = me.id and f2.kind = 'membership' and f2.status = 'draft'
    order by f2.created_at desc limit 1;
  if f.id is not null then
    update union_members set factory_name = trim(p->>'factory_name'), category = v_cat, legal_form = v_lf, governorate = p->>'governorate',
      city = nullif(trim(coalesce(p->>'city', '')), ''), address = trim(p->>'address'), site_geo = coalesce(v_geo, site_geo),
      trade_name_no = trim(p->>'trade_name_no'), dev_license_no = nullif(trim(coalesce(p->>'dev_license_no', '')), ''), dev_license_kind = nullif(p->>'dev_license_kind', ''),
      capital = nullif(regexp_replace(coalesce(p->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint, workers = nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int,
      products = trim(p->>'products'), capacity = nullif(trim(coalesce(p->>'capacity', '')), ''), phone = coalesce(me.phone, phone), updated_at = now()
    where id = f.member_id returning * into m;
  else
    select * into m from union_members where citizen_id = me.id and status = 'pending' and not exists (select 1 from union_files x where x.member_id = union_members.id and x.status not in ('draft', 'cancelled'))
      order by created_at desc limit 1;
    if m.id is null then
      insert into union_members(org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address, site_geo,
        trade_name_no, dev_license_no, dev_license_kind, capital, workers, products, capacity)
      values (_un_org(), me.id, me.full_name, me.national_id, me.phone, trim(p->>'factory_name'), v_cat, v_lf, p->>'governorate',
        nullif(trim(coalesce(p->>'city', '')), ''), trim(p->>'address'), v_geo, trim(p->>'trade_name_no'), nullif(trim(coalesce(p->>'dev_license_no', '')), ''),
        nullif(p->>'dev_license_kind', ''), nullif(regexp_replace(coalesce(p->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint,
        nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int, trim(p->>'products'), nullif(trim(coalesce(p->>'capacity', '')), ''))
      returning * into m;
    end if;
    f := _un_new_file('membership', m.id, null, 'draft', null,
      coalesce(_setting('union_member_fee'), 50000)::bigint + coalesce(_setting('union_insp_min'), 50000)::bigint, 'طلب انتساب من بوابة المقترض', null, null);
    update union_files set meta = jsonb_build_object('flow', 'v53') where id = f.id returning * into f;
  end if;
  return jsonb_build_object('id', f.id, 'code', f.code, 'member', m.id, 'fee', f.fee, 'docs', _un_docs_check(f.id));
end $f$;

-- طلب الانتساب — الخطوة الأخيرة: المستمسكات مكتملة ← الدفع ← يصل قسم العضوية في مكتب المحافظة
create or replace function public.union_member_submit(p_file uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f union_files; m union_members; miss text[];
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file for update;
  select * into m from union_members where id = f.member_id;
  if m.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if f.status <> 'draft' or f.kind <> 'membership' then raise exception 'الطلب قُدّم سابقاً'; end if;
  miss := _un_docs_missing(f.id);
  if cardinality(miss) > 0 then raise exception 'ارفع المستمسكات الناقصة: %', array_to_string(miss, '، '); end if;
  if not coalesce((p->>'confirm')::boolean, false) then raise exception 'أقرّ بصحة البيانات والمستمسكات'; end if;
  perform _un_pay_check(p->>'method', p->>'otp');
  update union_files set status = 'new', fee_paid_at = now(), fee_ref = _un_pay_ref('UPAY', p->>'method'), created_at = now(), updated_at = now(),
    due_at = now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int), meta = meta || jsonb_build_object('submitted_at', now(), 'confirm', true)
  where id = f.id returning * into f;
  perform _un_log(f.id, m.id, null, 'تقديم طلب الانتساب مع المستمسكات', 'دفع البدل وأجور الكشف إلكترونياً ' || to_char(f.fee, 'FM999,999,999') || ' د.ع · ' || f.fee_ref);
  perform _un_notify_gov(array['union_reg'], m.governorate, 'طلب انتساب جديد ' || f.code, m.factory_name || ' — ' || m.governorate, f.id);
  perform _un_notify(array['union_sg'], 'طلب انتساب جديد ' || f.code, m.factory_name || ' — ' || m.governorate, f.id);
  perform _un_tell_citizen(m.id, 'وصل طلب انتسابك ' || f.code || ' إلى اتحاد الصناعات', 'سيدققه قسم العضوية ثم يزور مهندس الاتحاد معملك', f.id);
  return jsonb_build_object('ok', true, 'code', f.code, 'ref', f.fee_ref, 'fee', f.fee);
end $f$;

-- حذف مسودة الانتساب
create or replace function public.union_draft_discard(p_file uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f union_files; m union_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file;
  select * into m from union_members where id = f.member_id;
  if m.citizen_id is distinct from me.id or f.status <> 'draft' then raise exception 'لا مسودة لحذفها'; end if;
  update union_files set status = 'cancelled', closed_at = now(), updated_at = now() where id = f.id;
  return jsonb_build_object('ok', true);
end $f$;

-- مستندات المعاملة: الصناعي (مسودة، وارد، أو مُعاد) أو موظف الاتحاد (صور الكشف)
create or replace function public.union_doc_add(p_file uuid, p_kind text, p_data text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; f union_files; m union_members; mime text; sz int := length(coalesce(p_data, '')); did uuid; v_label text; v_until date;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file;
  select * into m from union_members where id = f.member_id;
  if f.id is null then raise exception 'المعاملة غير موجودة'; end if;
  if me.portal = 'union' then
    if p_kind <> 'visit_photo' then raise exception 'يرفع موظف الاتحاد صور الكشف فقط'; end if;
    if f.status <> 'inspection' then raise exception 'صور الكشف أثناء الكشف الموقعي فقط'; end if;
    v_label := 'صورة الكشف الموقعي';
  else
    if m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
    if f.status not in ('draft', 'new', 'returned') then raise exception 'المعاملة لدى الاتحاد الآن — لا يمكن تغيير مستنداتها'; end if;
    if f.status = 'new' and f.kind = 'membership' and coalesce(f.meta->>'flow', '') = 'v53' then raise exception 'قُدّم الطلب — تُغيَّر المستندات إن أعاده الاتحاد للاستكمال'; end if;
    v_label := coalesce(_un_doc_label(p_kind), _bp_doc_label(p_kind));
    if v_label is null or p_kind = 'visit_photo' then raise exception 'نوع مستند غير معروف'; end if;
    v_until := nullif(p_meta->>'valid_until', '')::date;
    if v_until is not null and v_until < current_date then raise exception 'المستند منتهي الصلاحية (%) — ارفع النسخة النافذة', v_until; end if;
    delete from union_docs where file_id = f.id and kind = p_kind;
  end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg', 'image/png', 'application/pdf') then raise exception 'صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  insert into union_docs(file_id, member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name, valid_until)
  values (f.id, f.member_id, p_kind, v_label, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'), coalesce(p_meta, '{}') || jsonb_build_object('server_at', now()),
    me.id, me.full_name, v_until)
  returning id into did;
  return did;
end $f$;

-- ───────── 7) خدمات المنتسب ─────────
-- التجديد — فتح الطلب (مسودة يُرفع فيها عقد الإيجار الجديد إن لزم) مع الحساب
create or replace function public.union_renew_start(p_member uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; q jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into m from union_members where id = p_member;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  select * into f from union_files where member_id = m.id and kind = 'renewal' and status = 'draft' order by created_at desc limit 1;
  q := _un_renew_quote(m, f.id);
  if not (q->>'allowed')::boolean then return jsonb_build_object('quote', q); end if;
  if f.id is null then
    f := _un_new_file('renewal', m.id, null, 'draft', null, (q->>'total')::bigint, 'طلب تجديد من بوابة المقترض', null, null);
  end if;
  update union_files set fee = (q->>'total')::bigint, meta = jsonb_build_object('quote', q, 'mode', q->>'mode') where id = f.id;
  return jsonb_build_object('file', f.id, 'code', f.code, 'quote', q,
    'lease', (select jsonb_build_object('id', d.id, 'valid_until', d.valid_until) from union_docs d where d.file_id = f.id and d.kind = 'ind_lease' limit 1));
end $f$;

-- التجديد — الدفع: فوري، أو إلى قسم العضوية، أو إلى الكشف الموقعي
create or replace function public.union_renew_submit(p_file uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f union_files; m union_members; q jsonb; v_mode text;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file for update;
  select * into m from union_members where id = f.member_id for update;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if f.kind <> 'renewal' or f.status <> 'draft' then raise exception 'طلب التجديد قُدّم سابقاً'; end if;
  q := _un_renew_quote(m, f.id);
  if not (q->>'allowed')::boolean then raise exception '%', q->'why'->>0; end if;
  if (q->>'lease_expired')::boolean then raise exception 'عقد إيجار المعمل منتهٍ — ارفع العقد الجديد أولاً'; end if;
  if not coalesce((p->>'confirm')::boolean, false) then raise exception 'أقرّ بأن بيانات المعمل لم تتغير (أو حدّثها أولاً)'; end if;
  perform _un_pay_check(p->>'method', p->>'otp');
  v_mode := q->>'mode';
  update union_files set fee = (q->>'total')::bigint, fee_paid_at = now(), fee_ref = _un_pay_ref('UREN', p->>'method'), created_at = now(), updated_at = now(),
    meta = jsonb_build_object('quote', q, 'mode', v_mode, 'confirm', true), status = case when v_mode = 'auto' then 'new' else 'new' end,
    due_at = now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int)
  where id = f.id returning * into f;
  perform _un_log(f.id, m.id, null, 'طلب تجديد الهوية ودفع ' || to_char(f.fee, 'FM999,999,999') || ' د.ع',
    'بدل ' || (q->>'years') || ' سنة' || case when (q->>'late_fee')::bigint > 0 then ' + غرامة تأخير ' || to_char((q->>'late_fee')::bigint, 'FM999,999') || ' د.ع' else '' end || ' · ' || f.fee_ref);
  if v_mode = 'auto' then
    m := _un_apply_renewal(f.id, 'تجديد فوري آلي — الهوية ضمن مهلة التجديد وبياناتها لم تتغير');
    return jsonb_build_object('ok', true, 'mode', 'auto', 'valid_until', m.valid_until, 'code', f.code, 'ref', f.fee_ref);
  end if;
  perform _un_notify_gov(array['union_reg'], m.governorate, 'طلب تجديد هوية ' || f.code || case when v_mode = 'inspection' then ' — يتطلب كشفاً' else '' end, m.factory_name || ' · ' || m.code, f.id);
  perform _un_tell_citizen(m.id, 'وصل طلب تجديد هويتك ' || f.code, case when v_mode = 'inspection' then 'سيزور مهندس الاتحاد معملك قبل التجديد' else 'يراجعه قسم العضوية خلال ' || coalesce(_setting('union_sla_days'), 7) || ' أيام' end, f.id);
  return jsonb_build_object('ok', true, 'mode', v_mode, 'code', f.code, 'ref', f.fee_ref);
end $f$;

-- التوافق مع الجلسة 52: التجديد المباشر (للفوري فقط)
create or replace function public.union_renew(p_member uuid, p_method text, p_otp text) returns union_members language plpgsql security definer set search_path = public as $f$
declare r jsonb; m union_members;
begin
  r := union_renew_start(p_member);
  if r->>'file' is null then raise exception '%', r->'quote'->'why'->>0; end if;
  if r->'quote'->>'mode' <> 'auto' then raise exception 'هذا التجديد يحتاج مراجعة — حدّث الصفحة وقدّمه من «جدّد هويتي»'; end if;
  perform union_renew_submit((r->>'file')::uuid, jsonb_build_object('method', p_method, 'otp', p_otp, 'confirm', true));
  select * into m from union_members where id = p_member;
  return m;
end $f$;

-- تحديث البيانات: البسيطة تُطبَّق فوراً، والجوهرية تمر بقسم العضوية (والنقل بكشف، والاسم والصنف بقرار الأمين العام)
create or replace function public.union_update_request(p_member uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; c jsonb := '{}'; applied text[] := '{}'; k text; v_new text; v_old text; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  select * into me from profiles where id = auth.uid();
  select * into m from union_members where id = p_member for update;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if m.status not in ('approved', 'expired') or m.code is null then raise exception 'تحديث البيانات للهويات الصادرة'; end if;
  -- البسيطة
  if p ? 'products' and length(trim(p->>'products')) >= 3 and trim(p->>'products') is distinct from m.products then applied := array_append(applied, 'products'); end if;
  if p ? 'capacity' and nullif(trim(p->>'capacity'), '') is distinct from m.capacity then applied := array_append(applied, 'capacity'); end if;
  if p ? 'workers' and nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int is distinct from m.workers then applied := array_append(applied, 'workers'); end if;
  if p ? 'capital' and nullif(regexp_replace(coalesce(p->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint is distinct from m.capital then applied := array_append(applied, 'capital'); end if;
  if cardinality(applied) > 0 then
    update union_members set products = case when 'products' = any(applied) then trim(p->>'products') else products end,
      capacity = case when 'capacity' = any(applied) then nullif(trim(p->>'capacity'), '') else capacity end,
      workers = case when 'workers' = any(applied) then nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int else workers end,
      capital = case when 'capital' = any(applied) then nullif(regexp_replace(coalesce(p->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint else capital end, updated_at = now()
    where id = m.id;
    perform _un_log(null, m.id, null, 'تحديث بيانات من المنتسب (فوري)', (select string_agg(_un_field_label(x), '، ') from unnest(applied) x));
  end if;
  -- الجوهرية
  foreach k in array array['factory_name','category','legal_form','governorate','city','address','trade_name_no','dev_license_no','dev_license_kind'] loop
    if p ? k then
      v_new := nullif(trim(p->>k), ''); v_old := to_jsonb(m)->>k;
      if v_new is not null and v_new is distinct from v_old then c := c || jsonb_build_object(k, jsonb_build_object('from', v_old, 'to', v_new)); end if;
    end if;
  end loop;
  if c ? 'category' and _un_cat_label(c->'category'->>'to') is null then raise exception 'صنف غير معروف'; end if;
  if c ? 'legal_form' and c->'legal_form'->>'to' not in ('individual', 'company') then raise exception 'الشكل القانوني غير معروف'; end if;
  if c ? 'dev_license_kind' and c->'dev_license_kind'->>'to' not in ('under', 'complete') then raise exception 'نوع الإجازة غير معروف'; end if;
  if c = '{}'::jsonb then
    if cardinality(applied) = 0 then raise exception 'لم تغيّر شيئاً'; end if;
    return jsonb_build_object('ok', true, 'applied', to_jsonb(applied));
  end if;
  if exists (select 1 from union_files x where x.member_id = m.id and x.kind = 'update' and x.status in ('new', 'returned', 'inspection', 'signing')) then
    raise exception 'لديك طلب تحديث قيد الدراسة — انتظر قراره'; end if;
  f := _un_new_file('update', m.id, null, 'new', null, 0, 'طلب تحديث بيانات من المنتسب', v_note, null);
  update union_files set meta = jsonb_build_object('changes', c,
      'needs_insp', c ?| array['governorate', 'city', 'address'], 'needs_sg', c ?| array['factory_name', 'category', 'legal_form'])
  where id = f.id returning * into f;
  perform _un_tell_citizen(m.id, 'وصل طلب تحديث بياناتك ' || f.code, case when (f.meta->>'needs_insp')::boolean then 'نقل المعمل يتطلب كشفاً موقعياً على العنوان الجديد' else 'يراجعه قسم العضوية' end, f.id);
  return jsonb_build_object('ok', true, 'applied', to_jsonb(applied), 'file', f.code, 'id', f.id, 'needs_insp', f.meta->'needs_insp');
end $f$;

-- كتاب تأييد عضوية: يصدر فوراً لأي جهة ما دامت الهوية نافذة
create or replace function public.union_cert_request(p_member uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; l union_letters; v_to text := trim(coalesce(p->>'to', '')); v_for text := trim(coalesce(p->>'purpose', ''));
  v_fee bigint := coalesce(_setting('union_cert_fee'), 10000)::bigint; v_valid date;
begin
  select * into me from profiles where id = auth.uid();
  perform set_config('alwah.face_skip', '1', true); perform _un_scan(); perform set_config('alwah.face_skip', '', true);
  select * into m from union_members where id = p_member;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if not _un_member_ok(m) then raise exception 'هويتك غير نافذة — جدّدها أولاً ثم اطلب الكتاب'; end if;
  if length(v_to) < 3 then raise exception 'اكتب الجهة التي يُوجَّه إليها الكتاب'; end if;
  if length(v_for) < 3 then raise exception 'اكتب الغرض من الكتاب'; end if;
  if v_fee > 0 then perform _un_pay_check(p->>'method', p->>'otp'); end if;
  f := _un_new_file('certificate', m.id, null, 'done', null, v_fee, 'طلب كتاب تأييد عضوية من المنتسب', v_to || ' — ' || v_for, null);
  update union_files set fee_paid_at = case when v_fee > 0 then now() end, fee_ref = case when v_fee > 0 then _un_pay_ref('UCRT', p->>'method') end,
    meta = jsonb_build_object('to', v_to, 'purpose', v_for), decision = jsonb_build_object('result', 'ok', 'by', 'آلياً', 'at', now()) where id = f.id returning * into f;
  v_valid := least(m.valid_until, current_date + coalesce(_setting('union_cert_days'), 30)::int);
  l := _un_issue_letter(f, 'كتاب تأييد عضوية — إلى ' || v_to, jsonb_build_object('kind', 'certificate', 'member', m.code, 'member_valid', m.valid_until,
    'owner', m.owner_name, 'factory', m.factory_name, 'category', _un_cat_label(m.category), 'governorate', m.governorate, 'address', m.address,
    'joined', m.joined_at, 'to', v_to, 'purpose', v_for, 'products', m.products, 'trade_name', m.trade_name_no,
    'statement', 'يؤيد اتحاد الصناعات العراقي أن ' || m.owner_name || ' صاحب «' || m.factory_name || '» منتمٍ إلى الاتحاد بالهوية الصناعية ' || m.code
      || ' النافذة حتى ' || m.valid_until || '، ضمن ' || _un_cat_label(m.category) || '. زُوّد بهذا الكتاب بناءً على طلبه لتقديمه إلى ' || v_to
      || ' لغرض ' || v_for || '، ولا يترتب على الاتحاد أي التزام تجاه الغير.'), v_valid);
  update union_files set decision = decision || jsonb_build_object('letter', l.no) where id = f.id;
  perform _un_log(f.id, m.id, l.id, 'إصدار كتاب تأييد عضوية آلياً', v_to || ' — ' || v_for || coalesce(' · ' || f.fee_ref, ''));
  return jsonb_build_object('ok', true, 'letter', to_jsonb(l), 'code', f.code);
end $f$;

-- بدل ضائع أو تالف: رمز تحقق جديد، والرمز القديم يُبطَل
create or replace function public.union_card_replace(p_member uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; v_fee bigint := coalesce(_setting('union_replace_fee'), 10000)::bigint; v_old text;
begin
  select * into me from profiles where id = auth.uid();
  select * into m from union_members where id = p_member for update;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if m.code is null or m.status not in ('approved', 'expired') then raise exception 'البدل للهويات الصادرة'; end if;
  if coalesce(p->>'reason', '') not in ('lost', 'damaged', 'stolen') then raise exception 'اختر السبب'; end if;
  if v_fee > 0 then perform _un_pay_check(p->>'method', p->>'otp'); end if;
  v_old := m.verify_code;
  update union_members set old_codes = array_append(old_codes, coalesce(v_old, '')), verify_code = _un_vcode(), card_version = card_version + 1, updated_at = now()
  where id = m.id returning * into m;
  f := _un_new_file('replace', m.id, null, 'done', null, v_fee, 'بدل ' || case p->>'reason' when 'lost' then 'ضائع' when 'stolen' then 'مسروق' else 'تالف' end || ' من المنتسب', null, null);
  update union_files set fee_paid_at = case when v_fee > 0 then now() end, fee_ref = case when v_fee > 0 then _un_pay_ref('UREP', p->>'method') end,
    meta = jsonb_build_object('reason', p->>'reason', 'old_code', v_old, 'version', m.card_version), decision = jsonb_build_object('result', 'ok', 'by', 'آلياً', 'at', now()) where id = f.id;
  perform _un_log(f.id, m.id, null, 'إصدار نسخة ' || m.card_version || ' من الهوية ' || m.code || ' وإبطال الرمز السابق', v_old);
  return jsonb_build_object('ok', true, 'version', m.card_version, 'verify_code', m.verify_code);
end $f$;

-- إلغاء الانتماء بطلب المنتسب (قرار الأمين العام، وكتاب براءة ذمة)
create or replace function public.union_cancel_request(p_member uuid, p_note text) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files;
begin
  select * into me from profiles where id = auth.uid();
  select * into m from union_members where id = p_member;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if m.code is null or m.status in ('cancelled', 'rejected', 'pending') then raise exception 'لا عضوية لإلغائها'; end if;
  if length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب سبب الإلغاء'; end if;
  if exists (select 1 from union_files x where x.member_id = m.id and x.kind in ('endorse', 'install', 'production', 'followup') and x.status in ('new', 'returned', 'inspection', 'committee', 'signing', 'issued')) then
    raise exception 'لديك معاملة قرض صناعي قائمة لدى الاتحاد — لا يُلغى الانتماء قبل إنجازها'; end if;
  if exists (select 1 from applications a where a.citizen_id = me.id and a.program = 'industrial' and a.status = 'active' and a.biz->>'member_id' = m.id::text) then
    raise exception 'لديك قرض صناعي قائم مرتبط بهويتك — لا يُلغى الانتماء قبل تسديده'; end if;
  if exists (select 1 from union_files x where x.member_id = m.id and x.kind = 'cancel' and x.status in ('new', 'returned', 'signing')) then raise exception 'طلب الإلغاء قُدّم سابقاً'; end if;
  f := _un_new_file('cancel', m.id, null, 'new', null, 0, 'طلب إلغاء الانتماء من المنتسب', trim(p_note), null);
  return jsonb_build_object('ok', true, 'code', f.code);
end $f$;

-- ───────── 8) بوابة الاتحاد ─────────
create or replace function public._un_file_row(f union_files) returns jsonb language sql stable security definer set search_path = public as $f$
  select jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _un_kind_label(f.kind), 'status', f.status, 'status_label', _un_status_label(f.status),
    'engineer_id', f.engineer_id, 'engineer', f.engineer_name, 'amount', f.amount, 'fee', f.fee, 'fee_paid_at', f.fee_paid_at, 'due_at', f.due_at,
    'late', f.status in ('new', 'inspection', 'committee', 'signing') and f.due_at < now(), 'appeal', f.appeal is not null, 'new_member', f.note = 'new_member',
    'created_at', f.created_at, 'updated_at', f.updated_at, 'result', f.decision->>'result', 'mode', f.meta->>'mode',
    'member', jsonb_build_object('id', m.id, 'code', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', m.category, 'category_label', _un_cat_label(m.category),
      'governorate', m.governorate, 'status', m.status),
    'app', case when a.id is not null then jsonb_build_object('id', a.id, 'code', a.code, 'stage', a.stage, 'status', a.status,
      'bank', (select name from orgs where id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid))) end)
  from union_members m left join applications a on a.id = f.application_id where m.id = f.member_id $f$;

create or replace function public.union_inbox() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); ob branches;
begin
  perform set_config('alwah.face_skip', '1', true); perform _un_scan(); perform set_config('alwah.face_skip', '', true);
  select * into ob from branches where id = me.branch_id;
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'name', me.full_name, 'role', me.role, 'role_title', _role_title(me.role), 'code', me.staff_code, 'governorate', me.governorate,
      'manage', me.manage_scope, 'office', ob.name, 'govs', case when ob.id is not null then to_jsonb(coalesce(ob.governorates, '{}')) end),
    'org', (select jsonb_build_object('id', id, 'name', name, 'code', code) from orgs where id = me.org_id),
    'office_govs', (select coalesce(jsonb_agg(distinct g), '[]') from branches b, unnest(coalesce(b.governorates, '{}')) g where b.bank_id = me.org_id),
    'files', coalesce((select jsonb_agg(_un_file_row(f) order by f.updated_at desc) from union_files f where f.org_id = me.org_id and f.status <> 'draft'
      and not (f.status = 'cancelled' and f.kind in ('membership', 'renewal') and f.fee_paid_at is null)), '[]'),
    'members', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'code', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', m.category,
        'category_label', _un_cat_label(m.category), 'governorate', m.governorate, 'status', m.status, 'valid_until', m.valid_until, 'joined_at', m.joined_at,
        'workers', m.workers, 'dev_license_kind', m.dev_license_kind, 'phone', m.phone,
        'expiring', m.status = 'approved' and m.valid_until <= current_date + coalesce(_setting('union_remind_days'), 30)::int)
        order by m.code nulls last, m.created_at desc) from union_members m where m.org_id = me.org_id
        and (m.code is not null or exists (select 1 from union_files x where x.member_id = m.id and x.status <> 'draft'
          and not (x.kind = 'membership' and x.status = 'cancelled' and x.fee_paid_at is null)))), '[]'),
    'engineers', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'governorate', p.governorate,
        'office', (select name from branches where id = p.branch_id), 'away', p.away_until > now(),
        'open', (select count(*) from union_files f where f.engineer_id = p.id and f.status = 'inspection')) order by p.full_name)
        from profiles p where p.org_id = me.org_id and p.role = 'union_eng' and not coalesce(p.disabled, false)), '[]'),
    'fees', jsonb_build_object(
      'paid', (select coalesce(sum(fee), 0) from union_files where org_id = me.org_id and fee_paid_at is not null),
      'due', (select coalesce(sum(fee), 0) from union_files where org_id = me.org_id and fee_paid_at is null and fee > 0 and status not in ('cancelled', 'rejected', 'draft')),
      'month', (select coalesce(sum(fee), 0) from union_files where org_id = me.org_id and fee_paid_at >= date_trunc('month', now())),
      'by_kind', (select coalesce(jsonb_object_agg(k, s), '{}') from (select kind k, sum(fee) s from union_files where org_id = me.org_id and fee_paid_at is not null group by kind) z),
      'rows', coalesce((select jsonb_agg(jsonb_build_object('code', f.code, 'kind', _un_kind_label(f.kind), 'factory', m.factory_name, 'fee', f.fee, 'paid_at', f.fee_paid_at, 'ref', f.fee_ref)
        order by coalesce(f.fee_paid_at, f.created_at) desc) from union_files f join union_members m on m.id = f.member_id where f.org_id = me.org_id and f.fee > 0 and f.status <> 'draft'
        and not (f.status = 'cancelled' and f.fee_paid_at is null)), '[]')),
    'team', case when me.role = 'union_sg' then jsonb_build_object('ready', _org_readiness(me.org_id),
      'offices', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'govs', to_jsonb(coalesce(b.governorates, '{}')),
          'staff', (select coalesce(jsonb_agg(jsonb_build_object('name', p.full_name, 'role', p.role, 'title', _role_title(p.role)) order by p.role), '[]') from profiles p
            where p.branch_id = b.id and not coalesce(p.disabled, false))) order by b.code) from branches b where b.bank_id = me.org_id), '[]'),
      'hq', (select coalesce(jsonb_agg(jsonb_build_object('name', p.full_name, 'role', p.role, 'title', _role_title(p.role), 'away', p.away_until > now(),
          'pending_pw', p.must_change_password) order by p.role), '[]') from profiles p where p.org_id = me.org_id and p.branch_id is null and not coalesce(p.disabled, false))) end,
    'settings', jsonb_build_object('member_fee', _setting('union_member_fee'), 'insp_pct', _setting('union_insp_pct'), 'insp_min', _setting('union_insp_min'),
      'insp_max', _setting('union_insp_max'), 'sla', _setting('union_sla_days'), 'letter_days', _setting('union_letter_days'), 'prod_days', _setting('union_prod_days'),
      'early', _setting('union_renew_early_days'), 'grace', _setting('union_renew_grace_days'), 'insp_days', _setting('union_renew_insp_days'),
      'late_month', _setting('union_late_fee_month'), 'late_max', _setting('union_late_fee_max'), 'cert_fee', _setting('union_cert_fee'), 'cert_days', _setting('union_cert_days'),
      'replace_fee', _setting('union_replace_fee'), 'remind', _setting('union_remind_days'), 'appeal', _setting('union_appeal_days')));
end $f$;

-- الدالتان القديمتان تصيران داخليتين، والجديدتان تضيفان دورة خدمات المنتسب فوقهما
do $$ begin
  if to_regprocedure('public._union_act52(uuid,jsonb)') is null then alter function public.union_act(uuid, jsonb) rename to _union_act52; end if;
  if to_regprocedure('public._union_file52(uuid)') is null then alter function public.union_file(uuid) rename to _union_file52; end if;
end $$;

create or replace function public.union_file(p_id uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); f union_files; r jsonb; m union_members; v_svc boolean;
begin
  select * into f from union_files where id = p_id;
  if f.id is null or f.org_id <> me.org_id or f.status = 'draft' then raise exception 'المعاملة غير موجودة'; end if;
  select * into m from union_members where id = f.member_id;
  r := _union_file52(p_id);
  v_svc := f.kind in ('renewal', 'update', 'cancel');
  return r || jsonb_build_object('meta', f.meta, 'fee_ref', f.fee_ref, 'note', f.note,
    'checklist', case when f.kind = 'membership' then _un_docs_check(f.id) end,
    'member_docs', _un_member_docs(f.member_id),
    'quote_now', case when f.kind = 'renewal' then _un_renew_quote(m) end,
    'can', (r->'can') || jsonb_build_object(
      'approve', v_svc and f.status = 'new' and me.role in ('union_reg', 'union_sg')
        and not (f.kind = 'renewal' and f.meta->>'mode' = 'inspection' and f.inspection is null)
        and not (f.kind = 'update' and (f.meta->>'needs_insp')::boolean and f.inspection is null),
      'must_inspect', v_svc and f.status = 'new' and ((f.kind = 'renewal' and f.meta->>'mode' = 'inspection') or (f.kind = 'update' and (f.meta->>'needs_insp')::boolean)),
      'docs_missing', case when f.kind = 'membership' and coalesce(f.meta->>'flow', '') = 'v53' then to_jsonb(_un_docs_missing(f.id)) end));
end $f$;

create or replace function public.union_act(p_id uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); f union_files; m union_members; v_act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); l union_letters; miss text[];
begin
  select * into f from union_files where id = p_id for update;
  if f.id is null or f.org_id <> me.org_id or f.status = 'draft' then raise exception 'المعاملة غير موجودة'; end if;
  select * into m from union_members where id = f.member_id;

  -- طلب الانتساب الجديد: لا إحالة للكشف والمستمسكات ناقصة
  if v_act = 'accept' and f.kind = 'membership' and coalesce(f.meta->>'flow', '') = 'v53' then
    miss := _un_docs_missing(f.id);
    if cardinality(miss) > 0 then raise exception 'المستمسكات ناقصة: % — أعد الطلب للصناعي', array_to_string(miss, '، '); end if;
  end if;

  -- قسم العضوية: اعتماد طلبات الخدمة (تجديد بمراجعة، تحديث بيانات، إلغاء انتماء)
  if v_act = 'approve' then
    if f.kind not in ('renewal', 'update', 'cancel') then raise exception 'هذه المعاملة تُحال للكشف'; end if;
    if f.status <> 'new' then raise exception 'المعاملة ليست في الوارد'; end if;
    if me.role not in ('union_reg', 'union_sg') then raise exception 'الاعتماد لقسم العضوية والتسجيل'; end if;
    if f.kind = 'renewal' then
      if f.meta->>'mode' = 'inspection' and f.inspection is null then raise exception 'الهوية منتهية منذ أكثر من سنة — أحِلها للكشف الموقعي أولاً'; end if;
      m := _un_apply_renewal(f.id, coalesce(v_note, 'اعتمده قسم العضوية بعد المراجعة'));
      return jsonb_build_object('ok', true, 'member', m.code, 'valid_until', m.valid_until);
    elsif f.kind = 'update' then
      if (f.meta->>'needs_insp')::boolean and f.inspection is null then raise exception 'نقل المعمل يتطلب كشفاً على العنوان الجديد — أحِله للمهندس'; end if;
      if (f.meta->>'needs_sg')::boolean then
        update union_files set status = 'signing', updated_at = now() where id = f.id;
        perform _un_log(f.id, m.id, null, 'دقق قسم العضوية التحديث ورفعه للأمين العام', v_note);
        perform _un_notify(array['union_sg'], 'بانتظار قرارك: ' || f.code, m.factory_name || ' — تحديث بيانات', f.id);
        return jsonb_build_object('ok', true, 'next', 'signing');
      end if;
      m := _un_apply_update(f.id, coalesce(v_note, 'اعتمده قسم العضوية'));
      return jsonb_build_object('ok', true, 'member', m.code);
    else
      update union_files set status = 'signing', updated_at = now() where id = f.id;
      perform _un_log(f.id, m.id, null, 'دقق قسم العضوية طلب الإلغاء ورفعه للأمين العام', v_note);
      perform _un_notify(array['union_sg'], 'بانتظار قرارك: ' || f.code, m.factory_name || ' — إلغاء انتماء', f.id);
      return jsonb_build_object('ok', true, 'next', 'signing');
    end if;
  end if;

  -- الأمين العام: قرار طلبات الخدمة
  if v_act = 'issue' and f.kind in ('renewal', 'update', 'cancel') then
    if f.status <> 'signing' or me.role <> 'union_sg' then raise exception 'القرار للأمين العام'; end if;
    if coalesce(p->>'confirm', '') <> 'أوافق' then raise exception 'اكتب «أوافق» لتأكيد القرار'; end if;
    if f.kind = 'renewal' then
      m := _un_apply_renewal(f.id, coalesce(v_note, 'قرار الأمين العام بعد الكشف'));
      return jsonb_build_object('ok', true, 'member', m.code, 'valid_until', m.valid_until);
    elsif f.kind = 'update' then
      m := _un_apply_update(f.id, coalesce(v_note, 'قرار الأمين العام'));
      return jsonb_build_object('ok', true, 'member', m.code);
    end if;
    update union_members set status = 'cancelled', reason = 'إلغاء الانتماء بطلب المنتسب' || coalesce(' — ' || v_note, ''), decided_by_name = me.full_name, decided_at = now(), updated_at = now()
    where id = m.id returning * into m;
    l := _un_issue_letter(f, 'كتاب إلغاء الانتماء وبراءة الذمة — ' || m.factory_name, jsonb_build_object('kind', 'cancel', 'member', m.code, 'owner', m.owner_name,
      'factory', m.factory_name, 'category', _un_cat_label(m.category), 'governorate', m.governorate, 'joined', m.joined_at,
      'statement', 'يؤيد اتحاد الصناعات العراقي إلغاء انتماء ' || m.owner_name || ' صاحب «' || m.factory_name || '» (الهوية ' || m.code || ') بناءً على طلبه، '
        || 'وأنه بريء الذمة تجاه الاتحاد من تاريخه، والهوية الصناعية المذكورة لم تعد نافذة.'), null);
    update union_files set status = 'done', closed_at = now(), updated_at = now(),
      decision = jsonb_build_object('result', 'ok', 'note', v_note, 'by', me.full_name, 'at', now(), 'letter', l.no) where id = f.id;
    perform _un_tell_citizen(m.id, 'أُلغي انتماؤك لاتحاد الصناعات', 'كتاب براءة الذمة ' || l.no || ' في صفحة «اتحاد الصناعات»', f.id);
    return jsonb_build_object('ok', true, 'letter', l.no);
  end if;

  if f.kind in ('renewal', 'update', 'cancel', 'certificate', 'replace') and v_act in ('recommend', 'revoke') then raise exception 'إجراء لا ينطبق على هذه المعاملة'; end if;
  if f.kind in ('certificate', 'replace') then raise exception 'هذه المعاملة أُنجزت آلياً'; end if;
  return _union_act52(p_id, p);
end $f$;

-- سجل الأعضاء: التجديد بوصل قبض في المكتب بالحساب نفسه، والتعليق والإعادة والإلغاء للأمين العام
create or replace function public.union_member_act(p_id uuid, p jsonb) returns union_members language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); m union_members; f union_files; q jsonb; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  select * into m from union_members where id = p_id and org_id = me.org_id for update;
  if m.id is null then raise exception 'العضو غير موجود'; end if;
  if p->>'action' = 'suspend' then
    if me.role <> 'union_sg' then raise exception 'التعليق للأمين العام'; end if;
    if m.status not in ('approved', 'expired') then raise exception 'لا يُعلَّق إلا عضو بهوية صادرة'; end if;
    if v_note is null then raise exception 'اكتب سبب التعليق'; end if;
    update union_members set status = 'suspended', reason = v_note, updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'تعليق العضوية ' || m.code, v_note);
    perform _un_tell_citizen(m.id, 'علّق اتحاد الصناعات عضويتك ' || m.code, v_note, m.id);
  elsif p->>'action' = 'reinstate' then
    if me.role <> 'union_sg' or m.status <> 'suspended' then raise exception 'إعادة العضوية المعلّقة للأمين العام'; end if;
    update union_members set status = case when valid_until >= current_date then 'approved' else 'expired' end, reason = null, updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'إعادة العضوية ' || m.code, v_note);
    perform _un_tell_citizen(m.id, 'أُعيدت عضويتك في اتحاد الصناعات', m.code, m.id);
  elsif p->>'action' = 'renew' then
    if me.role not in ('union_sg', 'union_reg', 'union_fin') then raise exception 'التجديد بالوصل لقسم العضوية أو الحسابات'; end if;
    if length(trim(coalesce(p->>'ref', ''))) < 3 then raise exception 'اكتب رقم وصل القبض'; end if;
    q := _un_renew_quote(m);
    if not (q->>'allowed')::boolean then raise exception '%', q->'why'->>0; end if;
    if q->>'mode' = 'inspection' and me.role <> 'union_sg' then raise exception 'انتهت الهوية منذ أكثر من سنة — يتطلب كشفاً موقعياً أو قرار الأمين العام'; end if;
    f := _un_new_file('renewal', m.id, null, 'done', null, (q->>'total')::bigint, 'تجديد في مقر الاتحاد بوصل قبض', v_note, null);
    update union_files set fee_paid_at = now(), fee_ref = 'وصل ' || trim(p->>'ref'), meta = jsonb_build_object('quote', q, 'mode', q->>'mode', 'cash', true) where id = f.id;
    m := _un_apply_renewal(f.id, 'تجديد في المقر بوصل ' || trim(p->>'ref') || ' — ' || to_char((q->>'total')::bigint, 'FM999,999,999') || ' د.ع');
  elsif p->>'action' = 'cancel' then
    if me.role <> 'union_sg' then raise exception 'إلغاء الانتماء للأمين العام'; end if;
    if v_note is null or length(v_note) < 10 then raise exception 'اكتب سبب الإلغاء (10 أحرف على الأقل)'; end if;
    update union_members set status = 'cancelled', reason = v_note, decided_by_name = me.full_name, decided_at = now(), updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'إلغاء الانتماء بقرار الأمين العام ' || coalesce(m.code, ''), v_note);
    perform _un_tell_citizen(m.id, 'ألغى اتحاد الصناعات انتماءك', v_note || ' — يحق لك الاعتراض لدى الأمين العام', m.id);
  else raise exception 'إجراء غير معروف'; end if;
  return m;
end $f$;

create or replace function public.union_member(p_id uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles := _un_me(); m union_members;
begin
  select * into m from union_members where id = p_id and org_id = me.org_id;
  if m.id is null then raise exception 'العضو غير موجود'; end if;
  return to_jsonb(m) - 'seal' || jsonb_build_object('category_label', _un_cat_label(m.category), 'valid', _un_member_ok(m), 'quote', _un_renew_quote(m),
    'docs', _un_member_docs(m.id), 'office', (_un_office(m.governorate)).name,
    'files', coalesce((select jsonb_agg(_un_file_row(f) order by f.created_at desc) from union_files f where f.member_id = m.id and f.status <> 'draft'), '[]'),
    'letters', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'no', l.no, 'kind', l.kind, 'title', l.title, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
      'verify_code', l.verify_code, 'sha256', l.sha256, 'body', l.body, 'revoked_at', l.revoked_at, 'revoke_reason', l.revoke_reason) order by l.issued_at desc)
      from union_letters l where l.member_id = m.id), '[]'),
    'log', coalesce((select jsonb_agg(jsonb_build_object('action', g.action, 'note', g.note, 'by', g.actor_name, 'at', g.created_at) order by g.id desc)
      from union_log g where g.member_id = m.id), '[]'));
end $f$;

-- مستند المنتسب لموظف الاتحاد (سجل المستمسكات)
create or replace function public.union_doc(p_id uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; d union_docs; m union_members; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into d from union_docs where id = p_id;
  if d.id is null then raise exception 'المستند غير موجود'; end if;
  select * into m from union_members where id = d.member_id;
  select a2.* into a from union_files f join applications a2 on a2.id = f.application_id where f.id = d.file_id;
  if not (me.portal = 'union' or m.citizen_id = me.id or (me.portal = 'bank' and me.org_id = a.bank_id) or me.portal in ('cbi', 'integrity', 'audit', 'admin')) then
    raise exception 'لا صلاحية لعرض المستند'; end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label, 'mime', d.mime, 'data', d.data, 'sha256', d.sha256, 'meta', d.meta, 'by', d.uploaded_by_name,
    'at', d.created_at, 'valid_until', d.valid_until);
end $f$;

-- ───────── 9) التحقق العام: الهوية البديلة والملغاة، وكتاب العضوية مع حال الهوية الآن ─────────
create or replace function public.union_verify(p_code text) returns jsonb language plpgsql stable security definer set search_path = public, extensions as $f$
declare l union_letters; m union_members; v text := upper(trim(coalesce(p_code, '')));
begin
  select * into l from union_letters where verify_code = v;
  if l.id is not null then
    select * into m from union_members where id = l.member_id;
    return jsonb_build_object('found', true, 'type', 'letter', 'kind', l.kind, 'title', l.title, 'no', l.no, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
      'issuer', l.issued_by_name, 'issuer_title', l.issued_by_title, 'intact', encode(extensions.digest(convert_to(l.body::text, 'UTF8'), 'sha256'), 'hex') = l.sha256,
      'sha256', l.sha256, 'revoked', l.revoked_at is not null, 'revoke_reason', l.revoke_reason, 'expired', l.valid_until < current_date,
      'factory', m.factory_name, 'member', m.code, 'category', _un_cat_label(m.category), 'bank', l.body->>'bank', 'amount', l.body->'amount', 'result', l.body->>'result',
      'to', l.body->>'to', 'purpose', l.body->>'purpose', 'auto', coalesce((l.body->>'auto')::boolean, false),
      'member_valid', _un_member_ok(m), 'member_status', m.status, 'ack', l.ack_at is not null, 'ack_at', l.ack_at);
  end if;
  select * into m from union_members where verify_code = v;
  if m.id is not null then
    return jsonb_build_object('found', true, 'type', 'member', 'member', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', _un_cat_label(m.category),
      'governorate', m.governorate, 'status', m.status, 'valid', _un_member_ok(m), 'joined', m.joined_at, 'valid_until', m.valid_until, 'version', m.card_version,
      'intact', m.seal = _un_seal_of(m));
  end if;
  select * into m from union_members where v = any(old_codes) limit 1;
  if m.id is not null then
    return jsonb_build_object('found', true, 'type', 'member_old', 'member', m.code, 'factory', m.factory_name, 'version', m.card_version);
  end if;
  return jsonb_build_object('found', false);
end $f$;

-- ───────── 10) Face ID والصلاحيات ─────────
revoke all on function public._union_act52(uuid, jsonb), public._union_file52(uuid) from public, anon, authenticated;
revoke all on function public._un_office(text), public._un_pick_eng(text, uuid), public._un_notify_gov(text[], text, text, text, uuid), public._un_req_docs(union_members),
  public._un_docs_check(uuid), public._un_docs_missing(uuid), public._un_member_docs(uuid), public._un_reseal(uuid), public._un_issue_letter(union_files, text, jsonb, date),
  public._un_new_file(text, uuid, uuid, text, bigint, bigint, text, text, uuid), public._un_pay_check(text, text), public._un_renew_quote(union_members, uuid),
  public._un_apply_renewal(uuid, text), public._un_apply_update(uuid, text), public._un_scan(), public._un_file_row(union_files), public._un_staff_gov()
  from public, anon, authenticated;
revoke all on function public.union_my(), public.union_member_draft(jsonb), public.union_member_submit(uuid, jsonb), public.union_draft_discard(uuid),
  public.union_doc_add(uuid, text, text, jsonb), public.union_renew_start(uuid), public.union_renew_submit(uuid, jsonb), public.union_renew(uuid, text, text),
  public.union_update_request(uuid, jsonb), public.union_cert_request(uuid, jsonb), public.union_card_replace(uuid, jsonb), public.union_cancel_request(uuid, text),
  public.union_inbox(), public.union_file(uuid), public.union_act(uuid, jsonb), public.union_member_act(uuid, jsonb), public.union_member(uuid), public.union_doc(uuid)
  from public, anon;
grant execute on function public.union_my(), public.union_member_draft(jsonb), public.union_member_submit(uuid, jsonb), public.union_draft_discard(uuid),
  public.union_doc_add(uuid, text, text, jsonb), public.union_renew_start(uuid), public.union_renew_submit(uuid, jsonb), public.union_renew(uuid, text, text),
  public.union_update_request(uuid, jsonb), public.union_cert_request(uuid, jsonb), public.union_card_replace(uuid, jsonb), public.union_cancel_request(uuid, text),
  public.union_inbox(), public.union_file(uuid), public.union_act(uuid, jsonb), public.union_member_act(uuid, jsonb), public.union_member(uuid), public.union_doc(uuid),
  public._un_doc_label(text), public._un_kind_label(text), public._un_status_label(text), public._un_field_label(text) to authenticated;
revoke all on function public.union_verify(text) from public;
grant execute on function public.union_verify(text) to anon, authenticated;

-- ───────── 11) بيانات العرض ─────────
-- إصلاح بصمة الهويات (التجديد في الجلسة 52 لم يحدّثها)
do $$ declare r record; begin for r in select id from public.union_members where code is not null loop perform public._un_reseal(r.id); end loop; end $$;

-- مكتب البصرة (البصرة، ميسان، ذي قار، المثنى) فيه موظف تسجيل ومهندس — المقر العام في بغداد يخدم بقية المحافظات
do $$
declare o uuid := (select id from public.orgs where code = 'ifi'); b uuid; sg uuid; pre text;
begin
  if o is null then return; end if;
  select id into sg from public.profiles where username = 'union.sg';
  select id into b from public.branches where bank_id = o and name = 'مكتب البصرة';
  if b is null then
    pre := public._staff_prefix(o);
    insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone)
    values (o, pre || '-' || lpad((select count(*) + 1 from public.branches where bank_id = o)::text, 2, '0'), 'مكتب البصرة', array['البصرة', 'ميسان', 'ذي قار', 'المثنى'], false, null)
    returning id into b;
  end if;
  if not exists (select 1 from public.profiles where username = 'union.reg2') then
    perform public._mk_user('union.reg2', 'Ifi@2026r2', 'زينب كاظم الحلفي', 'union_reg', 'union', 'ifi', null, null);
  end if;
  update public.profiles set branch_id = b, governorate = 'البصرة', must_change_password = false, managed_by = coalesce(managed_by, sg)
  where username in ('union.reg2', 'union.eng2') and branch_id is distinct from b;
end $$;

-- منتسبة بهوية منتهية منذ 40 يوماً (تجديد فوري) — citizen10، ومنتسب انتهت هويته منذ 5 أشهر (تجديد بمراجعة) — المعمل في نينوى
do $$
declare o uuid := (select id from public.orgs where code = 'ifi'); c uuid; m union_members; m2 uuid;
begin
  if o is null then return; end if;
  if not exists (select 1 from profiles where username = 'citizen10') then
    c := _mk_user('citizen10', 'Alwah@1010', 'سارة عدنان الموسوي', 'citizen', 'citizen', null, '07701234510', '198811030010');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'البصرة', city = 'شط العرب', employer = 'صاحبة معمل',
      monthly_salary = 2200000, birth_date = '1988-11-03', must_change_password = false where id = c;
  end if;
  select id into c from profiles where username = 'citizen10';
  if not exists (select 1 from union_members where citizen_id = c) then
    insert into union_members(code, org_id, citizen_id, owner_name, national_id, phone, factory_name, category, governorate, city, address, site_geo, trade_name_no,
      dev_license_no, dev_license_kind, capital, workers, products, capacity, status, joined_at, valid_until, verify_code, decided_by_name, decided_at)
    values (_vet_seq('IFI', 'union_members', 'code'), o, c, 'سارة عدنان الموسوي', '198811030010', '07701234510', 'معمل شط العرب للألبان', 'food', 'البصرة', 'شط العرب',
      'التنومة — الطريق العام قرب جسر الصافي', '{"lat":30.5292,"lng":47.8466,"acc":15}', 'TN-BSR-2290', 'IDD-2021-1174', 'complete', 180000000, 9,
      'ألبان وأجبان ولبن', '3 أطنان يومياً', 'expired', current_date - 405, current_date - 40, _un_vcode(), 'د. عبد الرزاق حميد الكبيسي', now() - interval '405 days')
    returning * into m;
    perform _un_reseal(m.id);
    -- عقد الإيجار مسجّل ونافذ
    insert into union_docs(member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name, valid_until, created_at)
    values (m.id, 'ind_lease', _un_doc_label('ind_lease'), 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
      95, encode(extensions.digest('demo-lease-10', 'sha256'), 'hex'), '{"demo": true}', c, 'سارة عدنان الموسوي', current_date + 300, now() - interval '405 days');
    perform _un_log(null, m.id, null, 'انتماء سابق (بيانات العرض)', 'انتهت الهوية قبل 40 يوماً — تجدَّد فوراً من بوابة المقترض');
  end if;
  -- معمل دجلة للنسيج (نينوى): انتهت هويته قبل 5 أشهر ليظهر مسار «التجديد بمراجعة»
  select id into m2 from union_members where org_id = o and factory_name = 'معمل دجلة للنسيج' and status = 'expired' and valid_until > current_date - 100;
  if m2 is not null then
    update union_members set valid_until = current_date - 150 where id = m2;
    perform _un_reseal(m2);
  end if;
end $$;
