-- ألواح — الجلسة 49: التحقق بالوجه (Face ID) قبل أي إجراء على معاملة
-- • كل موظف في أي جهة (الإدارة العليا التي يضيفها مشغّل النظام، وكل موظف تضيفه الإدارة من «فريقي») يسجّل بصمة وجهه
--   على جهازه مرة واحدة (WebAuthn — Face ID في آيفون، وبصمة الوجه أو الإصبع في غيره). المفتاح الخاص لا يغادر الجهاز.
-- • أي إجراء يكتب على معاملة (الطلب ومستنداته والصرف والأقساط والمفاتحات والكشف والتأمين والهيئة الشرعية…) يرفضه الحارس
--   trg_zz_face_gate ما لم يتحقق صاحبه بوجهه خلال «صلاحية التحقق» (90 ثانية افتراضياً). التحقق يفحصه الخادم (faceid.js) لا المتصفح.
-- • وضع المطور: settings.face_dev = 1 يتخطى التحقق كلياً. 0 = تشغيل حقيقي. يُبدَّل من مشغّل النظام ← الإعدادات.
-- • المقترض لا يُطلب منه (له التوقيع الإلكتروني بالوجه منذ الجلسة 15)، ولا العمليات الآلية (لا مستخدم لها).
-- يمكن تشغيله أكثر من مرة دون ضرر.

create schema if not exists private;

create table if not exists private.face_creds (
  id text primary key,                         -- معرّف المفتاح (base64url)
  user_id uuid not null references auth.users(id) on delete cascade,
  public_key text not null,                    -- SPKI DER (base64url)
  alg int not null,
  sign_count bigint not null default 0,
  device text,
  created_at timestamptz not null default now(),
  last_used_at timestamptz,
  revoked_at timestamptz,
  revoked_by uuid
);
create index if not exists face_creds_user on private.face_creds(user_id);

create table if not exists private.face_challenges (
  challenge text primary key,
  user_id uuid not null,
  kind text not null check (kind in ('register', 'verify')),
  created_at timestamptz not null default now()
);

create table if not exists private.face_passes (
  id bigserial primary key,
  user_id uuid not null,
  cred_id text,
  via text not null,
  verified_at timestamptz not null default now()
);
create index if not exists face_passes_user on private.face_passes(user_id, verified_at desc);
revoke all on private.face_creds, private.face_challenges, private.face_passes from public, anon, authenticated;

create table if not exists public.face_log (
  id bigserial primary key,
  user_id uuid,
  org_id uuid,
  event text not null,          -- enroll / verify / reset / dev
  actor_id uuid,
  device text,
  note text,
  created_at timestamptz not null default now()
);
alter table public.face_log enable row level security;
revoke all on public.face_log from anon, authenticated;

insert into public.settings(key, value, label)
select 'face_dev', 0, 'وضع المطور للتحقق بالوجه (1 = تخطّي التحقق، 0 = تشغيل حقيقي)'
where not exists (select 1 from public.settings where key = 'face_dev');
insert into public.settings(key, value, label)
select 'face_window_sec', 90, 'صلاحية التحقق بالوجه لإكمال الإجراء (ثانية)'
where not exists (select 1 from public.settings where key = 'face_window_sec');

-- ═══ أدوات ═══
create or replace function public._face_live() returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce(_setting('face_dev'), 0) <> 1 $f$;

create or replace function public._face_staff(p_user uuid) returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select portal not in ('citizen', 'borrower') from profiles where id = p_user), false) $f$;

create or replace function public._face_window() returns int
 language sql stable security definer set search_path to 'public' as $f$
  select greatest(30, least(900, coalesce(_setting('face_window_sec'), 90)::int)) $f$;

create or replace function public._face_passed(p_user uuid) returns timestamptz
 language sql stable security definer set search_path to 'public', 'private' as $f$
  select max(verified_at) + make_interval(secs => _face_window()) from private.face_passes
   where user_id = p_user and verified_at > now() - make_interval(secs => _face_window()) $f$;

-- ═══ الحارس: لا كتابة على معاملة من موظف دون تحقق بالوجه ═══
create or replace function public._face_gate() returns trigger
 language plpgsql security definer set search_path to 'public', 'private' as $f$
declare u uuid := auth.uid();
begin
  if u is null or coalesce(current_setting('alwah.face_skip', true), '') = '1' then return null; end if;
  if not _face_live() or not _face_staff(u) then return null; end if;
  if _face_passed(u) is not null then return null; end if;
  raise exception 'FACE_REQUIRED: هذا الإجراء يتطلب التحقق من وجهك (Face ID) — أعد المحاولة وتحقّق' using errcode = 'P0001';
end $f$;
revoke all on function public._face_gate(), public._face_passed(uuid), public._face_staff(uuid) from public, anon, authenticated;

do $d$
declare t text;
begin
  foreach t in array array['applications', 'app_documents', 'app_fix_requests', 'disbursements', 'installments', 'payments',
    'employer_checks', 'employer_check_files', 'mortgage_referrals', 'salary_referrals', 'expert_referrals',
    'eng_inspections', 'eng_items', 'eng_visits', 'ins_policies', 'ins_claims',
    'vet_memberships', 'vet_projects', 'vet_tranches', 'cbi_batches', 'oversight_letters', 'offer_reviews',
    'islamic_products', 'islamic_contract_versions', 'islamic_app_docs', 'sharia_resolutions', 'sharia_votes', 'sharia_reviews',
    'bank_programs', 'properties']
  loop
    if to_regclass('public.' || t) is not null then
      execute format('drop trigger if exists trg_zz_face_gate on public.%I', t);
      execute format('create trigger trg_zz_face_gate after insert or update or delete on public.%I for each row execute function public._face_gate()', t);
    end if;
  end loop;
end $d$;

-- صندوق التأمين يُنهي الوثائق المنتهية عند فتحه — ليس إجراءً من الموظف
do $d$
declare d text := pg_get_functiondef('public.ins_inbox()'::regprocedure);
  o text := '  perform _ins_expire();';
  n text := '  perform set_config(''alwah.face_skip'', ''1'', true); perform _ins_expire(); perform set_config(''alwah.face_skip'', '''', true);';
begin
  if position('alwah.face_skip' in d) = 0 then
    if (length(d) - length(replace(d, o, ''))) / length(o) <> 1 then raise exception 'ins_inbox: نص غير متوقع'; end if;
    execute replace(d, o, n);
  end if;
end $d$;

-- ═══ حالة المستخدم ═══
create or replace function public.my_face() returns jsonb
 language sql stable security definer set search_path to 'public', 'private' as $f$
  select jsonb_build_object(
    'live', _face_live(), 'staff', _face_staff(auth.uid()), 'window', _face_window(),
    'passed_until', _face_passed(auth.uid()),
    'devices', coalesce((select jsonb_agg(jsonb_build_object('id', left(c.id, 10), 'device', c.device, 'created_at', c.created_at, 'last_used_at', c.last_used_at) order by c.created_at)
                         from private.face_creds c where c.user_id = auth.uid() and c.revoked_at is null), '[]')) $f$;

-- ═══ دوال الخادم (faceid.js) — بالسر المشترك وجلسة المستخدم ═══
create or replace function public.face_begin(p_secret text, p_kind text) returns jsonb
 language plpgsql security definer set search_path to 'public', 'private', 'extensions' as $f$
declare u uuid := auth.uid(); me profiles; ch text; n int;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into me from profiles where id = u;
  if me.id is null then raise exception 'سجّل الدخول أولاً'; end if;
  if not _face_staff(u) then raise exception 'التحقق بالوجه لموظفي الجهات'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if p_kind not in ('register', 'verify') then raise exception 'طلب غير صالح'; end if;
  select count(*) into n from private.face_creds where user_id = u and revoked_at is null;
  -- جهاز إضافي: بعد التحقق بجهاز مسجّل (لا يكفي من يعرف كلمة المرور)
  if p_kind = 'register' and n > 0 and _face_passed(u) is null then
    raise exception 'لحسابك بصمة وجه مسجّلة — تحقّق بها أولاً ثم أضف هذا الجهاز، أو اطلب من مديرك إعادة ضبطها';
  end if;
  if p_kind = 'verify' and n = 0 then raise exception 'NO_FACE: لم تُسجَّل بصمة وجه لهذا الحساب بعد'; end if;
  delete from private.face_challenges where created_at < now() - interval '10 minutes' or (user_id = u and created_at < now() - interval '3 minutes');
  ch := translate(rtrim(encode(gen_random_bytes(32), 'base64'), '='), '+/', '-_');
  insert into private.face_challenges(challenge, user_id, kind) values (ch, u, p_kind);
  return jsonb_build_object('challenge', ch, 'user_id', u, 'username', me.username, 'full_name', me.full_name,
    'creds', coalesce((select jsonb_agg(id) from private.face_creds where user_id = u and revoked_at is null), '[]'));
end $f$;

create or replace function public.face_cred(p_secret text, p_challenge text, p_cred text) returns jsonb
 language plpgsql security definer set search_path to 'public', 'private' as $f$
declare u uuid := auth.uid(); c private.face_creds;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  if not exists (select 1 from private.face_challenges where challenge = p_challenge and user_id = u and kind = 'verify' and created_at > now() - interval '3 minutes')
    then raise exception 'انتهت مهلة التحقق — أعد المحاولة'; end if;
  select * into c from private.face_creds where id = p_cred and user_id = u and revoked_at is null;
  if c.id is null then raise exception 'هذا الجهاز غير مسجّل لحسابك'; end if;
  return jsonb_build_object('public_key', c.public_key, 'alg', c.alg, 'sign_count', c.sign_count);
end $f$;

create or replace function public.face_done(p_secret text, p_challenge text, p_kind text, p_data jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public', 'private' as $f$
declare u uuid := auth.uid(); ch private.face_challenges; me profiles; dev text := left(coalesce(p_data->>'device', ''), 80);
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  delete from private.face_challenges where challenge = p_challenge and user_id = u returning * into ch;
  if ch.challenge is null or ch.kind <> p_kind or ch.created_at < now() - interval '3 minutes' then raise exception 'انتهت مهلة التحقق — أعد المحاولة'; end if;
  select * into me from profiles where id = u;
  if p_kind = 'register' then
    if exists (select 1 from private.face_creds where id = p_data->>'id') then raise exception 'هذا المفتاح مسجّل مسبقاً'; end if;
    insert into private.face_creds(id, user_id, public_key, alg, sign_count, device, last_used_at)
    values (p_data->>'id', u, p_data->>'public_key', (p_data->>'alg')::int, coalesce((p_data->>'sign_count')::bigint, 0), nullif(dev, ''), now());
    insert into face_log(user_id, org_id, event, actor_id, device) values (u, me.org_id, 'enroll', u, nullif(dev, ''));
    perform _taudit('تسجيل بصمة الوجه', me.username, jsonb_build_object('note', nullif(dev, '')), me.org_id, me.branch_id);
  else
    update private.face_creds set sign_count = greatest(sign_count, coalesce((p_data->>'sign_count')::bigint, 0)), last_used_at = now()
     where id = p_data->>'id' and user_id = u and revoked_at is null;
    if not found then raise exception 'هذا الجهاز غير مسجّل لحسابك'; end if;
    insert into face_log(user_id, org_id, event, actor_id, device)
    select u, me.org_id, 'verify', u, device from private.face_creds where id = p_data->>'id';
  end if;
  insert into private.face_passes(user_id, cred_id, via) values (u, p_data->>'id', p_kind);
  delete from private.face_passes where verified_at < now() - interval '1 day';
  return jsonb_build_object('ok', true, 'until', _face_passed(u));
end $f$;

-- ═══ المدير ومشغّل النظام: حالة بصمة الوجه لموظفي النطاق، وإعادة ضبطها ═══
create or replace function public.team_face() returns jsonb
 language plpgsql stable security definer set search_path to 'public', 'private' as $f$
declare m profiles; adm boolean := _is_admin();
begin
  if not adm then m := _mgr(); end if;
  return jsonb_build_object('live', _face_live(), 'users', coalesce((select jsonb_agg(jsonb_build_object('user_id', p.id,
      'devices', (select count(*) from private.face_creds c where c.user_id = p.id and c.revoked_at is null),
      'enrolled_at', (select min(created_at) from private.face_creds c where c.user_id = p.id and c.revoked_at is null),
      'last_verify', (select max(created_at) from face_log l where l.user_id = p.id and l.event = 'verify')))
    from profiles p where p.portal not in ('citizen', 'borrower') and (adm or p.id = m.id or _can_manage(m, p))), '[]'));
end $f$;

create or replace function public.team_face_reset(p_user uuid, p_reason text) returns jsonb
 language plpgsql security definer set search_path to 'public', 'private' as $f$
declare m profiles; t profiles; adm boolean := _is_admin(); n int;
begin
  select * into t from profiles where id = p_user;
  if t.id is null then raise exception 'الموظف غير موجود'; end if;
  if not adm then m := _mgr(); if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if; end if;
  if length(trim(coalesce(p_reason, ''))) < 3 then raise exception 'اكتب سبب إعادة الضبط (جهاز جديد، فقدان الهاتف…)'; end if;
  update private.face_creds set revoked_at = now(), revoked_by = auth.uid() where user_id = p_user and revoked_at is null;
  get diagnostics n = row_count;
  delete from private.face_passes where user_id = p_user;
  insert into face_log(user_id, org_id, event, actor_id, note) values (p_user, t.org_id, 'reset', auth.uid(), trim(p_reason));
  perform _taudit('إعادة ضبط بصمة الوجه', t.username, jsonb_build_object('reason', trim(p_reason)), t.org_id, t.branch_id);
  return jsonb_build_object('ok', true, 'revoked', n);
end $f$;

-- ═══ مشغّل النظام: وضع المطور وصلاحية التحقق ═══
create or replace function public.admin_face_settings(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public', 'private' as $f$
declare v numeric; old numeric;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if p ? 'dev' then
    v := (p->>'dev')::numeric; if v not in (0, 1) then raise exception 'قيمة غير صحيحة'; end if;
    select value into old from settings where key = 'face_dev';
    update settings set value = v where key = 'face_dev';
    perform _audit('تعديل إعداد', 'face_dev', jsonb_build_object('from', old, 'to', v));
    insert into face_log(event, actor_id, note) values ('dev', auth.uid(), case when v = 1 then 'تفعيل وضع المطور — تخطّي التحقق بالوجه' else 'تشغيل حقيقي للتحقق بالوجه' end);
  end if;
  if p ? 'window' then
    v := (p->>'window')::numeric; if v < 30 or v > 900 then raise exception 'صلاحية التحقق بين 30 و900 ثانية'; end if;
    select value into old from settings where key = 'face_window_sec';
    update settings set value = v where key = 'face_window_sec';
    perform _audit('تعديل إعداد', 'face_window_sec', jsonb_build_object('from', old, 'to', v));
  end if;
  return jsonb_build_object('live', _face_live(), 'window', _face_window(),
    'staff', (select count(*) from profiles where portal not in ('citizen', 'borrower') and not coalesce(disabled, false)),
    'enrolled', (select count(distinct c.user_id) from private.face_creds c join profiles p on p.id = c.user_id where c.revoked_at is null and not coalesce(p.disabled, false)),
    'verifies_today', (select count(*) from face_log where event = 'verify' and created_at > date_trunc('day', now())));
end $f$;

create or replace function public.public_config() returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('dev_mode', coalesce(_setting('dev_mode'), 0) = 1,
                            'dev_otp', case when coalesce(_setting('dev_mode'), 0) = 1 then '1234' end,
                            'sms', _sms_live(),
                            'face_dev', not _face_live()) $f$;

revoke all on function public.face_begin(text, text), public.face_cred(text, text, text), public.face_done(text, text, text, jsonb),
  public.my_face(), public.team_face(), public.team_face_reset(uuid, text), public.admin_face_settings(jsonb), public._face_live(), public._face_window()
  from public, anon;
grant execute on function public.face_begin(text, text), public.face_cred(text, text, text), public.face_done(text, text, text, jsonb),
  public.my_face(), public.team_face(), public.team_face_reset(uuid, text), public.admin_face_settings(jsonb) to authenticated;
