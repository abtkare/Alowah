-- ═══════════════════════════════════════════════════════════════════════════
-- الجلسة 57 — خريطة المشاريع للجهات (وزارة التخطيط، وزارة التجارة، اتحاد الغرف التجارية وكل غرفة محافظة)
--              ومؤشرات المشاريع الوهمية على خريطة البنك المركزي (مواقع نصب محطات الطاقة الشمسية)
-- آمن للتكرار. لا يغيّر أي جدول قائم — دوال قراءة فقط.
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── 1) نقطة المشروع الأدق: زيارة المدقق ← موقع التركيب ← عنوان المقترض (GPS) ← تقريبي ─────────
create or replace function public._pm_point(a applications) returns jsonb language sql stable set search_path = public as $f$
  select case
    when a.audit_geo ? 'lat'   then jsonb_build_object('lat', (a.audit_geo->>'lat')::float8,   'lng', (a.audit_geo->>'lng')::float8,   'src', 'audit')
    when a.install_geo ? 'lat' then jsonb_build_object('lat', (a.install_geo->>'lat')::float8, 'lng', (a.install_geo->>'lng')::float8, 'src', 'install')
    when a.site_geo ? 'lat'    then jsonb_build_object('lat', (a.site_geo->>'lat')::float8,    'lng', (a.site_geo->>'lng')::float8,    'src', 'site')
    when a.lat is not null     then jsonb_build_object('lat', a.lat::float8, 'lng', a.lng::float8, 'src', 'approx')
  end $f$;

-- ───────── 2) مؤشرات المشروع الوهمي — تُحسب آلياً من قيود المعاملة (لا يُدخلها أحد) ─────────
--   no_install     صُرف أو تجاوز التركيب ولا يوجد توثيق GPS لموقع نصب المنظومة
--   audit_far      المدقق الهندسي وقف في مكان يبعد عن موقع التركيب/العنوان أكثر من الحد
--   non_conforming نتيجة التدقيق الهندسي: غير مطابق
--   disb_no_audit  صُرف المبلغ ولم يكشف عليه مدقق مستقل
--   no_gps         لدى المصرف ولا موقع GPS له إطلاقاً (تقريبي فقط)
--   dup_site       نقطة تركيب يدّعيها طلب آخر لمستفيد آخر (أقل من 20 م) — المنظومة نفسها مرتين؟
create or replace function public._pm_flags(a applications) returns text[] language plpgsql stable security definer set search_path = public as $f$
declare f text[] := '{}'; p jsonb := _pm_point(a); ref jsonb := coalesce(a.install_geo, a.site_geo); mx numeric := coalesce(_setting('install_max_distance_m'), 300);
  disb boolean := a.status = 'completed' or a.stage > 35;
begin
  if a.status in ('rejected', 'cancelled') then return f; end if;
  if coalesce(a.program, 'solar') = 'solar' and (disb or a.stage > 31) and a.install_geo is null and a.audit_geo is null then f := f || 'no_install'::text; end if;
  if a.audit_geo ? 'lat' and ref ? 'lat'
     and _geo_dist_m((a.audit_geo->>'lat')::float8, (a.audit_geo->>'lng')::float8, (ref->>'lat')::float8, (ref->>'lng')::float8) > mx then f := f || 'audit_far'::text; end if;
  if a.audit_status = 'non_conforming' then f := f || 'non_conforming'::text; end if;
  if disb and a.audit_status is null then f := f || 'disb_no_audit'::text; end if;
  if p is null or p->>'src' = 'approx' then f := f || 'no_gps'::text;
  elsif exists (select 1 from applications b
      where b.id <> a.id and b.citizen_id is distinct from a.citizen_id and b.bank_id is not null and b.stage >= 6
        and b.status not in ('rejected', 'cancelled') and _pm_point(b)->>'src' <> 'approx'
        and abs((_pm_point(b)->>'lat')::float8 - (p->>'lat')::float8) < 0.0005
        and _geo_dist_m((_pm_point(b)->>'lat')::float8, (_pm_point(b)->>'lng')::float8, (p->>'lat')::float8, (p->>'lng')::float8) < 20) then
    f := f || 'dup_site'::text;
  end if;
  return f;
end $f$;

-- ───────── 3) خريطة المشاريع حسب الجهة ─────────
--  وزارة التخطيط، وزارة التجارة، البنك المركزي، مشغّل النظام: كل المحافظات
--  اتحاد الغرف التجارية: رئيس الاتحاد وموظفو المقر كل المحافظات، وغرفة المحافظة محافظتها فقط (+ محلات التجار المنتسبين)
--  مؤشرات المشاريع الوهمية والنقطتان (العنوان المعلن وموقع التركيب) للبنك المركزي ومشغّل النظام فقط
--  لا أسماء أشخاص ولا أرقام هويات — اسم النشاط وعنوان المشروع فقط
create or replace function public.projects_map() returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; govs text[]; oversight boolean; pr jsonb; mem jsonb := '[]'::jsonb; lbl text;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or coalesce(me.disabled, false) or me.portal not in ('planning', 'trade', 'cbi', 'admin', 'chamber') then
    raise exception 'خريطة المشاريع لوزارة التخطيط ووزارة التجارة واتحاد الغرف التجارية والبنك المركزي'; end if;
  oversight := me.portal in ('cbi', 'admin');
  if me.portal = 'chamber' and me.branch_id is not null then
    select coalesce(b.governorates, '{}'), b.name into govs, lbl from branches b where b.id = me.branch_id;
  end if;

  select coalesce(jsonb_agg(x order by x->>'code'), '[]'::jsonb) into pr from (
    select jsonb_strip_nulls(jsonb_build_object(
      'id', a.id, 'code', a.code, 'sector', _app_sector(a.program, a.purpose), 'program', coalesce(a.program, 'solar'),
      'name', nullif(trim(coalesce(a.biz->>'business_name', '')), ''),
      'activity', coalesce(nullif(trim(coalesce(a.biz->>'activity', '')), ''), case when a.purpose = 'other' then a.purpose_other end),
      'vet_type', v.project_type,
      'gov', a.governorate, 'city', a.city, 'address', coalesce(a.site_geo->>'address', a.biz->>'address'),
      'lat', round((pt->>'lat')::numeric, 6), 'lng', round((pt->>'lng')::numeric, 6), 'src', pt->>'src',
      'status', a.status, 'stage', a.stage, 'kw', a.kw, 'amount', a.amount, 'audit', a.audit_status,
      'flags', case when oversight then to_jsonb(_pm_flags(a)) end,
      'site', case when oversight and a.site_geo ? 'lat' then jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng') end,
      'install', case when oversight and a.install_geo ? 'lat' then jsonb_build_object('lat', a.install_geo->'lat', 'lng', a.install_geo->'lng', 'at', a.install_geo->'at') end
    )) x
    from applications a
    left join lateral (select vp.project_type from vet_projects vp where vp.application_id = a.id limit 1) v on true
    cross join lateral (select _pm_point(a) pt) q
    where a.bank_id is not null and a.stage >= 6 and a.status not in ('rejected', 'cancelled')
      and (govs is null or a.governorate = any(govs))) s;

  if me.portal = 'chamber' then
    select coalesce(jsonb_agg(jsonb_strip_nulls(jsonb_build_object(
      'id', m.id, 'code', m.code, 'name', m.factory_name, 'cat', m.category, 'gov', m.governorate, 'city', m.city, 'address', m.address,
      'lat', (m.site_geo->>'lat')::numeric, 'lng', (m.site_geo->>'lng')::numeric, 'status', m.status)) order by m.code), '[]'::jsonb) into mem
    from chamber_members m
    where m.status in ('approved', 'expired', 'suspended', 'pending') and (govs is null or m.governorate = any(govs));
  end if;

  return jsonb_build_object('portal', me.portal, 'govs', to_jsonb(govs), 'scope_label', lbl, 'oversight', oversight,
    'max_m', coalesce(_setting('install_max_distance_m'), 300), 'projects', pr, 'members', mem, 'at', now());
end $f$;

revoke execute on function public._pm_flags(applications) from public, anon, authenticated;
revoke execute on function public.projects_map() from public, anon;
grant execute on function public.projects_map() to authenticated;
