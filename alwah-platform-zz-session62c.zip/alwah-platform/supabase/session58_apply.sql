-- ═══════════════════════════════════════════════════════════════════════════
-- الجلسة 58 — بيانات عرض للخرائط (للعرض في القمة): مشاريع من كل تخصصات المبادرات في المحافظات الثماني عشرة،
--              ومحلات تجار منتسبين لغرف التجارة في بغداد والمحافظات.
-- منفصلة تماماً عن المعاملات الحقيقية: جدولان مستقلان لا يمسّان المصارف ولا الإحصاءات ولا الرسائل.
-- تظهر على الخرائط فقط ما دام الإعداد map_demo = 1 (يُصفَّر من الإعدادات قبل التشغيل الفعلي فتختفي كلها).
-- آمن للتكرار: لا يُعاد التوليد إن كانت البيانات موجودة.
-- ═══════════════════════════════════════════════════════════════════════════

create table if not exists public.demo_map_projects (
  id uuid primary key default gen_random_uuid(), code text unique, sector text, program text, purpose text,
  name text, activity text, vet_type text, gov text, city text, address text,
  lat numeric, lng numeric, src text, status text, stage int, kw numeric, amount bigint, audit text,
  flags text[] not null default '{}', site jsonb, install jsonb, created_at timestamptz default now());
create table if not exists public.demo_map_members (
  id uuid primary key default gen_random_uuid(), code text unique, name text, cat text, gov text, city text, address text,
  lat numeric, lng numeric, status text, created_at timestamptz default now());
alter table public.demo_map_projects enable row level security;
alter table public.demo_map_members enable row level security;
revoke all on public.demo_map_projects, public.demo_map_members from anon, authenticated;

insert into public.settings (key, value, label)
values ('map_demo', 1, 'بيانات العرض على خرائط المشاريع (1 = تظهر، 0 = تختفي) — صفّرها قبل التشغيل الفعلي')
on conflict (key) do nothing;

-- ───────── المدن ومراكزها ─────────
drop table if exists pg_temp._dm_city; drop table if exists pg_temp._dm_gov;
create temp table _dm_city (gov text, city text, lat float8, lng float8, w int);
insert into _dm_city values
 ('بغداد','الكرادة',33.300,44.420,4),('بغداد','المنصور',33.320,44.330,4),('بغداد','الأعظمية',33.370,44.370,3),('بغداد','الكاظمية',33.380,44.340,3),
 ('بغداد','مدينة الصدر',33.390,44.460,4),('بغداد','الدورة',33.250,44.380,3),('بغداد','أبو غريب',33.290,44.070,3),('بغداد','التاجي',33.500,44.230,2),
 ('بغداد','المحمودية',33.060,44.360,2),('بغداد','الزعفرانية',33.250,44.470,2),('بغداد','الشعب',33.410,44.410,2),('بغداد','بغداد الجديدة',33.320,44.470,3),
 ('البصرة','العشار',30.510,47.820,4),('البصرة','الزبير',30.390,47.700,3),('البصرة','أبو الخصيب',30.450,48.000,2),('البصرة','القرنة',31.010,47.430,2),
 ('البصرة','الفاو',29.980,48.470,1),('البصرة','شط العرب',30.530,47.900,2),('البصرة','الجمهورية',30.530,47.800,2),
 ('نينوى','الموصل',36.340,43.130,5),('نينوى','تلعفر',36.380,42.450,2),('نينوى','الحمدانية',36.270,43.380,2),('نينوى','سنجار',36.320,41.880,1),('نينوى','بعشيقة',36.450,43.350,1),
 ('أربيل','أربيل',36.190,44.010,5),('أربيل','شقلاوة',36.400,44.320,1),('أربيل','كويسنجق',36.080,44.630,1),('أربيل','سوران',36.650,44.540,1),
 ('النجف','النجف',32.000,44.330,4),('النجف','الكوفة',32.030,44.400,2),('النجف','المناذرة',31.880,44.480,2),('النجف','المشخاب',31.800,44.490,2),
 ('كربلاء','كربلاء',32.610,44.020,4),('كربلاء','الهندية',32.540,44.220,2),('كربلاء','عين التمر',32.570,43.490,1),
 ('بابل','الحلة',32.480,44.430,4),('بابل','المسيب',32.780,44.290,2),('بابل','المحاويل',32.650,44.400,2),('بابل','الهاشمية',32.370,44.650,2),
 ('ذي قار','الناصرية',31.050,46.260,4),('ذي قار','الشطرة',31.410,46.170,2),('ذي قار','سوق الشيوخ',30.880,46.460,2),('ذي قار','الرفاعي',31.720,46.110,1),
 ('الأنبار','الرمادي',33.420,43.300,4),('الأنبار','الفلوجة',33.350,43.780,3),('الأنبار','هيت',33.640,42.830,1),('الأنبار','القائم',34.370,41.090,1),
 ('ديالى','بعقوبة',33.750,44.640,4),('ديالى','المقدادية',33.980,44.940,2),('ديالى','الخالص',33.810,44.530,2),('ديالى','خانقين',34.350,45.390,1),
 ('واسط','الكوت',32.510,45.820,4),('واسط','الصويرة',32.930,44.780,2),('واسط','النعمانية',32.560,45.420,1),('واسط','الحي',32.170,46.050,1),
 ('ميسان','العمارة',31.840,47.150,4),('ميسان','المجر الكبير',31.570,47.170,1),('ميسان','قلعة صالح',31.510,47.270,1),
 ('الديوانية','الديوانية',31.990,44.920,4),('الديوانية','الشامية',31.960,44.600,2),('الديوانية','عفك',32.060,45.250,1),
 ('صلاح الدين','تكريت',34.610,43.680,3),('صلاح الدين','سامراء',34.200,43.870,3),('صلاح الدين','بلد',34.020,44.150,2),('صلاح الدين','الشرقاط',35.510,43.230,1),
 ('كركوك','كركوك',35.470,44.390,4),('كركوك','الحويجة',35.320,43.770,1),('كركوك','داقوق',35.130,44.450,1),
 ('المثنى','السماوة',31.310,45.280,4),('المثنى','الرميثة',31.530,45.200,2),('المثنى','الخضر',31.200,45.530,1),
 ('السليمانية','السليمانية',35.560,45.430,5),('السليمانية','رانية',36.250,44.880,1),('السليمانية','حلبجة',35.180,45.990,1),
 ('دهوك','دهوك',36.870,42.990,4),('دهوك','زاخو',37.140,42.680,2),('دهوك','سميل',36.860,42.850,1);

create temp table _dm_gov (gov text, np int, nm int);   -- عدد المشاريع والمحلات في كل محافظة
insert into _dm_gov values ('بغداد',150,300),('البصرة',70,110),('نينوى',60,90),('أربيل',40,70),('النجف',45,70),('كربلاء',40,60),('بابل',45,60),
 ('ذي قار',40,55),('الأنبار',40,55),('ديالى',35,45),('واسط',30,40),('ميسان',28,35),('الديوانية',32,40),('صلاح الدين',32,40),('كركوك',35,50),
 ('المثنى',25,30),('السليمانية',38,60),('دهوك',30,45);

do $seed$
declare
  g record; c record; i int; n int := 0; k int; r float8; sec text; prog text; purp text; nm text; act text; vt text; kw numeric; amt bigint;
  st text; stg int; src text; aud text; fl text[]; jit float8; la float8; lo float8; site jsonb; inst jsonb;
  w_sec text[] := array['residential','residential','residential','residential','residential','residential','agricultural','agricultural','agricultural',
    'project','project','project','industrial','industrial','commercial_program','commercial_program','industrial_program','ecommerce_program',
    'export_program','export','vet','vet_program','vet_program','other'];
  fam text[] := array['الرافدين','النور','الأمل','دجلة','الفرات','بابل','سومر','الخيرات','البركة','الهدى','السلام','الوفاء','الأصيل','الجنائن','الفجر',
    'الرواد','الإبداع','المستقبل','الشموخ','الياسمين','النخيل','الصفاء','الريادة','أكد','آشور','الوركاء','الحضارة','الكرم','الأنوار','الغدير'];
  agri text[] := array['بستان نخيل','حقل حنطة وشعير','مشتل نباتات','مزرعة دواجن','مزرعة أسماك','بيوت بلاستيكية للخضروات','بستان حمضيات','مزرعة أبقار حليب','ري بالتنقيط — بئر ارتوازي','حقل ذرة صفراء'];
  proj text[] := array['مطعم','فندق','مركز تسوق','مدرسة أهلية','مستوصف','صالة مناسبات','مخبز آلي','مجمع تجاري','مكتب خدمات','مركز رياضي','محطة غسل سيارات','كافتيريا'];
  ind text[] := array['معمل بلوك','معمل ألبان','معمل منظفات','معمل أعلاف','معمل بلاستك','مطحنة','معمل خياطة','معمل تعبئة مياه','معمل حلويات','ورشة حدادة','معمل أثاث','معمل طابوق'];
  com text[] := array['مواد غذائية بالجملة','مواد إنشائية','أجهزة كهربائية','قطع غيار سيارات','ملابس وأقمشة','مستلزمات طبية','أدوات منزلية','مواد زراعية'];
  ecom text[] := array['متجر إلكتروني للملابس','متجر إلكتروني للأجهزة','منصة توصيل طعام','متجر إلكتروني للعطور','متجر مستحضرات تجميل','منصة حجز خدمات'];
  expo text[] := array['تصدير تمور','تصدير جلود','تصدير ملح','تصدير أسمدة','تصدير منتجات ألبان','تصدير خضروات'];
  oth text[] := array['محطة شحن سيارات كهربائية','مركز تدريب مهني','مكتبة عامة','دار أيتام أهلية','مسجد وملحقاته','ملعب خماسي'];
  vets text[] := array['clinic','clinic','clinic','lab','hospital','pharma','supplies'];
  fakes text[] := array['no_install','dup_site','audit_far','non_conforming','disb_no_audit','no_gps'];
begin
  perform setseed(0.58);
  if not exists (select 1 from demo_map_projects) then
    for g in select * from _dm_gov loop
      for i in 1..g.np loop
        -- مدينة بحسب الوزن
        select * into c from _dm_city where gov = g.gov order by -ln(random()) / w limit 1;
        n := n + 1;
        sec := w_sec[1 + floor(random() * array_length(w_sec, 1))::int];
        prog := case sec when 'commercial_program' then 'commercial' when 'industrial_program' then 'industrial' when 'ecommerce_program' then 'ecommerce'
                         when 'export_program' then 'export' when 'vet_program' then 'vet' else 'solar' end;
        purp := case when prog <> 'solar' then null when sec = 'residential' then 'household' else sec end;
        nm := null; act := null; vt := null;
        case sec
          when 'residential' then kw := (3 + floor(random() * 8))::numeric; jit := 0.025;
          when 'agricultural' then act := agri[1 + floor(random() * 10)::int]; nm := 'مزرعة ' || fam[1 + floor(random() * 30)::int]; kw := (10 + floor(random() * 50))::numeric; jit := 0.13;
          when 'project' then act := proj[1 + floor(random() * 12)::int]; nm := act || ' ' || fam[1 + floor(random() * 30)::int]; kw := (10 + floor(random() * 40))::numeric; jit := 0.03;
          when 'industrial' then act := ind[1 + floor(random() * 12)::int]; nm := act || ' ' || fam[1 + floor(random() * 30)::int]; kw := (30 + floor(random() * 170))::numeric; jit := 0.07;
          when 'export' then act := expo[1 + floor(random() * 6)::int]; nm := 'شركة ' || fam[1 + floor(random() * 30)::int] || ' للتصدير'; kw := (20 + floor(random() * 80))::numeric; jit := 0.06;
          when 'vet' then vt := vets[1 + floor(random() * 7)::int]; kw := (10 + floor(random() * 30))::numeric; jit := 0.04;
          when 'other' then act := oth[1 + floor(random() * 6)::int]; kw := (5 + floor(random() * 35))::numeric; jit := 0.04;
          when 'commercial_program' then act := com[1 + floor(random() * 8)::int]; nm := 'محلات ' || fam[1 + floor(random() * 30)::int]; kw := null; jit := 0.025;
          when 'industrial_program' then act := ind[1 + floor(random() * 12)::int]; nm := act || ' ' || fam[1 + floor(random() * 30)::int]; kw := null; jit := 0.07;
          when 'ecommerce_program' then act := ecom[1 + floor(random() * 6)::int]; nm := fam[1 + floor(random() * 30)::int] || ' أونلاين'; kw := null; jit := 0.025;
          when 'export_program' then act := expo[1 + floor(random() * 6)::int]; nm := 'شركة ' || fam[1 + floor(random() * 30)::int] || ' للتجارة والتصدير'; kw := null; jit := 0.05;
          when 'vet_program' then vt := vets[1 + floor(random() * 7)::int]; kw := null; jit := 0.03;
        end case;
        amt := case when kw is not null then (kw * (950000 + floor(random() * 300000)))::bigint
                    else ((20 + floor(random() * 230)) * 1000000)::bigint end;
        r := random();
        if r < 0.68 then st := 'completed'; stg := 37; else st := 'active'; stg := (array[8,12,18,22,26,30,32,34,35])[1 + floor(random() * 9)::int]; end if;
        la := c.lat + (random() - 0.5) * 2 * jit; lo := c.lng + (random() - 0.5) * 2 * jit;
        src := case when st = 'completed' then (case when random() < 0.62 then 'audit' else 'install' end)
                    when stg >= 32 and prog = 'solar' then 'install' else 'site' end;
        aud := case when src = 'audit' then (case when random() < 0.88 then 'conforming' else 'conditional' end) end;
        site := jsonb_build_object('lat', round(la::numeric, 6), 'lng', round(lo::numeric, 6)); inst := null; fl := '{}';
        if src in ('install', 'audit') then inst := site; end if;
        -- مؤشرات المشاريع الوهمية على قرابة 7% (لإظهار ما يكشفه البنك المركزي)
        if random() < 0.07 then
          k := 1 + floor(random() * 6)::int; fl := array[fakes[k]];
          if fakes[k] = 'no_install' then src := 'site'; inst := null; aud := null; st := 'completed'; stg := 37; fl := fl || 'disb_no_audit'::text;
          elsif fakes[k] = 'audit_far' then
            site := jsonb_build_object('lat', round((la + 0.009)::numeric, 6), 'lng', round((lo - 0.006)::numeric, 6)); src := 'audit'; aud := 'conditional';
          elsif fakes[k] = 'non_conforming' then src := 'audit'; aud := 'non_conforming'; st := 'completed'; stg := 37;
          elsif fakes[k] = 'disb_no_audit' then src := 'install'; aud := null; st := 'completed'; stg := 37;
          elsif fakes[k] = 'no_gps' then src := 'approx'; la := c.lat; lo := c.lng; site := null; inst := null; aud := null;
          end if;
        end if;
        insert into demo_map_projects (code, sector, program, purpose, name, activity, vet_type, gov, city, address, lat, lng, src, status, stage, kw, amount, audit, flags, site, install)
        values ('ALW-2026-' || lpad((10000 + n)::text, 5, '0'), sec, prog, purp, nm, act, vt, g.gov, c.city,
          case when src = 'approx' then null else 'محلة ' || (100 + floor(random() * 800))::int || '، زقاق ' || (1 + floor(random() * 40))::int end,
          round(la::numeric, 6), round(lo::numeric, 6), src, st, stg, kw, amt, aud, fl, site, inst);
      end loop;
    end loop;
    -- نقاط تركيب مكررة: يُنسخ موقع مشروع إلى مشروع آخر في المدينة نفسها
    update demo_map_projects d set lat = s.lat + 0.00005, lng = s.lng + 0.00005, install = jsonb_build_object('lat', s.lat + 0.00005, 'lng', s.lng + 0.00005), src = 'install'
    from (select distinct on (x.id) x.id, y.lat, y.lng from demo_map_projects x join demo_map_projects y on y.city = x.city and y.id <> x.id and y.src <> 'approx' and y.flags = '{}'
          where 'dup_site' = any(x.flags) order by x.id, y.code) s where d.id = s.id;
    update demo_map_projects set flags = '{dup_site}' where id in (
      select y.id from demo_map_projects x join demo_map_projects y on y.id <> x.id and 'dup_site' = any(x.flags) and y.flags = '{}' and abs(y.lat - x.lat) < 0.0002 and abs(y.lng - x.lng) < 0.0002);
  end if;

  if not exists (select 1 from demo_map_members) then
    n := 0;
    for g in select * from _dm_gov loop
      for i in 1..g.nm loop
        select * into c from _dm_city where gov = g.gov order by -ln(random()) / w limit 1;
        n := n + 1;
        act := (array['food','food','food','construction','construction','electrical','electrical','vehicles','vehicles','textile','textile','medical','agri','fuel','general','general','services','services','other'])[1 + floor(random() * 19)::int];
        nm := (case act when 'food' then (array['أسواق','مخازن','شركة','بقالة'])[1 + floor(random() * 4)::int]
                        when 'construction' then (array['مواد إنشائية','معرض','مخازن'])[1 + floor(random() * 3)::int]
                        when 'electrical' then (array['معرض','مركز','شركة'])[1 + floor(random() * 3)::int]
                        when 'vehicles' then (array['معرض سيارات','قطع غيار','وكالة'])[1 + floor(random() * 3)::int]
                        when 'textile' then (array['أقمشة','أزياء','بيت'])[1 + floor(random() * 3)::int]
                        when 'medical' then (array['مذخر','مستلزمات طبية','صيدلية'])[1 + floor(random() * 3)::int]
                        when 'agri' then 'مستلزمات زراعية' when 'fuel' then 'محطة وقود'
                        when 'services' then (array['مكتب','شركة','مركز'])[1 + floor(random() * 3)::int]
                        else (array['شركة','مؤسسة','مكتب'])[1 + floor(random() * 3)::int] end)
              || ' ' || fam[1 + floor(random() * 30)::int];
        r := random();
        insert into demo_map_members (code, name, cat, gov, city, address, lat, lng, status)
        values ('FCC-2026-' || lpad((10000 + n)::text, 5, '0'), nm, act, g.gov, c.city,
          'شارع ' || (array['التجارة','الرشيد','المكتبات','السوق','الجمهورية','الصناعة','النهر','المطار','الكورنيش','فلسطين'])[1 + floor(random() * 10)::int] || '، محل ' || (1 + floor(random() * 300))::int,
          round((c.lat + (random() - 0.5) * 0.05)::numeric, 6), round((c.lng + (random() - 0.5) * 0.05)::numeric, 6),
          case when r < 0.8 then 'approved' when r < 0.88 then 'pending' when r < 0.96 then 'expired' else 'suspended' end);
      end loop;
    end loop;
  end if;
end $seed$;
drop table if exists pg_temp._dm_city; drop table if exists pg_temp._dm_gov;

-- ───────── projects_map: تُضاف بيانات العرض ما دام map_demo = 1 ─────────
create or replace function public.projects_map() returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; govs text[]; oversight boolean; pr jsonb; mem jsonb := '[]'::jsonb; lbl text; demo boolean := coalesce(_setting('map_demo'), 0) = 1;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or coalesce(me.disabled, false) or me.portal not in ('planning', 'trade', 'cbi', 'admin', 'chamber') then
    raise exception 'خريطة المشاريع لوزارة التخطيط ووزارة التجارة واتحاد الغرف التجارية والبنك المركزي'; end if;
  oversight := me.portal in ('cbi', 'admin');
  if me.portal = 'chamber' and me.branch_id is not null then
    select coalesce(b.governorates, '{}'), b.name into govs, lbl from branches b where b.id = me.branch_id;
  end if;

  select coalesce(jsonb_agg(x order by x->>'code'), '[]'::jsonb) into pr from (
    select jsonb_strip_nulls(jsonb_build_object(
      'id', a.id, 'code', a.code, 'sector', _app_sector(a.program, a.purpose), 'program', coalesce(a.program, 'solar'), 'purpose', a.purpose,
      'name', nullif(trim(coalesce(a.biz->>'business_name', '')), ''),
      'activity', coalesce(nullif(trim(coalesce(a.biz->>'activity', '')), ''), case when a.purpose = 'other' then a.purpose_other end),
      'vet_type', v.project_type,
      'gov', a.governorate, 'city', a.city, 'address', coalesce(a.site_geo->>'address', a.biz->>'address'),
      'lat', round((pt->>'lat')::numeric, 6), 'lng', round((pt->>'lng')::numeric, 6), 'src', pt->>'src',
      'status', a.status, 'stage', a.stage, 'kw', a.kw, 'amount', a.amount, 'audit', a.audit_status,
      'flags', case when oversight then to_jsonb(_pm_flags(a)) end,
      'site', case when oversight and a.site_geo ? 'lat' then jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng') end,
      'install', case when oversight and a.install_geo ? 'lat' then jsonb_build_object('lat', a.install_geo->'lat', 'lng', a.install_geo->'lng', 'at', a.install_geo->'at') end
    )) x
    from applications a
    left join lateral (select vp.project_type from vet_projects vp where vp.application_id = a.id limit 1) v on true
    cross join lateral (select _pm_point(a) pt) q
    where a.bank_id is not null and a.stage >= 6 and a.status not in ('rejected', 'cancelled')
      and (govs is null or a.governorate = any(govs))
    union all
    select jsonb_strip_nulls(jsonb_build_object(
      'id', d.id, 'code', d.code, 'sector', d.sector, 'program', d.program, 'purpose', d.purpose, 'name', d.name, 'activity', d.activity, 'vet_type', d.vet_type,
      'gov', d.gov, 'city', d.city, 'address', d.address, 'lat', d.lat, 'lng', d.lng, 'src', d.src, 'status', d.status, 'stage', d.stage,
      'kw', d.kw, 'amount', d.amount, 'audit', d.audit, 'demo', true,
      'flags', case when oversight then to_jsonb(d.flags) end,
      'site', case when oversight then d.site end, 'install', case when oversight then d.install end))
    from demo_map_projects d where demo and (govs is null or d.gov = any(govs))) s;

  if me.portal = 'chamber' then
    select coalesce(jsonb_agg(z order by z->>'code'), '[]'::jsonb) into mem from (
      select jsonb_strip_nulls(jsonb_build_object(
        'id', m.id, 'code', m.code, 'name', m.factory_name, 'cat', m.category, 'gov', m.governorate, 'city', m.city, 'address', m.address,
        'lat', (m.site_geo->>'lat')::numeric, 'lng', (m.site_geo->>'lng')::numeric, 'status', m.status)) z
      from chamber_members m
      where m.status in ('approved', 'expired', 'suspended', 'pending') and (govs is null or m.governorate = any(govs))
      union all
      select jsonb_strip_nulls(jsonb_build_object('id', d.id, 'code', d.code, 'name', d.name, 'cat', d.cat, 'gov', d.gov, 'city', d.city,
        'address', d.address, 'lat', d.lat, 'lng', d.lng, 'status', d.status, 'demo', true))
      from demo_map_members d where demo and (govs is null or d.gov = any(govs))) t;
  end if;

  return jsonb_build_object('portal', me.portal, 'govs', to_jsonb(govs), 'scope_label', lbl, 'oversight', oversight, 'demo', demo,
    'max_m', coalesce(_setting('install_max_distance_m'), 300), 'projects', pr, 'members', mem, 'at', now());
end $f$;
revoke execute on function public.projects_map() from public, anon;
grant execute on function public.projects_map() to authenticated;
