-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 62b: تصحيحان بعد اختبار كل المسارات على القاعدة الحية
--  1) الحارس يفحص الإرسال الأول فقط: الطلب الذي أعاده المصرف للمقترض (نواقص المرحلة 6 أو استبدال الضمان)
--     ثم أعاده المقترض لا يُرفض بسياسة اعتُمدت بعد إرساله — كان سيعلق طلب citizen3 لو أُعيد.
--  2) نطاق الشرط: لكل شرط حقل اختياري sectors — يُطبَّق على هذه الأنواع من الطلبات فقط.
--     سياسة السنابل «لا عمل حر» صارت للمنظومات الشمسية فقط، فلا تمنع الأطباء البيطريين (عملهم حر بطبيعته) من مبادرتهم.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════
set check_function_bodies = off;

create or replace function public._policy_eval(p_rules jsonb, p_ctx jsonb) returns jsonb
language plpgsql immutable as $$
declare r jsonb; f text; op text; v jsonb; lim numeric; x numeric; ok boolean; lbl text;
  fails jsonb := '[]'; unknown jsonb := '[]'; n int := 0; passed int := 0;
begin
  for r in select * from jsonb_array_elements(coalesce(p_rules, '[]'::jsonb)) loop
    -- الجلسة 62b: الشرط المقيّد بأنواع طلبات لا يُطبَّق على غيرها
    if jsonb_typeof(r->'sectors') = 'array' and jsonb_array_length(r->'sectors') > 0 and p_ctx ? 'sector'
       and not ((r->'sectors') ? (p_ctx->>'sector')) then continue; end if;
    f := r->>'field'; op := r->>'op'; v := p_ctx -> f; n := n + 1;
    lbl := coalesce(_policy_fields() -> f ->> 'label', f);
    if v is null or jsonb_typeof(v) = 'null' then
      unknown := unknown || jsonb_build_object('field', f, 'label', lbl, 'text', r->>'text'); continue;
    end if;
    if op in ('gte', 'lte') then
      x := (v #>> '{}')::numeric; lim := (r->>'value')::numeric;
      ok := case op when 'gte' then x >= lim else x <= lim end;
    elsif op = 'in' then ok := coalesce(r->'value', '[]') ? (v #>> '{}');
    elsif op = 'not_in' then ok := not (coalesce(r->'value', '[]') ? (v #>> '{}'));
    else continue; end if;
    if ok then passed := passed + 1;
    else
      fails := fails || jsonb_build_object('field', f, 'label', lbl, 'op', op, 'value', r->'value', 'actual', v, 'text', r->>'text',
        'msg', lbl || ' ' || _policy_fmt(f, v) || ' — ' || case op
          when 'gte' then 'السياسة تشترط ألا يقل عن ' || _policy_fmt(f, r->'value')
          when 'lte' then 'السياسة تشترط ألا يزيد على ' || _policy_fmt(f, r->'value')
          when 'in' then 'السياسة تقبل فقط: ' || _policy_fmt(f, r->'value')
          else 'السياسة لا تقبل: ' || _policy_fmt(f, r->'value') end);
    end if;
  end loop;
  return jsonb_build_object('result', case when n = 0 then 'no_policy' when jsonb_array_length(fails) > 0 then 'fail' else 'pass' end,
    'rules', n, 'passed', passed, 'fails', fails, 'unknown', unknown);
end $$;

create or replace function public._policy_norm(p_rules jsonb) returns jsonb language plpgsql immutable as $$
declare r jsonb; f text; op text; k text; out jsonb := '[]'; i int := 0; vals jsonb; sc jsonb;
begin
  if p_rules is null or jsonb_typeof(p_rules) <> 'array' then raise exception 'الشروط غير صحيحة'; end if;
  for r in select * from jsonb_array_elements(p_rules) loop
    i := i + 1; f := r->>'field'; op := r->>'op'; k := _policy_fields() -> f ->> 'kind';
    if k is null then raise exception 'الشرط %: حقل غير معروف «%»', i, coalesce(f, '—'); end if;
    select coalesce(jsonb_agg(distinct x), '[]') into sc from jsonb_array_elements_text(case when jsonb_typeof(r->'sectors') = 'array' then r->'sectors' else '[]' end) x where trim(x) <> '';
    if k = 'num' then
      if op not in ('gte', 'lte') then raise exception 'الشرط % (%): المقارنة «لا يقل عن» أو «لا يزيد على»', i, _policy_fields() -> f ->> 'label'; end if;
      if coalesce(r->>'value', '') !~ '^[0-9]+(\.[0-9]+)?$' then raise exception 'الشرط % (%): اكتب رقماً', i, _policy_fields() -> f ->> 'label'; end if;
      out := out || (jsonb_build_object('field', f, 'op', op, 'value', (r->>'value')::numeric, 'text', left(coalesce(r->>'text', ''), 400))
        || case when jsonb_array_length(sc) > 0 then jsonb_build_object('sectors', sc) else '{}' end);
    else
      if op not in ('in', 'not_in') then raise exception 'الشرط % (%): المقارنة «تقبل فقط» أو «لا تقبل»', i, _policy_fields() -> f ->> 'label'; end if;
      select coalesce(jsonb_agg(distinct x), '[]') into vals from jsonb_array_elements_text(case when jsonb_typeof(r->'value') = 'array' then r->'value' else '[]' end) x where trim(x) <> '';
      if jsonb_array_length(vals) = 0 then raise exception 'الشرط % (%): اختر قيمة واحدة على الأقل', i, _policy_fields() -> f ->> 'label'; end if;
      out := out || (jsonb_build_object('field', f, 'op', op, 'value', vals, 'text', left(coalesce(r->>'text', ''), 400))
        || case when jsonb_array_length(sc) > 0 then jsonb_build_object('sectors', sc) else '{}' end);
    end if;
  end loop;
  if jsonb_array_length(out) > 60 then raise exception 'السياسة تتجاوز 60 شرطاً'; end if;
  return out;
end $$;

create or replace function public._policy_gate() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_bank uuid; v_old uuid; v_submit boolean := false; pol bank_policies; ctx jsonb; ev jsonb; alts jsonb; v_name text; p jsonb;
begin
  if coalesce((select value from settings where key = 'policy_gate'), 1) = 0 then return new; end if;
  if auth.uid() is null or new.citizen_id is null or auth.uid() <> new.citizen_id then return new; end if;
  if new.status not in ('active', 'returned') then return new; end if;
  v_bank := coalesce(nullif(new.bank_choice->>'bank_id', '')::uuid, new.bank_id);
  if v_bank is null then return new; end if;
  if tg_op = 'UPDATE' then
    v_old := coalesce(nullif(old.bank_choice->>'bank_id', '')::uuid, old.bank_id);
    -- الجلسة 62b: الإرسال الأول فقط — إعادة الإرسال بعد إرجاع المصرف لا تُفحص من جديد
    v_submit := old.stage <= 5 and new.stage >= 6 and old.submitted_at is null and old.returned_from is null and old.status <> 'returned';
    if v_bank is not distinct from v_old and not v_submit then return new; end if;
  end if;
  pol := _policy_active(v_bank);
  if pol.id is null then return new; end if;
  ctx := _policy_ctx_app(new, v_bank);
  if not v_submit then ctx := ctx - 'guarantee'; end if;
  ev := _policy_eval(pol.rules, ctx);
  if ev->>'result' = 'fail' then
    p := jsonb_build_object('amount', ctx->'amount', 'term', ctx->'term', 'program', new.program, 'purpose', new.purpose, 'governorate', new.governorate,
      'guarantee', case when v_submit then new.guarantee_type end);
    alts := _policy_alternatives(new.citizen_id, v_bank, p);
    select name into v_name from orgs where id = v_bank;
    raise exception 'POLICY_REJECT: طلبك لا يطابق السياسة الائتمانية لدى «%» (الإصدار %): %.%', v_name, pol.version,
      (select string_agg(x->>'msg', '؛ ') from jsonb_array_elements(ev->'fails') x),
      case when jsonb_array_length(alts) > 0 then ' ننصحك بالتقديم لدى: ' || (select string_agg('«' || (x->>'name') || '»', '، ') from jsonb_array_elements(alts) x) || '.'
        else ' لا يوجد الآن مصرف آخر يطابق طلبك سياسته — جرّب مبلغاً أقل أو مدة أطول.' end
      using errcode = 'P0001';
  end if;
  insert into policy_checks(bank_id, policy_id, citizen_id, application_id, kind, result, fails, ctx)
  values (v_bank, pol.id, new.citizen_id, case when tg_op = 'UPDATE' then new.id end, 'gate', ev->>'result', '[]', ctx);
  return new;
end $$;

-- سياسة السنابل التجريبية: شرط نوع العمل للمنظومات الشمسية فقط (الإصدار 1 كما هو إن عدّلته الإدارة العليا)
update public.bank_policies b set
  rules = (select jsonb_agg(case when r->>'field' = 'employment' then r || '{"sectors":["residential","agricultural","industrial","project","vet","export","other"]}'::jsonb else r end order by o)
           from jsonb_array_elements(b.rules) with ordinality t(r, o)),
  policy_text = replace(policy_text, 'ولا يُقبل أصحاب العمل الحر.', 'ولا يُقبل أصحاب العمل الحر في تمويل المنظومات الشمسية.')
where b.bank_id = (select id from orgs where code = 'bank1') and b.version = 1 and b.status = 'active'
  and position('"sectors"' in b.rules::text) = 0;
update public.bank_policies b set sha256 = encode(extensions.digest(policy_text || rules::text, 'sha256'), 'hex')
where b.bank_id = (select id from orgs where code = 'bank1') and b.version = 1;

reset check_function_bodies;
