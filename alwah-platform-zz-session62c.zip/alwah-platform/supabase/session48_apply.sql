-- ألواح — الجلسة 48: قطاع مستقل لكل برنامج مصرف في لوحات التخطيط والمالية والبنك المركزي وديوان الرقابة
-- كانت طلبات برامج المصارف (المصدّرون، التجاري، التجارة الإلكترونية) تُحسب «سكنية» لأن غرضها الافتراضي household.
-- الآن قاعدة واحدة للقطاع (_app_sector) تستعملها كل اللوحات، وكل برنامج قطاع قائم بذاته.
-- آمن للتكرار: كل استبدال يُطبَّق مرة واحدة ويُتحقَّق منه.

-- ═══ 1) قاعدة القطاع الموحدة ═══
create or replace function public._app_sector(p_program text, p_purpose text) returns text
language sql immutable set search_path = public as $$
  select case p_program
    when 'vet' then 'vet_program'
    when 'export' then 'export_program'
    when 'commercial' then 'commercial_program'
    when 'ecommerce' then 'ecommerce_program'
    else case when p_purpose is null or p_purpose = 'household' then 'residential' else p_purpose end end $$;

-- ═══ 2) استبدال التعبير المكرر في الدوال الحية ═══
do $mig$
declare
  r record; src text; dst text; n int;
begin
  for r in select * from (values
    ('public._plan_apps(text,text)',
     $x$case when a.program = 'vet' then 'vet_program' when a.purpose is null or a.purpose = 'household' then 'residential' else a.purpose end$x$,
     $x$_app_sector(a.program, a.purpose)$x$),
    ('public.finance_overview()',
     $x$case when x.program = 'vet' then 'vet_program' when x.purpose is null or x.purpose = 'household' then 'residential' else x.purpose end$x$,
     $x$_app_sector(x.program, x.purpose)$x$),
    -- سعر الكيلوواط من المنظومات الشمسية فقط (لا البيطري ولا البرامج)
    ('public.finance_overview()',
     $x$where a.program is distinct from 'vet' and coalesce(a.kw, 0) > 0$x$,
     $x$where coalesce(a.program, 'solar') = 'solar' and coalesce(a.kw, 0) > 0$x$),
    ('public.cbi_analytics()',
     $x$case when a.program = 'vet' then 'vet_program' when coalesce(a.purpose, 'household') = 'household' then 'residential' else a.purpose end$x$,
     $x$_app_sector(a.program, a.purpose)$x$),
    ('public.audit_overview(integer,uuid)',
     $x$case when x.program = 'vet' then 'vet_program' when x.purpose is null or x.purpose = 'household' then 'residential' else x.purpose end$x$,
     $x$_app_sector(x.program, x.purpose)$x$),
    -- أهداف وزارة التخطيط والمبادرات تقبل القطاعات الجديدة
    ('public.planning_save_goal(jsonb,text)',
     $x$'vet_program', 'export', 'other')$x$,
     $x$'vet_program', 'export_program', 'commercial_program', 'ecommerce_program', 'export', 'other')$x$),
    ('public.cbi_publish_initiative(jsonb)',
     $x$'other', 'vet_program'))$x$,
     $x$'other', 'vet_program', 'export_program', 'commercial_program', 'ecommerce_program'))$x$)
  ) v(fn, old, new) loop
    src := pg_get_functiondef(r.fn::regprocedure);
    if position(r.new in src) > 0 then continue; end if;   -- طُبّق سابقاً
    n := (length(src) - length(replace(src, r.old, ''))) / length(r.old);
    if n <> 1 then raise exception 'الجلسة 48: النص المطلوب استبداله في % وُجد % مرة (المتوقع مرة واحدة)', r.fn, n; end if;
    dst := replace(src, r.old, r.new);
    execute dst;
  end loop;
end $mig$;
