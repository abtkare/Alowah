-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 56: اتحاد الغرف التجارية العراقية + «رئيس الاتحاد» بدل «الأمين العام»
--  1) قاعدة ثابتة: صاحب الصلاحية في أي اتحاد هو «رئيس الاتحاد»، وفي النقابة «النقيب».
--     يُصحَّح ذلك في اتحاد الصناعات القائم (نصوص الدوال فقط — الكتب الصادرة سابقاً مختومة ببصمتها فلا تُمس).
--  2) جهة جديدة نوعها chamber «اتحاد الغرف التجارية العراقية» وبوابة /chamber:
--     رئيس الاتحاد (chamber_pres) ولجنة التصنيف والحسابات في المقر، وغرفة تجارة لكل محافظة (فرع)
--     فيها رئيس الغرفة (chamber_head — يدير فريق غرفته ويقرّر في معاملات محافظته) وموظف التسجيل ومفتش الغرفة.
--     موظفو الغرفة يرون معاملات محافظتهم وأعضاءها فقط؛ المقر يرى الكل.
--  3) دورة العضوية والخدمات منسوخة آلياً من دوال اتحاد الصناعات الحية (الجلسات 52–54) بعد تحويل الأسماء والنصوص:
--     هوية الغرفة التجارية FCC-…، الانتساب بالمستمسكات، التجديد، كتاب تأييد العضوية، البدل، التحديث، الإلغاء، التحقق /v/CC…
--  4) القرض التجاري (برامج commercial): الخطوة 2 «محلك وهوية الغرفة التجارية»، والخطوة 3 تفتح معاملة تأييد في غرفة المحافظة،
--     والخطوة 5 تنتظر كتاب التأييد ثم تُضاف أجور الغرفة إلى الدفعة. الطلبات التجارية القديمة (قبل هذه الجلسة) لا تتأثر.
--  5) «بوابة التجار» /merchant للتاجر (حساب شخصي portal = citizen) — واجهة فقط.
-- الملف آمن للتكرار. تعديل الدوال القائمة يتم داخل القاعدة باستبدال نص يقع مرة واحدة.
-- ═══════════════════════════════════════════════════════════════════════
set check_function_bodies = off;

-- ───────── 1) رئيس الاتحاد بدل الأمين العام (اتحاد الصناعات) ─────────
do $mig$
declare r record; src text; dst text;
begin
  for r in select p.oid from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f'
             and (p.proname ~ '^(union_|_un_|_union_)' or p.proname = '_role_title') loop
    src := pg_get_functiondef(r.oid);
    if position('لأمين العام' in src) = 0 then continue; end if;
    dst := replace(replace(src, 'للأمين العام', 'لرئيس الاتحاد'), 'الأمين العام', 'رئيس الاتحاد');
    execute dst;
  end loop;
end $mig$;

-- ───────── 2) نوع الجهة والبوابة ─────────
do $mig$
declare d text;
begin
  select pg_get_constraintdef(oid) into d from pg_constraint where conrelid = 'public.orgs'::regclass and conname = 'orgs_type_check';
  if position('''chamber''' in d) = 0 then
    execute 'alter table public.orgs drop constraint orgs_type_check';
    execute 'alter table public.orgs add constraint orgs_type_check ' || replace(d, '''union''::text', '''union''::text, ''chamber''::text');
  end if;
  select pg_get_constraintdef(oid) into d from pg_constraint where conrelid = 'public.profiles'::regclass and conname = 'profiles_portal_check';
  if position('''chamber''' in d) = 0 then
    execute 'alter table public.profiles drop constraint profiles_portal_check';
    execute 'alter table public.profiles add constraint profiles_portal_check ' || replace(d, '''union''::text', '''union''::text, ''chamber''::text');
  end if;
end $mig$;

-- الإعدادات: نسخة من إعدادات اتحاد الصناعات بمفاتيح chamber_
insert into public.settings(key, value, label, circular_no)
select replace(key, 'union_', 'chamber_'), value,
  replace(replace(replace(replace(label, 'اتحاد الصناعات', 'الغرف التجارية'), 'الهوية الصناعية', 'هوية الغرفة'), 'التأييد الصناعي', 'تأييد الغرفة'), 'بدء الإنتاج', 'مزاولة النشاط'), null
from public.settings where key like 'union\_%'
on conflict (key) do nothing;

-- ───────── 3) الجداول ─────────
create table if not exists public.chamber_members (
  id uuid primary key default gen_random_uuid(),
  code text unique,                                   -- رقم هوية الغرفة التجارية FCC-2026-00001
  org_id uuid references public.orgs(id),
  citizen_id uuid references public.profiles(id),
  owner_name text not null, national_id text, phone text,
  factory_name text not null,                         -- اسم المحل أو الشركة التجارية
  category text not null check (category in ('food','construction','electrical','vehicles','textile','medical','agri','fuel','general','services','other')),
  legal_form text not null default 'individual' check (legal_form in ('individual','company')),
  governorate text not null, city text, address text, site_geo jsonb,
  trade_name_no text,                                 -- رقم السجل التجاري (شرط الانتساب)
  dev_license_no text, dev_license_kind text check (dev_license_kind is null or dev_license_kind in ('under','complete')),   -- إجازة ممارسة النشاط أو الاستيراد (اختياري)
  capital bigint, workers int, products text, capacity text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','suspended','expired','cancelled')),
  joined_at date, valid_until date, verify_code text unique, seal text,
  decided_by_name text, decided_at timestamptz, reason text,
  card_version int not null default 1, old_codes text[] not null default '{}', reminders jsonb not null default '{}'::jsonb, renewed_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists chamber_members_citizen on public.chamber_members(citizen_id);

create table if not exists public.chamber_files (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                          -- CF-2026-00001
  org_id uuid references public.orgs(id),
  kind text not null check (kind in ('membership','endorse','install','production','followup','renewal','update','certificate','replace','cancel')),
  member_id uuid references public.chamber_members(id),
  application_id uuid references public.applications(id),
  status text not null default 'new' check (status in ('draft','new','returned','inspection','committee','signing','issued','delivered','done','rejected','cancelled')),
  engineer_id uuid references public.profiles(id), engineer_name text,
  amount bigint, fee bigint not null default 0, fee_paid_at timestamptz, fee_ref text,
  inspection jsonb, committee jsonb, decision jsonb, appeal jsonb,
  return_note text, returned_by text,
  origin text, note text, due_at timestamptz, meta jsonb not null default '{}'::jsonb,
  created_by_name text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), closed_at timestamptz
);
create index if not exists chamber_files_app on public.chamber_files(application_id);
create index if not exists chamber_files_member on public.chamber_files(member_id);

create table if not exists public.chamber_docs (
  id uuid primary key default gen_random_uuid(),
  file_id uuid references public.chamber_files(id), member_id uuid references public.chamber_members(id),
  kind text not null, label text, mime text, data text, bytes int, sha256 text, meta jsonb not null default '{}'::jsonb,
  uploaded_by uuid, uploaded_by_name text, created_at timestamptz not null default now(), valid_until date
);
create index if not exists chamber_docs_file on public.chamber_docs(file_id);
create index if not exists chamber_docs_member on public.chamber_docs(member_id);

create table if not exists public.chamber_letters (
  id uuid primary key default gen_random_uuid(),
  no text unique not null,                            -- FCC/OUT/2026/00001
  file_id uuid references public.chamber_files(id), member_id uuid references public.chamber_members(id),
  application_id uuid references public.applications(id), bank_id uuid references public.orgs(id),
  kind text not null check (kind in ('membership','endorse','install','production','followup','renewal','update','certificate','replace','cancel')),
  title text not null, body jsonb not null, sha256 text not null, verify_code text unique not null,
  issued_by uuid, issued_by_name text, issued_by_title text, issued_at timestamptz not null default now(), valid_until date,
  revoked_at timestamptz, revoke_reason text, revoked_by_name text, superseded_by uuid,
  ack_at timestamptz, ack_by_name text, ack_by_title text, ack_no text
);
create index if not exists chamber_letters_app on public.chamber_letters(application_id);

create table if not exists public.chamber_log (
  id bigserial primary key, file_id uuid, member_id uuid, letter_id uuid,
  actor_id uuid, actor_name text, actor_title text, action text not null, note text, created_at timestamptz not null default now()
);
create index if not exists chamber_log_file on public.chamber_log(file_id);

alter table public.chamber_members enable row level security;
alter table public.chamber_files enable row level security;
alter table public.chamber_docs enable row level security;
alter table public.chamber_letters enable row level security;
alter table public.chamber_log enable row level security;
drop policy if exists cm_read on public.chamber_members;
create policy cm_read on public.chamber_members for select to authenticated using (my_portal() = 'chamber' or citizen_id = auth.uid());
drop policy if exists cf_read on public.chamber_files;
create policy cf_read on public.chamber_files for select to authenticated
  using (my_portal() = 'chamber' or exists (select 1 from chamber_members m where m.id = member_id and m.citizen_id = auth.uid()));
drop policy if exists cl_read on public.chamber_letters;
create policy cl_read on public.chamber_letters for select to authenticated
  using (my_portal() = 'chamber' or exists (select 1 from chamber_members m where m.id = member_id and m.citizen_id = auth.uid()));
grant select on public.chamber_members, public.chamber_files, public.chamber_letters to authenticated;
revoke all on public.chamber_docs, public.chamber_log from anon, authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'chamber_files') then
      alter publication supabase_realtime add table public.chamber_files; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'chamber_letters') then
      alter publication supabase_realtime add table public.chamber_letters; end if;
  end if;
end $$;

-- ───────── 4) نطاق غرفة المحافظة ─────────
-- موظف المقر (بلا فرع) يرى كل المحافظات؛ موظف غرفة المحافظة يرى محافظة غرفته فقط
create or replace function public._cc_gov_ok(me profiles, p_gov text) returns boolean language sql stable security definer set search_path = public as $f$
  select me.branch_id is null or exists (select 1 from branches b where b.id = me.branch_id and p_gov = any(coalesce(b.governorates, '{}'))) $f$;
create or replace function public._cc_scope_ok(me profiles, p_member uuid) returns boolean language sql stable security definer set search_path = public as $f$
  select me.branch_id is null or exists (select 1 from chamber_members m join branches b on b.id = me.branch_id
    where m.id = p_member and m.governorate = any(coalesce(b.governorates, '{}'))) $f$;

-- ───────── 5) نسخ دوال اتحاد الصناعات الحية إلى اتحاد الغرف التجارية ─────────
do $mig$
declare r record; src text; i int;
  -- التحويلات بالترتيب: المعرّفات أولاً ثم النصوص العربية (الأطول قبل الأقصر)
  map text[][] := array[
    ['_union_act52', '_chamber_act52'], ['_union_file52', '_chamber_file52'],
    ['union_', 'chamber_'], ['_un_', '_cc_'], ['''union''', '''chamber'''], ['chamber_sg', 'chamber_pres'],
    ['industrial', 'commercial'], ['IFI', 'FCC'], ['''IF''', '''CC'''], ['''UF''', '''CF'''], ['''ifi''', '''fcc'''],
    ['ind_trade_name', 'com_trade_reg'], ['ind_lease', 'com_lease'], ['ind_dev_license', 'com_license'], ['env_approval', 'tax_clearance'], ['machines_list', 'goods_list'],
    ['/industry', '/merchant'],
    ['اتحاد الصناعات العراقي', 'اتحاد الغرف التجارية العراقية'], ['اتحاد الصناعات', 'اتحاد الغرف التجارية'], ['بوابة الصناعيين', 'بوابة التجار'],
    ['رقم تسجيل الاسم التجاري لدى غرفة الصناعة', 'رقم السجل التجاري'], ['تسجيل الاسم التجاري لدى غرفة الصناعة', 'السجل التجاري'],
    ['إجازة التأسيس من المديرية العامة للتنمية الصناعية', 'إجازة ممارسة النشاط أو الاستيراد'],
    ['هويتك الصناعية', 'هوية غرفتك التجارية'], ['الهويات الصناعية', 'هويات الغرفة التجارية'], ['الهوية الصناعية', 'هوية الغرفة التجارية'], ['هوية صناعية', 'هوية غرفة تجارية'],
    ['التأييد الصناعي', 'تأييد الغرفة التجارية'], ['تأييد صناعي', 'تأييد تجاري'], ['القروض الصناعية', 'القروض التجارية'], ['القرض الصناعي', 'القرض التجاري'],
    ['لجنة الصنف الصناعي', 'لجنة التصنيف'], ['لجنة الصنف', 'لجنة التصنيف'],
    ['مهندس الكشف الصناعي', 'مفتش الغرفة'], ['مهندس الكشف', 'مفتش الغرفة'], ['مهندسو', 'مفتشو'], ['المهندس', 'المفتش'], ['مهندس', 'مفتش'],
    ['نصب المكائن', 'تجهيز المحل'], ['المكائن', 'المعدات والبضائع'], ['مكائن', 'معدات'], ['بدء الإنتاج', 'مزاولة النشاط'], ['الإنتاج', 'النشاط'],
    ['المعمل', 'المحل'], ['معمل', 'محل'], ['المصنع', 'الشركة'],
    ['الصناعيين', 'التجار'], ['الصناعية', 'التجارية'], ['صناعية', 'تجارية'], ['للصناعي', 'للتاجر'], ['الصناعي', 'التاجر'], ['غرفة الصناعة', 'غرفة التجارة'],
    ['الصناعات', 'الأنشطة التجارية'], ['الصناعة', 'التجارة'], ['صناعي', 'تجاري'],
    ['الصنف', 'النشاط'], ['المنتجات', 'البضائع'],
    -- رئيس الغرفة يقرّر في محافظته كما يقرّر رئيس الاتحاد
    ['in (''chamber_reg'', ''chamber_pres'')', 'in (''chamber_reg'', ''chamber_pres'', ''chamber_head'')'],
    ['in (''chamber_committee'', ''chamber_pres'')', 'in (''chamber_committee'', ''chamber_pres'', ''chamber_head'')'],
    ['in (''chamber_pres'', ''chamber_reg'', ''chamber_fin'')', 'in (''chamber_pres'', ''chamber_head'', ''chamber_reg'', ''chamber_fin'')'],
    ['in (''chamber_pres'', ''chamber_reg'')', 'in (''chamber_pres'', ''chamber_head'', ''chamber_reg'')'],
    ['r = ''chamber_pres''', 'r in (''chamber_pres'', ''chamber_head'')'],
    ['me.role <> ''chamber_pres''', 'me.role not in (''chamber_pres'', ''chamber_head'')'],
    ['لرئيس الاتحاد', 'لرئيس الاتحاد أو رئيس الغرفة'],
    -- نطاق غرفة المحافظة
    ['f.org_id <> me.org_id', '(f.org_id <> me.org_id or not _cc_scope_ok(me, f.member_id))'],
    ['f.org_id = me.org_id', '(f.org_id = me.org_id and _cc_scope_ok(me, f.member_id))'],
    ['m.org_id = me.org_id', '(m.org_id = me.org_id and _cc_gov_ok(me, m.governorate))'],
    ['from chamber_files where org_id = me.org_id', 'from chamber_files where org_id = me.org_id and _cc_scope_ok(me, member_id)'],
    ['p.org_id = me.org_id and p.role = ''chamber_eng''', 'p.org_id = me.org_id and p.role = ''chamber_eng'' and (me.branch_id is null or p.branch_id is not distinct from me.branch_id)']
  ];
begin
  for r in select p.oid, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' and p.proname ~ '^(union_|_un_|_union_)' order by p.proname loop
    src := pg_get_functiondef(r.oid);
    for i in 1 .. array_length(map, 1) loop src := replace(src, map[i][1], map[i][2]); end loop;
    execute src;
  end loop;
end $mig$;

-- ───────── 6) ما يختلف عن اتحاد الصناعات (يُعاد تعريفه بعد النسخ) ─────────
-- أنشطة التجار
create or replace function public._cc_cat_label(c text) returns text language sql immutable as $f$
  select case c when 'food' then 'المواد الغذائية' when 'construction' then 'المواد الإنشائية' when 'electrical' then 'الأجهزة الكهربائية والإلكترونية'
    when 'vehicles' then 'السيارات والآليات وقطع الغيار' when 'textile' then 'الأقمشة والملابس' when 'medical' then 'المستلزمات الطبية والصيدلانية'
    when 'agri' then 'المواد والمستلزمات الزراعية' when 'fuel' then 'المشتقات النفطية والزيوت' when 'general' then 'التجارة العامة والاستيراد'
    when 'services' then 'الخدمات التجارية' when 'other' then 'أنشطة تجارية أخرى' end $f$;

create or replace function public._cc_doc_label(k text) returns text language sql immutable as $f$
  select case k when 'id_front' then 'البطاقة الوطنية — الوجه' when 'id_back' then 'البطاقة الوطنية — الظهر' when 'id_card' then 'البطاقة الوطنية لصاحب المحل'
    when 'residence' then 'بطاقة السكن' when 'photo' then 'صورة شخصية حديثة' when 'com_trade_reg' then 'شهادة السجل التجاري أو تسجيل الاسم التجاري'
    when 'com_lease' then 'عقد إيجار المحل أو سند ملكيته' when 'com_license' then 'إجازة ممارسة النشاط أو إجازة الاستيراد'
    when 'factory_photo' then 'صورة واجهة المحل من الخارج' when 'company_contract' then 'عقد تأسيس الشركة وشهادة تسجيلها'
    when 'tax_clearance' then 'براءة الذمة الضريبية' when 'goods_list' then 'قائمة البضائع أو فواتير الشراء' when 'other' then 'مستند آخر' end $f$;

create or replace function public._cc_req_docs(m chamber_members) returns text[] language sql immutable as $f$
  select array['id_front','id_back','residence','photo','com_trade_reg','com_lease','factory_photo']
    || case when coalesce(m.dev_license_no, '') <> '' then array['com_license'] else array[]::text[] end
    || case when m.legal_form = 'company' then array['company_contract'] else array[]::text[] end $f$;

-- الإشعار: موظفو الغرفة لمعاملات محافظتهم فقط، والمقر للكل؛ وما ينتظر قرار رئيس الاتحاد يصل رئيس غرفة المحافظة أيضاً
create or replace function public._cc_notify(p_roles text[], p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path = public as $f$
declare o uuid := _cc_org(); g text; n int := 0; k int;
begin
  if o is null then return; end if;
  select m.governorate into g from chamber_files f join chamber_members m on m.id = f.member_id where f.id = p_ref;
  if g is null then select governorate into g from chamber_members where id = p_ref; end if;
  insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
  select o, p.id, 'chamber', 'chamber', p_title, p_body, p_ref from profiles p
  where p.org_id = o and not coalesce(p.disabled, false)
    and (p.role = any(p_roles) or ('chamber_pres' = any(p_roles) and p.role = 'chamber_head'))
    and (g is null or _cc_gov_ok(p, g))
    and (p.role <> 'chamber_head' or p.branch_id is not null);
  get diagnostics k = row_count; n := n + k;
  if n = 0 then perform _notify(o, 'chamber', 'chamber', p_title, p_body, p_ref); end if;
end $f$;

-- القرض التجاري: لا مكائن تُنصب؛ بعد الصرف تأييد مزاولة النشاط، وعند إلغاء الطلب تُغلق المعاملات المفتوحة
create or replace function public._cc_on_app() returns trigger language plpgsql security definer set search_path = public as $f$
declare m uuid;
begin
  if new.program is distinct from 'commercial' then return null; end if;
  m := nullif(new.biz->>'member_id', '')::uuid;
  if m is null or not exists (select 1 from chamber_members where id = m) then return null; end if;
  if new.stage > 35 and old.stage <= 35
     and not exists (select 1 from chamber_files where application_id = new.id and kind = 'production' and status <> 'cancelled') then
    begin
      perform _cc_new_file('production', m, new.id, 'inspection', new.amount, 0, 'آلياً — بعد صرف القرض ' || new.code, null, null);
    exception when others then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('chamber_unassigned', 'medium', 'تعذّر إسناد كشف مزاولة النشاط لغرفة التجارة', new.code || ': ' || sqlerrm, new.id, coalesce(new.governorate, ''));
    end;
  end if;
  if new.status in ('cancelled', 'rejected') and old.status is distinct from new.status then
    update chamber_files set status = 'cancelled', closed_at = now(), updated_at = now(), note = coalesce(note || ' · ', '') || 'أُلغي طلب القرض'
    where application_id = new.id and status in ('new', 'returned', 'inspection', 'committee', 'signing');
  end if;
  return null;
end $f$;

-- لا إرسال للقرض التجاري (المقدَّم بعد هذه الجلسة) دون كتاب تأييد نافذ من غرفة التجارة
create or replace function public._com_guard() returns trigger language plpgsql security definer set search_path = public as $f$
begin
  if new.program is distinct from 'commercial' or new.stage <= old.stage or not (coalesce(new.biz, '{}') ? 'chamber_mode') then return new; end if;
  if old.stage <= 5 and new.stage >= 6 and not _cc_letter_ok(new.id) then
    raise exception 'القرض التجاري: لا يُرسل الطلب دون كتاب تأييد نافذ من غرفة التجارة'; end if;
  return new;
end $f$;

-- خطوات المقترض في القرض التجاري (فوق _trade_step)
create or replace function public._com_step(p_app uuid, p_step integer, p_data jsonb) returns applications
language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications; m chamber_members; v_mode text; v_cat text; v_no text; r applications; f chamber_files; pay payments;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  p_data := coalesce(p_data, '{}'::jsonb);

  if p_step = 2 then
    if not (p_data ? 'chamber_mode') then return _trade_step(p_app, p_step, p_data); end if;   -- واجهة قديمة
    v_mode := p_data->>'chamber_mode';
    v_cat := p_data->>'category';
    if _cc_cat_label(v_cat) is null then raise exception 'اختر نوع النشاط التجاري'; end if;
    if length(trim(coalesce(p_data->>'factory_name', ''))) < 3 then raise exception 'اكتب اسم المحل أو الشركة'; end if;
    if length(trim(coalesce(p_data->>'products', ''))) < 3 then raise exception 'اكتب البضائع أو الخدمات التي تتاجر بها'; end if;
    if length(trim(coalesce(p_data->>'trade_name_no', ''))) < 2 then raise exception 'اكتب رقم السجل التجاري'; end if;
    if _cc_org() is null then raise exception 'اتحاد الغرف التجارية غير مضاف إلى المنصة بعد'; end if;
    if v_mode = 'member' then
      v_no := upper(trim(coalesce(p_data->>'chamber_no', '')));
      select * into m from chamber_members where code = v_no;
      if m.id is null then raise exception 'رقم هوية الغرفة التجارية % غير موجود في السجل — تأكد منه، أو اختر «لست عضواً بعد»', v_no; end if;
      if m.citizen_id is distinct from me.id and m.national_id is distinct from me.national_id then raise exception 'هوية الغرفة التجارية % ليست باسمك', v_no; end if;
      if m.status = 'suspended' then raise exception 'عضويتك في غرفة التجارة معلّقة — راجع الغرفة'; end if;
      if m.status = 'expired' or (m.status = 'approved' and m.valid_until < current_date) then raise exception 'هوية غرفتك التجارية منتهية منذ % — جدّدها من «بوابة التجار» ثم عُد', m.valid_until; end if;
      if m.status <> 'approved' then raise exception 'عضويتك ما زالت قيد الدراسة لدى الغرفة — اختر «لست عضواً بعد» ليُدرس انتسابك مع القرض'; end if;
      update chamber_members set citizen_id = me.id, updated_at = now() where id = m.id and citizen_id is null;
    elsif v_mode = 'new' then
      select * into m from chamber_members where citizen_id = me.id and status in ('approved', 'pending') order by (status = 'approved') desc, created_at desc limit 1;
      if m.status = 'approved' and m.valid_until >= current_date then raise exception 'لديك هوية غرفة تجارية نافذة (%) — اختر «عضو في الغرفة» واكتب رقمها', m.code; end if;
      if m.id is null then
        insert into chamber_members(org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address,
          trade_name_no, dev_license_no, capital, workers, products)
        values (_cc_org(), me.id, me.full_name, me.national_id, me.phone, trim(p_data->>'factory_name'), v_cat, coalesce(nullif(p_data->>'legal_form', ''), 'individual'),
          coalesce(nullif(p_data->>'governorate', ''), a.governorate), nullif(trim(coalesce(p_data->>'city', '')), ''), nullif(trim(coalesce(p_data->>'address', '')), ''),
          trim(p_data->>'trade_name_no'), nullif(trim(coalesce(p_data->>'dev_license_no', '')), ''),
          nullif(regexp_replace(coalesce(p_data->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint, nullif(regexp_replace(coalesce(p_data->>'workers', ''), '[^0-9]', '', 'g'), '')::int,
          trim(p_data->>'products'))
        returning * into m;
      elsif m.status = 'pending' then
        update chamber_members set factory_name = trim(p_data->>'factory_name'), category = v_cat, governorate = coalesce(nullif(p_data->>'governorate', ''), governorate),
          city = nullif(trim(coalesce(p_data->>'city', '')), ''), address = nullif(trim(coalesce(p_data->>'address', '')), ''),
          trade_name_no = trim(p_data->>'trade_name_no'), dev_license_no = nullif(trim(coalesce(p_data->>'dev_license_no', '')), ''),
          workers = nullif(regexp_replace(coalesce(p_data->>'workers', ''), '[^0-9]', '', 'g'), '')::int, products = trim(p_data->>'products'), updated_at = now()
        where id = m.id returning * into m;
      end if;
    else
      raise exception 'حدّد: هل أنت عضو في غرفة التجارة؟';
    end if;
    r := _trade_step(p_app, 2, p_data || jsonb_build_object('business_name', trim(p_data->>'factory_name'), 'activity', _cc_cat_label(v_cat) || ' — ' || trim(p_data->>'products'),
      'reg_no', coalesce(m.code, trim(p_data->>'trade_name_no')), 'employees', p_data->>'workers'));
    update applications set biz = coalesce(biz, '{}') || jsonb_build_object('member_id', m.id, 'chamber_no', m.code, 'chamber_mode', v_mode,
      'category', v_cat, 'category_label', _cc_cat_label(v_cat), 'products', trim(p_data->>'products'), 'trade_name_no', trim(p_data->>'trade_name_no'),
      'dev_license_no', nullif(trim(coalesce(p_data->>'dev_license_no', '')), ''), 'new_member', m.status <> 'approved')
    where id = a.id returning * into r;
    update chamber_files set member_id = m.id, updated_at = now() where application_id = a.id and kind = 'endorse' and status in ('new', 'returned') and member_id is distinct from m.id;
    return r;
  end if;

  -- الطلبات التجارية التي لم تمر بخطوة الغرفة (قبل هذه الجلسة) تبقى على مسارها
  if not (coalesce(a.biz, '{}') ? 'chamber_mode') then return _trade_step(p_app, p_step, p_data); end if;

  if p_step = 3 then
    r := _trade_step(p_app, 3, p_data);
    perform _cc_sync(a.id);
    return r;
  elsif p_step = 5 then
    if not _cc_letter_ok(a.id) then
      select * into f from chamber_files where application_id = a.id and kind = 'endorse' and status <> 'cancelled' order by created_at desc limit 1;
      raise exception 'بانتظار كتاب التأييد من غرفة التجارة (%: %) — يصلك إشعار حين يصدر', coalesce(f.code, '—'), _cc_status_label(coalesce(f.status, 'new'));
    end if;
    r := _trade_step(p_app, 5, p_data);
    select * into pay from payments where application_id = a.id and status = 'paid' order by paid_at desc nulls last limit 1;
    update chamber_files set fee_paid_at = now(), fee_ref = pay.ref where application_id = a.id and kind = 'endorse' and status in ('issued', 'delivered') and fee_paid_at is null;
    return r;
  end if;
  return _trade_step(p_app, p_step, p_data);
end $f$;

-- ───────── 7) الحرّاس والمحفّزات ─────────
drop trigger if exists trg_a1_com_guard on public.applications;
create trigger trg_a1_com_guard before update of stage on public.applications for each row execute function public._com_guard();
drop trigger if exists trg_cc_on_app on public.applications;
create trigger trg_cc_on_app after update on public.applications for each row execute function public._cc_on_app();
drop trigger if exists trg_cc_staff_gov on public.profiles;
create trigger trg_cc_staff_gov before insert or update of branch_id, portal on public.profiles for each row execute function public._cc_staff_gov();
do $d$
declare t text;
begin
  if to_regprocedure('public._face_gate()') is null then return; end if;
  foreach t in array array['chamber_members', 'chamber_files', 'chamber_letters', 'chamber_docs'] loop
    execute format('drop trigger if exists trg_zz_face_gate on public.%I', t);
    execute format('create trigger trg_zz_face_gate after insert or update or delete on public.%I for each row execute function public._face_gate()', t);
  end loop;
end $d$;

-- ───────── 8) الدوال المشتركة (استبدال نص يقع مرة واحدة) ─────────
do $mig$
declare r record; src text; n int;
begin
  for r in select * from (values
    ('public._org_roles(text)',
     $x$    when 'union' then array['union_reg', 'union_eng', 'union_committee', 'union_fin', 'union_sg']$x$,
     $x$    when 'union' then array['union_reg', 'union_eng', 'union_committee', 'union_fin', 'union_sg']
    when 'chamber' then array['chamber_head', 'chamber_reg', 'chamber_eng', 'chamber_committee', 'chamber_fin', 'chamber_pres']$x$),
    ('public._portal_of_role(text)',
     $x$when r in ('union_sg', 'union_reg', 'union_eng', 'union_committee', 'union_fin') then 'union'$x$,
     $x$when r in ('union_sg', 'union_reg', 'union_eng', 'union_committee', 'union_fin') then 'union'
    when r in ('chamber_pres', 'chamber_head', 'chamber_reg', 'chamber_eng', 'chamber_committee', 'chamber_fin') then 'chamber'$x$),
    ('public._org_type_of_portal(text)',
     $x$when 'union' then 'union'$x$,
     $x$when 'union' then 'union' when 'chamber' then 'chamber'$x$),
    ('public._role_abbr(text)',
     $x$when 'union_sg' then 'SG'$x$,
     $x$when 'chamber_pres' then 'CP' when 'chamber_head' then 'CH' when 'chamber_reg' then 'CR' when 'chamber_eng' then 'CI' when 'chamber_committee' then 'CC' when 'chamber_fin' then 'CF'
    when 'union_sg' then 'SG'$x$),
    ('public._role_title(text)',
     $x$when 'platform_admin' then 'مشغّل النظام$x$,
     $x$when 'chamber_pres' then 'رئيس الاتحاد — اتحاد الغرف التجارية العراقية' when 'chamber_head' then 'رئيس غرفة التجارة في المحافظة'
    when 'chamber_reg' then 'موظف التسجيل والعضوية — غرفة التجارة' when 'chamber_eng' then 'مفتش الغرفة — الكشف على المحال التجارية'
    when 'chamber_committee' then 'عضو لجنة التصنيف — اتحاد الغرف التجارية' when 'chamber_fin' then 'موظف الحسابات — اتحاد الغرف التجارية'
    when 'platform_admin' then 'مشغّل النظام$x$),
    ('public.public_brand(text)',
     $x$'trade','sharia','union')$x$,
     $x$'trade','sharia','union','chamber')$x$),
    ('public.citizen_step(uuid,integer,jsonb)',
     $x$if a.program = 'industrial' then return _ind_step(p_app, p_step, p_data); end if;$x$,
     $x$if a.program = 'industrial' then return _ind_step(p_app, p_step, p_data); end if;
    if a.program = 'commercial' then return _com_step(p_app, p_step, p_data); end if;   -- الجلسة 56$x$),
    ('public.pay_application_fees(uuid,uuid,text,text)',
     $x$|| _un_fee_items(a.id))$x$,
     $x$|| _un_fee_items(a.id) || _cc_fee_items(a.id))$x$),
    ('public._has_branches(text)',
     $x$select p_type in ('bank', 'insurer', 'union')$x$,
     $x$select p_type in ('bank', 'insurer', 'union', 'chamber')$x$),
    ('public.team_readiness()',
     $x$'insurer', 'union') then return null; end if;$x$,
     $x$'insurer', 'union', 'chamber') then return null; end if;$x$),
    ('public.team_save_branch(jsonb)',
     $x$ومكاتب المحافظات للأمين العام لاتحاد الصناعات$x$,
     $x$ومكاتب المحافظات لرئيس اتحاد الصناعات، وغرف المحافظات لرئيس اتحاد الغرف التجارية$x$),
    ('public._branch_roles_of(text)',
     $x$when 'insurer' then array['ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance']$x$,
     $x$when 'insurer' then array['ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance'] when 'chamber' then array['chamber_reg', 'chamber_eng', 'chamber_fin']$x$),
    ('public._is_branch_mgr_role(text)',
     $x$('bank_branch_mgr', 'ins_branch_mgr')$x$,
     $x$('bank_branch_mgr', 'ins_branch_mgr', 'chamber_head')$x$),
    ('public.team_meta()',
     $x$when m.manage_scope = 'org' and o.type = 'insurer' then '["branch"]'::jsonb$x$,
     $x$when m.manage_scope = 'org' and o.type in ('insurer', 'chamber') then '["branch"]'::jsonb$x$),
    ('public.team_meta()',
     $x$when 'insurer' then 'ins_branch_mgr' end$x$,
     $x$when 'insurer' then 'ins_branch_mgr' when 'chamber' then 'chamber_head' end$x$),
    ('public.team_create_user(jsonb)',
     $x$if o.type = 'insurer' and v_role = 'ins_branch_mgr' and v_br is null then raise exception 'مدير الفرع مربوط بفرع — اختر الفرع'; end if;$x$,
     $x$if o.type = 'insurer' and v_role = 'ins_branch_mgr' and v_br is null then raise exception 'مدير الفرع مربوط بفرع — اختر الفرع'; end if;
  if o.type = 'chamber' and v_role = 'chamber_head' and v_br is null then raise exception 'رئيس الغرفة مربوط بغرفة محافظة — اختر الغرفة'; end if;$x$),
    ('public._onboard_kind(text)',
     $x$    when 'union'          then '{"type":"union","portal":"union","role":"union_sg","title":"اتحاد صناعات / غرفة صناعة"}'::jsonb$x$,
     $x$    when 'union'          then '{"type":"union","portal":"union","role":"union_sg","title":"اتحاد صناعات / غرفة صناعة"}'::jsonb
    when 'chamber'        then '{"type":"chamber","portal":"chamber","role":"chamber_pres","title":"اتحاد الغرف التجارية"}'::jsonb$x$),
    ('public._org_readiness(uuid)',
     $x$  elsif o.type = 'union' then$x$,
     $x$  elsif o.type = 'chamber' then   -- الجلسة 56: اتحاد الغرف التجارية — أقسام المقر، وكل غرفة محافظة فيها فريق
    foreach r in array array['chamber_committee','chamber_fin'] loop
      if _org_has(o.id, r) then done := done || jsonb_build_array(_role_title(r));
      else miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r)); end if;
    end loop;
    for b in select id, name from branches br where br.bank_id = o.id and exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false)) order by code loop
      foreach r in array array['chamber_head','chamber_reg','chamber_eng'] loop
        if not _org_has(o.id, r, b.id, false) then miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r, 'branch', b.id, 'branch_name', b.name)); end if;
      end loop;
    end loop;
    if exists (select 1 from branches br where br.bank_id = o.id and not exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false))) then
      warn := warn || jsonb_build_array('غرف بلا فريق بعد (يخدم المقر معاملاتها): ' || (select string_agg(br.name, '، ' order by br.code) from branches br where br.bank_id = o.id
        and not exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false)))); end if;
    if not exists (select 1 from branches where bank_id = o.id) then
      warn := warn || '["لا توجد غرف محافظات — أضفها من «فريقي ← غرف المحافظات»"]'::jsonb; end if;
    v_routable := jsonb_array_length(miss) = 0;

  elsif o.type = 'union' then$x$)
  ) v(fn, old, new) loop
    if to_regprocedure(r.fn) is null then raise exception 'الجلسة 56: الدالة % غير موجودة', r.fn; end if;
    src := pg_get_functiondef(r.fn::regprocedure);
    if position(r.new in src) > 0 then continue; end if;   -- طُبّق سابقاً
    n := (length(src) - length(replace(src, r.old, ''))) / length(r.old);
    if n <> 1 then raise exception 'الجلسة 56: النص المطلوب استبداله في % وُجد % مرة (المتوقع مرة واحدة)', r.fn, n; end if;
    execute replace(src, r.old, r.new);
  end loop;
end $mig$;

-- ───────── 9) الصلاحيات ─────────
do $g$
declare r record;
begin
  for r in select p.oid::regprocedure::text sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' and p.proname ~ '^(chamber_|_cc_|_chamber_|_com_)' loop
    if r.proname = 'chamber_verify' then
      execute 'revoke all on function ' || r.sig || ' from public';
      execute 'grant execute on function ' || r.sig || ' to anon, authenticated';
    elsif r.proname ~ '^_' and r.proname <> '_cc_cat_label' then
      execute 'revoke all on function ' || r.sig || ' from public, anon, authenticated';
    else
      execute 'revoke all on function ' || r.sig || ' from public, anon';
      execute 'grant execute on function ' || r.sig || ' to authenticated';
    end if;
  end loop;
end $g$;

-- ───────── 10) بيانات العرض ─────────
insert into public.orgs(code, type, name, meta)
select 'fcc', 'chamber', 'اتحاد الغرف التجارية العراقية', '{"hq": "بغداد", "demo": true}'::jsonb
where not exists (select 1 from public.orgs where code = 'fcc');

-- غرفة تجارة لكل محافظة
do $$
declare o uuid := (select id from public.orgs where code = 'fcc'); g text; pre text; k int := 0;
begin
  if o is null then return; end if;
  pre := public._staff_prefix(o);
  foreach g in array array['بغداد','البصرة','نينوى','أربيل','النجف','كربلاء','بابل','ذي قار','الأنبار','ديالى','واسط','ميسان','الديوانية','صلاح الدين','كركوك','المثنى','السليمانية','دهوك'] loop
    k := k + 1;
    if not exists (select 1 from public.branches where bank_id = o and name = 'غرفة تجارة ' || g) then
      insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone)
      values (o, pre || '-' || lpad(k::text, 2, '0'), 'غرفة تجارة ' || g, array[g], false, null);
    end if;
  end loop;
end $$;

-- الفريق: المقر (رئيس الاتحاد، لجنة التصنيف، الحسابات) وغرف بغداد والبصرة والنجف (رئيس الغرفة، التسجيل، المفتش)
do $$
declare o uuid := (select id from public.orgs where code = 'fcc'); r text[]; uid uuid; pres uuid; br uuid;
  rows text[][] := array[
  -- اسم الدخول، كلمة المرور، الاسم، الدور، المحافظة/الغرفة (فارغ = المقر)، نطاق الإدارة
  ['chamber.pres', 'Fcc@2026pr', 'د. ماجد حسين الصفار',      'chamber_pres',      '',       'org'],
  ['chamber.cmt',  'Fcc@2026cm', 'هدى فاضل العبيدي',          'chamber_committee', '',       ''],
  ['chamber.fin',  'Fcc@2026fn', 'عمار جاسم الزبيدي',         'chamber_fin',       '',       ''],
  ['bgd.head',     'Fcc@2026bh', 'عبد الكريم رشيد البياتي',    'chamber_head',      'بغداد',  'branch'],
  ['bgd.reg',      'Fcc@2026br', 'لمى سعد الجنابي',           'chamber_reg',       'بغداد',  ''],
  ['bgd.insp',     'Fcc@2026bi', 'حيدر علي الكعبي',           'chamber_eng',       'بغداد',  ''],
  ['bsr.head',     'Fcc@2026sh', 'فيصل عبد الواحد التميمي',   'chamber_head',      'البصرة', 'branch'],
  ['bsr.reg',      'Fcc@2026sr', 'رنا محمد السعد',            'chamber_reg',       'البصرة', ''],
  ['bsr.insp',     'Fcc@2026si', 'مصطفى كاظم الأسدي',         'chamber_eng',       'البصرة', ''],
  ['njf.head',     'Fcc@2026nh', 'محمد جواد الحكيم',          'chamber_head',      'النجف',  'branch'],
  ['njf.reg',      'Fcc@2026nr', 'زهراء حسن الخزاعي',         'chamber_reg',       'النجف',  ''],
  ['njf.insp',     'Fcc@2026ni', 'علي رضا الطائي',            'chamber_eng',       'النجف',  '']];
  i int;
begin
  if o is null then return; end if;
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'chamber', 'fcc', null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    select id into pres from public.profiles where username = 'chamber.pres';
    br := case when rows[i][5] = '' then null else (select id from public.branches where bank_id = o and name = 'غرفة تجارة ' || rows[i][5]) end;
    update public.profiles set branch_id = br, governorate = coalesce(nullif(rows[i][5], ''), 'بغداد'), manage_scope = nullif(rows[i][6], ''), must_change_password = false,
      managed_by = case when rows[i][1] <> 'chamber.pres' then coalesce(managed_by, case when rows[i][4] = 'chamber_head' then pres
        else coalesce((select id from public.profiles where branch_id = br and role = 'chamber_head' and br is not null limit 1), pres) end) end
    where id = uid;
  end loop;
end $$;

-- تجار العرض: trader1 عضو نافذ في بغداد (يقدّم على قرض تجاري)، trader2 طلب انتساب وارد إلى غرفة البصرة، trader3 بلا عضوية في النجف
do $$
declare o uuid := (select id from public.orgs where code = 'fcc'); c1 uuid; c2 uuid; c3 uuid; m chamber_members; f chamber_files;
begin
  if o is null then return; end if;
  if not exists (select 1 from profiles where username = 'trader1') then
    c1 := _mk_user('trader1', 'Alwah@1101', 'أحمد عبد الحسين الربيعي', 'citizen', 'citizen', null, '07701234511', '198004150011');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'بغداد', city = 'الشورجة', employer = 'صاحب محل تجاري',
      monthly_salary = 3000000, birth_date = '1980-04-15', must_change_password = false where id = c1;
  end if;
  if not exists (select 1 from profiles where username = 'trader2') then
    c2 := _mk_user('trader2', 'Alwah@1102', 'نور الهدى قاسم العيداني', 'citizen', 'citizen', null, '07701234512', '199002200012');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'البصرة', city = 'العشار', employer = 'صاحبة محل تجاري',
      monthly_salary = 1900000, birth_date = '1990-02-20', must_change_password = false where id = c2;
  end if;
  if not exists (select 1 from profiles where username = 'trader3') then
    c3 := _mk_user('trader3', 'Alwah@1103', 'حسين علي الموسوي', 'citizen', 'citizen', null, '07701234513', '198709090013');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'النجف', city = 'النجف', employer = 'تاجر',
      monthly_salary = 2500000, birth_date = '1987-09-09', must_change_password = false where id = c3;
  end if;
  select id into c1 from profiles where username = 'trader1';
  select id into c2 from profiles where username = 'trader2';

  if not exists (select 1 from chamber_members where citizen_id = c1) then
    insert into chamber_members(code, org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address, site_geo,
      trade_name_no, capital, workers, products, status, joined_at, valid_until, verify_code, decided_by_name, decided_at)
    values (_vet_seq('FCC', 'chamber_members', 'code'), o, c1, 'أحمد عبد الحسين الربيعي', '198004150011', '07701234511', 'مخازن الربيعي للمواد الغذائية', 'food', 'individual',
      'بغداد', 'الشورجة', 'شارع الرشيد — سوق الشورجة، قرب جامع الخلفاء', '{"lat":33.3409,"lng":44.3986,"acc":15}', 'TR-BGD-118204', 250000000, 7,
      'رز وسكر وزيوت وبقوليات بالجملة', 'approved', current_date - 150, current_date + 215, _cc_vcode(), 'عبد الكريم رشيد البياتي', now() - interval '150 days')
    returning * into m;
    perform _cc_reseal(m.id);
    perform _cc_log(null, m.id, null, 'انتساب سابق (بيانات العرض)', 'هوية نافذة — يقدّم على قرض تجاري من بوابة المقترض');
  end if;

  if not exists (select 1 from chamber_members where citizen_id = c2) then
    insert into chamber_members(org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address,
      trade_name_no, capital, workers, products)
    values (o, c2, 'نور الهدى قاسم العيداني', '199002200012', '07701234512', 'معرض العيداني للأجهزة الكهربائية', 'electrical', 'individual',
      'البصرة', 'العشار', 'شارع الوطني — مقابل سوق المغايز', 'TR-BSR-77310', 90000000, 3, 'أجهزة منزلية ومكيفات ومولدات صغيرة')
    returning * into m;
    insert into chamber_files(code, org_id, kind, member_id, status, fee, fee_paid_at, fee_ref, origin, due_at, created_by_name)
    values (_vet_seq('CF', 'chamber_files', 'code'), o, 'membership', m.id, 'new', coalesce(_setting('chamber_member_fee'), 50000)::bigint, now() - interval '1 day',
      'RCPT-FCC-0091', 'طلب انتساب من بوابة التجار (بيانات العرض)', now() + interval '6 days', 'نور الهدى قاسم العيداني')
    returning * into f;
    perform _cc_log(f.id, m.id, null, 'فتح معاملة: انتساب وهوية غرفة تجارية', 'بيانات العرض — بانتظار التدقيق والإحالة في غرفة تجارة البصرة');
  end if;
end $$;

reset check_function_bodies;
