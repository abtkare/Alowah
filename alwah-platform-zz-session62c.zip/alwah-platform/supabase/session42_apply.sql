-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 42: جاهزية الجهة قبل أن يصلها العمل
-- المشكلة: الجهة التي يضيفها المشغّل تبدأ بحساب الإدارة العليا وحده. شركة التأمين أو الفحص الجديدة كانت «الأقل انشغالاً»
-- فتصلها الطلبات الآلية فوراً وليس فيها من يعمل عليها، والمصرف يمكن تفعيل استقباله للطلبات وليس فيه موظف لمرحلة.
-- الحل:
--  1) _org_readiness(org): ما ينقص الجهة (لكل قسم، ولكل فرع) — يراه المشغّل في بطاقة الجهة، والإدارة العليا في «فريقي».
--  2) شركات التأمين والفحص لا يُسند إليها عمل آلي حتى تكتمل، وفرع التأمين المختار هو الفرع المكتمل الذي يغطي المحافظة.
--  3) لا يُفعَّل «يستقبل طلبات عبر المنصة» لمصرف ناقص.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- هل في الجهة موظف فعّال بهذا الدور؟ (p_branch: في الفرع نفسه أو في الإدارة العامة بلا فرع)
create or replace function public._org_has(p_org uuid, p_role text, p_branch uuid default null, p_hq_ok boolean default true) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from profiles p where p.org_id = p_org and p.role = p_role and not coalesce(p.disabled, false)
    and (p_branch is null or p.branch_id = p_branch or (p_hq_ok and p.branch_id is null))) $f$;

-- الجاهزية: {ok, routable, missing:[{t, role, branch, branch_name}], warn:[...], done:[...]}
--  ok       = لا نقص يمنع العمل
--  routable = يمكن أن يُسند إليها عمل آلي (للتأمين: فرع مكتمل واحد على الأقل)
create or replace function public._org_readiness(p_org uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare o orgs; miss jsonb := '[]'; warn jsonb := '[]'; done jsonb := '[]'; r text; b record; ok_br int := 0; v_sp text; v_n int; v_routable boolean;
begin
  select * into o from orgs where id = p_org;
  if o.id is null then return null; end if;

  if o.type = 'bank' then
    -- أدوار الإدارة العامة: كل مرحلة يملكها دور في المصرف (عدا مراحل الفرع)
    foreach r in array array['bank_compliance','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection','bank_legal','bank_md','bank_ops','bank_admin']
      || case when coalesce(o.is_islamic, false) then array['bank_islamic_products'] else array[]::text[] end loop
      if _org_has(o.id, r) then done := done || jsonb_build_array(_role_title(r));
      else miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r)); end if;
    end loop;
    -- أدوار الفرع: في كل فرع
    if not exists (select 1 from branches where bank_id = o.id) then miss := miss || '[{"t":"لا يوجد فرع — أضف فرعاً من «فريقي ← الفروع»"}]'::jsonb; end if;
    for b in select id, name from branches where bank_id = o.id order by is_main desc, code loop
      foreach r in array array['bank_cs','bank_branch_mgr','bank_teller'] loop
        if not _org_has(o.id, r, b.id, false) then miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r, 'branch', b.id, 'branch_name', b.name)); end if;
      end loop;
    end loop;
    if not _org_has(o.id, 'bank_collection') then warn := warn || '["لا يوجد موظف تحصيل ومتابعة (يحتاجه المصرف بعد صرف القروض)"]'::jsonb; end if;
    if not _org_has(o.id, 'bank_payroll') then warn := warn || '["لا يوجد موظف توطين الرواتب (للاستقطاع المباشر)"]'::jsonb; end if;
    v_routable := jsonb_array_length(miss) = 0;

  elsif o.type = 'insurer' then
    if not exists (select 1 from ins_products where org_id = o.id and active) then
      miss := miss || '[{"t":"لا يوجد منتج تأمين فعّال — راجع «المنتجات والأسعار»"}]'::jsonb; end if;
    if not exists (select 1 from branches where bank_id = o.id) then miss := miss || '[{"t":"لا يوجد فرع — أضف فرعاً من «فريقي ← الفروع»"}]'::jsonb; end if;
    -- كل فرع يحتاج: الاكتتاب والمعاين والحسابات (في الفرع أو في الإدارة العامة). الاعتماد: مدير الفرع أو الإدارة العليا.
    for b in select id, name from branches where bank_id = o.id order by is_main desc, code loop
      v_n := 0;
      foreach r in array array['ins_underwriter','ins_surveyor','ins_finance'] loop
        if not _org_has(o.id, r, b.id) then v_n := v_n + 1;
          miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r, 'branch', b.id, 'branch_name', b.name)); end if;
      end loop;
      if v_n = 0 then ok_br := ok_br + 1; end if;
      if not _org_has(o.id, 'ins_branch_mgr', b.id, false) then warn := warn || jsonb_build_array('فرع ' || b.name || ': لا يوجد مدير فرع — كل الاعتمادات تذهب للإدارة العليا'); end if;
    end loop;
    if not _org_has(o.id, 'ins_claims') then warn := warn || '["لا يوجد موظف مطالبات — يُحتاج عند الإبلاغ عن ضرر"]'::jsonb; end if;
    v_routable := ok_br > 0 and exists (select 1 from ins_products where org_id = o.id and active) and not coalesce((o.meta->>'suspended')::boolean, false);
    if ok_br > 0 and jsonb_array_length(miss) > 0 then warn := warn || jsonb_build_array('تصل الطلبات إلى الفروع المكتملة فقط (' || ok_br || ')'); end if;

  elsif o.type = 'eng_audit' then
    select count(*) into v_n from profiles p join eng_staff s on s.profile_id = p.id
      where p.org_id = o.id and not coalesce(p.disabled, false) and cardinality(s.specialties) > 0;
    if v_n = 0 then miss := miss || '[{"t":"مهندس فاحص بتخصص محدد — أضفه من «فريقي» ثم حدد تخصصه من «الفريق والتخصصات»","role":"auditor_engineer"}]'::jsonb; end if;
    foreach v_sp in array array['pv','electrical','civil','medical','production'] loop
      if not exists (select 1 from profiles p join eng_staff s on s.profile_id = p.id
                     where p.org_id = o.id and not coalesce(p.disabled, false) and v_sp = any(s.specialties)) then
        warn := warn || jsonb_build_array('لا يوجد مهندس بتخصص «' || _eng_spec_label(v_sp) || '» — بنوده تبقى بانتظار التوزيع'); end if;
    end loop;
    v_routable := v_n > 0 and not coalesce((o.meta->>'suspended')::boolean, false);

  elsif o.type = 'supplier' then
    if not _org_has(o.id, 'supplier_admin') then miss := miss || '[{"t":"مدير حساب المورد","role":"supplier_admin"}]'::jsonb; end if;
    if not exists (select 1 from supplier_offers where supplier_id = o.id and status = 'published') then
      miss := miss || '[{"t":"لا توجد عروض منشورة — لا يراه المقترضون حتى ينشر عرضاً"}]'::jsonb; end if;
    if not _org_has(o.id, 'supplier_tech') then warn := warn || '["لا يوجد فني تركيب — يُنجز المدير التركيب بنفسه"]'::jsonb; end if;
    v_routable := jsonb_array_length(miss) = 0;
  else
    return jsonb_build_object('ok', true, 'routable', true, 'missing', '[]'::jsonb, 'warn', '[]'::jsonb);
  end if;

  return jsonb_build_object('ok', jsonb_array_length(miss) = 0, 'routable', coalesce(v_routable, false), 'missing', miss, 'warn', warn, 'done', done);
end $f$;

-- للمشغّل: جاهزية كل الجهات المُدارة
create or replace function public.admin_orgs_readiness() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return (select coalesce(jsonb_object_agg(id, _org_readiness(id)), '{}') from orgs where type in ('bank', 'supplier', 'eng_audit', 'insurer'));
end $f$;

-- للإدارة العليا ومديري الفروع: جاهزية جهتي (مدير الفرع يرى نواقص فرعه فقط)
create or replace function public.team_readiness() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare m profiles := _mgr(); o orgs; r jsonb;
begin
  select * into o from orgs where id = m.org_id;
  if o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then return null; end if;
  r := _org_readiness(o.id);
  if m.manage_scope = 'branch' then
    r := r || jsonb_build_object('missing', (select coalesce(jsonb_agg(x), '[]') from jsonb_array_elements(r->'missing') x where x->>'branch' = m.branch_id::text), 'warn', '[]'::jsonb);
  elsif m.manage_scope = 'dept' then
    r := r || jsonb_build_object('missing', (select coalesce(jsonb_agg(x), '[]') from jsonb_array_elements(r->'missing') x where x->>'role' = any(_dept_roles(m.role))), 'warn', '[]'::jsonb);
  end if;
  return r || jsonb_build_object('ok', jsonb_array_length(r->'missing') = 0, 'scope', m.manage_scope, 'org_type', o.type, 'accepting', case when o.type = 'bank' then coalesce((o.meta->>'accepting')::boolean, true) end);
end $f$;

-- ───────── الإسناد الآلي: للجهات الجاهزة فقط ─────────
-- فرع التأمين المكتمل (الاكتتاب والمعاين والحسابات في الفرع أو الإدارة العامة)
create or replace function public._ins_branch_ready(p_org uuid, p_branch uuid) returns boolean language sql stable security definer set search_path to 'public' as $f$
  select _org_has(p_org, 'ins_underwriter', p_branch) and _org_has(p_org, 'ins_surveyor', p_branch) and _org_has(p_org, 'ins_finance', p_branch) $f$;

create or replace function public._ins_pick_org(p_gov text) returns uuid language sql stable security definer set search_path to 'public' as $f$
  select o.id from orgs o where o.type = 'insurer' and not coalesce((o.meta->>'suspended')::boolean, false)
    and (jsonb_array_length(coalesce(o.meta->'governorates', '[]')) = 0 or o.meta->'governorates' ? p_gov)
    and exists (select 1 from ins_products x where x.org_id = o.id and x.active)
    and exists (select 1 from branches b where b.bank_id = o.id and _ins_branch_ready(o.id, b.id))
  order by (select count(*) from ins_policies x where x.org_id = o.id and x.status in ('new', 'survey', 'pricing', 'approval')), o.created_at limit 1 $f$;

-- الفرع المكتمل الذي يغطي المحافظة، وإلا الرئيسي المكتمل، وإلا أي فرع مكتمل؛ وإن لم يكتمل فرع (طلب يدوي من المصرف) فالسلوك السابق
create or replace function public._ins_pick_branch(p_org uuid, p_gov text) returns uuid language sql stable security definer set search_path to 'public' as $f$
  select id from branches where bank_id = p_org
  order by _ins_branch_ready(p_org, id) desc, (p_gov = any(coalesce(governorates, '{}'))) desc, is_main desc, code limit 1 $f$;

create or replace function public._eng_pick_org(p_gov text) returns uuid
language sql stable security definer set search_path to 'public' as $f$
  select o.id from orgs o
  where o.type = 'eng_audit' and coalesce((o.meta->>'suspended')::boolean, false) is false
    and (jsonb_array_length(coalesce(o.meta->'governorates', '[]')) = 0 or (o.meta->'governorates') ? p_gov)
    and exists (select 1 from profiles p join eng_staff s on s.profile_id = p.id
                where p.org_id = o.id and not coalesce(p.disabled, false) and cardinality(s.specialties) > 0)
  order by (select count(*) from eng_inspections i where i.org_id = o.id and i.status not in ('done', 'cancelled')), o.created_at
  limit 1 $f$;

-- طلب التأمين اليدوي من المصرف: إن اختار المصرف شركة غير مكتملة يُرفض بسبب واضح
create or replace function public._ins_assert_ready(p_org uuid) returns void language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if p_org is not null and exists (select 1 from orgs where id = p_org and type = 'insurer')
     and not exists (select 1 from branches b where b.bank_id = p_org and _ins_branch_ready(p_org, b.id)) then
    raise exception 'شركة التأمين هذه لم تُكمل حسابات موظفيها بعد (الاكتتاب والمعاينة والحسابات) — اختر شركة أخرى';
  end if;
end $f$;

create or replace function public.ins_request(p_app uuid, p_org uuid, p_note text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
declare me profiles; a applications; v_org uuid := p_org; pol ins_policies;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me.portal <> 'bank' or me.org_id is distinct from a.bank_id or coalesce(me.disabled, false) then raise exception 'طلب التأمين لموظفي المصرف صاحب الطلب'; end if;
  if a.stage < 8 then raise exception 'يُطلب التأمين بعد الموافقة المبدئية'; end if;
  if v_org is null then v_org := _ins_pick_org(a.governorate); end if;
  if v_org is null then raise exception 'لا توجد شركة تأمين معتمدة مكتملة الموظفين تغطي محافظة %', coalesce(a.governorate, ''); end if;
  perform _ins_assert_ready(v_org);   -- الجلسة 42
  pol := _ins_create(a.id, v_org, 'bank', p_note, me.position_title);
  perform _ev(a.id, a.stage, 'طلب تأمين ' || pol.code, (select name from orgs where id = v_org) || coalesce(' · ' || nullif(trim(coalesce(p_note, '')), ''), ''));
  return jsonb_build_object('ok', true, 'code', pol.code, 'company', (select name from orgs where id = v_org), 'branch', (select name from branches where id = pol.branch_id));
end $function$;

-- ───────── المصرف: لا يُفعَّل الاستقبال وهو ناقص ─────────
create or replace function public.admin_set_bank(p_bank uuid, p jsonb)
 RETURNS bank_terms LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $function$
declare bt bank_terms; v_sup uuid[]; rd jsonb;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into bt from bank_terms where bank_id = p_bank;
  if bt is null then raise exception 'المصرف غير موجود'; end if;
  if p ? 'margin' and ((p->>'margin')::numeric < 0 or (p->>'margin')::numeric > _setting('margin_max')) then raise exception 'عوائد المصرف بين 0 و% بالمئة حسب سياسة التمويل', _setting('margin_max'); end if;
  if p ? 'commission_pct' and ((p->>'commission_pct')::numeric < 0 or (p->>'commission_pct')::numeric > 5) then raise exception 'عمولة المصرف بين 0 و5 بالمئة'; end if;
  if p ? 'max_term_months' and ((p->>'max_term_months')::int < 12 or (p->>'max_term_months')::int > 120) then raise exception 'أقصى مدة بين 12 و120 شهراً'; end if;
  if p ? 'file_fee' and (p->>'file_fee')::bigint < 0 then raise exception 'رسم الملف غير صحيح'; end if;
  -- الجلسة 42: تفعيل الاستقبال لمصرف ينقصه موظفو مرحلة يوقف الطلبات عنده
  if coalesce((p->>'accepting')::boolean, false) and exists (select 1 from orgs where id = p_bank and coalesce((meta->>'accepting')::boolean, true) = false) then
    rd := _org_readiness(p_bank);
    if not (rd->>'ok')::boolean then
      raise exception 'لا يمكن تفعيل الاستقبال — ينقص المصرف: %', (select string_agg(x->>'t' || coalesce(' (' || (x->>'branch_name') || ')', ''), '، ') from (select x from jsonb_array_elements(rd->'missing') x limit 6) q);
    end if;
  end if;
  if p ? 'suppliers' then
    select coalesce(array_agg(x::uuid), '{}') into v_sup from jsonb_array_elements_text(coalesce(p->'suppliers', '[]'::jsonb)) x;
    if exists (select 1 from unnest(v_sup) s where not exists (select 1 from orgs where id = s and type = 'supplier')) then raise exception 'مورد غير معروف'; end if;
  end if;
  update bank_terms set margin = coalesce((p->>'margin')::numeric, margin), commission_pct = coalesce((p->>'commission_pct')::numeric, commission_pct),
    file_fee = coalesce((p->>'file_fee')::bigint, file_fee), max_term_months = coalesce((p->>'max_term_months')::int, max_term_months),
    processing_days = coalesce((p->>'processing_days')::int, processing_days), single_approval_cap = coalesce((p->>'single_approval_cap')::bigint, single_approval_cap),
    suppliers = case when p ? 'suppliers' then nullif(v_sup, '{}') else suppliers end
  where bank_id = p_bank returning * into bt;
  if p ? 'accepting' then update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('accepting', (p->>'accepting')::boolean) where id = p_bank; end if;
  perform _audit('تعديل شروط مصرف', (select name from orgs where id = p_bank), p);
  return bt;
end $function$;

revoke all on function public._org_has(uuid, text, uuid, boolean), public._org_readiness(uuid), public._ins_branch_ready(uuid, uuid), public._ins_assert_ready(uuid) from public, anon, authenticated;
grant execute on function public.admin_orgs_readiness(), public.team_readiness() to authenticated;
