-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 45: هيئة الرقابة الشرعية في المصرف — قرارات المستخدم
--  • نصاب هيئة المصرف 3 (حداً أدنى وافتراضياً عند الإنشاء)، ويُرفع نصاب الهيئات القائمة إليه.
--  • أمين السر شرط لاكتمال هيئة المصرف (بملاءمة معتمدة)، ولا يحيل أو يعيد الملفات قبل ملاءمته.
--  • الملاءمة قرار الهيئة المركزية وحدها، والبنك المركزي يُبلَّغ بكل ترشيح وقرار للاطلاع فقط،
--    ويرى «سجل الملاءمة» في «الامتثال الشرعي»، ويظهر للهيئة المركزية متى اطّلع.
--  • العرض: عضو ثالث بملاءمة في هيئة الواحة (wsh.m3) صوّت على «منظومة المزرعة بالمرابحة»، فيبقى صوت الرئيس وقراره.
--  • الأسماء تجريبية (قرار المستخدم: لا حاجة لأسماء حقيقية).
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) الأعمدة ─────────
alter table public.sharia_members add column if not exists cbi_seen_at timestamptz;
alter table public.sharia_members add column if not exists cbi_seen_by text;

-- ───────── 2) النصاب الأدنى واكتمال هيئة المصرف ─────────
create or replace function public._sh_bank_min_quorum() returns int language sql immutable as $f$ select 3 $f$;

-- اكتمال هيئة المصرف: رئيس بملاءمة + أمين سر بملاءمة + مصوّتون بقدر النصاب (الجلسة 45: أمين السر شرط)
create or replace function public._sh_board_ready(p_board uuid) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_head' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))
    and exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_secretary' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))
    and _sh_voters(p_board) >= coalesce((select quorum from sharia_boards where id = p_board), 99) $f$;

create or replace function public._sh_board_missing(p_board uuid) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select 'رئيس الهيئة بملاءمة معتمدة' x where not exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_head' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))
    union all
    select 'أعضاء مصوّتون بملاءمة: ' || _sh_voters(p_board) || ' من ' || b.quorum || ' (النصاب)' from sharia_boards b where b.id = p_board and _sh_voters(p_board) < b.quorum
    union all
    select 'أمين سر الهيئة بملاءمة معتمدة' where not exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_secretary' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))) z $f$;

-- ───────── 3) الدوال المعدّلة (إنشاء الهيئة، الإعدادات، الملاءمة، الترشيح، تحقق أمين السر) ─────────
create or replace function public.sharia_board_create(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare me profiles; c sharia_boards; bk orgs; o orgs; b sharia_boards; v_code text; v_name text; v_q int := coalesce(nullif(p->>'quorum', '')::int, _sh_bank_min_quorum());
  m jsonb := coalesce(p->'head', '{}'::jsonb); v_user text; uid uuid; i int := 0;
begin
  me := _sh_central_head();
  c := _sh_central();
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  select * into bk from orgs where id = nullif(p->>'bank_id', '')::uuid;
  if bk.id is null or bk.type <> 'bank' then raise exception 'اختر المصرف'; end if;
  if not coalesce(bk.is_islamic, false) then raise exception 'هيئة الرقابة الشرعية للمصارف الإسلامية فقط (النوافذ الإسلامية في المصارف التجارية ليست في المرحلة الأولى)'; end if;
  if exists (select 1 from sharia_boards where scope = 'bank' and bank_id = bk.id) then raise exception 'لهذا المصرف هيئة مسبقاً'; end if;
  if v_q < _sh_bank_min_quorum() or v_q > 9 then raise exception 'نصاب هيئة المصرف بين % و9', _sh_bank_min_quorum(); end if;
  v_name := coalesce(nullif(trim(p->>'name'), ''), 'هيئة الرقابة الشرعية — ' || bk.name);
  if length(v_name) < 6 then raise exception 'اكتب اسم الهيئة'; end if;
  -- حساب رئيس الهيئة (بالشروط نفسها لحساب الإدارة العليا لأي جهة)
  v_user := lower(trim(coalesce(m->>'username', '')));
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم مستخدم الرئيس: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم «%» مستخدم مسبقاً', v_user; end if;
  if length(coalesce(m->>'password', '')) < 8 or (m->>'password') !~ '[0-9]' or (m->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if length(trim(coalesce(m->>'full_name', ''))) < 3 then raise exception 'اكتب اسم رئيس الهيئة'; end if;
  -- جهة الهيئة (بوابة /sharia)
  v_code := 'sh' || left(regexp_replace(bk.code, '[^a-z0-9]', '', 'g'), 6);
  while exists (select 1 from orgs where code = v_code) loop i := i + 1; v_code := 'sh' || left(regexp_replace(bk.code, '[^a-z0-9]', '', 'g'), 5) || i; end loop;
  insert into orgs(code, type, name, is_islamic, meta) values (v_code, 'sharia', v_name, false,
    jsonb_build_object('kind', 'sharia_bank', 'bank_id', bk.id, 'onboarded_at', now(), 'onboarded_by', me.full_name)) returning * into o;
  insert into sharia_boards(code, name, scope, org_id, bank_id, madhhab, marja, quorum, majority, chair_casting, review_months, late_kind, late_rule, parent_id, created_by_name)
  values ('SHB-' || upper(bk.code), v_name, 'bank', o.id, bk.id, c.madhhab, c.marja, v_q, 'simple', true, c.review_months, c.late_kind, c.late_rule, c.id, me.full_name)
  returning * into b;
  uid := _mk_user(v_user, m->>'password', trim(m->>'full_name'), 'sharia_head', 'sharia', o.code, _opt_phone(m->>'phone'), null);
  update profiles set manage_scope = 'org', must_change_password = true, managed_by = me.id where id = uid;
  -- الرئيس عيّنته الهيئة المركزية: ملاءمته معتمدة بقرار الإنشاء
  update sharia_members set fit_status = 'approved', fit_code = _sh_fit_code(), fit_by_name = me.full_name, fit_at = now(),
    fit_note = 'عيّنته ' || c.name || ' عند إنشاء الهيئة', specialty = nullif(trim(coalesce(m->>'specialty', '')), '')
  where board_id = b.id and profile_id = uid;
  perform _sh_board_log(b.id, 'إنشاء الهيئة وتعيين رئيسها: ' || trim(m->>'full_name'), 'النصاب ' || v_q || ' · تكتمل بأعضاء مصوّتين وأمين سر بملاءمة معتمدة');
  perform _sh_board_log(c.id, 'إنشاء ' || v_name, bk.name);
  perform _audit('إنشاء هيئة رقابة شرعية لمصرف', v_name, jsonb_build_object('bank', bk.name, 'code', b.code, 'head', v_user));
  perform _sh_notify(bk.id, 'bank', array['bank_md', 'bank_islamic_products'], 'sharia_bank', 'أُنشئت ' || v_name,
    'تعتمد منتجات مصرفكم بعد اكتمال أعضائها وملاءمتهم وتفعيل النطاق المصرفي. الاعتمادات الحالية تبقى نافذة.', b.id);
  -- الجلسة 45: البنك المركزي يُبلَّغ بقرارات الملاءمة للاطلاع فقط
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_fit', 'للاطلاع: أُنشئت ' || v_name,
    'عيّنت ' || c.name || ' رئيسها: ' || trim(m->>'full_name') || ' — ملاءمة معتمدة. النصاب ' || v_q, b.id);
  return jsonb_build_object('board', b.code, 'name', v_name, 'org', o.code, 'username', v_user, 'portal', 'sharia');
end $f$;

create or replace function public.sharia_settings(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; q int; rm int; v_scope text;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إعدادات الهيئة لرئيسها'; end if;
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1 for update;
  q := coalesce(nullif(p->>'quorum', '')::int, b.quorum); rm := coalesce(nullif(p->>'review_months', '')::int, b.review_months);
  if q < 1 or q > greatest(_sh_voters(b.id), case when b.scope = 'bank' then 9 else 1 end) then raise exception 'النصاب بين 1 وعدد الأعضاء المصوّتين (%)', _sh_voters(b.id); end if;
  if b.scope = 'bank' and q < _sh_bank_min_quorum() then raise exception 'نصاب هيئة المصرف % على الأقل', _sh_bank_min_quorum(); end if;
  if rm < 1 or rm > 60 then raise exception 'دورة المراجعة بين 1 و60 شهراً'; end if;
  if coalesce(p->>'majority', b.majority) not in ('simple', 'two_thirds') then raise exception 'قاعدة الأغلبية غير معروفة'; end if;
  if coalesce(p->>'late_kind', b.late_kind) not in ('claim', 'damage', 'charity') then raise exception 'اختر معالجة التأخر'; end if;
  v_scope := coalesce(nullif(p->>'approval_scope', ''), b.approval_scope);
  if v_scope not in ('central', 'bank') then raise exception 'نطاق الاعتماد: مركزي أو مصرفي'; end if;
  if b.scope = 'bank' and v_scope <> b.approval_scope then raise exception 'نطاق الاعتماد تضبطه الهيئة المركزية'; end if;
  update sharia_boards set
    name = coalesce(nullif(trim(p->>'name'), ''), name),
    marja = case when p ? 'marja' then nullif(trim(p->>'marja'), '') else marja end,
    late_rule = case when p ? 'late_rule' then nullif(trim(p->>'late_rule'), '') else late_rule end,
    late_kind = coalesce(nullif(p->>'late_kind', ''), late_kind),
    quorum = q, review_months = rm, majority = coalesce(p->>'majority', majority),
    chair_casting = coalesce((p->>'chair_casting')::boolean, chair_casting), approval_scope = v_scope, updated_at = now()
  where id = b.id;
  if v_scope is distinct from b.approval_scope then
    perform _sh_board_log(b.id, 'نطاق الاعتماد: ' || case v_scope when 'bank' then 'مصرفي — كل مصرف تعتمد منتجاته هيئته متى اكتملت' else 'مركزي — الهيئة المركزية تعتمد كل المنتجات' end,
      'القرارات السابقة تبقى نافذة حتى إعادة الاعتماد أو المراجعة الدورية');
    perform _notify(o.id, 'bank', 'sharia_bank', 'نطاق الاعتماد الشرعي: ' || case v_scope when 'bank' then 'مصرفي' else 'مركزي' end,
      case when v_scope = 'bank' and _sh_board_for(o.id) <> b.id then 'تُقدَّم منتجاتكم الجديدة إلى ' || (select name from sharia_boards where id = _sh_board_for(o.id)) || '. المنتجات المعتمدة مركزياً تبقى نافذة حتى تعيد هيئتكم اعتمادها أو يحلّ موعد مراجعتها.'
        else 'تُقدَّم منتجاتكم إلى ' || b.name || '.' end, null)
    from orgs o where o.type = 'bank' and coalesce(o.is_islamic, false);
  end if;
  perform _audit('تعديل إعدادات الهيئة الشرعية', b.code, p);
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.sharia_fit_decide(p_board uuid, p_profile uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; mm sharia_members; pr profiles; d text := p->>'decision'; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_code text; v_st text;
begin
  me := _sh_central_head();
  select * into b from sharia_boards where id = p_board;
  if b.id is null or b.scope <> 'bank' then raise exception 'الملاءمة لأعضاء هيئات المصارف'; end if;
  select * into mm from sharia_members where board_id = b.id and profile_id = p_profile for update;
  select * into pr from profiles where id = p_profile;
  if mm.profile_id is null then raise exception 'العضو غير موجود في هذه الهيئة'; end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  if d = 'approve' then
    if mm.fit_status = 'approved' then raise exception 'ملاءمته معتمدة مسبقاً'; end if;
    v_st := 'approved';
  elsif d = 'reject' then
    if mm.fit_status <> 'pending' then raise exception 'يُرفض الترشيح وهو بانتظار الملاءمة — للمعتمد استخدم «سحب الملاءمة»'; end if;
    v_st := 'rejected';
  elsif d = 'revoke' then
    if mm.fit_status <> 'approved' then raise exception 'تُسحب الملاءمة المعتمدة فقط'; end if;
    v_st := 'revoked';
  else raise exception 'اختر القرار'; end if;
  if v_st <> 'approved' and (v_note is null or length(v_note) < 5) then raise exception 'اكتب السبب'; end if;
  v_code := _sh_fit_code();
  update sharia_members set fit_status = v_st, fit_code = v_code, fit_by_name = me.full_name, fit_at = now(), fit_note = v_note, cbi_seen_at = null, cbi_seen_by = null,
    specialty = coalesce(nullif(trim(coalesce(p->>'specialty', '')), ''), specialty) where board_id = b.id and profile_id = mm.profile_id;
  perform _sh_board_log(b.id, v_code || ': ' || _sh_fit_label(v_st) || ' — ' || pr.full_name || ' (' || _role_title(pr.role) || ')', v_note);
  perform _sh_board_log((_sh_central()).id, v_code || ': ' || _sh_fit_label(v_st) || ' — ' || pr.full_name || ' · ' || b.name, v_note);
  insert into notifications(user_id, kind, title, body, ref_id)
  values (pr.id, 'sharia_fit', case v_st when 'approved' then 'اعتمدت الهيئة المركزية ملاءمتك عضواً في ' || b.name else _sh_fit_label(v_st) || ' — ' || b.name end,
    coalesce(v_note, 'صار صوتك يُحسب في النصاب والقرارات') || ' · ' || v_code, b.id);
  perform _sh_notify(b.org_id, 'sharia', array['sharia_head'], 'sharia_fit', _sh_fit_label(v_st) || ': ' || pr.full_name, coalesce(v_note, '') || ' · ' || v_code, b.id);
  -- الجلسة 45: البنك المركزي يطّلع على القرار (لا يعتمده ولا يعترض عليه في المنصة)
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_fit', 'للاطلاع: ' || v_code || ' — ' || _sh_fit_label(v_st) || ' — ' || pr.full_name,
    b.name || ' · ' || _role_title(pr.role) || coalesce(' — ' || v_note, '') || ' · قرار ' || me.full_name, b.id);
  return jsonb_build_object('code', v_code, 'status', v_st, 'status_label', _sh_fit_label(v_st), 'ready', _sh_board_ready(b.id), 'voters', _sh_voters(b.id));
end $f$;

create or replace function public._sh_member_sync() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare b sharia_boards; r text; v_new boolean := false; c sharia_boards;
begin
  if new.portal <> 'sharia' or new.role not in ('sharia_head', 'sharia_member', 'sharia_secretary') then return new; end if;
  select * into b from sharia_boards where org_id = new.org_id order by created_at limit 1;
  if b.id is null then return new; end if;
  r := case new.role when 'sharia_head' then 'head' when 'sharia_secretary' then 'secretary' else 'member' end;
  if not exists (select 1 from sharia_members where board_id = b.id and profile_id = new.id) then
    insert into sharia_members(board_id, profile_id, role, fit_status, nominated_at)
    values (b.id, new.id, r, case when b.scope = 'central' then 'approved' else 'pending' end, now());
    v_new := b.scope = 'bank';
  else
    update sharia_members set role = r where board_id = b.id and profile_id = new.id and role <> r;
  end if;
  if v_new then
    c := _sh_central();
    perform _sh_board_log(b.id, 'ترشيح عضو: ' || new.full_name || ' — ' || _role_title(new.role), 'بانتظار ملاءمة الهيئة المركزية');
    perform _sh_notify(c.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_fit', 'عضو جديد في ' || b.name || ' بانتظار الملاءمة',
      new.full_name || ' — ' || _role_title(new.role) || '. لا يُحسب صوته حتى تعتمدوا ملاءمته', b.id);
    perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_fit', 'للاطلاع: ترشيح عضو في ' || b.name,
      new.full_name || ' — ' || _role_title(new.role) || '. الملاءمة تقررها ' || c.name, b.id);
  end if;
  return new;
end $f$;

create or replace function public.sharia_screen(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  me := _sh_me();
  if me.role not in ('sharia_secretary', 'sharia_head') then raise exception 'التحقق من الاكتمال لأمين السر'; end if;
  select * into pr from islamic_products where id = p_id for update;
  perform _sh_own(pr);
  -- الجلسة 45: أمين سر هيئة المصرف يحيل ويعيد بعد ملاءمته
  if not _sh_fit_ok(pr.board_id, me.id) then raise exception 'تتحقق من الملفات بعد أن تعتمد الهيئة المركزية ملاءمتك'; end if;
  if pr.status <> 'submitted' then raise exception 'المنتج ليس بانتظار التحقق (حالته: %)', _sh_status_label(pr.status); end if;
  if act = 'refer' then
    update islamic_products set status = 'deliberation', status_note = v_note, updated_at = now() where id = pr.id;
    perform _sh_log(pr.id, 'إحالة للأعضاء للمداولة والتصويت', v_note);
    perform _sh_notify(me.org_id, 'sharia', array['sharia_head', 'sharia_member'], 'sharia_review', 'منتج للمداولة: ' || pr.name,
      (select name from orgs where id = pr.bank_id) || ' · ' || (select name from sharia_contract_types where code = pr.contract_type) || ' — علّق على البنود وصوّت', pr.id);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أحيل منتجك للأعضاء: ' || pr.name, 'بدأت المداولة. ستصلك التعليقات على البنود', pr.id);
  elsif act = 'return' then
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الإعادة للمصرف'; end if;
    update islamic_products set status = 'returned', status_note = v_note, updated_at = now() where id = pr.id;
    update islamic_contract_versions set status = 'returned' where id = pr.current_version_id;
    perform _sh_log(pr.id, 'إعادة للمصرف لاستكمال الملف', v_note);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أعادت الهيئة منتجك للتعديل: ' || pr.name, v_note, pr.id);
  else raise exception 'إجراء غير معروف'; end if;
  return _sh_row((select x from islamic_products x where id = pr.id));
end $f$;

create or replace function public._sh_members_json(b sharia_boards) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('profile_id', p.id, 'name', p.full_name, 'role', p.role, 'role_title', _role_title(p.role), 'code', p.staff_code,
      'specialty', m.specialty, 'fit_status', coalesce(m.fit_status, 'approved'), 'fit_label', _sh_fit_label(coalesce(m.fit_status, 'approved')), 'fit_code', m.fit_code,
      'fit_note', m.fit_note, 'fit_at', m.fit_at, 'fit_by', m.fit_by_name, 'nominated_at', m.nominated_at, 'cbi_seen_at', m.cbi_seen_at, 'counts', _sh_fit_ok(b.id, p.id) and p.role in ('sharia_head', 'sharia_member'),
      'username', case when (_sh_my_board()).id = b.id or (_sh_my_board()).scope = 'central' then p.username end)
    order by case p.role when 'sharia_head' then 0 when 'sharia_member' then 1 else 2 end, p.full_name), '[]'::jsonb)
  from profiles p left join sharia_members m on m.profile_id = p.id and m.board_id = b.id
  where p.org_id = b.org_id and p.role like 'sharia\_%' and not coalesce(p.disabled, false) $f$;

-- ───────── 4) سجل الملاءمة: للبنك المركزي (اطلاع) والهيئة المركزية والجهات الرقابية ─────────
create or replace function public.sharia_fit_register() returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; r jsonb;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or not (me.portal in ('cbi', 'audit', 'integrity', 'admin') or (me.portal = 'sharia' and (_sh_my_board()).scope = 'central')) then
    raise exception 'سجل الملاءمة للبنك المركزي والهيئة المركزية'; end if;
  r := jsonb_build_object('viewer', me.portal,
    'members', coalesce((select jsonb_agg(jsonb_build_object('board', b.name, 'board_code', b.code, 'bank', o.name, 'name', p.full_name, 'role_title', _role_title(p.role),
        'specialty', m.specialty, 'fit_status', m.fit_status, 'fit_label', _sh_fit_label(m.fit_status), 'fit_code', m.fit_code, 'fit_by', m.fit_by_name, 'fit_at', m.fit_at,
        'fit_note', m.fit_note, 'nominated_at', m.nominated_at, 'cbi_seen_at', m.cbi_seen_at, 'cbi_seen_by', m.cbi_seen_by)
      order by b.code, case m.fit_status when 'pending' then 0 else 1 end, case p.role when 'sharia_head' then 0 when 'sharia_member' then 1 else 2 end, p.full_name)
      from sharia_members m join sharia_boards b on b.id = m.board_id join profiles p on p.id = m.profile_id left join orgs o on o.id = b.bank_id
      where b.scope = 'bank'), '[]'::jsonb),
    'log', coalesce((select jsonb_agg(jsonb_build_object('at', z.at, 'board', z.board, 'actor', z.actor_name, 'action', z.action, 'note', z.note) order by z.at desc)
      from (select l.at, b.name board, l.actor_name, l.action, l.note from sharia_board_log l join sharia_boards b on b.id = l.board_id
        where b.scope = 'bank' and (l.action like 'FT-%' or l.action like 'ترشيح%' or l.action like 'إنشاء الهيئة%' or l.action like 'اعتماد ملاءمة%')
        order by l.at desc limit 40) z), '[]'::jsonb));
  -- اطلاع البنك المركزي يُسجَّل (تراه الهيئة المركزية)
  if me.portal = 'cbi' then
    update sharia_members m set cbi_seen_at = now(), cbi_seen_by = me.full_name || ' — ' || _role_title(me.role)
    from sharia_boards b where b.id = m.board_id and b.scope = 'bank' and m.cbi_seen_at is null;
  end if;
  return r;
end $f$;
grant execute on function public.sharia_fit_register() to authenticated;
revoke all on function public.sharia_fit_register() from anon;

-- ───────── 5) البيانات ─────────
-- نصاب هيئات المصارف القائمة يُرفع إلى 3
do $$
declare b sharia_boards;
begin
  for b in select * from sharia_boards where scope = 'bank' and quorum < _sh_bank_min_quorum() loop
    update sharia_boards set quorum = _sh_bank_min_quorum(), updated_at = now() where id = b.id;
    insert into sharia_board_log(board_id, actor_name, action, note) values
      (b.id, 'النظام', 'النصاب: ' || b.quorum || ' ← ' || _sh_bank_min_quorum(), 'نصاب هيئة المصرف 3 على الأقل، وأمين السر شرط لاكتمالها');
  end loop;
end $$;

-- العرض: عضو ثالث بملاءمة في هيئة الواحة، صوّت على «منظومة المزرعة بالمرابحة»
do $$
declare b sharia_boards; c sharia_boards; uid uuid; hid uuid; ch profiles; pid uuid;
  v_name text := 'السيد د. حيدر جواد الموسوي';
begin
  select * into b from sharia_boards where code = 'SHB-WAH';
  c := _sh_central();
  if b.id is null or c.id is null then return; end if;
  select * into ch from profiles where username = 'sharia.head';
  select id into hid from profiles where username = 'wsh.head';
  if not exists (select 1 from profiles where username = 'wsh.m3') then
    perform _mk_user('wsh.m3', 'Wsh@2026m3', v_name, 'sharia_member', 'sharia', 'shwah', null, null);
    select id into uid from profiles where username = 'wsh.m3';
    update profiles set managed_by = hid where id = uid;
    update sharia_members set specialty = 'أصول الفقه والقواعد الفقهية', fit_status = 'approved', fit_code = _sh_fit_code(), fit_by_name = ch.full_name,
      fit_at = now() - interval '1 day', nominated_at = now() - interval '2 days', fit_note = null, cbi_seen_at = null
    where board_id = b.id and profile_id = uid;
    -- إشعارات الترشيح الآلية لا تلزم بعد اعتماده؛ يبقى إشعار قرار الملاءمة للبنك المركزي
    delete from notifications where kind = 'sharia_fit' and ref_id = b.id and body like v_name || '%';
    delete from sharia_board_log where board_id = b.id and action like 'ترشيح عضو: ' || v_name || '%';
    insert into sharia_board_log(board_id, at, actor_name, action, note) values
      (b.id, now() - interval '2 days', (select full_name from profiles where id = hid), 'ترشيح عضو: ' || v_name || ' — ' || _role_title('sharia_member'), 'بانتظار ملاءمة الهيئة المركزية'),
      (b.id, now() - interval '1 day', ch.full_name, (select fit_code from sharia_members where board_id = b.id and profile_id = uid) || ': ملاءمة معتمدة — ' || v_name || ' (' || _role_title('sharia_member') || ')', null),
      (c.id, now() - interval '1 day', ch.full_name, (select fit_code from sharia_members where board_id = b.id and profile_id = uid) || ': ملاءمة معتمدة — ' || v_name || ' · ' || b.name, null);
    perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_fit',
      'للاطلاع: ' || (select fit_code from sharia_members where board_id = b.id and profile_id = uid) || ' — ملاءمة معتمدة — ' || v_name,
      b.name || ' · ' || _role_title('sharia_member') || ' · قرار ' || ch.full_name, b.id);
  end if;
  select id into uid from profiles where username = 'wsh.m3';
  -- للعرض: البنك المركزي أُبلغ بترشيح العضوة المنتظرة أيضاً
  if not exists (select 1 from notifications n where n.portal = 'cbi' and n.kind = 'sharia_fit' and n.ref_id = b.id and n.title like 'للاطلاع: ترشيح عضو%') then
    perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_fit', 'للاطلاع: ترشيح عضو في ' || b.name,
      p.full_name || ' — ' || _role_title(p.role) || '. الملاءمة تقررها ' || c.name, b.id)
    from sharia_members m join profiles p on p.id = m.profile_id where m.board_id = b.id and m.fit_status = 'pending';
  end if;
  -- صوت العضو الثالث على المنتج قيد المداولة
  select id into pid from islamic_products where board_id = b.id and name = 'منظومة المزرعة بالمرابحة' and status = 'deliberation';
  if pid is not null and uid is not null and not exists (select 1 from sharia_votes v join islamic_products p on p.current_version_id = v.version_id where p.id = pid and v.member_id = uid) then
    perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
    perform set_config('request.jwt.claim.sub', uid::text, true);
    perform sharia_vote(pid, '{"vote":"approve"}'::jsonb);
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
  end if;
end $$;
