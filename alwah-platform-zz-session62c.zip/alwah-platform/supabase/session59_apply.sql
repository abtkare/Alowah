-- ═══════════════════════════════════════════════════════════════════════════
-- الجلسة 59 — فصل صلاحيات خريطة المشاريع حسب تخصص كل جهة
--   الخطأ: اتحاد الغرف التجارية (وغرف المحافظات) ووزارة التجارة كانت ترى كل المشاريع، ومنها المنظومات الشمسية
--          السكنية والزراعية والصناعية — وهي ليست من اختصاصها.
--   القاعدة الجديدة (دالة واحدة _pm_scope):
--     • الجهات الشاملة — ترى كل المشاريع من كل التخصصات:
--         وزارة التخطيط، وزارة المالية، البنك المركزي، هيئة النزاهة، ديوان الرقابة المالية، مشغّل النظام
--     • الجهات القطاعية — ترى البرامج التي تصدر هي إجازتها أو تؤيّدها فقط:
--         اتحاد الغرف التجارية وغرف المحافظات، وزارة التجارة ← القروض التجارية، التجارة الإلكترونية، المصدّرون
--         اتحاد الصناعات ومكاتبه                              ← القروض الصناعية (+ طبقة المعامل المنتسبة)
--         نقابة الأطباء البيطريين، دائرة البيطرة            ← مبادرة الأطباء البيطريين
--     • المنظومات الشمسية (سكني، زراعي، صناعي، تجاري أو خدمي، بيطري، تصدير، أخرى) للجهات الشاملة فقط.
--     • مؤشرات المشاريع الوهمية: البنك المركزي ومشغّل النظام وهيئة النزاهة وديوان الرقابة المالية.
--   + بيانات عرض إضافية (لا تمسّ المعاملات): كل غرفة محافظة ≥ 100 مشروع تجاري، كل محافظة ≥ 60 مشروعاً صناعياً
--     (مكتب الاتحاد يغطي عدة محافظات)، ومبادرة البيطريين ≥ 250 مشروعاً، ومعامل منتسبة لاتحاد الصناعات.
-- آمن للتكرار: الإضافة «حتى الحد الأدنى» فلا تتضاعف عند إعادة التطبيق.
-- يعتمد على الجلسة 58 (الجدولان demo_map_projects و demo_map_members).
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── 1) تخصص كل جهة — null = كل التخصصات ─────────
create or replace function public._pm_scope(p_portal text) returns text[] language sql immutable as $f$
  select case
    when p_portal in ('planning', 'finance', 'cbi', 'integrity', 'audit', 'admin') then null
    when p_portal in ('chamber', 'trade') then array['commercial_program', 'ecommerce_program', 'export_program']
    when p_portal = 'union' then array['industrial_program']
    when p_portal in ('syndicate', 'vetdept') then array['vet_program']
    else array[]::text[] end $f$;

-- ───────── 2) طبقة المعامل لاتحاد الصناعات ─────────
alter table public.demo_map_members add column if not exists kind text not null default 'chamber';

-- ───────── 3) بيانات عرض إضافية حتى الحد الأدنى لكل جهة ─────────
drop table if exists pg_temp._dz_city; drop table if exists pg_temp._dz_gov;
create temp table _dz_city (gov text, city text, lat float8, lng float8, w int);
insert into _dz_city values
 ('بغداد','الكرادة',33.300,44.420,4),('بغداد','المنصور',33.320,44.330,4),('بغداد','الأعظمية',33.370,44.370,3),('بغداد','الكاظمية',33.380,44.340,3),
 ('بغداد','مدينة الصدر',33.390,44.460,4),('بغداد','الدورة',33.250,44.380,3),('بغداد','أبو غريب',33.290,44.070,3),('بغداد','التاجي',33.500,44.230,2),
 ('بغداد','المحمودية',33.060,44.360,2),('بغداد','الزعفرانية',33.250,44.470,2),('بغداد','الشعب',33.410,44.410,2),('بغداد','بغداد الجديدة',33.320,44.470,3),
 ('بغداد','الرصافة — الشورجة',33.342,44.398,5),('بغداد','جميلة',33.402,44.452,3),
 ('البصرة','العشار',30.510,47.820,4),('البصرة','الزبير',30.390,47.700,3),('البصرة','أبو الخصيب',30.450,48.000,2),('البصرة','القرنة',31.010,47.430,2),
 ('البصرة','الفاو',29.980,48.470,1),('البصرة','شط العرب',30.530,47.900,2),('البصرة','الجمهورية',30.530,47.800,2),('البصرة','خور الزبير',30.200,47.870,2),
 ('نينوى','الموصل',36.340,43.130,5),('نينوى','تلعفر',36.380,42.450,2),('نينوى','الحمدانية',36.270,43.380,2),('نينوى','سنجار',36.320,41.880,1),('نينوى','بعشيقة',36.450,43.350,1),
 ('أربيل','أربيل',36.190,44.010,5),('أربيل','شقلاوة',36.400,44.320,1),('أربيل','كويسنجق',36.080,44.630,1),('أربيل','سوران',36.650,44.540,1),
 ('النجف','النجف',32.000,44.330,4),('النجف','الكوفة',32.030,44.400,2),('النجف','المناذرة',31.880,44.480,2),('النجف','المشخاب',31.800,44.490,2),
 ('كربلاء','كربلاء',32.610,44.020,4),('كربلاء','الهندية',32.540,44.220,2),('كربلاء','عين التمر',32.570,43.490,1),
 ('بابل','الحلة',32.480,44.430,4),('بابل','المسيب',32.780,44.290,2),('بابل','المحاويل',32.650,44.400,2),('بابل','الهاشمية',32.370,44.650,2),
 ('ذي قار','الناصرية',31.050,46.260,4),('ذي قار','الشطرة',31.410,46.170,2),('ذي قار','سوق الشيوخ',30.880,46.460,2),('ذي قار','الرفاعي',31.720,46.110,1),
 ('الأنبار','الرمادي',33.420,43.300,4),('الأنبار','الفلوجة',33.350,43.780,3),('الأنبار','هيت',33.640,42.830,1),('الأنبار','القائم',34.370,41.090,1),
 ('ديالى','بعقوبة',33.750,44.640,4),('ديالى','المقدادية',33.980,44.940,2),('ديالى','الخالص',33.810,44.530,2),('ديالى','خانقين',34.350,45.390,1),
 ('واسط','الكوت',32.510,45.820,4),('واسط','الصويرة',32.930,44.780,2),('واسط','النعمانية',32.560,45.420,1),('واسط','الحي',32.170,46.050,1),
 ('ميسان','العمارة',31.840,47.150,4),('ميسان','المجر الكبير',31.570,47.170,1),('ميسان','قلعة صالح',31.510,47.270,1),
 ('الديوانية','الديوانية',31.990,44.920,4),('الديوانية','الشامية',31.960,44.600,2),('الديوانية','عفك',32.060,45.250,1),
 ('صلاح الدين','تكريت',34.610,43.680,3),('صلاح الدين','سامراء',34.200,43.870,3),('صلاح الدين','بلد',34.020,44.150,2),('صلاح الدين','الشرقاط',35.510,43.230,1),('صلاح الدين','بيجي',34.930,43.490,2),
 ('كركوك','كركوك',35.470,44.390,4),('كركوك','الحويجة',35.320,43.770,1),('كركوك','داقوق',35.130,44.450,1),
 ('المثنى','السماوة',31.310,45.280,4),('المثنى','الرميثة',31.530,45.200,2),('المثنى','الخضر',31.200,45.530,1),
 ('السليمانية','السليمانية',35.560,45.430,5),('السليمانية','رانية',36.250,44.880,1),('السليمانية','حلبجة',35.180,45.990,1),
 ('دهوك','دهوك',36.870,42.990,4),('دهوك','زاخو',37.140,42.680,2),('دهوك','سميل',36.860,42.850,1);

-- الحد الأدنى في كل محافظة: مشاريع تجارية (غرف التجارة)، صناعية (مكاتب الاتحاد)، بيطرية، ومعامل منتسبة
create temp table _dz_gov (gov text, com int, ind int, vet int, fac int);
insert into _dz_gov values ('بغداد',220,150,45,180),('البصرة',130,90,20,90),('نينوى',120,80,18,80),('أربيل',110,70,14,60),('النجف',110,60,14,55),
 ('كربلاء',105,60,12,50),('بابل',105,65,14,55),('ذي قار',100,60,12,50),('الأنبار',100,65,12,55),('ديالى',100,60,12,45),('واسط',100,60,12,40),
 ('ميسان',100,60,10,35),('الديوانية',100,60,12,40),('صلاح الدين',100,65,10,45),('كركوك',105,70,12,55),('المثنى',100,60,10,30),
 ('السليمانية',110,70,14,60),('دهوك',100,60,12,45);

do $seed$
declare
  g record; c record; i int; need int; n int; sec text; prog text; nm text; act text; vt text; amt bigint; r float8;
  st text; stg int; src text; jit float8; la float8; lo float8; site jsonb;
  fam text[] := array['الرافدين','النور','الأمل','دجلة','الفرات','بابل','سومر','الخيرات','البركة','الهدى','السلام','الوفاء','الأصيل','الجنائن','الفجر',
    'الرواد','الإبداع','المستقبل','الشموخ','الياسمين','النخيل','الصفاء','الريادة','أكد','آشور','الوركاء','الحضارة','الكرم','الأنوار','الغدير',
    'الزوراء','المربد','الكوثر','العراق الجديد','الميثاق','الضياء','الأرز','الصقر','الماسة','اللؤلؤة'];
  com text[] := array['مواد غذائية بالجملة','مواد إنشائية','أجهزة كهربائية','قطع غيار سيارات','ملابس وأقمشة','مستلزمات طبية','أدوات منزلية','مواد زراعية',
    'أثاث ومفروشات','هواتف وإكسسوارات','مواد تجميل وعطور','مكتبة وقرطاسية','أحذية وحقائب','لوازم مطاعم'];
  ecom text[] := array['متجر إلكتروني للملابس','متجر إلكتروني للأجهزة','منصة توصيل طعام','متجر إلكتروني للعطور','متجر مستحضرات تجميل','منصة حجز خدمات',
    'متجر إلكتروني للكتب','منصة بيع قطع الغيار'];
  expo text[] := array['تصدير تمور','تصدير جلود','تصدير ملح','تصدير أسمدة','تصدير منتجات ألبان','تصدير خضروات','تصدير حبة سوداء وبذور','تصدير سجاد يدوي'];
  ind text[] := array['معمل بلوك','معمل ألبان','معمل منظفات','معمل أعلاف','معمل بلاستك','مطحنة','معمل خياطة','معمل تعبئة مياه','معمل حلويات','ورشة حدادة',
    'معمل أثاث','معمل طابوق','معمل معجون طماطم','معمل كاشي وموزائيك','معمل أكياس ورقية','معمل مقرنصات','معمل ثلج','مقلع حصى ورمل'];
  fcat text[] := array['food','food','food','textile','construction_sand','construction','construction','wood','chemical','chemical','metal','metal','other'];
  vets text[] := array['clinic','clinic','clinic','clinic','lab','lab','hospital','pharma','supplies'];
begin
  if to_regclass('public.demo_map_projects') is null then return; end if;
  perform setseed(0.59);
  select coalesce(max(substr(code, 10)::int), 10000) - 10000 into n from demo_map_projects where code ~ '^ALW-2026-\d{5}$';

  for g in select * from _dz_gov loop
    -- (أ) المشاريع التجارية — القروض التجارية والتجارة الإلكترونية والمصدّرون
    select g.com - count(*) into need from demo_map_projects where gov = g.gov and sector in ('commercial_program', 'ecommerce_program', 'export_program');
    for i in 1..greatest(need, 0) loop
      select * into c from _dz_city where gov = g.gov order by -ln(random()) / w limit 1;
      n := n + 1; r := random();
      if r < 0.62 then sec := 'commercial_program'; prog := 'commercial'; act := com[1 + floor(random() * 14)::int];
        nm := (array['محلات','مخازن','معرض','شركة','أسواق'])[1 + floor(random() * 5)::int] || ' ' || fam[1 + floor(random() * 40)::int]; jit := 0.022;
      elsif r < 0.82 then sec := 'ecommerce_program'; prog := 'ecommerce'; act := ecom[1 + floor(random() * 8)::int];
        nm := fam[1 + floor(random() * 40)::int] || ' أونلاين'; jit := 0.025;
      else sec := 'export_program'; prog := 'export'; act := expo[1 + floor(random() * 8)::int];
        nm := 'شركة ' || fam[1 + floor(random() * 40)::int] || ' للتجارة والتصدير'; jit := 0.045; end if;
      amt := ((15 + floor(random() * 235)) * 1000000)::bigint;
      if random() < 0.64 then st := 'completed'; stg := 37; else st := 'active'; stg := (array[8,12,18,22,26,30,34,35])[1 + floor(random() * 8)::int]; end if;
      la := c.lat + (random() - 0.5) * 2 * jit; lo := c.lng + (random() - 0.5) * 2 * jit;
      site := jsonb_build_object('lat', round(la::numeric, 6), 'lng', round(lo::numeric, 6));
      insert into demo_map_projects (code, sector, program, purpose, name, activity, gov, city, address, lat, lng, src, status, stage, kw, amount, flags, site)
      values ('ALW-2026-' || lpad((10000 + n)::text, 5, '0'), sec, prog, null, nm, act, g.gov, c.city,
        'شارع ' || (array['التجارة','الرشيد','السوق','الجمهورية','الصناعة','النهر','المطار','الكورنيش','فلسطين','الأطباء'])[1 + floor(random() * 10)::int] || '، محل ' || (1 + floor(random() * 300))::int,
        round(la::numeric, 6), round(lo::numeric, 6), 'site', st, stg, null, amt, '{}', site);
    end loop;

    -- (ب) المشاريع الصناعية — القروض الصناعية (في أطراف المدن والمناطق الصناعية)
    select g.ind - count(*) into need from demo_map_projects where gov = g.gov and sector = 'industrial_program';
    for i in 1..greatest(need, 0) loop
      select * into c from _dz_city where gov = g.gov order by -ln(random()) / w limit 1;
      n := n + 1; act := ind[1 + floor(random() * 18)::int];
      la := c.lat + (random() - 0.5) * 0.14; lo := c.lng + (random() - 0.5) * 0.14;
      if random() < 0.6 then st := 'completed'; stg := 37; else st := 'active'; stg := (array[8,12,18,22,26,30,32,34])[1 + floor(random() * 8)::int]; end if;
      insert into demo_map_projects (code, sector, program, purpose, name, activity, gov, city, address, lat, lng, src, status, stage, kw, amount, flags, site)
      values ('ALW-2026-' || lpad((10000 + n)::text, 5, '0'), 'industrial_program', 'industrial', null, act || ' ' || fam[1 + floor(random() * 40)::int], act,
        g.gov, c.city, 'الحي الصناعي، قطعة ' || (1 + floor(random() * 400))::int, round(la::numeric, 6), round(lo::numeric, 6),
        case when st = 'completed' then 'audit' else 'site' end, st, stg, null, ((50 + floor(random() * 450)) * 1000000)::bigint, '{}',
        jsonb_build_object('lat', round(la::numeric, 6), 'lng', round(lo::numeric, 6)));
    end loop;

    -- (ج) مبادرة الأطباء البيطريين
    select g.vet - count(*) into need from demo_map_projects where gov = g.gov and sector = 'vet_program';
    for i in 1..greatest(need, 0) loop
      select * into c from _dz_city where gov = g.gov order by -ln(random()) / w limit 1;
      n := n + 1; vt := vets[1 + floor(random() * 9)::int];
      la := c.lat + (random() - 0.5) * 0.06; lo := c.lng + (random() - 0.5) * 0.06;
      if random() < 0.6 then st := 'completed'; stg := 37; else st := 'active'; stg := (array[8,12,18,22,26,30,32,34])[1 + floor(random() * 8)::int]; end if;
      insert into demo_map_projects (code, sector, program, purpose, name, activity, vet_type, gov, city, address, lat, lng, src, status, stage, kw, amount, flags, site)
      values ('ALW-2026-' || lpad((10000 + n)::text, 5, '0'), 'vet_program', 'vet', null, null, null, vt, g.gov, c.city,
        'محلة ' || (100 + floor(random() * 800))::int || '، زقاق ' || (1 + floor(random() * 40))::int, round(la::numeric, 6), round(lo::numeric, 6),
        case when st = 'completed' then 'audit' else 'site' end, st, stg, null, ((25 + floor(random() * 175)) * 1000000)::bigint, '{}',
        jsonb_build_object('lat', round(la::numeric, 6), 'lng', round(lo::numeric, 6)));
    end loop;

    -- (د) المعامل المنتسبة لاتحاد الصناعات (طبقة مستقلة عن محلات التجار)
    select g.fac - count(*) into need from demo_map_members where gov = g.gov and kind = 'union';
    for i in 1..greatest(need, 0) loop
      select * into c from _dz_city where gov = g.gov order by -ln(random()) / w limit 1;
      act := fcat[1 + floor(random() * 13)::int]; r := random();
      insert into demo_map_members (code, kind, name, cat, gov, city, address, lat, lng, status)
      values ('IFI-2026-' || lpad((10000 + (select count(*) from demo_map_members where kind = 'union') + 1)::text, 5, '0'), 'union',
        (case act when 'food' then (array['معمل ألبان','معمل حلويات','مطحنة','معمل معجنات'])[1 + floor(random() * 4)::int]
                  when 'textile' then (array['معمل خياطة','معمل نسيج','معمل ملابس جاهزة'])[1 + floor(random() * 3)::int]
                  when 'construction_sand' then (array['معمل طابوق','مقلع حصى ورمل','معمل جص'])[1 + floor(random() * 3)::int]
                  when 'construction' then (array['معمل بلوك','معمل كاشي','معمل مقرنصات'])[1 + floor(random() * 3)::int]
                  when 'wood' then (array['معمل أثاث','نجارة آلية'])[1 + floor(random() * 2)::int]
                  when 'chemical' then (array['معمل منظفات','معمل بلاستك','معمل أصباغ'])[1 + floor(random() * 3)::int]
                  when 'metal' then (array['ورشة حدادة','معمل أبواب وشبابيك','معمل هياكل معدنية'])[1 + floor(random() * 3)::int]
                  else (array['معمل ثلج','معمل أكياس','معمل تعبئة'])[1 + floor(random() * 3)::int] end) || ' ' || fam[1 + floor(random() * 40)::int],
        act, g.gov, c.city, 'الحي الصناعي، قطعة ' || (1 + floor(random() * 400))::int,
        round((c.lat + (random() - 0.5) * 0.12)::numeric, 6), round((c.lng + (random() - 0.5) * 0.12)::numeric, 6),
        case when r < 0.8 then 'approved' when r < 0.88 then 'pending' when r < 0.96 then 'expired' else 'suspended' end);
    end loop;
  end loop;
end $seed$;
drop table if exists pg_temp._dz_city; drop table if exists pg_temp._dz_gov;

-- ───────── 4) projects_map: كل جهة ترى تخصصها فقط ─────────
create or replace function public.projects_map() returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; govs text[]; sc text[]; oversight boolean; pr jsonb; mem jsonb := '[]'::jsonb; lbl text; mk text;
  demo boolean := coalesce(_setting('map_demo'), 0) = 1 and to_regclass('public.demo_map_projects') is not null;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or coalesce(me.disabled, false)
     or me.portal not in ('planning', 'finance', 'cbi', 'integrity', 'audit', 'admin', 'trade', 'chamber', 'union', 'syndicate', 'vetdept') then
    raise exception 'خريطة المشاريع غير متاحة لهذه الجهة'; end if;
  sc := _pm_scope(me.portal);                                       -- null = كل التخصصات
  oversight := me.portal in ('cbi', 'admin', 'integrity', 'audit');  -- مؤشرات المشاريع الوهمية
  mk := case me.portal when 'chamber' then 'chamber' when 'union' then 'union' end;   -- طبقة المنتسبين
  if me.portal in ('chamber', 'union') and me.branch_id is not null then
    select nullif(coalesce(b.governorates, '{}'), '{}'), b.name into govs, lbl from branches b where b.id = me.branch_id;
  end if;

  select coalesce(jsonb_agg(x order by x->>'code'), '[]'::jsonb) into pr from (
    select jsonb_strip_nulls(jsonb_build_object(
      'id', a.id, 'code', a.code, 'sector', _app_sector(a.program, a.purpose), 'program', coalesce(a.program, 'solar'), 'purpose', a.purpose,
      'name', nullif(trim(coalesce(a.biz->>'business_name', '')), ''),
      'activity', coalesce(nullif(trim(coalesce(a.biz->>'activity', '')), ''), case when a.purpose = 'other' then a.purpose_other end),
      'vet_type', v.project_type,
      'gov', a.governorate, 'city', a.city, 'address', coalesce(a.site_geo->>'address', a.biz->>'address'),
      'lat', round((pt->>'lat')::numeric, 6), 'lng', round((pt->>'lng')::numeric, 6), 'src', pt->>'src',
      'status', a.status, 'stage', a.stage, 'kw', a.kw, 'amount', a.amount, 'audit', a.audit_status,
      'flags', case when oversight then to_jsonb(_pm_flags(a)) end,
      'site', case when oversight and a.site_geo ? 'lat' then jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng') end,
      'install', case when oversight and a.install_geo ? 'lat' then jsonb_build_object('lat', a.install_geo->'lat', 'lng', a.install_geo->'lng', 'at', a.install_geo->'at') end
    )) x
    from applications a
    left join lateral (select vp.project_type from vet_projects vp where vp.application_id = a.id limit 1) v on true
    cross join lateral (select _pm_point(a) pt) q
    where a.bank_id is not null and a.stage >= 6 and a.status not in ('rejected', 'cancelled')
      and (sc is null or _app_sector(a.program, a.purpose) = any(sc))
      and (govs is null or a.governorate = any(govs))
    union all
    select jsonb_strip_nulls(jsonb_build_object(
      'id', d.id, 'code', d.code, 'sector', d.sector, 'program', d.program, 'purpose', d.purpose, 'name', d.name, 'activity', d.activity, 'vet_type', d.vet_type,
      'gov', d.gov, 'city', d.city, 'address', d.address, 'lat', d.lat, 'lng', d.lng, 'src', d.src, 'status', d.status, 'stage', d.stage,
      'kw', d.kw, 'amount', d.amount, 'audit', d.audit, 'demo', true,
      'flags', case when oversight then to_jsonb(d.flags) end,
      'site', case when oversight then d.site end, 'install', case when oversight then d.install end))
    from demo_map_projects d
    where demo and (sc is null or d.sector = any(sc)) and (govs is null or d.gov = any(govs))) s;

  if mk = 'chamber' then
    select coalesce(jsonb_agg(z order by z->>'code'), '[]'::jsonb) into mem from (
      select jsonb_strip_nulls(jsonb_build_object(
        'id', m.id, 'code', m.code, 'name', m.factory_name, 'cat', m.category, 'gov', m.governorate, 'city', m.city, 'address', m.address,
        'lat', (m.site_geo->>'lat')::numeric, 'lng', (m.site_geo->>'lng')::numeric, 'status', m.status)) z
      from chamber_members m
      where m.status in ('approved', 'expired', 'suspended', 'pending') and (govs is null or m.governorate = any(govs))
      union all
      select jsonb_strip_nulls(jsonb_build_object('id', d.id, 'code', d.code, 'name', d.name, 'cat', d.cat, 'gov', d.gov, 'city', d.city,
        'address', d.address, 'lat', d.lat, 'lng', d.lng, 'status', d.status, 'demo', true))
      from demo_map_members d where demo and d.kind = 'chamber' and (govs is null or d.gov = any(govs))) t;
  elsif mk = 'union' then
    select coalesce(jsonb_agg(z order by z->>'code'), '[]'::jsonb) into mem from (
      select jsonb_strip_nulls(jsonb_build_object(
        'id', m.id, 'code', m.code, 'name', m.factory_name, 'cat', m.category, 'gov', m.governorate, 'city', m.city, 'address', m.address,
        'lat', (m.site_geo->>'lat')::numeric, 'lng', (m.site_geo->>'lng')::numeric, 'status', m.status)) z
      from union_members m
      where m.status in ('approved', 'expired', 'suspended', 'pending') and (govs is null or m.governorate = any(govs))
      union all
      select jsonb_strip_nulls(jsonb_build_object('id', d.id, 'code', d.code, 'name', d.name, 'cat', d.cat, 'gov', d.gov, 'city', d.city,
        'address', d.address, 'lat', d.lat, 'lng', d.lng, 'status', d.status, 'demo', true))
      from demo_map_members d where demo and d.kind = 'union' and (govs is null or d.gov = any(govs))) t;
  end if;

  return jsonb_build_object('portal', me.portal, 'govs', to_jsonb(govs), 'scope_label', lbl, 'scope', to_jsonb(sc), 'members_kind', mk,
    'oversight', oversight, 'demo', demo,
    'max_m', coalesce(_setting('install_max_distance_m'), 300), 'projects', pr, 'members', mem, 'at', now());
end $f$;
revoke execute on function public.projects_map() from public, anon;
grant execute on function public.projects_map() to authenticated;
