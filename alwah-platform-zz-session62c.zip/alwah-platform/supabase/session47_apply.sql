-- ألواح — الجلسة 47: برامج المصرف تطلقها الإدارة العليا وتديرها (المصدّرون، التجاري، التجارة الإلكترونية)
-- الإدارة العليا للمصرف (bank_md) تنشئ البرنامج وتحدد ثوابته ومتغيراته وتطلقه أو توقفه أو تغلقه،
-- وتنضم أو تنسحب من مبادرتي الطاقة الشمسية والبيطري. والمقترض يقدّم على البرنامج من هاتفه بخمس خطوات.
-- آمن للتكرار.

-- ═══ 1) الجداول ═══
create table if not exists public.bank_programs (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  bank_id uuid not null references public.orgs(id),
  kind text not null check (kind in ('export', 'commercial', 'ecommerce')),
  name text not null,
  summary text,
  status text not null default 'draft' check (status in ('draft', 'active', 'paused', 'closed')),
  params jsonb not null default '{}'::jsonb,
  version int not null default 1,
  launched_at timestamptz, launched_by text,
  created_by text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists bank_programs_bank on public.bank_programs(bank_id);
create table if not exists public.bank_program_log (
  id bigserial primary key, program_id uuid references public.bank_programs(id), bank_id uuid,
  action text not null, note text, before jsonb, after jsonb,
  actor_id uuid, actor_name text, created_at timestamptz not null default now()
);
alter table public.applications add column if not exists program_id uuid references public.bank_programs(id);
alter table public.applications add column if not exists biz jsonb;

alter table public.bank_programs enable row level security;
alter table public.bank_program_log enable row level security;
drop policy if exists bp_read on public.bank_programs;
create policy bp_read on public.bank_programs for select to authenticated
  using (status <> 'draft' or bank_id = my_org() or my_portal() in ('admin', 'cbi', 'integrity', 'audit'));
drop policy if exists bpl_read on public.bank_program_log;
create policy bpl_read on public.bank_program_log for select to authenticated
  using (bank_id = my_org() or my_portal() in ('admin', 'cbi', 'integrity', 'audit'));
grant select on public.bank_programs, public.bank_program_log to authenticated;

-- ═══ 2) المستندات والثوابت لكل نوع ═══
create or replace function public._bp_doc_label(k text) returns text language sql immutable as $$
  select case k
    when 'biz_reg' then 'شهادة تأسيس الشركة أو السجل التجاري'
    when 'biz_chamber' then 'هوية غرفة التجارة'
    when 'biz_license' then 'إجازة ممارسة المهنة أو النشاط'
    when 'biz_lease' then 'عقد إيجار المحل أو سند ملكيته'
    when 'biz_statement' then 'كشف حساب مصرفي أو دفتر المبيعات (آخر 6 أشهر)'
    when 'biz_invoice' then 'فاتورة أو عرض سعر المورد'
    when 'biz_tax' then 'براءة الذمة الضريبية'
    when 'exp_license' then 'إجازة التصدير'
    when 'exp_contract' then 'عقد أو طلبية المستورد'
    when 'ecm_license' then 'إجازة التجارة الإلكترونية من وزارة التجارة (منصة التاجر الإلكتروني)'
    when 'ecm_daman' then 'شهادة التسجيل في منصة «ضمان»'
    when 'ecm_sales' then 'سجل مبيعات المتجر (آخر 6 أشهر)'
    when 'biz_other' then 'مستند آخر'
  end $$;
create or replace function public._bp_fixed_docs(p_kind text) returns text[] language sql immutable as $$
  select case p_kind when 'export' then array['exp_license', 'exp_contract'] when 'ecommerce' then array['ecm_license', 'ecm_daman']
    when 'commercial' then array['biz_chamber'] else array[]::text[] end $$;
create or replace function public._bp_kind_label(p_kind text) returns text language sql immutable as $$
  select case p_kind when 'export' then 'قروض المصدّرين' when 'commercial' then 'القروض التجارية' when 'ecommerce' then 'قروض التجارة الإلكترونية' else p_kind end $$;
create or replace function public._is_trade(p text) returns boolean language sql immutable as $$ select p in ('export', 'commercial', 'ecommerce') $$;

-- تطبيع متغيرات البرنامج وثوابته والتحقق منها
create or replace function public._bp_norm(p_kind text, p jsonb) returns jsonb language plpgsql stable as $$
declare r jsonb; v_g text[]; v_d text[]; v_gov text[]; v_pur text[];
begin
  p := coalesce(p, '{}'::jsonb);
  r := jsonb_build_object(
    'min_amount', coalesce(nullif(regexp_replace(coalesce(p->>'min_amount', ''), '[^0-9]', '', 'g'), '')::bigint, 5000000),
    'max_amount', coalesce(nullif(regexp_replace(coalesce(p->>'max_amount', ''), '[^0-9]', '', 'g'), '')::bigint, 100000000),
    'min_term', coalesce(nullif(p->>'min_term', '')::int, 12),
    'max_term', coalesce(nullif(p->>'max_term', '')::int, 60),
    'grace_max', coalesce(nullif(p->>'grace_max', '')::int, 0),
    'rate', coalesce(nullif(p->>'rate', '')::numeric, 6),
    'commission_pct', coalesce(nullif(p->>'commission_pct', '')::numeric, 1),
    'file_fee', coalesce(nullif(regexp_replace(coalesce(p->>'file_fee', ''), '[^0-9]', '', 'g'), '')::bigint, 0),
    'budget', coalesce(nullif(regexp_replace(coalesce(p->>'budget', ''), '[^0-9]', '', 'g'), '')::bigint, 0),
    'min_activity_months', coalesce(nullif(p->>'min_activity_months', '')::int, 0),
    'disburse', coalesce(nullif(p->>'disburse', ''), 'supplier'),
    'funding', coalesce(nullif(p->>'funding', ''), case when p_kind = 'export' then 'eu' else 'bank' end),
    'conditions', left(trim(coalesce(p->>'conditions', '')), 800));
  if (r->>'min_amount')::bigint < 500000 then raise exception 'أدنى مبلغ للقرض 500 ألف دينار على الأقل'; end if;
  if (r->>'max_amount')::bigint < (r->>'min_amount')::bigint then raise exception 'أعلى مبلغ أقل من أدنى مبلغ'; end if;
  if (r->>'max_amount')::bigint > 50000000000 then raise exception 'أعلى مبلغ كبير جداً'; end if;
  if (r->>'min_term')::int < 3 or (r->>'max_term')::int > 180 or (r->>'max_term')::int < (r->>'min_term')::int then raise exception 'المدة: الأدنى 3 أشهر والأعلى 180 شهراً، والأعلى لا يقل عن الأدنى'; end if;
  if (r->>'grace_max')::int < 0 or (r->>'grace_max')::int > (r->>'max_term')::int - 3 then raise exception 'مدة السماح أقل من أعلى مدة بثلاثة أشهر على الأقل'; end if;
  if (r->>'rate')::numeric < 0 or (r->>'rate')::numeric > 30 then raise exception 'نسبة الفائدة أو الربح بين 0 و30 بالمئة سنوياً'; end if;
  if (r->>'commission_pct')::numeric < 0 or (r->>'commission_pct')::numeric > 5 then raise exception 'عمولة المصرف بين 0 و5 بالمئة'; end if;
  if (r->>'min_activity_months')::int < 0 or (r->>'min_activity_months')::int > 240 then raise exception 'مدة ممارسة النشاط بين 0 و240 شهراً'; end if;
  if r->>'disburse' not in ('supplier', 'account', 'mixed') then raise exception 'طريقة الصرف غير معروفة'; end if;
  if r->>'funding' not in ('initiative', 'bank', 'eu', 'other') then raise exception 'مصدر التمويل غير معروف'; end if;
  select coalesce(array_agg(distinct x), '{}') into v_g from jsonb_array_elements_text(coalesce(p->'guarantees', '["single_salary","multi_salary","mortgage","gold"]'::jsonb)) x;
  if cardinality(v_g) = 0 then raise exception 'اختر نوع ضمان واحداً على الأقل'; end if;
  if exists (select 1 from unnest(v_g) x where x not in ('single_salary', 'multi_salary', 'mortgage', 'gold')) then raise exception 'نوع ضمان غير معروف'; end if;
  select coalesce(array_agg(distinct x), '{}') into v_d from jsonb_array_elements_text(coalesce(p->'docs', '[]'::jsonb)) x;
  if exists (select 1 from unnest(v_d) x where _bp_doc_label(x) is null) then raise exception 'مستند غير معروف في قائمة المستندات'; end if;
  v_d := array(select distinct x from unnest(v_d || _bp_fixed_docs(p_kind)) x order by 1);
  select coalesce(array_agg(distinct x), '{}') into v_gov from jsonb_array_elements_text(coalesce(p->'governorates', '[]'::jsonb)) x;
  select coalesce(array_agg(left(trim(x), 60)), '{}') into v_pur from jsonb_array_elements_text(coalesce(p->'purposes', '[]'::jsonb)) x where trim(x) <> '';
  if cardinality(v_pur) > 12 then raise exception '12 غرضاً كحد أقصى'; end if;
  return r || jsonb_build_object('guarantees', to_jsonb(v_g), 'docs', to_jsonb(v_d), 'governorates', to_jsonb(v_gov), 'purposes', to_jsonb(v_pur));
end $$;

-- ما استُخدم من سقف البرنامج (الطلبات المرسلة غير المرفوضة ولا الملغاة)
create or replace function public._bp_used(p_prog uuid) returns bigint language sql stable security definer set search_path = public as $$
  select coalesce(sum(amount), 0)::bigint from applications where program_id = p_prog and stage >= 6 and status not in ('rejected', 'cancelled') $$;

-- برامج المصرف في orgs.meta.programs: مبادرتا المنصة كما اختارتهما الإدارة، وأنواع البرامج المطلقة
create or replace function public._bp_sync(p_bank uuid) returns void language plpgsql security definer set search_path = public as $$
declare v_init text[]; v_tr text[];
begin
  select coalesce(array_agg(x), '{}') into v_init from orgs o, jsonb_array_elements_text(coalesce(o.meta->'programs', '["solar","vet"]'::jsonb)) x
    where o.id = p_bank and x in ('solar', 'vet');
  select coalesce(array_agg(distinct kind), '{}') into v_tr from bank_programs where bank_id = p_bank and status = 'active';
  update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('programs', to_jsonb(v_init || v_tr)) where id = p_bank;
end $$;

create or replace function public._bp_me() returns profiles language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'bank' or coalesce(me.disabled, false) then raise exception 'برامج المصرف للإدارة العليا للمصرف'; end if;
  if me.role <> 'bank_md' then raise exception 'إطلاق البرامج وإدارتها صلاحية الإدارة العليا للمصرف'; end if;
  return me;
end $$;

-- ═══ 3) دوال الإدارة العليا ═══
create or replace function public.bank_program_save(p_id uuid, p jsonb) returns bank_programs
language plpgsql security definer set search_path = public as $$
declare me profiles := _bp_me(); bp bank_programs; old bank_programs; v_kind text; v_name text; v_params jsonb; v_n int;
begin
  v_name := trim(coalesce(p->>'name', ''));
  if length(v_name) < 4 then raise exception 'اكتب اسم البرنامج (4 أحرف على الأقل)'; end if;
  if p_id is null then
    v_kind := p->>'kind';
    if not _is_trade(v_kind) then raise exception 'اختر نوع البرنامج: المصدّرون أو التجاري أو التجارة الإلكترونية'; end if;
    v_params := _bp_norm(v_kind, p->'params');
    select count(*) + 1 into v_n from bank_programs where bank_id = me.org_id;
    insert into bank_programs(code, bank_id, kind, name, summary, params, created_by)
    values ('P-' || upper((select code from orgs where id = me.org_id)) || '-' || lpad(v_n::text, 3, '0'), me.org_id, v_kind, v_name,
      nullif(left(trim(coalesce(p->>'summary', '')), 400), ''), v_params, me.full_name)
    returning * into bp;
    insert into bank_program_log(program_id, bank_id, action, after, actor_id, actor_name) values (bp.id, bp.bank_id, 'إنشاء مسودة', to_jsonb(bp), me.id, me.full_name);
    return bp;
  end if;
  select * into old from bank_programs where id = p_id for update;
  if old.id is null or old.bank_id <> me.org_id then raise exception 'البرنامج غير موجود في مصرفك'; end if;
  if old.status = 'closed' then raise exception 'البرنامج مغلق — أنشئ برنامجاً جديداً'; end if;
  v_params := _bp_norm(old.kind, p->'params');
  update bank_programs set name = v_name, summary = nullif(left(trim(coalesce(p->>'summary', '')), 400), ''), params = v_params,
    version = version + case when status = 'draft' then 0 else 1 end, updated_at = now()
  where id = p_id returning * into bp;
  insert into bank_program_log(program_id, bank_id, action, note, before, after, actor_id, actor_name)
  values (bp.id, bp.bank_id, case when old.status = 'draft' then 'تعديل المسودة' else 'تعديل البرنامج (الإصدار ' || bp.version || ') — يسري على الطلبات الجديدة' end,
    nullif(trim(coalesce(p->>'note', '')), ''), to_jsonb(old), to_jsonb(bp), me.id, me.full_name);
  return bp;
end $$;

create or replace function public.bank_program_status(p_id uuid, p_status text, p_note text default null) returns bank_programs
language plpgsql security definer set search_path = public as $$
declare me profiles := _bp_me(); bp bank_programs; rd jsonb; v_act text; v_old text;
begin
  select * into bp from bank_programs where id = p_id for update;
  v_old := bp.status;
  if bp.id is null or bp.bank_id <> me.org_id then raise exception 'البرنامج غير موجود في مصرفك'; end if;
  if p_status not in ('active', 'paused', 'closed') then raise exception 'إجراء غير معروف'; end if;
  if bp.status = 'closed' then raise exception 'البرنامج مغلق'; end if;
  if p_status = bp.status then return bp; end if;
  if p_status in ('paused', 'closed') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;
  if p_status = 'active' then
    rd := _org_readiness(bp.bank_id);
    if not coalesce((rd->>'ok')::boolean, false) then
      raise exception 'لا يمكن إطلاق البرنامج — ينقص المصرف: %', (select string_agg(x->>'t' || coalesce(' (' || (x->>'branch_name') || ')', ''), '، ') from (select x from jsonb_array_elements(rd->'missing') x limit 6) q);
    end if;
    perform _bp_norm(bp.kind, bp.params);
    if coalesce((select (meta->>'suspended')::boolean from orgs where id = bp.bank_id), false) then raise exception 'المصرف موقوف من مشغّل النظام'; end if;
    update orgs set meta = coalesce(meta, '{}') || '{"accepting": true}'::jsonb where id = bp.bank_id and coalesce((meta->>'accepting')::boolean, true) = false;
  end if;
  update bank_programs set status = p_status, updated_at = now(),
    launched_at = case when p_status = 'active' and launched_at is null then now() else launched_at end,
    launched_by = case when p_status = 'active' and launched_at is null then me.full_name else launched_by end
  where id = p_id returning * into bp;
  v_act := case p_status when 'active' then case when v_old = 'draft' then 'إطلاق البرنامج' else 'إعادة تشغيل البرنامج' end
    when 'paused' then 'إيقاف مؤقت — الطلبات القائمة تستمر' else 'إغلاق البرنامج — الطلبات القائمة تستمر' end;
  insert into bank_program_log(program_id, bank_id, action, note, actor_id, actor_name) values (bp.id, bp.bank_id, v_act, nullif(trim(p_note), ''), me.id, me.full_name);
  perform _bp_sync(bp.bank_id);
  perform _audit('برامج المصرف: ' || v_act, bp.code || ' — ' || bp.name, jsonb_build_object('status', p_status, 'note', p_note));
  return bp;
end $$;

-- الانضمام إلى مبادرتي المنصة (الطاقة الشمسية، البيطري) أو الانسحاب منهما — الطلبات القائمة لا تتأثر
create or replace function public.bank_initiative_join(p_kind text, p_on boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare me profiles := _bp_me(); v text[];
begin
  if p_kind not in ('solar', 'vet') then raise exception 'المبادرة غير معروفة'; end if;
  select coalesce(array_agg(x), '{}') into v from orgs o, jsonb_array_elements_text(coalesce(o.meta->'programs', '["solar","vet"]'::jsonb)) x where o.id = me.org_id and x <> p_kind;
  if p_on then v := v || p_kind; end if;
  update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('programs', to_jsonb(v)) where id = me.org_id;
  insert into bank_program_log(bank_id, action, actor_id, actor_name)
  values (me.org_id, case when p_on then 'الانضمام إلى مبادرة ' else 'الانسحاب من مبادرة ' end || _program_label(p_kind), me.id, me.full_name);
  return (select meta from orgs where id = me.org_id);
end $$;

-- ═══ 4) المقترض: بدء الطلب والمستندات والخطوات ═══
create or replace function public.start_trade_application(p_program uuid, p_governorate text, p_city text default null) returns applications
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; bp bank_programs; v_code text; v_term int;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'citizen' then raise exception 'التقديم من بوابة المقترض فقط'; end if;
  if exists (select 1 from applications where citizen_id = me.id and status in ('active', 'returned')) then
    raise exception 'لديك طلب قائم — تابعه من «طلبي» أو ألغِه قبل تقديم طلب جديد'; end if;
  select * into bp from bank_programs where id = p_program;
  if bp.id is null or bp.status <> 'active' then raise exception 'البرنامج غير متاح الآن'; end if;
  if coalesce(p_governorate, '') = '' then raise exception 'اختر محافظة النشاط'; end if;
  if jsonb_array_length(bp.params->'governorates') > 0 and not (bp.params->'governorates' ? p_governorate) then
    raise exception 'البرنامج لا يغطي محافظة % — يغطي: %', p_governorate, (select string_agg(x, '، ') from jsonb_array_elements_text(bp.params->'governorates') x); end if;
  v_code := _vet_seq(case bp.kind when 'export' then 'EXP' when 'commercial' then 'COM' else 'ECM' end, 'applications', 'code');
  v_term := least(greatest(36, (bp.params->>'min_term')::int), (bp.params->>'max_term')::int);
  insert into applications(code, citizen_id, citizen_name, program, program_id, governorate, city, stage, status, bank_unit, term_months, grace_months, margin, bank_choice)
  values (v_code, me.id, me.full_name, bp.kind, bp.id, p_governorate, coalesce(nullif(trim(p_city), ''), p_governorate), 1, 'active', 'المواطن', v_term, 0,
    (bp.params->>'rate')::numeric, jsonb_build_object('bank_id', bp.bank_id, 'program_id', bp.id, 'term_months', v_term, 'commission_pct', (bp.params->>'commission_pct')::numeric, 'at', now()))
  returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, 1, 'بدء طلب: ' || _bp_kind_label(bp.kind), bp.name || ' — ' || (select name from orgs where id = bp.bank_id), me.id, me.full_name, me.role);
  return a;
end $$;

create or replace function public.trade_doc_add(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $$
declare me profiles; a applications; mime text; sz int := length(coalesce(p_data, '')); did uuid;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if not _is_trade(a.program) then raise exception 'هذه المستندات لطلبات برامج المصارف'; end if;
  if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
  if _bp_doc_label(p_kind) is null then raise exception 'نوع مستند غير معروف'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg', 'image/png', 'application/pdf') then raise exception 'صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  delete from app_documents where application_id = a.id and kind = p_kind;
  insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_kind, coalesce(p_source, 'file'), mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}') || jsonb_build_object('server_at', now()), me.id, _role_title(me.role)) returning id into did;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || _bp_doc_label(p_kind), case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $$;

create or replace function public._trade_step(p_app uuid, p_step integer, p_data jsonb) returns applications
language plpgsql security definer set search_path = public as $$
declare me profiles; a applications; bp bank_programs; pp jsonb; act text; note text; new_stage int; b jsonb; miss text;
  v_amount bigint; v_term int; v_grace int; v_purpose text; gt text; inst bigint; v_used bigint; v_months int; v_y int; v_m int;
  g jsonb; arr jsonb := '[]'::jsonb; phones text[] := '{}'; ph text; n int; total bigint := 0; need bigint; pr properties; v_val bigint; v_gr numeric; v_kt int; v_gv bigint; rd jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  select * into bp from bank_programs where id = a.program_id;
  if bp.id is null then raise exception 'برنامج الطلب غير موجود'; end if;
  pp := bp.params;
  new_stage := greatest(a.stage, p_step + 1);

  if p_step = 2 then
    -- النشاط
    if length(trim(coalesce(p_data->>'business_name', ''))) < 3 then raise exception 'اكتب اسم النشاط أو الشركة أو المتجر'; end if;
    if length(trim(coalesce(p_data->>'activity', ''))) < 3 then raise exception 'اكتب نوع النشاط'; end if;
    if coalesce(p_data->>'legal_form', '') not in ('individual', 'company') then raise exception 'حدّد: نشاط فردي أم شركة'; end if;
    if length(trim(coalesce(p_data->>'reg_no', ''))) < 2 then raise exception 'اكتب رقم السجل التجاري أو هوية غرفة التجارة'; end if;
    if coalesce(p_data->>'governorate', '') = '' then raise exception 'اختر محافظة النشاط'; end if;
    if jsonb_array_length(pp->'governorates') > 0 and not (pp->'governorates' ? (p_data->>'governorate')) then raise exception 'البرنامج لا يغطي محافظة %', p_data->>'governorate'; end if;
    if length(trim(coalesce(p_data->>'address', ''))) < 4 then raise exception 'اكتب عنوان النشاط'; end if;
    v_y := nullif(regexp_replace(coalesce(p_data->>'start_year', ''), '[^0-9]', '', 'g'), '')::int;
    v_m := coalesce(nullif(regexp_replace(coalesce(p_data->>'start_month', ''), '[^0-9]', '', 'g'), '')::int, 1);
    if v_y is null or v_y < 1950 or v_y > extract(year from now())::int or v_m not between 1 and 12 then raise exception 'اكتب سنة بدء النشاط وشهره'; end if;
    v_months := (extract(year from now())::int - v_y) * 12 + extract(month from now())::int - v_m;
    if v_months < 0 then raise exception 'تاريخ بدء النشاط في المستقبل'; end if;
    if v_months < (pp->>'min_activity_months')::int then raise exception 'البرنامج يشترط ممارسة النشاط % شهراً على الأقل (نشاطك % شهراً)', pp->>'min_activity_months', v_months; end if;
    b := jsonb_build_object('business_name', trim(p_data->>'business_name'), 'activity', trim(p_data->>'activity'), 'legal_form', p_data->>'legal_form',
      'reg_no', trim(p_data->>'reg_no'), 'governorate', p_data->>'governorate', 'city', nullif(trim(coalesce(p_data->>'city', '')), ''), 'address', trim(p_data->>'address'),
      'start_year', v_y, 'start_month', v_m, 'activity_months', v_months, 'employees', nullif(regexp_replace(coalesce(p_data->>'employees', ''), '[^0-9]', '', 'g'), '')::int,
      'monthly_sales', nullif(regexp_replace(coalesce(p_data->>'monthly_sales', ''), '[^0-9]', '', 'g'), '')::bigint);
    if bp.kind = 'export' then
      if length(trim(coalesce(p_data->>'export_license_no', ''))) < 2 then raise exception 'اكتب رقم إجازة التصدير'; end if;
      if length(trim(coalesce(p_data->>'goods', ''))) < 3 then raise exception 'اكتب البضاعة المصدَّرة'; end if;
      if length(trim(coalesce(p_data->>'destination', ''))) < 2 then raise exception 'اكتب بلد التصدير'; end if;
      if length(trim(coalesce(p_data->>'importer', ''))) < 3 then raise exception 'اكتب اسم المستورد'; end if;
      b := b || jsonb_build_object('export_license_no', trim(p_data->>'export_license_no'), 'goods', trim(p_data->>'goods'), 'destination', trim(p_data->>'destination'),
        'importer', trim(p_data->>'importer'), 'contract_value', nullif(regexp_replace(coalesce(p_data->>'contract_value', ''), '[^0-9]', '', 'g'), '')::bigint);
    elsif bp.kind = 'ecommerce' then
      if coalesce(p_data->>'store_url', '') !~* '^(https?://)?[a-z0-9.-]+\.[a-z]{2,}(/.*)?$' and length(trim(coalesce(p_data->>'store_url', ''))) < 3 then raise exception 'اكتب رابط المتجر أو اسم صفحته'; end if;
      if length(trim(coalesce(p_data->>'emerchant_license_no', ''))) < 2 then raise exception 'اكتب رقم إجازة التجارة الإلكترونية من وزارة التجارة (منصة التاجر الإلكتروني)'; end if;
      if length(trim(coalesce(p_data->>'daman_no', ''))) < 2 then raise exception 'اكتب رقم التسجيل في منصة «ضمان»'; end if;
      b := b || jsonb_build_object('store_url', trim(p_data->>'store_url'), 'emerchant_license_no', trim(p_data->>'emerchant_license_no'),
        'daman_no', trim(p_data->>'daman_no'), 'platforms', nullif(trim(coalesce(p_data->>'platforms', '')), ''));
    end if;
    update applications set biz = coalesce(biz, '{}') || b, governorate = p_data->>'governorate', city = coalesce(nullif(trim(coalesce(p_data->>'city', '')), ''), p_data->>'governorate') where id = a.id;
    act := 'تثبيت بيانات النشاط'; note := trim(p_data->>'business_name') || ' · ' || trim(p_data->>'activity');

  elsif p_step = 3 then
    -- المبلغ والمدة والغرض والضمان والمستندات
    if bp.status <> 'active' then raise exception 'البرنامج متوقف حالياً — لا يقبل طلبات جديدة'; end if;
    v_amount := nullif(regexp_replace(coalesce(p_data->>'amount', ''), '[^0-9]', '', 'g'), '')::bigint;
    if v_amount is null or v_amount < (pp->>'min_amount')::bigint or v_amount > (pp->>'max_amount')::bigint then
      raise exception 'مبلغ القرض بين % و% د.ع', to_char((pp->>'min_amount')::bigint, 'FM999,999,999,999'), to_char((pp->>'max_amount')::bigint, 'FM999,999,999,999'); end if;
    if (pp->>'budget')::bigint > 0 then
      v_used := _bp_used(bp.id);
      if v_used + v_amount > (pp->>'budget')::bigint then raise exception 'المتبقي من سقف البرنامج % د.ع فقط', to_char(greatest((pp->>'budget')::bigint - v_used, 0), 'FM999,999,999,999'); end if;
    end if;
    v_term := coalesce(nullif(p_data->>'term_months', '')::int, 0);
    v_grace := coalesce(nullif(p_data->>'grace_months', '')::int, 0);
    if v_term < (pp->>'min_term')::int or v_term > (pp->>'max_term')::int then raise exception 'مدة السداد بين % و% شهراً', pp->>'min_term', pp->>'max_term'; end if;
    if v_grace < 0 or v_grace > (pp->>'grace_max')::int or v_grace > v_term - 3 then raise exception 'مدة السماح حتى % شهراً وضمن مدة السداد', pp->>'grace_max'; end if;
    v_purpose := trim(coalesce(p_data->>'purpose', ''));
    if jsonb_array_length(pp->'purposes') > 0 and not (pp->'purposes' ? v_purpose) then raise exception 'اختر غرض التمويل من أغراض البرنامج'; end if;
    if length(v_purpose) < 3 then raise exception 'اكتب غرض التمويل'; end if;
    gt := coalesce(nullif(p_data->>'guarantee_type', ''), a.guarantee_type);
    if gt is null or not (pp->'guarantees' ? gt) then raise exception 'اختر الضمان من الضمانات التي يقبلها البرنامج'; end if;
    select string_agg(_bp_doc_label(x), '، ') into miss from jsonb_array_elements_text(pp->'docs') x
      where not exists (select 1 from app_documents d where d.application_id = a.id and d.kind = x);
    if miss is not null then raise exception 'ارفع المستندات المطلوبة: %', miss; end if;
    inst := _installment(v_amount, (pp->>'rate')::numeric, greatest(v_term - v_grace, 1));
    if gt is distinct from a.guarantee_type then
      update applications set guarantee = null, property_id = null, ownership = null where id = a.id;
      if new_stage > 4 then new_stage := 4; end if;
    end if;
    update applications set amount = v_amount, price = v_amount, term_months = v_term, grace_months = v_grace, margin = (pp->>'rate')::numeric,
      monthly_installment = inst, guarantee_type = gt, biz = coalesce(biz, '{}') || jsonb_build_object('purpose', v_purpose, 'program_version', bp.version),
      bank_choice = jsonb_build_object('bank_id', bp.bank_id, 'program_id', bp.id, 'term_months', v_term, 'grace_months', v_grace, 'commission_pct', (pp->>'commission_pct')::numeric, 'at', now())
    where id = a.id;
    act := 'تثبيت التمويل والمستندات'; note := to_char(v_amount, 'FM999,999,999,999') || ' د.ع · ' || v_term || ' شهراً (سماح ' || v_grace || ') · القسط ' || to_char(inst, 'FM999,999,999') || ' د.ع · ' || v_purpose;

  elsif p_step = 4 then
    -- الضمان (كما في مسار الطاقة الشمسية، والقسط الفعلي من البرنامج)
    if a.amount is null then raise exception 'ثبّت مبلغ التمويل أولاً'; end if;
    inst := coalesce(nullif(a.monthly_installment, 0), _installment(a.amount, a.margin, greatest(a.term_months - coalesce(a.grace_months, 0), 1)));
    if a.guarantee_type = 'gold' then
      v_gr := nullif(p_data->>'grams', '')::numeric; v_kt := coalesce(nullif(p_data->>'karat', '')::int, 21);
      if v_gr is null or v_gr < 1 then raise exception 'اكتب وزن الذهب بالغرام'; end if;
      if v_kt not in (18, 21, 22, 24) then raise exception 'العيار 18 أو 21 أو 22 أو 24'; end if;
      v_gv := round(v_gr * _setting('gold_gram_21') * v_kt / 21);
      if a.amount > v_gv * _setting('gold_ltv') / 100 then
        raise exception 'قيمة ذهبك التقديرية % د.ع لا تكفي — يلزم ذهب بقيمة % د.ع على الأقل', to_char(v_gv, 'FM999,999,999'), to_char(ceil(a.amount * 100 / _setting('gold_ltv')), 'FM999,999,999'); end if;
      update applications set property_id = null, guarantee = jsonb_build_object('type', 'gold', 'grams', v_gr, 'karat', v_kt, 'value', v_gv,
        'gram_price', _setting('gold_gram_21'), 'ltv', round(a.amount * 100.0 / v_gv, 1), 'items', nullif(left(trim(coalesce(p_data->>'items', '')), 200), '')) where id = a.id;
      act := 'تأكيد الضمان: رهن ذهب'; note := v_gr || ' غرام عيار ' || v_kt || ' · قيمة تقديرية ' || to_char(v_gv, 'FM999,999,999') || ' د.ع — يُسلَّم للفرع ويُوزن ويُقيَّم';
    elsif a.guarantee_type in ('single_salary', 'multi_salary') then
      n := jsonb_array_length(coalesce(p_data->'guarantors', '[]'::jsonb));
      if a.guarantee_type = 'single_salary' and n < 1 then raise exception 'أضف كفيلاً واحداً موظفاً'; end if;
      if a.guarantee_type = 'multi_salary' and n < 2 then raise exception 'هذا الضمان يتطلب كفيلين موظفين على الأقل'; end if;
      if n > 3 then raise exception 'ثلاثة كفلاء كحد أقصى'; end if;
      for g in select * from jsonb_array_elements(p_data->'guarantors') loop
        if length(trim(coalesce(g->>'name', ''))) < 6 then raise exception 'اكتب الاسم الثلاثي لكل كفيل'; end if;
        ph := _norm_phone(g->>'phone');
        if ph = me.phone then raise exception 'لا يكفل المتقدم نفسه'; end if;
        if ph = any(phones) then raise exception 'رقم هاتف مكرر بين الكفلاء'; end if;
        phones := phones || ph;
        if nullif(g->>'national_id', '') is not null and ((g->>'national_id') !~ '^[0-9]{12}$' or g->>'national_id' = me.national_id) then
          raise exception 'الرقم الوطني للكفيل % غير صحيح', g->>'name'; end if;
        if coalesce(g->>'employer', '') = '' then raise exception 'اكتب جهة عمل كل كفيل'; end if;
        if g->>'ministry' = 'trade' and length(trim(coalesce(g->>'dept', ''))) < 3 then raise exception 'اختر دائرة الكفيل % في وزارة التجارة', g->>'name'; end if;
        if exists (select 1 from employer_checks c where c.application_id = a.id and c.guarantor_phone = ph and c.status = 'rejected') then
          raise exception 'رفضت وزارة التجارة كفالة % لهذا الطلب — اختر كفيلاً آخر', g->>'name'; end if;
        if coalesce((g->>'salary')::bigint, 0) < 250000 then raise exception 'راتب الكفيل غير صحيح'; end if;
        if not (_otp_ok(g->>'otp', ph) or _g_link_ok(a.id, g->>'link', ph, g)) then raise exception 'لم يؤكد الكفيل % موافقته برمز التحقق', g->>'name'; end if;
        total := total + (g->>'salary')::bigint;
        arr := arr || jsonb_build_object('name', trim(g->>'name'), 'phone', ph, 'employer', g->>'employer', 'salary', (g->>'salary')::bigint,
          'relation', g->>'relation', 'ministry', case when g->>'ministry' = 'trade' then 'trade' end, 'salary_bank_id', nullif(g->>'salary_bank_id', ''),
          'salary_account', nullif(regexp_replace(coalesce(g->>'salary_account', ''), '\s', '', 'g'), ''), 'dept', nullif(trim(coalesce(g->>'dept', '')), ''),
          'national_id', nullif(g->>'national_id', ''), 'id_source', case when g->>'id_source' = 'ocr' then 'ocr' else 'manual' end,
          'consent', true, 'consent_at', now(), 'consent_via', case when _otp_ok(g->>'otp', ph) then 'otp' else 'link' end);
      end loop;
      need := ceil(inst * _setting('salary_safety'));
      if total < need then raise exception 'مجموع رواتب الكفلاء (% د.ع) أقل من القسط × % = % د.ع', to_char(total, 'FM999,999,999'), _setting('salary_safety'), to_char(need, 'FM999,999,999'); end if;
      update applications set guarantee = jsonb_build_object('type', a.guarantee_type, 'guarantors', arr, 'total_salary', total, 'required', need) where id = a.id;
      act := 'تأكيد الضمان وموافقة الكفلاء'; note := n || ' كفيل · مجموع الرواتب ' || to_char(total, 'FM999,999,999') || ' د.ع';
    else
      if coalesce(trim(p_data->>'deed_no'), '') = '' then raise exception 'اكتب رقم السند العقاري (رقم القطعة/المقاطعة)'; end if;
      select * into pr from properties where deed_no = trim(p_data->>'deed_no');
      if pr is null then
        v_val := coalesce(nullif(regexp_replace(coalesce(p_data->>'estimated_value', ''), '[^0-9]', '', 'g'), '')::bigint, 0);
        if v_val <= 0 then raise exception 'اكتب القيمة التقديرية للعقار'; end if;
        if coalesce(p_data->>'district', '') = '' then raise exception 'اكتب المنطقة أو المقاطعة'; end if;
        insert into properties(deed_no, owner_name, owner_national_id, governorate, district, use_type, land_area, ref_value, status)
        values (trim(p_data->>'deed_no'), me.full_name, me.national_id, coalesce(p_data->>'governorate', a.governorate), p_data->>'district',
          coalesce(p_data->>'use_type', 'تجاري'), nullif(p_data->>'land_area', '')::numeric, v_val, 'free')
        returning * into pr;
      end if;
      if pr.status <> 'free' and not exists (select 1 from mortgage_referrals m where m.property_id = pr.id and m.application_id = a.id) then
        raise exception 'العقار عليه إشارة — لا يقبل ضماناً'; end if;
      if a.amount > pr.ref_value * _setting('ltv_max') / 100 then raise exception 'مبلغ التمويل يتجاوز % بالمئة من قيمة العقار', _setting('ltv_max'); end if;
      update applications set property_id = pr.id, guarantee = jsonb_build_object('type', 'mortgage', 'deed_no', pr.deed_no, 'ref_value', pr.ref_value,
        'ltv', round(a.amount * 100.0 / pr.ref_value, 1)) where id = a.id;
      act := 'تأكيد الضمان: رهن عقار'; note := 'سند ' || pr.deed_no || ' · ' || pr.governorate || ' / ' || pr.district;
    end if;

  elsif p_step = 5 then
    if bp.status <> 'active' then raise exception 'البرنامج متوقف حالياً — لا يقبل طلبات جديدة'; end if;
    if a.amount is null or a.guarantee is null then raise exception 'أكمل التمويل والضمان أولاً'; end if;
    if exists (select 1 from orgs where id = bp.bank_id and coalesce((meta->>'accepting')::boolean, true) = false) then raise exception 'المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
    select string_agg(_bp_doc_label(x), '، ') into miss from jsonb_array_elements_text(pp->'docs') x
      where not exists (select 1 from app_documents d where d.application_id = a.id and d.kind = x);
    if miss is not null then raise exception 'ارفع المستندات المطلوبة: %', miss; end if;
    if (pp->>'budget')::bigint > 0 and _bp_used(bp.id) + a.amount > (pp->>'budget')::bigint then raise exception 'نفد سقف البرنامج'; end if;
    if not _otp_ok(p_data->>'otp') then raise exception 'رمز التوقيع الإلكتروني غير صحيح'; end if;
    update applications set bank_id = bp.bank_id, margin = (pp->>'rate')::numeric, submitted_at = now() where id = a.id;
    act := 'توقيع الطلب إلكترونياً وإرساله للمصرف'; note := bp.name || ' — ' || (select name from orgs where id = bp.bank_id) || ' · القسط ' || to_char(a.monthly_installment, 'FM999,999,999') || ' د.ع';
  else
    raise exception 'خطوة غير معروفة';
  end if;

  update applications set stage = new_stage, status = 'active', updated_at = now(),
    bank_unit = (select s.owner_label from stages s where s.n = new_stage) where id = a.id returning * into a;
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, p_step, act, note, me.id, me.full_name, me.role);
  return a;
end $$;

-- توجيه خطوات المقترض: برامج المصارف إلى _trade_step (الهوية مشتركة)
create or replace function public.citizen_step(p_app uuid, p_step integer, p_data jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
-- مسار الطاقة الشمسية في _citizen_step_solar (يحفظ bank_choice واختيار المصرف كما في الجلسة 5)
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program = 'vet' or _is_trade(a.program) then
    if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
    if p_step < 1 or p_step > 5 then raise exception 'مرحلة غير معروفة'; end if;
    if p_step > a.stage then raise exception 'أكمل المراحل السابقة أولاً'; end if;
    if p_step = 1 then return _citizen_step_solar(p_app, 1, p_data); end if;   -- التحقق من الهوية مشترك
    if a.program = 'vet' then return _vet_step(p_app, p_step, p_data); end if;
    return _trade_step(p_app, p_step, p_data);
  end if;
  return _citizen_step_solar(p_app, p_step, p_data);
end $function$;

-- عمولة المصرف ورسم الملف من البرنامج
create or replace function public._bp_fee_quote(p_prog uuid, p_amount bigint) returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_array(
    jsonb_build_object('key', 'bank_commission', 'label', 'عمولة المصرف (' || (bp.params->>'commission_pct') || '%) — ' || o.name,
      'amount', round(coalesce(p_amount, 0) * (bp.params->>'commission_pct')::numeric / 100)::bigint),
    jsonb_build_object('key', 'bank_fee', 'label', 'رسم دراسة الملف — ' || o.name, 'amount', coalesce((bp.params->>'file_fee')::bigint, 0)),
    jsonb_build_object('key', 'inspection_fee', 'label', 'أجور الكشف الموقعي', 'amount', coalesce(_setting('inspection_fee'), 0)::bigint),
    jsonb_build_object('key', 'platform_fee', 'label', 'عمولة المنصة', 'amount', coalesce(_setting('platform_fee'), 0)::bigint))
  from bank_programs bp join orgs o on o.id = bp.bank_id where bp.id = p_prog $$;

create or replace function public.pay_application_fees(p_app uuid, p_bank uuid, p_method text, p_otp text) returns payments
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; pay payments; it jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.stage <> 5 or a.status not in ('active','returned') then raise exception 'الدفع بعد تأكيد الضمان وقبل إرسال الطلب'; end if;
  if not exists (select 1 from bank_terms where bank_id = p_bank) then raise exception 'اختر مصرفاً'; end if;
  if p_method not in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  select * into pay from payments where application_id = a.id and bank_id = p_bank and status = 'paid';
  if pay.id is not null then return pay; end if;
  -- الجلسة 47: طلب برنامج مصرف — العمولة ورسم الملف من البرنامج
  it := case when a.program_id is not null then _bp_fee_quote(a.program_id, a.amount) else fee_quote(p_bank, a.amount) end;
  insert into payments(application_id, bank_id, method, items, amount, ref, paid_by)
  values (a.id, p_bank, p_method, it, (select sum((x->>'amount')::bigint) from jsonb_array_elements(it) x),
    'PAY-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)), me.id)
  returning * into pay;
  perform _ev(a.id, 5, 'دفع عمولة المصرف والرسوم إلكترونياً',
    to_char(pay.amount, 'FM999,999,999') || ' د.ع · ' || pay_method_label(p_method) || ' · ' || pay.ref);
  return pay;
end $function$;

-- ═══ 5) مسار المصرف لطلبات البرامج ═══
-- لا مورد على المنصة يركّب: المرحلة 31 (التركيب) تُتجاوز، والكشف في 32 على البضاعة أو المحل والمستندات
create or replace function public._trade_skip() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if _is_trade(new.program) and new.stage = 31 and old.stage = 30 then
    new.stage := 32; new.bank_unit := (select owner_label from stages where n = 32);
    insert into application_events(application_id, stage, action, note, actor_name, actor_role)
    values (new.id, 31, 'تجاوز مرحلة التركيب — لا تنطبق على ' || _bp_kind_label(new.program), 'آلياً', 'النظام', 'system');
  end if;
  return new;
end $$;
drop trigger if exists trg_a0_trade_skip on public.applications;
create trigger trg_a0_trade_skip before update of stage on public.applications for each row execute function public._trade_skip();

-- الكشف الهندسي الآلي لمسارَي الطاقة الشمسية والبيطري فقط
create or replace function public._eng_on_stage() returns trigger language plpgsql security definer set search_path to 'public' as $function$
begin
  if new.stage = 32 and old.stage is distinct from 32 and new.status = 'active' and coalesce(new.program, 'solar') in ('solar', 'vet')
     and not exists (select 1 from eng_inspections where application_id = new.id and status not in ('done', 'cancelled'))
     and exists (select 1 from orgs where type = 'eng_audit') then
    begin
      perform _eng_create(new.id, 'acceptance', null, 'آلياً — وصول الطلب إلى الكشف والاستلام (المرحلة 32)');
    exception when others then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('eng_unassigned', 'medium', 'تعذّر إسناد كشف هندسي', new.code || ': ' || sqlerrm, new.id, coalesce(new.governorate, ''));
    end;
  end if;
  -- إلغاء الطلب أو رفضه يُلغي الأوامر المفتوحة
  if new.status in ('cancelled', 'rejected') and old.status is distinct from new.status then
    update eng_inspections set status = 'cancelled', updated_at = now() where application_id = new.id and status not in ('done', 'cancelled');
  end if;
  return new;
end $function$;

-- حارس الضمان (تأييد وزارة التجارة للكفيل، واستلام الذهب) يشمل البرامج
create or replace function public._guard_guarantee() returns trigger language plpgsql security definer set search_path to 'public' as $function$
declare miss text;
begin
  if new.stage > old.stage and old.stage in (9, 19) and (new.program = 'solar' or _is_trade(new.program)) then
    if new.guarantee_type in ('single_salary', 'multi_salary') and old.stage = 9 then
      select string_agg(x->>'name', '، ') into miss from jsonb_array_elements(coalesce(new.guarantee->'guarantors', '[]'::jsonb)) x
      where x->>'ministry' = 'trade' and not exists (select 1 from employer_checks c where c.application_id = new.id and c.guarantor_phone = x->>'phone' and c.status = 'approved');
      if miss is not null then
        raise exception 'الضمان الأولي: بانتظار تأييد وزارة التجارة لراتب الكفيل (%) — إن رفضت الوزارة أعد الطلب للمقترض لاستبدال الضمان', miss; end if;
    end if;
    if new.guarantee_type = 'gold' and new.guarantee->'custody' is null then
      raise exception 'رهن الذهب: سجّل استلام الذهب ووزنه وتقييمه في الفرع أولاً'; end if;
  end if;
  return new;
end $function$;

create or replace function public._emp_on_app() returns trigger language plpgsql security definer set search_path to 'public' as $function$
begin
  if (new.program = 'solar' or _is_trade(new.program)) and new.stage >= 6 and (old.stage <= 5 or new.guarantee is distinct from old.guarantee or new.guarantee_type is distinct from old.guarantee_type) then
    perform _emp_sync(new.id);
    if old.stage <= 5 then perform _auto_referrals(new.id); end if;   -- auto_referrals_on_submit
  end if;
  return null;
end $function$;

-- جدول الأقساط وقيد الصرف للبرامج (الصرف للمورد بفاتورة أو لحساب المقترض حسب البرنامج — لا عمولة منصة على مورد غير مسجل)
create or replace function public._repay_hooks() returns trigger language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; pct numeric; c bigint; cnt int; sup text;
begin
  if not (new.program = 'solar' or _is_trade(new.program)) or new.stage <= old.stage then return new; end if;
  select * into me from profiles where id = auth.uid();
  if old.stage <= 33 and new.stage > 33 then
    cnt := _make_schedule(new.id);
    if cnt > 0 then
      perform _ev(new.id, 33, 'إصدار جدول الأقساط آلياً',
        cnt || ' قسطاً شهرياً بمبلغ ' || to_char(new.monthly_installment, 'FM999,999,999') || ' د.ع — أول استحقاق '
        || to_char((select min(due_date) from installments where application_id = new.id), 'YYYY-MM-DD'));
    end if;
  end if;
  if old.stage <= 35 and new.stage > 35 and not exists (select 1 from disbursements where application_id = new.id) then
    pct := case when new.supplier_id is null then 0 else _supplier_commission_pct(new.supplier_id) end;
    c := round(new.amount * pct / 100);
    insert into disbursements(application_id, bank_id, supplier_id, gross, commission_pct, commission, net, paid_by, paid_by_name, paid_by_title, paid_by_code)
    values (new.id, new.bank_id, new.supplier_id, new.amount, pct, c, new.amount - c, me.id, me.full_name, _role_title(me.role), me.staff_code);
    if new.supplier_id is not null then
      select name into sup from orgs where id = new.supplier_id;
      perform _ev(new.id, 35, 'قيد الصرف للمورد واستقطاع عمولة المنصة',
        'الإجمالي ' || to_char(new.amount, 'FM999,999,999') || ' · عمولة المنصة ' || pct || '% = ' || to_char(c, 'FM999,999,999')
        || ' · الصافي للمورد ' || to_char(new.amount - c, 'FM999,999,999') || ' د.ع');
      perform _notify(new.supplier_id, 'supplier', 'disbursement', 'صُرف مبلغ الطلب ' || new.code,
        'الصافي ' || to_char(new.amount - c, 'FM999,999,999') || ' د.ع بعد استقطاع عمولة المنصة ' || pct || '%', new.id);
    else
      perform _ev(new.id, 35, 'قيد صرف التمويل', to_char(new.amount, 'FM999,999,999') || ' د.ع — '
        || case (select params->>'disburse' from bank_programs where id = new.program_id) when 'account' then 'إلى حساب المقترض ' || coalesce(new.bank_account, '')
             when 'mixed' then 'للموردين بفواتير والباقي لحساب المقترض' else 'للموردين بفواتير' end);
    end if;
  end if;
  return new;
end $function$;

-- ═══ 6) بيانات العرض ═══
do $$
declare b uuid; i uuid; md text;
begin
  select id into b from orgs where code = 'tpi';
  select id into i from orgs where code = 'ind';
  if b is not null and not exists (select 1 from bank_programs where code = 'P-TPI-001') then
    select full_name into md from profiles where username = 'tpi.md';
    insert into bank_programs(code, bank_id, kind, name, summary, status, params, launched_at, launched_by, created_by) values
    ('P-TPI-001', b, 'export', 'تمويل المصدّرين — ما قبل الشحن', 'تمويل شراء البضاعة وتجهيزها للتصدير بعقد أو طلبية من مستورد خارجي، بدعم الاتحاد الأوروبي.', 'active',
      _bp_norm('export', '{"min_amount":10000000,"max_amount":500000000,"min_term":6,"max_term":36,"grace_max":6,"rate":4,"commission_pct":0.5,"file_fee":100000,"budget":20000000000,"min_activity_months":12,"disburse":"supplier","funding":"eu","guarantees":["mortgage","multi_salary","gold"],"docs":["biz_reg","biz_statement","biz_invoice"],"purposes":["شراء البضاعة المصدَّرة","التعبئة والتغليف","النقل والشحن"]}'::jsonb), now(), md, md),
    ('P-TPI-002', b, 'commercial', 'القرض التجاري للمحلات والشركات', 'رأس مال عامل أو شراء بضاعة أو تجهيز محل لتاجر مسجل في غرفة التجارة.', 'active',
      _bp_norm('commercial', '{"min_amount":5000000,"max_amount":150000000,"min_term":12,"max_term":60,"grace_max":3,"rate":7,"commission_pct":1,"file_fee":75000,"budget":0,"min_activity_months":6,"disburse":"mixed","funding":"bank","guarantees":["single_salary","multi_salary","mortgage","gold"],"docs":["biz_lease","biz_statement"],"purposes":["شراء بضاعة","رأس مال عامل","تجهيز المحل"]}'::jsonb), now(), md, md),
    ('P-TPI-003', b, 'ecommerce', 'تمويل المتاجر الإلكترونية', 'للمتاجر المسجلة في منصة «ضمان» والحاصلة على إجازة التجارة الإلكترونية من وزارة التجارة.', 'active',
      _bp_norm('ecommerce', '{"min_amount":3000000,"max_amount":75000000,"min_term":6,"max_term":48,"grace_max":3,"rate":6.5,"commission_pct":1,"file_fee":50000,"budget":5000000000,"min_activity_months":6,"disburse":"mixed","funding":"bank","guarantees":["single_salary","multi_salary","gold"],"docs":["ecm_sales"],"purposes":["مخزون بضاعة","تسويق إلكتروني","معدات تغليف وتوصيل","تطوير المتجر"]}'::jsonb), now(), md, md);
    insert into bank_program_log(program_id, bank_id, action, actor_name) select id, bank_id, 'إطلاق البرنامج', md from bank_programs where code like 'P-TPI-00%';
  end if;
  if i is not null and not exists (select 1 from bank_programs where code = 'P-IND-001') then
    select full_name into md from profiles where username = 'ind.md';
    insert into bank_programs(code, bank_id, kind, name, summary, status, params, launched_at, launched_by, created_by) values
    ('P-IND-001', i, 'commercial', 'تمويل الورش والمعامل الصغيرة', 'رأس مال تشغيلي ومواد أولية للورش والمعامل الصناعية الصغيرة.', 'active',
      _bp_norm('commercial', '{"min_amount":10000000,"max_amount":250000000,"min_term":12,"max_term":84,"grace_max":6,"rate":5,"commission_pct":0.75,"file_fee":50000,"budget":10000000000,"min_activity_months":12,"disburse":"supplier","funding":"bank","guarantees":["mortgage","multi_salary"],"docs":["biz_license","biz_lease","biz_invoice"],"purposes":["مواد أولية","رأس مال تشغيلي","مكائن ومعدات"]}'::jsonb), now(), md, md);
    insert into bank_program_log(program_id, bank_id, action, actor_name) select id, bank_id, 'إطلاق البرنامج', md from bank_programs where code = 'P-IND-001';
  end if;
  if b is not null then
    if coalesce((_org_readiness(b)->>'ok')::boolean, false) then update orgs set meta = meta || '{"accepting": true}'::jsonb where id = b; end if;
    perform _bp_sync(b);
  end if;
  if i is not null then perform _bp_sync(i); end if;
end $$;

-- مقترض تجريبي بلا طلب لتجربة برامج المصارف
do $$
declare uid uuid;
begin
  if not exists (select 1 from profiles where username = 'citizen7') then
    uid := _mk_user('citizen7', 'Alwah@1007', 'علي كريم جواد', 'citizen', 'citizen', null, '07701234507', '199003150007');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'بغداد', city = 'الكرادة', employer = 'القطاع الخاص',
      monthly_salary = 1500000, birth_date = '1990-03-15', must_change_password = false where id = uid;
  end if;
end $$;

revoke all on function public._bp_norm(text, jsonb), public._bp_sync(uuid), public._bp_me(), public._bp_used(uuid), public._trade_step(uuid, integer, jsonb), public._bp_fee_quote(uuid, bigint) from public, anon, authenticated;
grant execute on function public.bank_program_save(uuid, jsonb), public.bank_program_status(uuid, text, text), public.bank_initiative_join(text, boolean),
  public.start_trade_application(uuid, text, text), public.trade_doc_add(uuid, text, text, text, jsonb), public._bp_doc_label(text), public._bp_kind_label(text) to authenticated;
