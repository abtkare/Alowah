-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 52: اتحاد الصناعات العراقي والقرض الصناعي
--  1) جهة جديدة «اتحاد الصناعات العراقي» (نوعها union) وبوابة /union بخمسة أدوار:
--     قسم العضوية والتسجيل (union_reg) ← مهندس الكشف الصناعي (union_eng) ← لجنة الصنف (union_committee)
--     ← الأمين العام صاحب الصلاحية (union_sg)، والحسابات (union_fin) للأجور.
--  2) سجل الأعضاء: الهوية الصناعية IFI-… برمز تحقق QR، نافذة سنة، تجديد بالدفع الإلكتروني، تعليق.
--  3) نوع برنامج جديد للمصارف «القرض الصناعي» (industrial) — قطاع مستقل industrial_program.
--  4) دورة معاملة المقترض داخل الاتحاد:
--     وارد آلي (عند تثبيت مبلغ القرض) ← التدقيق والإحالة ← الكشف الموقعي بالـGPS والصور وتقدير الموجودات ومعقولية أسعار المكائن
--     ← توصية لجنة الصنف ← قرار الأمين العام ← كتاب تأييد صناعي مختوم ببصمة SHA-256 ورمز تحقق ← استلام المصرف وتأكيده.
--     ثم بعد الموافقة: تأييد نصب المكائن (حارس على المرحلة 32) ← تأييد بدء الإنتاج (موعد 90 يوماً بعد الصرف) ← متابعة بطلب المصرف.
--     مع الإعادة للاستكمال، والرفض المسبَّب، والاعتراض خلال 30 يوماً، وسحب الكتاب بسبب، والإنذار المبكر للمصرف والنزاهة.
-- الملف آمن للتكرار. تعديل الدوال القائمة يتم داخل القاعدة باستبدال نص يقع مرة واحدة.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة والبرنامج ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance','trade','eng_audit','sharia','insurer','union']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance','trade','auditor','sharia','insurance','union']));
alter table public.applications drop constraint if exists applications_program_check;
alter table public.applications add constraint applications_program_check check (program = any (array['solar','vet','export','commercial','ecommerce','industrial']));
alter table public.bank_programs drop constraint if exists bank_programs_kind_check;
alter table public.bank_programs add constraint bank_programs_kind_check check (kind = any (array['export','commercial','ecommerce','industrial']));

-- إصلاح من الجلسة 47: مستندات برامج المصارف (biz_*, exp_*, ecm_*) لم تكن مسموحة في قيد نوع المستند، فيفشل رفعها.
-- القيد الآن يضم كل مستندات البرامج ومستندات القرض الصناعي (ind_*).
alter table public.app_documents drop constraint if exists app_documents_kind_check;
alter table public.app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site',
  'mortgage_letter','annotation_mark','dd_letter','dd_auth','kyc_face','contract_signed','feasibility','expert_report','install_panels','install_inverter','install_video','eng_photo','ins_photo',
  'biz_reg','biz_chamber','biz_license','biz_lease','biz_statement','biz_invoice','biz_tax','biz_other','exp_license','exp_contract','ecm_license','ecm_daman','ecm_sales',
  'ind_dev_license','ind_quotes','ind_lease','ind_union','ind_machines','ind_feasibility','ind_trade_name']));

insert into public.settings(key, value, label, circular_no) values
  ('union_member_fee', 50000, 'اتحاد الصناعات: بدل الانتماء والهوية الصناعية السنوي (د.ع)', null),
  ('union_insp_pct', 0.1, 'اتحاد الصناعات: أجور الكشف نسبةً من مبلغ القرض (%)', null),
  ('union_insp_min', 50000, 'اتحاد الصناعات: أدنى أجور كشف (د.ع)', null),
  ('union_insp_max', 1000000, 'اتحاد الصناعات: أعلى أجور كشف (د.ع)', null),
  ('union_sla_days', 7, 'اتحاد الصناعات: مهلة إنجاز معاملة التأييد (أيام)', null),
  ('union_letter_days', 90, 'اتحاد الصناعات: مدة نفاذ كتاب التأييد الصناعي (أيام)', null),
  ('union_prod_days', 90, 'اتحاد الصناعات: مهلة تأييد بدء الإنتاج بعد صرف القرض (أيام)', null),
  ('union_appeal_days', 30, 'اتحاد الصناعات: مهلة الاعتراض على الرفض (أيام)', null)
on conflict (key) do nothing;

-- ───────── 2) الأدوار والتسميات (استبدال داخل الدوال الحية) ─────────
do $mig$
declare r record; src text; n int;
begin
  for r in select * from (values
    ('public._org_roles(text)',
     $x$    when 'insurer' then array['ins_branch_mgr', 'ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance', 'ins_md']$x$,
     $x$    when 'insurer' then array['ins_branch_mgr', 'ins_underwriter', 'ins_surveyor', 'ins_claims', 'ins_finance', 'ins_md']
    when 'union' then array['union_reg', 'union_eng', 'union_committee', 'union_fin', 'union_sg']$x$),
    ('public._portal_of_role(text)',
     $x$then 'insurance'$x$,
     $x$then 'insurance'
    when r in ('union_sg', 'union_reg', 'union_eng', 'union_committee', 'union_fin') then 'union'$x$),
    ('public._org_type_of_portal(text)',
     $x$when 'insurance' then 'insurer'$x$,
     $x$when 'insurance' then 'insurer' when 'union' then 'union'$x$),
    ('public._role_abbr(text)',
     $x$when 'platform_admin' then 'SA'$x$,
     $x$when 'union_sg' then 'SG' when 'union_reg' then 'UR' when 'union_eng' then 'UE' when 'union_committee' then 'UC' when 'union_fin' then 'UF'
    when 'platform_admin' then 'SA'$x$),
    ('public._role_title(text)',
     $x$when 'platform_admin' then 'مشغّل النظام$x$,
     $x$when 'union_sg' then 'الأمين العام — اتحاد الصناعات العراقي' when 'union_reg' then 'موظف قسم العضوية والتسجيل — اتحاد الصناعات'
    when 'union_eng' then 'مهندس الكشف الصناعي — اتحاد الصناعات' when 'union_committee' then 'عضو لجنة الصنف الصناعي — اتحاد الصناعات'
    when 'union_fin' then 'موظف الحسابات — اتحاد الصناعات'
    when 'platform_admin' then 'مشغّل النظام$x$),
    ('public.public_brand(text)',
     $x$'trade','sharia')$x$,
     $x$'trade','sharia','union')$x$),
    ('public.admin_set_bank_mode(uuid,jsonb)',
     $x$('solar', 'vet', 'export', 'commercial', 'ecommerce')$x$,
     $x$('solar', 'vet', 'export', 'commercial', 'ecommerce', 'industrial')$x$),
    ('public.planning_save_goal(jsonb,text)',
     $x$'ecommerce_program', 'export', 'other')$x$,
     $x$'ecommerce_program', 'industrial_program', 'export', 'other')$x$),
    ('public.cbi_publish_initiative(jsonb)',
     $x$'ecommerce_program'))$x$,
     $x$'ecommerce_program', 'industrial_program'))$x$),
    ('public.start_trade_application(uuid,text,text)',
     $x$when 'commercial' then 'COM' else 'ECM' end$x$,
     $x$when 'commercial' then 'COM' when 'industrial' then 'IND' else 'ECM' end$x$),
    ('public._bp_norm(text,jsonb)',
     $x$'conditions', left(trim(coalesce(p->>'conditions', '')), 800));$x$,
     $x$'conditions', left(trim(coalesce(p->>'conditions', '')), 800),
    'feasibility_from', coalesce(nullif(regexp_replace(coalesce(p->>'feasibility_from', ''), '[^0-9]', '', 'g'), '')::bigint, case when p_kind = 'industrial' then 150000000 else 0 end));$x$),
    ('public.citizen_step(uuid,integer,jsonb)',
     $x$return _trade_step(p_app, p_step, p_data);$x$,
     $x$if a.program = 'industrial' then return _ind_step(p_app, p_step, p_data); end if;   -- الجلسة 52
    return _trade_step(p_app, p_step, p_data);$x$),
    ('public.pay_application_fees(uuid,uuid,text,text)',
     $x$_bp_fee_quote(a.program_id, a.amount)$x$,
     $x$(_bp_fee_quote(a.program_id, a.amount) || _un_fee_items(a.id))$x$)
  ) v(fn, old, new) loop
    if to_regprocedure(r.fn) is null then raise exception 'الجلسة 52: الدالة % غير موجودة', r.fn; end if;
    src := pg_get_functiondef(r.fn::regprocedure);
    if position(r.new in src) > 0 then continue; end if;   -- طُبّق سابقاً
    n := (length(src) - length(replace(src, r.old, ''))) / length(r.old);
    if n <> 1 then raise exception 'الجلسة 52: النص المطلوب استبداله في % وُجد % مرة (المتوقع مرة واحدة)', r.fn, n; end if;
    if r.fn = 'public.pay_application_fees(uuid,uuid,text,text)' then
      -- الدالة المساعدة يجب أن توجد قبل إعادة تعريف الدفع
      execute $q$create or replace function public._un_fee_items(p_app uuid) returns jsonb language sql stable security definer set search_path = public as $f$ select '[]'::jsonb $f$$q$;
    end if;
    execute replace(src, r.old, r.new);
  end loop;
end $mig$;

-- إضافة جهة اتحاد الصناعات من مشغّل النظام (مرة واحدة عادةً)
create or replace function public._onboard_kind(k text) returns jsonb language sql immutable as $f$
  select case k
    when 'bank'           then '{"type":"bank","portal":"bank","role":"bank_md","title":"مصرف"}'::jsonb
    when 'supplier_solar' then '{"type":"supplier","portal":"supplier","role":"supplier_admin","kind":"solar","title":"مورد منظومات الطاقة الشمسية"}'::jsonb
    when 'supplier_vet'   then '{"type":"supplier","portal":"supplier","role":"supplier_admin","kind":"vet","title":"مورد الأجهزة والمواد الطبية البيطرية"}'::jsonb
    when 'eng_audit'      then '{"type":"eng_audit","portal":"auditor","role":"auditor_admin","title":"شركة فحص هندسي"}'::jsonb
    when 'insurer'        then '{"type":"insurer","portal":"insurance","role":"ins_md","title":"شركة تأمين"}'::jsonb
    when 'union'          then '{"type":"union","portal":"union","role":"union_sg","title":"اتحاد صناعات / غرفة صناعة"}'::jsonb
  end $f$;

-- ───────── 3) برنامج القرض الصناعي ─────────
create or replace function public._is_trade(p text) returns boolean language sql immutable as $f$ select p in ('export', 'commercial', 'ecommerce', 'industrial') $f$;
create or replace function public._bp_kind_label(p_kind text) returns text language sql immutable as $f$
  select case p_kind when 'export' then 'قروض المصدّرين' when 'commercial' then 'القروض التجارية' when 'ecommerce' then 'قروض التجارة الإلكترونية'
    when 'industrial' then 'القروض الصناعية' else p_kind end $f$;
create or replace function public._program_label(p text) returns text language sql immutable as $f$
  select case p when 'solar' then 'منظومات الطاقة الشمسية' when 'vet' then 'مشاريع الأطباء البيطريين' when 'export' then 'قروض المصدّرين'
    when 'commercial' then 'القروض التجارية' when 'ecommerce' then 'قروض التجارة الإلكترونية' when 'industrial' then 'القروض الصناعية' else p end $f$;
create or replace function public._bp_fixed_docs(p_kind text) returns text[] language sql immutable as $f$
  select case p_kind when 'export' then array['exp_license', 'exp_contract'] when 'ecommerce' then array['ecm_license', 'ecm_daman']
    when 'commercial' then array['biz_chamber'] when 'industrial' then array['ind_dev_license', 'ind_quotes'] else array[]::text[] end $f$;
create or replace function public._bp_doc_label(k text) returns text language sql immutable as $f$
  select case k
    when 'biz_reg' then 'شهادة تأسيس الشركة أو السجل التجاري'
    when 'biz_chamber' then 'هوية غرفة التجارة'
    when 'biz_license' then 'إجازة ممارسة المهنة أو النشاط'
    when 'biz_lease' then 'عقد إيجار المحل أو سند ملكيته'
    when 'biz_statement' then 'كشف حساب مصرفي أو دفتر المبيعات (آخر 6 أشهر)'
    when 'biz_invoice' then 'فاتورة أو عرض سعر المورد'
    when 'biz_tax' then 'براءة الذمة الضريبية'
    when 'exp_license' then 'إجازة التصدير'
    when 'exp_contract' then 'عقد أو طلبية المستورد'
    when 'ecm_license' then 'إجازة التجارة الإلكترونية من وزارة التجارة (منصة التاجر الإلكتروني)'
    when 'ecm_daman' then 'شهادة التسجيل في منصة «ضمان»'
    when 'ecm_sales' then 'سجل مبيعات المتجر (آخر 6 أشهر)'
    when 'ind_dev_license' then 'إجازة التأسيس من المديرية العامة للتنمية الصناعية'
    when 'ind_quotes' then 'عروض أسعار المكائن والمعدات المطلوب تمويلها'
    when 'ind_lease' then 'عقد إيجار أرض المعمل مصدَّق أو سند ملكيتها'
    when 'ind_union' then 'هوية اتحاد الصناعات العراقي'
    when 'ind_machines' then 'صور المكائن والمعمل الحالية'
    when 'ind_feasibility' then 'دراسة الجدوى الاقتصادية للمشروع'
    when 'ind_trade_name' then 'شهادة تسجيل الاسم التجاري لدى غرفة الصناعة'
    when 'biz_other' then 'مستند آخر'
  end $f$;

create or replace function public._app_sector(p_program text, p_purpose text) returns text
language sql immutable set search_path = public as $f$
  select case p_program
    when 'vet' then 'vet_program'
    when 'export' then 'export_program'
    when 'commercial' then 'commercial_program'
    when 'ecommerce' then 'ecommerce_program'
    when 'industrial' then 'industrial_program'
    else case when p_purpose is null or p_purpose = 'household' then 'residential' else p_purpose end end $f$;

-- الأصناف الصناعية كما في النظام الداخلي لاتحاد الصناعات العراقي رقم (1) لسنة 2024
create or replace function public._un_cat_label(c text) returns text language sql immutable as $f$
  select case c when 'food' then 'الصناعات الغذائية' when 'textile' then 'الصناعات النسيجية'
    when 'construction_sand' then 'الصناعات الإنشائية (الرمل والحصى والمقالع والطابوق والجص)' when 'construction' then 'الصناعات الإنشائية الأخرى'
    when 'wood' then 'الصناعات الخشبية' when 'chemical' then 'الصناعات الكيمياوية والبلاستيكية' when 'metal' then 'الصناعات المعدنية والهندسية'
    when 'other' then 'الصناعات الأخرى' end $f$;

-- ───────── 4) الجداول ─────────
create table if not exists public.union_members (
  id uuid primary key default gen_random_uuid(),
  code text unique,                                   -- رقم الهوية الصناعية IFI-2026-00001 يُمنح عند القبول
  org_id uuid references public.orgs(id),
  citizen_id uuid references public.profiles(id),
  owner_name text not null, national_id text, phone text,
  factory_name text not null,
  category text not null check (category in ('food','textile','construction_sand','construction','wood','chemical','metal','other')),
  legal_form text not null default 'individual' check (legal_form in ('individual','company')),
  governorate text not null, city text, address text, site_geo jsonb,
  trade_name_no text,                                 -- تسجيل الاسم التجاري لدى غرفة الصناعة (شرط الانتماء — المادة 17)
  dev_license_no text, dev_license_kind text check (dev_license_kind is null or dev_license_kind in ('under','complete')),
  capital bigint, workers int, products text, capacity text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','suspended','expired')),
  joined_at date, valid_until date, verify_code text unique, seal text,
  decided_by_name text, decided_at timestamptz, reason text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists union_members_citizen on public.union_members(citizen_id);

create table if not exists public.union_files (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                          -- UF-2026-00001
  org_id uuid references public.orgs(id),
  kind text not null check (kind in ('membership','endorse','install','production','followup')),
  member_id uuid references public.union_members(id),
  application_id uuid references public.applications(id),
  status text not null default 'new' check (status in ('new','returned','inspection','committee','signing','issued','delivered','done','rejected','cancelled')),
  engineer_id uuid references public.profiles(id), engineer_name text,
  amount bigint, fee bigint not null default 0, fee_paid_at timestamptz, fee_ref text,
  inspection jsonb, committee jsonb, decision jsonb, appeal jsonb,
  return_note text, returned_by text,
  origin text, note text, due_at timestamptz,
  created_by_name text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), closed_at timestamptz
);
create index if not exists union_files_app on public.union_files(application_id);
create index if not exists union_files_member on public.union_files(member_id);

create table if not exists public.union_docs (
  id uuid primary key default gen_random_uuid(),
  file_id uuid references public.union_files(id), member_id uuid references public.union_members(id),
  kind text not null, label text, mime text, data text, bytes int, sha256 text, meta jsonb not null default '{}'::jsonb,
  uploaded_by uuid, uploaded_by_name text, created_at timestamptz not null default now()
);
create index if not exists union_docs_file on public.union_docs(file_id);

create table if not exists public.union_letters (
  id uuid primary key default gen_random_uuid(),
  no text unique not null,                            -- IFI/OUT/2026/00001
  file_id uuid references public.union_files(id), member_id uuid references public.union_members(id),
  application_id uuid references public.applications(id), bank_id uuid references public.orgs(id),
  kind text not null check (kind in ('membership','endorse','install','production','followup')),
  title text not null, body jsonb not null, sha256 text not null, verify_code text unique not null,
  issued_by uuid, issued_by_name text, issued_by_title text, issued_at timestamptz not null default now(), valid_until date,
  revoked_at timestamptz, revoke_reason text, revoked_by_name text, superseded_by uuid,
  ack_at timestamptz, ack_by_name text, ack_by_title text, ack_no text
);
create index if not exists union_letters_app on public.union_letters(application_id);

create table if not exists public.union_log (
  id bigserial primary key, file_id uuid, member_id uuid, letter_id uuid,
  actor_id uuid, actor_name text, actor_title text, action text not null, note text, created_at timestamptz not null default now()
);
create index if not exists union_log_file on public.union_log(file_id);

alter table public.union_members enable row level security;
alter table public.union_files enable row level security;
alter table public.union_docs enable row level security;
alter table public.union_letters enable row level security;
alter table public.union_log enable row level security;
-- القراءة المباشرة لموظفي الاتحاد ولصاحب العلاقة (للتحديث اللحظي)؛ الكتابة عبر الدوال فقط، والجهات الأخرى عبر union_app_report
drop policy if exists um_read on public.union_members;
create policy um_read on public.union_members for select to authenticated using (my_portal() = 'union' or citizen_id = auth.uid());
drop policy if exists uf_read on public.union_files;
create policy uf_read on public.union_files for select to authenticated
  using (my_portal() = 'union' or exists (select 1 from union_members m where m.id = member_id and m.citizen_id = auth.uid()));
drop policy if exists ul_read on public.union_letters;
create policy ul_read on public.union_letters for select to authenticated
  using (my_portal() = 'union' or exists (select 1 from union_members m where m.id = member_id and m.citizen_id = auth.uid()));
grant select on public.union_members, public.union_files, public.union_letters to authenticated;
revoke all on public.union_docs, public.union_log from anon, authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'union_files') then
      alter publication supabase_realtime add table public.union_files; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'union_letters') then
      alter publication supabase_realtime add table public.union_letters; end if;
  end if;
end $$;

-- ───────── 5) أدوات ─────────
create or replace function public._un_org() returns uuid language sql stable security definer set search_path = public as $f$
  select id from orgs where type = 'union' and not coalesce((meta->>'suspended')::boolean, false) order by (code = 'ifi') desc, created_at limit 1 $f$;

create or replace function public._un_me() returns profiles language plpgsql stable security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'union' or coalesce(me.disabled, false) then raise exception 'هذه الصفحة لموظفي اتحاد الصناعات'; end if;
  return me;
end $f$;

create or replace function public._un_status_label(s text) returns text language sql immutable as $f$
  select case s when 'new' then 'وارد — قسم العضوية والتسجيل' when 'returned' then 'أُعيد للصناعي لاستكمال النواقص' when 'inspection' then 'الكشف الموقعي'
    when 'committee' then 'لجنة الصنف' when 'signing' then 'بانتظار قرار الأمين العام' when 'issued' then 'صدر الكتاب' when 'delivered' then 'استلمه المصرف'
    when 'done' then 'أُنجز' when 'rejected' then 'مرفوض' when 'cancelled' then 'ملغى' else s end $f$;
create or replace function public._un_kind_label(k text) returns text language sql immutable as $f$
  select case k when 'membership' then 'انتماء وهوية صناعية' when 'endorse' then 'تأييد صناعي لقرض' when 'install' then 'تأييد نصب المكائن'
    when 'production' then 'تأييد بدء الإنتاج' when 'followup' then 'كشف متابعة' else k end $f$;

create or replace function public._un_vcode() returns text language plpgsql volatile as $f$
declare c text; i int;
begin
  loop
    c := 'IF';
    for i in 1 .. 8 loop c := c || substr('ABCDEFGHJKMNPQRSTUVWXYZ23456789', 1 + floor(random() * 31)::int, 1); end loop;
    exit when not exists (select 1 from union_letters where verify_code = c) and not exists (select 1 from union_members where verify_code = c);
  end loop;
  return c;
end $f$;

create or replace function public._un_log(p_file uuid, p_member uuid, p_letter uuid, p_action text, p_note text) returns void
language sql security definer set search_path = public as $f$
  insert into union_log(file_id, member_id, letter_id, actor_id, actor_name, actor_title, action, note)
  select p_file, p_member, p_letter, auth.uid(), coalesce((select full_name from profiles where id = auth.uid()), 'النظام'),
    coalesce((select _role_title(role) from profiles where id = auth.uid()), 'آلياً'), p_action, nullif(trim(coalesce(p_note, '')), '') $f$;

-- إشعار أدوار في الاتحاد (لكل موظف بالدور، وإن لم يوجد: إشعار عام للجهة)
create or replace function public._un_notify(p_roles text[], p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path = public as $f$
declare o uuid := _un_org(); n int;
begin
  if o is null then return; end if;
  insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
  select o, p.id, 'union', 'union', p_title, p_body, p_ref from profiles p
  where p.org_id = o and p.role = any(p_roles) and not coalesce(p.disabled, false);
  get diagnostics n = row_count;
  if n = 0 then perform _notify(o, 'union', 'union', p_title, p_body, p_ref); end if;
end $f$;

create or replace function public._un_tell_citizen(p_member uuid, p_title text, p_body text, p_ref uuid) returns void
language sql security definer set search_path = public as $f$
  insert into notifications(user_id, portal, kind, title, body, ref_id)
  select m.citizen_id, 'citizen', 'union', p_title, p_body, p_ref from union_members m where m.id = p_member and m.citizen_id is not null $f$;

create or replace function public._un_insp_fee(p_amount bigint) returns bigint language sql stable security definer set search_path = public as $f$
  select greatest(coalesce(_setting('union_insp_min'), 50000), least(coalesce(_setting('union_insp_max'), 1000000),
    round(coalesce(p_amount, 0) * coalesce(_setting('union_insp_pct'), 0.1) / 100)))::bigint $f$;

-- أجور الاتحاد ضمن دفعة المقترض قبل الإرسال (أجور الكشف + بدل الانتماء للعضو الجديد)
create or replace function public._un_fee_items(p_app uuid) returns jsonb language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(jsonb_build_object('key', 'union_fee', 'label', 'أجور كشف وتأييد اتحاد الصناعات العراقي' ||
      case when f.note = 'new_member' then ' + بدل الانتماء' else '' end || ' — ' || f.code, 'amount', f.fee)), '[]'::jsonb)
  from union_files f where f.application_id = p_app and f.kind = 'endorse' and f.status in ('issued', 'delivered') and f.fee > 0 and f.fee_paid_at is null $f$;

-- المهندس: المحدد، أو مهندس الاتحاد الأقل انشغالاً في المحافظة، وإلا الأقل انشغالاً
create or replace function public._un_pick_eng(p_gov text, p_want uuid) returns profiles language plpgsql stable security definer set search_path = public as $f$
declare e profiles;
begin
  if p_want is not null then
    select * into e from profiles where id = p_want and role = 'union_eng' and org_id = _un_org() and not coalesce(disabled, false);
    if e.id is null then raise exception 'المهندس غير موجود في الاتحاد'; end if;
    return e;
  end if;
  select p.* into e from profiles p where p.role = 'union_eng' and p.org_id = _un_org() and not coalesce(p.disabled, false)
  order by (p.governorate is not distinct from p_gov) desc,
    (select count(*) from union_files f where f.engineer_id = p.id and f.status = 'inspection'), p.created_at limit 1;
  return e;
end $f$;

-- العضو صالح: مقبول ونافذ
create or replace function public._un_member_ok(m union_members) returns boolean language sql stable as $f$
  select m.id is not null and m.status = 'approved' and coalesce(m.valid_until, current_date) >= current_date $f$;

-- كتاب التأييد صالح لإرسال الطلب: غير مسحوب ولا منتهٍ ويغطي مبلغ القرض، وعضوية نافذة
create or replace function public._un_letter_ok(p_app uuid) returns boolean language sql stable security definer set search_path = public as $f$
  select exists (select 1 from union_letters l join applications a on a.id = l.application_id join union_members m on m.id = l.member_id
    where l.application_id = p_app and l.kind = 'endorse' and l.revoked_at is null and coalesce(l.valid_until, current_date) >= current_date
      and coalesce((l.body->>'amount')::bigint, 0) >= coalesce(a.amount, 0) and _un_member_ok(m)) $f$;

-- إصدار كتاب ببصمة SHA-256 ورمز تحقق
create or replace function public._un_issue_letter(f union_files, p_title text, p_body jsonb, p_valid date) returns union_letters
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; l union_letters; v_no text; v_code text := _un_vcode(); v_body jsonb; v_n int;
begin
  select * into me from profiles where id = auth.uid();
  select count(*) + 1 into v_n from union_letters where no like 'IFI/OUT/' || to_char(now(), 'YYYY') || '/%';
  v_no := 'IFI/OUT/' || to_char(now(), 'YYYY') || '/' || lpad(v_n::text, 5, '0');
  v_body := p_body || jsonb_build_object('no', v_no, 'issued_at', now(), 'issuer', me.full_name, 'issuer_title', _role_title(me.role), 'issuer_code', me.staff_code,
    'file', f.code, 'verify', v_code, 'valid_until', p_valid);
  insert into union_letters(no, file_id, member_id, application_id, bank_id, kind, title, body, sha256, verify_code, issued_by, issued_by_name, issued_by_title, valid_until)
  values (v_no, f.id, f.member_id, f.application_id,
    (select coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid) from applications a where a.id = f.application_id),
    f.kind, p_title, v_body, encode(extensions.digest(convert_to(v_body::text, 'UTF8'), 'sha256'), 'hex'), v_code, me.id, me.full_name, _role_title(me.role), p_valid)
  returning * into l;
  perform _un_log(f.id, f.member_id, l.id, 'إصدار الكتاب ' || v_no, p_title);
  return l;
end $f$;

-- ───────── 6) إنشاء المعاملات ─────────
create or replace function public._un_new_file(p_kind text, p_member uuid, p_app uuid, p_status text, p_amount bigint, p_fee bigint, p_origin text, p_note text, p_eng uuid)
returns union_files language plpgsql security definer set search_path = public as $f$
declare f union_files; e profiles; m union_members;
begin
  select * into m from union_members where id = p_member;
  if p_status = 'inspection' then e := _un_pick_eng(m.governorate, p_eng); end if;
  insert into union_files(code, org_id, kind, member_id, application_id, status, engineer_id, engineer_name, amount, fee, origin, note, due_at, created_by_name)
  values (_vet_seq('UF', 'union_files', 'code'), coalesce(_un_org(), m.org_id), p_kind, p_member, p_app, p_status, e.id, e.full_name, p_amount, coalesce(p_fee, 0), p_origin, p_note,
    case when p_kind = 'production' then now() + make_interval(days => coalesce(_setting('union_prod_days'), 90)::int)
         else now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int) end,
    coalesce((select full_name from profiles where id = auth.uid()), 'النظام'))
  returning * into f;
  perform _un_log(f.id, f.member_id, null, 'فتح معاملة: ' || _un_kind_label(p_kind), coalesce(p_origin, '') || coalesce(' — ' || p_note, ''));
  if p_status = 'new' then
    perform _un_notify(array['union_reg', 'union_sg'], 'معاملة واردة ' || f.code || ': ' || _un_kind_label(p_kind), m.factory_name || ' — ' || m.governorate, f.id);
  elsif e.id is not null then
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
    values (f.org_id, e.id, 'union', 'union', 'كشف موقعي مسند إليك: ' || f.code, _un_kind_label(p_kind) || ' — ' || m.factory_name || ' · ' || m.governorate, f.id);
  end if;
  return f;
end $f$;

-- مزامنة معاملة التأييد مع طلب القرض (عند تثبيت المبلغ والمستندات في الخطوة 3)
create or replace function public._un_sync(p_app uuid) returns void language plpgsql security definer set search_path = public as $f$
declare a applications; m union_members; f union_files; l union_letters; v_fee bigint;
begin
  select * into a from applications where id = p_app;
  select * into m from union_members where id = nullif(a.biz->>'member_id', '')::uuid;
  if m.id is null then raise exception 'أكمل بيانات المعمل والهوية الصناعية في الخطوة السابقة'; end if;
  select * into f from union_files where application_id = a.id and kind = 'endorse' and status <> 'cancelled' order by created_at desc limit 1;
  v_fee := _un_insp_fee(a.amount) + case when m.status = 'approved' then 0 else coalesce(_setting('union_member_fee'), 50000)::bigint end;
  if f.id is null then
    f := _un_new_file('endorse', m.id, a.id, 'new', a.amount, v_fee, 'آلياً من طلب القرض ' || a.code, case when m.status <> 'approved' then 'new_member' end, null);
    perform _ev(a.id, 3, 'إحالة آلية إلى اتحاد الصناعات العراقي لطلب التأييد الصناعي', f.code || ' — ' || _un_status_label('new'));
  elsif f.status = 'rejected' then
    if f.updated_at > now() - make_interval(days => coalesce(_setting('union_appeal_days'), 30)::int) then
      raise exception 'رفض اتحاد الصناعات طلب التأييد (%): % — يمكنك الاعتراض من صفحة «اتحاد الصناعات»', f.code, coalesce(f.decision->>'reason', ''); end if;
    f := _un_new_file('endorse', m.id, a.id, 'new', a.amount, v_fee, 'طلب جديد بعد رفض سابق ' || f.code, case when m.status <> 'approved' then 'new_member' end, null);
  elsif f.status = 'returned' then
    update union_files set status = 'new', amount = a.amount, fee = v_fee, return_note = null, updated_at = now(),
      due_at = now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int) where id = f.id;
    perform _un_log(f.id, m.id, null, 'أعاد الصناعي المعاملة بعد الاستكمال', null);
    perform _un_notify(array['union_reg', 'union_sg'], 'عادت المعاملة ' || f.code || ' بعد الاستكمال', m.factory_name, f.id);
  elsif f.status in ('new', 'inspection', 'committee', 'signing') then
    if f.amount is distinct from a.amount then
      update union_files set amount = a.amount, fee = v_fee, updated_at = now() where id = f.id;
      perform _un_log(f.id, m.id, null, 'عدّل الصناعي مبلغ القرض', to_char(a.amount, 'FM999,999,999,999') || ' د.ع');
    end if;
  elsif f.status in ('issued', 'delivered') then
    select * into l from union_letters where file_id = f.id and kind = 'endorse' and revoked_at is null order by issued_at desc limit 1;
    if l.id is not null and a.amount > coalesce((l.body->>'amount')::bigint, 0) then
      update union_letters set revoked_at = now(), revoke_reason = 'زيادة مبلغ القرض بعد التأييد — يلزم تأييد جديد', revoked_by_name = 'النظام' where id = l.id;
      update union_files set status = 'cancelled', closed_at = now(), updated_at = now() where id = f.id;
      perform _un_log(f.id, m.id, l.id, 'سحب آلي للكتاب ' || l.no, 'زاد المقترض مبلغ القرض فوق المؤيَّد');
      f := _un_new_file('endorse', m.id, a.id, 'new', a.amount, v_fee, 'تأييد جديد بعد زيادة المبلغ', case when m.status <> 'approved' then 'new_member' end, null);
    end if;
  end if;
end $f$;

-- ───────── 7) خطوات المقترض في القرض الصناعي (فوق _trade_step) ─────────
create or replace function public._ind_step(p_app uuid, p_step integer, p_data jsonb) returns applications
language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications; bp bank_programs; m union_members; v_mode text; v_cat text; v_no text; r applications; v_amount bigint; f union_files; pay payments;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  select * into bp from bank_programs where id = a.program_id;
  p_data := coalesce(p_data, '{}'::jsonb);

  if p_step = 2 then
    v_mode := coalesce(nullif(p_data->>'union_mode', ''), 'member');
    v_cat := p_data->>'category';
    if _un_cat_label(v_cat) is null then raise exception 'اختر صنف الصناعة'; end if;
    if length(trim(coalesce(p_data->>'factory_name', ''))) < 3 then raise exception 'اكتب اسم المعمل أو المصنع'; end if;
    if length(trim(coalesce(p_data->>'products', ''))) < 3 then raise exception 'اكتب المنتجات'; end if;
    if length(trim(coalesce(p_data->>'dev_license_no', ''))) < 2 then raise exception 'اكتب رقم إجازة التأسيس من المديرية العامة للتنمية الصناعية'; end if;
    if coalesce(p_data->>'dev_license_kind', '') not in ('under', 'complete') then raise exception 'حدّد نوع الإجازة: تحت التأسيس أم كاملة التأسيس'; end if;
    if v_mode = 'member' then
      v_no := upper(trim(coalesce(p_data->>'union_no', '')));
      select * into m from union_members where code = v_no;
      if m.id is null then raise exception 'رقم الهوية الصناعية % غير موجود في سجل اتحاد الصناعات — تأكد منه، أو اختر «لست عضواً بعد»', v_no; end if;
      if m.citizen_id is distinct from me.id and m.national_id is distinct from me.national_id then raise exception 'الهوية الصناعية % ليست باسمك', v_no; end if;
      if m.status = 'suspended' then raise exception 'عضويتك في اتحاد الصناعات معلّقة — راجع الاتحاد'; end if;
      if m.status = 'expired' or (m.status = 'approved' and m.valid_until < current_date) then raise exception 'هويتك الصناعية منتهية منذ % — جدّدها من صفحة «اتحاد الصناعات» ثم عُد', m.valid_until; end if;
      if m.status <> 'approved' then raise exception 'عضويتك ما زالت قيد الدراسة لدى الاتحاد — اختر «لست عضواً بعد» ليُدرس انتماؤك مع القرض'; end if;
      update union_members set citizen_id = me.id, updated_at = now() where id = m.id and citizen_id is null;
    elsif v_mode = 'new' then
      select * into m from union_members where citizen_id = me.id and status in ('approved', 'pending') order by (status = 'approved') desc, created_at desc limit 1;
      if m.status = 'approved' and m.valid_until >= current_date then raise exception 'لديك هوية صناعية نافذة (%) — اختر «عضو في الاتحاد» واكتب رقمها', m.code; end if;
      if m.id is null then
        insert into union_members(org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address,
          trade_name_no, dev_license_no, dev_license_kind, capital, workers, products, capacity)
        values (_un_org(), me.id, me.full_name, me.national_id, me.phone, trim(p_data->>'factory_name'), v_cat, coalesce(nullif(p_data->>'legal_form', ''), 'individual'),
          coalesce(nullif(p_data->>'governorate', ''), a.governorate), nullif(trim(coalesce(p_data->>'city', '')), ''), nullif(trim(coalesce(p_data->>'address', '')), ''),
          nullif(trim(coalesce(p_data->>'trade_name_no', '')), ''), trim(p_data->>'dev_license_no'), p_data->>'dev_license_kind',
          nullif(regexp_replace(coalesce(p_data->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint, nullif(regexp_replace(coalesce(p_data->>'workers', ''), '[^0-9]', '', 'g'), '')::int,
          trim(p_data->>'products'), nullif(trim(coalesce(p_data->>'capacity', '')), ''))
        returning * into m;
      elsif m.status = 'pending' then
        update union_members set factory_name = trim(p_data->>'factory_name'), category = v_cat, governorate = coalesce(nullif(p_data->>'governorate', ''), governorate),
          city = nullif(trim(coalesce(p_data->>'city', '')), ''), address = nullif(trim(coalesce(p_data->>'address', '')), ''),
          trade_name_no = nullif(trim(coalesce(p_data->>'trade_name_no', '')), ''), dev_license_no = trim(p_data->>'dev_license_no'), dev_license_kind = p_data->>'dev_license_kind',
          workers = nullif(regexp_replace(coalesce(p_data->>'workers', ''), '[^0-9]', '', 'g'), '')::int, products = trim(p_data->>'products'),
          capacity = nullif(trim(coalesce(p_data->>'capacity', '')), ''), updated_at = now()
        where id = m.id returning * into m;
      end if;
    else
      raise exception 'حدّد: هل أنت عضو في اتحاد الصناعات؟';
    end if;
    r := _trade_step(p_app, 2, p_data || jsonb_build_object('business_name', trim(p_data->>'factory_name'), 'activity', _un_cat_label(v_cat) || ' — ' || trim(p_data->>'products'),
      'reg_no', coalesce(m.code, trim(p_data->>'dev_license_no')), 'employees', p_data->>'workers'));
    update applications set purpose = 'industrial', biz = coalesce(biz, '{}') || jsonb_build_object('member_id', m.id, 'union_no', m.code, 'union_mode', v_mode,
      'category', v_cat, 'category_label', _un_cat_label(v_cat), 'products', trim(p_data->>'products'), 'dev_license_no', trim(p_data->>'dev_license_no'),
      'dev_license_kind', p_data->>'dev_license_kind', 'trade_name_no', nullif(trim(coalesce(p_data->>'trade_name_no', '')), ''),
      'capacity', nullif(trim(coalesce(p_data->>'capacity', '')), ''), 'new_member', m.status <> 'approved')
    where id = a.id returning * into r;
    -- إن وُجدت معاملة مفتوحة يُحدَّث ربطها بالعضو
    update union_files set member_id = m.id, updated_at = now() where application_id = a.id and kind = 'endorse' and status in ('new', 'returned') and member_id is distinct from m.id;
    return r;

  elsif p_step = 3 then
    v_amount := nullif(regexp_replace(coalesce(p_data->>'amount', ''), '[^0-9]', '', 'g'), '')::bigint;
    if coalesce((bp.params->>'feasibility_from')::bigint, 0) > 0 and coalesce(v_amount, 0) >= (bp.params->>'feasibility_from')::bigint
       and not exists (select 1 from app_documents d where d.application_id = a.id and d.kind = 'ind_feasibility') then
      raise exception 'القرض من % د.ع فأكثر يتطلب دراسة الجدوى الاقتصادية — أرفقها في قائمة المستندات', to_char((bp.params->>'feasibility_from')::bigint, 'FM999,999,999,999'); end if;
    r := _trade_step(p_app, 3, p_data);
    perform _un_sync(a.id);
    return r;

  elsif p_step = 5 then
    if not _un_letter_ok(a.id) then
      select * into f from union_files where application_id = a.id and kind = 'endorse' and status <> 'cancelled' order by created_at desc limit 1;
      raise exception 'بانتظار كتاب التأييد من اتحاد الصناعات العراقي (%: %) — يصلك إشعار حين يصدر', coalesce(f.code, '—'), _un_status_label(coalesce(f.status, 'new'));
    end if;
    r := _trade_step(p_app, 5, p_data);
    select * into pay from payments where application_id = a.id and status = 'paid' order by paid_at desc nulls last limit 1;
    update union_files set fee_paid_at = now(), fee_ref = pay.ref where application_id = a.id and kind = 'endorse' and status in ('issued', 'delivered') and fee_paid_at is null;
    return r;
  end if;
  return _trade_step(p_app, p_step, p_data);
end $f$;

-- ───────── 8) الحرّاس والمعاملات الآلية على طلب القرض ─────────
-- لا إرسال للمصرف دون تأييد نافذ، ولا خروج من الكشف والاستلام (32) قبل تأييد الاتحاد لنصب المكائن
create or replace function public._ind_guard() returns trigger language plpgsql security definer set search_path = public as $f$
declare f union_files;
begin
  if new.program is distinct from 'industrial' or new.stage <= old.stage then return new; end if;
  if old.stage <= 5 and new.stage >= 6 and not _un_letter_ok(new.id) then
    raise exception 'القرض الصناعي: لا يُرسل الطلب دون كتاب تأييد نافذ من اتحاد الصناعات العراقي'; end if;
  if old.stage = 32 and new.stage > 32 then
    select * into f from union_files where application_id = new.id and kind = 'install' and status <> 'cancelled' order by created_at desc limit 1;
    if f.id is null or f.status <> 'done' or coalesce(f.decision->>'result', '') <> 'ok' then
      raise exception 'القرض الصناعي: بانتظار تأييد اتحاد الصناعات لنصب المكائن ومطابقتها (%: %)', coalesce(f.code, 'لم تُفتح بعد'),
        case when f.status = 'done' then 'النتيجة غير مطابقة — راجع الاتحاد' else _un_status_label(coalesce(f.status, 'new')) end;
    end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_a1_ind_guard on public.applications;
create trigger trg_a1_ind_guard before update of stage on public.applications for each row execute function public._ind_guard();

create or replace function public._un_on_app() returns trigger language plpgsql security definer set search_path = public as $f$
declare m uuid;
begin
  if new.program is distinct from 'industrial' then return null; end if;
  m := nullif(new.biz->>'member_id', '')::uuid;
  if m is not null and new.stage >= 32 and old.stage < 32 and new.status = 'active'
     and not exists (select 1 from union_files where application_id = new.id and kind = 'install' and status <> 'cancelled') then
    begin
      perform _un_new_file('install', m, new.id, 'inspection', new.amount, 0, 'آلياً — وصول القرض ' || new.code || ' إلى الكشف والاستلام (المرحلة 32)', null, null);
      perform _ev(new.id, 32, 'طلب آلي لاتحاد الصناعات: تأييد نصب المكائن ومطابقتها', null);
    exception when others then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('union_unassigned', 'medium', 'تعذّر إسناد كشف نصب المكائن لاتحاد الصناعات', new.code || ': ' || sqlerrm, new.id, coalesce(new.governorate, ''));
    end;
  end if;
  if m is not null and new.stage > 35 and old.stage <= 35
     and not exists (select 1 from union_files where application_id = new.id and kind = 'production' and status <> 'cancelled') then
    begin
      perform _un_new_file('production', m, new.id, 'inspection', new.amount, 0, 'آلياً — بعد صرف القرض ' || new.code, null, null);
    exception when others then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('union_unassigned', 'medium', 'تعذّر إسناد كشف بدء الإنتاج لاتحاد الصناعات', new.code || ': ' || sqlerrm, new.id, coalesce(new.governorate, ''));
    end;
  end if;
  if new.status in ('cancelled', 'rejected') and old.status is distinct from new.status then
    update union_files set status = 'cancelled', closed_at = now(), updated_at = now(), note = coalesce(note || ' · ', '') || 'أُلغي طلب القرض'
    where application_id = new.id and status in ('new', 'returned', 'inspection', 'committee', 'signing');
  end if;
  return null;
end $f$;
drop trigger if exists trg_un_on_app on public.applications;
create trigger trg_un_on_app after update on public.applications for each row execute function public._un_on_app();

-- انتهاء الهويات غير المجددة
create or replace function public._un_scan() returns void language sql security definer set search_path = public as $f$
  update union_members set status = 'expired', updated_at = now() where status = 'approved' and valid_until < current_date $f$;

-- ───────── 9) المقترض والصناعي ─────────
create or replace function public.union_my() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'سجّل الدخول'; end if;
  perform set_config('alwah.face_skip', '1', true); perform _un_scan(); perform set_config('alwah.face_skip', '', true);
  return jsonb_build_object(
    'org', (select jsonb_build_object('id', id, 'name', name) from orgs where id = _un_org()),
    'fees', jsonb_build_object('member', coalesce(_setting('union_member_fee'), 50000), 'appeal_days', coalesce(_setting('union_appeal_days'), 30)),
    'members', coalesce((select jsonb_agg(to_jsonb(m) - 'seal' || jsonb_build_object('category_label', _un_cat_label(m.category),
        'valid', _un_member_ok(m)) order by m.created_at desc) from union_members m where m.citizen_id = me.id), '[]'),
    'files', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _un_kind_label(f.kind), 'status', f.status,
        'status_label', _un_status_label(f.status), 'return_note', f.return_note, 'reason', f.decision->>'reason', 'appeal', f.appeal, 'fee', f.fee, 'fee_paid_at', f.fee_paid_at,
        'app', (select code from applications where id = f.application_id), 'application_id', f.application_id, 'updated_at', f.updated_at,
        'can_appeal', f.status = 'rejected' and f.appeal is null and f.updated_at > now() - make_interval(days => coalesce(_setting('union_appeal_days'), 30)::int),
        'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label)), '[]') from union_docs d where d.file_id = f.id and d.kind <> 'visit_photo'))
        order by f.created_at desc) from union_files f join union_members m on m.id = f.member_id where m.citizen_id = me.id), '[]'),
    'letters', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'no', l.no, 'kind', l.kind, 'title', l.title, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
        'verify_code', l.verify_code, 'revoked_at', l.revoked_at, 'revoke_reason', l.revoke_reason, 'ack_at', l.ack_at, 'body', l.body, 'sha256', l.sha256) order by l.issued_at desc)
        from union_letters l join union_members m on m.id = l.member_id where m.citizen_id = me.id), '[]'));
end $f$;

-- طلب انتماء مستقل (دون قرض) مع دفع البدل وأجور الكشف إلكترونياً
create or replace function public.union_member_apply(p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; f union_files; v_cat text := p->>'category'; v_fee bigint;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'citizen' then raise exception 'التقديم من بوابة المقترض'; end if;
  if _un_org() is null then raise exception 'اتحاد الصناعات غير مضاف إلى المنصة بعد'; end if;
  if exists (select 1 from union_members where citizen_id = me.id and status = 'approved' and valid_until >= current_date) then raise exception 'لديك هوية صناعية نافذة'; end if;
  if exists (select 1 from union_files uf join union_members x on x.id = uf.member_id where x.citizen_id = me.id and uf.kind in ('membership', 'endorse')
     and uf.status in ('new', 'returned', 'inspection', 'committee', 'signing')) then raise exception 'لديك معاملة انتماء قيد الدراسة — تابعها من هذه الصفحة'; end if;
  if _un_cat_label(v_cat) is null then raise exception 'اختر صنف الصناعة'; end if;
  if length(trim(coalesce(p->>'factory_name', ''))) < 3 then raise exception 'اكتب اسم المعمل'; end if;
  if coalesce(p->>'governorate', '') = '' then raise exception 'اختر محافظة المعمل'; end if;
  if length(trim(coalesce(p->>'address', ''))) < 4 then raise exception 'اكتب عنوان المعمل'; end if;
  if length(trim(coalesce(p->>'products', ''))) < 3 then raise exception 'اكتب المنتجات'; end if;
  if length(trim(coalesce(p->>'trade_name_no', ''))) < 2 then raise exception 'اكتب رقم تسجيل الاسم التجاري لدى غرفة الصناعة (شرط الانتماء)'; end if;
  if coalesce(p->>'method', '') not in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p->>'otp') then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  select * into m from union_members where citizen_id = me.id and status in ('pending', 'rejected', 'expired') order by created_at desc limit 1;
  if m.id is null or m.status <> 'pending' then
    insert into union_members(org_id, citizen_id, owner_name, national_id, phone, factory_name, category, legal_form, governorate, city, address, site_geo,
      trade_name_no, dev_license_no, dev_license_kind, capital, workers, products, capacity)
    values (_un_org(), me.id, me.full_name, me.national_id, me.phone, trim(p->>'factory_name'), v_cat, coalesce(nullif(p->>'legal_form', ''), 'individual'), p->>'governorate',
      nullif(trim(coalesce(p->>'city', '')), ''), trim(p->>'address'), p->'site_geo', trim(p->>'trade_name_no'), nullif(trim(coalesce(p->>'dev_license_no', '')), ''),
      nullif(p->>'dev_license_kind', ''), nullif(regexp_replace(coalesce(p->>'capital', ''), '[^0-9]', '', 'g'), '')::bigint,
      nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int, trim(p->>'products'), nullif(trim(coalesce(p->>'capacity', '')), ''))
    returning * into m;
  end if;
  v_fee := coalesce(_setting('union_member_fee'), 50000)::bigint + coalesce(_setting('union_insp_min'), 50000)::bigint;
  f := _un_new_file('membership', m.id, null, 'new', null, v_fee, 'طلب انتماء من بوابة المقترض', null, null);
  update union_files set fee_paid_at = now(), fee_ref = 'UPAY-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6)) || ' · ' || (p->>'method') where id = f.id returning * into f;
  perform _un_log(f.id, m.id, null, 'دفع البدل وأجور الكشف إلكترونياً', to_char(v_fee, 'FM999,999,999') || ' د.ع · ' || f.fee_ref);
  return jsonb_build_object('file', f.code, 'id', f.id, 'fee', v_fee, 'ref', f.fee_ref);
end $f$;

-- مستندات المعاملة: الصناعي (قبل الكشف أو عند الإعادة) أو موظف الاتحاد (صور الكشف)
create or replace function public.union_doc_add(p_file uuid, p_kind text, p_data text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; f union_files; m union_members; mime text; sz int := length(coalesce(p_data, '')); did uuid; v_label text;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file;
  select * into m from union_members where id = f.member_id;
  if f.id is null then raise exception 'المعاملة غير موجودة'; end if;
  if me.portal = 'union' then
    if p_kind <> 'visit_photo' then raise exception 'يرفع موظف الاتحاد صور الكشف فقط'; end if;
    if f.status <> 'inspection' then raise exception 'صور الكشف أثناء الكشف الموقعي فقط'; end if;
    v_label := 'صورة الكشف الموقعي';
  else
    if m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
    if f.status not in ('new', 'returned') then raise exception 'المعاملة لدى الاتحاد الآن — لا يمكن تغيير مستنداتها'; end if;
    v_label := coalesce(_bp_doc_label(p_kind), case p_kind when 'id_card' then 'البطاقة الوطنية لصاحب المعمل' end);
    if v_label is null then raise exception 'نوع مستند غير معروف'; end if;
    delete from union_docs where file_id = f.id and kind = p_kind;
  end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg', 'image/png', 'application/pdf') then raise exception 'صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  insert into union_docs(file_id, member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name)
  values (f.id, f.member_id, p_kind, v_label, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'), coalesce(p_meta, '{}') || jsonb_build_object('server_at', now()), me.id, me.full_name)
  returning id into did;
  return did;
end $f$;

-- الصناعي يعيد معاملة الانتماء بعد الاستكمال
create or replace function public.union_resubmit(p_file uuid, p_note text) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f union_files; m union_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file for update;
  select * into m from union_members where id = f.member_id;
  if m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
  if f.status <> 'returned' then raise exception 'المعاملة ليست مُعادة للاستكمال'; end if;
  if f.kind = 'endorse' then raise exception 'معاملة التأييد تعود آلياً حين تحفظ خطوة «التمويل والمستندات» في طلب القرض'; end if;
  update union_files set status = 'new', return_note = null, updated_at = now(), due_at = now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int) where id = f.id;
  perform _un_log(f.id, f.member_id, null, 'أعاد الصناعي المعاملة بعد الاستكمال', p_note);
  perform _un_notify(array['union_reg', 'union_sg'], 'عادت المعاملة ' || f.code || ' بعد الاستكمال', m.factory_name, f.id);
  return jsonb_build_object('ok', true);
end $f$;

-- الاعتراض على الرفض خلال المهلة: يعود القرار للأمين العام
create or replace function public.union_appeal(p_file uuid, p_note text) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f union_files; m union_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from union_files where id = p_file for update;
  select * into m from union_members where id = f.member_id;
  if m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
  if f.status <> 'rejected' then raise exception 'لا يُعترض إلا على معاملة مرفوضة'; end if;
  if f.appeal is not null then raise exception 'قُدّم اعتراض على هذه المعاملة سابقاً — القرار بعده نهائي داخل الاتحاد'; end if;
  if f.updated_at < now() - make_interval(days => coalesce(_setting('union_appeal_days'), 30)::int) then raise exception 'انتهت مهلة الاعتراض'; end if;
  if length(trim(coalesce(p_note, ''))) < 10 then raise exception 'اكتب أسباب اعتراضك (10 أحرف على الأقل)'; end if;
  update union_files set status = 'signing', appeal = jsonb_build_object('note', trim(p_note), 'at', now(), 'prev', f.decision), updated_at = now(),
    due_at = now() + make_interval(days => coalesce(_setting('union_sla_days'), 7)::int) where id = f.id;
  if f.kind = 'membership' or (f.kind = 'endorse' and m.status = 'rejected') then update union_members set status = 'pending', updated_at = now() where id = m.id and status = 'rejected'; end if;
  perform _un_log(f.id, m.id, null, 'اعتراض الصناعي على الرفض', p_note);
  perform _un_notify(array['union_sg'], 'اعتراض على رفض المعاملة ' || f.code, m.factory_name, f.id);
  return jsonb_build_object('ok', true);
end $f$;

-- تجديد الهوية الصناعية سنة بالدفع الإلكتروني
create or replace function public.union_renew(p_member uuid, p_method text, p_otp text) returns union_members language plpgsql security definer set search_path = public as $f$
declare me profiles; m union_members; v_ref text;
begin
  select * into me from profiles where id = auth.uid();
  select * into m from union_members where id = p_member for update;
  if m.citizen_id is distinct from me.id then raise exception 'الهوية لا تخصك'; end if;
  if m.status not in ('approved', 'expired') or m.code is null then raise exception 'التجديد للهويات الصادرة فقط'; end if;
  if p_method not in ('zaincash','qicard','asiapay','fastpay','fib','visa','mastercard','other') then raise exception 'اختر طريقة الدفع'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز تأكيد الدفع غير صحيح'; end if;
  v_ref := 'UREN-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text), 1, 6));
  update union_members set status = 'approved', valid_until = greatest(coalesce(valid_until, current_date), current_date) + interval '1 year', updated_at = now()
  where id = m.id returning * into m;
  perform _un_log(null, m.id, null, 'تجديد الهوية الصناعية سنة', to_char(coalesce(_setting('union_member_fee'), 50000), 'FM999,999') || ' د.ع · ' || p_method || ' · ' || v_ref || ' · حتى ' || m.valid_until);
  return m;
end $f$;

-- ───────── 10) بوابة الاتحاد ─────────
create or replace function public._un_file_row(f union_files) returns jsonb language sql stable security definer set search_path = public as $f$
  select jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _un_kind_label(f.kind), 'status', f.status, 'status_label', _un_status_label(f.status),
    'engineer_id', f.engineer_id, 'engineer', f.engineer_name, 'amount', f.amount, 'fee', f.fee, 'fee_paid_at', f.fee_paid_at, 'due_at', f.due_at,
    'late', f.status in ('new', 'inspection', 'committee', 'signing') and f.due_at < now(), 'appeal', f.appeal is not null, 'new_member', f.note = 'new_member',
    'created_at', f.created_at, 'updated_at', f.updated_at, 'result', f.decision->>'result',
    'member', jsonb_build_object('id', m.id, 'code', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', m.category, 'category_label', _un_cat_label(m.category),
      'governorate', m.governorate, 'status', m.status),
    'app', case when a.id is not null then jsonb_build_object('id', a.id, 'code', a.code, 'stage', a.stage, 'status', a.status,
      'bank', (select name from orgs where id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid))) end)
  from union_members m left join applications a on a.id = f.application_id where m.id = f.member_id $f$;

create or replace function public.union_inbox() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me();
begin
  perform set_config('alwah.face_skip', '1', true); perform _un_scan(); perform set_config('alwah.face_skip', '', true);
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'name', me.full_name, 'role', me.role, 'role_title', _role_title(me.role), 'code', me.staff_code, 'governorate', me.governorate),
    'org', (select jsonb_build_object('id', id, 'name', name, 'code', code) from orgs where id = me.org_id),
    'files', coalesce((select jsonb_agg(_un_file_row(f) order by f.updated_at desc) from union_files f where f.org_id = me.org_id), '[]'),
    'members', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'code', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', m.category,
        'category_label', _un_cat_label(m.category), 'governorate', m.governorate, 'status', m.status, 'valid_until', m.valid_until, 'joined_at', m.joined_at,
        'workers', m.workers, 'dev_license_kind', m.dev_license_kind) order by m.code nulls last, m.created_at desc) from union_members m where m.org_id = me.org_id), '[]'),
    'engineers', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'governorate', p.governorate,
        'open', (select count(*) from union_files f where f.engineer_id = p.id and f.status = 'inspection')) order by p.full_name)
        from profiles p where p.org_id = me.org_id and p.role = 'union_eng' and not coalesce(p.disabled, false)), '[]'),
    'fees', jsonb_build_object(
      'paid', (select coalesce(sum(fee), 0) from union_files where org_id = me.org_id and fee_paid_at is not null),
      'due', (select coalesce(sum(fee), 0) from union_files where org_id = me.org_id and fee_paid_at is null and fee > 0 and status not in ('cancelled', 'rejected')),
      'rows', coalesce((select jsonb_agg(jsonb_build_object('code', f.code, 'kind', _un_kind_label(f.kind), 'factory', m.factory_name, 'fee', f.fee, 'paid_at', f.fee_paid_at, 'ref', f.fee_ref)
        order by f.created_at desc) from union_files f join union_members m on m.id = f.member_id where f.org_id = me.org_id and f.fee > 0), '[]')),
    'settings', jsonb_build_object('member_fee', _setting('union_member_fee'), 'insp_pct', _setting('union_insp_pct'), 'insp_min', _setting('union_insp_min'),
      'insp_max', _setting('union_insp_max'), 'sla', _setting('union_sla_days'), 'letter_days', _setting('union_letter_days'), 'prod_days', _setting('union_prod_days')));
end $f$;

create or replace function public.union_file(p_id uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); f union_files; m union_members; a applications; bp bank_programs; r text;
begin
  select * into f from union_files where id = p_id;
  if f.id is null or f.org_id <> me.org_id then raise exception 'المعاملة غير موجودة'; end if;
  select * into m from union_members where id = f.member_id;
  select * into a from applications where id = f.application_id;
  select * into bp from bank_programs where id = a.program_id;
  r := me.role;
  return _un_file_row(f) || jsonb_build_object(
    'inspection', f.inspection, 'committee', f.committee, 'decision', f.decision, 'appeal_data', f.appeal, 'return_note', f.return_note, 'origin', f.origin,
    'member_full', to_jsonb(m) - 'seal' || jsonb_build_object('category_label', _un_cat_label(m.category), 'valid', _un_member_ok(m),
      'phone', m.phone, 'past', (select count(*) from union_files x where x.member_id = m.id and x.id <> f.id)),
    'loan', case when a.id is not null then jsonb_build_object('code', a.code, 'amount', a.amount, 'term', a.term_months, 'grace', a.grace_months, 'rate', a.margin,
      'installment', a.monthly_installment, 'purpose', a.biz->>'purpose', 'guarantee', a.guarantee_type, 'stage', a.stage,
      'stage_name', (select name from stages where n = a.stage), 'program', bp.name, 'program_code', bp.code, 'disburse', bp.params->>'disburse',
      'bank', (select name from orgs where id = coalesce(a.bank_id, bp.bank_id)), 'biz', a.biz) end,
    'app_docs', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', coalesce(_bp_doc_label(d.kind), d.kind), 'at', d.created_at) order by d.created_at)
      from app_documents d where d.application_id = f.application_id and d.kind like any (array['ind\_%', 'biz\_%'])), '[]'),
    'docs', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label, 'by', d.uploaded_by_name, 'at', d.created_at) order by d.created_at)
      from union_docs d where d.file_id = f.id or (d.member_id = f.member_id and d.kind <> 'visit_photo' and d.file_id <> f.id)), '[]'),
    'letters', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'no', l.no, 'kind', l.kind, 'title', l.title, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
      'verify_code', l.verify_code, 'sha256', l.sha256, 'body', l.body, 'revoked_at', l.revoked_at, 'revoke_reason', l.revoke_reason, 'ack_at', l.ack_at, 'ack_by', l.ack_by_name,
      'ack_no', l.ack_no) order by l.issued_at desc) from union_letters l where l.file_id = f.id), '[]'),
    'log', coalesce((select jsonb_agg(jsonb_build_object('action', g.action, 'note', g.note, 'by', g.actor_name, 'title', g.actor_title, 'at', g.created_at) order by g.id)
      from union_log g where g.file_id = f.id), '[]'),
    'can', jsonb_build_object(
      'triage', f.status = 'new' and r in ('union_reg', 'union_sg'),
      'visit', f.status = 'inspection' and (f.engineer_id = me.id or r = 'union_sg'),
      'reassign', f.status = 'inspection' and r in ('union_reg', 'union_sg'),
      'recommend', f.status = 'committee' and r in ('union_committee', 'union_sg'),
      'sign', f.status = 'signing' and r = 'union_sg',
      'revoke', f.status in ('issued', 'delivered') and r = 'union_sg'));
end $f$;

-- عرض مستند: موظف الاتحاد، أو صاحب المعاملة، أو المصرف صاحب الطلب
create or replace function public.union_doc(p_id uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; d union_docs; m union_members; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into d from union_docs where id = p_id;
  if d.id is null then raise exception 'المستند غير موجود'; end if;
  select * into m from union_members where id = d.member_id;
  select a2.* into a from union_files f join applications a2 on a2.id = f.application_id where f.id = d.file_id;
  if not (me.portal = 'union' or m.citizen_id = me.id or (me.portal = 'bank' and me.org_id = a.bank_id) or me.portal in ('cbi', 'integrity', 'audit', 'admin')) then
    raise exception 'لا صلاحية لعرض المستند'; end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label, 'mime', d.mime, 'data', d.data, 'sha256', d.sha256, 'meta', d.meta, 'by', d.uploaded_by_name, 'at', d.created_at);
end $f$;

-- مستندات طلب القرض لموظف الاتحاد (عروض الأسعار والإجازة …) — للمعاملة المحالة إليه فقط
create or replace function public.union_app_doc(p_file uuid, p_doc uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles := _un_me(); f union_files; d app_documents;
begin
  select * into f from union_files where id = p_file and org_id = me.org_id;
  select * into d from app_documents where id = p_doc and application_id = f.application_id;
  if f.id is null or d.id is null then raise exception 'المستند غير متاح'; end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'label', coalesce(_bp_doc_label(d.kind), d.kind), 'mime', d.mime, 'data', d.data, 'sha256', d.sha256);
end $f$;

-- دورة المعاملة داخل الاتحاد
create or replace function public.union_act(p_id uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); f union_files; m union_members; a applications; l union_letters; e profiles;
  v_act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_gps jsonb; v_ins jsonb; v_body jsonb; v_res text; v_to text; v_valid date; v_bank uuid;
begin
  select * into f from union_files where id = p_id for update;
  if f.id is null or f.org_id <> me.org_id then raise exception 'المعاملة غير موجودة'; end if;
  select * into m from union_members where id = f.member_id;
  select * into a from applications where id = f.application_id;

  -- ١) قسم العضوية والتسجيل: الإحالة للكشف، أو الإعادة للصناعي، أو الرفض الشكلي
  if v_act in ('accept', 'return', 'reject_form') then
    if f.status <> 'new' then raise exception 'المعاملة ليست في الوارد'; end if;
    if me.role not in ('union_reg', 'union_sg') then raise exception 'التدقيق والإحالة لقسم العضوية والتسجيل'; end if;
    if v_act = 'accept' then
      if f.kind = 'membership' and f.fee > 0 and f.fee_paid_at is null then raise exception 'لم يُدفع البدل وأجور الكشف بعد'; end if;
      e := _un_pick_eng(m.governorate, nullif(p->>'engineer', '')::uuid);
      if e.id is null then raise exception 'لا يوجد مهندس كشف في الاتحاد — أضفه من «فريقي»'; end if;
      update union_files set status = 'inspection', engineer_id = e.id, engineer_name = e.full_name, updated_at = now(),
        due_at = greatest(due_at, now() + interval '3 days') where id = f.id;
      perform _un_log(f.id, m.id, null, 'تدقيق المستندات وإحالة للكشف الموقعي — ' || e.full_name, v_note);
      insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
      values (f.org_id, e.id, 'union', 'union', 'كشف موقعي مسند إليك: ' || f.code, _un_kind_label(f.kind) || ' — ' || m.factory_name || ' · ' || m.governorate, f.id);
      perform _un_tell_citizen(m.id, 'اتحاد الصناعات: معاملتك ' || f.code || ' قيد الكشف الموقعي', 'سيزور مهندس الاتحاد معملك — ' || e.full_name, f.id);
      return jsonb_build_object('ok', true, 'engineer', e.full_name);
    end if;
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب النقص أو السبب بوضوح'; end if;
    if v_act = 'return' then
      update union_files set status = 'returned', return_note = v_note, returned_by = me.full_name, updated_at = now() where id = f.id;
      perform _un_log(f.id, m.id, null, 'إعادة للصناعي لاستكمال النواقص', v_note);
      perform _un_tell_citizen(m.id, 'اتحاد الصناعات أعاد معاملتك ' || f.code || ' للاستكمال', v_note, f.id);
      if a.id is not null then perform _ev(a.id, a.stage, 'اتحاد الصناعات: إعادة طلب التأييد للاستكمال', v_note); end if;
      return jsonb_build_object('ok', true);
    end if;
    v_act := 'reject'; v_res := 'reject_form';
  end if;

  -- ٢) المهندس: الكشف الموقعي
  if v_act = 'visit' then
    if f.status <> 'inspection' then raise exception 'المعاملة ليست في الكشف الموقعي'; end if;
    if f.engineer_id is distinct from me.id and me.role <> 'union_sg' then raise exception 'الكشف للمهندس المسند إليه'; end if;
    v_gps := p->'gps';
    if v_gps is null or (v_gps->>'lat') is null or coalesce((v_gps->>'acc')::numeric, 9999) > 150 then raise exception 'ثبّت موقعك في المعمل بدقة ±150 م أو أفضل'; end if;
    if jsonb_array_length(coalesce(p->'photos', '[]')) < 1 then raise exception 'التقط صورة واحدة للمعمل أو المكائن على الأقل'; end if;
    if exists (select 1 from jsonb_array_elements_text(p->'photos') x where not exists (select 1 from union_docs d where d.id = x::uuid and d.file_id = f.id)) then raise exception 'صورة غير معروفة'; end if;
    if coalesce(p->>'site_state', '') not in ('operating', 'under_construction', 'stopped', 'not_found') then raise exception 'حدّد حالة المعمل'; end if;
    if coalesce(p->>'result', '') not in ('ok', 'issues') then raise exception 'حدّد نتيجة الكشف: مطابق أم عليه ملاحظات'; end if;
    if p->>'result' = 'issues' and v_note is null then raise exception 'اكتب الملاحظات'; end if;
    v_ins := jsonb_build_object('gps', jsonb_build_object('lat', (v_gps->>'lat')::numeric, 'lng', (v_gps->>'lng')::numeric, 'acc', round((v_gps->>'acc')::numeric)),
      'photos', p->'photos', 'site_state', p->>'site_state', 'result', p->>'result', 'note', v_note,
      'machines_match', case when p ? 'machines_match' then (p->>'machines_match')::boolean end,
      'assessed_value', nullif(regexp_replace(coalesce(p->>'assessed_value', ''), '[^0-9]', '', 'g'), '')::bigint,
      'quotes_total', nullif(regexp_replace(coalesce(p->>'quotes_total', ''), '[^0-9]', '', 'g'), '')::bigint,
      'fair_value', nullif(regexp_replace(coalesce(p->>'fair_value', ''), '[^0-9]', '', 'g'), '')::bigint,
      'price_ok', case when p ? 'price_ok' then (p->>'price_ok')::boolean end,
      'capacity', nullif(trim(coalesce(p->>'capacity', '')), ''), 'workers', nullif(regexp_replace(coalesce(p->>'workers', ''), '[^0-9]', '', 'g'), '')::int,
      'checks', coalesce(p->'checks', '[]'), 'by', me.full_name, 'code', me.staff_code, 'at', now());
    if f.kind = 'endorse' and (v_ins->>'quotes_total') is null then raise exception 'اكتب مجموع عروض أسعار المكائن كما اطّلعت عليها'; end if;
    if f.kind = 'endorse' and (v_ins->>'price_ok') is null then raise exception 'حدّد: هل أسعار المكائن معقولة قياساً بالسوق؟'; end if;
    if f.kind = 'install' and (v_ins->>'machines_match') is null then raise exception 'حدّد: هل المكائن المنصوبة مطابقة لما مُوّل؟'; end if;
    update union_files set inspection = v_ins, updated_at = now(),
      status = case when f.kind in ('membership', 'endorse') then 'committee' else 'signing' end where id = f.id returning * into f;
    if m.site_geo is null then update union_members set site_geo = v_ins->'gps', updated_at = now() where id = m.id; end if;
    perform _un_log(f.id, m.id, null, 'الكشف الموقعي بالـGPS — ' || case p->>'result' when 'ok' then 'مطابق' else 'عليه ملاحظات' end,
      coalesce(v_note, '') || coalesce(' · القيمة المقدّرة ' || to_char((v_ins->>'assessed_value')::bigint, 'FM999,999,999,999') || ' د.ع', ''));
    perform _un_notify(case when f.status = 'committee' then array['union_committee'] else array['union_sg'] end,
      'اكتمل الكشف على ' || f.code, m.factory_name || ' — ' || case when f.status = 'committee' then 'لتوصية لجنة الصنف' else 'لقرار الأمين العام' end, f.id);
    if a.id is not null then perform _ev(a.id, a.stage, 'اتحاد الصناعات: أُنجز الكشف الموقعي (' || _un_kind_label(f.kind) || ')', case p->>'result' when 'ok' then 'مطابق' else 'عليه ملاحظات' end); end if;
    return jsonb_build_object('ok', true, 'next', f.status);
  end if;

  if v_act = 'reassign' then
    if f.status <> 'inspection' or me.role not in ('union_reg', 'union_sg') then raise exception 'إعادة الإسناد لقسم التسجيل أو الأمين العام أثناء الكشف'; end if;
    e := _un_pick_eng(m.governorate, nullif(p->>'engineer', '')::uuid);
    update union_files set engineer_id = e.id, engineer_name = e.full_name, updated_at = now() where id = f.id;
    perform _un_log(f.id, m.id, null, 'إعادة إسناد الكشف — ' || e.full_name, v_note);
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id) values (f.org_id, e.id, 'union', 'union', 'كشف موقعي مسند إليك: ' || f.code, m.factory_name, f.id);
    return jsonb_build_object('ok', true);
  end if;

  -- ٣) لجنة الصنف: التوصية
  if v_act = 'recommend' then
    if f.status <> 'committee' then raise exception 'المعاملة ليست لدى لجنة الصنف'; end if;
    if me.role not in ('union_committee', 'union_sg') then raise exception 'التوصية للجنة الصنف'; end if;
    if coalesce(p->>'rec', '') not in ('approve', 'conditional', 'reject') then raise exception 'اختر التوصية'; end if;
    if p->>'rec' <> 'approve' and v_note is null then raise exception 'اكتب الشروط أو أسباب التوصية بالرفض'; end if;
    update union_files set status = 'signing', committee = jsonb_build_object('rec', p->>'rec', 'note', v_note, 'by', me.full_name, 'code', me.staff_code, 'at', now(),
      'recommended_amount', nullif(regexp_replace(coalesce(p->>'recommended_amount', ''), '[^0-9]', '', 'g'), '')::bigint), updated_at = now() where id = f.id;
    perform _un_log(f.id, m.id, null, 'توصية لجنة الصنف: ' || case p->>'rec' when 'approve' then 'التأييد' when 'conditional' then 'التأييد بشروط' else 'عدم التأييد' end, v_note);
    perform _un_notify(array['union_sg'], 'بانتظار قرارك: ' || f.code, m.factory_name || ' — ' || _un_kind_label(f.kind), f.id);
    return jsonb_build_object('ok', true);
  end if;

  -- ٤) الأمين العام: الإعادة لقسم داخلي
  if v_act = 'return_to' then
    if f.status <> 'signing' or me.role <> 'union_sg' then raise exception 'الإعادة الداخلية للأمين العام عند القرار'; end if;
    v_to := p->>'to';
    if v_to not in ('new', 'inspection', 'committee') then raise exception 'اختر القسم'; end if;
    if v_note is null then raise exception 'اكتب سبب الإعادة'; end if;
    if v_to = 'committee' and f.kind not in ('membership', 'endorse') then raise exception 'لا لجنة صنف في هذه المعاملة'; end if;
    update union_files set status = v_to, updated_at = now(), due_at = greatest(due_at, now() + interval '2 days') where id = f.id;
    perform _un_log(f.id, m.id, null, 'إعادة من الأمين العام إلى: ' || _un_status_label(v_to), v_note);
    perform _un_notify(case v_to when 'new' then array['union_reg'] when 'committee' then array['union_committee'] else array['union_eng'] end, 'أعاد الأمين العام المعاملة ' || f.code, v_note, f.id);
    return jsonb_build_object('ok', true);
  end if;

  -- ٤) الأمين العام: القرار وإصدار الكتاب
  if v_act = 'issue' then
    if f.status <> 'signing' or me.role <> 'union_sg' then raise exception 'القرار للأمين العام'; end if;
    if coalesce(p->>'confirm', '') <> 'أوافق' then raise exception 'اكتب «أوافق» لتأكيد القرار'; end if;
    v_valid := current_date + coalesce(_setting('union_letter_days'), 90)::int;
    -- منح العضوية أو تثبيتها
    if f.kind in ('membership', 'endorse') and m.status <> 'approved' then
      update union_members set status = 'approved', code = coalesce(code, _vet_seq('IFI', 'union_members', 'code')), joined_at = coalesce(joined_at, current_date),
        valid_until = current_date + interval '1 year', verify_code = coalesce(verify_code, _un_vcode()), decided_by_name = me.full_name, decided_at = now(), reason = null,
        site_geo = coalesce(site_geo, f.inspection->'gps'), updated_at = now() where id = m.id returning * into m;
      update union_members set seal = encode(extensions.digest(convert_to(jsonb_build_object('code', m.code, 'owner', m.owner_name, 'nid', m.national_id, 'factory', m.factory_name,
        'category', m.category, 'joined', m.joined_at, 'valid', m.valid_until)::text, 'UTF8'), 'sha256'), 'hex') where id = m.id returning * into m;
      perform _un_log(f.id, m.id, null, 'قبول الانتماء ومنح الهوية الصناعية ' || m.code, 'نافذة حتى ' || m.valid_until);
      if a.id is not null then update applications set biz = biz || jsonb_build_object('union_no', m.code, 'new_member', false) where id = a.id; end if;
    end if;
    if f.kind = 'membership' then
      l := _un_issue_letter(f, 'قرار انتماء ومنح الهوية الصناعية ' || m.code, jsonb_build_object('kind', 'membership', 'member', m.code, 'owner', m.owner_name,
        'factory', m.factory_name, 'category', _un_cat_label(m.category), 'governorate', m.governorate, 'joined', m.joined_at, 'member_valid', m.valid_until), m.valid_until);
      update union_files set status = 'done', decision = jsonb_build_object('result', 'ok', 'note', v_note, 'by', me.full_name, 'at', now(), 'letter', l.no), closed_at = now(), updated_at = now() where id = f.id;
      perform _un_tell_citizen(m.id, 'مبروك — قُبل انتماؤك لاتحاد الصناعات', 'هويتك الصناعية ' || m.code || ' نافذة حتى ' || m.valid_until, f.id);
      return jsonb_build_object('ok', true, 'letter', l.no, 'member', m.code);
    end if;
    if f.kind = 'endorse' then
      if f.inspection is null or f.committee is null then raise exception 'المعاملة بلا كشف أو توصية'; end if;
      v_bank := coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid);
      v_body := jsonb_build_object('kind', 'endorse', 'member', m.code, 'member_valid', m.valid_until, 'owner', m.owner_name, 'factory', m.factory_name,
        'category', _un_cat_label(m.category), 'governorate', m.governorate, 'address', m.address, 'dev_license', m.dev_license_no,
        'dev_license_kind', case m.dev_license_kind when 'complete' then 'كاملة التأسيس' when 'under' then 'تحت التأسيس' end,
        'app', a.code, 'bank', (select name from orgs where id = v_bank), 'program', (select name from bank_programs where id = a.program_id),
        'amount', a.amount, 'purpose', a.biz->>'purpose', 'term', a.term_months,
        'site_state', f.inspection->>'site_state', 'assessed_value', f.inspection->'assessed_value', 'quotes_total', f.inspection->'quotes_total',
        'fair_value', f.inspection->'fair_value', 'price_ok', f.inspection->'price_ok', 'capacity', f.inspection->>'capacity', 'workers', f.inspection->'workers',
        'gps', f.inspection->'gps', 'engineer', f.inspection->>'by', 'visit_at', f.inspection->>'at',
        'committee', f.committee->>'rec', 'conditions', coalesce(v_note, f.committee->>'note'),
        'statement', 'يؤيد اتحاد الصناعات العراقي أن المذكور صناعي منتمٍ إلى الاتحاد بهويته النافذة، وأن مشروعه قائم في الموقع المؤشَّر بعد الكشف عليه، '
          || 'وأن المكائن والمعدات المطلوب تمويلها لازمة لنشاطه' || case when (f.inspection->>'price_ok')::boolean then ' وأسعارها معقولة قياساً بالسوق' else ' مع ملاحظة على أسعارها مذكورة أدناه' end
          || '. صدر هذا التأييد بناءً على طلبه لتقديمه إلى المصرف المذكور حصراً، ولا يُعد ضماناً للقرض.');
      l := _un_issue_letter(f, 'كتاب تأييد صناعي — ' || m.factory_name, v_body, v_valid);
      update union_files set status = 'issued', decision = jsonb_build_object('result', 'ok', 'note', v_note, 'by', me.full_name, 'at', now(), 'letter', l.no), updated_at = now() where id = f.id;
      if a.id is not null then
        update applications set biz = biz || jsonb_build_object('union_letter', l.no, 'union_verify', l.verify_code) where id = a.id;
        perform _ev(a.id, a.stage, 'اتحاد الصناعات العراقي: صدر كتاب التأييد الصناعي ' || l.no, 'نافذ حتى ' || v_valid || ' · رمز التحقق ' || l.verify_code);
      end if;
      perform _un_tell_citizen(m.id, 'صدر كتاب تأييد اتحاد الصناعات لقرضك', 'الكتاب ' || l.no || ' — أكمل الدفع والتوقيع لإرسال طلبك للمصرف', f.id);
      return jsonb_build_object('ok', true, 'letter', l.no);
    end if;
    -- نصب المكائن، بدء الإنتاج، المتابعة
    if f.inspection is null then raise exception 'المعاملة بلا كشف'; end if;
    v_res := case when f.kind = 'install' then case when coalesce((f.inspection->>'machines_match')::boolean, false) and f.inspection->>'result' = 'ok' then 'ok' else 'not_ok' end
      when f.kind = 'production' then case when f.inspection->>'site_state' = 'operating' and f.inspection->>'result' = 'ok' then 'ok' else 'not_ok' end
      else case when f.inspection->>'site_state' = 'operating' and f.inspection->>'result' = 'ok' then 'ok' else 'not_ok' end end;
    if coalesce(p->>'result', v_res) <> v_res and p->>'result' in ('ok', 'not_ok') then v_res := p->>'result'; end if;
    l := _un_issue_letter(f, case f.kind when 'install' then 'تأييد نصب المكائن ومطابقتها' when 'production' then 'تأييد بدء الإنتاج' else 'تقرير كشف متابعة' end
        || case when v_res = 'ok' then '' else ' — غير مطابق' end || ' — ' || m.factory_name,
      jsonb_build_object('kind', f.kind, 'result', v_res, 'member', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'app', a.code,
        'bank', (select name from orgs where id = a.bank_id), 'amount', a.amount, 'site_state', f.inspection->>'site_state', 'machines_match', f.inspection->'machines_match',
        'capacity', f.inspection->>'capacity', 'workers', f.inspection->'workers', 'gps', f.inspection->'gps', 'engineer', f.inspection->>'by', 'visit_at', f.inspection->>'at',
        'note', coalesce(v_note, f.inspection->>'note')), null);
    update union_files set status = 'done', decision = jsonb_build_object('result', v_res, 'note', v_note, 'by', me.full_name, 'at', now(), 'letter', l.no), closed_at = now(), updated_at = now() where id = f.id;
    if a.id is not null then
      perform _ev(a.id, a.stage, 'اتحاد الصناعات: ' || l.title, coalesce(v_note, f.inspection->>'note'));
      if a.bank_id is not null then
        perform _notify(a.bank_id, 'bank', 'union_' || f.kind, l.title, a.code || ' — الكتاب ' || l.no, a.id);
      end if;
      if v_res <> 'ok' then
        insert into integrity_alerts(type, severity, title, details, application_id, entity)
        values ('union_' || f.kind, 'high', 'اتحاد الصناعات: ' || _un_kind_label(f.kind) || ' — غير مطابق', a.code || ' · ' || m.factory_name || ' · ' || coalesce(v_note, f.inspection->>'note', ''), a.id, m.factory_name);
      end if;
    end if;
    return jsonb_build_object('ok', true, 'letter', l.no, 'result', v_res);
  end if;

  -- ٤) الأمين العام: الرفض المسبَّب (أو الرفض الشكلي من قسم التسجيل)
  if v_act = 'reject' then
    if v_res is null and (f.status <> 'signing' or me.role <> 'union_sg') then raise exception 'الرفض قرار الأمين العام'; end if;
    if v_note is null or length(v_note) < 10 then raise exception 'اكتب أسباب الرفض بوضوح (10 أحرف على الأقل)'; end if;
    update union_files set status = 'rejected', decision = jsonb_build_object('result', 'rejected', 'reason', v_note, 'by', me.full_name, 'at', now(), 'final', f.appeal is not null),
      closed_at = now(), updated_at = now() where id = f.id;
    if f.kind = 'membership' or (f.kind = 'endorse' and m.status = 'pending') then
      update union_members set status = 'rejected', reason = v_note, decided_by_name = me.full_name, decided_at = now(), updated_at = now() where id = m.id;
    end if;
    perform _un_log(f.id, m.id, null, case when f.appeal is not null then 'رفض نهائي بعد الاعتراض' else 'رفض مسبَّب' end, v_note);
    perform _un_tell_citizen(m.id, 'اتحاد الصناعات لم يؤيد معاملتك ' || f.code, v_note || case when f.appeal is null then ' — يمكنك الاعتراض خلال ' || coalesce(_setting('union_appeal_days'), 30) || ' يوماً' else '' end, f.id);
    if a.id is not null then perform _ev(a.id, a.stage, 'اتحاد الصناعات: عدم تأييد', v_note); end if;
    return jsonb_build_object('ok', true);
  end if;

  -- سحب كتاب صادر بسبب (يصل المصرف والنزاهة)
  if v_act = 'revoke' then
    if me.role <> 'union_sg' then raise exception 'سحب الكتاب للأمين العام'; end if;
    if v_note is null or length(v_note) < 10 then raise exception 'اكتب سبب السحب'; end if;
    select * into l from union_letters where file_id = f.id and revoked_at is null order by issued_at desc limit 1;
    if l.id is null then raise exception 'لا كتاب نافذ في المعاملة'; end if;
    update union_letters set revoked_at = now(), revoke_reason = v_note, revoked_by_name = me.full_name where id = l.id;
    update union_files set status = 'cancelled', decision = coalesce(decision, '{}') || jsonb_build_object('revoked', true, 'revoke_reason', v_note), updated_at = now() where id = f.id;
    perform _un_log(f.id, m.id, l.id, 'سحب الكتاب ' || l.no, v_note);
    if a.id is not null then
      perform _ev(a.id, a.stage, 'اتحاد الصناعات: سحب الكتاب ' || l.no, v_note);
      if a.bank_id is not null then perform _notify(a.bank_id, 'bank', 'union_revoke', 'سحب اتحاد الصناعات كتابه ' || l.no, a.code || ' — ' || v_note, a.id); end if;
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('union_revoke', 'medium', 'سحب كتاب تأييد صناعي', a.code || ' · ' || l.no || ' · ' || v_note, a.id, m.factory_name);
    end if;
    perform _un_tell_citizen(m.id, 'سحب اتحاد الصناعات كتابه ' || l.no, v_note, f.id);
    return jsonb_build_object('ok', true);
  end if;

  raise exception 'إجراء غير معروف';
end $f$;

-- سجل الأعضاء: التعليق والإعادة والتجديد من الاتحاد
create or replace function public.union_member_act(p_id uuid, p jsonb) returns union_members language plpgsql security definer set search_path = public as $f$
declare me profiles := _un_me(); m union_members; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  select * into m from union_members where id = p_id and org_id = me.org_id for update;
  if m.id is null then raise exception 'العضو غير موجود'; end if;
  if me.role not in ('union_sg', 'union_reg') then raise exception 'إدارة السجل لقسم العضوية والأمين العام'; end if;
  if p->>'action' = 'suspend' then
    if me.role <> 'union_sg' then raise exception 'التعليق للأمين العام'; end if;
    if v_note is null then raise exception 'اكتب سبب التعليق'; end if;
    update union_members set status = 'suspended', reason = v_note, updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'تعليق العضوية ' || m.code, v_note);
  elsif p->>'action' = 'reinstate' then
    if me.role <> 'union_sg' or m.status <> 'suspended' then raise exception 'إعادة العضوية المعلّقة للأمين العام'; end if;
    update union_members set status = case when valid_until >= current_date then 'approved' else 'expired' end, reason = null, updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'إعادة العضوية ' || m.code, v_note);
  elsif p->>'action' = 'renew' then
    if m.status not in ('approved', 'expired') or m.code is null then raise exception 'التجديد للهويات الصادرة'; end if;
    if length(trim(coalesce(p->>'ref', ''))) < 3 then raise exception 'اكتب رقم وصل القبض'; end if;
    update union_members set status = 'approved', valid_until = greatest(coalesce(valid_until, current_date), current_date) + interval '1 year', updated_at = now() where id = m.id returning * into m;
    perform _un_log(null, m.id, null, 'تجديد الهوية في الاتحاد (وصل ' || trim(p->>'ref') || ')', 'حتى ' || m.valid_until);
  else raise exception 'إجراء غير معروف'; end if;
  return m;
end $f$;

create or replace function public.union_member(p_id uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles := _un_me(); m union_members;
begin
  select * into m from union_members where id = p_id and org_id = me.org_id;
  if m.id is null then raise exception 'العضو غير موجود'; end if;
  return to_jsonb(m) || jsonb_build_object('category_label', _un_cat_label(m.category), 'valid', _un_member_ok(m),
    'files', coalesce((select jsonb_agg(_un_file_row(f) order by f.created_at desc) from union_files f where f.member_id = m.id), '[]'),
    'log', coalesce((select jsonb_agg(jsonb_build_object('action', g.action, 'note', g.note, 'by', g.actor_name, 'at', g.created_at) order by g.id desc)
      from union_log g where g.member_id = m.id and g.file_id is null), '[]'));
end $f$;

-- ───────── 11) المصرف والجهات: التأييد في ملف الطلب ─────────
create or replace function public.union_app_report(p_app uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; a applications; m union_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a.id is null then raise exception 'الطلب غير موجود'; end if;
  if not (a.citizen_id = me.id or me.portal in ('cbi', 'integrity', 'audit', 'admin', 'union', 'finance', 'planning')
          or (me.portal = 'bank' and me.org_id in (a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid))) then raise exception 'لا صلاحية'; end if;
  select * into m from union_members where id = nullif(a.biz->>'member_id', '')::uuid;
  return jsonb_build_object(
    'member', case when m.id is not null then jsonb_build_object('code', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', _un_cat_label(m.category),
      'status', m.status, 'valid_until', m.valid_until, 'valid', _un_member_ok(m), 'verify_code', m.verify_code) end,
    'letter_ok', _un_letter_ok(a.id),
    'can_ack', me.portal = 'bank' and me.org_id = a.bank_id,
    'files', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _un_kind_label(f.kind), 'status', f.status,
      'status_label', _un_status_label(f.status), 'engineer', f.engineer_name, 'due_at', f.due_at, 'late', f.status in ('new', 'inspection', 'committee', 'signing') and f.due_at < now(),
      'result', f.decision->>'result', 'reason', f.decision->>'reason', 'site_state', f.inspection->>'site_state', 'visit_at', f.inspection->>'at',
      'assessed_value', f.inspection->'assessed_value', 'price_ok', f.inspection->'price_ok', 'fee', f.fee, 'fee_paid_at', f.fee_paid_at) order by f.created_at)
      from union_files f where f.application_id = a.id), '[]'),
    'letters', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'no', l.no, 'kind', l.kind, 'title', l.title, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
      'verify_code', l.verify_code, 'sha256', l.sha256, 'body', l.body, 'issued_by', l.issued_by_name, 'issued_by_title', l.issued_by_title,
      'revoked_at', l.revoked_at, 'revoke_reason', l.revoke_reason, 'ack_at', l.ack_at, 'ack_by', l.ack_by_name, 'ack_by_title', l.ack_by_title, 'ack_no', l.ack_no) order by l.issued_at)
      from union_letters l where l.application_id = a.id), '[]'));
end $f$;

-- المصرف يؤكد استلام الكتاب برقم وهوية المستلم (مرة واحدة)
create or replace function public.union_letter_ack(p_letter uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; l union_letters; a applications; v_no text;
begin
  select * into me from profiles where id = auth.uid();
  select * into l from union_letters where id = p_letter for update;
  select * into a from applications where id = l.application_id;
  if l.id is null or me.portal <> 'bank' or me.org_id is distinct from a.bank_id then raise exception 'تأكيد الاستلام لموظف المصرف صاحب الطلب'; end if;
  if l.revoked_at is not null then raise exception 'الكتاب مسحوب'; end if;
  if l.ack_at is not null then return jsonb_build_object('ok', true, 'ack_no', l.ack_no, 'again', true); end if;
  v_no := 'ACK-' || upper((select code from orgs where id = me.org_id)) || '-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(l.id::text || now()::text), 1, 5));
  update union_letters set ack_at = now(), ack_by_name = me.full_name, ack_by_title = _role_title(me.role), ack_no = v_no where id = l.id;
  update union_files set status = 'delivered', updated_at = now() where id = l.file_id and status = 'issued';
  perform _un_log(l.file_id, l.member_id, l.id, 'أكد المصرف استلام الكتاب ' || l.no, me.full_name || ' — ' || _role_title(me.role) || ' · ' || v_no);
  perform _ev(a.id, a.stage, 'تأكيد استلام كتاب اتحاد الصناعات ' || l.no, v_no);
  return jsonb_build_object('ok', true, 'ack_no', v_no);
end $f$;

-- المصرف يطلب كشف متابعة على معمل مموَّل (شك بالتوقف أو تعثر)
create or replace function public.union_request(p_app uuid, p_note text) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications; f union_files;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a.program is distinct from 'industrial' then raise exception 'كشف الاتحاد للقروض الصناعية'; end if;
  if me.portal <> 'bank' or me.org_id is distinct from a.bank_id then raise exception 'الطلب لموظف المصرف صاحب القرض'; end if;
  if a.stage < 33 then raise exception 'كشف المتابعة بعد تنفيذ القرض'; end if;
  if length(trim(coalesce(p_note, ''))) < 10 then raise exception 'اكتب سبب طلب الكشف'; end if;
  if exists (select 1 from union_files where application_id = a.id and kind = 'followup' and status in ('new', 'inspection', 'signing')) then raise exception 'يوجد كشف متابعة مفتوح'; end if;
  f := _un_new_file('followup', nullif(a.biz->>'member_id', '')::uuid, a.id, 'inspection', a.amount, 0, 'بطلب ' || me.full_name || ' — ' || (select name from orgs where id = me.org_id), trim(p_note), null);
  perform _ev(a.id, a.stage, 'طلب كشف متابعة من اتحاد الصناعات', trim(p_note));
  return jsonb_build_object('ok', true, 'code', f.code);
end $f$;

-- ───────── 12) التحقق العام (رمز QR) ─────────
create or replace function public.union_verify(p_code text) returns jsonb language plpgsql stable security definer set search_path = public, extensions as $f$
declare l union_letters; m union_members; v text := upper(trim(coalesce(p_code, '')));
begin
  select * into l from union_letters where verify_code = v;
  if l.id is not null then
    select * into m from union_members where id = l.member_id;
    return jsonb_build_object('found', true, 'type', 'letter', 'kind', l.kind, 'title', l.title, 'no', l.no, 'issued_at', l.issued_at, 'valid_until', l.valid_until,
      'issuer', l.issued_by_name, 'issuer_title', l.issued_by_title, 'intact', encode(extensions.digest(convert_to(l.body::text, 'UTF8'), 'sha256'), 'hex') = l.sha256,
      'sha256', l.sha256, 'revoked', l.revoked_at is not null, 'revoke_reason', l.revoke_reason, 'expired', l.valid_until < current_date,
      'factory', m.factory_name, 'member', m.code, 'category', _un_cat_label(m.category), 'bank', l.body->>'bank', 'amount', l.body->'amount', 'result', l.body->>'result',
      'ack', l.ack_at is not null, 'ack_at', l.ack_at);
  end if;
  select * into m from union_members where verify_code = v;
  if m.id is not null then
    return jsonb_build_object('found', true, 'type', 'member', 'member', m.code, 'factory', m.factory_name, 'owner', m.owner_name, 'category', _un_cat_label(m.category),
      'governorate', m.governorate, 'status', m.status, 'valid', _un_member_ok(m), 'joined', m.joined_at, 'valid_until', m.valid_until,
      'intact', m.seal = encode(extensions.digest(convert_to(jsonb_build_object('code', m.code, 'owner', m.owner_name, 'nid', m.national_id, 'factory', m.factory_name,
        'category', m.category, 'joined', m.joined_at, 'valid', m.valid_until)::text, 'UTF8'), 'sha256'), 'hex'));
  end if;
  return jsonb_build_object('found', false);
end $f$;

-- ───────── 13) Face ID: جداول الاتحاد محروسة ─────────
do $d$
declare t text;
begin
  foreach t in array array['union_members', 'union_files', 'union_letters', 'union_docs'] loop
    execute format('drop trigger if exists trg_zz_face_gate on public.%I', t);
    execute format('create trigger trg_zz_face_gate after insert or update or delete on public.%I for each row execute function public._face_gate()', t);
  end loop;
end $d$;

-- ───────── 14) الصلاحيات ─────────
revoke all on function public._un_org(), public._un_me(), public._un_vcode(), public._un_log(uuid, uuid, uuid, text, text), public._un_notify(text[], text, text, uuid),
  public._un_tell_citizen(uuid, text, text, uuid), public._un_insp_fee(bigint), public._un_fee_items(uuid), public._un_pick_eng(text, uuid), public._un_letter_ok(uuid),
  public._un_issue_letter(union_files, text, jsonb, date), public._un_new_file(text, uuid, uuid, text, bigint, bigint, text, text, uuid), public._un_sync(uuid),
  public._ind_step(uuid, integer, jsonb), public._un_scan(), public._un_file_row(union_files) from public, anon, authenticated;
revoke all on function public.union_my(), public.union_member_apply(jsonb), public.union_doc_add(uuid, text, text, jsonb), public.union_resubmit(uuid, text),
  public.union_appeal(uuid, text), public.union_renew(uuid, text, text), public.union_inbox(), public.union_file(uuid), public.union_doc(uuid), public.union_app_doc(uuid, uuid),
  public.union_act(uuid, jsonb), public.union_member_act(uuid, jsonb), public.union_member(uuid), public.union_app_report(uuid), public.union_letter_ack(uuid),
  public.union_request(uuid, text) from public, anon;
grant execute on function public.union_my(), public.union_member_apply(jsonb), public.union_doc_add(uuid, text, text, jsonb), public.union_resubmit(uuid, text),
  public.union_appeal(uuid, text), public.union_renew(uuid, text, text), public.union_inbox(), public.union_file(uuid), public.union_doc(uuid), public.union_app_doc(uuid, uuid),
  public.union_act(uuid, jsonb), public.union_member_act(uuid, jsonb), public.union_member(uuid), public.union_app_report(uuid), public.union_letter_ack(uuid),
  public.union_request(uuid, text), public._un_cat_label(text) to authenticated;
revoke all on function public.union_verify(text) from public;
grant execute on function public.union_verify(text) to anon, authenticated;

-- ───────── 15) بيانات العرض ─────────
insert into public.orgs(code, type, name, meta)
select 'ifi', 'union', 'اتحاد الصناعات العراقي', '{"hq": "بغداد", "founded": 1956, "law": "قانون اتحاد الصناعات العراقي رقم 44 لسنة 1989", "demo": true}'::jsonb
where not exists (select 1 from public.orgs where code = 'ifi');

do $$
declare r text[]; rows text[][] := array[
  -- اسم الدخول، كلمة المرور، الاسم، الدور، المحافظة، نطاق الإدارة
  ['union.sg',   'Ifi@2026sg', 'د. عبد الرزاق حميد الكبيسي', 'union_sg',        'بغداد', 'org'],
  ['union.reg',  'Ifi@2026rg', 'نادية صلاح الخفاجي',          'union_reg',       'بغداد', ''],
  ['union.eng',  'Ifi@2026en', 'م. أحمد فاضل العزاوي',        'union_eng',       'بغداد', ''],
  ['union.eng2', 'Ifi@2026e2', 'م. حسين عبد الكريم المالكي',   'union_eng',       'البصرة', ''],
  ['union.cmt',  'Ifi@2026cm', 'م. سعاد جواد الربيعي',         'union_committee', 'بغداد', ''],
  ['union.fin',  'Ifi@2026fn', 'علي محسن الشمري',              'union_fin',       'بغداد', '']];
  i int; uid uuid; sg uuid;
begin
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'union', 'ifi', null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    select id into sg from public.profiles where username = 'union.sg';
    update public.profiles set governorate = rows[i][5], manage_scope = nullif(rows[i][6], ''), must_change_password = false,
      managed_by = case when rows[i][1] <> 'union.sg' then coalesce(managed_by, sg) end where id = uid;
  end loop;
end $$;

-- برنامج القرض الصناعي في المصرف الصناعي العراقي
do $$
declare i uuid; md text;
begin
  select id into i from orgs where code = 'ind';
  if i is not null and not exists (select 1 from bank_programs where code = 'P-IND-002') then
    select full_name into md from profiles where username = 'ind.md';
    insert into bank_programs(code, bank_id, kind, name, summary, status, params, launched_at, launched_by, created_by) values
    ('P-IND-002', i, 'industrial', 'القرض الصناعي — المكائن وخطوط الإنتاج',
     'تمويل شراء المكائن والمعدات وخطوط الإنتاج وتأهيل المعامل المتوقفة، للصناعيين المنتمين إلى اتحاد الصناعات العراقي والحاصلين على إجازة التنمية الصناعية. يُصرف للموردين بفواتير بعد تأييد الاتحاد.',
     'active', _bp_norm('industrial', '{"min_amount":15000000,"max_amount":2000000000,"min_term":12,"max_term":180,"grace_max":12,"rate":4,"commission_pct":0.5,"file_fee":50000,"budget":50000000000,"min_activity_months":0,"disburse":"supplier","funding":"initiative","guarantees":["mortgage","multi_salary"],"docs":["ind_lease","ind_machines"],"purposes":["شراء مكائن ومعدات","خط إنتاج جديد","توسعة معمل قائم","تأهيل معمل متوقف"],"feasibility_from":150000000,"conditions":"الانتماء إلى اتحاد الصناعات العراقي بهوية نافذة (أو يُدرس الانتماء مع القرض)، وإجازة التأسيس من المديرية العامة للتنمية الصناعية. القرض من 150 مليون دينار فأكثر يتطلب دراسة جدوى اقتصادية."}'::jsonb),
     now(), md, md);
    insert into bank_program_log(program_id, bank_id, action, actor_name) select id, bank_id, 'إطلاق البرنامج', md from bank_programs where code = 'P-IND-002';
    perform _bp_sync(i);
  end if;
end $$;

-- أعضاء ومعاملات العرض (مرة واحدة)
do $$
declare o uuid := (select id from public.orgs where code = 'ifi'); i uuid := (select id from public.orgs where code = 'ind');
  bp uuid := (select id from public.bank_programs where code = 'P-IND-002');
  eng uuid := (select id from public.profiles where username = 'union.eng'); cmt text := 'م. سعاد جواد الربيعي';
  c8 uuid; c9 uuid; m1 union_members; m2 union_members; m3 union_members; m4 union_members; f union_files; a applications; v_inst bigint;
begin
  if o is null or exists (select 1 from public.union_members where org_id = o) then return; end if;
  -- مقترض صناعي عضو في الاتحاد، طلبه عند خطوة «الضمان» وتأييده قيد الكشف
  if not exists (select 1 from profiles where username = 'citizen8') then
    c8 := _mk_user('citizen8', 'Alwah@1008', 'صالح مهدي العبيدي', 'citizen', 'citizen', null, '07701234508', '198205120008');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'بغداد', city = 'الزعفرانية', employer = 'صاحب معمل',
      monthly_salary = 3500000, birth_date = '1982-05-12', must_change_password = false where id = c8;
  end if;
  select id into c8 from profiles where username = 'citizen8';
  -- صناعي جديد بلا هوية — لتجربة طلب الانتماء
  if not exists (select 1 from profiles where username = 'citizen9') then
    c9 := _mk_user('citizen9', 'Alwah@1009', 'مريم حسن الجبوري', 'citizen', 'citizen', null, '07701234509', '199107220009');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'البصرة', city = 'الزبير', employer = 'صاحبة ورشة',
      monthly_salary = 1800000, birth_date = '1991-07-22', must_change_password = false where id = c9;
  end if;
  select id into c9 from profiles where username = 'citizen9';

  insert into union_members(code, org_id, citizen_id, owner_name, national_id, phone, factory_name, category, governorate, city, address, site_geo, trade_name_no,
    dev_license_no, dev_license_kind, capital, workers, products, capacity, status, joined_at, valid_until, verify_code, decided_by_name, decided_at)
  values ('IFI-' || to_char(now(), 'YYYY') || '-00001', o, c8, 'صالح مهدي العبيدي', '198205120008', '07701234508', 'معمل الرافدين للصناعات البلاستيكية', 'chemical', 'بغداد', 'الزعفرانية',
    'المنطقة الصناعية — شارع المعامل، قرب علوة الرشيد', '{"lat":33.2741,"lng":44.4683,"acc":12}', 'TN-BGD-4471', 'IDD-2019-0388', 'complete', 450000000, 18,
    'أنابيب وخراطيم بلاستيكية للري والبناء', '600 طن سنوياً', 'approved', current_date - 200, current_date + 165, 'IFDEMO8K2Q', 'د. عبد الرزاق حميد الكبيسي', now() - interval '200 days')
  returning * into m1;
  update union_members set seal = encode(extensions.digest(convert_to(jsonb_build_object('code', m1.code, 'owner', m1.owner_name, 'nid', m1.national_id, 'factory', m1.factory_name,
    'category', m1.category, 'joined', m1.joined_at, 'valid', m1.valid_until)::text, 'UTF8'), 'sha256'), 'hex') where id = m1.id;

  if c8 is not null and bp is not null then
    v_inst := _installment(250000000, 4, 108);
    insert into applications(code, citizen_id, citizen_name, program, program_id, purpose, governorate, city, stage, status, bank_unit, amount, price, term_months, grace_months, margin,
      monthly_installment, guarantee_type, bank_choice, biz)
    values (_vet_seq('IND', 'applications', 'code'), c8, 'صالح مهدي العبيدي', 'industrial', bp, 'industrial', 'بغداد', 'الزعفرانية', 4, 'active', 'المواطن',
      250000000, 250000000, 120, 12, 4, v_inst, 'mortgage',
      jsonb_build_object('bank_id', i, 'program_id', bp, 'term_months', 120, 'grace_months', 12, 'commission_pct', 0.5, 'at', now()),
      jsonb_build_object('business_name', m1.factory_name, 'activity', 'الصناعات الكيمياوية والبلاستيكية — أنابيب وخراطيم بلاستيكية للري والبناء', 'legal_form', 'individual',
        'reg_no', m1.code, 'governorate', 'بغداد', 'city', 'الزعفرانية', 'address', m1.address, 'start_year', 2019, 'start_month', 3, 'activity_months', 80, 'employees', 18,
        'monthly_sales', 65000000, 'member_id', m1.id, 'union_no', m1.code, 'union_mode', 'member', 'category', 'chemical', 'category_label', 'الصناعات الكيمياوية والبلاستيكية',
        'products', 'أنابيب وخراطيم بلاستيكية للري والبناء', 'dev_license_no', 'IDD-2019-0388', 'dev_license_kind', 'complete', 'trade_name_no', 'TN-BGD-4471',
        'capacity', '600 طن سنوياً', 'new_member', false, 'purpose', 'خط إنتاج جديد', 'program_version', 1))
    returning * into a;
    insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role) values
      (a.id, 1, 'بدء طلب: القروض الصناعية', 'القرض الصناعي — المكائن وخطوط الإنتاج — المصرف الصناعي العراقي', c8, 'صالح مهدي العبيدي', 'citizen'),
      (a.id, 2, 'تثبيت بيانات النشاط', m1.factory_name, c8, 'صالح مهدي العبيدي', 'citizen'),
      (a.id, 3, 'تثبيت التمويل والمستندات', '250,000,000 د.ع · 120 شهراً (سماح 12) · خط إنتاج جديد', c8, 'صالح مهدي العبيدي', 'citizen');
    insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
    select x.app, x.kind, x.src, x.mime, x.data, length(x.data), encode(extensions.digest(x.data, 'sha256'), 'hex'), '{"demo": true}'::jsonb, c8, 'المقترض'
    from (values
      (a.id, 'ind_quotes', 'demo', 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAAGQCAMAAACH26ouAAAAwFBMVEX////8/f36+PL3+Pr49vD19PLz8ezw8vbw7uns7evr6ubq6OLn5eDm5N/i4uHf3tnZ2tnX1dDS0czOz9DLysXExsa+wMC7urW4t7OztbSwr6ulqrKlo6Cgn5yUmqOWlpSTko+PjouGjZeIh4SEg4B3f4t4d3VycW5jcYdqaWdkZGJdXFtNaJROWGhSUVBOTkxJSEc/RlElRXxBQD8eQHg+PT06Ojk2NjUyMjEuLS0oKCcmJiUkJCQiIiIfHx8eHh5Awt7WAAAhTUlEQVR42u2deXfpTADGNXVSpQQlNI1aqpQ4OLyWUOb7f6t3ZrJNIiHppbo8zx/35jJbZn6ZTea5qf8gKIFSqAIIwEAABgIwEICBAAwEARgIwEAABgIwEICBAAwEARgIwEAABgIwEICBAEwyjahmsULOWNBkUSJzmB1L3704W+E/UfQZgAnXTSqVitk6NGQqWZTwHGYvj3fH0ncvzlb4pEWPKCGAuQIwo5ci/fftNwYmuoQA5quBsdqC6v67AnO0hADmosC8qeqLL3inYLXFnTr67/LAjB47iYt+ooQA5pLAjFJ3haIYvMPb4lZ9m51I/0zApJ6TFv1UCe0JTvXlVwIzenwbPYZXzui98zK6NDCd1Js/h0cW/2l2Ov2vHZKEejpVQhuY1OPPQEJs5hjAvKdeOqlOyP0+37F6eT+s88fns/Yw94XnqhicTw5G/30NMKPO8/OzW13Hii7U06kSOjX4E5bcgWb+/JA0ureG6RBgbornBOY9lbp5PBiSHr8EmFnVuslUYZR4SDrVfXQeRy+PV57iVKtJm/nTwMzurUnd88WHpFHH3iJzg/NWfPkHYKpqoBeMKomacnQ/S1L0EyXkek6NnlPnAWY2S7QD6un+PmkzxwJm9lYsFgMsvtB0bl5mMacBoxdVfe7MYgEzixrR3OAztga5GX0emLvCfzePMYCZsQSKLxybzumie/V0ooT+mqSRXoKwBXWsuxpVbznSL7PTiYfvLrLGCS/sQTPHAKZTvOGUOTBbI+8zm9aF17kTxL2aPfMUUjfPcR7TWaoafH6s9Lzgo1v3mbd37Dud91kMYAI7+rMC1SgamHdrLsIfs+dTRffVU7CEYTc0s/5mNan+AzCzOyfQ8+nEw+YoduOETtIPmvkkMLNHuzQ3/sZ4cQr436zjB8ZrppEVbVZw71uN3a+/3N/fVyM7pDdfJY54ld2+nARmduvPceYk6SvJ6OXl5d2bi8ysSeyJogfqySph1dfJOqna1cLJeP40MG56IzdQ9XTih7wUQ/LwynrQzCeBYRnfPqYOaBjRKrujD9/o6e7mODCcl7uXTtWu/XjAjA6zFIM/C5ME/jSL/44E5s3rKT0gDoB5d/dnR9byuOMmHl30QD3ZJXzz91b3PmAeY7Zp5FrATs9t8rdEiY/e399nnJe75zc1FVEDwWY+BQzL/272350ziL+5CfNavL91n6kbp368INYVK8vjzH6c35yPT057GGbFWTD4m9hX2JME1laPVaugvgK8BYFhz8ut2/POOjyRWbAkM29VwCG/9Sa9kUUP1pNdwmJgPvQulq9gdQrq6V4/fBfHSc/pJF7iJO79gs9Yen+2a5mPa28hNRBs5lPAsPD37x2W3D3NZ8TLps7YvNwB+8YimI3zRTGIfcX+KNDg1nKeJsI/vgur9RmdoRVn4gKlMJp5wZ0cHPJpU47YGGw9DgU7V68AXkyxh6GdHR/j35/vvYHfXxK7oOwmndH09n3m3FFo0QP15JRQrOSUrw6rs5F1B3w8ff7MDqtTyo7dwz6OZqcT97ocVhnFW8Y5bZz7VFQNBJr5FDDv4kBaCBlc75/tFn5MJdFj1GN6L96ZP/iRHG6f7alb6uXY4O/MD+/ubtxZ1ey/0B4mYdHfw8MWAj2CoBvxr9Ene5goRSYuzOJG0fOkWXQzx5rDON0yB8ara/qBsDzveB8LQe592XoTrE7UY/oYCkwnkEO0XgIF8E/VRnf+0MW3kGX16HgOncg5jFNPqbDcw1J9corxmf16H5jvz7exEh95nW6wQI+zqLIWnkcJltWjl2e6SB9V7yxgCqMOg+DmrqgGlu7Pd+6uaMfm5L4zeynyO7m9K1Rpts7S8zl09+NFXFiw/qToC+7lwApwX31/Ltxw+O2Pi8/3NxwYrwB3zwd7DlZ5aPzik3cDvpIwVO9Y0je3d/fsNt+eHwt3tzepI0X31ZNXwsBYwFOl5XvjzXv38t8LnxxUP7Pp5qZ3W+A/ibN3tU4nLjyTrKZUXsG0cR59THg1cNjM3+md3hfheeBT5E7M3vmdN1b8fdHZsV9x3m4+Oak4qmCqzluk72+f26M9WsroxF9cYPji9f0MNXBFYN68Xtxa7s2u8VvbzQVyPneqn07vzYnGfyW7nZ0h7ePAvD2OOhf7xcxaK6vvI3tJ1flaVuhz2VHvnNXXd03139LjHXeh8/7C56NP50g7dWLUeDvXL2aRLx6JG5dfKW+SN/rGqf5jeuJaojg7R9pXPZfU8aa1N8+z6wBTeJl951T/Mb2Z9wO8OjtL2tc9yEb30x6LheKj+9P2F6pQKFYTzJ2vlOo/pzeia75CYFn0L2nj5CMEYCAAAwEYCMBAAAaCAAwEYCAAAwEYCMBAAAaCAAwEYKArACNBUAIBGAjAQAAGAjAQgIEADAQBGAjAQAAGAjAQgIEADAQBGAjAQAAGAjAQgIEADAQBGAjAQAAGAjDQlVV61QAMFF8LHcBA8ZVeVkoABooteboxAMzXqPv6c7OpDCt2D6M7V3GkDXM/CJhSe0pWzj+y3cV28ZqlF4RrLQTUpx/rfv7gWvw4UbgIzScnSikWOCTRbGO83kxbmROZhmdjq8rufTPR7SumbJy6rJOng6sYeiXKzwEmzWrDqX9lySunFQZMm3+wyAauxY8ThUsEjFBKscBhifasks8zxzMNZKPUM08ZPzBUbQBz2BTz18rCAWZMplU532owYHr+cMpuq8lFg7z6r8WPE4VLCIxXSuEyNNFuT81n6ivSOJ5pIBttUyIlAZiuJOVbZCvzq9iKA0z6tfT9gcnVji7yHGBUsnYepANgmvRxowltVv5r8eNE4RIOSUIpvcsjiWqsoY9lemJI4pgYpHI2YOSnbE2x5sPVk8AotasCI/d2xIwDTJdXsA3Mcr2dt2U3zMB6AA3y4LsWP04UTlp9/DMwh4kKTacf/T6YTbbV10OAKX8CmPTTQwgweVJZ0U5PyjjgHANGN68KTH/fU4vCvzPNRjq0KYak+rreTnXJncNMXGLGJG3NECq+a/HjROHOAcxhom6/P17Kx74PZpNZ0Jvt+oF5aO23GWcOM40PjExqR4YkhZRN/Sgw2aIiX3VIyu6CD4m264c2hUEG9lxPyg7U7IO2ZPNfS9Od3QlVfdfix4nCnWNIikw0PTDLx753spG1dqNojWA9ZbxXoie903+ew9RbWvropLfSaqr8+SZkv+zr2asBo9BJ34PeH/tKWAsHxqxnc/rHztkWKJPxxXqY4BaGU582MBlNLyfoYRS7Ya1pwtCsHO+BrGy0FY2xYwNFg1ZI06sUcVkdeNpK+oPQL/FBhg8x/E+OiXclqu10YfzrjG9YYsCUxixPgxZYe+0OJh9k273akEQ52JMPEZiMaYQ1RY80rb/cmtssLjaH8avBnuKcB0xpTZ+zVvw5jAjMw2Rdjp7jqPOqnU2XLLVscbqhjVTeLbsrogbmMFIIMEPT6yfSHz3+VDWdPzkm3pWgh4+pOtyXnIBWHAGY2mbXzud6pG5/VFuTydWAqayIUfcPi4YZ1hS6A4x62MNcdpVU3M3rr9bCzAJmuG9qy538mVVScbEqSdHf562Z/XzSIkaO3y3b2NMm8ylRYgAznYiUD1j18lqrsHV8jWj2VRCYCh3cSzxnHpyHEYCpb9esF6w5H7f2ZjNzLWBK5jq4SpOXq7CmyG7Meiarf2yz0mu7nPHNYS67D6Oxml6bWV4GWlOyOWa9eOk4MKGJVtYLJaQswh7gnHE4N/dj+neuu19bXYaymktxepitM76V6YRvnWGPWZ8/bLxzadtXQWCyu2U1zZ8IHlz3ff1KTJPealpbW7Ot4pAY+etNeoc7dzKQY/1cs65PhTocC7M63bpu8pkXXyVl3AVNjB3cuOEOVkmNOemV63uyHA7pcmU+HMzJvF6e7B/CSilchu3kDu3BaRDxfY5n0DcJGfaHkx1Lqd/vD8abfT0UGFsuJpud0dIb7f6ckH6DLHvDDdkbzeFmk2MP4s6Y8isBmME8bRVlRRb9gUGDj60wdmfS709ZGWgJ2Bb2cDickn03fcVV0tqQfMDQ2cGulw4FRqpPNpsJ2+TLtehNTVt8TEibS6tVvd9lhGvvMm64A2A0sqbVT8zxZkfWvR5ty61h+ta5EcAcJBoAJux7jYxNh4Ld2mgoA5O21N4c16Q4wEjFPo9ujtu0U2iZy/2iMd4O9wuOW2W6s64EYLYDq2qHaxaPBf+wQ9szTEv7zbRbatFpuDntlq+6rF4Pg9uItVyiBCpEO2u4kFm5IpV1zTdo5+p65RK1kV9tMv+cRknJxg4sE3sPI033AaWf8HqDYdqPWPqTCbQm6bOGO9B492U/nalL33Tzs6p6TW9v3fL93VCtprxa8obwa0t06G8ATHW3apbz+VqvK31TfREw5XprTLaNs5S4F9y6lUktclvO0Ov6YEP6aaHbqX3jF6jUKR8kD3ak/xowdPKz6ipffneyNaua1qWf88adUtO0aua78iKp2pdkU6uX0le5v0Jdr5fwiiYk4VwSBGAgAAMBGAgCMBCAgQAMBGAgAANBAAYCMBCAgQAMBGAgAANdW0m8oaRzmGJVTjlX/Vpg0rXhcrvoWS+4PXTn27VRC7epinCsShbuqFxfrcRK4tzyz2JH+E4aEf1aYOzzGRv2plnWMrYiephNVcQ5pmThjsrz1foxwPgNsf4EMJVBvSCXBvZhv0mFGluRecjxyIiTksnCSSfe5XV8tX4MMH5DrN8DzAlnK/ZK/YCfQebB1ouQA9gRZ7GThTsqwVfr34FRahiSpIs5W6VLfY6Ksp2U5YeWd5IxwtbhmBXE0XCR7kQBX60Y8jtEJfGGOicwfkOs3wLMCWcrjc4bltZtV9jxVrOdDjGbifCTSRbuKDCCr1aUBVekQ1QSb6jARDtB2ANgAoZYvwSYU85WDJhNj9eazp17BtkQO6sIx6pk4Q5Ww71mVjiI6/pqOarvekmGpHjeUIGnKSxsuqfFAiZgiPVLgDntbCWX+3zSWydjNundjy/WwwQHIXpkTRH8lPy+WnyZVZOCPlCilVQMb6iMOGoc+lKJYUu1tPWH7J2WPYwhABMwxPotQ9JJZyuqpckHBcWakSiXmsP4VKaLsgbpe07PQV8tVtCxJPhAWa5UgpXUaW+ozFzstA59qZywY551lhU6IwITEsMDJmCI9VuAOelsRauCTy7GFilD173gsqsky53ItTE88NXiBWVGZa4PVN7zhvKbQ0V7Q+mkq0y22UhfKiusZV7UY/c/JgVqt9KLdrLiwNSsBaXfEOuXAHPc2arbKmeylaH9hFlD0jbzBfsw6dc1GdYbxDU5EXy1hIKyhnF9oCxXKsFK6rQ3VIsmoLlj4qEvlRV2wLYLMyvKY3ZDcVS93uswRnYztD2sgoZYvwSY485WtoXVhoVRbAeflrueOb2DGzfcwSqpQebGnn7p7Xt5vlp2v8UKunO8olxXKkOwkjrtDVXabQ3DHeUOfKn6Vlg6cE2nC7LZDef75a6/3Lm9xkGMwYLthDMPq1bQEOuXAHPc2eqhNdl8OL8l5Xvz7WaseS5VUdZU7nXccIfAGHTCkFdVcd3s+mrZBacOV93SZO/5QHFXKp+V1GlvKNUwd9G+VE7YPLX5MLslukzuqib5EEa7gxhrziL1sDKChli/BZjPOFtd3M0qhncILWjmLK5UxlaO6UuVLjMHvEruH5ysfj4wn3K2uribVQKzGWdT13GlSmgLJfeCe2vVxJZkyWP8YGC+qbNVfGDYpm5bcKVKYAtVUrXXBTHkSF+q5E5Wf+AFqu/pbJXMzuqTrlRsL2/ZTOONu1/gbJXMzuqTrlQ1raZIeEUTkvBOLwRgIAADQQAGAjAQgIEADARgIAjAQAAGAjAQgIGkw7db6LsN5RaAgeKp9zpeLiYqgIHiib5s95CTMCRB0tnMnxJITKv7miRmtQ5gopVtjNf0f8fOBK+lr7apiuW0kUBiWvNJ7GiZxpR0AcyRiYN1jmOeCVxLX21TFQ+YaF+oswBTov/F+7SRATBHRoKems/UV/ylffH6y22q4gET7Qt1DmC6ZDdUMYeJYVOlCd2wcP2VNlX/NiTVlErZf7MngRGi2CqSiYJJbwybKla7etj1V9pUxQMmyhfK1I2e7f9i3+xJYJwo3lmoEhlilSSdtKlidTZeymHXX2lTFQuYI75Q7qjSqyqJhiThLNSANADMSZsqysjALIddX9ymKjYw1ICqKh33hWrwu5Q3/ag5jKy1G8WQKCKP050KYE7aVMlDsxJ2fXGbqrjA5PmZ/GFa9IXyuU9RMxBj82FNQxo+YCwzK5a2xj3bGodReBDb9EpZmw5TGU0v/9Eh6YRN1cNkXQ67vrhNlbNP1laPA1Nef3ADKlXwhfK7T8nGfmAQtt+T2bMeptR1jaS4xQhNu0uWWrY4dU2nvCg8iGN6pe7n1iZAiRpM7Ft/E5jjNlXFxaoUdn3pVZLyZP0MoO/JXgsBJm99Pe+XzJVlQKULvlB+96nWrk5Hq5rVnfUbxn7tGElVbGBaxMjxb3MHUXiQig0MpdvgTA33TW25k/8iMMdtqirrhRJ2ffF9mIFptcZ0o0xMxTJ/EoBxHnlju2QGVDI1oKoIvlAB96lFNmObjmUn9Kj5a84xkrIsrebmfkxzy3X3i/RBFB7ECkfzmVuTapk58LXDt3x+OzDHbaqGtmXPIHB9cZsqx2HulQyLm+WQmz8JwHT3D/ZoJxpQub5QfvcpbUe/XhOjxwIuuQGeZSQ1pJZW4zHzDRr2h5MdWZalYBQeZMqtr6jt1IL0xmQyHMzJvF6e7B/+IjDHbaoigLm8TdXYzDklyFCrS27+JABjrJzBc2oZUBXbbNbq+kL53acUTSvJg+1ivxrUnVtjRlLM0urDvqvd2mgIQ4wbhQWxrK8YQl0522P+WIb5G42df7JNlUaWDbVa0wfEiFo0cQ/QaUz3qbPvjtf1yt9cJX1TmypJX1veNq+hv/WN12lrOv0a230qTDEtrfz/vcEf34f5pjZVtDEb3Xa/HAEcXdboNd0gq4fY7lMntnFPOWHpAEb6zjZVVH2jsY6kqb9nUxZD+V7uU3/k1+rvaFN1UnlV15Tv5j6F92EgAAMBGAjAQAAGAjAQBGAgAAMBGAjAQAAGAjAQBGAgAAMBGAjAQJ9Sfvj0XfP8K8AU+qvdqhthLxVlIZUo3DlVIl9vpxkzzz8CTMF653oih9lGRR0sShQOwEi/y5vMKMmloXMkNPKM4rFjjUfDfVHj5V9zFwYm9yQfPWuQ+htWU9MdG43kj2nIgeiow9GJwl0QmLwwtyhNlQsDoxLl6FmD1N+wmnKAcQ+YR/gsHLNmOBruqF2QlPRUkA+YJ+JePtDHP/eJw0RSjJNKgV4tKmTqb1hN9cmQD0lEOTR1iTJ4SRQuKTDZoiJHnwqKGpJq9PGvfuIwUZyTSoE8o0Km/obVVNHkh5MMUj60jYqykEoULjHe9NjRsq9nTzZeujmZG/62S/eSntDN6G09H29IyvSmRxd/qT9iNVUamNtxaXLBHia6tfjQkfEPINprdzD5INvuwTde4/Ev2sSc7PeM81Itbf0hk56XrOhFVdIfBEO8hv9c7rYWHikAzJisyDwdWqpfNiSdsJrivdDHJn2xOYwUZS9lmb04li+SOnd7JerbMBa+CTYe/+KVDLKWO0yPZFkZMjYw/Fu/F9XQ9Abh9Ad3ydR6crpHprVMZT0Nj+TPU6HmaPwxCCnVLwPmuNWU48byFaukgL2U5e9Ucfzn8m5btfZkLgvfeCrzxuMR5Qk1cmla3ZnCOoAC9S3pOwn6vaimgl+mbTFEI/VIT+YOI+GR/HmWKIwtBkwlwlMz9TesptJGNZNv7/eVr9iHCdhLWf5OuuP+kuaU0GnVkBgD1ki65wtTtf9PiZrnDkWvyZI1bmZFSctuKDwqWWftaAEvqq1zVaZWROsMjzTn/ZEyYJ1ZWCR/nun5prleyb5S/U5gjltNpS1bnaa3nomxgxs3XHCV5LeXMri/03CzyTmlI/PhYDgl+26aDg7TufsNnQp/yHZMMu5aBlLjndkj5rBH7aE2u+F8v9z1lxShocGj+b2oyhvqO6U32n065vQbZMkjkd2gb7BBaM+SPIzky5O5UFG3q8HAEEr1O4E5bjUl1cYb07BsaG3fqAivKO8ybrgDYPz2Upa/035Rd72ExnTJZk67DPD8YEMW3n84Y6ztHzI244+5ZSBl9hVJHW9XxOyWaGN2VZN8tKhNlJ2g34uq2LdWg+M2nWK1zCWN9DCk9mS7laGVjO00LJIvTxa3Z6z3ZL+o//JVUnyrqYv7Sx21l8qvNtFOEq+kTRdB+jJi/pAu01uSK7ljXlT5khLnBy4v0ok8fy0w8a2mLu8v5beX4numzsas6jWMcrgzlp0Sc/Fhm9nE28s99KKqlhNF8uX5h4D5VlZTPnspvmfKNmbb9daYbN0HWQ/5IUPWB0ZPy8Tcyw33ohr3kkUS8/xLv1Z/K6upUHspah216p7zx8NPeVH9o4FVClZTX6ZavXReo7FPeVH9o4EVXtGEAAwEYCAAAwEYCMBAEICBAAwEYCAAAwEYCMBAEICBAAwEYCAAA/00delpi8qwAmC+VtnGeL2Ztqz3emvD5XbRc95cejBJ7xubYbH/Bbn+288lSd/QxIhrzoipWtebkvXVYCUC8+3MsADMdTr2nprP1Ff8lEBlUC/IpYGNydNGE4D5fmZYAEa6huuVZB9S6goOE/y8c3atVwRgLmyGdbKEAEb6Hq5XlurEOcaQLvWto3F9QxKBObuRhGhtFKOEAEb6Hq5XFiXjpWz3NPR0B2enRo/cicCc3apGBCZYwigfLABzfdcrzsvALEsuMBvmu5FdcQuQnuC/dzkzrMMSxvHBAjDSVVyv6IAwNL3dDLncZ5j0hpJ02R4mooQ513cqo+lK0AdL+BTASFdyvXqYrP3nnJcm9RNy1PwKMyyvhFnqEmItpUrM2cI7IGr5YImfAhjpKq5XxcWq5B+g6OxCOQDmoqskr4QN8mr7Tg33bW31kfX7YImfAhjpGq5XlfXCPZPabZUz2cqQjF0rka/ZhxFK2KRLNJ2NW7I5ZkOn1Zm4PljCp9nNEMBIX+96NbR7koE1u+Q7veUAMBcxwxJWSUIJi5utMaZ0UDeqeb08ITuj2fd8sKbep9SESgcw0te7XonAPLQmmw/vtyQHmMuYYQnACCWkvlPrHdlT/1WD2VSN19u+6IMlfLrupgHMlV2vpCuZYQVKaGz4dCZbb4SswcM/BTBXcb2SrmSG5SvhoVlVuA8WgJH+guvV8RL2Ld+pQ+50E8BIf9P16mgJ5//mOwVgpD/ieuWU8B99pwAMBGAgAAMBGAjAQAAGggAMBGAgAAMBGAjAQNK5T8S9GhkAA8VTZr4atqppAAPFU1pJlxt99DBQTMmGOelp6GGguD1MVcakF0qiKMenK6TIDKjgQPXdFfWWvk/Z7mK7eM3G852KlaIUcRYfpwZ+AzDKkr9v2ZKko75TD09pAANgJHYEf1qV862GFHbeMfPkLLJqJANgAAx9oZuss2EHrS0VSRlDEoDxTUY5JNKBlUNwomPbevAU008hpg5qCcD8BWCGpPq63k71oFmM3/0qs6Bzm66TokxCDqpNXwHMXwDGIAM+020H7KicFHY9y+qqp4z3yqkUK61m4GBsujmZGzUA87OAoTZQ1lTE8YvKeOeJqDlQPZvTP3Y5KdR3qs17kwb9s8mueIqZ8ONIeYORN/RtLbeJOdnvywDmJwHDbKD2LdEvquwaD1E6mtZftfA5TIZZvEjl3bK7IqqdohBdUHn90c7neiwUn9PMq9xtbZBdMwABzE9QjRs0DPdNbbmTBb+oCjeG5tIdYNQI3yljw7oMbTKfEsVOUYgu5S1riXm/ZK4qPEv7iG+eJyZPyJrnAGB+gsqs0bgNVJt1Hq5flO41XHZj1jNZ/YNxFOY7JS9tVxBlNXdSFKI7nY2xXZo0B1lb7+2FeNoyLavR49dZ24AKwHx3ycudMbFsoPYPnl/UeLPxLGd0wRwvuNPL3a92O2Pcp3H2dTvFqRC9u3+wV+RkygKRre66IZH5cDDemT1iGnNuQAVgvr0q051tA9UV/KL2i7o40ZlsNhNNCvOdopOfbbc0oQ5Te3Ncc1IUoxsrxzOGOjrsN9NXxbO3H9N8zb4iqeMPy4AKwPwQ5ep6JeAXJcU0aahlYmzgMivPaXDJtNpk8HrDL/h/DFhXk3nKnsmnQxqv09aPCoFtO3UpTIwBzI9UyfWLUkj5XHZFLWLoNd0gK2ElXq63xmTbwAtUP1zjc/lFiUr36QSH7A3Fn9Gqq+CNux+/KXMuv6jAZEXVNX+6tXopjVc0IQnv9EIABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABoIADARgIAADARgIwEAABoIADARgIAADARgIwEAABoIADARgIAADARgIwEAABoIADARgIAADARgIwEAQgIEADARgIAADARgIwEAQgIEADARgIAADARgIwEAQgIEADARgIAADARgIAjAQgIEADARgIAADARgIAjAQgIEADARgIAADARgIAjDQ1wOTzaDCAEx8PWhlVBiAia+cVkGFAZhj0kruZflJyrWrqDAAc0y6NwZVdN8/IQADYKArA5OvaV5SJev6SUGl/z5gCuWqWimmkwLTkP28tGrBCLlM+iBWDf3WjwemqWntNm1+Tkhajt/DPNSeKi4StZr4laLTL9o02VrB+7D4hCb4FUNSqVWV7SFJabYrPmDKbU8BgiqteqWh8qusJNXplZyze5uG3s4y+B4qrTZNOk+Tq1WkcgM9zG8AJttS3DlMo1Zq0x3einakh8kxLMr1cpNGs+YtOoVMaalPLStKulmWmkXeBzXajKhimw54dQ6MhsX6jwem9uRNenVNaZZzeb12BJhGmTPQLudLT1avozUUpay363YHk26paksv5BW1pVZb5Uxeb6ulVlPR2pVys4Rm+OnAOA89IySvt+jEo93IRgMjsy6IDmPNdrupKVaP0qCRVO+3p7xaVXT7a7VVazfKrbaqtZu1VltLoxl+Sw9jz0xbJ5o012YBVN37RG3Kp3KWKU1ZsPI7gHlo07VOWsmzviJXbZ/6CYkOOJlMxZ6uSOlsSW8VUbV/apVU1NvNNp/Cttv66cYvs8HIwarWbqpZ1Oxf2+mVrT22TMxRI5Nzw8kyqhWvN0AQgIEADARgIAADARgIwEAQgIEADARgIAADARgIwEDQUf0PemfBAbxlO0sAAAAASUVORK5CYII='),
      (a.id, 'ind_dev_license', 'demo', 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAAGQCAMAAACH26ouAAAAwFBMVEX////9/fz6+PL3+Pb49vD19fHz8ezx7+nu7efr6uTo5+Hk5N7g39ne3dfZ2tLX1tDS0MvOzsfLysXEw768u7a6ubS4t7W4t7O4trKyt6W2tLC1tK+utJ6vr6ioqKKko5+cnpOYl5SPk4ONjIqEh3d/gHZ0f1l5eHZveFlubWtjaFRhYV9SXzJbW1lNWypXV1VSUVBNTUxLS0lGRkVDQ0JCQkE+Pj03NzYzMzMvLy8tLCwnJyckJCQiIiEfHx8eHh6JEeP9AAAeJ0lEQVR42u2dZ2OizAKFsyxBsSvkbjGKBg1L0NeSWBHm//+rOzN0BGOMaeacDwnCMI2HKcgcr/6DoBfoClUAARgIwEAABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABgIwEIC5LN1TjY4KOWJBX3bKS2KNbb0i32+TyVOSuVRgflxdXR13me5pyKuXnfKSWGNbr8j322TylGQADIABMAAGwAAYAANgAMx7TH/qg0F9kHno3+Cu93BWYA4k9hpgDkR7AjCnZ/JbADO46t1d3WXMCP9cs9IO9iu+8efkSspLLK0giUH9/q7+71lgDkR7AjDHZhJdUqJ1KV5d5QDzo/bmXVKQRO9qcOvFgS7pc2vEeblW/vy7nDHM6OHfw+j8mVR+/vx5+62AGQ2q1Worua9HC/ijNzpy0PvQU5Q/d6NjKikrsTMAkxttmImH1k92YrF37kyOarGG+BsAc1djhbkq+KWnYv9v6a6b7Ds1CBJujf7wGK5+3I6eq6REYlFE7BLd3Q2iT+kkngEmWYZEbEEmRtKVr9uTM5nAJNr/QEksZJfk8oAZNf1q/JEsIGthvIHn6C4JTPLK0dMeysGluFIPV1IysfiFvy+wDz97+a3JAWBSZUjGFmTiX5jJ1qmZpJ96vd5gPxPs7uodLsnFANNipWuwYj0kCvhAS3h9T2+Xm+sfh4EZleg/SbtTgkjyKymZWKzO//30L1LvFGBSZUjGFmaiFgBz999pmeTzp6DhSex/oNuVwyW5FGBYgaTRf9dBPQ7CamdNzJX8M7xvfwQddRTE21Lpn+bIQ4yHGORVUiqxKCJ+kRrsz/UoK4mMrQNliGIrxvM9qsav5IsyGbU+V4laSOy+zy3JJQFzx6p1cMeqp0jL88ArVRnRHvo+uCN/KDwkmzVVH2JB/C0WrESD3/KnNvI/b3chq5KSiUURjW69i1thndpoP4mMrUJ+GeKxjaJ8j+78e79xn4jkiEzGEvPLmNzPU7wq/8spSeGSgBlcxVS+2pd86z/qrV+9RPWsShocOuPnH3/ofHz8B8rgxzbKznf5ZZmsJ1uYxP6ecntTOFyS+sWNYVghw3q8jhW2dHufuPN8xYLIiaqqXiXGCZnDgyCxdFpJRUeytq6Sz2H3yhDmJ5nvq8rgNh7ouEzGE7tPZPLOH+/yzOXDfXdZ0+r73p/bu38PyrVXj+X7O9aI/7iuqncPiYC3QZ34QRgudyOtymv253W5dfvvv7sqv6jXtzmPbmKJxSOS//hx126LP5JJZG0F8eeUIYrtIZbvnyWVDT5GvYbk3xnHZTKR2B/2ufQjtt8DRrod9eQfWSXJTwbv9L7u2WHv9vbu/lPGFuuufoQPG6J3MOlTl3+vSRvAXCzUt4yXwggvgcfvofDb4ctK65WZfPh3f6fyzubn/bkz/7WBib4dvqy0XpnJaH717+yZR5d0gQpmjb0R1iVBR6hcqbX+3P3DQjYIKx8hAAMBGAgCMBCAgQAMBGAgAAMBGAgCMBCAgQAMBGCgSwFGgKAXCMBAAAYCMBCAgQAMBGAgCMBAAAYCMBCAgQAMBGAgCMBAAAYCMBCAgQAMBGAgCMBAAAYCMG+tut755lf5jDXwHYBZdr87MGesgW8AjLhs1r83L+esgW8AjPRoj783MOesge/QwjTFb94jnbMGvsMYpmm1wu2hntqRPJJ5UuvvOVL+LDVwZJC8U74DML9IO9x+mqV2JI/sn1TQHsnwHCl/lho4MkjeKQDmIDD14ZY8aQUAA2COAmZAHEt52wv1jMq6DGA+FzBqtdXIAaZKZpWTUpTV9rEXKgiao9q88hbAKPVGC8AcrK5Cu6hWs4DZaGMjB5g6sU5J73rokE2s1sV2KXfCawRBs1VqS235vDXANdeNaKJdVwDMftmrpLHRXtolmaR3QnpDYiiVWK1LRM0LarqGUjsQlUoqRDlvDexLfwyCyLWK9G2AKRkZl0U0Os+PYbRhHjCFR0d9cUYk28y/TYua3i1H/ZFz1ASMl+JcNcBV7bULQtYNQtyl2ZUvGRiVDUCa9C6sEfYgxWt166ro/ZGIEZTdO7IHjNixtrsYMIWu1oiudWWzrUa1TFKqZuaoGjVL8ZS5uht6mh1e1wrNc0kzJxwl3ewmI0qWIpa3V9UAT5dmY9PdB6atD8zZjuyGFwzMjLWnk21QXQ3S552CzG6XQry6vCNpYCTLtcakHAJTX9ObrB+FUdzx8cC0dNZ9FFyTT8iFZModQxINMlcLzU3Ulllk45LdlJ21pBH6zw6VJ0XYK0Usb6+qAaYB6SpTEvRPPLmoTtQNmV0iMGVvMKi79GovHZFWB3+IyyvFYNdyQjmQWXXd8LJ7RxYpYHTnt9DhY4zFnF9Bt99Z7aTgJLrDuX4uJxV/UNt1idvhqZua5a6FZMo0TwYx2BBhug5Pba7J+BcfNmhkUJntil7RPHJipTATeTu5BoKmb0xzIE5tPyqeXFBeoe9u+4ULBCa4Xdq0tFWXdIQuWdAK6LK6LazoTtmmIRQWqskrkh8p2lYSGGtZLGjekS2tJmlL73ad1IOTBOlp+2xWzK1X8492Zbalo93ijJCtXhISKdM8LXhDUTWjuVd9uwm6J50XwZvrirwo8VKs5XjeTq6BoNjTJ56i30KKLF9+eWsWmZQvctA7dL3b+oa41tJe2wbtlheWZRN3OlsS27EW7nJnrhxaKdLKsfTgiJasjI5De4I1mT7RHmFpmQuyuGnMWNT0pMnMNJdHfC/wOA+uuVWzV9bUJqu+N6RMpGwTxzStJ0Lm4ajXcsIxSd2xxxNy442FeVFipSBkZVlR3k6tATs413QUQVlt/K8kZTLwy2s9EncgXuYsabLy/vfIinbsv21ia+aGjvF70x3ZDur0+g+VLdnxfro1d8bekc1QTFVGpdOpSSY7wircHm8pQEP/JLq5GUrPZmW6kYMRSUHduCvzJvxyOEp5OyxZO0J2K6sTfXW8jr11oFgbx29humRCsxErRX+4TuTtxBr4HfaENtmRddC4dUnHL+92Pmhc6rTan9SI851UobdzsVVMziYbrJVoll7+kPav9tJvmDtk2VNaqmaSl751sk4+GJx4o4ryalvMLEUyb6+pgUpPD6mOkjvmrc4vC8x0LXrjfSO+N/408/2krfmkaau/9FvK8cbvnUT+1NdrPpQV0d6xBlLJVdXDb3V+WWD6ZKKp3QmZy8lnIDlPM99WojbUjcbL31JSnFW/US6rhqF09CUZS41f+pTseu9VAzw5OxFc2xx+q/PLAnNtuvSmdkz5U+TGtLT1Kecpc69tWtA/y74oTOkIfFh5txrITy73rc4v/OCurHQ7FeGrq3LT7SgFtaPyoqh/a+I71kB+crlvdWIhGyTgnV4IwEAABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABhI+j+1U1VJf5YwFYF4ihb11q9D33Nztwvwtervin3zJ2mRtP/qv+GqPu41Z9l6snpPgxbyyuXZWw8Tb12FA8cZa2UvDezW3NKRrSCZqalN4uceHrNX5aqbeq3xrAMxJwHBNS0L6ky/D2/VU4KuVmJZFtmCMrYHyefHeG5/FFrFEAf04bXaBiyvvg5bYPAUYcTl+DpjKr0K7AGDODgz9U2j06fI3If3J18BQysVfa3ZtKju7I1UnbF2huNCby3WAlFWX6haJlkrHArasX2WpbvLlAF0ya0plnTwlNk9yEeq59WeA6dp1UgcwbwEMX8/D1mQnPwnJ9UpD9m4/W4Jasv1VZwEwjw67k6XdoxAtAkgEZO//m3zNNXdZ2CwTm1l5S5tK7VFR2Brokj4QGLrk0Eh/SuiGdR6md8uOSSkTGCfsk1IBr2smX5BYsWcNqdRnq1ljm77Wuyi1PVOpfSp0ulb2IDDFvqkBmDcDps5WOiY/JcYM06XEVnJce9YdzQQwvEuiK98jy5BEwC4bzXjXrjVlK3Z1Mbm5D8yeqZRHRcxUSijvdM/CIQeY4jKxFhfAnBmYMvNRSX6K82Ju2TrlueM7sigJYKpsnTTZTEi4Gj8RkAFjc28QocuGx44lJzcz5stpUymPipipFP2wlhTWr+UA0yVGdeJWAcy7tTDccsj0nYo2zb2GIwJGqJmb3bQ+I5XgnFRAqeENen+TKR3p9t1JYjNjgrNnKuVRETOVYgMYTSP7vVVL71x7vapKh1IqgHm3MUwETGm2bmQNTZaJBZLyzhaDc1IBWdgNd4TgS9XYv9jmvvZNpWJUeKZSLPYniy34TwLTY08AWKoN+mRo7TeFvgsWgDnjLGmdmCWt47dmdbmqZU5+ksDoMV/XvVmSuNrxFsqnpBHf3Ne+qVToKRWYSnFXTt5sJYCpOsu/uleK9nzx6I+qykQHMOd8DlNPPIepJ5/DtDbLoBWoOOHjlTgw4lgplHXXjWbCsYADvVEotqgXFO+ivH7ILsQ397VvKuV7SkWmUhyYVSkNDLeH2Wy9UU5lvYjZUgGYd3rSa/n7zOgBruytfWeaC/5TX0L6wt6TXm5m6C3RZ6OZ6sb7oCc292dJ+6ZS3HbKjJlK9XXD2TTSj2i0J2I0f7vMf8s0p7b7O2ZLBWDe6bukODD0igTfJcWAEdTJdjtODhPCgCV9vt0F3yWVjeXOnnZSm3vAZJhKMdupuKnUmHqbldPP9DpkveDzNXvHCjJJ2lIBmMvVs6ZSJd3IsKNiQ+hmt5Pu5bJtqQDMhTaEmaZSpt7LsPCYOkfEAGAuV/mmUla3WjwGmIwYAMzlKt9UynDmtWOAOeyCBWAuTPmmUo3MN12U9vExABhIwOsNEICBAAwEYCAAA0EABgIwEICBAAwEYCAAA0EABgIwEICBAMwZ1fr7bBBur+RrqAsHrZb2Dh0Iy+Py/wqnOkCx0zPSKFvt96vDnDwc7V/1dYApaI8Hl4nH7JWE2K/0HvC12Dt0IKz3i79PsxdlOR0fOz0jjTrRhXf98ebjvD6+9u9W14db8qQd8kaK2St9ODCltghgPlQDalmgPBMmslf6cGBUUvhwYMq6/L2AUautRmTFNHv+t1Mje6WXAiOr7S/YJQW5zlFtXvlewGy0sRFVqXXEb7+H9kovA+Z66JBNtENsl14LTGDjdG5g4u5BkhHkOq9XlNry9+2STNJ7/rffQ3ulA8AotWYrVSNDYiiVaIeUaY9yDDCFvrdOLLRxektgTNdQagd7xQpRvhkwWjQpKjw6h4YwotEJ7ZUOA7Oki9OTNSLZZm4VFTW9W84F5le6zf/lGAkbpxOBEfuzpfWMF6/sDI+pQr9iXgoMP+2LASN2rC2/obzep7LZevcT/+j3SHVV9P5InjMFt1fqheekgKlpUV9TWoU+b9UIMb4j1tt1mVmCfZMHjE3tnuRylEdmv6DGbZxeCEyh0614sWznrssHcIWu1sisngo9p6SZ3IqqqJvdVIypigmjzsxDYD+VOu1rASNZrjUmZU4Bd8RQ3EVRCD76+4aEO2MUwnqh9kr8iHc8BYy1iVZnSe4gOFRwTT5tD8J653YMSTTIXC00N4+HuqQe9xfz80PH3ZO4jVOYtm/mdBiYOvWv22kcGFNek5a/y+1nVpBFNi7ZMUeawjIyAPETSldMGHVWHkL7qdRpXwsY3flNfSjY/dr0L4ZFxmLw0d9nMPecCcVK9oFRfYMN7/giCUz8amtspblv0GQQU7PcteDv8M6lURuEexJOtyzQgjt0LGb7XYPB0/NbqbEtxmycwrR9M6dFNjAN76jl6p3Vjt4V0oxsvAJabp/ukjKfw67J+JfklWVQme2K8YRiFWMmos7IQ8x+KlmfXwsYa1ksaLy0Xa/M0pM3kOQfvX2FFa0e2aZ1q/hQUXul+Ub2jxdtK9nC2K3wEcVuWRACg6bijDr36CXB38HPpVEvOIRVk/tKFe1tIYiR62bqdxUru8zO8RKRVr6nimfjFKYtkoXknx67DIrV9HPNSiNtp6xx0Tzuuf2QvyvLmbu+3aihDVGHZqAVSyheMWs5EXU6D3H7qVR9fi1gOg5z5SeToWUTdzo1zSUZTsjc4h/n9M+kT3fZjrVwlztz5VQDe6U2WZg80GzJaygqdpOG1rWebi5cMq3yy8sMmqY2Wfn+b3TH5NE/1yaOaVpPzCxoMqRJUX8maxk5YBiuf9/PycqwbDqhF/o33Ufi7MbT0MYpetBDyMI/PXYZTL/toMZTNIkFWdw0ZoSeP3G2Btlahr/LLWXMkiwnHNvUHXs8ITeJhMKKIWRlWUHUFqszLc9+ykrV5xcb9FY6nZpk7pbusjfdMYOkoVQ01oR/5H8ssh3U6YUcKluvf2b2SnRkp2+33jmboZic+dRMzxp3OvCbGmbQ5K7M0IWH7fDO3Q5LFk3VWVvd+th+pHEZzNR0GIa0tsFF3GzX7pLhwcYJw/rMjWycwrS7ZLL1T4/lx1r7Zor2dEcv1pjlbrKmGTcrgjKxV/6uYda0eh3zkFasjeO3MF5CsYrp09FUFLW5l4e4/VSqPr/2d0l5c6kGvf2kJr8HxVrp+efl9WrxPA+GbL/ZipwDKzdqznddOWZOOqGW3lJ3FQyA5N9a+vth+a+W/ZXxOvEkU5h45plRQvGKyY46034qddpXBCb1VDfnIW+ao3bpjbPlux9LU/YF1jOZyjNzkh/JdklvbO2E9Mcb3xZT5E99vWYo3zUqV9n2U8IXBib1VDfnIW96Uk7UN86WvLYHbbX/xMfNBzLFzZx2vZxsaubY6JzU5CnOqt8ol1XDUDr6koylgwl9J2A+q2oT/mNZ2sl2UK+UMveMWdkIZNkXT00IwLxj29fpNEXhZDuo108LbrodpaB21MorElLaAAYS8E4vBGAgAAMBGAgCMBCAgQAMBGAgAAMBGAgCMBCAgQAMBGAgAAMJr3KiEs7kEXVC5Mdn4cs7UH1hHbf4XXjxcvkTIj8+C5e5agDAnAxM5VehXQAwXwOYbOuW9wWma9cz11QCGOEDrbNyrmmFNIVcG6lXAlNuo0v6WopbZ3krpHIvf2R+xVRXzgFMmwiHjIiEtE0WgPlUkrJ8YqLZSGh+xaQ/vggY3/DKNy3x3a+E55yrQl6WiVW4AEb4HNZZmY1AYfholpPmV6d0SW3HjCL33a+ec6/qjJeTbsImC8AIn8k6i/9JV/2E+lIsrhPmV7nAVElK1fji7Fjz5blfhe5V2Yt3f5Mdtb7oxm2yBDk0sAp9qgDMh1lnNRJOK55BVIVY1N2qlTC/yvWpOgRMYTuOgnruV6F7VWCKlWpgyLw04wuwQ5ssOTSwinyqAIzwUdZZ3Jsq5URVo44POvfniMyvnvepytJ4GwvK3a9C96pmZuslWsRxDD7aCWyyNKJTAys54VO1ADDCB1lncW+qlBOVuLD7m7WUML/K96k61JqtVlFQ3/0qcK/qZsZQps3JU/D0xbPJ6tPTNIZv5FOV9u4CMMJ7WWfNuTdV0omKuWlRYyjTsmLmV/k+VXnihle6HzRwv5oF7lWeKdbeLMkk/d7OmZq6Gdpk1ewdNbCaWJPQAmvPuwvACO9lneV5U6WcqMh2OpxQD8yE+VWuT1XuXJkaZBnXftDQ/Spwr/IS3gNmQ/uaqrFy5pFNlqCMqYGVS+IWWGnvLgDzMcpxojrqaIZ5g1oSnne/OmhclTKwyvWpAjDCu1tnPWsQdYJ91MtNuMabUmRcFf1sARkIeB9G+FTWWYcNok60j3q5CRc1rupx46pB+HUEN7C6BjCfTIcNot7Mp2pP6pNnXNWNUuYGVgDmk+mwQdQb+lTtt3y/qHFVaC4eGFgBGEjAO70QgIEADARgIAjAQAAGAjAQgIEADARgoLRkVZ8UUQ0A5jgVFmurr4ioCABznMSq2NDMAioCwBwnabKZDztoYQDMkbpWJFQCgBHezEhKyDB1evfcVdmy2YP59g8mswcHKuH9fYGEjOXKe/OuwXK31PnMS3vcbUz/l2Lj26fmTtbqfPVl75l8+weT2cPKx88JTHXF35fU+RJXpiVnJ759cu7E5fggMIEBFYD5QsBMyVyRyjp9VbyysztSdcLZiW+/Inc99ova+cAEBlQA5usAo5C1HP5uOsOjZK9S28IxBlc5niJbIwuY9OkA5n2ByV7+cxwwg6gRMT27uTEpJbeFfUOghMFVKnf+WigvUzpdLLsPTHB6YEAFYN4XmOzlP8cBYxFF3+zmXd45XXuOVM3k9gHLMW9oW6tIsdz5a6G8TJV3eso8QsgwoAIwH9oliUYncUYleQ2ktq7VhMhXyAwGvXPHb3OU5LbwjMEVjcBdml05M3fmWlKYeVDqCD89NKCKAxNmD8CcDxh//Wtg2+R9rKui90ciie7CpmHkcghMh66ZJ04vamE2f4uytqPmLIdbmCyDKy/htj4wZzu6ED+ROz+PDaJpjLr4lQ9ODw2oYsBE2QMw5wPGc3YKbZu8j0Mis7u9kAaGz1a8C0+vwYCsOsXa4zb4esHwTKIMet0Oj2GyDK5iDlPqhswSuQuOjZ8stso+duWj0wMDqggYP3vMlgjAnEU3rAY9Z6fQtonbTNFrXmU9TJlavOwBI3tuhU8znUxkHrYU2nv4wCjHz5JCg6tmCEzf3TKTGT93cfcpai5kJK985I8VGFDdBMCE2SvDgepMarIr6Tk7hbZN3GaqsKJHZJteLCW672+m/vR1ZbNO6WnrTujdXhq4y6CFkbdhl1RxYs9hnAPPYUKDK54wVc0ik3Isd2bMfUolq1Lyykf+WIEBVdNLJ8reRoQD1ZkkrZzJo+fsFNg2TZnNFHVssh1r4S535soJHT4M15+/zMnKME1q1mOZ1twhq+gxiObZHPajp7v8uUx8Oz1L8g2upgua8KRvWo/EHYix3LG9nvtUXzecTSM1WA9OfwwNqOhplh7LHiGPSzhQnUmtuRM4O/m2TdxmimwHdTqmGSpb34TSu5m3weXebNe+A6azHmvx77z/zmx75s2rtKfYd0lPye+S4tNq3+CKsIQt6rE6aCRyx/Z6eRwT1yrvze6C0yMDKnraOMjeZtKrmjYcqN5Gvm2TP/to0JtaasbGqaYddGTGR+SupBslAa83CJ/GV+pZ2ybPNVmQpm79Tf2tqtlPDk29JwIY4XP4Sh1l2ySv7UFb7T8R/W39rbRNZgCrWy0CGOHT2EkdYdtUm7BxwVr7mDwazrwGYD6JjrVtqnY6zY96CbhRwCuakIB3eiEAAwEYCAIwEICBAAwEYCAAAwEYCAIwEICBAAwEYCAAAwEYCAIwEICBAAwEYCAAA0EABgIwEICBAAwEYCAAA0EABgIwEICBAAwEYCAAA0EABgIwEICBAAwEYCAAA0EABgIwEICBAAwEYCAIwEAABgIwEICBAAwEYCAIwEAABgIwEICBAAwEYCAIwEAABgIwEICBAAwEYCAIwEAABgIwEICBAAwEARgIwEAABgIwEICBAAwEARgIwEAABgIwEICBAAwEARgIwEAABgIwEICBAAwEARgIwEAABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABgIwEICBIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABgIwEARgIAADARgIwEAABoIADARgoM8DjFxEhQGY41VuN1BhAOZ4lbotVBiAOaROPdxstIWSrqDCAMwhac1ws9VNfIQADICBPhiY8k0n3O7Wu/x/u4pKvzxgKk1FadXElwLTl5K86Gpjb2Iu7p2lYu715YHpd7q63pM8QkTp+BampLZbIRI3agLCLj2g67qmVqKd1b+4BBfRJdX7Lcnvkqp9vZUApqFHSjUOTf1Xq8+nUi36jO83BUYq+a2NpulFBl+p2dcL9DONTm0JDY3+w8joywMj69VwDKOpdXaFD7YwssxA+t3o08ZD5eMW9sim0lf/+kiJ/YbQr/E2qMcn51VdFLr/E5o9OnfHZP3LA6O2o0Gv1q70G6Uyvbr5wGgMi5quN8v1todIp1etNDT9t9/AiLqi9rvlclXVlVa/USx3daWu9ysdvdXo13EZvjowwU3PCClrtOvp65qcD4zEmiDajfVpwE7Fa1F6dLSiRN89lRWlqrHDtOlS+qquNXVd6ej9m77eEXEZLqWF8VTTrw9HIuvsmivdaI+SmjBlUUYhk8HKZQBT0lvXglgts7ZCbunPjUqvdaVQbAUjYLFY7+o1VO23miXR7qOv8yEs7Vmef9TWYJ1RgJWq91W8B/HtnvRK3jO2gnx9VDzFqHcpSKhWvN4AQQAGAjAQgIEADARgIAADQQAGAjAQgIEADARgIAADQQf1f82cTyhvW5IqAAAAAElFTkSuQmCC'),
      (a.id, 'ind_lease', 'demo', 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAAGQCAMAAACH26ouAAAAwFBMVEX////9/Pz5+Pf6+PL49/H39fD29PD08u3y8Ovw7uns6uXp5+Ll497h39rc2tXZ1tHV087QzcnMy8fJxcHEwLu/u7a6ubW4t7W4t7O6tbC1tbK1tK+2r6mtrKmspqGoopygn5ubmJSelIyRkI6Qi4eRhXyBgH1+eHKDcGRvb2x1Z11zYlZgYF5hVk1RUU9TTUhLSklgQzBGRkVDQ0JAQD9aPCg8PDs3NzYzMzIvLy4rKyomJiYkJCQhISEfHx8eHh5x9zp9AAAah0lEQVR42u2daXuiPANGbXFXXNF3+rihKMqUcmlr3TH//1+9SVhFUJy2ttX7fOioQIBwTALCPYl3AC4ggSoAEAZAGABhAIQBEAYACAMgDIAwAMIACAMgDAAQ5vfx3Ja6Mwjzdby83JQvs/RDKQ1hvqhyJ4N6NjG4rQYm0UaX9EWMHhKJdLX3fFstTDn9VH+BMF/B+Gl0W7LwHpZ+C4oQ5gsHMA3pCquZTCZXcnNW700m0WOYv5NTU+PPc5fCTEbvYum9Xvj6NXUTiYR0pb2iLUzi7z9OjT/PXQpTrryL+fd6EcJAmFgUq+/5xN98GcJAmOj+uTKaVCa2MPnnRC6R6EGYS+fpVmbtyn0IM0n0RomR9fopkShN6oMZhLl0nnpiVnm4vy5p1rvWNfTb75KeJ6PB8w0KMxv12u3u6NqXzm9MmBdai12fH7N2hi6SmNyeMJN0gvM4+b3CSNI3CzOrW5WYKNrKPOet97cnzOzR3tVE1mpjpMfHx+73CjN7eX6+qMHL5z9FmF69Lj31RmHrPi7hoJ4kpxITeb7wjPuSltq31yVNWOPy9y/bwZH9w0vYF+Nl0Gi0Ry9nhn0h1C4W5rnOHc5f+gMo38TByweEKdnb/FBuBy/rHpfgr6cXtlRpwLXhtThgpZw+dfitwoxYO/r+XqX/NOy9p8crZ+/rjMI75AerJr0R8WwyGgVq9d+F8Rc2yzqL9qJXFdIqde1NfJp9WBhezsxfAWEl+OqJfesStDGhFySsH8bZzj3d5lkS39dyhf2t2h/16OuBfV8ArTlaNUW3HhvOYqxuEsnBpwhzUNizu2g9elXHvngHu+rt22AwmEQL40x2p07G9LymXbOMnbkbE1WCV08je4GSU0MDxxx6SnEzwsysb0/FrWnn8i5rYEWfMDPmS7Y34i2u1eQ/OyOfwSeMYQKFlZ3tGcVa1TP7WZD3D+neqGF/1b0vQ/GEMPbkwFS7rTovjFdPf9lsT7OR2y6y38fTz7RtfEo/3IwwaatuZ90C3bmyrzGYubU+5oo8sa/tzKoF+yiyxqTK/uQ/JEzlsDDrrjinsRi8n1jV7Pn52XK3zYYSrLDyjN1bR1+M3/07MosUxpns7RZvEXiDZm/a6JQwXj1ZjeujN+jlTUyikLRa6NsQxv36sbaGN68N5xvGdlakNfHCDx1rggqz2aTLz7/zzLGedfxE54sYl0G73XbG00+8EZkdFNZgx3xkNylVdrYStaq2u73smIqP7CRvNunlDlqYd+ddxBjGN/IovbBqeB63eQlsfjZk5RWQixDGqye6oJhwLk6wVptuitNOPjRuRZie28064z36lR5I3adc4jT2oDTZ5iPhS4SZPbh9mr8r9AoLIkatil8MmATGPDaV4ybgRAvzHNgSPlB74WfFDV95gRLi1BNvY3ovNzPobfiHBay5eXix+gl+BcHb5YMKKHnC2B9c2qhlfHfBRSJOeo8+YY5X5StpEli2OvPdy3uyS3ImjwLCURH/PnrCjEKEOa6nEIrdv7d0llTzCfOctk8DrYrIdmeDPD+g+dGsV+LH7jEt1umtvqPSIxUm37ZrqvJ8qTD23fsz9rV+tNbhFtZlK30sPLGmYzaoZpgw4asaeC0Je/lUeuCbWKwd3I3cdkY+4cK4k63ONvGQzFecO1SfG7kHLky6+x4pjFNPD4/pQrkxeBm1q8Us26mHTOnsra6/soWxLxWM2OCMX1KY/R2NYt3USx8u6PYGF95iya9v1WgvP7EsGMUqLGzqwD19nhUiL8CzG9oT0Retz0w++WRT7Hq6IWFYnT+yEduED/GTf68kqcfgY5cbeVvFf8R5nEVeycvNTl7oy8Ucgs0yD6XMnd/Ta/2IlLe6nkTu71XW6f3m8lB9/uBzAAlxNBnwS4rBa6rP9MaCp3Tk1+D05F7FJ8aoMhmxvvDl3HXbe7jjbvLgPy+40kqfB1K5KFbP/Sx1lrZ/iDwLOV0++O34ksmS/2xskBj1eIdX+fQnm37hTwPPDX7Ck678xufWvN6tMYswohDx69+ZyVEXBIovuKeX3kjwMnt//6UP2FfEolgLk70oluvt6DHpmcmh9TSYzPAgG3jHk48AwgAIAwCEARAGQBgAYQCEARAGAAgDIAyAMADCgF8vjADABUAYAGEAhAEQBkAYAGEAgDAAwgAIAyAMgDAAwgAAYQCEARAGQBgAYQCEAQDCAAgDIAyAMADCAABhAIQBEOYD1PTaBXOr6qVLxF8dK/tM4XyWL9y6C2ohckW3Lswf0rpg7rfppUvEXx0r+0zhfJYv3LoLaiFyRRAGwkCYU0cw28r/NGEKrWyr8BFhxKH8rxuckYeFOxamKdarZ46gSJy+udBo/bMwwRU5ZV0ijFuGRETS+BdhnBIM+Z+F6Wvd0h0Ls+7pY/dNkn1tI49gWjXJ2n1Xli4T5mBFvrL4wslWIY4wh2UcC3NUzNHWOSVMG+WM9YnUyx4us9yd3hFFFYvokuzOhzRPHH6VjOui+274+pEuySuLL8xX/PExzFExkVun7wy7n+2QZeOsMPmS6Golm/PmXQsjq6e7pJz6qrGvVHarfWwM41uRr6zjhXPdYbcYcRjsMpxtsmbJtIZyKe4YxiqhmnFdmJK9mjyz6Roh5kLrcsfKhXse9CY7+oZ/o3JN0f4T3G+DLMk8LQglIp89JCUSoBRcEV+Fvyy+sPWpRXdNl9s2Qw6Du7HuNvFZOiu6gCm7hQu5TlcMFyZkd1VTXRLtTDW1hqo23ZEtk62gaF1HbWdFdyNMRt/rOmHf1Srp23/c/Zbe6nzIqyfHbNibM1m1lp1mwpoaVxh3RXwV/rL4wtanQnucpeuaNnK19evxYfA21t0mNotKFu186XWTcoopU4F2vTBhwnbXMAR1s+tH1ZC9m4zGmhi0RVrQ3Rpawzh3RXcjjGL+oZ14I1yYIq+XMhkLCmG1NiaarO9Xgn+qMDdidUnuimw1vLKaPmHGpDQmY9ZbGBu7bF/h3sZ62/Q2VYhR4Iu6NurmsLPc5UO2Lmx3taWgvyqbXMSG27vJF9706VwyGYrTLS/dW1FgS29XGH2Rz8m8Qe6yv122y+5+J8mcHrvk27a/XmWt3p6s3WsQ1tT8Vo8ljLuirtX8e2VV2RGxPs3Rfoawk5iSxr/LrGxf4d7Getv0tjYNuhkF1Vwn7WKyG7rskLBvfnDrjnaX/ukRjahi5B5Yu0k3SSc6HzX1SYcuyGT1VhTc0tsVpmPS9nVFDFXfkr0x3W78p9UFQt50TZvTWZaarhtbsuh7X0Q+VV+w+oohjLOiOV2P3td8ZWWWpv5qfbogW2Jqmv5G590br7xsX+HuxnrbpG0I0TV9yqZMNb4TxhuZN6sG2fECD7cuuLtsdp0OmApV0o04S7IqQX+lI+OU1etut7pBDK2ruSsyglt6w4NesdMpZ7Xtwpz3jd1+/p9/vzvEYOPPtaEa6z3ZL7Wm/2TCmrpm1RjnLMla0Y7Q9Wx1019WbWru+adkoxb0HR2/LvVOhb7gZfsLdzbW3SYbc23IJW2z5TtBtjq1iBirrXa8dYHd5bPPDbLZr8UIYazd3ExV96qjpK9Nsiequ6KQLb3L2xuKy8iO/ezU7yX/R65fMr80VEoX7aaxyV6wopsUJtfK+85seS0uyImr56enXrKen7TPp3ZTdK/WZcZEFe79fpgSqa577rvKH8Ug2ygjTk+9ZD0/aZ/P7WaP/5JRkTrDOdHTuIEqcK2OLFXx36bediXQD+lwPSVAmAMarXLyX6fediU0Ow0Rt2gCAff0AggDIAyAMABAGABhAIQBEAZAGABhwM1SGbYhDIjPotuBMCA2yUWtAmFAbDKv/P5uCAPikaqmBAjz44kRPXWtouItetcJVD+AGE/hX6uoeIvedaAQhIEwEAbCQBgIA75BmHN5U2zR8w8wQZivIlnv/scfJcz15dRl9R9vUUbxj6JqY1Wu/qswvsAptuj5h6kgzBdRYs/Zr/jZ5x9zHLzm0TfmeiOq/k8uKgTyoswleyr8NawoN98qXuBUqAWpcQfCXAXN7GSrK4O/VqxAOi8LakifeTfNSkT9hywqFPXNtGJFQfV8V/ClSma422yMckhRVr5VQ4gbOOUPyCo3actWoTECWTK+0wSq6wsj54S0lS+X2/Cj70X7qETLr5xcqRBhjhZNve3GG92OgtorB02EmrNCgnxF+fKtprEDp/wBWSrJs6JzjjB3mEB1RTJFerDFKdlqzvhR36YOhMkaZG0dmUCgU9SiLaIIxhuPgurTKKisL6ODhhQVd7JTFE+58udbrYS4gVOBgCz2sKxIQ2O0O02guiKqyUYOqT/admkFnmYXpHOQBSU06HPLeeE40ClqUZUU+nvZjYIqu+uav7GHXLV1yS6Kp1z5860if1A8Cpw6DMhSaIFUHoms8veZQHVFpq/2iz6htyT1m91XYtKUKF8WlGGuaQaQPtaCgU4Ri9L5DJZDZWdO7QtedDlvJgrLzZtVFEu5mvryrabFqLOko8Cpw4AsU5/vFzttSZ/T1/W7TKC6HsbSOgLl+Z6OT2nvv1XLhqn7sqDWtMeRjO3yKNApYlE3qtOKgvIyW6rEOgkuv9pFsZQrJ99qt9TbycjT6uPAKS8ga62WafiVKq3JTlFXBAlUX4tM9Ha9reg7s8/jeRq5Dy86JhVjWbH+swp/FFTxssCfC3K1UhXajGVrhYuiriDMv6FsWWuw1qohMVDh/9fAmUVpD9XIzY2w7m9jR5BdGEsSGjgl4H6YbyKvqLKcDI2BCv+/Bs4sKhS38+rba8js9e1aqRWL0viCliY0cArCfO9VGF1efeqiHdryhEan1Qw+uNnIn5W6BWFug2K7GjGl0Oh06rlPS92CMEDAg2wAwgAIAyAMABAGQBgAYQCEARAGQBgAIAyAMADCAAgDIAy4Hc7mULEIKiRQ/VCS3betEXrzdVmZkqXvfV42VptXxb6Pqve6W2vF4EvhU0I/2KOPeGrghyJqpYIWdq9nit2W6RdmbD2G8pazHshmzPOHLyHMfaDMw4SZq7WFXxh1LBVzf1b8vl9xt+1kSwZ7xs33EsLcB9I6akxxIIxgP5ym8mdSFPq3sF0evAyjKdarEOam6Kwinx8LEabJH4TUrGevdVLwvxRCnn9c9/QxhLmlQe/wrSTEFyZlLLL8MZK0FdlR9b+8IIcKwvxWKnzIarUO7XE/f1qYlLbhXkxNa1hD6v6X4cjq6RyqowQqCPNLUNlpUemUMFndHu6cbGEOGrCOvtmF5VCdSKCCML+lrTFqshXuEyFMYbqqOKFUJ8YwPjL6XtdJMSSH6kQCFYT5JYNflhezmkYLU1osy+6T+/HOkhTzDy23EZJDdSKBikdQQZifPvilIS36H/kwTupAmNp64T4tLZrWxRf14OUx+iKfc1qtwxyq6AQqK4IKwgg/PXFmrps05azsf6CeMXVOfJzMIX74h/wlz0TzvTw6S+qYLN6VGGowh2oamUDVtzKzIMwPR6dDiqIkpYQwYZKbRUAYQX5zf0DyvTw6rRY7nXJW2y6COVSRCVRbzYqggjA/HMM8MbFKOl+wSiRQ3awwyjQp4H4YEFsYATdQAQgDPoLUgjBAwD29AMIAAGEAhAEQBkAYAGEAgDAAwgAIAyAMgDAAwgAAYQCEEZAZ9fkggeprOYiG8sVB+SKkRG1lLtXcv67h7OPzQlhq1aXJVAKerb4O/mgoXxyUL0JKXFlPjGS+WJiD1KqLk6kgzLVacC8ayh8H5YuQGhO9ki3rpP/VwvhSqy5PpoIwwnUfjVaPH3S2j96ryVqf7O71q7sk3+O1J5+5lsrVOoT5Xng0VDBKISCMmf0MYZKtQgxhTiZTTYdjHcJ8K1Y0VDCsxT56GtHLGdolkVL8AqVyrRYuTJY0YwgTM5kq15dTEOYbfLGioYJxUPbRK7HnlslaJ5WDduPkf10/VzQ9VpcUSJByhDmZTCXKLeeU7Y85hjBXx4mGimhhhLK23hoVlsbiY0sPdF600596PpfKPa/PKSxl5+gVFK3LZ26KYQlSZ1sYny9rqm/XPZtqIoHqyrjRUBFjGPt6zW6bOk75qNrpT3vF/VBfe/Nl907IWJ6mLfBznio/2womSJ0fw/jD0bqSwQN/mSgsGQYJVNfEi4aKOEuyGJLjgWaedwi62afpT1l/l+AZ5YS1yGQoTrd5RxhfgtT40rMkfcUGXVt7hTr3GAlUV8MXDRWMg7KPXkqv54rDveldbW8adhe02IpO+pObJaRvnRmLynaRs49en2Z+dNmIpMsiYvwJUv0wYU4lUxlvvCuytjq7YGEiSKASrpgF5CX9+OOgvESglPXKd2DHzhn2lKzerPSnvdt31Gg4lNKTh9p8TwzRGfSWtlvdIIZubMneMHwJUmYpNLXqRDKVZtaF+pJ1fP1m95WYO91AAtX3COOPg/IdvYaxWeuSf5m1/WK13tjpT76mgI6R+WmVodZ9Z0mSvjbJnuznfWPnT5CSQ1OrTiVTVbdkS5YsK5FlT6llw0QC1Q9H2zjZUnwAUmgF05+K5VLIr0DGJhuZIHUJoqw0+cBabDZySKD6BShWFmrGMCvxF8qMw7MyBdwPc/sn4quN2mr234gSc4GK1BnOiZ6GMHdKmQ83Vr2487PZF/2UAGHu9+pNu1OLL0Cz0xAF3KIJBNzTCyAMABAGQBgAYQCEARAGQBgAIAyAMADCAAgDIAz45SQrspaDMECI++zdVO2kIIzwQwOj6i072ylsclFvfWw19YuXT9ezRUERIcwP4PiO+5z8ym/H5Y+ohdyQX459q2bYapzShctys4SloNchzA8UpqxuyJuc+yJhvNKFmHcHF/9j/+jCNgthfqIwKjGdZ5K+QBhf6fFQp22Td2jixljnIcw3EMxzOjSiZD29eJkwhUYrnjD+0i8it1o1lTpOq7+DYJ7ToRFl3zP4MYVJqyZZnzrYrTyN/ODllIl+4damutqQdWAFEddhvhs7zilghEbkeMK4aVAqGddPHc4Sqa57djm+0oXYT/bqUeFTEOYaeHlOLVM7NiL3akrxWhg7DSq71eKPYWjpjcDnJ5sO1oepRDoOn8p1h90ihLmGL748pyF7BDZohLhel+J1SVYaVCnYaPgjqXIL2Q6hsssR15vD6DxfslUg2krgT3MPhZodxqr40vK67Pn/bTNiKQjzifjznHJrf7aK9GaNKiXTzlc+J4yVBpXj7VRZDY2kSu7GdqaQU45kHg9jrGSrYLQVI7PajKd2BpEdPtUeZ5NjMm3kauvXiKUgzCdykOekb3xGFJ1YZZ3oScHOdgoTpupkx1hpUGOiyfp+JYRHUmn2/E2nHN1MhydbBaKtulPW5VT1uWaqh6srjck4w9MhjpeCMJ+NP88pywKgXCOSZM7T4jNvVvwLz3byC1PXrcjCht1AWWlQQn5KO7mh1w15kVQVjT6QnaMhVC2rc7FK3wihyVbBaCvd8U60GzRrdTTMas6bnJJGmNDBQCwI88m4eU48zkn1GVGg/wOBrmk000k1yFTXebaTXxhtl7GHPpIvDYpmTC36/ku31Q2PpFK0OY0tkslyvt1QmzJL+qlVuhCSbLUca4Foq83YDRupeaub0jArYmqaTq2m2VZqcCkI89m4eU606zfHaZ8RHWJYUVJqJj9eESvbyS+MvrL/8woWFOSkQe2XWjMZOLVxIqmG9HuvrMn8P/7r49TUrdJDk61WgWirrPOqzIcubvjURi3oO7rpS71T0bevx4FYEObTT6utPCca53TwtSwuN2d+4hkSJSVkuwveI/nSoEIIj6Q6k2x1GG21tQbHlcW2cnp1x4FYEOYKSIuz19ToYGU9p4F1sa691SsfTLbS2fWgQn+zbQi44+6HUfmjGGR73oNsT9PHnXg/NRvqB5OtyhtzvtiTRQ23aP68Myf6H12p4k9Ltipr81e9mxEgzI+j0Sonhd+QbAVhgICnBgCEARAGQBgAIAyAMADCAAgDIAyAMABAGABhAIQBEAZAGABhAIAwAMIACAMgDIAwAEAYAGEAhAEQBkAYAGEAgDAAwgAIAyAMgDAAwgAAYQCEARAGQBgAYQCEAQDCAAgDIAyAMADCAABhAIQBEAZAGABhAIQBAMIACAMgDIAwAMIACAMAhAEQBkAYAGEAhAEQBlUAIAyAMADCAAgDIAwAEAZAGABhAIQBEAZAGAAgDIAwAMIACAMgDIAwAEAYAGEAhAEQBkAYACAMgDAAwgAIAyAMgDAAQBgAYQCEARAGQBgAYQCAMADCAAgDIAyAMADCAABhAIQBEAZAGABhAIAwAMIACAMgDIAwAMIAAGEAhAEQBkAYAGEAhAEAwgAIAyAMgDAAwgAIAwCEARAGQBgAYQCEAQDCgK8XJp9DhUGY+BRbVVQYhIlPoVNDhUGYU3Qq7stqSygM66gwCHOKntcH1ToHbwGEgTDgm4UpNjvu627Fet0qodJvTxixWq/XSslLhelnDn1RGpXguDmfPFrqaCbw64TpdzpDRc5YhiQz8VuYQrNVSzlvmo0DCbvUlSEttil6H5b+wyG4iS6potQzdpdU6iv1A2EqQ49A41BV/tT7EvcrLwj/0VfZgt3ayPKQfpTKFKrKMEvfd2nTUhMqMv0HI6NfL0xeEd0xjNyoKPQKb/1UC5NnWlT+q/bpYg0+VmGXbESl8Z9iLZLsV4U+H70UZH5yXlJSQvd/QpUK08HJ+q8XptHyBr1yS1SqhWK3eUIYmU0oDZVqsdyyFOnIoliRlf/sBialSJLSFYulhiLVlWqu2BlKZUURO8NapV/GYfjtwjhfemZIsacMh/2hnI8WJjtkPzKVlf5Q6bdEq0WRFUWWvN+eilJd7NJy2EmSpDSHMu2ZpM6w31SUThKH4bcL02z535WV9OlC8kM20JW63ieSkjm35gy1KZ/CEbgJYQpKLS0kxSLrTAp15dyoNK1IuVzNmS2ZL3cVXG25r7Okkqz0FT6EpefB5w9+pU97G+eXycawL+VRs/d2pTdTyLGxRS6fjlVOzrsil82gWnF7AwAQBkAYAGEAhAEQBkAYACAMgDAAwgAIAyAMgDAAnOT/c5103Hsg4Q4AAAAASUVORK5CYII='),
      (a.id, 'ind_machines', 'demo', 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAAGQCAMAAACH26ouAAAAwFBMVEX////9/f34+Pj6+PL39vH19PDz8ezw7unt6+fq6eTl5ODi4Nze3Nja2NTX1dHS0c3OzcnLysbGxcHBwL69vLi5uLW4t7W4t7O3trO2tLC1tK+0tLSwr6yrqqinpqSko6CfnpuYl5WRkI6MjIuJiIaDgoB7enh0dHJtbWtoZ2dmZWRjY2JdXVtZWFdTU1JPT01NTUxKSklGRkVDQ0I/Pz88PDw8PDs4ODczMzIvLy4rKyomJiYkJCQhISEfHx8eHh6TRzrkAAATyklEQVR42u2cZ0PizAJGdYPB0Jvvul5aEqoEkKIQEOf//6s7aSQ0AcWt53yQkEyKzGFKgOfqGeAMrngJAGEAYQBhAGEAYQAQBhAGEAYQBhAGEAYAYQBhAGEAYQBhAGHgIow7EmehKx/HHy/zPJDbrK85P8L8RjxeSZyFa/nY/XiZ56rcVvya8yMMwiAMwiAMwiAMIAycSCfbbGfbCAMn0rrSG1cNhAG6JIT5lcLUCoXS/+qNx8nlhJkOrP4IYf44Js10Ol04VmHpK49v6Up7fAlh+oVvzgFu9elXCDPQS6VKY4gwl2bayDh1chX35ZG8L4zD9ehjwkzaptny25SJGhyttrvxdGEmrUoxX6y0phvXPy5fexdamSLMRRnng4ZjulFPuxXWbrWaeiXvVfPHhOnEnT1ihvvEWutX2N147NgdXddbbkOS8A+SW3t+HVl7dXWHMBel4FRSznll+0eE8QWrXn9YGOubX4muFNN1k9Xc3Xjs2C25NuEs3K3NMEJhxo4var1ZdNYPEObCY1t1OL2RD42gItyXuOW9Vb0Ka677L9NtBq6y0+ftMoeEqTjFQzlzzp8b17dROmrI1sYjxx4G1jrXo0/+C/zxrt95mpdbB4cvDGE+humMOlumI8zto3yF3TosjrwFd1hzKxdSsvWZjKxW5dbtvGRV6uPnSJntejHL5XJwK/B/zi4N2V+M6s5Jps8pp5+QtTlq+G1KrjfZ2Xj42L65zo6Wv1mf9Hx/vOt3BmWJ8bBTdf6t6yHCXJB2ZCR7lbjaxG0Yslsrr+4GmvsQKbNVqaNvkZ4g41vhPcQqleurQ2xvzB4WZhR0oqmrI5QYw1x0jlTwh7xrYW7COnM7qeaWRPJbTd1voTCNPZXacQ4TzG6vN4TZItWufTtc143DwgRNynN7xz9t41lxjDCXpaNXaqbVL964wlwnu81b76W+8WakU7dhl1tit9n/zL43ei3Fr+8iZfYJ493fe3IaqG/fHGGutbJ3pKtM9Vbu8S3xn9NtjfScer2z8eCxfcpOD+aNwu4SsYg0WmNSTzkSXn+7SRbqFvdh/gCGTgXmO8OnduVm3VJ4d1r0as18PHBD5b2N25Mk5wyVcFenVUlxp/ePpRTtFK71i987cqf28afged8d6uoI8wtoZTuNbO+zR5kUQ11yj5e8vn6vbf7nNlsx2U/1+/1uq55ze6TEBGF+AcZVq37V+fxxLL2YTqZy5cbgstcXzuh6/vgmGD4P+PARDgqTMCbPUWH85wgDWyRSmULZDPrMZDKVLfxXbw74egPwy0dAGEAYQBgAhAGEAYQBhAGEAYQBQBhAGEAY+COEUQDOAGEAYQBhAGEAYQBhABAGEAYQBhAGEAYQBgBhAGEAYQBhAGEAYQAQBhAGEAYQBhAGAGEAYQBh/nSSjw/HC6Vftwr9WKUPl8495jeeN5t7Vu5lt2T5UUOYD6DVB/PF2Ii7T2rjV7udcBczxkjM/Zpvz1ezZvzcI2eEcbxQb7x1MmXUO1z6u9jUa/K0Z+Vedks2RBJhPkBbuEwcH0x3cXorF2POkleHybm7+kn9AmGyorp5MkWpiCzC/MY0W8VE/Ptc1KUZr8uymu6LhlOH00buxavDlrAyaqYn9HCn+EP8MsK0l/HNk8ljL1v7SqbM2rrGtQf1IXFcmFgjgzBfRFnIPl4XplMby5m/0q/D8cqpVPV1FBl5vNMKnCWMbSmbJ5NY9r6Sw3ooTFEkRemgMOqDVkq5C6PCOcKk7hDmZO6ErI6ucN+RlkjsFWa12yfFHhKfEibrtmZbwhh7bRyVMuppXVJC5Od1txm8vUudIUzNRphTiQ1epA0DceN1QbmNOmyLXkZN94RIhV2SXo+572Hvjf5hYcruEGZLmLIo7ylqvQ5vzxvDpETWrp0qjJZOqnRJJ/vSWThv6tHKG9WIwkYdphfOmNTuR9/431fts7ukmD6cWpuC1cX3XWFKznhqd0athjUeb43b74xh7oxy7NRBb97Q3f+2I8TqpVPVEOYE1J7ttikHWhgl3bWXg+ww0sI4/YZT9XFvsBCv1LIHhYlXqt5b2RSL0WqVXe/lCnN/TJi8UXavyt3Jr/GBmIvpzSFhnLlec72L/3e/MJmh816wpF7lRrPz9CqWTYQ5SuJp7lX3gTGM32a/LqNv2/hi4I5BnKlTRs673/QDwjgbX2tey9XV5iIf7HVal1R3pvxacCqvxpOiJ63OHxAm8Top9t4y66vz/u4VprR8NRNaSwSj3ZIthghzjPTzzL+3emCWFLy+mzfULMefnFsZvZVenr2quyNaw91oyo3OrR11KGy3fG7dhGT2DXrNSN+XXk1/NEQr2OnOrfG0XGG4wkyHu8Lk5Gk9V3P+2fS9JRvi+3JeiLZoxmqhxxHmCHn7OeggUqvwPkykDmNWIZ4031YbN+DVmdMOVEVHLjqNjSnW9zwKvZzftXT9jQ1R81aIF6exqIb1Nj8yra6Iipx7LzR/p5yrtDJZ6vZcCnq77O0Ko61mhRvXMffqvL97SjaEbctrvinPvTGbHNb3Ewx6j9Lz7vQ6levf6X12R35Db/XIvw8rovft9LvqSKxe+6OleBsMJ2J6lx2+rV/sjt/YNIQYjr2N4tXSO/2V3RZ2r/W4XKzHli33xl3kZJs37uoT0c7dr8RLz3J3Umcry+h0prLsrNO1XlwRQw06k5j3X8zEVG6WV9fXH91r3C6pdzpjIcadbt8Z0c97vd5YvDVjzJLOE0apTV7tjlfzkTos9Re2VYzsI4cly2ZmuHqb1gdyoGg5L3pYy1bwicJivXEwX3aE3U4qxcFyJnuZyDinui1M5KOBspg7btiDxau/U360spwVrb79Jh/dKg41WLr/hHLfs52jreTVLXsr9xq3S/b9//ptMWqmjZmQ4/Fmlmn1V5G8K2309dqPWj7a1hsxRa3O/KGBdl8rHD7U43jnDl04VrLkRCZXrZz6sacq/Ll+rH/KnWiFrzf8HmhjYU/lm7p2YPvGHdjUe19vGKzOO/PM7ZKUhCXaJ96NRpjf4r5OrdNvH24XNu7AvsvwTGEaol+7r3WWoh2LtjslhPlHOFcY9dEbCv1Q+MbdP0nx4dw9kj+q92mFr2iCwnd6AWEAYQAQBhAGEAYQBhAGEAYAYQBh/gmKzQLCwMkkp5USwsDJpMbpNMLAyaTndgth/jpOCoE6mWYz+ptnr6F5LO09y8ETn55NhTCXoeB8d235VA0WHbRTg34+h/srxbUxNe9HjPW9Zzl44tOjhhDmgsJIzF8sTOzZQpg/QxjZqCcMsVS9xXf5QmGUuvM7aYT5M4RxfvGV+wnC3KUK2UPCxO32lwrzXvAUwvymwtg1q31IGKWx1C4izPeNxKlM8YTgKYQ5u0t6kz9+DsYwo40CxXQu/369HUl1OrFLkvkdppfdED2Ln4F1jjDLSrSAOT7nEhHmI4PeTWGmRufxfWGOpDptUG8eFEbpzNWi8xvsjbM8uBlY53ZJD23tQ5eIMKdOq2th7xSSroW/Pk3Mgvd+JPDJW9xOdUqJLVLBQcrW4lXZTItS4kanGgTN1GpOJMdm/TecXzR6q7R10XXc1QFhilsxahuXuD9IC2HOGsMo+4R5tMOfoqpvTb9mIoFPYcZUNNXpkDCq9db1Yq+yYVpUfOo1b+5AatJbqNv1H3ciW91V2oss6obahHFXW8Ikin4jsugH6kwKW5d4IEgLYT4vTLTPqDvJK3de2s868Cm3FuadVKc1xupeJnuUlI20qJpopobLWz+ayE0T2WowrIW/qiYayaelthF3tZU41RT+J1Lj6Tqc1VyfXkzVw0FaCPN5YaxlMNxNmMuXuJ8MFQl88haPpDqt6b3cxuvbaVGGTLiq+HmeJTHTdoRRZzN/lS5jqtw+K4y72k6c6i79hVEgTMyzxL3EjtNRbQdpIcwnhPEJNMktZRBUrd7oTt/EIOVW3sqNo/IDn7zFzpFUp3AgsXJSoES/FU2Lyq6WVt+JK9SN9srObg2t3Qyshr8qvVz2B6Lf7QdxV/2dxKmeHeTSBxlpmgxb7HW9S5Td33i8HaSFMJcTRkl33IwnexB8u0kmQ72FgU/e4rFUp5BkuZxWu8vnaFqUUrTslXNGS6x6ye25mBxurNo3wSq3qEykCuKudhOnWivNz32srNPz+vY6eCohI0K2g7QQ5rIkMqnbrz5HX34uocTS2t4MrM21/YX6XtxVSXSckVRlOVWDyd1iZ2i1GaSFMF+NG/XkxUt9MPVpI5tKUdtH7zCfXrQllpOBLWb+EKU4EzWFz5J+LW7Ukxcv9cHUpzCbKlssN6bCOuUurF/05kixYnf6YrkTtux3YyiWdQVh/iIGcjjxoscuXHS9w7yZVBDmb+KuUkpdvqg/nvmR5usNoPCdXkAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAY+Gqc0KjPZEY1m++FU30ukgphLkqyPV/NmnHl87Ewn4mB2PpJ9tahPhcYgzAX9WXu/gjlSf1aYRIPMYT5K2gJK6NmekL/WmFKIo4wfwXjlVOT6utIOSFe6nfukrRSGWF+ojCrdZ80f1UOxUt9WJhbo1P7UmFuWithI8xPoC16GVX+qD3Me9kQZhM/OupsYeLPcpjUvJwwwXWE19MUrUIKYX4C6YX7Q+u+yJ4QL+VHR50tTEW0UoO31MHMuv3CxPTh1CrtbWGC6/juP6rLDmOYn2VM114OZGzC/vfnZryUHx0VjhvW6VHvC1OXe+kbezqZdVpyO7hqnSPlHsqUP7dfrbJ7u6TgOgzvMS3qCPMz0V6X+/qa7XgpPzpKcUOgipH0qIPCFMyiG/8xa85FYUej3GZwVZgj5R6qKbra3E2d2BUmuI64EwwjH9yWJtNEmJ9EQ/SUI/FS9TA6yguBakTSo9zQqEiNJh+8fIbqm3hzJi/l0XS804Zpq1YYXOXO0tY5Um4qljoUtufpViRV9Dosz/SW6NSttznCfDkxqxBPmm+r/LF4qYcwOsoLgWqH6VFeaFSkRjtegIcyXqae7JR3g3CynqoP/fHSbJlcB1fZ8WiOlJuK5aSdvWjKbiRV5DrUmXBn07dPciDW0BDm64Xx4oYi9+0is6RIvNRCC6OjvBCoZpAe1al23NCoSI2OR+uWK72cdTvdwfLtXlkHBPlT+JGYtYPgKjHtdcMcKScV66m/stvC7rU625FUwXW4j6vXnt4ZLMXsYBwfwlyUUn9hW0VlrzCReKkfkegob+JTXqdHtbzQqIgwA9t/s/dEXOZcirfFoBTJ8QzOZC/mfnBVq2WLaI6UTMUSdjupFAfL2U4kVXAd8nHZzAxXvdWscxdj0PvbEYmOSszs22h61M48+qVeLJRqXWHtbuz4w4+caJ+RI7XnOuRjnI8Gfks246XCEKiD6VE17zNNu7GnRv2psDpYZXaPrPB9mL+BMF4qDIF6Pz0qVmua7ezefkKbL5rlkj5xg72jR0YY5S8NmHJDoI6kR7Wt+vzAprSzq5jXFL5x90+Mkv0QqLPTo6LKlMu5mIIwoPCdXkAYQBgAhAGEAYQBhAGEAYQBQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAYQBQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAYQBQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYQBgAhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYAIQBhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEAYQBhAGEAYQBhAFAGEAYQBhAGEAYAIQBhAGEAYQBhAGEAUAYQBhAGEAYQBhAGACEgV8ijBbnBUOY00mUs7xgCHNGA1PJ84IhzHtEmpTcg6KZBV4whHmPWm69mK9sPAWEQRj4xcIk7irr5WrWW35I8aL/fcIkc4VCPn22MPWbTV+M0va0SruN7exVYu71xwujlyumUVd9Q25Ob2ESpYf8Wom7UnRTqio3mKZZLyUjK++pgr+iS8oYBdXvklK6OzkKhcmaIVuNQ864z9eLrl+3inIvhVE136R6zZSrYmoiZ5jy0ImqbFrySrYuHxgZ/fHCaEZqPYaplzKGvMNbeK+F0RwtsvdZXe5Wcscqzi2blFG6N3yl9Jyipz1zXP9SRkyp/qfkpDAVJut/vDClh3DQWysn9ayWqN69I0zd0SJtGrlE5sFrdcr1VDJbM+79BiZmFEtGNZlIlYxiwcjeJipmMWPoybKZz+oZquFPF6ZcCIVJ1Aw58DDr2mFhVDPudmO6aeplr23S63KnYvjZU6JYSFX9zUWjZNZlz1Qsm/qdYZZjVMPf0sJ4pI2b9w+imU6dF6vhmqKuHjuzKm3ScOXvECZh5KUjKWc6E9MKxrFR6Y1RjMfzwXAldpupGmle2n9qlpSqGbocYsi2xjRrxys/63RGgVYlUy/e8sr+a3d6Ve/LL3Ht5qTjxMPeRVV5Wfl6AwDCAMIAwgDCAMIAwgAgDCAMIAwgDCAMIAzAu/wfAdGoI8MdOUcAAAAASUVORK5CYII=')) x(app, kind, src, mime, data);
    f := _un_new_file('endorse', m1.id, a.id, 'inspection', a.amount, _un_insp_fee(a.amount), 'آلياً من طلب القرض ' || a.code, null, eng);
    insert into union_log(file_id, member_id, actor_name, actor_title, action) values (f.id, m1.id, 'نادية صلاح الخفاجي', 'موظف قسم العضوية والتسجيل — اتحاد الصناعات', 'تدقيق المستندات وإحالة للكشف الموقعي — م. أحمد فاضل العزاوي');
    insert into application_events(application_id, stage, action, note, actor_name, actor_role) values (a.id, 3, 'إحالة آلية إلى اتحاد الصناعات العراقي لطلب التأييد الصناعي', f.code, 'النظام', 'system');
  end if;

  -- ورشة بلا حساب على المنصة: معاملة انتماء بانتظار قرار الأمين العام (كشف وتوصية منجزان)
  insert into union_members(org_id, owner_name, national_id, phone, factory_name, category, governorate, city, address, trade_name_no, dev_license_no, dev_license_kind, capital, workers, products, capacity)
  values (o, 'كاظم جبار الموسوي', '197911030044', '07801112233', 'ورشة النور للصناعات المعدنية', 'metal', 'بغداد', 'الشيخ عمر', 'شارع الصناعة — محلة 135',
    'TN-BGD-5120', 'IDD-2025-1104', 'under', 90000000, 7, 'أبواب وشبابيك حديدية وهياكل معدنية خفيفة', '1,200 قطعة شهرياً') returning * into m2;
  insert into union_files(code, org_id, kind, member_id, status, engineer_id, engineer_name, fee, fee_paid_at, fee_ref, origin, due_at, created_by_name, inspection, committee)
  values (_vet_seq('UF', 'union_files', 'code'), o, 'membership', m2.id, 'signing', eng, 'م. أحمد فاضل العزاوي', 100000, now() - interval '6 days', 'RCPT-IFI-2231',
    'حضورياً — مقر الاتحاد', now() + interval '1 day', 'نادية صلاح الخفاجي',
    jsonb_build_object('gps', jsonb_build_object('lat', 33.3612, 'lng', 44.3870, 'acc', 18), 'photos', '[]'::jsonb, 'site_state', 'operating', 'result', 'ok',
      'note', 'الورشة قائمة وتعمل بسبعة عمال، المكائن: مكينة قص هيدروليك، لحام قوسي (3)، مثقب عمودي، ضاغطة هواء', 'assessed_value', 85000000, 'workers', 7,
      'capacity', '1,200 قطعة شهرياً', 'checks', '["المعمل قائم في العنوان المذكور","المكائن مطابقة للإجازة","الاسم التجاري مسجل لدى الغرفة"]'::jsonb,
      'by', 'م. أحمد فاضل العزاوي', 'at', now() - interval '3 days'),
    jsonb_build_object('rec', 'approve', 'note', 'مستوفٍ لشروط الانتماء — صنف الصناعات المعدنية والهندسية', 'by', cmt, 'at', now() - interval '1 day'))
  returning * into f;
  insert into union_log(file_id, member_id, actor_name, actor_title, action, note, created_at) values
    (f.id, m2.id, 'نادية صلاح الخفاجي', 'موظف قسم العضوية والتسجيل — اتحاد الصناعات', 'فتح معاملة: انتماء وهوية صناعية', 'حضورياً — مقر الاتحاد', now() - interval '6 days'),
    (f.id, m2.id, 'نادية صلاح الخفاجي', 'موظف قسم العضوية والتسجيل — اتحاد الصناعات', 'تدقيق المستندات وإحالة للكشف الموقعي — م. أحمد فاضل العزاوي', null, now() - interval '5 days'),
    (f.id, m2.id, 'م. أحمد فاضل العزاوي', 'مهندس الكشف الصناعي — اتحاد الصناعات', 'الكشف الموقعي بالـGPS — مطابق', 'القيمة المقدّرة 85,000,000 د.ع', now() - interval '3 days'),
    (f.id, m2.id, cmt, 'عضو لجنة الصنف الصناعي — اتحاد الصناعات', 'توصية لجنة الصنف: التأييد', 'مستوفٍ لشروط الانتماء', now() - interval '1 day');

  -- معمل غذائي: معاملة انتماء واردة لقسم التسجيل
  insert into union_members(org_id, owner_name, national_id, phone, factory_name, category, governorate, city, address, trade_name_no, dev_license_no, dev_license_kind, workers, products, capacity)
  values (o, 'زينب عادل الحسيني', '198806150071', '07709988776', 'معمل الواحة لتعبئة التمور', 'food', 'كربلاء', 'الحسينية', 'طريق الحسينية — قرب البساتين',
    'TN-KRB-0907', 'IDD-2024-0712', 'complete', 12, 'تمور معبأة ودبس', '300 طن سنوياً') returning * into m3;
  perform _un_new_file('membership', m3.id, null, 'new', null, 100000, 'حضورياً — غرفة صناعة كربلاء', null, null);
  update union_files set fee_paid_at = now(), fee_ref = 'RCPT-KRB-0412' where member_id = m3.id;

  -- عضو بهوية منتهية — للتجديد
  insert into union_members(code, org_id, owner_name, national_id, factory_name, category, governorate, city, trade_name_no, dev_license_no, dev_license_kind, workers, products,
    status, joined_at, valid_until, verify_code)
  values ('IFI-' || to_char(now(), 'YYYY') || '-00002', o, 'فلاح نوري السعدي', '197503300019', 'معمل دجلة للنسيج', 'textile', 'نينوى', 'الموصل', 'TN-NIN-2210', 'IDD-2016-0219',
    'complete', 40, 'أقمشة قطنية وبطانيات', 'expired', current_date - 400, current_date - 35, 'IFDEMO2N7T') returning * into m4;
end $$;
