-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 62c: مقترض العرض في القمة العربية لدعم المشاريع الصغيرة والمتوسطة
-- summit1: موظف حكومي في بغداد بدخل 1.5 مليون — يطابق سياسة مصرف السنابل، فيكمل دورة التمويل كاملة
-- عند الفرع الرئيسي (snb.cs) أمام الحضور. بلا طلب قائم. آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════
do $$
declare u uuid;
begin
  if not exists (select 1 from profiles where username = 'summit1') and not exists (select 1 from profiles where phone = '07701239012') then
    u := _mk_user('summit1', 'Summit@2026', 'علي حسن الموسوي', 'citizen', 'citizen', null, '07701239012', '198806100912');
    update profiles set kyc_status = 'verified', kyc_at = now(), governorate = 'بغداد', city = 'الكرادة', employer = 'وزارة الكهرباء',
      employment_type = 'gov', monthly_salary = 1500000, birth_date = '1988-06-10', must_change_password = false where id = u;
  end if;
end $$;
