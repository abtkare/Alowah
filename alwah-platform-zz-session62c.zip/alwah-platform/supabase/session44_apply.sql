-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 44: الهيئة الشرعية — المرحلة الثانية: هيئة في كل مصرف إسلامي
--  • لكل مصرف إسلامي هيئته (scope = 'bank') بجهة مستقلة من نوع sharia وبوابة /sharia نفسها، تعتمد منتجات مصرفها فقط.
--  • الهيئة المركزية إشرافية: تُنشئ هيئات المصارف، وتعتمد ملاءمة أعضائها (لا يُحسب صوت عضو قبل ملاءمته)،
--    وتحدد الصيغ المسموحة، وتطّلع على كل قرارات هيئات المصارف، ولها تعليق أي منتج.
--  • إعداد «نطاق الاعتماد: مركزي / مصرفي» في إعدادات الهيئة المركزية. في النطاق المصرفي يُقدَّم المنتج الجديد إلى هيئة مصرفه
--    إن اكتملت (رئيس + مصوّتون بقدر النصاب، كلهم بملاءمة)، وإلا إلى الهيئة المركزية.
--  • القرارات المركزية السابقة تبقى نافذة حتى تعيد هيئة المصرف اعتماد المنتج (نسخة مطابقة تمر بدورتها) أو يحلّ موعد مراجعته الدورية.
--  • تقرير الامتثال لكل هيئة مصرف، ويجمع تقرير البنك المركزي الهيئات كلها وتقاريرها الصادرة.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) الأعمدة والجداول ─────────
alter table public.sharia_boards add column if not exists approval_scope text not null default 'central';
alter table public.sharia_boards drop constraint if exists sharia_boards_approval_scope_check;
alter table public.sharia_boards add constraint sharia_boards_approval_scope_check check (approval_scope in ('central', 'bank'));
alter table public.sharia_boards add column if not exists parent_id uuid references public.sharia_boards(id);
alter table public.sharia_boards add column if not exists created_by_name text;
create unique index if not exists sharia_boards_one_per_bank on public.sharia_boards(bank_id) where scope = 'bank';

-- ملاءمة العضو (تعتمدها الهيئة المركزية لأعضاء هيئات المصارف؛ أعضاء الهيئة المركزية معتمدون)
alter table public.sharia_members add column if not exists fit_status text not null default 'approved';
alter table public.sharia_members drop constraint if exists sharia_members_fit_status_check;
alter table public.sharia_members add constraint sharia_members_fit_status_check check (fit_status in ('pending', 'approved', 'rejected', 'revoked'));
alter table public.sharia_members add column if not exists fit_note text;
alter table public.sharia_members add column if not exists fit_by_name text;
alter table public.sharia_members add column if not exists fit_at timestamptz;
alter table public.sharia_members add column if not exists fit_code text;
alter table public.sharia_members add column if not exists nominated_at timestamptz default now();

-- من علّق المنتج (الهيئة المركزية تعلّق إشرافياً ولا يرفع تعليقها غيرها)، ومن أين انتقل الملف
alter table public.islamic_products add column if not exists suspended_by uuid references public.sharia_boards(id);
alter table public.islamic_products add column if not exists moved_from uuid references public.sharia_boards(id);

-- تقرير الامتثال لهيئة مصرف: مصرفه
alter table public.sharia_compliance_reports add column if not exists bank_id uuid references public.orgs(id);

-- سجل الهيئة (الإنشاء، الملاءمة، الصيغ المسموحة، نطاق الاعتماد)
create table if not exists public.sharia_board_log (
  id bigserial primary key,
  board_id uuid not null references public.sharia_boards(id) on delete cascade,
  at timestamptz not null default now(),
  actor_name text, actor_code text, action text not null, note text
);
create index if not exists sharia_board_log_b on public.sharia_board_log(board_id, at desc);
alter table public.sharia_board_log enable row level security;
revoke all on public.sharia_board_log from anon, authenticated;

-- ───────── 2) أدوات ─────────
create or replace function public._sh_central() returns public.sharia_boards
language sql stable security definer set search_path to 'public' as $f$
  select * from sharia_boards where scope = 'central' order by created_at limit 1 $f$;

-- هيئة المستخدم الحالي (من جهته)
create or replace function public._sh_my_board() returns public.sharia_boards
language sql stable security definer set search_path to 'public' as $f$
  select b.* from sharia_boards b join profiles p on p.org_id = b.org_id where p.id = auth.uid() order by b.created_at limit 1 $f$;

-- هل يُحسب للعضو صوته؟ الهيئة المركزية: نعم. هيئة المصرف: بعد ملاءمته من الهيئة المركزية
create or replace function public._sh_fit_ok(p_board uuid, p_profile uuid) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select case when (select scope from sharia_boards where id = p_board) = 'central' then true
    else exists (select 1 from sharia_members where board_id = p_board and profile_id = p_profile and fit_status = 'approved') end $f$;

-- الأعضاء المصوّتون: الرئيس والأعضاء الفعّالون في جهة الهيئة (بملاءمة في هيئات المصارف)
create or replace function public._sh_voters(p_board uuid) returns int
language sql stable security definer set search_path to 'public' as $f$
  select count(*)::int from profiles p join sharia_boards b on b.org_id = p.org_id
  where b.id = p_board and p.role in ('sharia_head', 'sharia_member') and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id) $f$;

-- اكتمال هيئة المصرف: رئيس بملاءمة + مصوّتون بقدر النصاب
create or replace function public._sh_board_ready(p_board uuid) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_head' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))
    and _sh_voters(p_board) >= coalesce((select quorum from sharia_boards where id = p_board), 99) $f$;

-- ما ينقص هيئة المصرف لتكتمل (يظهر للهيئة المركزية ولرئيس هيئة المصرف)
create or replace function public._sh_board_missing(p_board uuid) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from (
    select 'رئيس الهيئة بملاءمة معتمدة' x where not exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_head' and not coalesce(p.disabled, false) and _sh_fit_ok(b.id, p.id))
    union all
    select 'أعضاء مصوّتون بملاءمة: ' || _sh_voters(p_board) || ' من ' || b.quorum || ' (النصاب)' from sharia_boards b where b.id = p_board and _sh_voters(p_board) < b.quorum
    union all
    select 'أمين سر الهيئة' where not exists (select 1 from profiles p join sharia_boards b on b.org_id = p.org_id
      where b.id = p_board and p.role = 'sharia_secretary' and not coalesce(p.disabled, false))) z $f$;

-- الهيئة المختصة بمصرف: هيئة المصرف إن كان النطاق مصرفياً واكتملت، وإلا المركزية
create or replace function public._sh_board_for(p_bank uuid) returns uuid
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    (select b.id from sharia_boards b where b.scope = 'bank' and b.bank_id = p_bank and (_sh_central()).approval_scope = 'bank' and _sh_board_ready(b.id) limit 1),
    (_sh_central()).id) $f$;

-- اعتماد مركزي قديم لمنتج مصرفٍ صارت له هيئة نافذة: «موروث» — نافذ حتى إعادة الاعتماد أو موعد المراجعة
create or replace function public._sh_inherited(p public.islamic_products) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select p.status in ('approved', 'conditional') and p.board_id = (_sh_central()).id and _sh_board_for(p.bank_id) is distinct from p.board_id $f$;

-- المنتج نافذ للطلبات الجديدة؟ (المعتمد، إلا الموروث الذي حلّ موعد مراجعته ولم تُعد هيئة المصرف اعتماده)
create or replace function public._sh_live(p public.islamic_products) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select p.status in ('approved', 'conditional') and not (_sh_inherited(p) and p.review_due is not null and p.review_due < current_date) $f$;

-- المستخدم في بوابة الهيئة يرى ملفات هذه الهيئة؟ (المركزية ترى الكل)
create or replace function public._sh_sees_board(p_board uuid) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from sharia_boards b join profiles p on p.org_id = b.org_id where p.id = auth.uid() and (b.scope = 'central' or b.id = p_board)) $f$;

create or replace function public._sh_board_log(p_board uuid, p_action text, p_note text) returns void
language sql security definer set search_path to 'public' as $f$
  insert into sharia_board_log(board_id, actor_name, actor_code, action, note)
  select p_board, coalesce(p.full_name, 'النظام'), p.staff_code, p_action, p_note from (select 1) x left join profiles p on p.id = auth.uid() $f$;

-- رقم قرار الملاءمة FT-…
create or replace function public._sh_fit_code() returns text language plpgsql security definer set search_path to 'public' as $f$
declare y text := to_char(now(), 'YYYY'); n int;
begin
  perform pg_advisory_xact_lock(hashtext('sharia_fit_code'));
  select coalesce(max(substring(fit_code from '\d+$')::int), 0) + 1 into n from sharia_members where fit_code like 'FT-' || y || '-%';
  return 'FT-' || y || '-' || lpad(n::text, 4, '0');
end $f$;

create or replace function public._sh_fit_label(s text) returns text language sql immutable as $f$
  select case s when 'pending' then 'بانتظار الملاءمة' when 'approved' then 'ملاءمة معتمدة' when 'rejected' then 'لم تُعتمد الملاءمة' when 'revoked' then 'سُحبت الملاءمة' else s end $f$;

-- ───────── 3) عضوية الهيئة تُسجَّل آلياً عند إضافة الحساب («فريقي» أو الإنشاء) ─────────
create or replace function public._sh_member_sync() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare b sharia_boards; r text; v_new boolean := false; c sharia_boards;
begin
  if new.portal <> 'sharia' or new.role not in ('sharia_head', 'sharia_member', 'sharia_secretary') then return new; end if;
  select * into b from sharia_boards where org_id = new.org_id order by created_at limit 1;
  if b.id is null then return new; end if;
  r := case new.role when 'sharia_head' then 'head' when 'sharia_secretary' then 'secretary' else 'member' end;
  if not exists (select 1 from sharia_members where board_id = b.id and profile_id = new.id) then
    insert into sharia_members(board_id, profile_id, role, fit_status, nominated_at)
    values (b.id, new.id, r, case when b.scope = 'central' then 'approved' else 'pending' end, now());
    v_new := b.scope = 'bank';
  else
    update sharia_members set role = r where board_id = b.id and profile_id = new.id and role <> r;
  end if;
  if v_new then
    c := _sh_central();
    perform _sh_board_log(b.id, 'ترشيح عضو: ' || new.full_name || ' — ' || _role_title(new.role), 'بانتظار ملاءمة الهيئة المركزية');
    perform _sh_notify(c.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_fit', 'عضو جديد في ' || b.name || ' بانتظار الملاءمة',
      new.full_name || ' — ' || _role_title(new.role) || '. لا يُحسب صوته حتى تعتمدوا ملاءمته', b.id);
  end if;
  return new;
end $f$;
drop trigger if exists trg_sh_member_sync on public.profiles;
create trigger trg_sh_member_sync after insert or update of role, org_id on public.profiles for each row execute function public._sh_member_sync();

-- أعضاء الهيئة المركزية الحاليون: عضوية بملاءمة (لمن ليس له سجل)
insert into public.sharia_members(board_id, profile_id, role, fit_status)
select b.id, p.id, case p.role when 'sharia_head' then 'head' when 'sharia_secretary' then 'secretary' else 'member' end, 'approved'
from public.profiles p join public.sharia_boards b on b.org_id = p.org_id
where p.portal = 'sharia' and p.role in ('sharia_head', 'sharia_member', 'sharia_secretary') on conflict do nothing;

-- ───────── 4) الصلاحيات على الجداول: هيئة المصرف ترى ملفات هيئتها فقط ─────────
drop policy if exists read_isl_products on public.islamic_products;
create policy read_isl_products on public.islamic_products for select using (
  my_portal() in ('cbi', 'integrity', 'audit', 'admin') or (my_portal() = 'sharia' and _sh_sees_board(board_id)) or (my_portal() = 'bank' and bank_id = my_org()));
drop policy if exists read_sh_votes on public.sharia_votes;
create policy read_sh_votes on public.sharia_votes for select using (
  my_portal() = 'sharia' and _sh_sees_board((select board_id from islamic_products p where p.id = product_id)));
drop policy if exists read_sh_reviews on public.sharia_reviews;
create policy read_sh_reviews on public.sharia_reviews for select using (
  (my_portal() = 'sharia' and _sh_sees_board((select board_id from islamic_products p where p.id = product_id)))
  or exists (select 1 from islamic_products p where p.id = product_id and my_portal() = 'bank' and p.bank_id = my_org()));

create or replace function public._isl_can_see(a applications) returns boolean
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; mb sharia_boards;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or a.id is null then return false; end if;
  if me.portal = 'sharia' then   -- الجلسة 44: هيئة المصرف ترى طلبات مصرفها فقط
    mb := _sh_my_board();
    return mb.scope = 'central' or mb.bank_id = a.bank_id;
  end if;
  return a.citizen_id = me.id
    or me.portal in ('cbi', 'integrity', 'audit', 'admin')
    or (me.portal = 'bank' and me.org_id = a.bank_id)
    or (me.portal = 'supplier' and me.org_id = a.supplier_id);
end $f$;

create or replace function public._sh_res_can_see(r sharia_resolutions) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from profiles me where me.id = auth.uid() and not coalesce(me.disabled, false) and (
    me.portal in ('cbi', 'audit', 'integrity', 'admin')
    or (me.portal = 'sharia' and (_sh_sees_board(r.board_id) or _sh_sees_board((select board_id from islamic_products where id = r.product_id))))
    or (me.portal = 'bank' and me.org_id = (select bank_id from islamic_products where id = r.product_id)))) $f$;

-- ───────── 5) سطر المنتج: الهيئة ونفاذ الاعتماد الموروث ─────────
create or replace function public._sh_row(p islamic_products) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', p.id, 'code', p.code, 'name', p.name, 'bank', (select name from orgs where id = p.bank_id), 'bank_id', p.bank_id,
    'type', p.contract_type, 'type_name', (select name from sharia_contract_types where code = p.contract_type),
    'type_allowed', (select allowed from sharia_contract_types where code = p.contract_type),
    'sector', p.sector, 'subsector', p.subsector, 'sector_label', _sh_sector_label(p.sector, p.subsector), 'line', p.line,
    'status', p.status, 'status_label', _sh_status_label(p.status), 'status_note', p.status_note,
    'version', (select n from islamic_contract_versions where id = p.current_version_id),
    'versions', (select count(*) from islamic_contract_versions where product_id = p.id),
    'comments', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null),
    'comments_open', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null and not resolved and author_side = 'board'),
    'votes', (select count(*) from sharia_votes where version_id = p.current_version_id and _sh_fit_ok(p.board_id, member_id)),
    'my_vote', (select vote from sharia_votes where version_id = p.current_version_id and member_id = auth.uid()),
    'resolution', (select jsonb_build_object('code', code, 'decision', decision, 'decision_label', _sh_decision_label(decision), 'issued_at', issued_at) from sharia_resolutions where id = p.resolution_id),
    'submitted_at', p.submitted_at, 'updated_at', p.updated_at, 'review_due', p.review_due,
    'review_soon', p.review_due is not null and p.review_due <= current_date + 30,
    'amends', (select jsonb_build_object('id', o.id, 'code', o.code, 'name', o.name, 'board_scope', (select scope from sharia_boards where id = o.board_id)) from islamic_products o where o.id = p.amends_product_id),
    'amending', (select jsonb_build_object('id', c.id, 'code', c.code, 'status', c.status, 'status_label', _sh_status_label(c.status)) from islamic_products c
      where c.amends_product_id = p.id and c.status not in ('rejected', 'superseded', 'withdrawn') limit 1),
    -- الجلسة 44
    'board_id', p.board_id, 'board_name', (select name from sharia_boards where id = p.board_id), 'board_scope', (select scope from sharia_boards where id = p.board_id),
    'inherited', _sh_inherited(p), 'live', _sh_live(p),
    'suspended_by_central', p.status = 'suspended' and p.suspended_by is not null and p.suspended_by is distinct from p.board_id,
    'readopt', p.amends_product_id is not null and (select board_id from islamic_products where id = p.amends_product_id) is distinct from p.board_id) $f$;

-- ───────── 6) الحرّاس: اعتماد الموروث وإعادة الاعتماد لدى هيئة المصرف ─────────
-- تعديل المنتج المعتمد (أو إعادة اعتماده) يُقدَّم إلى الهيئة المختصة الآن
create or replace function public.islamic_product_amend(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; o islamic_products; c islamic_products; av islamic_contract_versions; k int; v_board uuid; v_re boolean;
begin
  me := _sh_bank_me();
  select * into o from islamic_products where id = p_id for update;
  if o.bank_id is distinct from me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
  if o.status not in ('approved', 'conditional') then raise exception 'يُعدَّل بهذه الطريقة المنتج المعتمد النافذ فقط'; end if;
  select * into c from islamic_products where amends_product_id = o.id and status not in ('rejected', 'superseded', 'withdrawn') limit 1;
  if c.id is not null then return jsonb_build_object('id', c.id, 'code', c.code, 'existing', true); end if;
  v_board := _sh_board_for(o.bank_id); v_re := v_board is distinct from o.board_id;
  select * into av from islamic_contract_versions where id = o.approved_version_id;
  k := (select count(*) from islamic_products where amends_product_id = o.id) + 1;
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, amends_product_id, created_by)
  values (o.code || '-T' || k, o.bank_id, v_board, o.contract_type, o.name, o.sector, o.subsector, o.line, o.pricing, o.guarantees, o.attachments, 'draft', o.id, me.id)
  returning * into c;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name)
  values (c.id, av.n, av.clauses, av.sha256, 'superseded', 'النسخة المعتمدة النافذة (أساس التعديل)', av.created_by_name);
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name)
  values (c.id, av.n + 1, av.clauses, av.sha256, 'draft', case when v_re then 'إعادة اعتماد النص نفسه لدى ' || (select name from sharia_boards where id = v_board) end, me.full_name)
  returning id into av.id;
  update islamic_products set current_version_id = av.id where id = c.id;
  if v_re then
    perform _sh_log(c.id, 'بدء إعادة اعتماد المنتج ' || o.code || ' لدى ' || (select name from sharia_boards where id = v_board), 'الاعتماد السابق (' || (select name from sharia_boards where id = o.board_id) || ') يبقى نافذاً حتى يصدر القرار');
    perform _sh_log(o.id, 'قدّم المصرف المنتج لإعادة اعتماده لدى هيئة المصرف (' || c.code || ')', 'هذا المنتج يبقى نافذاً حتى يصدر القرار');
  else
    perform _sh_log(c.id, 'بدء تعديل على المنتج المعتمد ' || o.code, 'النسخة المعتمدة تبقى نافذة للمقترضين حتى يصدر القرار الجديد');
    perform _sh_log(o.id, 'بدأ المصرف تعديلاً على العقد (' || c.code || ')', 'هذا المنتج يبقى نافذاً حتى يصدر القرار');
  end if;
  return jsonb_build_object('id', c.id, 'code', c.code, 'existing', false, 'readopt', v_re);
end $f$;

-- لا يُقدَّم تعديل بلا تغيير — إلا إعادة الاعتماد لدى هيئة أخرى (النص نفسه)
create or replace function public._isl_amend_guard() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare base text; o islamic_products;
begin
  if new.amends_product_id is null then return new; end if;
  select * into o from islamic_products where id = new.amends_product_id;
  if new.contract_type is distinct from o.contract_type then
    raise exception 'تعديل المنتج المعتمد لا يغيّر صيغته — أنشئ منتجاً جديداً لصيغة أخرى'; end if;
  if new.status = 'submitted' and old.status in ('draft', 'returned') and new.board_id is not distinct from o.board_id then
    select sha256 into base from islamic_contract_versions where id = o.approved_version_id;
    if (select sha256 from islamic_contract_versions where id = new.current_version_id) = base then
      raise exception 'لم يتغير شيء في نص العقد عن النسخة المعتمدة — عدّل البنود أولاً'; end if;
  end if;
  return new;
end $f$;

-- عند اعتماد التعديل أو إعادة الاعتماد: يُدمج في المنتج الأصلي، وينتقل المنتج إلى الهيئة التي اعتمدته
create or replace function public._isl_amend_merge() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare o islamic_products;
begin
  if new.amends_product_id is null or new.status not in ('approved', 'conditional') or old.status = new.status then return new; end if;
  select * into o from islamic_products where id = new.amends_product_id for update;
  update islamic_contract_versions set status = 'superseded' where id = o.approved_version_id;
  update islamic_products set approved_version_id = new.approved_version_id, current_version_id = new.approved_version_id, resolution_id = new.resolution_id,
    review_due = new.review_due, status = case when o.status in ('approved', 'conditional') then new.status else o.status end,
    moved_from = case when o.board_id is distinct from new.board_id then o.board_id else o.moved_from end, board_id = new.board_id,
    status_note = case when o.board_id is distinct from new.board_id then 'أعادت ' || (select name from sharia_boards where id = new.board_id) || ' اعتماده (' || new.code || ')'
      else 'نافذ بالنسخة المعدّلة من ' || new.code end, updated_at = now()
  where id = o.id;
  update islamic_products set status = 'superseded', status_note = 'دُمج في ' || o.code || ' بعد اعتماده', updated_at = now() where id = new.id;
  perform _sh_log(o.id, case when o.board_id is distinct from new.board_id then 'أعادت ' || (select name from sharia_boards where id = new.board_id) || ' اعتماد المنتج — صار تحت إشرافها'
    else 'اعتُمدت النسخة المعدّلة وصارت هي النافذة' end, (select code from sharia_resolutions where id = new.resolution_id) || ' · ' || new.code);
  perform _sh_log(new.id, 'دُمج التعديل في المنتج ' || o.code, null);
  return new;
end $f$;

-- عند التقديم: الملف يذهب إلى الهيئة المختصة الآن (هيئة المصرف إن اكتملت في النطاق المصرفي)
create or replace function public.islamic_product_submit(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; cur islamic_contract_versions; v_board uuid;
begin
  me := _sh_bank_me();
  select * into pr from islamic_products where id = p_id for update;
  if pr.bank_id <> me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
  if pr.status not in ('draft', 'returned') then raise exception 'يُقدَّم المنتج وهو مسودة أو معاد للتعديل'; end if;
  if not exists (select 1 from sharia_contract_types where code = pr.contract_type and allowed) then
    raise exception 'صيغة هذا المنتج لم تعد مسموحة من الهيئة المركزية'; end if;
  select * into cur from islamic_contract_versions where id = pr.current_version_id;
  if cur.id is null or jsonb_array_length(cur.clauses) < 5 then raise exception 'اكتب نموذج العقد (5 بنود على الأقل) قبل التقديم'; end if;
  if pr.status = 'returned' and cur.status <> 'draft' then raise exception 'عدّل نص العقد أولاً (نسخة جديدة) ثم قدّمه'; end if;
  v_board := _sh_board_for(pr.bank_id);
  if v_board is distinct from pr.board_id and pr.amends_product_id is null then
    update islamic_products set moved_from = pr.board_id, board_id = v_board where id = pr.id;
    perform _sh_log(pr.id, 'انتقل الملف إلى ' || (select name from sharia_boards where id = v_board), 'نطاق الاعتماد مصرفي: منتجات المصرف تعتمدها هيئته');
    pr.board_id := v_board;
  end if;
  update islamic_contract_versions set status = 'submitted', sha256 = _sh_sha(clauses) where id = cur.id;
  update islamic_products set status = 'submitted', status_note = null, submitted_at = now(), updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تقديم إلى ' || (select name from sharia_boards where id = pr.board_id) || ' — النسخة ' || cur.n, null);
  perform _sh_notify(_sh_board_org(pr.board_id), 'sharia', array['sharia_secretary'], 'sharia_review',
    case when pr.amends_product_id is not null and (select board_id from islamic_products where id = pr.amends_product_id) is distinct from pr.board_id
      then 'منتج معتمد مركزياً لإعادة اعتماده: ' else 'منتج جديد للتحقق: ' end || pr.name,
    (select name from orgs where id = pr.bank_id) || ' · ' || (select name from sharia_contract_types where code = pr.contract_type), pr.id);
  return _sh_row((select x from islamic_products x where id = pr.id));
end $f$;

-- نفاذ المنتج للمقترض: الموروث الذي حلّ موعد مراجعته لا يُختار لطلب جديد
do $$
declare d text; f regprocedure;
begin
  f := 'public.islamic_offer_products(uuid,numeric,integer,text)'::regprocedure; d := pg_get_functiondef(f);
  if position('_sh_live(p)' in d) = 0 then
    if position('where p.bank_id = p_bank and p.status in (''approved'', ''conditional'')' in d) = 0 then raise exception 'الجلسة 44: لم يُعثر على موضع التعديل في islamic_offer_products'; end if;
    execute replace(d, 'where p.bank_id = p_bank and p.status in (''approved'', ''conditional'')', 'where p.bank_id = p_bank and _sh_live(p)');
  end if;
  f := 'public.app_choose_product(uuid,uuid)'::regprocedure; d := pg_get_functiondef(f);
  if position('_sh_live(p)' in d) = 0 then
    if position('if p.status not in (''approved'', ''conditional'') then raise exception ''هذا المنتج غير معتمد شرعاً حالياً' in d) = 0 then raise exception 'الجلسة 44: لم يُعثر على موضع التعديل في app_choose_product'; end if;
    execute replace(d, 'if p.status not in (''approved'', ''conditional'') then raise exception ''هذا المنتج غير معتمد شرعاً حالياً',
      'if not _sh_live(p) then raise exception ''هذا المنتج غير معتمد شرعاً حالياً');
  end if;
  f := 'public.islamic_sign(uuid,text,text,jsonb)'::regprocedure; d := pg_get_functiondef(f);
  if position('_sh_live(p)' in d) = 0 then
    if position('if p.status not in (''approved'', ''conditional'') then raise exception ''المنتج «%» لم يعد معتمداً شرعاً (%)' in d) = 0 then raise exception 'الجلسة 44: لم يُعثر على موضع التعديل في islamic_sign'; end if;
    execute replace(d, 'if p.status not in (''approved'', ''conditional'') then raise exception ''المنتج «%» لم يعد معتمداً شرعاً (%)',
      'if not _sh_live(p) then raise exception ''المنتج «%» لم يعد معتمداً شرعاً (%)');
  end if;
end $$;

-- لوحة المصرف: الهيئة المختصة الآن ونفاذ الموروث
create or replace function public.islamic_my_products() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; c sharia_boards; bb sharia_boards;
begin
  me := _sh_bank_me();
  select * into b from sharia_boards where id = _sh_board_for(me.org_id);
  c := _sh_central();
  select * into bb from sharia_boards where scope = 'bank' and bank_id = me.org_id;
  return jsonb_build_object(
    'bank', (select name from orgs where id = me.org_id),
    'board', jsonb_build_object('name', b.name, 'madhhab_label', _sh_madhhab_label(b.madhhab), 'scope', b.scope),
    'central', jsonb_build_object('name', c.name, 'approval_scope', c.approval_scope),
    'bank_board', case when bb.id is null then null else jsonb_build_object('name', bb.name, 'ready', _sh_board_ready(bb.id), 'missing', _sh_board_missing(bb.id),
      'active', b.id = bb.id) end,
    'products', coalesce((select jsonb_agg(_sh_row(p) order by p.updated_at desc) from islamic_products p where p.bank_id = me.org_id), '[]'::jsonb),
    'types', coalesce((select jsonb_agg(to_jsonb(t) order by t.sort) from sharia_contract_types t where t.allowed), '[]'::jsonb));
end $f$;

-- ───────── 7) دورة الاعتماد: كل هيئة تعمل على ملفات هيئتها ─────────
-- المنتج في يد هذه الهيئة؟
create or replace function public._sh_own(pr islamic_products) returns sharia_boards
language plpgsql stable security definer set search_path to 'public' as $f$
declare mb sharia_boards;
begin
  mb := _sh_my_board();
  if pr.id is null then raise exception 'المنتج غير موجود'; end if;
  if mb.id is distinct from pr.board_id then raise exception 'هذا الملف لدى % — تطّلع عليه الهيئة المركزية إشرافياً فقط', coalesce((select name from sharia_boards where id = pr.board_id), 'هيئة أخرى'); end if;
  return mb;
end $f$;

create or replace function public._sh_tally(p_prod uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; b sharia_boards; a int; c int; r int; n int; mem int; head_vote text; prop text; need_ok boolean;
begin
  select * into p from islamic_products where id = p_prod;
  select * into b from sharia_boards where id = p.board_id;
  -- الجلسة 44: لا يُحسب صوت عضو سُحبت ملاءمته أو لم تُعتمد
  select count(*) filter (where vote = 'approve'), count(*) filter (where vote = 'approve_cond'), count(*) filter (where vote = 'reject'), count(*),
    max(vote) filter (where is_head)
  into a, c, r, n, head_vote from sharia_votes where version_id = p.current_version_id and _sh_fit_ok(p.board_id, member_id);
  mem := _sh_voters(p.board_id);
  need_ok := n >= b.quorum;
  prop := case
    when not need_ok then null
    when b.majority = 'two_thirds' and (a + c) * 3 >= n * 2 then case when c > 0 then 'conditional' else 'approved' end
    when b.majority = 'two_thirds' and r * 3 > n then 'rejected'
    when b.majority = 'simple' and (a + c) > r then case when c > 0 then 'conditional' else 'approved' end
    when b.majority = 'simple' and r > (a + c) then 'rejected'
    when b.chair_casting and head_vote is not null then case when head_vote = 'reject' then 'rejected' when c > 0 then 'conditional' else 'approved' end
    else null end;
  return jsonb_build_object('approve', a, 'approve_cond', c, 'reject', r, 'cast', n, 'members', mem, 'quorum', b.quorum, 'quorum_ok', need_ok,
    'majority', b.majority, 'tie', (a + c) = r and n > 0, 'head_vote', head_vote, 'proposed', prop, 'proposed_label', _sh_decision_label(prop));
end $f$;

create or replace function public.sharia_screen(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  me := _sh_me();
  if me.role not in ('sharia_secretary', 'sharia_head') then raise exception 'التحقق من الاكتمال لأمين السر'; end if;
  select * into pr from islamic_products where id = p_id for update;
  perform _sh_own(pr);
  if pr.status <> 'submitted' then raise exception 'المنتج ليس بانتظار التحقق (حالته: %)', _sh_status_label(pr.status); end if;
  if act = 'refer' then
    update islamic_products set status = 'deliberation', status_note = v_note, updated_at = now() where id = pr.id;
    perform _sh_log(pr.id, 'إحالة للأعضاء للمداولة والتصويت', v_note);
    perform _sh_notify(me.org_id, 'sharia', array['sharia_head', 'sharia_member'], 'sharia_review', 'منتج للمداولة: ' || pr.name,
      (select name from orgs where id = pr.bank_id) || ' · ' || (select name from sharia_contract_types where code = pr.contract_type) || ' — علّق على البنود وصوّت', pr.id);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أحيل منتجك للأعضاء: ' || pr.name, 'بدأت المداولة. ستصلك التعليقات على البنود', pr.id);
  elsif act = 'return' then
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الإعادة للمصرف'; end if;
    update islamic_products set status = 'returned', status_note = v_note, updated_at = now() where id = pr.id;
    update islamic_contract_versions set status = 'returned' where id = pr.current_version_id;
    perform _sh_log(pr.id, 'إعادة للمصرف لاستكمال الملف', v_note);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أعادت الهيئة منتجك للتعديل: ' || pr.name, v_note, pr.id);
  else raise exception 'إجراء غير معروف'; end if;
  return _sh_row((select x from islamic_products x where id = pr.id));
end $f$;

create or replace function public.sharia_comment(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; v_body text := nullif(trim(coalesce(p->>'body', '')), ''); v_clause int := nullif(p->>'clause_n', '')::int; rid uuid;
begin
  me := _sh_me();
  select * into pr from islamic_products where id = p_id;
  perform _sh_own(pr);
  if pr.status not in ('deliberation', 'submitted') then raise exception 'التعليق متاح أثناء المداولة فقط'; end if;
  if v_body is null or length(v_body) < 3 then raise exception 'اكتب التعليق'; end if;
  if v_clause is not null and not exists (select 1 from islamic_contract_versions v, jsonb_array_elements(v.clauses) c where v.id = pr.current_version_id and (c->>'n')::int = v_clause) then
    raise exception 'البند % غير موجود في النسخة الحالية', v_clause; end if;
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body)
  values (pr.id, pr.current_version_id, v_clause, me.id, me.full_name, 'board', left(v_body, 2000)) returning id into rid;
  update islamic_products set updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تعليق على ' || coalesce('البند ' || v_clause, 'المنتج'), left(v_body, 200));
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'تعليق من الهيئة على ' || coalesce('البند ' || v_clause, 'منتجك') || ': ' || pr.name, left(v_body, 160), pr.id);
  return jsonb_build_object('id', rid);
end $f$;

create or replace function public.sharia_comment_resolve(p_review uuid, p_resolved boolean) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; r sharia_reviews;
begin
  me := _sh_me();
  select * into r from sharia_reviews where id = p_review;
  if r.id is null then raise exception 'التعليق غير موجود'; end if;
  perform _sh_own((select x from islamic_products x where id = r.product_id));
  if r.author_id <> me.id and me.role not in ('sharia_head', 'sharia_secretary') then raise exception 'يعلّم التعليقَ كاتبُه أو الرئيس أو أمين السر'; end if;
  update sharia_reviews set resolved = coalesce(p_resolved, true) where id = r.id;
  perform _sh_log(r.product_id, case when coalesce(p_resolved, true) then 'تعليم تعليق معالَجاً' else 'إعادة فتح تعليق' end, left(r.body, 120));
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.sharia_vote(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; mb sharia_boards; v text := p->>'vote'; v_cond text := nullif(trim(coalesce(p->>'condition', '')), ''); v_reason text := nullif(trim(coalesce(p->>'reason', '')), '');
begin
  me := _sh_me();
  if me.role not in ('sharia_head', 'sharia_member') then raise exception 'التصويت للرئيس والأعضاء'; end if;
  select * into pr from islamic_products where id = p_id;
  mb := _sh_own(pr);
  if not _sh_fit_ok(mb.id, me.id) then raise exception 'لا يُحسب صوتك قبل أن تعتمد الهيئة المركزية ملاءمتك (%)',
    _sh_fit_label((select fit_status from sharia_members where board_id = mb.id and profile_id = me.id)); end if;
  if pr.status <> 'deliberation' then raise exception 'التصويت متاح أثناء المداولة فقط'; end if;
  if v not in ('approve', 'approve_cond', 'reject') then raise exception 'اختر: موافق أو موافق بشرط أو غير موافق'; end if;
  if v = 'approve_cond' and (v_cond is null or length(v_cond) < 5) then raise exception 'اكتب الشرط'; end if;
  if v = 'reject' and (v_reason is null or length(v_reason) < 5) then raise exception 'اكتب سبب عدم الموافقة'; end if;
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, condition, reason)
  values (pr.id, pr.current_version_id, me.id, me.full_name, me.role = 'sharia_head', v, case when v = 'approve_cond' then v_cond end, v_reason)
  on conflict (version_id, member_id) do update set vote = excluded.vote, condition = excluded.condition, reason = excluded.reason, at = now();
  update islamic_products set updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تصويت: ' || case v when 'approve' then 'موافق' when 'approve_cond' then 'موافق بشرط' else 'غير موافق' end, coalesce(v_cond, v_reason));
  return _sh_tally(pr.id);
end $f$;

create or replace function public.sharia_decide(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; pr islamic_products; b sharia_boards; cur islamic_contract_versions; tl jsonb; d text := p->>'decision'; c sharia_boards;
  v_body text := nullif(trim(coalesce(p->>'body', '')), ''); v_conds text; v_code text; res sharia_resolutions; v_due date; v_now timestamptz := now();
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إصدار القرار لرئيس الهيئة'; end if;
  select * into pr from islamic_products where id = p_id for update;
  b := _sh_own(pr);
  if not _sh_fit_ok(b.id, me.id) then raise exception 'إصدار القرار بعد أن تعتمد الهيئة المركزية ملاءمتك'; end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح — التوقيع لم يتم'; end if;
  if pr.status <> 'deliberation' then raise exception 'القرار يصدر بعد المداولة (حالة المنتج: %)', _sh_status_label(pr.status); end if;
  select * into cur from islamic_contract_versions where id = pr.current_version_id;
  tl := _sh_tally(pr.id);
  if d not in ('approved', 'conditional', 'returned', 'rejected') then raise exception 'اختر القرار'; end if;
  if d in ('approved', 'conditional') and not exists (select 1 from sharia_contract_types where code = pr.contract_type and allowed) then
    raise exception 'الصيغة % غير مسموحة من الهيئة المركزية — لا يُعتمد عليها منتج', pr.contract_type; end if;
  if d in ('approved', 'conditional', 'rejected') and not (tl->>'quorum_ok')::boolean then
    raise exception 'لم يكتمل النصاب: صوّت % من % مطلوبين', tl->>'cast', tl->>'quorum'; end if;
  if d in ('approved', 'conditional') and coalesce(tl->>'proposed', '') not in ('approved', 'conditional') then
    raise exception 'نتيجة التصويت لا تسمح بالاعتماد (النتيجة: %)', coalesce(tl->>'proposed_label', 'لا أغلبية'); end if;
  if d = 'approved' and tl->>'proposed' = 'conditional' then d := 'conditional'; end if;
  if d = 'rejected' and coalesce(tl->>'proposed', '') <> 'rejected' then raise exception 'نتيجة التصويت لا تسمح بالرفض — يمكنك الإعادة للتعديل'; end if;
  if d in ('returned', 'rejected') and (v_body is null or length(v_body) < 5) then raise exception 'اكتب نص القرار وسببه'; end if;
  select string_agg('• ' || member_name || ': ' || condition, E'\n' order by at) into v_conds from sharia_votes
  where version_id = cur.id and vote = 'approve_cond' and _sh_fit_ok(b.id, member_id);
  v_code := _sh_next_code();
  v_due := case when d in ('approved', 'conditional') then (v_now + make_interval(months => b.review_months))::date end;
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, conditions, votes, dissent, version_sha256, seal, signed_by, signed_by_name, signed_by_code, signed_via, issued_at)
  values (v_code, b.id, pr.id, cur.id, d,
    coalesce(v_body, case d when 'approved' then 'اعتمدت ' || b.name || ' المنتج «' || pr.name || '» ونموذج عقده بالنسخة ' || cur.n || ' على ' || _sh_madhhab_label(b.madhhab) || '.'
      when 'conditional' then 'اعتمدت ' || b.name || ' المنتج «' || pr.name || '» ونموذج عقده بالنسخة ' || cur.n || ' بالشروط المذكورة، على ' || _sh_madhhab_label(b.madhhab) || '.' end),
    case when d = 'conditional' then v_conds end, tl,
    coalesce((select jsonb_agg(jsonb_build_object('name', member_name, 'vote', vote, 'reason', reason) order by at) from sharia_votes
      where version_id = cur.id and _sh_fit_ok(b.id, member_id) and ((d in ('approved', 'conditional') and vote = 'reject') or (d = 'rejected' and vote <> 'reject'))), '[]'::jsonb),
    cur.sha256, encode(extensions.digest(v_code || '|' || coalesce(cur.sha256, '') || '|' || d || '|' || v_now::text, 'sha256'), 'hex'),
    me.id, me.full_name, me.staff_code, 'رمز تحقق على هاتف الرئيس', v_now)
  returning * into res;
  update islamic_contract_versions set status = case d when 'approved' then 'approved' when 'conditional' then 'approved' when 'rejected' then 'rejected' else 'returned' end where id = cur.id;
  if d in ('approved', 'conditional') then
    update islamic_contract_versions set status = 'superseded' where id = pr.approved_version_id and id <> cur.id;
  end if;
  update islamic_products set status = d, status_note = left(coalesce(v_body, v_conds), 400), resolution_id = res.id,
    approved_version_id = case when d in ('approved', 'conditional') then cur.id else approved_version_id end,
    review_due = coalesce(v_due, review_due), updated_at = v_now where id = pr.id;
  perform _sh_log(pr.id, 'قرار ' || v_code || ': ' || _sh_decision_label(d), left(coalesce(v_body, v_conds, ''), 200));
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products', 'bank_md'], 'sharia_bank', 'قرار ' || b.name || ' ' || v_code || ' — ' || _sh_decision_label(d) || ': ' || pr.name,
    case when d in ('approved', 'conditional') then 'المنتج يظهر الآن للمقترضين في مصرفكم' else coalesce(v_body, '') end, pr.id);
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_resolution', 'قرار ' || b.name || ' ' || v_code || ' — ' || _sh_decision_label(d),
    pr.name || ' · ' || (select name from orgs where id = pr.bank_id), pr.id);
  -- الجلسة 44: الهيئة المركزية تطّلع على كل قرارات هيئات المصارف
  if b.scope = 'bank' then
    c := _sh_central();
    perform _sh_notify(c.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_oversight', 'قرار ' || b.name || ' ' || v_code || ' — ' || _sh_decision_label(d),
      pr.name || ' · ' || (select name from sharia_contract_types where code = pr.contract_type), pr.id);
  end if;
  return jsonb_build_object('code', res.code, 'decision', d, 'decision_label', _sh_decision_label(d), 'seal', res.seal, 'version_sha256', res.version_sha256, 'issued_at', res.issued_at);
end $f$;

-- تعليق/رفع/سحب: هيئة المنتج، والهيئة المركزية تعلّق أي منتج إشرافياً (ولا يرفع تعليقها غيرها)
create or replace function public.sharia_post_action(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; mb sharia_boards; pb sharia_boards; pr islamic_products; act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
  v_code text; v_new text; v_dec text; res sharia_resolutions; v_now timestamptz := now(); v_sup boolean;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'هذا الإجراء لرئيس الهيئة'; end if;
  mb := _sh_my_board();
  select * into pr from islamic_products where id = p_id for update;
  if pr.id is null then raise exception 'المنتج غير موجود'; end if;
  select * into pb from sharia_boards where id = pr.board_id;
  v_sup := mb.id is distinct from pr.board_id;
  if v_sup then
    if mb.scope <> 'central' then raise exception 'هذا الملف لدى % — لا صلاحية لهيئتكم عليه', pb.name; end if;
    if act not in ('suspend', 'reinstate') then raise exception 'الهيئة المركزية تعلّق منتجات هيئات المصارف أو ترفع تعليقها؛ السحب لهيئة المصرف'; end if;
    if act = 'reinstate' and pr.suspended_by is distinct from mb.id then raise exception 'علّقت هذا المنتج % — ترفع تعليقه هي', pb.name; end if;
  else
    if not _sh_fit_ok(mb.id, me.id) then raise exception 'هذا الإجراء بعد أن تعتمد الهيئة المركزية ملاءمتك'; end if;
    if act = 'reinstate' and pr.suspended_by is not null and pr.suspended_by is distinct from mb.id then
      raise exception 'علّقت الهيئة المركزية هذا المنتج إشرافياً — لا يُرفع التعليق إلا بقرارها'; end if;
  end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  if act = 'suspend' then
    if pr.status not in ('approved', 'conditional') then raise exception 'يُعلَّق المنتج المعتمد فقط'; end if;
    v_new := 'suspended'; v_dec := 'suspended';
  elsif act = 'reinstate' then
    if pr.status <> 'suspended' then raise exception 'المنتج ليس معلّقاً'; end if;
    v_dec := 'reinstated';
    v_new := coalesce((select decision from sharia_resolutions where product_id = pr.id and decision in ('approved', 'conditional') order by issued_at desc limit 1), 'approved');
  elsif act = 'withdraw' then
    if pr.status not in ('approved', 'conditional', 'suspended') then raise exception 'يُسحب اعتماد المنتج المعتمد أو المعلّق فقط'; end if;
    v_new := 'withdrawn'; v_dec := 'withdrawn';
  else raise exception 'إجراء غير معروف'; end if;
  if act <> 'reinstate' and (v_note is null or length(v_note) < 5) then raise exception 'اكتب السبب'; end if;
  v_code := _sh_next_code();
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, version_sha256, seal, signed_by, signed_by_name, signed_by_code, signed_via, issued_at)
  select v_code, mb.id, pr.id, pr.approved_version_id, v_dec,
    coalesce(case when v_sup then 'قرار إشرافي من ' || mb.name || ': ' end, '') || coalesce(v_note, 'رُفع التعليق وعاد المنتج نافذاً'), v.sha256,
    encode(extensions.digest(v_code || '|' || coalesce(v.sha256, '') || '|' || v_dec || '|' || v_now::text, 'sha256'), 'hex'), me.id, me.full_name, me.staff_code, 'رمز تحقق على هاتف الرئيس', v_now
  from (select 1) x left join islamic_contract_versions v on v.id = pr.approved_version_id
  returning * into res;
  update islamic_products set status = v_new, status_note = v_note, resolution_id = res.id, updated_at = v_now,
    suspended_by = case when v_new = 'suspended' then mb.id else null end where id = pr.id;
  perform _sh_log(pr.id, 'قرار ' || v_code || ': ' || _sh_decision_label(v_dec) || case when v_sup then ' (إشرافي — ' || mb.name || ')' else '' end, v_note);
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products', 'bank_md'], 'sharia_bank', 'قرار ' || mb.name || ' ' || v_code || ' — ' || _sh_decision_label(v_dec) || ': ' || pr.name,
    case when v_new in ('suspended', 'withdrawn') then 'توقف عرض المنتج للطلبات الجديدة. العقود الموقّعة تبقى على نسختها' else 'عاد المنتج للظهور للمقترضين' end, pr.id);
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_resolution', 'قرار ' || mb.name || ' ' || v_code || ' — ' || _sh_decision_label(v_dec), pr.name, pr.id);
  if v_sup then
    perform _sh_notify(pb.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_oversight', 'قرار إشرافي من ' || mb.name || ': ' || _sh_decision_label(v_dec) || ' — ' || pr.name, v_note, pr.id);
  elsif mb.scope = 'bank' then
    perform _sh_notify((_sh_central()).org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_oversight', 'قرار ' || mb.name || ' ' || v_code || ' — ' || _sh_decision_label(v_dec), pr.name, pr.id);
  end if;
  return jsonb_build_object('code', v_code, 'status', v_new, 'status_label', _sh_status_label(v_new));
end $f$;

-- ───────── 8) الإنشاء والملاءمة والصيغ المسموحة ونطاق الاعتماد (الهيئة المركزية) ─────────
create or replace function public._sh_central_head() returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' or (_sh_my_board()).scope is distinct from 'central' then raise exception 'هذه الصلاحية لرئيس الهيئة المركزية'; end if;
  return me;
end $f$;

create or replace function public.sharia_board_create(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $f$
declare me profiles; c sharia_boards; bk orgs; o orgs; b sharia_boards; v_code text; v_name text; v_q int := coalesce(nullif(p->>'quorum', '')::int, 2);
  m jsonb := coalesce(p->'head', '{}'::jsonb); v_user text; uid uuid; i int := 0;
begin
  me := _sh_central_head();
  c := _sh_central();
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  select * into bk from orgs where id = nullif(p->>'bank_id', '')::uuid;
  if bk.id is null or bk.type <> 'bank' then raise exception 'اختر المصرف'; end if;
  if not coalesce(bk.is_islamic, false) then raise exception 'هيئة الرقابة الشرعية للمصارف الإسلامية فقط (النوافذ الإسلامية في المصارف التجارية ليست في المرحلة الأولى)'; end if;
  if exists (select 1 from sharia_boards where scope = 'bank' and bank_id = bk.id) then raise exception 'لهذا المصرف هيئة مسبقاً'; end if;
  if v_q < 2 or v_q > 9 then raise exception 'النصاب بين 2 و9'; end if;
  v_name := coalesce(nullif(trim(p->>'name'), ''), 'هيئة الرقابة الشرعية — ' || bk.name);
  if length(v_name) < 6 then raise exception 'اكتب اسم الهيئة'; end if;
  -- حساب رئيس الهيئة (بالشروط نفسها لحساب الإدارة العليا لأي جهة)
  v_user := lower(trim(coalesce(m->>'username', '')));
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم مستخدم الرئيس: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم «%» مستخدم مسبقاً', v_user; end if;
  if length(coalesce(m->>'password', '')) < 8 or (m->>'password') !~ '[0-9]' or (m->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if length(trim(coalesce(m->>'full_name', ''))) < 3 then raise exception 'اكتب اسم رئيس الهيئة'; end if;
  -- جهة الهيئة (بوابة /sharia)
  v_code := 'sh' || left(regexp_replace(bk.code, '[^a-z0-9]', '', 'g'), 6);
  while exists (select 1 from orgs where code = v_code) loop i := i + 1; v_code := 'sh' || left(regexp_replace(bk.code, '[^a-z0-9]', '', 'g'), 5) || i; end loop;
  insert into orgs(code, type, name, is_islamic, meta) values (v_code, 'sharia', v_name, false,
    jsonb_build_object('kind', 'sharia_bank', 'bank_id', bk.id, 'onboarded_at', now(), 'onboarded_by', me.full_name)) returning * into o;
  insert into sharia_boards(code, name, scope, org_id, bank_id, madhhab, marja, quorum, majority, chair_casting, review_months, late_kind, late_rule, parent_id, created_by_name)
  values ('SHB-' || upper(bk.code), v_name, 'bank', o.id, bk.id, c.madhhab, c.marja, v_q, 'simple', true, c.review_months, c.late_kind, c.late_rule, c.id, me.full_name)
  returning * into b;
  uid := _mk_user(v_user, m->>'password', trim(m->>'full_name'), 'sharia_head', 'sharia', o.code, _opt_phone(m->>'phone'), null);
  update profiles set manage_scope = 'org', must_change_password = true, managed_by = me.id where id = uid;
  -- الرئيس عيّنته الهيئة المركزية: ملاءمته معتمدة بقرار الإنشاء
  update sharia_members set fit_status = 'approved', fit_code = _sh_fit_code(), fit_by_name = me.full_name, fit_at = now(),
    fit_note = 'عيّنته ' || c.name || ' عند إنشاء الهيئة', specialty = nullif(trim(coalesce(m->>'specialty', '')), '')
  where board_id = b.id and profile_id = uid;
  perform _sh_board_log(b.id, 'إنشاء الهيئة وتعيين رئيسها: ' || trim(m->>'full_name'), 'النصاب ' || v_q || ' · تكتمل بأعضاء مصوّتين بملاءمة معتمدة');
  perform _sh_board_log(c.id, 'إنشاء ' || v_name, bk.name);
  perform _audit('إنشاء هيئة رقابة شرعية لمصرف', v_name, jsonb_build_object('bank', bk.name, 'code', b.code, 'head', v_user));
  perform _sh_notify(bk.id, 'bank', array['bank_md', 'bank_islamic_products'], 'sharia_bank', 'أُنشئت ' || v_name,
    'تعتمد منتجات مصرفكم بعد اكتمال أعضائها وملاءمتهم وتفعيل النطاق المصرفي. الاعتمادات الحالية تبقى نافذة.', b.id);
  return jsonb_build_object('board', b.code, 'name', v_name, 'org', o.code, 'username', v_user, 'portal', 'sharia');
end $f$;

-- قرار الملاءمة: اعتماد / عدم اعتماد / سحب — لرئيس الهيئة المركزية برمز تحقق
create or replace function public.sharia_fit_decide(p_board uuid, p_profile uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; mm sharia_members; pr profiles; d text := p->>'decision'; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_code text; v_st text;
begin
  me := _sh_central_head();
  select * into b from sharia_boards where id = p_board;
  if b.id is null or b.scope <> 'bank' then raise exception 'الملاءمة لأعضاء هيئات المصارف'; end if;
  select * into mm from sharia_members where board_id = b.id and profile_id = p_profile for update;
  select * into pr from profiles where id = p_profile;
  if mm.profile_id is null then raise exception 'العضو غير موجود في هذه الهيئة'; end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  if d = 'approve' then
    if mm.fit_status = 'approved' then raise exception 'ملاءمته معتمدة مسبقاً'; end if;
    v_st := 'approved';
  elsif d = 'reject' then
    if mm.fit_status <> 'pending' then raise exception 'يُرفض الترشيح وهو بانتظار الملاءمة — للمعتمد استخدم «سحب الملاءمة»'; end if;
    v_st := 'rejected';
  elsif d = 'revoke' then
    if mm.fit_status <> 'approved' then raise exception 'تُسحب الملاءمة المعتمدة فقط'; end if;
    v_st := 'revoked';
  else raise exception 'اختر القرار'; end if;
  if v_st <> 'approved' and (v_note is null or length(v_note) < 5) then raise exception 'اكتب السبب'; end if;
  v_code := _sh_fit_code();
  update sharia_members set fit_status = v_st, fit_code = v_code, fit_by_name = me.full_name, fit_at = now(), fit_note = v_note,
    specialty = coalesce(nullif(trim(coalesce(p->>'specialty', '')), ''), specialty) where board_id = b.id and profile_id = mm.profile_id;
  perform _sh_board_log(b.id, v_code || ': ' || _sh_fit_label(v_st) || ' — ' || pr.full_name || ' (' || _role_title(pr.role) || ')', v_note);
  perform _sh_board_log((_sh_central()).id, v_code || ': ' || _sh_fit_label(v_st) || ' — ' || pr.full_name || ' · ' || b.name, v_note);
  insert into notifications(user_id, kind, title, body, ref_id)
  values (pr.id, 'sharia_fit', case v_st when 'approved' then 'اعتمدت الهيئة المركزية ملاءمتك عضواً في ' || b.name else _sh_fit_label(v_st) || ' — ' || b.name end,
    coalesce(v_note, 'صار صوتك يُحسب في النصاب والقرارات') || ' · ' || v_code, b.id);
  perform _sh_notify(b.org_id, 'sharia', array['sharia_head'], 'sharia_fit', _sh_fit_label(v_st) || ': ' || pr.full_name, coalesce(v_note, '') || ' · ' || v_code, b.id);
  return jsonb_build_object('code', v_code, 'status', v_st, 'status_label', _sh_fit_label(v_st), 'ready', _sh_board_ready(b.id), 'voters', _sh_voters(b.id));
end $f$;

-- الصيغ المسموحة في مكتبة الهيئة المركزية
create or replace function public.sharia_type_allow(p_code text, p_allowed boolean, p_note text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; t sharia_contract_types; n int;
begin
  me := _sh_central_head();
  select * into t from sharia_contract_types where code = p_code for update;
  if t.code is null then raise exception 'الصيغة غير موجودة'; end if;
  if t.allowed = coalesce(p_allowed, true) then return jsonb_build_object('ok', true, 'allowed', t.allowed); end if;
  if not coalesce(p_allowed, true) and length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب سبب منع الصيغة'; end if;
  update sharia_contract_types set allowed = coalesce(p_allowed, true), updated_at = now() where code = t.code;
  select count(*) into n from islamic_products where contract_type = t.code and status in ('approved', 'conditional');
  perform _sh_board_log((_sh_central()).id, case when p_allowed then 'السماح بالصيغة ' else 'منع الصيغة ' end || t.name || ' (' || t.code || ')', nullif(trim(coalesce(p_note, '')), ''));
  perform _audit(case when p_allowed then 'السماح بصيغة' else 'منع صيغة' end, t.code, jsonb_build_object('note', p_note, 'live_products', n));
  perform _sh_notify(b.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_oversight',
    case when p_allowed then 'سمحت الهيئة المركزية بالصيغة: ' else 'منعت الهيئة المركزية الصيغة: ' end || t.name, coalesce(p_note, ''), null)
  from sharia_boards b where b.scope = 'bank';
  return jsonb_build_object('ok', true, 'allowed', coalesce(p_allowed, true), 'live_products', n);
end $f$;

-- إعدادات الهيئة (وللمركزية: نطاق الاعتماد)
create or replace function public.sharia_settings(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; q int; rm int; v_scope text;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إعدادات الهيئة لرئيسها'; end if;
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1 for update;
  q := coalesce(nullif(p->>'quorum', '')::int, b.quorum); rm := coalesce(nullif(p->>'review_months', '')::int, b.review_months);
  if q < 1 or q > greatest(_sh_voters(b.id), case when b.scope = 'bank' then 9 else 1 end) then raise exception 'النصاب بين 1 وعدد الأعضاء المصوّتين (%)', _sh_voters(b.id); end if;
  if b.scope = 'bank' and q < 2 then raise exception 'نصاب هيئة المصرف 2 على الأقل'; end if;
  if rm < 1 or rm > 60 then raise exception 'دورة المراجعة بين 1 و60 شهراً'; end if;
  if coalesce(p->>'majority', b.majority) not in ('simple', 'two_thirds') then raise exception 'قاعدة الأغلبية غير معروفة'; end if;
  if coalesce(p->>'late_kind', b.late_kind) not in ('claim', 'damage', 'charity') then raise exception 'اختر معالجة التأخر'; end if;
  v_scope := coalesce(nullif(p->>'approval_scope', ''), b.approval_scope);
  if v_scope not in ('central', 'bank') then raise exception 'نطاق الاعتماد: مركزي أو مصرفي'; end if;
  if b.scope = 'bank' and v_scope <> b.approval_scope then raise exception 'نطاق الاعتماد تضبطه الهيئة المركزية'; end if;
  update sharia_boards set
    name = coalesce(nullif(trim(p->>'name'), ''), name),
    marja = case when p ? 'marja' then nullif(trim(p->>'marja'), '') else marja end,
    late_rule = case when p ? 'late_rule' then nullif(trim(p->>'late_rule'), '') else late_rule end,
    late_kind = coalesce(nullif(p->>'late_kind', ''), late_kind),
    quorum = q, review_months = rm, majority = coalesce(p->>'majority', majority),
    chair_casting = coalesce((p->>'chair_casting')::boolean, chair_casting), approval_scope = v_scope, updated_at = now()
  where id = b.id;
  if v_scope is distinct from b.approval_scope then
    perform _sh_board_log(b.id, 'نطاق الاعتماد: ' || case v_scope when 'bank' then 'مصرفي — كل مصرف تعتمد منتجاته هيئته متى اكتملت' else 'مركزي — الهيئة المركزية تعتمد كل المنتجات' end,
      'القرارات السابقة تبقى نافذة حتى إعادة الاعتماد أو المراجعة الدورية');
    perform _notify(o.id, 'bank', 'sharia_bank', 'نطاق الاعتماد الشرعي: ' || case v_scope when 'bank' then 'مصرفي' else 'مركزي' end,
      case when v_scope = 'bank' and _sh_board_for(o.id) <> b.id then 'تُقدَّم منتجاتكم الجديدة إلى ' || (select name from sharia_boards where id = _sh_board_for(o.id)) || '. المنتجات المعتمدة مركزياً تبقى نافذة حتى تعيد هيئتكم اعتمادها أو يحلّ موعد مراجعتها.'
        else 'تُقدَّم منتجاتكم إلى ' || b.name || '.' end, null)
    from orgs o where o.type = 'bank' and coalesce(o.is_islamic, false);
  end if;
  perform _audit('تعديل إعدادات الهيئة الشرعية', b.code, p);
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 9) صندوق الهيئة وملف المنتج ─────────
create or replace function public._sh_members_json(b sharia_boards) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('profile_id', p.id, 'name', p.full_name, 'role', p.role, 'role_title', _role_title(p.role), 'code', p.staff_code,
      'specialty', m.specialty, 'fit_status', coalesce(m.fit_status, 'approved'), 'fit_label', _sh_fit_label(coalesce(m.fit_status, 'approved')), 'fit_code', m.fit_code,
      'fit_note', m.fit_note, 'fit_at', m.fit_at, 'fit_by', m.fit_by_name, 'nominated_at', m.nominated_at, 'counts', _sh_fit_ok(b.id, p.id) and p.role in ('sharia_head', 'sharia_member'),
      'username', case when (_sh_my_board()).id = b.id or (_sh_my_board()).scope = 'central' then p.username end)
    order by case p.role when 'sharia_head' then 0 when 'sharia_member' then 1 else 2 end, p.full_name), '[]'::jsonb)
  from profiles p left join sharia_members m on m.profile_id = p.id and m.board_id = b.id
  where p.org_id = b.org_id and p.role like 'sharia\_%' and not coalesce(p.disabled, false) $f$;

create or replace function public._sh_res_json(r sharia_resolutions) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', r.id, 'code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision),
    'product', p.name, 'product_id', p.id, 'bank', (select name from orgs where id = p.bank_id), 'type', p.contract_type, 'issued_at', r.issued_at,
    'signed_by', r.signed_by_name, 'seal', r.seal, 'version', (select n from islamic_contract_versions where id = r.version_id),
    'board', (select name from sharia_boards where id = r.board_id), 'board_scope', (select scope from sharia_boards where id = r.board_id))
  from islamic_products p where p.id = r.product_id $f$;

create or replace function public.sharia_inbox() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; c sharia_boards; ov jsonb; par jsonb;
begin
  me := _sh_me();
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1;
  if b.id is null then raise exception 'لا توجد هيئة مرتبطة بحسابك'; end if;
  c := _sh_central();
  if b.scope = 'central' then
    ov := jsonb_build_object(
      'approval_scope', b.approval_scope,
      'boards', coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'code', x.code, 'name', x.name, 'bank', o.name, 'bank_id', o.id, 'quorum', x.quorum,
          'voters', _sh_voters(x.id), 'ready', _sh_board_ready(x.id), 'missing', _sh_board_missing(x.id), 'active', _sh_board_for(o.id) = x.id,
          'members', _sh_members_json(x), 'fit_pending', (select count(*) from sharia_members where board_id = x.id and fit_status = 'pending'),
          'products_live', (select count(*) from islamic_products where board_id = x.id and status in ('approved', 'conditional')),
          'products_open', (select count(*) from islamic_products where board_id = x.id and status in ('submitted', 'deliberation')),
          'inherited', (select count(*) from islamic_products ip where ip.bank_id = o.id and _sh_inherited(ip)),
          'resolutions', (select count(*) from sharia_resolutions where board_id = x.id),
          'created_at', x.created_at, 'created_by', x.created_by_name,
          'log', coalesce((select jsonb_agg(jsonb_build_object('at', l.at, 'who', l.actor_name, 'action', l.action, 'note', l.note) order by l.at desc)
            from (select * from sharia_board_log where board_id = x.id order by at desc limit 12) l), '[]'::jsonb)) order by o.name)
        from sharia_boards x join orgs o on o.id = x.bank_id where x.scope = 'bank'), '[]'::jsonb),
      'banks_without', coalesce((select jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name) order by o.name) from orgs o
        where o.type = 'bank' and coalesce(o.is_islamic, false) and not exists (select 1 from sharia_boards x where x.scope = 'bank' and x.bank_id = o.id)), '[]'::jsonb),
      'fit_pending', (select count(*) from sharia_members m join sharia_boards x on x.id = m.board_id where x.scope = 'bank' and m.fit_status = 'pending'),
      'bank_products', coalesce((select jsonb_agg(_sh_row(p) order by p.updated_at desc) from islamic_products p where p.board_id <> b.id and p.status <> 'draft'), '[]'::jsonb),
      'bank_resolutions', coalesce((select jsonb_agg(_sh_res_json(r) order by r.issued_at desc) from sharia_resolutions r
        where r.board_id <> b.id), '[]'::jsonb),
      'log', coalesce((select jsonb_agg(jsonb_build_object('at', l.at, 'who', l.actor_name, 'action', l.action, 'note', l.note) order by l.at desc)
        from (select * from sharia_board_log where board_id = b.id order by at desc limit 20) l), '[]'::jsonb));
  else
    par := jsonb_build_object('name', c.name, 'approval_scope', c.approval_scope, 'ready', _sh_board_ready(b.id), 'missing', _sh_board_missing(b.id),
      'active', _sh_board_for(b.bank_id) = b.id, 'bank', (select name from orgs where id = b.bank_id),
      'my_fit', (select fit_status from sharia_members where board_id = b.id and profile_id = me.id),
      'my_fit_label', _sh_fit_label((select fit_status from sharia_members where board_id = b.id and profile_id = me.id)),
      'inherited', coalesce((select jsonb_agg(_sh_row(p) order by p.code) from islamic_products p where p.bank_id = b.bank_id and _sh_inherited(p)), '[]'::jsonb),
      'log', coalesce((select jsonb_agg(jsonb_build_object('at', l.at, 'who', l.actor_name, 'action', l.action, 'note', l.note) order by l.at desc)
        from (select * from sharia_board_log where board_id = b.id order by at desc limit 20) l), '[]'::jsonb));
  end if;
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'name', me.full_name, 'role', me.role, 'role_title', _role_title(me.role), 'code', me.staff_code,
      'head', me.role = 'sharia_head', 'secretary', me.role = 'sharia_secretary', 'voter', me.role in ('sharia_head', 'sharia_member') and _sh_fit_ok(b.id, me.id),
      'fit', _sh_fit_ok(b.id, me.id), 'central_head', me.role = 'sharia_head' and b.scope = 'central'),
    'board', jsonb_build_object('id', b.id, 'code', b.code, 'name', b.name, 'scope', b.scope, 'madhhab', b.madhhab, 'madhhab_label', _sh_madhhab_label(b.madhhab),
      'marja', b.marja, 'quorum', b.quorum, 'majority', b.majority, 'chair_casting', b.chair_casting, 'review_months', b.review_months, 'late_rule', b.late_rule, 'late_kind', b.late_kind,
      'approval_scope', c.approval_scope, 'bank', (select name from orgs where id = b.bank_id), 'voters', _sh_voters(b.id), 'members', _sh_members_json(b)),
    'products', coalesce((select jsonb_agg(_sh_row(p) order by p.updated_at desc) from islamic_products p where p.board_id = b.id and p.status <> 'draft'), '[]'::jsonb),
    'types', coalesce((select jsonb_agg(to_jsonb(t) order by t.sort) from sharia_contract_types t), '[]'::jsonb),
    'resolutions', coalesce((select jsonb_agg(_sh_res_json(r) order by r.issued_at desc) from sharia_resolutions r where r.board_id = b.id), '[]'::jsonb),
    'oversight', ov, 'parent', par);
end $f$;

create or replace function public.sharia_product(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; me profiles; side text; cur islamic_contract_versions; prev islamic_contract_versions; b sharia_boards; t sharia_contract_types; mb sharia_boards;
begin
  select * into me from profiles where id = auth.uid();
  select * into p from islamic_products where id = p_id;
  if p.id is null then raise exception 'المنتج غير موجود'; end if;
  if me.portal = 'sharia' then
    perform _sh_me(); mb := _sh_my_board();
    side := case when mb.id = p.board_id then 'board' when mb.scope = 'central' then 'supervisor' end;   -- الجلسة 44
    if side is null then raise exception 'هذا المنتج لدى هيئة أخرى'; end if;
  else
    side := case when me.portal = 'bank' and p.bank_id = me.org_id then 'bank' when me.portal in ('cbi', 'integrity', 'audit', 'admin') then 'viewer' end;
  end if;
  if side is null then raise exception 'لا صلاحية للاطلاع على هذا المنتج'; end if;
  if side in ('board', 'supervisor') and p.status = 'draft' then raise exception 'المنتج مسودة لدى المصرف ولم يُقدَّم بعد'; end if;
  select * into cur from islamic_contract_versions where id = p.current_version_id;
  select * into prev from islamic_contract_versions where product_id = p.id and n < coalesce(cur.n, 0) order by n desc limit 1;
  select * into b from sharia_boards where id = p.board_id;
  select * into t from sharia_contract_types where code = p.contract_type;
  return _sh_row(p) || jsonb_build_object(
    'side', side, 'pricing', p.pricing, 'guarantees', p.guarantees, 'attachments', p.attachments,
    'type_rules', t.rules, 'type_essence', t.essence, 'type_line', t.borrower_line,
    'board', jsonb_build_object('name', b.name, 'scope', b.scope, 'madhhab_label', _sh_madhhab_label(b.madhhab), 'marja', b.marja, 'quorum', b.quorum, 'majority', b.majority, 'chair_casting', b.chair_casting),
    'current', case when cur.id is null then null else jsonb_build_object('id', cur.id, 'n', cur.n, 'clauses', cur.clauses, 'sha256', cur.sha256, 'status', cur.status,
      'change_note', cur.change_note, 'by', cur.created_by_name, 'at', cur.created_at) end,
    'previous', case when prev.id is null then null else jsonb_build_object('id', prev.id, 'n', prev.n, 'clauses', prev.clauses, 'sha256', prev.sha256, 'at', prev.created_at) end,
    'version_list', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'n', v.n, 'status', v.status, 'sha256', v.sha256, 'at', v.created_at, 'by', v.created_by_name,
      'change_note', v.change_note, 'clauses', v.clauses) order by v.n desc) from islamic_contract_versions v where v.product_id = p.id), '[]'::jsonb),
    'approved_version', (select jsonb_build_object('n', n, 'sha256', sha256) from islamic_contract_versions where id = p.approved_version_id),
    'reviews', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'clause_n', r.clause_n, 'parent_id', r.parent_id, 'author', r.author_name, 'side', r.author_side,
      'body', r.body, 'resolved', r.resolved, 'at', r.created_at, 'version', v.n, 'mine', r.author_id = auth.uid()) order by r.created_at)
      from sharia_reviews r join islamic_contract_versions v on v.id = r.version_id where r.product_id = p.id), '[]'::jsonb),
    'votes', case when side = 'bank' then '[]'::jsonb else coalesce((select jsonb_agg(jsonb_build_object('name', member_name, 'head', is_head, 'vote', vote, 'condition', condition, 'reason', reason, 'at', at,
      'mine', member_id = auth.uid(), 'counts', _sh_fit_ok(p.board_id, member_id)) order by at) from sharia_votes where version_id = p.current_version_id), '[]'::jsonb) end,
    'tally', _sh_tally(p.id),
    'resolutions_list', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision),
      'body', r.body, 'conditions', r.conditions, 'votes', r.votes, 'dissent', r.dissent, 'version_sha256', r.version_sha256, 'seal', r.seal,
      'signed_by', r.signed_by_name, 'signed_code', r.signed_by_code, 'signed_via', r.signed_via, 'issued_at', r.issued_at,
      'board', (select name from sharia_boards where id = r.board_id),
      'version', (select n from islamic_contract_versions where id = r.version_id)) order by r.issued_at desc) from sharia_resolutions r where r.product_id = p.id), '[]'::jsonb),
    'log', coalesce((select jsonb_agg(jsonb_build_object('at', at, 'who', actor_name, 'code', actor_code, 'side', actor_side, 'action', action, 'note', note) order by at desc)
      from sharia_log where product_id = p.id), '[]'::jsonb),
    'checklist', jsonb_build_array(
      jsonb_build_object('k', 'name', 'label', 'اسم المنتج وسطر يشرح الصيغة للمقترض', 'ok', length(coalesce(p.name, '')) >= 3 and length(coalesce(p.line, '')) >= 10),
      jsonb_build_object('k', 'type', 'label', 'الصيغة من المكتبة ومسموحة', 'ok', coalesce(t.allowed, false)),
      jsonb_build_object('k', 'sector', 'label', 'الصيغة مناسبة للقطاع', 'ok', p.sector = any(coalesce(t.sectors, '{}'))),
      jsonb_build_object('k', 'pricing', 'label', 'قواعد التسعير: ربح أدنى وأعلى ومدد', 'ok', (p.pricing ? 'profit_max') and (p.pricing ? 'term_max')),
      jsonb_build_object('k', 'guarantees', 'label', 'الضمانات المسموحة', 'ok', cardinality(p.guarantees) > 0),
      jsonb_build_object('k', 'clauses', 'label', 'نموذج العقد ببنود مرقّمة (5 بنود على الأقل)', 'ok', jsonb_array_length(coalesce(cur.clauses, '[]'::jsonb)) >= 5),
      jsonb_build_object('k', 'late', 'label', 'بند التأخر في السداد بلا زيادة لمصلحة المصرف', 'ok', exists (select 1 from jsonb_array_elements(coalesce(cur.clauses, '[]'::jsonb)) c where c->>'title' like '%تأخر%')),
      jsonb_build_object('k', 'attachments', 'label', 'الملحقات (طلب الشراء أو الوعد، المحضر، جدول الأقساط)', 'ok', cardinality(p.attachments) >= 2)));
end $f$;

-- قائمة التوقيع الإلكتروني: هيئة المصرف ترى قراراتها فقط
create or replace function public.sharia_esign_list() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; mb sharia_boards;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal not in ('sharia', 'cbi', 'audit', 'integrity', 'admin') then raise exception 'غير مخوّل'; end if;
  if me.portal = 'sharia' then mb := _sh_my_board(); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code,
      'status', case when r.esign_status = 'sent' and r.esign_expires < now() then 'expired' else r.esign_status end,
      'at', r.esign_at, 'cert', r.esign_cert, 'qualified', r.esign_qualified, 'expires', r.esign_expires,
      'url', case when me.id = r.signed_by and r.esign_status = 'sent' and r.esign_expires > now() then r.esign_url end,
      'mine', me.id = r.signed_by) order by r.issued_at desc) from sharia_resolutions r
    where mb.id is null or mb.scope = 'central' or r.board_id = mb.id), '[]'::jsonb);
end $f$;

-- ───────── 10) تقرير الامتثال: لكل هيئة مصرف، ويجمعها تقرير البنك المركزي ─────────
drop function if exists public.sharia_compliance_report(date, date);
drop function if exists public._scr_build(date, date);

create or replace function public._scr_build(p_from date, p_to date, p_bank uuid default null) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare t0 timestamptz := (p_from::timestamp at time zone 'Asia/Baghdad'); t1 timestamptz := ((p_to + 1)::timestamp at time zone 'Asia/Baghdad');
  b sharia_boards; checks jsonb := '[]'; banks jsonb; prods jsonb; ress jsonb; docs jsonb; late jsonb; n int; lst jsonb; tot jsonb; boards jsonb; breps jsonb;
begin
  if p_from is null or p_to is null or p_to < p_from then raise exception 'اختر فترة صحيحة'; end if;
  if p_to - p_from > 400 then raise exception 'الفترة سنة واحدة كحد أقصى'; end if;
  if p_bank is null then b := _sh_central(); else select * into b from sharia_boards where scope = 'bank' and bank_id = p_bank; end if;
  if b.id is null then b := _sh_central(); end if;

  create temp table if not exists _scr_apps (id uuid, code text, bank_id uuid, program text, t text, stage int, status text, amount numeric,
    submitted_at timestamptz, product_id uuid) on commit drop;
  truncate _scr_apps;
  insert into _scr_apps
  select a.id, a.code, a.bank_id, coalesce(a.program, 'solar'), _isl_type(a), a.stage, a.status, a.amount, a.submitted_at, a.product_id
  from applications a join orgs o on o.id = a.bank_id
  where coalesce(o.is_islamic, false) and a.stage > 5 and a.status <> 'cancelled' and (p_bank is null or a.bank_id = p_bank);

  select count(*), coalesce(jsonb_agg(code), '[]') into n, lst from _scr_apps where product_id is null and submitted_at >= t0 and submitted_at < t1;
  checks := checks || jsonb_build_object('k', 'no_product', 'label', 'طلبات أُرسلت إلى مصرف إسلامي دون منتج معتمد شرعاً', 'kind', 'guard', 'count', n, 'items', lst,
    'note', (select case when count(*) > 0 then count(*) || ' طلب قديم أُرسل قبل الفترة أو قبل تفعيل المنتجات (الجلسة 39) — لا يدخل في العدّ' end from _scr_apps where product_id is null and (submitted_at < t0 or submitted_at is null)));
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where _isl_two_phase(x.t) and (_isl_doc(x.id, 'contract')).at < coalesce((_isl_doc(x.id, 'receipt')).at, 'infinity');
  checks := checks || jsonb_build_object('k', 'contract_before_receipt', 'label', 'المرابحة والإجارة: عقد وُقّع قبل تملّك المصرف وقبضه', 'kind', 'guard', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x where x.t is not null and x.stage > 33 and (_isl_doc(x.id, 'contract')).id is null;
  checks := checks || jsonb_build_object('k', 'exec_no_contract', 'label', 'تمويل نُفّذ دون عقد معتمد موقّع', 'kind', 'guard', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x where _isl_two_phase(x.t) and x.stage > 31 and (_isl_doc(x.id, 'invoice')).id is null;
  checks := checks || jsonb_build_object('k', 'no_invoice', 'label', 'المرابحة والإجارة: تركيب أُنجز دون فاتورة المورد باسم المصرف', 'kind', 'guard', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(z.code), '[]') into n, lst from (
    select x.code from _scr_apps x cross join lateral (select (_isl_doc(x.id, 'contract')).body->'calc'->>'total' tot) c
      cross join lateral (select count(*) cnt, coalesce(sum(i.amount), 0) s from installments i where i.application_id = x.id) i
    where c.tot is not null and i.cnt > 0 and abs(i.s - c.tot::numeric) > greatest(i.cnt * 2, c.tot::numeric * 0.0005)) z;
  checks := checks || jsonb_build_object('k', 'schedule_mismatch', 'label', 'جدول أقساط لا يساوي الثمن في العقد الموقّع', 'kind', 'guard', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where x.t = 'IJM' and (select min(due_date) from installments where application_id = x.id) <= ((_isl_doc(x.id, 'receipt')).at at time zone 'Asia/Baghdad')::date;
  checks := checks || jsonb_build_object('k', 'rent_before_delivery', 'label', 'الإجارة: أجرة مستحقة قبل تسليم الأصل', 'kind', 'guard', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(p.code || ' ' || p.name), '[]') into n, lst from islamic_products p
  where p.status in ('approved', 'conditional') and p.review_due < p_to and (p_bank is null or p.bank_id = p_bank);
  checks := checks || jsonb_build_object('k', 'review_overdue', 'label', 'منتجات نافذة تجاوزت موعد المراجعة الدورية', 'kind', 'warn', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(r.code), '[]') into n, lst from sharia_resolutions r join islamic_products p on p.id = r.product_id
  where r.issued_at >= t0 and r.issued_at < t1 and r.esign_status is distinct from 'signed' and (p_bank is null or p.bank_id = p_bank);
  checks := checks || jsonb_build_object('k', 'res_unsigned', 'label', 'قرارات الفترة دون توقيع إلكتروني موثوق من الرئيس (نافذة برمز التحقق)', 'kind', 'warn', 'count', n, 'items', lst);
  select count(*), coalesce(jsonb_agg(x.code), '[]') into n, lst from _scr_apps x
  where x.t is not null and exists (select 1 from application_events e where e.application_id = x.id and e.action = 'إرسال عقد التمويل والكمبيالة إلى المقترض للتوقيع الإلكتروني' and e.created_at >= t0 and e.created_at < t1);
  checks := checks || jsonb_build_object('k', 'kambiala', 'label', 'طلبات إسلامية أُرسل فيها «عقد التمويل والكمبيالة» بدل التعهدات والضمانات', 'kind', 'guard', 'count', n, 'items', lst);
  checks := checks || jsonb_build_object('k', 'no_late_increase', 'label', 'زيادة على قسط متأخر لمصلحة المصرف', 'kind', 'guard', 'count', 0, 'items', '[]'::jsonb,
    'note', 'ممنوعة آلياً بمشغّل على جدول الأقساط — لا يمكن تسجيلها');
  -- الجلسة 44: الهيئات — منتجات بصيغة ممنوعة، واعتمادات مركزية موروثة بانتظار هيئة المصرف، وأعضاء بانتظار الملاءمة
  select count(*), coalesce(jsonb_agg(p.code || ' ' || p.name), '[]') into n, lst from islamic_products p join sharia_contract_types t on t.code = p.contract_type
  where p.status in ('approved', 'conditional') and not t.allowed and (p_bank is null or p.bank_id = p_bank);
  checks := checks || jsonb_build_object('k', 'type_not_allowed', 'label', 'منتجات نافذة بصيغة منعتها الهيئة المركزية', 'kind', 'warn', 'count', n, 'items', lst,
    'note', 'تبقى نافذة حتى تعلّقها الهيئة أو تسحب اعتمادها — لا يُعتمد عليها منتج جديد');
  select count(*), coalesce(jsonb_agg(p.code || ' ' || p.name || coalesce(' — حتى ' || p.review_due, '')), '[]') into n, lst from islamic_products p
  where _sh_inherited(p) and (p_bank is null or p.bank_id = p_bank);
  checks := checks || jsonb_build_object('k', 'inherited', 'label', 'منتجات معتمدة مركزياً لم تُعِد هيئة مصرفها اعتمادها بعد', 'kind', 'warn', 'count', n, 'items', lst,
    'note', 'نافذة حتى إعادة الاعتماد أو موعد المراجعة الدورية');
  select count(*), coalesce(jsonb_agg(pr.full_name || ' — ' || x.name), '[]') into n, lst from sharia_members m join sharia_boards x on x.id = m.board_id join profiles pr on pr.id = m.profile_id
  where x.scope = 'bank' and m.fit_status = 'pending' and (p_bank is null or x.bank_id = p_bank);
  checks := checks || jsonb_build_object('k', 'fit_pending', 'label', 'أعضاء هيئات مصارف بانتظار ملاءمة الهيئة المركزية', 'kind', 'warn', 'count', n, 'items', lst);

  select coalesce(jsonb_agg(jsonb_build_object('bank', o.name, 'bank_id', o.id,
      'board', (select name from sharia_boards where id = _sh_board_for(o.id)),
      'products_live', (select count(*) from islamic_products p where p.bank_id = o.id and p.status in ('approved', 'conditional')),
      'products_all', (select count(*) from islamic_products p where p.bank_id = o.id and p.status not in ('draft')),
      'apps', (select count(*) from _scr_apps x where x.bank_id = o.id),
      'apps_islamic', (select count(*) from _scr_apps x where x.bank_id = o.id and x.t is not null),
      'apps_new', (select count(*) from _scr_apps x where x.bank_id = o.id and x.submitted_at >= t0 and x.submitted_at < t1),
      'financed', (select coalesce(sum(x.amount), 0) from _scr_apps x where x.bank_id = o.id and x.t is not null and x.stage > 33),
      'contracts', (select count(*) from islamic_app_docs d join _scr_apps x on x.id = d.application_id where x.bank_id = o.id and d.kind = 'contract' and not d.void and d.at >= t0 and d.at < t1),
      'by_type', (select coalesce(jsonb_object_agg(t, c), '{}') from (select x.t, count(*) c from _scr_apps x where x.bank_id = o.id and x.t is not null group by x.t) z))
    order by o.name), '[]') into banks
  from orgs o where o.type = 'bank' and coalesce(o.is_islamic, false) and (p_bank is null or o.id = p_bank);

  select coalesce(jsonb_agg(jsonb_build_object('code', p.code, 'name', p.name, 'bank', (select name from orgs where id = p.bank_id), 'type', p.contract_type,
      'sector', _sh_sector_label(p.sector, p.subsector), 'status', p.status, 'status_label', _sh_status_label(p.status), 'review_due', p.review_due,
      'board', (select name from sharia_boards where id = p.board_id), 'inherited', _sh_inherited(p),
      'resolution', (select code from sharia_resolutions where id = p.resolution_id)) order by p.code), '[]') into prods
  from islamic_products p where p.status <> 'draft' and (p_bank is null or p.bank_id = p_bank);

  select coalesce(jsonb_agg(jsonb_build_object('code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision), 'product', p.name,
      'bank', (select name from orgs where id = p.bank_id), 'board', (select name from sharia_boards where id = r.board_id),
      'issued_at', r.issued_at, 'esign', coalesce(r.esign_status, 'none'), 'cert', r.esign_cert) order by r.issued_at), '[]') into ress
  from sharia_resolutions r join islamic_products p on p.id = r.product_id where r.issued_at >= t0 and r.issued_at < t1 and (p_bank is null or p.bank_id = p_bank);

  select coalesce(jsonb_object_agg(kind, c), '{}') into docs from (
    select d.kind, count(*) c from islamic_app_docs d join applications a on a.id = d.application_id
    where not d.void and d.at >= t0 and d.at < t1 and (p_bank is null or a.bank_id = p_bank) group by d.kind) z;

  late := jsonb_build_object('kind', b.late_kind, 'rule', b.late_rule,
    'overdue_count', (select count(*) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at is null and i.due_date < least(p_to, current_date)),
    'overdue_amount', (select coalesce(sum(i.amount), 0) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at is null and i.due_date < least(p_to, current_date)),
    'charity_count', (select count(*) from islamic_charity c join applications a on a.id = c.application_id where c.at >= t0 and c.at < t1 and (p_bank is null or a.bank_id = p_bank)),
    'charity_amount', (select coalesce(sum(c.amount), 0) from islamic_charity c join applications a on a.id = c.application_id where c.at >= t0 and c.at < t1 and (p_bank is null or a.bank_id = p_bank)),
    'paid_in_period', (select coalesce(sum(i.amount), 0) from installments i join _scr_apps x on x.id = i.application_id where x.t is not null and i.paid_at >= t0 and i.paid_at < t1));

  -- الهيئات الشرعية وتقاريرها الصادرة للفترة (في التقرير الجامع للبنك المركزي)
  select coalesce(jsonb_agg(jsonb_build_object('code', x.code, 'name', x.name, 'scope', x.scope, 'bank', (select name from orgs where id = x.bank_id),
      'members', (select count(*) from sharia_members m join profiles pr on pr.id = m.profile_id where m.board_id = x.id and not coalesce(pr.disabled, false) and m.fit_status = 'approved'),
      'fit_pending', (select count(*) from sharia_members m where m.board_id = x.id and m.fit_status = 'pending'),
      'quorum', x.quorum, 'voters', _sh_voters(x.id), 'ready', x.scope = 'central' or _sh_board_ready(x.id),
      'active', x.scope = 'central' or _sh_board_for(x.bank_id) = x.id,
      'products_live', (select count(*) from islamic_products p where p.board_id = x.id and p.status in ('approved', 'conditional')),
      'resolutions', (select count(*) from sharia_resolutions r where r.board_id = x.id and r.issued_at >= t0 and r.issued_at < t1),
      'report', (select jsonb_build_object('code', s.code, 'from', s.period_from, 'to', s.period_to, 'violations', s.body->'totals'->'violations', 'warnings', s.body->'totals'->'warnings', 'issued_at', s.issued_at)
        from sharia_compliance_reports s where s.board_id = x.id and s.period_from <= p_to and s.period_to >= p_from order by s.issued_at desc limit 1))
    order by x.scope, x.name), '[]') into boards
  from sharia_boards x where p_bank is null or x.bank_id = p_bank;

  tot := jsonb_build_object('apps', (select count(*) from _scr_apps where t is not null), 'apps_new', (select count(*) from _scr_apps where t is not null and submitted_at >= t0 and submitted_at < t1),
    'vet', (select count(*) from _scr_apps where t is not null and program = 'vet'),
    'products_live', (select count(*) from islamic_products where status in ('approved', 'conditional') and (p_bank is null or bank_id = p_bank)),
    'resolutions', jsonb_array_length(ress), 'boards', jsonb_array_length(boards),
    'violations', (select coalesce(sum((c->>'count')::int), 0) from jsonb_array_elements(checks) c where c->>'kind' = 'guard'),
    'warnings', (select coalesce(sum((c->>'count')::int), 0) from jsonb_array_elements(checks) c where c->>'kind' = 'warn'));

  return jsonb_build_object('from', p_from, 'to', p_to, 'generated_at', now(), 'board', b.name, 'board_code', b.code, 'scope', case when p_bank is null then 'all' else 'bank' end,
    'bank', (select name from orgs where id = p_bank), 'madhhab', _sh_madhhab_label(b.madhhab), 'marja', b.marja,
    'totals', tot, 'checks', checks, 'banks', banks, 'products', prods, 'resolutions', ress, 'docs', docs, 'late', late, 'boards', boards);
end $f$;

-- نطاق التقرير لمن يطلبه: هيئة المصرف ← مصرفها؛ غيرها ← كل المصارف أو هيئة مختارة
create or replace function public._scr_bank_for(p_board uuid) returns uuid
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; mb sharia_boards;
begin
  me := _scr_can();
  if me.portal = 'sharia' then
    mb := _sh_my_board();
    if mb.scope = 'bank' then return mb.bank_id; end if;
  end if;
  if p_board is null then return null; end if;
  return (select bank_id from sharia_boards where id = p_board);
end $f$;

create or replace function public.sharia_compliance_report(p_from date, p_to date, p_board uuid default null) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare v_bank uuid := _scr_bank_for(p_board); v_bid uuid;
begin
  v_bid := case when v_bank is null then (_sh_central()).id else (select id from sharia_boards where scope = 'bank' and bank_id = v_bank) end;
  return _scr_build(p_from, p_to, v_bank) || jsonb_build_object('issued', (select jsonb_build_object('code', code, 'issued_at', issued_at, 'sha256', sha256)
      from sharia_compliance_reports where period_from = p_from and period_to = p_to and board_id = v_bid order by issued_at desc limit 1),
    'board_filter', coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'name', x.name, 'scope', x.scope) order by x.scope, x.name) from sharia_boards x), '[]'::jsonb),
    'board_id', v_bid);
end $f$;

create or replace function public.sharia_compliance_issue(p_from date, p_to date, p_label text, p_otp text) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; mb sharia_boards; body jsonb; v_code text; v_sha text; r sharia_compliance_reports; v_n int; v_bank uuid;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إصدار التقرير الدوري لرئيس الهيئة'; end if;
  mb := _sh_my_board();
  if mb.scope = 'bank' and not _sh_fit_ok(mb.id, me.id) then raise exception 'إصدار التقرير بعد أن تعتمد الهيئة المركزية ملاءمتك'; end if;
  if not _otp_ok(p_otp, me.phone) then raise exception 'رمز التحقق غير صحيح — لم يصدر التقرير'; end if;
  if p_to >= (now() at time zone 'Asia/Baghdad')::date then raise exception 'يصدر التقرير بعد انتهاء الفترة — اختر فترة منتهية'; end if;
  if exists (select 1 from sharia_compliance_reports where period_from = p_from and period_to = p_to and board_id = mb.id) then raise exception 'صدر تقرير هذه الفترة سابقاً'; end if;
  perform pg_advisory_xact_lock(hashtext('sharia_compliance_reports'));
  v_bank := case when mb.scope = 'bank' then mb.bank_id end;
  body := _scr_build(p_from, p_to, v_bank);
  select count(*) + 1 into v_n from sharia_compliance_reports where extract(year from issued_at) = extract(year from now());
  v_code := 'SCR-' || to_char(now(), 'YYYY') || '-' || lpad(v_n::text, 3, '0');
  v_sha := encode(extensions.digest(v_code || '|' || body::text, 'sha256'), 'hex');
  insert into sharia_compliance_reports(code, board_id, bank_id, period_from, period_to, period_label, body, sha256, issued_by, issued_by_name, signed_via)
  values (v_code, mb.id, v_bank, p_from, p_to, nullif(trim(coalesce(p_label, '')), ''), body, v_sha, me.id, me.full_name, 'رمز تحقق على هاتف الرئيس') returning * into r;
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_report', 'تقرير الامتثال الشرعي ' || v_code || ' — ' || mb.name || coalesce(' — ' || r.period_label, ''),
    'المخالفات ' || (body->'totals'->>'violations') || ' · الملاحظات ' || (body->'totals'->>'warnings') || ' · من ' || p_from || ' إلى ' || p_to, r.id);
  if mb.scope = 'bank' then
    perform _sh_notify((_sh_central()).org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_oversight', 'تقرير امتثال ' || mb.name || ' ' || v_code,
      'المخالفات ' || (body->'totals'->>'violations') || ' · الملاحظات ' || (body->'totals'->>'warnings') || ' · من ' || p_from || ' إلى ' || p_to, r.id);
  end if;
  return jsonb_build_object('code', v_code, 'sha256', v_sha, 'issued_at', r.issued_at);
end $f$;

create or replace function public.sharia_compliance_list() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; mb sharia_boards;
begin
  me := _scr_can();
  if me.portal = 'sharia' then mb := _sh_my_board(); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'code', s.code, 'from', s.period_from, 'to', s.period_to, 'label', s.period_label, 'sha256', s.sha256,
    'issued_at', s.issued_at, 'issued_by', s.issued_by_name, 'violations', s.body->'totals'->'violations', 'warnings', s.body->'totals'->'warnings',
    'cbi_seen_at', s.cbi_seen_at, 'board', (select name from sharia_boards where id = s.board_id), 'board_scope', (select scope from sharia_boards where id = s.board_id))
    order by s.issued_at desc) from sharia_compliance_reports s where mb.id is null or mb.scope = 'central' or s.board_id = mb.id), '[]'::jsonb);
end $f$;

create or replace function public.sharia_compliance_get(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; r sharia_compliance_reports; mb sharia_boards;
begin
  me := _scr_can();
  select * into r from sharia_compliance_reports where id = p_id;
  if r.id is null then raise exception 'التقرير غير موجود'; end if;
  if me.portal = 'sharia' then
    mb := _sh_my_board();
    if mb.scope = 'bank' and r.board_id is distinct from mb.id then raise exception 'التقرير لهيئة أخرى'; end if;
  end if;
  if me.portal = 'cbi' and r.cbi_seen_at is null then
    update sharia_compliance_reports set cbi_seen_at = now(), cbi_seen_by = me.full_name || ' — ' || _role_title(me.role) where id = r.id;
  end if;
  return r.body || jsonb_build_object('issued', jsonb_build_object('code', r.code, 'issued_at', r.issued_at, 'issued_by', r.issued_by_name, 'sha256', r.sha256,
    'intact', encode(extensions.digest(r.code || '|' || r.body::text, 'sha256'), 'hex') = r.sha256, 'label', r.period_label,
    'board', (select name from sharia_boards where id = r.board_id)));
end $f$;

-- ───────── 11) الصلاحيات على الدوال ─────────
revoke all on function public._sh_central(), public._sh_my_board(), public._sh_fit_ok(uuid, uuid), public._sh_board_ready(uuid), public._sh_board_missing(uuid),
  public._sh_inherited(islamic_products), public._sh_live(islamic_products), public._sh_board_log(uuid, text, text), public._sh_fit_code(), public._sh_member_sync(),
  public._sh_own(islamic_products), public._sh_central_head(), public._sh_members_json(sharia_boards), public._sh_res_json(sharia_resolutions),
  public._scr_build(date, date, uuid), public._scr_bank_for(uuid) from public, anon, authenticated;
-- تُستدعى من سياسات الجداول لكل مستخدم
grant execute on function public._sh_sees_board(uuid) to authenticated;
grant execute on function public.sharia_board_create(jsonb), public.sharia_fit_decide(uuid, uuid, jsonb), public.sharia_type_allow(text, boolean, text),
  public.sharia_compliance_report(date, date, uuid) to authenticated;
revoke all on function public.sharia_board_create(jsonb), public.sharia_fit_decide(uuid, uuid, jsonb), public.sharia_type_allow(text, boolean, text),
  public.sharia_compliance_report(date, date, uuid) from anon;

-- ───────── 12) العرض: هيئة الرقابة الشرعية لمصرف الواحة الإسلامي (مرة واحدة) ─────────
-- الرئيس عيّنته الهيئة المركزية (ملاءمة معتمدة)، وعضو بملاءمة، وأمين سر، وعضوة مرشّحة بانتظار الملاءمة (تعتمدها الهيئة المركزية من «هيئات المصارف»).
-- نطاق الاعتماد مصرفي: منتجات الواحة الجديدة تعتمدها هيئتها، والاعتمادات المركزية السابقة نافذة حتى إعادة الاعتماد.
-- ومنتج جديد «منظومة المزرعة بالمرابحة» قيد المداولة لدى هيئة المصرف: صوّت العضو، وبقي صوت الرئيس وقراره.
-- الأسماء تجريبية تُستبدل بأسماء الأعضاء الحقيقيين.
do $$
declare bk orgs; c sharia_boards; o orgs; b sharia_boards; r text[]; rows text[][] := array[
  ['wsh.head', 'Wsh@2026hd', 'الشيخ د. باقر حسن الصافي',      'sharia_head',      'فقه المعاملات المصرفية', 'approved'],
  ['wsh.m1',   'Wsh@2026m1', 'السيد د. مرتضى علي الحسيني',     'sharia_member',    'فقه العقود',             'approved'],
  ['wsh.m2',   'Wsh@2026m2', 'د. نرجس كاظم الطائي',            'sharia_member',    'المصرفية الإسلامية',     'pending'],
  ['wsh.sec',  'Wsh@2026sc', 'م. حوراء سعد العامري',           'sharia_secretary', 'أمانة السر',              'approved']];
  i int; uid uuid; ch uuid; v_p jsonb; pid uuid; cl jsonb;
begin
  select * into bk from orgs where code = 'bank2' and type = 'bank';
  if bk.id is null then select * into bk from orgs where type = 'bank' and is_islamic order by code limit 1; end if;
  c := _sh_central();
  if bk.id is null or c.id is null then return; end if;
  if exists (select 1 from sharia_boards where scope = 'bank' and bank_id = bk.id) then return; end if;
  select id into ch from profiles where username = 'sharia.head';

  insert into orgs(code, type, name, is_islamic, meta) values ('shwah', 'sharia', 'هيئة الرقابة الشرعية — مصرف الواحة الإسلامي', false,
    jsonb_build_object('kind', 'sharia_bank', 'bank_id', bk.id, 'onboarded_at', now(), 'onboarded_by', 'الجلسة 44 — بيانات العرض'))
  on conflict (code) do nothing;
  select * into o from orgs where code = 'shwah';
  insert into sharia_boards(code, name, scope, org_id, bank_id, madhhab, marja, quorum, majority, chair_casting, review_months, late_kind, late_rule, parent_id, created_by_name, created_at)
  values ('SHB-WAH', o.name, 'bank', o.id, bk.id, c.madhhab, c.marja, 2, 'simple', true, c.review_months, c.late_kind, c.late_rule, c.id,
    (select full_name from profiles where id = ch), now() - interval '6 days')
  returning * into b;
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from profiles where username = rows[i][1]) then
      perform _mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'sharia', 'shwah', null, null);
    end if;
    select id into uid from profiles where username = rows[i][1];
    update profiles set manage_scope = case when rows[i][4] = 'sharia_head' then 'org' else manage_scope end,
      managed_by = case when rows[i][4] = 'sharia_head' then ch else (select id from profiles where username = 'wsh.head') end
    where id = uid;
    insert into sharia_members(board_id, profile_id, role) values (b.id, uid, case rows[i][4] when 'sharia_head' then 'head' when 'sharia_secretary' then 'secretary' else 'member' end)
    on conflict do nothing;
    update sharia_members set specialty = rows[i][5], fit_status = rows[i][6], nominated_at = now() - interval '5 days',
      fit_code = case when rows[i][6] = 'approved' then 'FT-' || to_char(now(), 'YYYY') || '-' || lpad(i::text, 4, '0') end,
      fit_by_name = case when rows[i][6] = 'approved' then (select full_name from profiles where id = ch) end,
      fit_at = case when rows[i][6] = 'approved' then now() - interval '4 days' end,
      fit_note = case when rows[i][4] = 'sharia_head' then 'عيّنته الهيئة المركزية عند إنشاء الهيئة' end
    where board_id = b.id and profile_id = uid;
  end loop;
  -- سجل العرض يُكتب يدوياً بتسلسله الزمني (بدل ما كتبه المشغّل الآلي لحظة إنشاء الحسابات)، وإشعار ملاءمة واحد للمرشّحة
  delete from sharia_board_log where board_id = b.id;
  delete from notifications where kind = 'sharia_fit' and ref_id = b.id;
  perform _sh_notify(c.org_id, 'sharia', array['sharia_head', 'sharia_secretary'], 'sharia_fit', 'عضو جديد في ' || b.name || ' بانتظار الملاءمة',
    rows[3][3] || ' — ' || _role_title(rows[3][4]) || '. لا يُحسب صوتها حتى تعتمدوا ملاءمتها', b.id);
  insert into sharia_board_log(board_id, at, actor_name, action, note) values
    (b.id, now() - interval '6 days', (select full_name from profiles where id = ch), 'إنشاء الهيئة وتعيين رئيسها: ' || rows[1][3], 'النصاب 2'),
    (b.id, now() - interval '5 days', rows[1][3], 'ترشيح الأعضاء: ' || rows[2][3] || '، ' || rows[3][3] || '، ' || rows[4][3], 'بانتظار ملاءمة الهيئة المركزية'),
    (b.id, now() - interval '4 days', (select full_name from profiles where id = ch), 'اعتماد ملاءمة: ' || rows[2][3] || '، ' || rows[4][3], null),
    (c.id, now() - interval '6 days', (select full_name from profiles where id = ch), 'إنشاء ' || o.name, bk.name);
  -- نطاق الاعتماد مصرفي (اكتملت هيئة الواحة: رئيس وعضو بملاءمة = النصاب 2)
  update sharia_boards set approval_scope = 'bank', updated_at = now() where id = c.id;
  insert into sharia_board_log(board_id, at, actor_name, action, note) values (c.id, now() - interval '4 days', (select full_name from profiles where id = ch),
    'نطاق الاعتماد: مصرفي — كل مصرف تعتمد منتجاته هيئته متى اكتملت', 'القرارات السابقة تبقى نافذة حتى إعادة الاعتماد أو المراجعة الدورية');

  -- منتج جديد للمزارعين بالمرابحة، بدوال المنصة نفسها: المصرف يكتب ويقدّم ← أمين السر يحيل ← العضو يصوّت
  if exists (select 1 from islamic_products where bank_id = bk.id and name = 'منظومة المزرعة بالمرابحة') then return; end if;
  select v.clauses into cl from islamic_products p join islamic_contract_versions v on v.id = p.approved_version_id where p.bank_id = bk.id and p.contract_type = 'MRB' and p.sector = 'pv' order by p.code limit 1;
  if cl is null then return; end if;
  uid := (select id from profiles where username = 'wah.products');
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);
  v_p := islamic_product_save(null, jsonb_build_object('contract_type', 'MRB', 'sector', 'pv', 'subsector', 'agri', 'name', 'منظومة المزرعة بالمرابحة',
    'line', 'يشتري المصرف منظومة الضخ والطاقة للمزرعة ويملكها، ثم يبيعها لك بربح معلوم تسدده على أقساط.',
    'pricing', jsonb_build_object('profit_min', 4, 'profit_max', 7, 'term_min', 12, 'term_max', 84),
    'guarantees', jsonb_build_array('single_salary', 'multi_salary', 'gold', 'mortgage'),
    'attachments', jsonb_build_array('طلب الشراء والوعد غير الملزم', 'فاتورة المورد باسم المصرف', 'محضر الاستلام والقبض', 'جدول الأقساط')));
  pid := (v_p->>'id')::uuid;
  perform islamic_version_save(pid, jsonb_build_object('clauses', cl, 'change_note', 'نموذج المرابحة المعتمد مكيَّفاً لمنظومات المزارع'));
  perform islamic_product_submit(pid);
  uid := (select id from profiles where username = 'wsh.sec');
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);
  perform sharia_screen(pid, '{"action":"refer","note":"الملف مكتمل — أحيل للأعضاء"}'::jsonb);
  uid := (select id from profiles where username = 'wsh.m1');
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);
  perform sharia_comment(pid, '{"clause_n":3,"body":"يُذكر في المبيع أنها منظومة ضخ وطاقة للمزرعة مع موقعها، لتعيين المبيع تعييناً نافياً للجهالة."}'::jsonb);
  perform sharia_vote(pid, '{"vote":"approve"}'::jsonb);
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  update islamic_products set submitted_at = now() - interval '2 days' where id = pid;
end $$;
