-- ═══════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 41: الهيئة الشرعية — الحزمة 2
--  1) الحرّاس الآليون في مسار المصرف الإسلامي (مقروءة من صيغة المنتج)
--  2) توقيع النص المعتمد نفسه ببصمته في المحطة 5، والمرابحة/الإجارة على مرحلتين (وعد غير ملزم ← عقد بعد تملّك المصرف)
--  3) «عقدي» للمقترض، ورمز تحقق (QR) يثبت أن النص الموقّع مطابق للنسخة المعتمدة
--  4) التأخر في السداد: لا زيادة على الدين المتأخر لمصلحة المصرف، والبديل بقرار الهيئة
--  5) تعديل منتج معتمد: نسخة جديدة تمر بالدورة كاملة، والمعتمدة نافذة حتى يصدر القرار الجديد
-- آمن للتكرار. يمس الطلبات التي فيها منتج إسلامي فقط؛ المصرف التجاري والطلبات القديمة دون منتج لا تتأثر.
-- ═══════════════════════════════════════════════════════════════

-- ───────── 0) أعمدة وجداول ─────────
alter table public.islamic_products drop constraint if exists islamic_products_status_check;
alter table public.islamic_products add constraint islamic_products_status_check check (status in
  ('draft', 'submitted', 'returned', 'deliberation', 'approved', 'conditional', 'rejected', 'suspended', 'withdrawn', 'superseded'));
alter table public.islamic_products add column if not exists amends_product_id uuid references public.islamic_products(id);

-- معالجة التأخر: نوعها (المطالبة والضمانات / تعويض ضرر فعلي تقرّه الهيئة / التزام بالتبرع لصندوق خيري) ونصها في late_rule
alter table public.sharia_boards add column if not exists late_kind text not null default 'claim';
alter table public.sharia_boards drop constraint if exists sharia_boards_late_kind_check;
alter table public.sharia_boards add constraint sharia_boards_late_kind_check check (late_kind in ('claim', 'damage', 'charity'));

-- مستندات التنفيذ الإسلامي لكل طلب: الوعد، فاتورة المورد باسم المصرف، محضر القبض، العقد، الحصص، عقود بيع الحصص
create table if not exists public.islamic_app_docs (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  kind text not null check (kind in ('promise', 'invoice', 'receipt', 'contract', 'shares', 'share_sale')),
  n int not null default 1,
  title text not null,
  product_id uuid, version_id uuid, version_sha256 text, resolution text,
  body jsonb not null default '{}'::jsonb,       -- النص الموقّع كما هو (البنود مملوءة) أو بيانات الفاتورة والمحضر
  doc_sha256 text,                               -- SHA-256 لـ body — أي تغيير في النص يغيّرها
  amount numeric,
  verify_code text unique,
  actor_id uuid, actor_name text, actor_title text, signed_via text,
  void boolean not null default false, void_note text,
  at timestamptz not null default now()
);
create index if not exists islamic_app_docs_app on public.islamic_app_docs(application_id, kind, at);
alter table public.islamic_app_docs enable row level security;   -- القراءة عبر الدوال فقط

-- التبرع لصندوق خيري عند التأخر (إن قررته الهيئة) — خارج إيرادات المصرف
create table if not exists public.islamic_charity (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  n int, amount numeric not null check (amount > 0), ref text not null,
  by_id uuid, by_name text, by_code text,
  at timestamptz not null default now()
);
alter table public.islamic_charity enable row level security;

-- ───────── 1) أدوات ─────────
create or replace function public._isl_two_phase(p_type text) returns boolean language sql immutable as $f$ select p_type in ('MRB', 'IJM') $f$;

create or replace function public._isl_sha(p jsonb) returns text language sql immutable set search_path to 'public', 'extensions' as $f$
  select encode(extensions.digest(convert_to(p::text, 'UTF8'), 'sha256'), 'hex') $f$;

create or replace function public._isl_code() returns text language plpgsql volatile set search_path to 'public', 'extensions' as $f$
declare c text; al text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; b bytea; i int;
begin
  loop
    b := extensions.gen_random_bytes(10); c := '';
    for i in 0..9 loop c := c || substr(al, (get_byte(b, i) % 32) + 1, 1); end loop;
    exit when not exists (select 1 from islamic_app_docs where verify_code = c);
  end loop;
  return c;
end $f$;

-- طلب إسلامي؟ (مصرف إسلامي + منتج) — يرجع صيغة المنتج أو null
create or replace function public._isl_type(a applications) returns text language sql stable security definer set search_path to 'public' as $f$
  select p.contract_type from islamic_products p join orgs o on o.id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid)
  where p.id = a.product_id and coalesce(o.is_islamic, false) $f$;

create or replace function public._isl_doc(p_app uuid, p_kind text) returns islamic_app_docs language sql stable security definer set search_path to 'public' as $f$
  select * from islamic_app_docs where application_id = p_app and kind = p_kind and not void order by at desc limit 1 $f$;

create or replace function public._isl_can_see(a applications) returns boolean language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or a.id is null then return false; end if;
  return a.citizen_id = me.id
    or me.portal in ('cbi', 'integrity', 'audit', 'admin', 'sharia')
    or (me.portal = 'bank' and me.org_id = a.bank_id)
    or (me.portal = 'supplier' and me.org_id = a.supplier_id);
end $f$;

create or replace function public._isl_mask(p text) returns text language sql immutable as $f$
  select string_agg(left(w, 1) || repeat('•', greatest(length(w) - 1, 1)), ' ') from unnest(string_to_array(trim(coalesce(p, '')), ' ')) w $f$;

-- مدة السداد: قبل الإرسال ما اختاره المقترض في خطوة المصرف، وبعده ما حُفظ في الطلب
create or replace function public._isl_term(a applications) returns int language sql stable as $f$
  select case when a.stage <= 5 then coalesce(nullif(a.bank_choice->>'term_months', '')::int, a.term_months, 60) else coalesce(a.term_months, 60) end $f$;

-- نص الوعد غير الملزم (المرابحة: بالشراء، الإجارة: بالاستئجار) مملوءاً ببيانات الطلب
create or replace function public._isl_promise(a applications) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; v islamic_contract_versions; k jsonb; o supplier_offers; bank text; sup text; res text; asset text; cl jsonb;
begin
  select * into p from islamic_products where id = a.product_id;
  select * into v from islamic_contract_versions where id = a.contract_version_id;
  select * into o from supplier_offers where id = a.offer_id;
  k := _sh_calc(p, a.amount, _isl_term(a));
  bank := (select name from orgs where id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid)); sup := coalesce((select name from orgs where id = a.supplier_id), 'المورد المعتمد');
  asset := coalesce(o.title, 'المنظومة المختارة');
  res := coalesce(a.sharia_resolution, (select code from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1), '—');
  if p.contract_type = 'IJM' then
    cl := jsonb_build_array(
      jsonb_build_object('n', 1, 'title', 'موضوع الوعد', 'text', format('أرغب أنا %s في أن يشتري %s «%s» من %s، ثم يؤجّرها لي إجارةً تنتهي بالتمليك بعد أن يتملّكها ويسلّمها.', a.citizen_name, bank, asset, sup)),
      jsonb_build_object('n', 2, 'title', 'الوعد غير ملزم', 'text', 'هذا وعد مني غير ملزم، ولا تنعقد الإجارة به. تنعقد الإجارة بعقد مستقل أوقّعه بعد أن تصير المنظومة ملك المصرف ومسجّلة باسمه وتُسلَّم لي.'),
      jsonb_build_object('n', 3, 'title', 'الأجرة المتوقعة', 'text', format('الأجرة الشهرية %s د.ع × %s شهراً، تبدأ بعد التسليم لا قبله. وتنتقل إليّ الملكية في آخر المدة بالشرط المذكور في عقد الإجارة.', _sh_fmt((k->>'installment')::numeric), k->>'term')),
      jsonb_build_object('n', 4, 'title', 'ضمان المنظومة قبل العقد', 'text', 'تبقى المنظومة في ضمان المصرف حتى توقيع عقد الإجارة، ويتحمّل المالك تلفها ما لم أتعدَّ أو أفرّط.'),
      jsonb_build_object('n', 5, 'title', 'المرجع', 'text', format('منتج «%s» المعتمد بقرار الهيئة الشرعية %s — نسخة العقد %s.', p.name, res, v.n)));
  else
    cl := jsonb_build_array(
      jsonb_build_object('n', 1, 'title', 'موضوع الوعد', 'text', format('أرغب أنا %s في أن يشتري %s «%s» من %s، ثم يبيعها لي مرابحةً بعد أن يتملّكها ويقبضها.', a.citizen_name, bank, asset, sup)),
      jsonb_build_object('n', 2, 'title', 'الوعد غير ملزم', 'text', 'هذا وعد مني غير ملزم، ولا ينعقد البيع به. ينعقد البيع بعقد مستقل أوقّعه بعد أن تصير المنظومة ملك المصرف وفي قبضه، وتصدر فاتورة المورد باسم المصرف.'),
      jsonb_build_object('n', 3, 'title', 'الكلفة والربح المعلن', 'text', format('كلفة المنظومة %s د.ع، والربح المعلن %s د.ع، فيكون ثمن البيع %s د.ع يُدفع %s د.ع شهرياً × %s شهراً. لا يتغير الربح المعلن عند العقد.',
        _sh_fmt((k->>'cost')::numeric), _sh_fmt((k->>'profit')::numeric), _sh_fmt((k->>'total')::numeric), _sh_fmt((k->>'installment')::numeric), k->>'term')),
      jsonb_build_object('n', 4, 'title', 'ضمان المنظومة قبل البيع', 'text', 'تبقى المنظومة في ملك المصرف وضمانه حتى أوقّع عقد البيع.'),
      jsonb_build_object('n', 5, 'title', 'المرجع', 'text', format('منتج «%s» المعتمد بقرار الهيئة الشرعية %s — نسخة العقد %s.', p.name, res, v.n)));
  end if;
  return jsonb_build_object('title', case when p.contract_type = 'IJM' then 'وعد بالاستئجار (غير ملزم)' else 'طلب شراء ووعد بالشراء (غير ملزم)' end,
    'clauses', cl, 'calc', k, 'product', p.name, 'type', p.contract_type, 'version', v.n, 'resolution', res);
end $f$;

-- النص الذي سيوقّعه المقترض الآن (للقراءة قبل التوقيع، والتوقيع يحفظ النص نفسه)
create or replace function public.islamic_sign_text(p_app uuid, p_kind text) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; t text; pv jsonb;
begin
  select * into a from applications where id = p_app;
  if not _isl_can_see(a) then raise exception 'الطلب غير موجود'; end if;
  t := _isl_type(a);
  if t is null then raise exception 'ليس طلب تمويل إسلامي بمنتج معتمد'; end if;
  if p_kind = 'promise' then return _isl_promise(a); end if;
  if p_kind <> 'contract' then raise exception 'نوع غير معروف'; end if;
  pv := islamic_contract_preview(a.product_id, a.amount, _isl_term(a), a.offer_id, a.id);
  return jsonb_build_object('title', case t when 'MRB' then 'عقد بيع المرابحة' when 'IJM' then 'عقد الإجارة المنتهية بالتمليك' else 'عقد ' || (pv->>'type_name') end,
    'clauses', pv->'clauses', 'calc', pv->'calc', 'summary', pv->'summary', 'product', pv->>'product', 'type', t, 'version', pv->'version', 'resolution', pv->>'resolution',
    'sha256', pv->>'sha256', 'conditions', pv->>'conditions');
end $f$;

-- ───────── 2) توقيع المقترض: الوعد أو العقد (النص المعتمد نفسه ببصمته) ─────────
create or replace function public.islamic_sign(p_app uuid, p_kind text, p_otp text, p_data jsonb default '{}'::jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; a applications; p islamic_products; v islamic_contract_versions; t text; txt jsonb; body jsonb; d islamic_app_docs;
  pr islamic_app_docs; inv islamic_app_docs; rc islamic_app_docs; v_code text; v_title text; spec jsonb; f text; v_client numeric; v_pct numeric;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a.id is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح — لم يتم التوقيع'; end if;
  t := _isl_type(a);
  if t is null then raise exception 'ليس طلب تمويل إسلامي — اختر منتجاً معتمداً شرعاً أولاً'; end if;
  select * into p from islamic_products where id = a.product_id;
  select * into v from islamic_contract_versions where id = a.contract_version_id;
  -- النسخة في الطلب يجب أن تكون سليمة (بصمتها = بصمة بنودها) ومطابقة لما حُفظ لحظة الاختيار
  if v.id is null or v.sha256 is distinct from a.contract_sha256 or _sh_sha(v.clauses) is distinct from v.sha256 then
    raise exception 'بصمة نسخة العقد في طلبك لا تطابق النسخة المعتمدة — اختر المنتج من جديد'; end if;

  if p_kind = 'promise' then
    if not _isl_two_phase(t) then raise exception 'هذه الصيغة توقّع عقدها مباشرة دون وعد'; end if;
    if a.stage > 5 then raise exception 'وُقّع الوعد وأُرسل الطلب'; end if;
  elsif p_kind = 'contract' then
    if _isl_two_phase(t) then
      pr := _isl_doc(a.id, 'promise'); inv := _isl_doc(a.id, 'invoice'); rc := _isl_doc(a.id, 'receipt');
      if pr.id is null then raise exception 'لا يوجد وعد موقّع على هذا الطلب'; end if;
      if inv.id is null or rc.id is null or a.stage < 33 then
        raise exception 'يُوقَّع العقد بعد أن يتملّك المصرف المنظومة ويقبضها (فاتورة المورد باسم المصرف ومحضر الاستلام) — سنخبرك فور ذلك'; end if;
      if (_isl_doc(a.id, 'contract')).id is not null then raise exception 'وقّعت العقد سابقاً'; end if;
    else
      if a.stage > 5 then raise exception 'يُوقَّع العقد عند إرسال الطلب'; end if;
    end if;
  else raise exception 'نوع التوقيع غير معروف'; end if;

  -- عند الإرسال: المنتج يجب أن يكون معتمداً ونافذاً ونسخته هي المعتمدة الآن
  if a.stage <= 5 then
    if p.status not in ('approved', 'conditional') then raise exception 'المنتج «%» لم يعد معتمداً شرعاً (%) — اختر منتجاً آخر', p.name, _sh_status_label(p.status); end if;
    if p.approved_version_id is distinct from v.id then
      raise exception 'اعتمدت الهيئة نسخة جديدة من عقد «%» — افتح «اقرأ العقد» واختر المنتج من جديد', p.name; end if;
  end if;

  txt := islamic_sign_text(a.id, p_kind);
  -- المرابحة: الثمن في العقد = الكلفة (فاتورة المورد) + الربح المعلن في الوعد
  if p_kind = 'contract' and _isl_two_phase(t) then
    if (txt->'calc'->>'cost')::numeric is distinct from inv.amount then
      raise exception 'كلفة المنظومة في العقد (%) لا تطابق فاتورة المورد (%) — راجع المصرف', _sh_fmt((txt->'calc'->>'cost')::numeric), _sh_fmt(inv.amount); end if;
    if round((txt->'calc'->>'profit')::numeric) is distinct from round((pr.body->'calc'->>'profit')::numeric)
       or round((txt->'calc'->>'total')::numeric) is distinct from round((txt->'calc'->>'cost')::numeric + (txt->'calc'->>'profit')::numeric) then
      raise exception 'الثمن في العقد لا يساوي الكلفة + الربح المعلن في الوعد — راجع المصرف'; end if;
  end if;
  -- السَّلَم: السلعة موصوفة بالحقول الإلزامية
  if p_kind = 'contract' and t = 'SLM' then
    spec := coalesce(p_data->'spec', '{}'::jsonb);
    foreach f in array array['goods', 'qty', 'quality', 'delivery_date', 'delivery_place'] loop
      if length(trim(coalesce(spec->>f, ''))) < 1 then
        raise exception 'صف السلعة كاملة: % ناقص', case f when 'goods' then 'النوع' when 'qty' then 'الكمية' when 'quality' then 'الجودة' when 'delivery_date' then 'موعد التسليم' else 'مكان التسليم' end; end if;
    end loop;
    txt := txt || jsonb_build_object('spec', spec);
  end if;
  -- المشاركة المتناقصة: حصة كل طرف
  if p_kind = 'contract' and t = 'MSN' then
    v_client := nullif(regexp_replace(coalesce(p_data->>'client_share', ''), '[^0-9]', '', 'g'), '')::numeric;
    if v_client is null or v_client <= 0 then raise exception 'اكتب حصتك في رأس مال الشركة بالدينار'; end if;
    v_pct := round(a.amount * 100.0 / (a.amount + v_client), 2);
    txt := txt || jsonb_build_object('shares', jsonb_build_object('bank', a.amount, 'client', v_client, 'bank_pct', v_pct, 'client_pct', 100 - v_pct, 'units', a.term_months));
  end if;

  body := jsonb_build_object('title', txt->>'title', 'clauses', txt->'clauses', 'calc', txt->'calc', 'spec', txt->'spec', 'shares', txt->'shares',
    'borrower', a.citizen_name, 'app', a.code, 'bank', (select name from orgs where id = a.bank_id), 'product', p.name, 'type', t, 'version', v.n, 'signed_at', now());
  update islamic_app_docs set void = true, void_note = 'استُبدل بتوقيع أحدث' where application_id = a.id and kind = p_kind and not void;
  v_code := _isl_code(); v_title := txt->>'title';
  insert into islamic_app_docs(application_id, kind, n, title, product_id, version_id, version_sha256, resolution, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title, signed_via)
  values (a.id, p_kind, coalesce((select max(n) from islamic_app_docs where application_id = a.id and kind = p_kind), 0) + 1, v_title, p.id, v.id, v.sha256,
    coalesce(a.sharia_resolution, txt->>'resolution'), body, _isl_sha(body), (txt->'calc'->>'total')::numeric, v_code, me.id, me.full_name, 'المقترض', 'رمز تحقق على هاتف المقترض')
  returning * into d;
  if t = 'MSN' and p_kind = 'contract' then
    update islamic_app_docs set void = true where application_id = a.id and kind = 'shares' and not void;
    insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, actor_id, actor_name, actor_title)
    values (a.id, 'shares', 'سجل حصص الشركة', p.id, v.id, v.sha256, txt->'shares', _isl_sha(txt->'shares'), a.amount, me.id, me.full_name, 'المقترض');
  end if;
  perform _ev(a.id, a.stage, 'توقيع ' || v_title,
    'المنتج ' || p.name || ' · نسخة العقد ' || v.n || ' · قرار ' || coalesce(d.resolution, '—') || ' · بصمة النص ' || left(d.doc_sha256, 16) || '… · رمز التحقق ' || v_code);
  if p_kind = 'contract' and _isl_two_phase(t) then
    perform _notify(a.bank_id, 'bank', 'islamic', 'وقّع المقترض ' || v_title || ' — ' || a.code, 'يمكن الآن تنفيذ التمويل وإصدار جدول الأقساط (المرحلة 33)', a.id);
  end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'title', d.title, 'verify_code', d.verify_code, 'doc_sha256', d.doc_sha256, 'at', d.at);
end $f$;

-- ───────── 3) المورد: الفاتورة باسم المصرف (المرابحة والإجارة — المصرف يشتري أولاً) ─────────
create or replace function public.islamic_supplier_invoice(p_app uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; t text; v_no text := upper(trim(coalesce(p->>'invoice_no', ''))); v_amt numeric; d islamic_app_docs; bank text; body jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me.portal <> 'supplier' or me.org_id is distinct from a.supplier_id then raise exception 'الفاتورة يصدرها المورد صاحب العرض'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.role not in ('supplier_admin') then raise exception 'إصدار الفاتورة لمدير حساب المورد'; end if;
  t := _isl_type(a);
  if t is null or not _isl_two_phase(t) then raise exception 'هذا الطلب لا يحتاج فاتورة باسم المصرف'; end if;
  if a.stage not in (30, 31) then raise exception 'تُصدر الفاتورة بعد أمر الشراء من المصرف وقبل إنجاز التركيب'; end if;
  if length(v_no) < 3 then raise exception 'اكتب رقم الفاتورة'; end if;
  v_amt := coalesce(nullif(regexp_replace(coalesce(p->>'amount', ''), '[^0-9]', '', 'g'), '')::numeric, a.amount);
  if v_amt is distinct from a.amount::numeric then
    raise exception 'مبلغ الفاتورة يجب أن يساوي كلفة المنظومة في الطلب (%) د.ع', _sh_fmt(a.amount); end if;
  bank := (select name from orgs where id = a.bank_id);
  body := jsonb_build_object('invoice_no', v_no, 'buyer', bank, 'seller', (select name from orgs where id = a.supplier_id),
    'asset', (select title from supplier_offers where id = a.offer_id), 'amount', v_amt, 'date', to_char(now() at time zone 'Asia/Baghdad', 'YYYY-MM-DD'),
    'note', 'المشتري: ' || bank || ' — لا المقترض. يبيعها المصرف للمقترض بعد تملّكها وقبضها.');
  update islamic_app_docs set void = true, void_note = 'استُبدلت بفاتورة أحدث' where application_id = a.id and kind = 'invoice' and not void;
  insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title)
  values (a.id, 'invoice', 'فاتورة المورد باسم ' || bank, a.product_id, a.contract_version_id, a.contract_sha256, body, _isl_sha(body), v_amt, _isl_code(),
    me.id, me.full_name, _role_title(me.role)) returning * into d;
  perform _ev(a.id, a.stage, 'فاتورة المورد باسم المصرف', 'رقم ' || v_no || ' · ' || _sh_fmt(v_amt) || ' د.ع · المشتري ' || bank);
  perform _notify(a.bank_id, 'bank', 'islamic', 'فاتورة المورد باسم المصرف — ' || a.code, 'رقم ' || v_no || ' · ' || _sh_fmt(v_amt) || ' د.ع', a.id);
  return jsonb_build_object('id', d.id, 'invoice_no', v_no, 'amount', v_amt, 'verify_code', d.verify_code);
end $f$;

-- ───────── 4) الحرّاس الآليون على انتقال المراحل ─────────
create or replace function public._isl_guard() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare v_isl boolean; p islamic_products; v islamic_contract_versions; t text; k jsonb; rc islamic_app_docs; ct islamic_app_docs;
begin
  if new.stage <= old.stage or coalesce(new.program, 'solar') <> 'solar' then return new; end if;
  select coalesce(is_islamic, false) into v_isl from orgs where id = new.bank_id;
  if not coalesce(v_isl, false) then return new; end if;

  -- (أ) الإرسال إلى المصرف الإسلامي
  if old.stage <= 5 and new.stage > 5 then
    if new.product_id is null then
      raise exception 'لا يُرسل الطلب إلى مصرف إسلامي دون منتج معتمد شرعاً — اختر صيغة التمويل في خطوة «المصرف»'; end if;
    select * into p from islamic_products where id = new.product_id;
    if p.status not in ('approved', 'conditional') then
      raise exception 'المنتج «%» لم يعد معتمداً شرعاً (%) — اختر منتجاً آخر', p.name, _sh_status_label(p.status); end if;
    if new.contract_version_id is distinct from p.approved_version_id then
      raise exception 'اعتمدت الهيئة نسخة جديدة من عقد «%» — افتح «اقرأ العقد» واختر المنتج من جديد', p.name; end if;
    select * into v from islamic_contract_versions where id = new.contract_version_id;
    if new.contract_sha256 is distinct from v.sha256 or _sh_sha(v.clauses) is distinct from v.sha256 then
      raise exception 'بصمة العقد في الطلب لا تطابق النسخة المعتمدة'; end if;
    if _isl_two_phase(p.contract_type) then
      if not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'promise' and not void and version_id = v.id) then
        raise exception 'وقّع % أولاً', case when p.contract_type = 'IJM' then 'الوعد بالاستئجار' else 'طلب الشراء والوعد غير الملزم' end; end if;
    elsif not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'contract' and not void and version_id = v.id) then
      raise exception 'وقّع العقد المعتمد أولاً'; end if;
    -- القسط والمدة من تسعير المنتج نفسه، فيكون جدول الأقساط = الثمن المكتوب في العقد
    k := _sh_calc(p, new.amount, new.term_months);
    new.term_months := (k->>'term')::int; new.monthly_installment := round((k->>'installment')::numeric);
  end if;

  if new.product_id is null then return new; end if;   -- طلبات قديمة قبل الجلسة 39
  t := (select contract_type from islamic_products where id = new.product_id);

  -- (ب) لا يبيع المصرف ما لا يملك: فاتورة المورد باسم المصرف قبل إنجاز التركيب
  if _isl_two_phase(t) and old.stage <= 31 and new.stage > 31
     and not exists (select 1 from islamic_app_docs where application_id = new.id and kind = 'invoice' and not void) then
    raise exception 'صيغة %: لا يُنجز التركيب قبل فاتورة المورد باسم المصرف — يصدرها المورد من ملف الطلب', case t when 'IJM' then 'الإجارة' else 'المرابحة' end; end if;

  -- (ج) تنفيذ التمويل وجدول الأقساط بعد عقد البيع/الإجارة الموقّع بعد القبض
  if old.stage <= 33 and new.stage > 33 then
    ct := _isl_doc(new.id, 'contract');
    if ct.id is null then
      raise exception '%', case when _isl_two_phase(t) then 'لم يوقّع المقترض ' || case t when 'IJM' then 'عقد الإجارة' else 'عقد بيع المرابحة' end
        || ' بعد — وصله إشعار «المنظومة صارت ملك المصرف — وقّع»، ويوقّعه من «طلبي». لا يُنفَّذ التمويل قبله' else 'لا يوجد عقد موقّع على هذا الطلب' end; end if;
    if _isl_two_phase(t) then
      rc := _isl_doc(new.id, 'receipt');
      if rc.id is null or ct.at < rc.at then raise exception 'العقد يجب أن يُوقَّع بعد محضر القبض — لا قبله'; end if;
    end if;
    if t = 'MSN' and (_isl_doc(new.id, 'shares')).id is null then raise exception 'صيغة المشاركة: سجّل حصة كل طرف أولاً'; end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_isl_guard on public.applications;
create trigger trg_isl_guard before update of stage on public.applications for each row execute function public._isl_guard();

-- بعد الانتقال: محضر القبض عند استلام البضاعة (32)، والتحقق من جدول الأقساط (33)
-- الاسم يبدأ بـ zz ليعمل بعد trg_repay_hooks الذي يولّد الجدول
create or replace function public._isl_after() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare t text; me profiles; ct islamic_app_docs; rc islamic_app_docs; inv islamic_app_docs; tot numeric; cnt int; first_due date; tol numeric; body jsonb; bank text;
begin
  if new.stage <= old.stage or coalesce(new.program, 'solar') <> 'solar' or new.product_id is null then return new; end if;
  t := _isl_type(new);
  if t is null then return new; end if;
  select * into me from profiles where id = auth.uid();
  if _isl_two_phase(t) and old.stage <= 32 and new.stage > 32 and (_isl_doc(new.id, 'receipt')).id is null then
    inv := _isl_doc(new.id, 'invoice'); bank := (select name from orgs where id = new.bank_id);
    body := jsonb_build_object('asset', (select title from supplier_offers where id = new.offer_id), 'supplier', (select name from orgs where id = new.supplier_id),
      'owner', bank, 'invoice_no', inv.body->>'invoice_no', 'site', concat_ws(' — ', new.governorate, new.city), 'by', me.full_name, 'by_title', _role_title(me.role),
      'date', to_char(now() at time zone 'Asia/Baghdad', 'YYYY-MM-DD'),
      'statement', case when t = 'IJM' then 'استلم المصرف المنظومة وسُجّلت باسمه، وسُلّمت للمستأجر في موقعها' else 'استلم المصرف المنظومة وقبضها، وصارت ملكه وفي ضمانه' end);
    insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title)
    values (new.id, 'receipt', case when t = 'IJM' then 'محضر استلام وتسجيل الأصل باسم المصرف وتسليمه' else 'محضر استلام وقبض — المنظومة ملك المصرف' end,
      new.product_id, new.contract_version_id, new.contract_sha256, body, _isl_sha(body), new.amount, _isl_code(), me.id, me.full_name, _role_title(me.role));
    perform _ev(new.id, 32, case when t = 'IJM' then 'تسجيل الأصل باسم المصرف وتسليمه' else 'محضر القبض: المنظومة صارت ملك المصرف' end, 'بانتظار توقيع المقترض للعقد');
    insert into notifications(user_id, kind, title, body, ref_id)
    values (new.citizen_id, 'islamic', case when t = 'IJM' then 'المنظومة صارت ملك المصرف — وقّع عقد الإجارة' else 'المنظومة صارت ملك المصرف — وقّع عقد الشراء' end,
      'افتح «طلبي» واضغط «وقّع» — يستغرق دقيقة', new.id);
  end if;
  if old.stage <= 33 and new.stage > 33 then
    ct := _isl_doc(new.id, 'contract');
    select count(*), coalesce(sum(amount), 0), min(due_date) into cnt, tot, first_due from installments where application_id = new.id;
    if cnt > 0 and ct.id is not null then
      tol := greatest(cnt * 2, (ct.body->'calc'->>'total')::numeric * 0.0005);
      if abs(tot - (ct.body->'calc'->>'total')::numeric) > tol then
        raise exception 'مجموع الأقساط (%) لا يساوي الثمن المكتوب في العقد الموقّع (%) — لا يُصدر الجدول', _sh_fmt(tot), _sh_fmt((ct.body->'calc'->>'total')::numeric); end if;
      if t = 'IJM' then
        rc := _isl_doc(new.id, 'receipt');
        if first_due <= (rc.at at time zone 'Asia/Baghdad')::date then raise exception 'صيغة الإجارة: الأجرة تبدأ بعد التسليم لا قبله'; end if;
      end if;
      perform _ev(new.id, 33, 'تحقق آلي: جدول الأقساط = الثمن في العقد الموقّع', _sh_fmt(tot) || ' د.ع على ' || cnt || ' قسطاً · العقد ' || ct.verify_code);
    end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_zz_isl_after on public.applications;
create trigger trg_zz_isl_after after update of stage on public.applications for each row execute function public._isl_after();

-- ───────── 5) التأخر في السداد: لا زيادة على الدين لمصلحة المصرف ─────────
create or replace function public._isl_no_late_increase() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare a applications;
begin
  select * into a from applications where id = new.application_id;
  if a.product_id is null or _isl_type(a) is null then return new; end if;
  if new.amount > old.amount or new.profit > old.profit or new.principal > old.principal then
    raise exception 'تمويل إسلامي: لا تُضاف أي زيادة على القسط أو الدين المتأخر لمصلحة المصرف — البديل بقرار الهيئة الشرعية'; end if;
  return new;
end $f$;
drop trigger if exists trg_isl_no_late_increase on public.installments;
create trigger trg_isl_no_late_increase before update on public.installments for each row execute function public._isl_no_late_increase();

-- المشاركة المتناقصة: كل قسط مستوفى = عقد بيع مستقل لحصة من حصة المصرف
create or replace function public._isl_share_sale() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare a applications; sh islamic_app_docs; unit numeric; left_pct numeric; body jsonb;
begin
  if old.paid_at is not null or new.paid_at is null then return new; end if;
  select * into a from applications where id = new.application_id;
  if a.product_id is null or _isl_type(a) is distinct from 'MSN' then return new; end if;
  sh := _isl_doc(a.id, 'shares');
  if sh.id is null then return new; end if;
  unit := round((sh.body->>'bank_pct')::numeric / greatest((sh.body->>'units')::int, 1), 4);
  left_pct := greatest(round((sh.body->>'bank_pct')::numeric - unit * (select count(*) from installments where application_id = a.id and paid_at is not null), 4), 0);
  body := jsonb_build_object('n', new.n, 'pct', unit, 'price', new.principal, 'bank_pct_after', left_pct, 'client_pct_after', 100 - left_pct, 'ref', new.paid_ref);
  insert into islamic_app_docs(application_id, kind, n, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title)
  values (a.id, 'share_sale', new.n, 'عقد بيع الحصة ' || new.n || ' (' || unit || '%)', a.product_id, a.contract_version_id, a.contract_sha256, body, _isl_sha(body), new.principal, _isl_code(),
    new.paid_by, (select full_name from profiles where id = new.paid_by), new.paid_by_title);
  return new;
end $f$;
drop trigger if exists trg_isl_share_sale on public.installments;
create trigger trg_isl_share_sale after update of paid_at on public.installments for each row execute function public._isl_share_sale();

-- قاعدة التأخر كما يراها المقترض والتحصيل
create or replace function public.islamic_late_info(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; me profiles; b sharia_boards; t text;
begin
  select * into a from applications where id = p_app;
  if not _isl_can_see(a) then return null; end if;
  t := _isl_type(a);
  if t is null then return null; end if;
  select * into me from profiles where id = auth.uid();
  select sb.* into b from sharia_boards sb join islamic_products p on p.board_id = sb.id where p.id = a.product_id;
  return jsonb_build_object('islamic', true, 'type', t, 'kind', b.late_kind,
    'kind_label', case b.late_kind when 'charity' then 'التزام بالتبرع لصندوق خيري (لا يدخل إيرادات المصرف)' when 'damage' then 'تعويض عن ضرر فعلي تقرّه الهيئة' else 'المطالبة والرجوع إلى الضمانات' end,
    'rule', coalesce(b.late_rule, 'لا تُضاف أي زيادة على الدين المتأخر لمصلحة المصرف. يطالب المصرف بالقسط ويرجع إلى الضمان.'),
    'board', b.name,
    'can_charity', b.late_kind = 'charity' and me.portal = 'bank' and me.role = 'bank_collection' and me.org_id = a.bank_id,
    'charity', coalesce((select jsonb_agg(jsonb_build_object('n', n, 'amount', amount, 'ref', ref, 'by', by_name, 'at', at) order by at) from islamic_charity where application_id = a.id), '[]'::jsonb));
end $f$;

create or replace function public.islamic_charity_record(p_app uuid, p_n int, p_amount numeric, p_ref text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; b sharia_boards; i installments; late int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me.portal <> 'bank' or me.role <> 'bank_collection' or me.org_id is distinct from a.bank_id then raise exception 'لموظف التحصيل في المصرف المموِّل'; end if;
  if _isl_type(a) is null then raise exception 'ليس تمويلاً إسلامياً'; end if;
  select sb.* into b from sharia_boards sb join islamic_products p on p.board_id = sb.id where p.id = a.product_id;
  if b.late_kind <> 'charity' then raise exception 'قرار الهيئة في التأخر لا يتضمن التبرع لصندوق خيري'; end if;
  select * into i from installments where application_id = a.id and n = p_n;
  if i.id is null then raise exception 'القسط غير موجود'; end if;
  late := coalesce((i.paid_at at time zone 'Asia/Baghdad')::date, (now() at time zone 'Asia/Baghdad')::date) - i.due_date;
  if late <= 0 then raise exception 'القسط % غير متأخر', p_n; end if;
  if coalesce(p_amount, 0) <= 0 then raise exception 'اكتب المبلغ'; end if;
  if length(trim(coalesce(p_ref, ''))) < 3 then raise exception 'اكتب رقم وصل الصندوق الخيري'; end if;
  insert into islamic_charity(application_id, n, amount, ref, by_id, by_name, by_code) values (a.id, p_n, p_amount, trim(p_ref), me.id, me.full_name, me.staff_code);
  perform _ev(a.id, a.stage, 'تبرع لصندوق خيري عن تأخر القسط ' || p_n, _sh_fmt(p_amount) || ' د.ع · وصل ' || trim(p_ref) || ' — لا يدخل إيرادات المصرف');
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 6) حالة الطلب الإسلامي: الحرّاس كقائمة، والمستندات، وما المطلوب من المقترض ─────────
create or replace function public.islamic_app_state(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; me profiles; p islamic_products; ty sharia_contract_types; t text; two boolean; pr islamic_app_docs; inv islamic_app_docs; rc islamic_app_docs; ct islamic_app_docs;
  steps jsonb := '[]'::jsonb; nxt text; cnt int; tot numeric; first_due date; res sharia_resolutions; v islamic_contract_versions;
begin
  select * into a from applications where id = p_app;
  if not _isl_can_see(a) then return null; end if;
  t := _isl_type(a);
  if t is null then return null; end if;
  select * into me from profiles where id = auth.uid();
  select * into p from islamic_products where id = a.product_id;
  select * into ty from sharia_contract_types where code = t;
  select * into v from islamic_contract_versions where id = a.contract_version_id;
  select * into res from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  two := _isl_two_phase(t);
  pr := _isl_doc(a.id, 'promise'); inv := _isl_doc(a.id, 'invoice'); rc := _isl_doc(a.id, 'receipt'); ct := _isl_doc(a.id, 'contract');
  select count(*), coalesce(sum(amount), 0), min(due_date) into cnt, tot, first_due from installments where application_id = a.id;

  steps := steps || jsonb_build_object('k', 'product', 'label', 'المنتج معتمد ونافذ، والعقد بالنسخة المعتمدة', 'ok', a.contract_sha256 = v.sha256 and _sh_sha(v.clauses) = v.sha256,
    'note', 'قرار ' || coalesce(res.code, '—') || ' · النسخة ' || v.n || ' · ' || _sh_status_label(p.status));
  if two then
    steps := steps
      || jsonb_build_object('k', 'promise', 'label', case when t = 'IJM' then 'وعد بالاستئجار موقّع (غير ملزم)' else 'طلب شراء ووعد موقّع (غير ملزم)' end, 'ok', pr.id is not null, 'at', pr.at, 'stage', 5)
      || jsonb_build_object('k', 'invoice', 'label', 'فاتورة المورد باسم المصرف', 'ok', inv.id is not null, 'at', inv.at, 'stage', 31, 'note', inv.body->>'invoice_no')
      || jsonb_build_object('k', 'receipt', 'label', case when t = 'IJM' then 'الأصل مسجّل باسم المصرف ومسلَّم' else 'محضر استلام وقبض — المنظومة ملك المصرف' end, 'ok', rc.id is not null, 'at', rc.at, 'stage', 32)
      || jsonb_build_object('k', 'contract', 'label', case when t = 'IJM' then 'عقد الإجارة موقّع بعد التسليم' else 'عقد المرابحة موقّع بعد القبض — الثمن = الكلفة + الربح المعلن' end,
           'ok', ct.id is not null and rc.id is not null and ct.at >= rc.at, 'at', ct.at, 'stage', 33,
           'note', case when ct.id is not null then 'الكلفة ' || _sh_fmt((ct.body->'calc'->>'cost')::numeric) || ' + الربح ' || _sh_fmt((ct.body->'calc'->>'profit')::numeric) || ' = ' || _sh_fmt((ct.body->'calc'->>'total')::numeric) end);
  else
    steps := steps || jsonb_build_object('k', 'contract', 'label', 'العقد المعتمد موقّع ببصمته', 'ok', ct.id is not null, 'at', ct.at, 'stage', 5);
  end if;
  if t = 'MSN' then
    steps := steps || jsonb_build_object('k', 'shares', 'label', 'حصة كل طرف مسجّلة، وكل شراء لحصة عقد بيع مستقل', 'ok', (_isl_doc(a.id, 'shares')).id is not null,
      'note', (select count(*) from islamic_app_docs where application_id = a.id and kind = 'share_sale' and not void) || ' عقد بيع حصة');
  end if;
  if t = 'SLM' then
    steps := steps || jsonb_build_object('k', 'spec', 'label', 'السلعة موصوفة بالحقول الإلزامية، والثمن يُدفع كاملاً عند العقد', 'ok', coalesce(ct.body ? 'spec' and ct.body->'spec' <> 'null'::jsonb, false));
  end if;
  steps := steps || jsonb_build_object('k', 'schedule', 'label', case when t = 'IJM' then 'الأجرة تبدأ بعد التسليم ومجموعها = الثابت في العقد' else 'جدول الأقساط = الثمن المكتوب في العقد' end,
    'ok', cnt > 0 and ct.id is not null and abs(tot - (ct.body->'calc'->>'total')::numeric) <= greatest(cnt * 2, (ct.body->'calc'->>'total')::numeric * 0.0005)
      and (t <> 'IJM' or first_due > (rc.at at time zone 'Asia/Baghdad')::date), 'stage', 34,
    'note', case when cnt > 0 then _sh_fmt(tot) || ' د.ع على ' || cnt || ' قسطاً' end);
  steps := steps || jsonb_build_object('k', 'late', 'label', 'لا زيادة على المتأخر لمصلحة المصرف', 'ok', true, 'note', 'مفروض آلياً على جدول الأقساط والتحصيل');

  if a.citizen_id = me.id and a.status in ('active', 'returned') then
    if two and a.stage <= 5 and pr.id is null then nxt := 'promise';
    elsif not two and a.stage <= 5 and ct.id is null then nxt := 'contract';
    elsif two and rc.id is not null and ct.id is null and a.stage >= 33 then nxt := 'contract'; end if;
  end if;

  return jsonb_build_object('islamic', true, 'type', t, 'type_name', ty.name, 'two_phase', two, 'stage', a.stage,
    'calc', coalesce(ct.body->'calc', _sh_calc(p, a.amount, _isl_term(a))),
    'product', jsonb_build_object('id', p.id, 'code', p.code, 'name', p.name, 'status', p.status, 'status_label', _sh_status_label(p.status)),
    'resolution', res.code, 'resolution_at', res.issued_at, 'conditional', res.decision = 'conditional', 'version', v.n, 'sha256', v.sha256,
    'board', (select name from sharia_boards where id = p.board_id),
    'steps', steps, 'next', nxt,
    'next_label', case nxt when 'promise' then case when t = 'IJM' then 'الوعد بالاستئجار' else 'طلب الشراء والوعد غير الملزم' end
      when 'contract' then case t when 'MRB' then 'عقد بيع المرابحة' when 'IJM' then 'عقد الإجارة' else 'العقد المعتمد' end end,
    'can_invoice', me.portal = 'supplier' and me.org_id = a.supplier_id and me.role = 'supplier_admin' and two and a.stage in (30, 31) and inv.id is null,
    'docs', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'n', d.n, 'title', d.title, 'at', d.at, 'by', d.actor_name, 'by_title', d.actor_title,
        'verify_code', d.verify_code, 'doc_sha256', d.doc_sha256, 'amount', d.amount) order by d.at)
      from islamic_app_docs d where d.application_id = a.id and not d.void), '[]'::jsonb));
end $f$;

-- قراءة مستند موقّع كاملاً (النص المحفوظ نفسه)
create or replace function public.islamic_app_doc(p_doc uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare d islamic_app_docs; a applications;
begin
  select * into d from islamic_app_docs where id = p_doc;
  select * into a from applications where id = d.application_id;
  if d.id is null or not _isl_can_see(a) then raise exception 'المستند غير موجود'; end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'title', d.title, 'body', d.body, 'doc_sha256', d.doc_sha256, 'version_sha256', d.version_sha256,
    'resolution', d.resolution, 'verify_code', d.verify_code, 'at', d.at, 'by', d.actor_name, 'by_title', d.actor_title, 'signed_via', d.signed_via,
    'intact', _isl_sha(d.body) = d.doc_sha256, 'app_code', a.code);
end $f$;

-- ───────── 7) التحقق العام برمز QR (دون تسجيل دخول) ─────────
create or replace function public.islamic_verify(p_code text) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare d islamic_app_docs; v islamic_contract_versions; p islamic_products; r sharia_resolutions; a applications;
begin
  select * into d from islamic_app_docs where verify_code = upper(trim(coalesce(p_code, '')));
  if d.id is null then return jsonb_build_object('found', false); end if;
  select * into a from applications where id = d.application_id;
  select * into v from islamic_contract_versions where id = d.version_id;
  select * into p from islamic_products where id = d.product_id;
  select * into r from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at limit 1;
  return jsonb_build_object('found', true, 'kind', d.kind, 'title', d.title, 'at', d.at, 'void', d.void,
    'signer', _isl_mask(d.actor_name), 'signer_title', d.actor_title, 'app', left(a.code, 9) || '•••' || right(a.code, 2),
    'bank', (select name from orgs where id = a.bank_id), 'product', p.name, 'type_name', (select name from sharia_contract_types where code = p.contract_type),
    'version', v.n, 'version_sha256', d.version_sha256, 'doc_sha256', d.doc_sha256,
    -- 1) النص المحفوظ لم يتغير بعد التوقيع  2) قالب العقد هو النسخة التي اعتمدتها الهيئة حرفياً
    'doc_intact', _isl_sha(d.body) = d.doc_sha256,
    'version_intact', v.id is not null and _sh_sha(v.clauses) = v.sha256 and v.sha256 = d.version_sha256,
    'approved', r.id is not null and r.version_sha256 = v.sha256,
    'resolution', r.code, 'resolution_at', r.issued_at, 'board', (select name from sharia_boards where id = r.board_id),
    'amount', d.amount);
end $f$;

-- ───────── 8) تعديل منتج معتمد: نسخة جديدة تمر بالدورة كاملة ─────────
create or replace function public.islamic_product_amend(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; o islamic_products; c islamic_products; av islamic_contract_versions; k int;
begin
  me := _sh_bank_me();
  select * into o from islamic_products where id = p_id for update;
  if o.bank_id is distinct from me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
  if o.status not in ('approved', 'conditional') then raise exception 'يُعدَّل بهذه الطريقة المنتج المعتمد النافذ فقط'; end if;
  select * into c from islamic_products where amends_product_id = o.id and status not in ('rejected', 'superseded', 'withdrawn') limit 1;
  if c.id is not null then return jsonb_build_object('id', c.id, 'code', c.code, 'existing', true); end if;
  select * into av from islamic_contract_versions where id = o.approved_version_id;
  k := (select count(*) from islamic_products where amends_product_id = o.id) + 1;
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, amends_product_id, created_by)
  values (o.code || '-T' || k, o.bank_id, o.board_id, o.contract_type, o.name, o.sector, o.subsector, o.line, o.pricing, o.guarantees, o.attachments, 'draft', o.id, me.id)
  returning * into c;
  -- النسخة المعتمدة أساساً للمقارنة، ونسخة مسودة للتعديل
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name)
  values (c.id, av.n, av.clauses, av.sha256, 'superseded', 'النسخة المعتمدة النافذة (أساس التعديل)', av.created_by_name);
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name)
  values (c.id, av.n + 1, av.clauses, av.sha256, 'draft', null, me.full_name) returning id into av.id;
  update islamic_products set current_version_id = av.id where id = c.id;
  perform _sh_log(c.id, 'بدء تعديل على المنتج المعتمد ' || o.code, 'النسخة المعتمدة تبقى نافذة للمقترضين حتى يصدر القرار الجديد');
  perform _sh_log(o.id, 'بدأ المصرف تعديلاً على العقد (' || c.code || ')', 'هذا المنتج يبقى نافذاً حتى يصدر القرار');
  return jsonb_build_object('id', c.id, 'code', c.code, 'existing', false);
end $f$;

-- حماية التعديل: الصيغة والمصرف ثابتان، ولا يُقدَّم دون تغيير في النص. وعند اعتماده تنتقل النسخة إلى المنتج الأصلي
create or replace function public._isl_amend_guard() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare base text;
begin
  if new.amends_product_id is null then return new; end if;
  if new.contract_type is distinct from (select contract_type from islamic_products where id = new.amends_product_id) then
    raise exception 'تعديل المنتج المعتمد لا يغيّر صيغته — أنشئ منتجاً جديداً لصيغة أخرى'; end if;
  if new.status = 'submitted' and old.status in ('draft', 'returned') then
    select sha256 into base from islamic_contract_versions where id = (select approved_version_id from islamic_products where id = new.amends_product_id);
    if (select sha256 from islamic_contract_versions where id = new.current_version_id) = base then
      raise exception 'لم يتغير شيء في نص العقد عن النسخة المعتمدة — عدّل البنود أولاً'; end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_isl_amend_guard on public.islamic_products;
create trigger trg_isl_amend_guard before update on public.islamic_products for each row execute function public._isl_amend_guard();

create or replace function public._isl_amend_merge() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare o islamic_products;
begin
  if new.amends_product_id is null or new.status not in ('approved', 'conditional') or old.status = new.status then return new; end if;
  select * into o from islamic_products where id = new.amends_product_id for update;
  update islamic_contract_versions set status = 'superseded' where id = o.approved_version_id;
  update islamic_products set approved_version_id = new.approved_version_id, current_version_id = new.approved_version_id, resolution_id = new.resolution_id,
    review_due = new.review_due, status = case when o.status in ('approved', 'conditional') then new.status else o.status end,
    status_note = 'نافذ بالنسخة المعدّلة من ' || new.code, updated_at = now()
  where id = o.id;
  update islamic_products set status = 'superseded', status_note = 'دُمج في ' || o.code || ' بعد اعتماده', updated_at = now() where id = new.id;
  perform _sh_log(o.id, 'اعتُمدت النسخة المعدّلة وصارت هي النافذة', (select code from sharia_resolutions where id = new.resolution_id) || ' · ' || new.code);
  perform _sh_log(new.id, 'دُمج التعديل في المنتج ' || o.code, null);
  return new;
end $f$;
drop trigger if exists trg_isl_amend_merge on public.islamic_products;
create trigger trg_isl_amend_merge after update of status on public.islamic_products for each row execute function public._isl_amend_merge();

-- المنتج في القوائم يذكر أنه تعديل على منتج معتمد
create or replace function public._sh_row(p islamic_products) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', p.id, 'code', p.code, 'name', p.name, 'bank', (select name from orgs where id = p.bank_id), 'bank_id', p.bank_id,
    'type', p.contract_type, 'type_name', (select name from sharia_contract_types where code = p.contract_type),
    'sector', p.sector, 'subsector', p.subsector, 'sector_label', _sh_sector_label(p.sector, p.subsector), 'line', p.line,
    'status', p.status, 'status_label', _sh_status_label(p.status), 'status_note', p.status_note,
    'version', (select n from islamic_contract_versions where id = p.current_version_id),
    'versions', (select count(*) from islamic_contract_versions where product_id = p.id),
    'comments', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null),
    'comments_open', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null and not resolved and author_side = 'board'),
    'votes', (select count(*) from sharia_votes where version_id = p.current_version_id),
    'my_vote', (select vote from sharia_votes where version_id = p.current_version_id and member_id = auth.uid()),
    'resolution', (select jsonb_build_object('code', code, 'decision', decision, 'decision_label', _sh_decision_label(decision), 'issued_at', issued_at) from sharia_resolutions where id = p.resolution_id),
    'submitted_at', p.submitted_at, 'updated_at', p.updated_at, 'review_due', p.review_due,
    'review_soon', p.review_due is not null and p.review_due <= current_date + 30,
    'amends', (select jsonb_build_object('id', o.id, 'code', o.code, 'name', o.name) from islamic_products o where o.id = p.amends_product_id),
    'amending', (select jsonb_build_object('id', c.id, 'code', c.code, 'status', c.status, 'status_label', _sh_status_label(c.status)) from islamic_products c
      where c.amends_product_id = p.id and c.status not in ('rejected', 'superseded', 'withdrawn') limit 1)) $f$;

create or replace function public._sh_status_label(s text) returns text language sql immutable as $f$
  select case s when 'draft' then 'مسودة لدى المصرف' when 'submitted' then 'لدى أمين السر' when 'returned' then 'معاد للمصرف للتعديل'
    when 'deliberation' then 'قيد المداولة والتصويت' when 'approved' then 'معتمد شرعاً' when 'conditional' then 'معتمد بشرط' when 'rejected' then 'مرفوض'
    when 'suspended' then 'معلّق مؤقتاً' when 'withdrawn' then 'مسحوب الاعتماد' when 'superseded' then 'دُمج في المنتج الأصلي' else s end $f$;

-- القرار النافذ يُقرأ من نسخة العقد المعتمدة (بعد التعديل تكون نسخة المنتج قرارها من ملف التعديل)
create or replace function public.islamic_offer_products(p_bank uuid, p_amount numeric, p_term int, p_sector text default 'pv') returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth.uid() is null then raise exception 'سجّل الدخول أولاً'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'type', p.contract_type, 'type_name', t.name, 'line', coalesce(p.line, t.borrower_line),
      'sector_label', _sh_sector_label(p.sector, p.subsector), 'status', p.status, 'resolution', r.code, 'resolution_at', r.issued_at,
      'conditional', p.status = 'conditional', 'version', v.n, 'sha256', v.sha256, 'calc', _sh_calc(p, p_amount, p_term), 'guarantees', p.guarantees,
      'two_phase', _isl_two_phase(p.contract_type))
      order by p.created_at)
    from islamic_products p join sharia_contract_types t on t.code = p.contract_type
      join islamic_contract_versions v on v.id = p.approved_version_id
      left join sharia_resolutions r on r.id = (select id from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1)
    where p.bank_id = p_bank and p.status in ('approved', 'conditional') and p.sector = coalesce(p_sector, 'pv')
      and (p.subsector is null or p.subsector in ('individuals', 'agri', 'industry', 'clinic', 'production'))), '[]'::jsonb);
end $f$;

create or replace function public.app_choose_product(p_app uuid, p_product uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; p islamic_products; v islamic_contract_versions; v_bank uuid; res text;
begin
  select * into a from applications where id = p_app for update;
  if a.id is null or a.citizen_id <> auth.uid() then raise exception 'الطلب غير موجود'; end if;
  if a.stage > 5 then raise exception 'لا يمكن تغيير المنتج بعد إرسال الطلب للمصرف'; end if;
  v_bank := coalesce(nullif(a.bank_choice->>'bank_id', '')::uuid, a.bank_id);
  if p_product is null then
    update applications set product_id = null, contract_version_id = null, contract_sha256 = null, sharia_resolution = null, updated_at = now() where id = a.id;
    update islamic_app_docs set void = true, void_note = 'غيّر المقترض المنتج' where application_id = a.id and kind in ('promise', 'contract') and not void;
    return jsonb_build_object('ok', true);
  end if;
  select * into p from islamic_products where id = p_product;
  if p.id is null or p.bank_id is distinct from v_bank then raise exception 'المنتج لا يخص المصرف المختار في طلبك'; end if;
  if p.status not in ('approved', 'conditional') then raise exception 'هذا المنتج غير معتمد شرعاً حالياً — اختر منتجاً آخر'; end if;
  select * into v from islamic_contract_versions where id = p.approved_version_id;
  select code into res from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  -- تغيير المنتج أو نسخته يُبطل التوقيع السابق قبل الإرسال
  if a.product_id is distinct from p.id or a.contract_version_id is distinct from v.id then
    update islamic_app_docs set void = true, void_note = 'غيّر المقترض المنتج أو نسخة العقد' where application_id = a.id and kind in ('promise', 'contract') and not void;
  end if;
  update applications set product_id = p.id, contract_version_id = v.id, contract_sha256 = v.sha256, sharia_resolution = res, updated_at = now() where id = a.id;
  insert into application_events(application_id, stage, action, actor_name, note)
  select a.id, a.stage, 'اختيار المنتج الإسلامي: ' || p.name, a.citizen_name, 'نسخة العقد ' || v.n || ' · قرار ' || coalesce(res, '—') || ' · البصمة ' || left(v.sha256, 16) || '…'
  where to_regclass('public.application_events') is not null;
  return jsonb_build_object('ok', true, 'product', p.name, 'resolution', res, 'version', v.n, 'sha256', v.sha256);
end $f$;

-- قارئ العقد: القرار من نسخة العقد نفسها (يبقى صحيحاً بعد دمج تعديل معتمد)
do $$
declare d text;
begin
  d := pg_get_functiondef('public.islamic_contract_preview(uuid,numeric,integer,uuid,uuid)'::regprocedure);
  if position('where product_id = p.id and version_id = v.id' in d) > 0 then
    execute replace(d, 'where product_id = p.id and version_id = v.id', 'where version_id = v.id');
  end if;
end $$;

-- صندوق الهيئة يعرض نوع معالجة التأخر
do $$
declare d text;
begin
  d := pg_get_functiondef('public.sharia_inbox()'::regprocedure);
  if position('''late_kind''' in d) = 0 and position('''late_rule'', b.late_rule,' in d) > 0 then
    execute replace(d, '''late_rule'', b.late_rule,', '''late_rule'', b.late_rule, ''late_kind'', b.late_kind,');
  end if;
end $$;

-- إعدادات الهيئة: نوع معالجة التأخر مع نصها
create or replace function public.sharia_settings(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; q int; rm int;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إعدادات الهيئة لرئيسها'; end if;
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1 for update;
  q := coalesce(nullif(p->>'quorum', '')::int, b.quorum); rm := coalesce(nullif(p->>'review_months', '')::int, b.review_months);
  if q < 1 or q > greatest(_sh_voters(b.id), 1) then raise exception 'النصاب بين 1 وعدد الأعضاء المصوّتين (%)', _sh_voters(b.id); end if;
  if rm < 1 or rm > 60 then raise exception 'دورة المراجعة بين 1 و60 شهراً'; end if;
  if coalesce(p->>'majority', b.majority) not in ('simple', 'two_thirds') then raise exception 'قاعدة الأغلبية غير معروفة'; end if;
  if coalesce(p->>'late_kind', b.late_kind) not in ('claim', 'damage', 'charity') then raise exception 'اختر معالجة التأخر'; end if;
  update sharia_boards set
    name = coalesce(nullif(trim(p->>'name'), ''), name),
    marja = case when p ? 'marja' then nullif(trim(p->>'marja'), '') else marja end,
    late_rule = case when p ? 'late_rule' then nullif(trim(p->>'late_rule'), '') else late_rule end,
    late_kind = coalesce(nullif(p->>'late_kind', ''), late_kind),
    quorum = q, review_months = rm, majority = coalesce(p->>'majority', majority),
    chair_casting = coalesce((p->>'chair_casting')::boolean, chair_casting), updated_at = now()
  where id = b.id;
  perform _audit('تعديل إعدادات الهيئة الشرعية', b.code, p);
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 9) الصلاحيات ─────────
revoke all on function public._isl_type(applications), public._isl_doc(uuid, text), public._isl_can_see(applications), public._isl_promise(applications), public._isl_code()
  from public, anon, authenticated;
revoke all on function public.islamic_sign_text(uuid, text), public.islamic_sign(uuid, text, text, jsonb), public.islamic_supplier_invoice(uuid, jsonb),
  public.islamic_late_info(uuid), public.islamic_charity_record(uuid, int, numeric, text), public.islamic_app_state(uuid), public.islamic_app_doc(uuid),
  public.islamic_product_amend(uuid), public.islamic_offer_products(uuid, numeric, int, text), public.app_choose_product(uuid, uuid), public.sharia_settings(jsonb) from public, anon;
grant execute on function public.islamic_sign_text(uuid, text), public.islamic_sign(uuid, text, text, jsonb), public.islamic_supplier_invoice(uuid, jsonb),
  public.islamic_late_info(uuid), public.islamic_charity_record(uuid, int, numeric, text), public.islamic_app_state(uuid), public.islamic_app_doc(uuid),
  public.islamic_product_amend(uuid), public.islamic_offer_products(uuid, numeric, int, text), public.app_choose_product(uuid, uuid), public.sharia_settings(jsonb) to authenticated;
revoke all on function public.islamic_verify(text) from public;
grant execute on function public.islamic_verify(text) to anon, authenticated;

-- ───────── 10) حسابات العرض ─────────
-- citizen5: مرابحة لدى مصرف الواحة — المصرف تملّك المنظومة وقبضها، وبقي توقيع عقد الشراء (يظهر زر «وقّع» في «طلبي»)
-- citizen6: مرابحة لدى مصرف الواحة عند التركيب (31) — ينتظر فاتورة المورد باسم المصرف (supplier1)
do $$
declare uid uuid; aid uuid; p islamic_products; v islamic_contract_versions; res text; o supplier_offers; k jsonb; br uuid; d jsonb; cn text; u text; nm text; ph text; stg int;
begin
  select * into p from islamic_products where bank_id = (select id from orgs where code = 'bank2') and contract_type = 'MRB' and sector = 'pv' and status in ('approved', 'conditional') order by created_at limit 1;
  if p.id is null then raise notice 'لا منتج مرابحة معتمد لمصرف الواحة — لم تُنشأ حسابات العرض'; return; end if;
  select * into v from islamic_contract_versions where id = p.approved_version_id;
  select code into res from sharia_resolutions where version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  select so.* into o from supplier_offers so join orgs s on s.id = so.supplier_id join capacity_tiers ct on ct.id = so.tier_id where s.code = 'sup1' and ct.kw = 5 limit 1;
  select id into br from branches where code = 'WAH-01';
  foreach u in array array['citizen5', 'citizen6'] loop
    select id into uid from profiles where username = u;
    if uid is null then
      nm := case u when 'citizen5' then 'علي كاظم جواد' else 'زينب عباس محمد' end;
      ph := case u when 'citizen5' then '07701234505' else '07701234506' end;
      uid := _mk_user(u, case u when 'citizen5' then 'Alwah@1005' else 'Alwah@1006' end, nm, 'citizen', 'citizen', null, ph, case u when 'citizen5' then '199003120005' else '199208150006' end);
      update profiles set governorate = 'بغداد', city = case u when 'citizen5' then 'المنصور' else 'الكاظمية' end, employer = 'القطاع الخاص', monthly_salary = 1200000, kyc_status = 'verified', kyc_at = now() where id = uid;
    end if;
    if exists (select 1 from applications where citizen_id = uid) then continue; end if;
    stg := case u when 'citizen5' then 33 else 31 end;
    cn := 'ALW-2026-' || case u when 'citizen5' then '00205' else '00206' end;
    k := _sh_calc(p, o.price, 60);
    insert into applications(code, citizen_id, citizen_name, ur_number, ur_verified, offer_id, supplier_id, bank_id, branch_id, kw, price, amount, term_months, margin, monthly_installment,
      guarantee_type, guarantee, governorate, city, lat, lng, stage, status, bank_unit, program, purpose, submitted_at, bank_account, account_opened_at,
      product_id, contract_version_id, contract_sha256, sharia_resolution, site_geo, created_at, updated_at)
    values (cn, uid, (select full_name from profiles where id = uid), 'UR-' || substr(md5(cn), 1, 8), true, o.id, o.supplier_id, (select id from orgs where code = 'bank2'), br, 5, o.price, o.price,
      (k->>'term')::int, (select margin from bank_terms where bank_id = (select id from orgs where code = 'bank2')), round((k->>'installment')::numeric),
      'single_salary', jsonb_build_object('type', 'single_salary', 'guarantors', jsonb_build_array(jsonb_build_object('name', 'حسين علي ناصر', 'employer', 'وزارة الكهرباء', 'salary', 1100000, 'consent', true))),
      'بغداد', case u when 'citizen5' then 'المنصور' else 'الكاظمية' end, 33.3152, 44.3661, stg, 'active', (select owner_label from stages where n = stg), 'solar', 'household',
      now() - interval '40 days', '0' || (case u when 'citizen5' then '207' else '208' end) || '-114-' || floor(random() * 900000 + 100000)::text, now() - interval '38 days',
      p.id, v.id, v.sha256, res, jsonb_build_object('lat', 33.3152, 'lng', 44.3661, 'acc', 8, 'source', 'gps'), now() - interval '45 days', now() - interval '1 day')
    returning id into aid;
    insert into application_events(application_id, stage, action, actor_name, note, created_at)
    select aid, s.n, 'إنجاز: ' || s.name, s.owner_label, null, now() - interval '40 days' + (s.n * interval '20 hours') from stages s where s.n < stg;
    -- الوعد (المقترض) — النص نفسه الذي يُبنى عند التوقيع
    d := _isl_promise((select x from applications x where id = aid));
    d := jsonb_build_object('title', d->>'title', 'clauses', d->'clauses', 'calc', d->'calc', 'spec', null, 'shares', null, 'borrower', (select full_name from profiles where id = uid),
      'app', cn, 'bank', 'مصرف الواحة الإسلامي', 'product', p.name, 'type', 'MRB', 'version', v.n, 'signed_at', now() - interval '40 days');
    insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, resolution, body, doc_sha256, amount, verify_code, actor_id, actor_name, actor_title, signed_via, at)
    values (aid, 'promise', d->>'title', p.id, v.id, v.sha256, res, d, _isl_sha(d), (d->'calc'->>'total')::numeric, _isl_code(), uid, (select full_name from profiles where id = uid), 'المقترض', 'رمز تحقق على هاتف المقترض', now() - interval '40 days');
    if u = 'citizen5' then
      d := jsonb_build_object('invoice_no', 'INV-SB-2026-0412', 'buyer', 'مصرف الواحة الإسلامي', 'seller', (select name from orgs where id = o.supplier_id), 'asset', o.title, 'amount', o.price,
        'date', to_char(now() - interval '6 days', 'YYYY-MM-DD'), 'note', 'المشتري: مصرف الواحة الإسلامي — لا المقترض. يبيعها المصرف للمقترض بعد تملّكها وقبضها.');
      insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_name, actor_title, at)
      values (aid, 'invoice', 'فاتورة المورد باسم مصرف الواحة الإسلامي', p.id, v.id, v.sha256, d, _isl_sha(d), o.price, _isl_code(), 'مدير حساب المورد', 'مدير حساب المورد', now() - interval '6 days');
      d := jsonb_build_object('asset', o.title, 'supplier', (select name from orgs where id = o.supplier_id), 'owner', 'مصرف الواحة الإسلامي', 'invoice_no', 'INV-SB-2026-0412',
        'site', 'بغداد — المنصور', 'by', 'لجنة الكشف الموقعي', 'by_title', 'لجنة الكشف الموقعي', 'date', to_char(now() - interval '1 day', 'YYYY-MM-DD'),
        'statement', 'استلم المصرف المنظومة وقبضها، وصارت ملكه وفي ضمانه');
      insert into islamic_app_docs(application_id, kind, title, product_id, version_id, version_sha256, body, doc_sha256, amount, verify_code, actor_name, actor_title, at)
      values (aid, 'receipt', 'محضر استلام وقبض — المنظومة ملك المصرف', p.id, v.id, v.sha256, d, _isl_sha(d), o.price, _isl_code(), 'لجنة الكشف الموقعي', 'لجنة الكشف الموقعي', now() - interval '1 day');
      insert into application_events(application_id, stage, action, actor_name, note, created_at)
      values (aid, 32, 'محضر القبض: المنظومة صارت ملك المصرف', 'لجنة الكشف الموقعي', 'بانتظار توقيع المقترض للعقد', now() - interval '1 day');
      insert into notifications(user_id, kind, title, body, ref_id) values (uid, 'islamic', 'المنظومة صارت ملك المصرف — وقّع عقد الشراء', 'افتح «طلبي» واضغط «وقّع» — يستغرق دقيقة', aid);
    end if;
  end loop;
end $$;
