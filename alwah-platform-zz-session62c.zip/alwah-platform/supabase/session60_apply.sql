-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 60: نقابة الأطباء البيطريين — الفريق الكامل، «بوابة الأطباء البيطريين» /vets،
--                     هوية النقابة (تفعيل، انتساب، تجديد، طباعة)، وشركات التوصيل المعتمدة /courier
--  1) فريق النقابة: النقيب (صاحب الصلاحية) ورئيس فرع لكل محافظة، وأقسام: العضوية والتسجيل، التدقيق والسجلات،
--     الحسابات، الهويات والطباعة. فروع النقابة في المحافظات من «فريقي ← فروع النقابة»، وجاهزية كل فرع.
--  2) بوابة الطبيب البيطري (حساب شخصي portal = citizen) بثلاث خدمات:
--     أ) منتسب سابق: يفعّل حسابه برفع البطاقة الوطنية وهوية النقابة مع رقم العضوية وتاريخي الإصدار والانتهاء ← قسم العضوية ← التدقيق ← تفعيل.
--     ب) غير منتسب: طلب انتساب بشهادة التخرج والبطاقة الوطنية وبطاقة السكن والصورة وتأييد صدور الشهادة ← الدفع
--        ← العضوية ← التدقيق ← الحسابات ← قرار النقيب ورقم العضوية ← طباعة الهوية ← التوصيل.
--     ج) تجديد الهوية: صورة شخصية جديدة + عنوان الاستلام بالـGPS + الدفع ← العضوية ← الحسابات ← الاعتماد ← الطباعة ← التوصيل.
--  3) التذكير الآلي: قبل انتهاء الهوية بأسبوع ثم بيومين (إشعار + رسالة)، ويوم انتهائها.
--  4) جهة جديدة نوعها courier «شركة توصيل معتمدة» وبوابة /courier: مدير الشركة يسند الشحنة لمندوب،
--     والمندوب يستلم من النقابة ثم يسلّم الطبيب برمز استلام يظهر في هاتف الطبيب فقط.
--  5) التكامل: العضو النافذ يُؤيَّد آلياً في مبادرة تمويل الأطباء البيطريين (vet_memberships).
-- الملف آمن للتكرار. تعديل الدوال القائمة يتم داخل القاعدة باستبدال نص يقع مرة واحدة.
-- ═══════════════════════════════════════════════════════════════════════
set check_function_bodies = off;

-- ───────── 1) نوع الجهة والبوابة ─────────
do $mig$
declare d text;
begin
  select pg_get_constraintdef(oid) into d from pg_constraint where conrelid = 'public.orgs'::regclass and conname = 'orgs_type_check';
  if position('''courier''' in d) = 0 then
    execute 'alter table public.orgs drop constraint orgs_type_check';
    execute 'alter table public.orgs add constraint orgs_type_check ' || replace(d, '''chamber''::text', '''chamber''::text, ''courier''::text');
  end if;
  select pg_get_constraintdef(oid) into d from pg_constraint where conrelid = 'public.profiles'::regclass and conname = 'profiles_portal_check';
  if position('''courier''' in d) = 0 then
    execute 'alter table public.profiles drop constraint profiles_portal_check';
    execute 'alter table public.profiles add constraint profiles_portal_check ' || replace(d, '''chamber''::text', '''chamber''::text, ''courier''::text');
  end if;
end $mig$;

insert into public.settings(key, value, label, circular_no) values
  ('syn_join_fee', 50000, 'نقابة الأطباء البيطريين: رسم الانتساب الجديد (د.ع)', null),
  ('syn_renew_fee', 25000, 'نقابة الأطباء البيطريين: رسم تجديد الهوية لسنة (د.ع)', null),
  ('syn_card_fee', 10000, 'نقابة الأطباء البيطريين: كلفة إصدار الهوية وطباعتها (د.ع)', null),
  ('syn_delivery_fee', 5000, 'نقابة الأطباء البيطريين: أجور توصيل الهوية (د.ع)', null),
  ('syn_card_years', 1, 'نقابة الأطباء البيطريين: مدة نفاذ الهوية (سنوات)', null),
  ('syn_renew_early_days', 30, 'نقابة الأطباء البيطريين: يُفتح التجديد قبل انتهاء الهوية بـ (يوماً)', null),
  ('syn_remind1_days', 7, 'نقابة الأطباء البيطريين: التذكير الأول قبل انتهاء الهوية بـ (يوماً)', null),
  ('syn_remind2_days', 2, 'نقابة الأطباء البيطريين: التذكير الثاني قبل انتهاء الهوية بـ (يوماً)', null),
  ('syn_sla_days', 3, 'نقابة الأطباء البيطريين: مدة إنجاز كل قسم للمعاملة (أيام)', null),
  ('courier_sla_days', 3, 'شركات التوصيل: مدة التسليم بعد الاستلام من الجهة (أيام)', null)
on conflict (key) do nothing;

-- ───────── 2) الجداول ─────────
create table if not exists public.syn_members (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references public.orgs(id),
  citizen_id uuid references public.profiles(id),
  full_name text not null, national_id text, phone text,
  membership_no text,                                   -- رقم العضوية في النقابة
  governorate text not null,                            -- فرع النقابة (المحافظة)
  college text, graduation_year int, degree text check (degree is null or degree in ('bachelor','diploma','master','phd')),
  specialty text,
  status text not null default 'pending' check (status in ('pending','active','expired','suspended','rejected')),
  source text not null default 'join' check (source in ('activation','join')),
  issued_on date, valid_until date,
  photo_doc uuid,                                       -- آخر صورة شخصية معتمدة
  card_version int not null default 0,
  reminders jsonb not null default '{}'::jsonb,
  joined_at date, activated_at timestamptz, renewed_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists syn_members_citizen on public.syn_members(citizen_id);
create unique index if not exists syn_members_no on public.syn_members(membership_no) where membership_no is not null and status <> 'rejected';

create table if not exists public.syn_files (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                            -- SF-2026-00001
  org_id uuid references public.orgs(id),
  kind text not null check (kind in ('activate','join','renewal')),
  member_id uuid not null references public.syn_members(id),
  status text not null default 'draft' check (status in ('draft','new','audit','finance','approval','print','ship','done','returned','rejected','cancelled')),
  data jsonb not null default '{}'::jsonb,              -- ما كتبه الطبيب: رقم العضوية، التواريخ، الكلية…
  delivery jsonb,                                       -- عنوان الاستلام: النص، الـGPS، الهاتف، اسم المستلم
  fee bigint not null default 0, fee_items jsonb not null default '[]'::jsonb, fee_paid_at timestamptz, fee_ref text,
  return_note text, returned_by text, reason text,
  due_at timestamptz, meta jsonb not null default '{}'::jsonb,
  submitted_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), closed_at timestamptz
);
create index if not exists syn_files_member on public.syn_files(member_id);
create index if not exists syn_files_status on public.syn_files(status);

create table if not exists public.syn_docs (
  id uuid primary key default gen_random_uuid(),
  file_id uuid references public.syn_files(id), member_id uuid references public.syn_members(id),
  kind text not null, label text, mime text, data text, bytes int, sha256 text, meta jsonb not null default '{}'::jsonb,
  uploaded_by uuid, uploaded_by_name text, created_at timestamptz not null default now()
);
create index if not exists syn_docs_file on public.syn_docs(file_id);

create table if not exists public.syn_log (
  id bigserial primary key, file_id uuid, member_id uuid,
  actor_id uuid, actor_name text, actor_title text, action text not null, note text, from_status text, to_status text,
  created_at timestamptz not null default now()
);
create index if not exists syn_log_file on public.syn_log(file_id);

create table if not exists public.syn_cards (
  id uuid primary key default gen_random_uuid(),
  card_no text unique not null,                         -- VSC-2026-00001
  member_id uuid not null references public.syn_members(id), file_id uuid references public.syn_files(id),
  version int not null, body jsonb not null, sha256 text not null, verify_code text unique not null,
  status text not null default 'printed' check (status in ('printed','shipped','delivered','void')),
  printed_at timestamptz not null default now(), printed_by_name text, delivered_at timestamptz, void_reason text
);
create index if not exists syn_cards_member on public.syn_cards(member_id);

-- الشحنات: جدول عام لأي جهة ترسل شيئاً عبر شركة توصيل معتمدة (النقابة أولاً)
create table if not exists public.deliveries (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                            -- DLV-2026-00001
  source text not null default 'syndicate', source_org uuid references public.orgs(id), ref_id uuid, ref_code text,
  item text not null,
  courier_org uuid not null references public.orgs(id), agent_id uuid references public.profiles(id), agent_name text,
  recipient_id uuid references public.profiles(id), recipient_name text not null, recipient_phone text,
  governorate text, address text not null, geo jsonb,
  fee bigint not null default 0,
  status text not null default 'new' check (status in ('new','assigned','picked','out','delivered','failed','returned')),
  otp text not null, attempts int not null default 0, proof jsonb, fail_note text,
  events jsonb not null default '[]'::jsonb,
  due_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), delivered_at timestamptz
);
create index if not exists deliveries_courier on public.deliveries(courier_org, status);
create index if not exists deliveries_ref on public.deliveries(ref_id);

alter table public.syn_members enable row level security;
alter table public.syn_files enable row level security;
alter table public.syn_docs enable row level security;
alter table public.syn_log enable row level security;
alter table public.syn_cards enable row level security;
alter table public.deliveries enable row level security;
drop policy if exists sm_read on public.syn_members;
create policy sm_read on public.syn_members for select to authenticated using (my_portal() in ('syndicate', 'cbi', 'integrity') or citizen_id = auth.uid());
drop policy if exists sf_read on public.syn_files;
create policy sf_read on public.syn_files for select to authenticated
  using (my_portal() = 'syndicate' or exists (select 1 from syn_members m where m.id = member_id and m.citizen_id = auth.uid()));
grant select on public.syn_members, public.syn_files to authenticated;
-- المستندات والسجل والهويات والشحنات (فيها رمز الاستلام) عبر الدوال فقط
revoke all on public.syn_docs, public.syn_log, public.syn_cards, public.deliveries from anon, authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'syn_files') then
      alter publication supabase_realtime add table public.syn_files; end if;
  end if;
exception when others then null;
end $$;

-- ───────── 3) أساسيات ─────────
create or replace function public._syn_org() returns uuid language sql stable security definer set search_path = public as $f$
  select id from orgs where type = 'syndicate' order by (code = 'vsi') desc, created_at limit 1 $f$;

create or replace function public._syn_kind_label(k text) returns text language sql immutable as $f$
  select case k when 'activate' then 'تفعيل حساب عضو منتسب' when 'join' then 'انتساب جديد وإصدار هوية' when 'renewal' then 'تجديد هوية النقابة' end $f$;

create or replace function public._syn_status_label(s text) returns text language sql immutable as $f$
  select case s when 'draft' then 'مسودة لم تُرسل' when 'new' then 'لدى قسم العضوية والتسجيل' when 'audit' then 'لدى قسم التدقيق والسجلات'
    when 'finance' then 'لدى قسم الحسابات' when 'approval' then 'بانتظار اعتماد النقيب' when 'print' then 'لدى قسم الهويات — الطباعة'
    when 'ship' then 'مع شركة التوصيل' when 'done' then 'أُنجزت' when 'returned' then 'أُعيدت إليك للاستكمال' when 'rejected' then 'رُفضت'
    when 'cancelled' then 'أُلغيت' end $f$;

create or replace function public._syn_doc_label(k text) returns text language sql immutable as $f$
  select case k when 'id_front' then 'البطاقة الوطنية — الوجه' when 'id_back' then 'البطاقة الوطنية — الظهر'
    when 'syn_front' then 'هوية النقابة — الوجه' when 'syn_back' then 'هوية النقابة — الظهر'
    when 'residence' then 'بطاقة السكن' when 'photo' then 'صورة شخصية حديثة'
    when 'degree' then 'شهادة التخرج (مصدّقة)' when 'degree_verify' then 'تأييد صحة صدور الشهادة من الكلية'
    when 'transcript' then 'وثيقة الدرجات' when 'practice' then 'إجازة ممارسة المهنة (إن وُجدت)' when 'other' then 'مستند آخر' end $f$;

-- المستمسكات المطلوبة لكل معاملة (كما في المعاملة الورقية)
create or replace function public._syn_req_docs(p_kind text) returns text[] language sql immutable as $f$
  select case p_kind
    when 'activate' then array['id_front','id_back','syn_front','syn_back']
    when 'join'     then array['id_front','id_back','residence','photo','degree','degree_verify']
    when 'renewal'  then array['photo']
    else array[]::text[] end $f$;
create or replace function public._syn_opt_docs(p_kind text) returns text[] language sql immutable as $f$
  select case p_kind when 'join' then array['transcript','practice','other'] when 'activate' then array['photo','other'] when 'renewal' then array['syn_front'] else array[]::text[] end $f$;

-- المسار: من قسم إلى قسم حتى نهاية دورة المعاملة
create or replace function public._syn_next(p_kind text, p_status text) returns text language sql immutable as $f$
  select case p_kind
    when 'activate' then case p_status when 'new' then 'audit' when 'audit' then 'done' end
    when 'join'     then case p_status when 'new' then 'audit' when 'audit' then 'finance' when 'finance' then 'approval' when 'approval' then 'print' when 'print' then 'ship' when 'ship' then 'done' end
    when 'renewal'  then case p_status when 'new' then 'finance' when 'finance' then 'approval' when 'approval' then 'print' when 'print' then 'ship' when 'ship' then 'done' end
  end $f$;
create or replace function public._syn_prev(p_kind text, p_status text) returns text language sql immutable as $f$
  select case p_kind
    when 'activate' then case p_status when 'audit' then 'new' end
    when 'join'     then case p_status when 'audit' then 'new' when 'finance' then 'audit' when 'approval' then 'finance' when 'print' then 'approval' end
    when 'renewal'  then case p_status when 'finance' then 'new' when 'approval' then 'finance' when 'print' then 'approval' end
  end $f$;
create or replace function public._syn_path(p_kind text) returns text[] language sql immutable as $f$
  select case p_kind when 'activate' then array['new','audit','done'] when 'join' then array['new','audit','finance','approval','print','ship','done']
    when 'renewal' then array['new','finance','approval','print','ship','done'] end $f$;

-- القسم المالك لكل حالة
create or replace function public._syn_owner(p_status text) returns text[] language sql immutable as $f$
  select case p_status when 'new' then array['syn_reg'] when 'audit' then array['syn_audit'] when 'finance' then array['syn_fin']
    when 'approval' then array['syn_head', 'syn_branch_head'] when 'print' then array['syn_cards'] when 'ship' then array['syn_cards'] else array[]::text[] end $f$;

-- نطاق الموظف: المقر يرى كل المحافظات، وموظف فرع المحافظة يرى محافظته
create or replace function public._syn_gov_ok(me profiles, p_gov text) returns boolean language sql stable security definer set search_path = public as $f$
  select me.branch_id is null or exists (select 1 from branches b where b.id = me.branch_id and p_gov = any(coalesce(b.governorates, '{}'))) $f$;

-- هل يتصرف هذا الموظف في المعاملة الآن؟
create or replace function public._syn_can(me profiles, f syn_files, m syn_members) returns boolean language sql stable security definer set search_path = public as $f$
  select me.portal = 'syndicate' and me.org_id = f.org_id and not coalesce(me.disabled, false) and _syn_gov_ok(me, m.governorate)
    and (me.role = any(_syn_owner(f.status)) or me.role = 'syn_head')
    and (f.status <> 'approval' or me.role = 'syn_head' or (me.role = 'syn_branch_head' and f.kind = 'renewal')) $f$;

create or replace function public._syn_log(p_file uuid, p_member uuid, p_action text, p_note text, p_from text default null, p_to text default null) returns void
language sql security definer set search_path = public as $f$
  insert into syn_log(file_id, member_id, actor_id, actor_name, actor_title, action, note, from_status, to_status)
  select p_file, p_member, auth.uid(), coalesce((select full_name from profiles where id = auth.uid()), 'النظام'),
    coalesce((select _role_title(role) from profiles where id = auth.uid()), 'آلياً'), p_action, nullif(trim(coalesce(p_note, '')), ''), p_from, p_to $f$;

-- إشعار الطبيب (وتصله رسالة نصية إن كانت الرسائل مفعّلة)
create or replace function public._syn_tell(p_member uuid, p_title text, p_body text, p_ref uuid, p_sms boolean default false) returns void
language plpgsql security definer set search_path = public as $f$
declare m syn_members; ph text;
begin
  select * into m from syn_members where id = p_member;
  if m.citizen_id is null then return; end if;
  insert into notifications(user_id, portal, kind, title, body, ref_id) values (m.citizen_id, 'citizen', 'syndicate', p_title, p_body, p_ref);
  if p_sms and to_regprocedure('public._sms_enqueue(text,text,text,uuid,uuid,text,boolean)') is not null then
    select phone into ph from profiles where id = m.citizen_id;
    begin
      perform _sms_enqueue(coalesce(ph, m.phone), 'notice', 'نقابة الأطباء البيطريين: ' || p_title || '. ' || coalesce(p_body, '') || ' ' || coalesce(_sms_url(), '') || '/vets',
        null, m.citizen_id, 'syn:' || p_member || ':' || md5(p_title));
    exception when others then null; end;
  end if;
end $f$;

-- إشعار القسم المختص: في فرع محافظة الطبيب إن كان فيه من يحمل الدور، وإلا المقر
create or replace function public._syn_notify(p_roles text[], p_gov text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path = public as $f$
declare o uuid := _syn_org(); n int;
begin
  if o is null then return; end if;
  insert into notifications(org_id, user_id, portal, kind, title, body, ref_id)
  select o, p.id, 'syndicate', 'syndicate', p_title, p_body, p_ref from profiles p
  where p.org_id = o and p.role = any(p_roles) and not coalesce(p.disabled, false) and _syn_gov_ok(p, p_gov)
    and (p.branch_id is not null and exists (select 1 from branches b where b.id = p.branch_id and p_gov = any(coalesce(b.governorates, '{}')))
      or (p.branch_id is null and not exists (select 1 from profiles q join branches b on b.id = q.branch_id
            where q.org_id = o and q.role = p.role and not coalesce(q.disabled, false) and p_gov = any(coalesce(b.governorates, '{}')))));
  get diagnostics n = row_count;
  if n = 0 then perform _notify(o, 'syndicate', 'syndicate', p_title, p_body, p_ref); end if;
end $f$;

-- التكامل مع مبادرة التمويل: العضو النافذ مؤيَّد آلياً
create or replace function public._syn_sync_vet(p_member uuid) returns void language plpgsql security definer set search_path = public as $f$
declare m syn_members;
begin
  select * into m from syn_members where id = p_member;
  if m.citizen_id is null or m.status <> 'active' or m.valid_until < current_date or to_regclass('public.vet_memberships') is null then return; end if;
  insert into vet_memberships(profile_id, full_name, national_id, membership_no, syndicate_branch, license_year, graduation_year, college, specialty,
    status, letter_no, valid_until, decided_by_title, decided_at, submitted_at)
  values (m.citizen_id, m.full_name, m.national_id, m.membership_no, m.governorate, extract(year from current_date)::int, m.graduation_year, m.college, m.specialty,
    'endorsed', _vet_seq('VSI', 'vet_memberships', 'letter_no'), m.valid_until, 'هوية نقابة نافذة — بوابة الأطباء البيطريين', now(), now())
  on conflict (profile_id) do update set membership_no = excluded.membership_no, syndicate_branch = excluded.syndicate_branch,
    license_year = excluded.license_year, status = 'endorsed', letter_no = coalesce(vet_memberships.letter_no, excluded.letter_no),
    valid_until = excluded.valid_until, decided_by_title = excluded.decided_by_title, decided_at = now(), updated_at = now()
  where vet_memberships.status <> 'pending';
end $f$;

-- ───────── 4) التذكير الآلي والانتهاء ─────────
create or replace function public._syn_scan() returns void language plpgsql security definer set search_path = public as $f$
declare m record; d1 int := coalesce(_setting('syn_remind1_days'), 7)::int; d2 int := coalesce(_setting('syn_remind2_days'), 2)::int; k text; v_left int;
begin
  for m in update syn_members set status = 'expired', updated_at = now() where status = 'active' and valid_until < current_date returning * loop
    if not (m.reminders ? ('exp:' || m.valid_until)) then
      perform _syn_tell(m.id, 'انتهت هوية النقابة رقم ' || coalesce(m.membership_no, ''), 'جدّدها الآن من «بوابة الأطباء البيطريين» ← «جدّد هويتي» وتصلك الهوية الجديدة إلى بابك', m.id, true);
      update syn_members set reminders = reminders || jsonb_build_object('exp:' || m.valid_until, now()) where id = m.id;
    end if;
  end loop;
  for m in select * from syn_members where status = 'active' and citizen_id is not null and valid_until between current_date and current_date + d1 loop
    v_left := m.valid_until - current_date; k := null;
    if v_left <= d2 and not (m.reminders ? ('d2:' || m.valid_until)) then k := 'd2:' || m.valid_until;
    elsif v_left > d2 and not (m.reminders ? ('d1:' || m.valid_until)) then k := 'd1:' || m.valid_until; end if;
    if k is not null then
      perform _syn_tell(m.id, case when v_left = 0 then 'تنتهي هوية النقابة اليوم' when v_left = 1 then 'تنتهي هوية النقابة غداً' else 'تنتهي هوية النقابة بعد ' || v_left || ' أيام' end
        || ' (' || to_char(m.valid_until, 'YYYY-MM-DD') || ')',
        'جدّدها من هاتفك: صورة شخصية جديدة، عنوان الاستلام، والدفع — وتصلك الهوية الجديدة إلى بابك', m.id, true);
      update syn_members set reminders = reminders || jsonb_build_object(k, now()) where id = m.id;
    end if;
  end loop;
end $f$;

do $c$ begin
  if to_regprocedure('cron.schedule(text,text,text)') is not null then
    perform cron.schedule('alwah_syn_scan', '7 * * * *', 'select public._syn_scan()');
  end if;
exception when others then null;
end $c$;

-- ───────── 5) بوابة الطبيب البيطري ─────────
create or replace function public._syn_docs_check(p_file uuid) returns jsonb language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(jsonb_build_object('kind', k, 'label', _syn_doc_label(k), 'required', req,
      'doc', (select d.id from syn_docs d where d.file_id = p_file and d.kind = k order by d.created_at desc limit 1)) order by ord), '[]')
  from (select k, true req, ord from unnest(_syn_req_docs((select kind from syn_files where id = p_file))) with ordinality x(k, ord)
        union all select k, false, 100 + ord from unnest(_syn_opt_docs((select kind from syn_files where id = p_file))) with ordinality y(k, ord)) z $f$;

create or replace function public._syn_docs_missing(p_file uuid) returns text[] language sql stable security definer set search_path = public as $f$
  select coalesce(array_agg(_syn_doc_label(k)), '{}') from unnest(_syn_req_docs((select kind from syn_files where id = p_file))) k
  where not exists (select 1 from syn_docs d where d.file_id = p_file and d.kind = k) $f$;

create or replace function public._syn_fee(p_kind text) returns jsonb language sql stable security definer set search_path = public as $f$
  select case p_kind
    when 'join' then jsonb_build_array(jsonb_build_object('t', 'رسم الانتساب', 'v', coalesce(_setting('syn_join_fee'), 50000)),
                                        jsonb_build_object('t', 'إصدار الهوية وطباعتها', 'v', coalesce(_setting('syn_card_fee'), 10000)),
                                        jsonb_build_object('t', 'أجور التوصيل', 'v', coalesce(_setting('syn_delivery_fee'), 5000)))
    when 'renewal' then jsonb_build_array(jsonb_build_object('t', 'رسم التجديد لسنة', 'v', coalesce(_setting('syn_renew_fee'), 25000)),
                                        jsonb_build_object('t', 'إصدار الهوية وطباعتها', 'v', coalesce(_setting('syn_card_fee'), 10000)),
                                        jsonb_build_object('t', 'أجور التوصيل', 'v', coalesce(_setting('syn_delivery_fee'), 5000)))
    else '[]'::jsonb end $f$;

-- هل يُفتح التجديد الآن؟
create or replace function public._syn_renew_state(m syn_members) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare early int := coalesce(_setting('syn_renew_early_days'), 30)::int; opens date;
begin
  if m.id is null or m.status not in ('active', 'expired') then return jsonb_build_object('allowed', false, 'why', 'لا هوية نقابة مفعّلة'); end if;
  if exists (select 1 from syn_files where member_id = m.id and kind = 'renewal' and status in ('new','finance','approval','print','ship','returned')) then
    return jsonb_build_object('allowed', false, 'pending', true, 'why', 'لديك طلب تجديد قيد الإنجاز — تابعه من «معاملاتي»'); end if;
  opens := m.valid_until - early;
  if m.status = 'active' and current_date < opens then
    return jsonb_build_object('allowed', false, 'early', true, 'opens_at', opens, 'why', 'هويتك نافذة حتى ' || m.valid_until || ' — يُفتح التجديد في ' || opens); end if;
  return jsonb_build_object('allowed', true, 'new_valid', (greatest(m.valid_until, current_date) + make_interval(years => coalesce(_setting('syn_card_years'), 1)::int))::date);
end $f$;

create or replace function public._syn_delivery_pub(p_ref uuid) returns jsonb language sql stable security definer set search_path = public as $f$
  select jsonb_build_object('code', d.code, 'status', d.status, 'courier', o.name, 'courier_phone', o.meta->>'phone', 'agent', d.agent_name,
    'agent_phone', (select phone from profiles where id = d.agent_id), 'otp', case when d.status in ('assigned','picked','out','failed') then d.otp end,
    'address', d.address, 'delivered_at', d.delivered_at, 'fail_note', d.fail_note, 'updated_at', d.updated_at)
  from deliveries d join orgs o on o.id = d.courier_org where d.ref_id = p_ref order by d.created_at desc limit 1 $f$;

create or replace function public.syn_my() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m syn_members;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'سجّل الدخول'; end if;
  perform set_config('alwah.face_skip', '1', true); perform _syn_scan(); perform set_config('alwah.face_skip', '', true);
  select * into m from syn_members where citizen_id = me.id and status <> 'rejected' order by (status in ('active','expired')) desc, created_at desc limit 1;
  return jsonb_build_object(
    'org', (select jsonb_build_object('id', id, 'name', name) from orgs where id = _syn_org()),
    'me', jsonb_build_object('name', me.full_name, 'phone', me.phone, 'governorate', me.governorate, 'national_id', me.national_id),
    'fees', jsonb_build_object('join', _syn_fee('join'), 'renewal', _syn_fee('renewal'), 'years', coalesce(_setting('syn_card_years'), 1),
      'remind1', coalesce(_setting('syn_remind1_days'), 7), 'remind2', coalesce(_setting('syn_remind2_days'), 2)),
    'member', case when m.id is not null then to_jsonb(m) - 'reminders' || jsonb_build_object('valid', m.status = 'active' and m.valid_until >= current_date,
      'days_left', case when m.valid_until is not null then m.valid_until - current_date end, 'renew', _syn_renew_state(m),
      'photo', (select data from syn_docs where id = m.photo_doc),
      'card', (select jsonb_build_object('card_no', c.card_no, 'version', c.version, 'verify_code', c.verify_code, 'status', c.status, 'printed_at', c.printed_at, 'body', c.body)
               from syn_cards c where c.member_id = m.id and c.status <> 'void' order by c.version desc limit 1)) end,
    'files', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _syn_kind_label(f.kind), 'status', f.status,
        'status_label', _syn_status_label(f.status), 'path', to_jsonb(_syn_path(f.kind)), 'data', f.data, 'delivery', f.delivery, 'fee', f.fee, 'fee_items', f.fee_items,
        'fee_paid_at', f.fee_paid_at, 'fee_ref', f.fee_ref, 'return_note', f.return_note, 'reason', f.reason, 'created_at', f.created_at, 'updated_at', f.updated_at,
        'submitted_at', f.submitted_at, 'docs', _syn_docs_check(f.id), 'ship', _syn_delivery_pub(f.id),
        'log', (select coalesce(jsonb_agg(jsonb_build_object('a', l.action, 'by', l.actor_title, 'at', l.created_at, 'note', case when l.action like 'إعادة داخلية%' then null else l.note end) order by l.id), '[]')
                from syn_log l where l.file_id = f.id))
        order by f.created_at desc) from syn_files f join syn_members x on x.id = f.member_id where x.citizen_id = me.id and f.status <> 'cancelled'), '[]'));
end $f$;

-- فتح معاملة (مسودة) أو تحديث بياناتها: activate | join | renewal
create or replace function public.syn_start(p_kind text, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; m syn_members; f syn_files; o uuid := _syn_org(); v_gov text; v_iss date; v_exp date; v_no text; st jsonb; v_data jsonb := '{}'; v_year int;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'citizen' then raise exception 'التقديم من «بوابة الأطباء البيطريين» بحسابك الشخصي'; end if;
  if o is null then raise exception 'نقابة الأطباء البيطريين غير مضافة إلى المنصة بعد'; end if;
  p := coalesce(p, '{}');
  if p_kind not in ('activate','join','renewal') then raise exception 'نوع معاملة غير معروف'; end if;

  if p_kind = 'renewal' then
    select * into m from syn_members where citizen_id = me.id and status in ('active','expired') order by created_at desc limit 1;
    select * into f from syn_files where member_id = m.id and kind = 'renewal' and status = 'draft' order by created_at desc limit 1;
    if f.id is null then
      st := _syn_renew_state(m);
      if not (st->>'allowed')::boolean then raise exception '%', st->>'why'; end if;
    end if;
  else
    if exists (select 1 from syn_members where citizen_id = me.id and status in ('active','expired')) then
      raise exception 'حسابك مفعّل بهوية النقابة — للتجديد اختر «جدّد هويتي»'; end if;
    if exists (select 1 from syn_files sf join syn_members x on x.id = sf.member_id where x.citizen_id = me.id and sf.kind in ('activate','join')
               and sf.status in ('new','audit','finance','approval','print','ship','returned')) then
      raise exception 'لديك معاملة قيد الإنجاز لدى النقابة — تابعها من «معاملاتي»'; end if;
    v_gov := coalesce(nullif(p->>'governorate', ''), me.governorate);
    if v_gov is null then raise exception 'اختر فرع النقابة (المحافظة)'; end if;
    v_year := nullif(regexp_replace(coalesce(p->>'graduation_year', ''), '[^0-9]', '', 'g'), '')::int;
    if v_year is not null and (v_year < 1960 or v_year > extract(year from current_date)) then raise exception 'سنة التخرج غير صحيحة'; end if;
    if length(trim(coalesce(p->>'college', ''))) < 3 then raise exception 'اكتب الكلية التي تخرّجت منها'; end if;
    if p_kind = 'activate' then
      v_no := upper(trim(coalesce(p->>'membership_no', '')));
      if v_no !~ '^[A-Z0-9/-]{2,20}$' then raise exception 'اكتب رقم العضوية كما في هوية النقابة'; end if;
      begin v_iss := (p->>'issued_on')::date; v_exp := (p->>'valid_until')::date; exception when others then raise exception 'تاريخ غير صحيح'; end;
      if v_iss is null or v_exp is null then raise exception 'اكتب تاريخ إصدار هوية النقابة وتاريخ انتهائها'; end if;
      if v_iss > current_date then raise exception 'تاريخ الإصدار في المستقبل — تأكد منه'; end if;
      if v_exp <= v_iss then raise exception 'تاريخ الانتهاء يجب أن يكون بعد تاريخ الإصدار'; end if;
      if exists (select 1 from syn_members x where x.membership_no = v_no and x.status in ('active','expired','suspended') and x.citizen_id is distinct from me.id) then
        raise exception 'رقم العضوية % مفعّل لحساب آخر — راجع فرع النقابة', v_no; end if;
      v_data := jsonb_build_object('membership_no', v_no, 'issued_on', v_iss, 'valid_until', v_exp);
    else
      if v_year is null then raise exception 'اكتب سنة التخرج'; end if;
    end if;
    v_data := v_data || jsonb_build_object('governorate', v_gov, 'college', trim(p->>'college'), 'graduation_year', v_year,
      'degree', coalesce(nullif(p->>'degree', ''), 'bachelor'), 'specialty', nullif(trim(coalesce(p->>'specialty', '')), ''));
    select sf.* into f from syn_files sf join syn_members x on x.id = sf.member_id where x.citizen_id = me.id and sf.kind = p_kind and sf.status = 'draft' order by sf.created_at desc limit 1;
    if f.id is null then
      select * into m from syn_members where citizen_id = me.id and status = 'pending' order by created_at desc limit 1;
      if m.id is null then
        insert into syn_members(org_id, citizen_id, full_name, national_id, phone, governorate, source)
        values (o, me.id, me.full_name, me.national_id, me.phone, v_gov, case when p_kind = 'activate' then 'activation' else 'join' end) returning * into m;
      end if;
    else
      select * into m from syn_members where id = f.member_id;
    end if;
    update syn_members set governorate = v_gov, college = v_data->>'college', graduation_year = v_year, degree = v_data->>'degree', specialty = v_data->>'specialty',
      source = case when p_kind = 'activate' then 'activation' else 'join' end, full_name = me.full_name, national_id = coalesce(me.national_id, national_id), phone = coalesce(me.phone, phone),
      updated_at = now() where id = m.id returning * into m;
  end if;

  if f.id is null then
    insert into syn_files(code, org_id, kind, member_id, status, data, fee, fee_items)
    values (_vet_seq('SF', 'syn_files', 'code'), o, p_kind, m.id, 'draft', v_data,
      coalesce((select sum((x->>'v')::bigint) from jsonb_array_elements(_syn_fee(p_kind)) x), 0), _syn_fee(p_kind))
    returning * into f;
  elsif p_kind <> 'renewal' then
    update syn_files set data = data || v_data, fee = coalesce((select sum((x->>'v')::bigint) from jsonb_array_elements(_syn_fee(p_kind)) x), 0), fee_items = _syn_fee(p_kind), updated_at = now()
    where id = f.id returning * into f;
  end if;
  return jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'fee', f.fee, 'fee_items', f.fee_items, 'docs', _syn_docs_check(f.id), 'data', f.data, 'delivery', f.delivery);
end $f$;

-- رفع مستند: الطبيب (مسودة أو معاملة معادة إليه)
create or replace function public.syn_doc_add(p_file uuid, p_kind text, p_data text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; f syn_files; m syn_members; mime text; sz int := length(coalesce(p_data, '')); did uuid;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from syn_files where id = p_file;
  select * into m from syn_members where id = f.member_id;
  if f.id is null or m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
  if f.status not in ('draft', 'returned') then raise exception 'المعاملة لدى النقابة الآن — تُغيَّر مستنداتها إن أُعيدت إليك'; end if;
  if not (p_kind = any(_syn_req_docs(f.kind) || _syn_opt_docs(f.kind))) then raise exception 'نوع مستند غير مطلوب في هذه المعاملة'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg', 'image/png', 'application/pdf') then raise exception 'صورة أو PDF فقط'; end if;
  if p_kind = 'photo' and mime = 'application/pdf' then raise exception 'الصورة الشخصية صورة فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  delete from syn_docs where file_id = f.id and kind = p_kind;
  insert into syn_docs(file_id, member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name)
  values (f.id, f.member_id, p_kind, _syn_doc_label(p_kind), mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}') || jsonb_build_object('server_at', now()), me.id, me.full_name)
  returning id into did;
  return did;
end $f$;

-- عرض مستند: صاحبه أو موظف النقابة في نطاقه
create or replace function public.syn_doc(p_id uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; d syn_docs; m syn_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into d from syn_docs where id = p_id;
  select * into m from syn_members where id = d.member_id;
  if d.id is null then raise exception 'المستند غير موجود'; end if;
  if not (m.citizen_id = me.id or (me.portal = 'syndicate' and me.org_id = m.org_id and _syn_gov_ok(me, m.governorate)) or me.portal in ('cbi', 'integrity')) then
    raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label, 'mime', d.mime, 'data', d.data, 'at', d.created_at, 'meta', d.meta - 'server_at');
end $f$;

-- الإرسال: التفعيل بلا رسوم، والانتساب والتجديد بعنوان الاستلام والدفع
create or replace function public.syn_submit(p_file uuid, p jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f syn_files; m syn_members; miss text[]; g jsonb; v_addr text; v_phone text; v_ph uuid; was_ret boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from syn_files where id = p_file for update;
  select * into m from syn_members where id = f.member_id for update;
  if f.id is null or m.citizen_id is distinct from me.id then raise exception 'المعاملة لا تخصك'; end if;
  if f.status not in ('draft', 'returned') then raise exception 'المعاملة أُرسلت سابقاً'; end if;
  was_ret := f.status = 'returned';
  p := coalesce(p, '{}');
  miss := _syn_docs_missing(f.id);
  if cardinality(miss) > 0 then raise exception 'ارفع الناقص: %', array_to_string(miss, '، '); end if;
  if not coalesce((p->>'confirm')::boolean, false) then raise exception 'أقرّ بصحة البيانات والمستمسكات'; end if;

  if f.kind in ('join', 'renewal') and not was_ret then
    g := p->'geo'; v_addr := trim(coalesce(p->>'address', '')); v_phone := coalesce(nullif(regexp_replace(coalesce(p->>'phone', ''), '[^0-9]', '', 'g'), ''), me.phone);
    if g is null or jsonb_typeof(g) <> 'object' or (g->>'lat') is null then raise exception 'حدّد عنوان استلام الهوية على الخريطة (GPS)'; end if;
    if length(v_addr) < 6 then raise exception 'اكتب عنوان الاستلام: المنطقة، الشارع، أقرب نقطة دالة'; end if;
    if v_phone !~ '^07[3-9][0-9]{8}$' then raise exception 'رقم هاتف المستلم غير صحيح'; end if;
    perform _un_pay_check(p->>'method', p->>'otp');
    update syn_files set delivery = jsonb_build_object('address', v_addr, 'phone', v_phone, 'recipient', coalesce(nullif(trim(p->>'recipient'), ''), me.full_name),
        'geo', jsonb_build_object('lat', (g->>'lat')::numeric, 'lng', (g->>'lng')::numeric, 'acc', round(coalesce((g->>'acc')::numeric, 0)), 'at', now()),
        'governorate', m.governorate),
      fee_paid_at = now(), fee_ref = _un_pay_ref(case f.kind when 'join' then 'VJN' else 'VRN' end, p->>'method')
    where id = f.id returning * into f;
  end if;

  if f.kind = 'renewal' then
    select id into v_ph from syn_docs where file_id = f.id and kind = 'photo' order by created_at desc limit 1;
    update syn_files set meta = meta || jsonb_build_object('photo_doc', v_ph) where id = f.id returning * into f;
  end if;

  update syn_files set status = 'new', return_note = null, submitted_at = coalesce(submitted_at, now()), updated_at = now(),
    due_at = now() + make_interval(days => coalesce(_setting('syn_sla_days'), 3)::int), meta = meta || jsonb_build_object('confirm', true)
  where id = f.id returning * into f;
  perform _syn_log(f.id, m.id, case when was_ret then 'أعاد الطبيب المعاملة بعد الاستكمال' else 'تقديم: ' || _syn_kind_label(f.kind) end,
    case when f.fee_paid_at is not null and not was_ret then 'دفع إلكتروني ' || to_char(f.fee, 'FM999,999,999') || ' د.ع · ' || f.fee_ref end, case when was_ret then 'returned' else 'draft' end, 'new');
  perform _syn_notify(array['syn_reg'], m.governorate, 'معاملة واردة ' || f.code || ': ' || _syn_kind_label(f.kind), m.full_name || ' — فرع ' || m.governorate, f.id);
  perform _syn_tell(m.id, 'وصلت معاملتك ' || f.code || ' إلى النقابة', _syn_kind_label(f.kind) || ' — يدققها قسم العضوية والتسجيل في فرع ' || m.governorate, f.id);
  return jsonb_build_object('ok', true, 'code', f.code, 'ref', f.fee_ref, 'fee', case when f.kind = 'activate' then 0 else f.fee end, 'kind', f.kind);
end $f$;

create or replace function public.syn_discard(p_file uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f syn_files; m syn_members;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from syn_files where id = p_file;
  select * into m from syn_members where id = f.member_id;
  if m.citizen_id is distinct from me.id or f.status <> 'draft' then raise exception 'لا مسودة لحذفها'; end if;
  update syn_files set status = 'cancelled', closed_at = now(), updated_at = now() where id = f.id;
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 6) النقابة: الوارد والمعاملة والإجراءات ─────────
create or replace function public.syn_inbox() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'syndicate' then raise exception 'غير مخوّل'; end if;
  perform set_config('alwah.face_skip', '1', true); perform _syn_scan(); perform set_config('alwah.face_skip', '', true);
  return jsonb_build_object(
    'role', me.role, 'role_title', _role_title(me.role), 'branch', (select name from branches where id = me.branch_id),
    'files', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'kind', f.kind, 'kind_label', _syn_kind_label(f.kind), 'status', f.status,
        'status_label', _syn_status_label(f.status), 'name', m.full_name, 'governorate', m.governorate, 'membership_no', coalesce(m.membership_no, f.data->>'membership_no'),
        'mine', _syn_can(me, f, m), 'late', f.due_at < now() and f.status in ('new','audit','finance','approval','print'), 'due_at', f.due_at,
        'submitted_at', f.submitted_at, 'updated_at', f.updated_at, 'fee', f.fee, 'ship', case when f.status in ('ship','done') then _syn_delivery_pub(f.id) - 'otp' end)
        order by _syn_can(me, f, m) desc, f.due_at nulls last)
      from syn_files f join syn_members m on m.id = f.member_id
      where f.org_id = me.org_id and f.status not in ('draft','cancelled') and _syn_gov_ok(me, m.governorate)), '[]'),
    'counts', (select jsonb_build_object('active', count(*) filter (where status = 'active'), 'expired', count(*) filter (where status = 'expired'),
        'soon', count(*) filter (where status = 'active' and valid_until <= current_date + coalesce(_setting('syn_remind1_days'), 7)::int))
      from syn_members m where m.org_id = me.org_id and _syn_gov_ok(me, m.governorate)));
end $f$;

create or replace function public.syn_members_list(p_q text default null) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; q text := nullif(trim(coalesce(p_q, '')), '');
begin
  select * into me from profiles where id = auth.uid();
  if me.portal not in ('syndicate', 'cbi', 'integrity') then raise exception 'غير مخوّل'; end if;
  return coalesce((select jsonb_agg(x order by x->>'name') from (
    select jsonb_build_object('id', m.id, 'name', m.full_name, 'membership_no', m.membership_no, 'governorate', m.governorate, 'status', m.status,
      'valid_until', m.valid_until, 'days_left', m.valid_until - current_date, 'source', m.source, 'specialty', m.specialty, 'college', m.college,
      'graduation_year', m.graduation_year, 'card_version', m.card_version, 'phone', m.phone,
      'reminded', (select string_agg(k, ',') from jsonb_object_keys(m.reminders) k where k like '%' || m.valid_until::text)) x
    from syn_members m where m.status <> 'pending' and (me.portal <> 'syndicate' or (m.org_id = me.org_id and _syn_gov_ok(me, m.governorate)))
      and (q is null or m.full_name ilike '%' || q || '%' or m.membership_no ilike q || '%' or m.national_id = q)
    limit 300) s), '[]');
end $f$;

create or replace function public.syn_file(p_id uuid) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f syn_files; m syn_members; ok boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from syn_files where id = p_id;
  select * into m from syn_members where id = f.member_id;
  if f.id is null then raise exception 'المعاملة غير موجودة'; end if;
  if not (me.portal = 'syndicate' and me.org_id = f.org_id and _syn_gov_ok(me, m.governorate)) then raise exception 'المعاملة خارج نطاقك'; end if;
  ok := _syn_can(me, f, m);
  return jsonb_build_object('file', to_jsonb(f) || jsonb_build_object('kind_label', _syn_kind_label(f.kind), 'status_label', _syn_status_label(f.status), 'path', to_jsonb(_syn_path(f.kind)),
      'prev', _syn_prev(f.kind, f.status), 'next', _syn_next(f.kind, f.status), 'next_label', _syn_status_label(_syn_next(f.kind, f.status)),
      'prev_label', _syn_status_label(_syn_prev(f.kind, f.status))),
    'member', to_jsonb(m) - 'reminders' || jsonb_build_object('photo', (select data from syn_docs where id = m.photo_doc)),
    'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'label', d.label, 'mime', d.mime, 'at', d.created_at,
        'thumb', case when d.mime like 'image/%' and d.bytes < 600000 then d.data end) order by d.created_at), '[]') from syn_docs d where d.file_id = f.id),
    'missing', to_jsonb(_syn_docs_missing(f.id)),
    'log', (select coalesce(jsonb_agg(to_jsonb(l) - 'actor_id' order by l.id), '[]') from syn_log l where l.file_id = f.id),
    'card', (select to_jsonb(c) from syn_cards c where c.file_id = f.id order by c.version desc limit 1),
    'ship', _syn_delivery_pub(f.id) - 'otp',
    'can', ok, 'role', me.role,
    'history', (select coalesce(jsonb_agg(jsonb_build_object('code', x.code, 'kind', _syn_kind_label(x.kind), 'status', _syn_status_label(x.status), 'at', x.created_at) order by x.created_at desc), '[]')
                from syn_files x where x.member_id = m.id and x.id <> f.id and x.status not in ('draft','cancelled')),
    'dup', (select coalesce(jsonb_agg(jsonb_build_object('name', x.full_name, 'no', x.membership_no, 'status', x.status, 'gov', x.governorate)), '[]') from syn_members x
            where x.id <> m.id and x.status <> 'rejected' and ((x.national_id is not null and x.national_id = m.national_id) or (coalesce(m.membership_no, f.data->>'membership_no') is not null
              and x.membership_no = coalesce(m.membership_no, f.data->>'membership_no')))),
    'couriers', case when f.status = 'print' then (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name,
        'covers', coalesce(o.meta->'governorates', '[]'::jsonb), 'agents', (select count(*) from profiles a where a.org_id = o.id and a.role = 'courier_agent' and not coalesce(a.disabled, false)))
        order by (coalesce(jsonb_array_length(o.meta->'governorates'), 0) = 0 or o.meta->'governorates' ? m.governorate) desc, o.name), '[]')
      from orgs o where o.type = 'courier' and not coalesce((o.meta->>'suspended')::boolean, false)) end);
end $f$;

-- إصدار الهوية (عند الطباعة): رقم، نسخة، بصمة، رمز تحقق
create or replace function public._syn_vcode() returns text language sql volatile as $f$
  select 'VS' || upper(substr(translate(encode(extensions.gen_random_bytes(15), 'base64'), '+/=0O1Il', ''), 1, 8)) $f$;

create or replace function public._syn_issue_card(f syn_files) returns syn_cards language plpgsql security definer set search_path = public, extensions as $f$
declare m syn_members; c syn_cards; me profiles; b jsonb; v int;
begin
  select * into me from profiles where id = auth.uid();
  select * into m from syn_members where id = f.member_id for update;
  update syn_cards set status = 'void', void_reason = 'صدرت نسخة أحدث' where member_id = m.id and status in ('printed','shipped','delivered');
  v := m.card_version + 1;
  b := jsonb_build_object('org', (select name from orgs where id = m.org_id), 'name', m.full_name, 'membership_no', m.membership_no, 'governorate', m.governorate,
    'specialty', m.specialty, 'degree', m.degree, 'college', m.college, 'graduation_year', m.graduation_year,
    'issued_on', current_date, 'valid_until', m.valid_until, 'version', v, 'national_id_tail', right(coalesce(m.national_id, ''), 4));
  insert into syn_cards(card_no, member_id, file_id, version, body, sha256, verify_code, status, printed_by_name)
  values (_vet_seq('VSC', 'syn_cards', 'card_no'), m.id, f.id, v, b, encode(digest(b::text, 'sha256'), 'hex'), _syn_vcode(), 'printed', me.full_name)
  returning * into c;
  update syn_members set card_version = v, issued_on = current_date, updated_at = now() where id = m.id;
  return c;
end $f$;

-- ما يحدث عند انتهاء كل مرحلة
create or replace function public._syn_complete(f syn_files, p jsonb) returns syn_files language plpgsql security definer set search_path = public as $f$
declare m syn_members; v_no text; v_iss date; v_exp date;
begin
  select * into m from syn_members where id = f.member_id for update;
  -- التفعيل: التدقيق يطابق بيانات الهوية الورقية مع سجل النقابة (ويصحّحها إن لزم)
  if f.kind = 'activate' and f.status = 'audit' then
    v_no := upper(trim(coalesce(nullif(p->>'membership_no', ''), f.data->>'membership_no')));
    v_iss := coalesce(nullif(p->>'issued_on', '')::date, (f.data->>'issued_on')::date);
    v_exp := coalesce(nullif(p->>'valid_until', '')::date, (f.data->>'valid_until')::date);
    if v_exp <= v_iss then raise exception 'تاريخ الانتهاء يجب أن يكون بعد تاريخ الإصدار'; end if;
    if exists (select 1 from syn_members x where x.membership_no = v_no and x.id <> m.id and x.status in ('active','expired','suspended')) then
      raise exception 'رقم العضوية % مفعّل لحساب آخر — لا يُفعَّل مرتين', v_no; end if;
    update syn_members set membership_no = v_no, issued_on = v_iss, valid_until = v_exp, joined_at = coalesce(joined_at, v_iss),
      status = case when v_exp >= current_date then 'active' else 'expired' end, activated_at = now(), card_version = greatest(card_version, 1),
      photo_doc = coalesce((select id from syn_docs where file_id = f.id and kind = 'photo' order by created_at desc limit 1), photo_doc), updated_at = now()
    where id = m.id returning * into m;
    update syn_files set data = data || jsonb_build_object('membership_no', v_no, 'issued_on', v_iss, 'valid_until', v_exp) where id = f.id returning * into f;
    perform _syn_sync_vet(m.id);
    perform _syn_tell(m.id, case when m.status = 'active' then 'فُعّل حسابك في نقابة الأطباء البيطريين ✓' else 'فُعّل حسابك — وهويتك منتهية' end,
      case when m.status = 'active' then 'هويتك رقم ' || v_no || ' نافذة حتى ' || v_exp || '. نذكّرك قبل انتهائها بأسبوع ثم بيومين'
        else 'انتهت هويتك في ' || v_exp || ' — جدّدها الآن من «جدّد هويتي»' end, f.id, true);
  -- الانتساب: قرار النقيب يمنح رقم العضوية ويبدأ النفاذ
  elsif f.kind = 'join' and f.status = 'approval' then
    -- أرقام العضوية الجديدة تبدأ من 90001 فلا تتعارض مع أرقام الهويات الورقية السابقة
    v_no := coalesce(m.membership_no, (select coalesce(max(membership_no::bigint) filter (where membership_no::bigint > 90000), 90000) + 1
            from syn_members where membership_no ~ '^[0-9]{1,12}$')::text);
    update syn_members set membership_no = v_no, status = 'active', joined_at = current_date, valid_until = (current_date + make_interval(years => coalesce(_setting('syn_card_years'), 1)::int))::date,
      photo_doc = (select id from syn_docs where file_id = f.id and kind = 'photo' order by created_at desc limit 1), activated_at = now(), updated_at = now()
    where id = m.id returning * into m;
    update syn_files set data = data || jsonb_build_object('membership_no', v_no, 'valid_until', m.valid_until) where id = f.id returning * into f;
    perform _syn_sync_vet(m.id);
    perform _syn_tell(m.id, 'قُبل انتسابك — رقم عضويتك ' || v_no, 'هويتك تُطبع الآن وتصلك عبر شركة التوصيل. عضويتك نافذة حتى ' || m.valid_until, f.id, true);
  -- التجديد: الاعتماد يمدّ النفاذ فوراً، والهوية الجديدة تُطبع وتُرسل
  elsif f.kind = 'renewal' and f.status = 'approval' then
    update syn_members set valid_until = (greatest(valid_until, current_date) + make_interval(years => coalesce(_setting('syn_card_years'), 1)::int))::date,
      status = 'active', renewed_at = now(), photo_doc = coalesce((f.meta->>'photo_doc')::uuid, photo_doc), updated_at = now()
    where id = m.id returning * into m;
    update syn_files set data = data || jsonb_build_object('valid_until', m.valid_until) where id = f.id returning * into f;
    perform _syn_sync_vet(m.id);
    perform _syn_tell(m.id, 'جُدّدت عضويتك حتى ' || m.valid_until, 'الهوية الجديدة تُطبع الآن وتصلك عبر شركة التوصيل', f.id, true);
  end if;
  return f;
end $f$;

create or replace function public.syn_act(p_file uuid, p_action text, p jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; f syn_files; m syn_members; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_to text; v_from text; c syn_cards; d deliveries; co orgs;
begin
  select * into me from profiles where id = auth.uid();
  select * into f from syn_files where id = p_file for update;
  select * into m from syn_members where id = f.member_id;
  if f.id is null then raise exception 'المعاملة غير موجودة'; end if;
  if not _syn_can(me, f, m) then raise exception 'المعاملة ليست لدى قسمك الآن (%)', _syn_status_label(f.status); end if;
  p := coalesce(p, '{}'); v_from := f.status;

  if p_action = 'forward' then
    if f.status in ('ship', 'done') then raise exception 'المعاملة مع شركة التوصيل — تُغلق عند التسليم'; end if;
    if f.status = 'new' and cardinality(_syn_docs_missing(f.id)) > 0 then raise exception 'مستمسكات ناقصة — أعدها للطبيب للاستكمال'; end if;
    if f.status = 'finance' and f.fee > 0 and f.fee_paid_at is null then raise exception 'الرسوم غير مدفوعة'; end if;
    if f.status = 'print' then
      -- الطباعة ثم التسليم لشركة التوصيل المعتمدة
      select * into co from orgs where id = nullif(p->>'courier', '')::uuid and type = 'courier' and not coalesce((meta->>'suspended')::boolean, false);
      if co.id is null then raise exception 'اختر شركة التوصيل المعتمدة'; end if;
      if f.delivery is null then raise exception 'لا عنوان استلام في المعاملة'; end if;
      c := _syn_issue_card(f);
      insert into deliveries(code, source, source_org, ref_id, ref_code, item, courier_org, recipient_id, recipient_name, recipient_phone, governorate, address, geo, fee, status, otp, due_at, events)
      values (_vet_seq('DLV', 'deliveries', 'code'), 'syndicate', f.org_id, f.id, f.code, 'هوية نقابة الأطباء البيطريين ' || c.card_no || ' (مغلّفة)', co.id, m.citizen_id,
        coalesce(f.delivery->>'recipient', m.full_name), f.delivery->>'phone', m.governorate, f.delivery->>'address', f.delivery->'geo',
        coalesce((select (x->>'v')::bigint from jsonb_array_elements(f.fee_items) x where x->>'t' = 'أجور التوصيل'), 0), 'new',
        lpad((floor(random() * 10000))::int::text, 4, '0'), now() + make_interval(days => coalesce(_setting('courier_sla_days'), 3)::int),
        jsonb_build_array(jsonb_build_object('s', 'new', 'at', now(), 'by', me.full_name, 'note', 'سلّمت النقابة الشحنة للشركة')))
      returning * into d;
      update syn_cards set status = 'shipped' where id = c.id;
      update syn_files set status = 'ship', updated_at = now(), meta = meta || jsonb_build_object('card', c.card_no, 'delivery', d.code, 'courier', co.name) where id = f.id returning * into f;
      perform _syn_log(f.id, m.id, 'طُبعت الهوية ' || c.card_no || ' وسُلّمت لشركة التوصيل', co.name || ' · شحنة ' || d.code || coalesce(' — ' || v_note, ''), v_from, 'ship');
      insert into notifications(org_id, portal, kind, title, body, ref_id) values (co.id, 'courier', 'courier', 'شحنة جديدة ' || d.code, d.item || ' — ' || d.governorate, d.id);
      perform _syn_tell(m.id, 'طُبعت هويتك وهي الآن مع ' || co.name, 'رمز الاستلام يظهر في «بوابة الأطباء البيطريين» — أعطه للمندوب عند الاستلام فقط', f.id, true);
      return jsonb_build_object('ok', true, 'status', f.status, 'card', c.card_no, 'delivery', d.code);
    end if;
    v_to := _syn_next(f.kind, f.status);
    if v_to is null then raise exception 'لا مرحلة بعد هذه'; end if;
    f := _syn_complete(f, p);
    update syn_files set status = v_to, updated_at = now(), closed_at = case when v_to = 'done' then now() end,
      due_at = case when v_to in ('done') then due_at else now() + make_interval(days => coalesce(_setting('syn_sla_days'), 3)::int) end
    where id = f.id returning * into f;
    perform _syn_log(f.id, m.id, 'أنجز ' || _role_title(me.role) || ' — إلى: ' || _syn_status_label(v_to), v_note, v_from, v_to);
    if v_to <> 'done' then
      perform _syn_notify(_syn_owner(v_to), m.governorate, 'معاملة محالة إليك ' || f.code || ': ' || _syn_kind_label(f.kind), m.full_name || ' — ' || _syn_status_label(v_to), f.id);
      if f.kind <> 'activate' and v_from = 'new' then perform _syn_tell(m.id, 'معاملتك ' || f.code || ' انتقلت إلى ' || _syn_status_label(v_to), null, f.id); end if;
    end if;

  elsif p_action = 'back' then   -- إعادة داخلية إلى القسم السابق
    if v_note is null then raise exception 'اكتب سبب الإعادة'; end if;
    v_to := _syn_prev(f.kind, f.status);
    if v_to is null then raise exception 'لا قسم قبل هذا — أعدها للطبيب إن كان النقص منه'; end if;
    update syn_files set status = v_to, updated_at = now(), due_at = now() + make_interval(days => coalesce(_setting('syn_sla_days'), 3)::int) where id = f.id returning * into f;
    perform _syn_log(f.id, m.id, 'إعادة داخلية إلى ' || _syn_status_label(v_to), v_note, v_from, v_to);
    perform _syn_notify(_syn_owner(v_to), m.governorate, 'أُعيدت إليك المعاملة ' || f.code, v_note, f.id);

  elsif p_action = 'return' then  -- إلى الطبيب لاستكمال النواقص
    if v_note is null then raise exception 'اكتب ما ينقص ليعرفه الطبيب'; end if;
    if f.status not in ('new', 'audit') then raise exception 'الإعادة للطبيب من قسم العضوية أو التدقيق فقط'; end if;
    update syn_files set status = 'returned', return_note = v_note, returned_by = _role_title(me.role), updated_at = now() where id = f.id returning * into f;
    perform _syn_log(f.id, m.id, 'أُعيدت للطبيب لاستكمال النواقص', v_note, v_from, 'returned');
    perform _syn_tell(m.id, 'أُعيدت معاملتك ' || f.code || ' للاستكمال', v_note, f.id, true);

  elsif p_action = 'reject' then
    if v_note is null then raise exception 'اكتب سبب الرفض'; end if;
    if f.status not in ('new', 'audit', 'approval') then raise exception 'الرفض من قسم العضوية أو التدقيق أو النقيب'; end if;
    update syn_files set status = 'rejected', reason = v_note, updated_at = now(), closed_at = now() where id = f.id returning * into f;
    if f.kind in ('activate', 'join') and m.status = 'pending' then update syn_members set status = 'rejected', updated_at = now() where id = m.id; end if;
    perform _syn_log(f.id, m.id, 'رُفضت المعاملة', v_note, v_from, 'rejected');
    perform _syn_tell(m.id, 'رُفضت معاملتك ' || f.code, v_note || case when f.fee_paid_at is not null then ' — تُعاد الرسوم وفق تعليمات النقابة' else '' end, f.id, true);
  else
    raise exception 'إجراء غير معروف';
  end if;
  return jsonb_build_object('ok', true, 'status', f.status, 'status_label', _syn_status_label(f.status));
end $f$;

-- التحقق العام من الهوية (رمز QR على الهوية المطبوعة) — بلا بيانات شخصية حساسة
create or replace function public.syn_verify(p_code text) returns jsonb language plpgsql stable security definer set search_path = public, extensions as $f$
declare c syn_cards; m syn_members; latest int;
begin
  select * into c from syn_cards where verify_code = upper(trim(coalesce(p_code, '')));
  if c.id is null then return jsonb_build_object('found', false); end if;
  select * into m from syn_members where id = c.member_id;
  select max(version) into latest from syn_cards where member_id = m.id and status <> 'void';
  return jsonb_build_object('found', true, 'type', 'syn_card', 'org', c.body->>'org', 'name', c.body->>'name', 'membership_no', c.body->>'membership_no',
    'governorate', c.body->>'governorate', 'specialty', c.body->>'specialty', 'card_no', c.card_no, 'version', c.version, 'latest', latest,
    'void', c.status = 'void', 'status', m.status, 'valid_until', m.valid_until, 'valid', m.status = 'active' and m.valid_until >= current_date,
    'intact', encode(digest(c.body::text, 'sha256'), 'hex') = c.sha256, 'issued_on', c.body->>'issued_on');
end $f$;

-- ───────── 7) شركات التوصيل ─────────
create or replace function public.courier_inbox() returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'courier' then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('role', me.role,
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'code', d.code, 'item', d.item, 'status', d.status, 'source', (select name from orgs where id = d.source_org),
        'ref_code', d.ref_code, 'recipient', d.recipient_name, 'phone', d.recipient_phone, 'governorate', d.governorate, 'address', d.address, 'geo', d.geo,
        'agent_id', d.agent_id, 'agent', d.agent_name, 'fee', d.fee, 'attempts', d.attempts, 'fail_note', d.fail_note, 'events', d.events,
        'late', d.due_at < now() and d.status not in ('delivered','returned'), 'due_at', d.due_at, 'created_at', d.created_at, 'delivered_at', d.delivered_at,
        'pickup', (select jsonb_build_object('name', o.name, 'branch', 'قسم الهويات — المقر العام', 'phone', o.meta->>'phone') from orgs o where o.id = d.source_org))
        order by (d.status in ('delivered','returned')), d.created_at desc)
      from deliveries d where d.courier_org = me.org_id and (me.role = 'courier_admin' or d.agent_id = me.id)), '[]'),
    'agents', case when me.role = 'courier_admin' then (select coalesce(jsonb_agg(jsonb_build_object('id', a.id, 'name', a.full_name, 'governorate', a.governorate, 'phone', a.phone,
        'open', (select count(*) from deliveries x where x.agent_id = a.id and x.status in ('assigned','picked','out','failed'))) order by a.full_name), '[]')
      from profiles a where a.org_id = me.org_id and a.role = 'courier_agent' and not coalesce(a.disabled, false)) end);
end $f$;

create or replace function public._syn_on_delivery(d deliveries) returns void language plpgsql security definer set search_path = public as $f$
declare f syn_files; m syn_members;
begin
  if d.source <> 'syndicate' then return; end if;
  select * into f from syn_files where id = d.ref_id for update;
  if f.id is null then return; end if;
  select * into m from syn_members where id = f.member_id;
  if d.status = 'delivered' and f.status = 'ship' then
    update syn_files set status = 'done', closed_at = now(), updated_at = now() where id = f.id;
    update syn_cards set status = 'delivered', delivered_at = now() where file_id = f.id and status = 'shipped';
    perform _syn_log(f.id, m.id, 'سُلّمت الهوية للطبيب — اكتملت دورة المعاملة', d.code || ' · ' || coalesce(d.agent_name, ''), 'ship', 'done');
    perform _syn_tell(m.id, 'استلمت هويتك ✓', 'اكتملت معاملتك ' || f.code || '. هويتك نافذة حتى ' || m.valid_until, f.id);
    perform _syn_notify(array['syn_cards'], m.governorate, 'سُلّمت الهوية — ' || f.code, m.full_name, f.id);
  elsif d.status = 'returned' and f.status = 'ship' then
    update syn_files set status = 'print', updated_at = now(), due_at = now() + interval '2 days' where id = f.id;
    update syn_cards set status = 'printed' where file_id = f.id and status = 'shipped';
    perform _syn_log(f.id, m.id, 'أعادت شركة التوصيل الهوية للنقابة', coalesce(d.fail_note, ''), 'ship', 'print');
    perform _syn_notify(array['syn_cards'], m.governorate, 'أُعيدت شحنة ' || d.code || ' — أعد إرسالها', coalesce(d.fail_note, ''), f.id);
    perform _syn_tell(m.id, 'تعذّر تسليم هويتك', coalesce(d.fail_note, '') || ' — ستُرسل مجدداً. تأكد من رقم هاتفك', f.id, true);
  elsif d.status in ('picked', 'out') then
    perform _syn_tell(m.id, case when d.status = 'picked' then 'استلم المندوب هويتك من النقابة' else 'هويتك في الطريق إليك' end,
      'المندوب: ' || coalesce(d.agent_name, '') || ' — أعطه رمز الاستلام عند وصوله فقط', f.id, d.status = 'out');
  end if;
end $f$;

create or replace function public.courier_act(p_id uuid, p_action text, p jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path = public as $f$
declare me profiles; d deliveries; a profiles; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_to text; g jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into d from deliveries where id = p_id for update;
  if d.id is null or me.portal <> 'courier' or d.courier_org <> me.org_id then raise exception 'الشحنة لا تخص شركتك'; end if;
  if me.role <> 'courier_admin' and d.agent_id is distinct from me.id then raise exception 'الشحنة مسندة لمندوب آخر'; end if;
  p := coalesce(p, '{}'); g := p->'geo';

  if p_action = 'assign' then
    if me.role <> 'courier_admin' then raise exception 'الإسناد لمدير الشركة'; end if;
    if d.status not in ('new', 'assigned', 'failed') then raise exception 'لا يُغيَّر المندوب بعد الاستلام من الجهة'; end if;
    select * into a from profiles where id = nullif(p->>'agent', '')::uuid and org_id = me.org_id and role = 'courier_agent' and not coalesce(disabled, false);
    if a.id is null then raise exception 'اختر المندوب'; end if;
    update deliveries set agent_id = a.id, agent_name = a.full_name, status = case when status = 'new' then 'assigned' else status end, updated_at = now(),
      events = events || jsonb_build_array(jsonb_build_object('s', 'assigned', 'at', now(), 'by', me.full_name, 'note', 'أُسندت إلى ' || a.full_name))
    where id = d.id returning * into d;
    insert into notifications(org_id, user_id, portal, kind, title, body, ref_id) values (me.org_id, a.id, 'courier', 'courier', 'شحنة مسندة إليك ' || d.code, d.item || ' — ' || d.governorate, d.id);
    return jsonb_build_object('ok', true, 'status', d.status);
  elsif p_action = 'pickup' then
    if d.status not in ('assigned', 'new') then raise exception 'الشحنة ليست بانتظار الاستلام من الجهة'; end if;
    if d.agent_id is null then
      update deliveries set agent_id = me.id, agent_name = me.full_name where id = d.id returning * into d;
    end if;
    v_to := 'picked';
  elsif p_action = 'out' then
    if d.status not in ('picked', 'failed') then raise exception 'استلم الشحنة من الجهة أولاً'; end if;
    v_to := 'out';
  elsif p_action = 'deliver' then
    if d.status not in ('out', 'picked', 'failed') then raise exception 'الشحنة ليست في الطريق'; end if;
    if trim(coalesce(p->>'otp', '')) <> d.otp then raise exception 'رمز الاستلام غير صحيح — اطلبه من المستلم (يظهر في هاتفه)'; end if;
    v_to := 'delivered';
    update deliveries set delivered_at = now(), proof = jsonb_strip_nulls(jsonb_build_object('geo', case when g is not null and (g->>'lat') is not null then
        jsonb_build_object('lat', (g->>'lat')::numeric, 'lng', (g->>'lng')::numeric, 'acc', round(coalesce((g->>'acc')::numeric, 0))) end,
        'receiver', nullif(trim(coalesce(p->>'receiver', '')), ''), 'at', now(), 'by', me.full_name, 'otp_ok', true))
    where id = d.id;
  elsif p_action = 'fail' then
    if d.status not in ('out', 'picked') then raise exception 'الشحنة ليست في الطريق'; end if;
    if v_note is null then raise exception 'اكتب سبب تعذّر التسليم'; end if;
    v_to := 'failed';
    update deliveries set attempts = attempts + 1, fail_note = v_note where id = d.id;
  elsif p_action = 'return' then
    if d.status not in ('picked', 'out', 'failed') then raise exception 'لا يُعاد إلا ما استُلم'; end if;
    if v_note is null then raise exception 'اكتب سبب الإعادة للجهة'; end if;
    v_to := 'returned';
    update deliveries set fail_note = v_note where id = d.id;
  else
    raise exception 'إجراء غير معروف';
  end if;
  update deliveries set status = v_to, updated_at = now(),
    events = events || jsonb_build_array(jsonb_strip_nulls(jsonb_build_object('s', v_to, 'at', now(), 'by', me.full_name, 'note', v_note,
      'geo', case when g is not null and (g->>'lat') is not null then jsonb_build_object('lat', (g->>'lat')::numeric, 'lng', (g->>'lng')::numeric) end)))
  where id = d.id returning * into d;
  perform _syn_on_delivery(d);
  return jsonb_build_object('ok', true, 'status', d.status);
end $f$;

-- ───────── 8) حارس التحقق بالوجه على جداول المعاملات الجديدة ─────────
do $d$
declare t text;
begin
  if to_regprocedure('public._face_gate()') is null then return; end if;
  foreach t in array array['syn_members', 'syn_files', 'syn_cards', 'deliveries'] loop
    execute format('drop trigger if exists trg_zz_face_gate on public.%I', t);
    execute format('create trigger trg_zz_face_gate after insert or update or delete on public.%I for each row execute function public._face_gate()', t);
  end loop;
end $d$;

-- ───────── 9) الأدوار والفريق والفروع والجاهزية (استبدال داخل الدوال الحية) ─────────
do $mig$
declare r record; src text; n int;
begin
  for r in select * from (values
    ('public._org_roles(text)',
     $x$when 'syndicate' then array['syndicate_officer']$x$,
     $x$when 'syndicate' then array['syn_reg', 'syn_audit', 'syn_fin', 'syn_cards', 'syn_branch_head', 'syndicate_officer', 'syn_head']
    when 'courier' then array['courier_agent', 'courier_admin']$x$),
    ('public._portal_of_role(text)',
     $x$when r = 'syndicate_officer' then 'syndicate'$x$,
     $x$when r in ('syndicate_officer', 'syn_head', 'syn_branch_head', 'syn_reg', 'syn_audit', 'syn_fin', 'syn_cards') then 'syndicate'
    when r in ('courier_admin', 'courier_agent') then 'courier'$x$),
    ('public._org_type_of_portal(text)',
     $x$when 'chamber' then 'chamber'$x$,
     $x$when 'chamber' then 'chamber' when 'courier' then 'courier'$x$),
    ('public._role_abbr(text)',
     $x$when 'syndicate_officer' then 'SY'$x$,
     $x$when 'syndicate_officer' then 'SY' when 'syn_head' then 'NQ' when 'syn_branch_head' then 'VB' when 'syn_reg' then 'VR' when 'syn_audit' then 'VA'
    when 'syn_fin' then 'VF' when 'syn_cards' then 'VC' when 'courier_admin' then 'DA' when 'courier_agent' then 'DR'$x$),
    ('public._role_title(text)',
     $x$when 'platform_admin' then 'مشغّل النظام$x$,
     $x$when 'syn_head' then 'النقيب — نقابة الأطباء البيطريين' when 'syn_branch_head' then 'رئيس فرع النقابة في المحافظة'
    when 'syn_reg' then 'موظف قسم العضوية والتسجيل — نقابة الأطباء البيطريين' when 'syn_audit' then 'موظف قسم التدقيق والسجلات — نقابة الأطباء البيطريين'
    when 'syn_fin' then 'موظف قسم الحسابات — نقابة الأطباء البيطريين' when 'syn_cards' then 'موظف قسم الهويات والطباعة — نقابة الأطباء البيطريين'
    when 'courier_admin' then 'مدير شركة التوصيل' when 'courier_agent' then 'مندوب التوصيل'
    when 'platform_admin' then 'مشغّل النظام$x$),
    ('public.public_brand(text)',
     $x$'trade','sharia','union','chamber')$x$,
     $x$'trade','sharia','union','chamber')),
      'couriers', (select count(*) from orgs where type = 'courier'$x$),
    ('public._has_branches(text)',
     $x$select p_type in ('bank', 'insurer', 'union', 'chamber')$x$,
     $x$select p_type in ('bank', 'insurer', 'union', 'chamber', 'syndicate')$x$),
    ('public.team_readiness()',
     $x$'insurer', 'union', 'chamber') then return null; end if;$x$,
     $x$'insurer', 'union', 'chamber', 'syndicate', 'courier') then return null; end if;$x$),
    ('public.team_save_branch(jsonb)',
     $x$وغرف المحافظات لرئيس اتحاد الغرف التجارية$x$,
     $x$وغرف المحافظات لرئيس اتحاد الغرف التجارية، وفروع النقابة للنقيب$x$),
    ('public._branch_roles_of(text)',
     $x$when 'chamber' then array['chamber_reg', 'chamber_eng', 'chamber_fin']$x$,
     $x$when 'chamber' then array['chamber_reg', 'chamber_eng', 'chamber_fin'] when 'syndicate' then array['syn_reg', 'syn_fin']$x$),
    ('public._is_branch_mgr_role(text)',
     $x$('bank_branch_mgr', 'ins_branch_mgr', 'chamber_head')$x$,
     $x$('bank_branch_mgr', 'ins_branch_mgr', 'chamber_head', 'syn_branch_head')$x$),
    ('public.team_meta()',
     $x$when m.manage_scope = 'org' and o.type in ('insurer', 'chamber') then '["branch"]'::jsonb$x$,
     $x$when m.manage_scope = 'org' and o.type in ('insurer', 'chamber', 'syndicate') then '["branch"]'::jsonb$x$),
    ('public.team_meta()',
     $x$when 'chamber' then 'chamber_head' end$x$,
     $x$when 'chamber' then 'chamber_head' when 'syndicate' then 'syn_branch_head' end$x$),
    ('public.team_create_user(jsonb)',
     $x$if o.type = 'chamber' and v_role = 'chamber_head' and v_br is null then raise exception 'رئيس الغرفة مربوط بغرفة محافظة — اختر الغرفة'; end if;$x$,
     $x$if o.type = 'chamber' and v_role = 'chamber_head' and v_br is null then raise exception 'رئيس الغرفة مربوط بغرفة محافظة — اختر الغرفة'; end if;
  if o.type = 'syndicate' and v_role = 'syn_branch_head' and v_br is null then raise exception 'رئيس الفرع مربوط بفرع محافظة — اختر الفرع'; end if;
  if o.type = 'syndicate' and v_role in ('syn_audit', 'syn_cards', 'syn_head') and v_br is not null then raise exception 'هذا القسم في المقر العام للنقابة — اترك الفرع فارغاً'; end if;$x$),
    ('public._onboard_kind(text)',
     $x$    when 'chamber'        then '{"type":"chamber","portal":"chamber","role":"chamber_pres","title":"اتحاد الغرف التجارية"}'::jsonb$x$,
     $x$    when 'chamber'        then '{"type":"chamber","portal":"chamber","role":"chamber_pres","title":"اتحاد الغرف التجارية"}'::jsonb
    when 'courier'        then '{"type":"courier","portal":"courier","role":"courier_admin","title":"شركة توصيل معتمدة"}'::jsonb$x$),
    ('public.admin_onboard_org(jsonb)',
     $x$if k->>'type' in ('eng_audit', 'insurer') then$x$,
     $x$if k->>'type' in ('eng_audit', 'insurer', 'courier') then$x$),
    ('public._onboard_manager(orgs,jsonb)',   -- إصلاح: كان يرفض إضافة الاتحادات من «الجهات والشركات»
     $x$when 'insurer' then 'ins_md' end;$x$,
     $x$when 'insurer' then 'ins_md' when 'union' then 'union_sg' when 'chamber' then 'chamber_pres' when 'courier' then 'courier_admin' end;$x$),
    ('public.admin_org_update(uuid,jsonb)',   -- الجهات التي يعدّلها المشغّل: والاتحادات وشركات التوصيل
     $x$o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then$x$,
     $x$o.type not in ('bank', 'supplier', 'eng_audit', 'insurer', 'union', 'chamber', 'courier') then$x$),
    ('public.admin_org_update(uuid,jsonb)',
     $x$and type in ('eng_audit', 'insurer') then$x$,
     $x$and type in ('eng_audit', 'insurer', 'courier') then$x$),
    ('public.admin_org_suspend(uuid,boolean,text)',
     $x$o.type not in ('bank', 'supplier', 'eng_audit', 'insurer') then$x$,
     $x$o.type not in ('bank', 'supplier', 'eng_audit', 'insurer', 'union', 'chamber', 'courier') then$x$),
    ('public.admin_orgs_readiness()',
     $x$where type in ('bank', 'supplier', 'eng_audit', 'insurer'))$x$,
     $x$where type in ('bank', 'supplier', 'eng_audit', 'insurer', 'union', 'chamber', 'courier'))$x$),
    ('public.syndicate_action(uuid,text,text)',
     $x$me.role <> 'syndicate_officer'$x$,
     $x$me.role not in ('syndicate_officer', 'syn_head', 'syn_reg')$x$),
    ('public._org_readiness(uuid)',
     $x$  elsif o.type = 'chamber' then$x$,
     $x$  elsif o.type = 'syndicate' then   -- الجلسة 60: نقابة الأطباء البيطريين — أقسام المقر، وكل فرع محافظة فيه فريق
    foreach r in array array['syn_head','syn_reg','syn_audit','syn_fin','syn_cards'] loop
      if _org_has(o.id, r) then done := done || jsonb_build_array(_role_title(r));
      else miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r)); end if;
    end loop;
    for b in select id, name from branches br where br.bank_id = o.id and exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false)) order by code loop
      foreach r in array array['syn_branch_head','syn_reg'] loop
        if not _org_has(o.id, r, b.id, false) then miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title(r), 'role', r, 'branch', b.id, 'branch_name', b.name)); end if;
      end loop;
    end loop;
    if exists (select 1 from branches br where br.bank_id = o.id and not exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false))) then
      warn := warn || jsonb_build_array('فروع بلا فريق بعد (يخدم المقر العام معاملاتها): ' || (select string_agg(br.name, '، ' order by br.code) from branches br where br.bank_id = o.id
        and not exists (select 1 from profiles p where p.branch_id = br.id and not coalesce(p.disabled, false)))); end if;
    if not exists (select 1 from orgs where type = 'courier' and not coalesce((meta->>'suspended')::boolean, false)) then
      warn := warn || '["لا توجد شركة توصيل معتمدة — يضيفها مشغّل النظام من «الجهات والشركات»"]'::jsonb; end if;
    v_routable := jsonb_array_length(miss) = 0;

  elsif o.type = 'courier' then   -- الجلسة 60: شركة التوصيل — مندوب واحد على الأقل
    if _org_has(o.id, 'courier_agent') then done := done || jsonb_build_array(_role_title('courier_agent'));
    else miss := miss || jsonb_build_array(jsonb_build_object('t', _role_title('courier_agent'), 'role', 'courier_agent')); end if;
    v_routable := jsonb_array_length(miss) = 0;

  elsif o.type = 'chamber' then$x$)
  ) v(fn, old, new) loop
    if to_regprocedure(r.fn) is null then raise exception 'الجلسة 60: الدالة % غير موجودة', r.fn; end if;
    src := pg_get_functiondef(r.fn::regprocedure);
    if position(r.new in src) > 0 then continue; end if;   -- طُبّق سابقاً
    n := (length(src) - length(replace(src, r.old, ''))) / length(r.old);
    if n <> 1 then raise exception 'الجلسة 60: النص المطلوب استبداله في % وُجد % مرة (المتوقع مرة واحدة)', r.fn, n; end if;
    execute replace(src, r.old, r.new);
  end loop;
end $mig$;

-- محافظة موظف النقابة تتبع فرعه
create or replace function public._syn_staff_gov() returns trigger language plpgsql security definer set search_path = public as $f$
declare g text[];
begin
  if new.portal <> 'syndicate' then return new; end if;
  if new.branch_id is not null then
    select governorates into g from branches where id = new.branch_id;
    if cardinality(g) > 0 and not (coalesce(new.governorate, '') = any(g)) then new.governorate := g[1]; end if;
  elsif new.governorate is null then new.governorate := 'بغداد';
  end if;
  return new;
end $f$;
drop trigger if exists trg_syn_staff_gov on public.profiles;
create trigger trg_syn_staff_gov before insert or update of branch_id, portal on public.profiles for each row execute function public._syn_staff_gov();

-- الصلاحيات على الدوال
do $g$
declare r record;
begin
  for r in select p.oid::regprocedure::text sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' and p.proname ~ '^(syn_|_syn_|courier_)' loop
    if r.proname = 'syn_verify' then
      execute 'revoke all on function ' || r.sig || ' from public';
      execute 'grant execute on function ' || r.sig || ' to anon, authenticated';
    elsif r.proname ~ '^_' then
      execute 'revoke all on function ' || r.sig || ' from public, anon, authenticated';
    else
      execute 'revoke all on function ' || r.sig || ' from public, anon';
      execute 'grant execute on function ' || r.sig || ' to authenticated';
    end if;
  end loop;
end $g$;

-- ───────── 10) بيانات العرض: فروع النقابة، الفريق، شركة توصيل، أطباء ─────────
do $$
declare o uuid := _syn_org(); g text; pre text; k int := 0;
begin
  if o is null then return; end if;
  pre := 'VSI';
  foreach g in array array['بغداد','البصرة','نينوى','أربيل','النجف','كربلاء','بابل','ذي قار','الأنبار','ديالى','واسط','ميسان','الديوانية','صلاح الدين','كركوك','المثنى','السليمانية','دهوك'] loop
    k := k + 1;
    if not exists (select 1 from public.branches where bank_id = o and name = 'فرع نقابة ' || g) then
      insert into public.branches(bank_id, code, name, governorates, is_main, complaint_phone)
      values (o, pre || '-' || lpad(k::text, 2, '0'), 'فرع نقابة ' || g, array[g], false, null);
    end if;
  end loop;
end $$;

insert into public.orgs(code, type, name, meta)
select 'srq', 'courier', 'سريع للتوصيل', '{"demo": true, "phone": "07700000777", "governorates": [], "license": "MOT-DLV-2026-014"}'::jsonb
where not exists (select 1 from public.orgs where code = 'srq');

do $$
declare o uuid := _syn_org(); r text[]; uid uuid; head uuid; br uuid; i int;
  rows text[][] := array[
  ['syn.head',  'Vsi@2026hd', 'د. عبد الأمير كاظم الحسيني', 'syn_head',        '',       'org'],
  ['syn.audit', 'Vsi@2026au', 'د. سرى عادل النعيمي',         'syn_audit',       '',       ''],
  ['syn.fin',   'Vsi@2026fn', 'أحمد صباح الجبوري',           'syn_fin',         '',       ''],
  ['syn.cards', 'Vsi@2026cd', 'مريم خليل الدليمي',           'syn_cards',       '',       ''],
  ['syn.reg',   'Vsi@2026rg', 'علي حسن الربيعي',             'syn_reg',         '',       ''],
  ['vbgd.head', 'Vsi@2026bh', 'د. حيدر جاسم العامري',        'syn_branch_head', 'بغداد',  'branch'],
  ['vbgd.reg',  'Vsi@2026br', 'زينب فلاح الساعدي',           'syn_reg',         'بغداد',  ''],
  ['vbsr.head', 'Vsi@2026sh', 'د. ناصر عبد الله المالكي',     'syn_branch_head', 'البصرة', 'branch'],
  ['vbsr.reg',  'Vsi@2026sr', 'هدى سالم البطاط',             'syn_reg',         'البصرة', ''],
  ['vnjf.head', 'Vsi@2026nh', 'د. كاظم جواد الياسري',         'syn_branch_head', 'النجف',  'branch'],
  ['vnjf.reg',  'Vsi@2026nr', 'حسين مهدي الكرعاوي',          'syn_reg',         'النجف',  '']];
begin
  if o is null then return; end if;
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'syndicate', (select code from orgs where id = o), null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    select id into head from public.profiles where username = 'syn.head';
    br := case when rows[i][5] = '' then null else (select id from public.branches where bank_id = o and name = 'فرع نقابة ' || rows[i][5]) end;
    update public.profiles set branch_id = br, governorate = coalesce(nullif(rows[i][5], ''), 'بغداد'), manage_scope = nullif(rows[i][6], ''), must_change_password = false,
      managed_by = case when rows[i][1] <> 'syn.head' then coalesce(managed_by, case when rows[i][4] = 'syn_branch_head' then head
        else coalesce((select id from public.profiles where branch_id = br and role = 'syn_branch_head' and br is not null limit 1), head) end) end
    where id = uid;
  end loop;
end $$;

do $$
declare i int; uid uuid;
  rows text[][] := array[
  ['srq.admin', 'Srq@2026ad', 'كرار عبد الزهرة الموسوي', 'courier_admin', 'بغداد',  'org',  '07700000777'],
  ['srq.bgd',   'Srq@2026bg', 'مصطفى علاء الشمري',       'courier_agent', 'بغداد',  '',     '07700000778'],
  ['srq.bsr',   'Srq@2026bs', 'عباس فاضل الحلفي',        'courier_agent', 'البصرة', '',     '07700000779']];
begin
  if not exists (select 1 from orgs where code = 'srq') then return; end if;
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'courier', 'srq', rows[i][7], null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    update public.profiles set governorate = rows[i][5], manage_scope = nullif(rows[i][6], ''), must_change_password = false,
      managed_by = case when rows[i][1] <> 'srq.admin' then (select id from profiles where username = 'srq.admin') end where id = uid;
  end loop;
end $$;

-- أطباء العرض: vet4 منتسب سابق لم يفعّل، vet5 خريج غير منتسب، vet6 هويته تنتهي بعد 6 أيام، vet7 تجديد عند الطباعة، vet8 تفعيل وارد لفرع بغداد
do $$
declare o uuid := _syn_org(); u uuid; m syn_members; f syn_files; i int; img text := 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAABQCAIAAABd+SbeAAAA4UlEQVR42u3dsQ2CYBCA0YMwFAvYsgUbUFtQswFb0LKAc1hRMgIDGEj4A4nA+1q753mGKzT7TnPo/HIEoEELNGjQAn2nirUX2q6nk9C7qU30X0709vujvTvARPsyBC3QoEEjAA1ahz+w/DaMnyd7Va/SRFsdSlgdyZ8dEy3QoAUaNGiBBi23jnDrsDrk1mGiBRo0aIEGLdCgPbCEW4dbh9Uhtw4TDVqgQQs0aNAC7dYRbh0m2uqwOtw6TDRogQYNWqBBCzRo0AIdt751+M1dE32xMv/DYqJBCzRo0AINWrtbANPqHP7NP70rAAAAAElFTkSuQmCC';
  face text := 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABkCAIAAACemCBBAAABWElEQVR42u3csQ0CMQyFYe6JGempmImKnlWoGYBNmAAUcrb1TP60SLE/Xg7dXSK2x/N1WGnosNgADBgwYMCAAQMGDBjw3DhWFrve7p8+upxPNT1sNY+HX6jF7HTwILWMnQieoBaw5akNmaEOHNVrhlm22iSznLUZc8pcGz4zt5Z+8cbOT8KW8QZWIWHAJus5qhYJAwYMGDBgwK3BZa+UQ2qRMGCfVR1ShYRdQ46an4QtQw6cWbadJc0p8/7Cv0E5r8CM9SLbqy7pF4ETAP9+xkM+Tzk196csaad9oAx5PDh8I8L6xsP/yENYwgU7TEbPw2vtD6+1e1ipDamoXtr9ddVOu7O6Omr39KCm2ulO1Fc71w9vLVvFO9EVCXeL99feSLhhvD91SMI94x3vk4QBd1nPg92SMOC1wL0u4JGeSRgwYMCAncfG3zwCBgwYMGDAgAEDBgx4ZLwBKe6lA86fXf8AAAAASUVORK5CYII=';
  rows text[][] := array[
  ['vet4', 'Alwah@2004', 'د. علي فاضل الجبوري',      '07701234521', '199105120041', 'بغداد'],
  ['vet5', 'Alwah@2005', 'د. سارة محمود الخفاجي',     '07701234522', '199507030042', 'النجف'],
  ['vet6', 'Alwah@2006', 'د. حسن عبد الرضا الكناني',  '07701234523', '198812250043', 'بغداد'],
  ['vet7', 'Alwah@2007', 'د. نور الهدى ياسين العبادي', '07701234524', '199003140044', 'البصرة'],
  ['vet8', 'Alwah@2008', 'د. محمد قاسم الزيدي',       '07701234525', '199611110045', 'بغداد']];
begin
  if o is null then return; end if;
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from profiles where username = rows[i][1]) then
      u := _mk_user(rows[i][1], rows[i][2], rows[i][3], 'citizen', 'citizen', null, rows[i][4], rows[i][5]);
      update profiles set kyc_status = 'verified', kyc_at = now(), governorate = rows[i][6], city = rows[i][6], employer = 'طبيب بيطري',
        monthly_salary = 1500000, birth_date = ('19' || substr(rows[i][5], 3, 2) || '-' || substr(rows[i][5], 5, 2) || '-' || substr(rows[i][5], 7, 2))::date, must_change_password = false where id = u;
    end if;
  end loop;

  -- vet6: عضو نافذ تنتهي هويته بعد 6 أيام (وصله تذكير الأسبوع)
  select id into u from profiles where username = 'vet6';
  if not exists (select 1 from syn_members where citizen_id = u) then
    insert into syn_members(org_id, citizen_id, full_name, national_id, phone, membership_no, governorate, college, graduation_year, degree, specialty, status, source,
      issued_on, valid_until, joined_at, activated_at, card_version)
    values (o, u, 'د. حسن عبد الرضا الكناني', '198812250043', '07701234523', '5521', 'بغداد', 'كلية الطب البيطري — جامعة بغداد', 2011, 'bachelor', 'الأمراض الباطنية',
      'active', 'activation', current_date - 359, current_date + 6, '2011-10-01', now() - interval '30 days', 1)
    returning * into m;
    insert into syn_files(code, org_id, kind, member_id, status, data, submitted_at, closed_at, created_at)
    values (_vet_seq('SF', 'syn_files', 'code'), o, 'activate', m.id, 'done', jsonb_build_object('membership_no', '5521', 'issued_on', current_date - 359, 'valid_until', current_date + 6,
      'governorate', 'بغداد', 'college', m.college, 'graduation_year', 2011), now() - interval '31 days', now() - interval '30 days', now() - interval '31 days')
    returning * into f;
    insert into syn_log(file_id, member_id, actor_name, actor_title, action, note, from_status, to_status, created_at)
    values (f.id, m.id, 'زينب فلاح الساعدي', _role_title('syn_reg'), 'تفعيل حساب عضو منتسب (بيانات العرض)', null, 'audit', 'done', now() - interval '30 days');
    perform _syn_sync_vet(m.id);
  end if;

  -- vet7: طلب تجديد مدفوع ومعتمد — عند قسم الهويات للطباعة والتسليم لشركة التوصيل
  select id into u from profiles where username = 'vet7';
  if not exists (select 1 from syn_members where citizen_id = u) then
    insert into syn_members(org_id, citizen_id, full_name, national_id, phone, membership_no, governorate, college, graduation_year, degree, specialty, status, source,
      issued_on, valid_until, joined_at, activated_at, renewed_at, card_version)
    values (o, u, 'د. نور الهدى ياسين العبادي', '199003140044', '07701234524', '6874', 'البصرة', 'كلية الطب البيطري — جامعة البصرة', 2013, 'master', 'الجراحة البيطرية',
      'active', 'activation', current_date - 360, current_date + 365 + 5, '2013-11-01', now() - interval '60 days', now() - interval '1 day', 1)
    returning * into m;
    insert into syn_files(code, org_id, kind, member_id, status, data, delivery, fee, fee_items, fee_paid_at, fee_ref, submitted_at, due_at, created_at)
    values (_vet_seq('SF', 'syn_files', 'code'), o, 'renewal', m.id, 'print', jsonb_build_object('valid_until', current_date + 370),
      jsonb_build_object('address', 'البصرة — العشار، شارع الكورنيش قرب فندق شيراتون، عمارة 12', 'phone', '07701234524', 'recipient', 'د. نور الهدى ياسين العبادي',
        'geo', jsonb_build_object('lat', 30.5155, 'lng', 47.8433, 'acc', 12, 'at', now() - interval '3 days'), 'governorate', 'البصرة'),
      40000, _syn_fee('renewal'), now() - interval '3 days', 'VRN-DEMO-7A21C4 · zaincash', now() - interval '3 days', now() + interval '1 day', now() - interval '3 days')
    returning * into f;
    insert into syn_docs(file_id, member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name)
    values (f.id, m.id, 'photo', _syn_doc_label('photo'), 'image/png', face, length(face), encode(extensions.digest(face, 'sha256'), 'hex'), '{"demo": true}', u, m.full_name);
    update syn_members set photo_doc = (select id from syn_docs where file_id = f.id and kind = 'photo') where id = m.id;
    update syn_files set meta = jsonb_build_object('photo_doc', (select id from syn_docs where file_id = f.id and kind = 'photo'), 'confirm', true) where id = f.id;
    insert into syn_log(file_id, member_id, actor_name, actor_title, action, note, from_status, to_status, created_at) values
      (f.id, m.id, m.full_name, 'الطبيب', 'تقديم: تجديد هوية النقابة', 'دفع إلكتروني 40,000 د.ع', 'draft', 'new', now() - interval '3 days'),
      (f.id, m.id, 'هدى سالم البطاط', _role_title('syn_reg'), 'أنجز ' || _role_title('syn_reg') || ' — إلى: لدى قسم الحسابات', 'الصورة مطابقة', 'new', 'finance', now() - interval '2 days'),
      (f.id, m.id, 'أحمد صباح الجبوري', _role_title('syn_fin'), 'أنجز ' || _role_title('syn_fin') || ' — إلى: بانتظار اعتماد النقيب', 'الرسوم مستوفاة', 'finance', 'approval', now() - interval '2 days'),
      (f.id, m.id, 'د. ناصر عبد الله المالكي', _role_title('syn_branch_head'), 'أنجز ' || _role_title('syn_branch_head') || ' — إلى: لدى قسم الهويات — الطباعة', null, 'approval', 'print', now() - interval '1 day');
    perform _syn_sync_vet(m.id);
  end if;

  -- vet8: طلب تفعيل وارد في فرع بغداد (قسم العضوية)
  select id into u from profiles where username = 'vet8';
  if not exists (select 1 from syn_members where citizen_id = u) then
    insert into syn_members(org_id, citizen_id, full_name, national_id, phone, governorate, college, graduation_year, degree, specialty, status, source)
    values (o, u, 'د. محمد قاسم الزيدي', '199611110045', '07701234525', 'بغداد', 'كلية الطب البيطري — جامعة بغداد', 2019, 'bachelor', 'الدواجن', 'pending', 'activation')
    returning * into m;
    insert into syn_files(code, org_id, kind, member_id, status, data, submitted_at, due_at, created_at)
    values (_vet_seq('SF', 'syn_files', 'code'), o, 'activate', m.id, 'new', jsonb_build_object('membership_no', '7412', 'issued_on', current_date - 200, 'valid_until', current_date + 165,
      'governorate', 'بغداد', 'college', m.college, 'graduation_year', 2019, 'degree', 'bachelor', 'specialty', 'الدواجن'), now() - interval '5 hours', now() + interval '3 days', now() - interval '5 hours')
    returning * into f;
    insert into syn_docs(file_id, member_id, kind, label, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_name)
    select f.id, m.id, k, _syn_doc_label(k), 'image/png', img, length(img), encode(extensions.digest(img, 'sha256'), 'hex'), '{"demo": true}', u, m.full_name
    from unnest(array['id_front','id_back','syn_front','syn_back']) k;
    insert into syn_log(file_id, member_id, actor_name, actor_title, action, from_status, to_status, created_at)
    values (f.id, m.id, m.full_name, 'الطبيب', 'تقديم: تفعيل حساب عضو منتسب', 'draft', 'new', now() - interval '5 hours');
  end if;
end $$;

reset check_function_bodies;
