// الجلسة 57: خريطة المشاريع — وزارة التخطيط، وزارة التجارة، اتحاد الغرف التجارية وكل غرفة محافظة
// عنوان كل مشروع على الخريطة مع فلاتر حسب التخصص والمحافظة والحالة. للغرف أيضاً: محلات التجار المنتسبين حسب النشاط.
// البيانات من projects_map() — بلا أسماء أشخاص ولا أرقام هويات.
import { esc, num, mln, rpc, cleanErr, kpi, SECTORS, VET_TYPES, COM_CATS, GOVS, mapsLink } from './core.js';

let leafletReady;
export function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (leafletReady) return leafletReady;
  leafletReady = new Promise((res, rej) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = e => { leafletReady = null; rej(e); }; document.head.appendChild(s);
  });
  return leafletReady;
}

export const SRC_TXT = { audit: '📍 زيارة المدقق الهندسي (GPS)', install: '📍 موقع نصب المنظومة (فني المورد)', site: '📍 عنوان المشروع (GPS)', approx: 'موقع تقريبي — مركز المدينة' };
const CAT_COL = { food: '#16a34a', construction: '#a16207', electrical: '#2563eb', vehicles: '#475569', textile: '#db2777', medical: '#dc2626', agri: '#65a30d', fuel: '#0f172a', general: '#7c3aed', services: '#0891b2', other: '#6b7280' };
const MEM_ST = { approved: 'عضوية نافذة', expired: 'منتهية', suspended: 'معلّقة', pending: 'طلب انتساب' };
const INTRO = {
  planning: 'عنوان كل مشروع ممول على الخريطة، مع فلاتر حسب التخصص والمحافظة والحالة — لتوزيع المشاريع جغرافياً ومطابقته مع خارطة الطريق.',
  trade: 'عنوان كل مشروع ممول على الخريطة، مع فلاتر حسب التخصص — المشاريع التجارية وبرامج المصارف والمنظومات الشمسية للمشاريع.',
  chamber: 'عنوان كل مشروع ممول في نطاقكم، ومحلات التجار المنتسبين، مع فلاتر حسب التخصص والنشاط.',
};
const fullName = s => SECTORS[s]?.[0] || s;
const colOf = s => SECTORS[s]?.[1] || '#6b7280';
const subTxt = p => p.vet_type ? (VET_TYPES[p.vet_type] || 'مشروع بيطري') : p.activity || '';
const addr = p => [p.gov, p.city, p.address].filter(Boolean).map(esc).join(' · ');

export async function mountProjectsMap(ctx, body) {
  body.innerHTML = '<div class="card"><div class="spin"></div></div>';
  let d;
  try { d = await rpc(ctx.sb, 'projects_map', {}); }
  catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  const F = ctx.pmF ||= { layer: 'projects', sectors: [], cats: [], gov: '', status: 'all', q: '' };
  const P = d.projects || [], M = d.members || [], isCh = d.portal === 'chamber';
  const singleGov = (d.govs || []).length === 1;
  const govList = [...new Set([...P.map(p => p.gov), ...M.map(m => m.gov)].filter(Boolean))].sort((a, b) => GOVS.findIndex(g => g[0] === a) - GOVS.findIndex(g => g[0] === b));

  const paint = async () => {
    const mem = isCh && F.layer === 'members';
    const base = mem ? M : P;
    const q = F.q.trim();
    const shown = base.filter(x => {
      if (F.gov && x.gov !== F.gov) return false;
      if (q && ![x.code, x.name, x.activity, x.city, x.address].some(v => String(v || '').includes(q))) return false;
      if (mem) return !F.cats.length || F.cats.includes(x.cat);
      if (F.sectors.length && !F.sectors.includes(x.sector)) return false;
      if (F.status === 'done' && x.status !== 'completed') return false;
      if (F.status === 'live' && x.status === 'completed') return false;
      return true;
    });
    const inGov = base.filter(x => !F.gov || x.gov === F.gov);
    const secKeys = Object.keys(SECTORS).filter(k => P.some(p => p.sector === k));
    const chips = mem
      ? Object.entries(COM_CATS).filter(([k]) => M.some(m => m.cat === k)).map(([k, t]) => `<label class="chip ${F.cats.includes(k) ? 'on' : ''}"><input type="checkbox" value="${k}" data-cat ${F.cats.includes(k) ? 'checked' : ''}><i class="sw" style="background:${CAT_COL[k]}"></i>${esc(t)} <span class="num muted">${inGov.filter(m => m.cat === k).length}</span></label>`).join('')
      : secKeys.map(k => `<label class="chip ${F.sectors.includes(k) ? 'on' : ''}"><input type="checkbox" value="${k}" data-sec ${F.sectors.includes(k) ? 'checked' : ''}><i class="sw" style="background:${colOf(k)}"></i>${esc(fullName(k))} <span class="num muted">${inGov.filter(p => p.sector === k).length}</span></label>`).join('');
    const done = shown.filter(p => p.status === 'completed');
    const noGps = shown.filter(p => !p.lat || p.src === 'approx').length;

    body.innerHTML = `
      <div class="notice"><span>🗺️</span><span>${esc(INTRO[d.portal] || INTRO.planning)}${d.scope_label ? ` <b>نطاقك: ${esc(d.scope_label)}</b>.` : ''} لا تظهر أسماء الأشخاص ولا أرقام هوياتهم — اسم النشاط وعنوان المشروع فقط.</span></div>
      <div class="grid g4 mb">
        ${mem ? `${kpi('محلات منتسبة', `<span class="num">${shown.length}</span>`, 'حسب الفلتر', true)}${kpi('عضوية نافذة', `<span class="num">${shown.filter(m => m.status === 'approved').length}</span>`)}${kpi('طلبات انتساب', `<span class="num">${shown.filter(m => m.status === 'pending').length}</span>`)}${kpi('بلا موقع على الخريطة', `<span class="num">${shown.filter(m => !m.lat).length}</span>`, 'لم يثبّت مفتش الغرفة موقعها بعد')}`
        : `${kpi('المشاريع', `<span class="num">${shown.length}</span>`, `من ${num(P.length)} في نطاقك`, true)}${kpi('مكتملة ومركّبة', `<span class="num">${done.length}</span>`, `${num(shown.length - done.length)} قيد التنفيذ`)}${kpi('مبلغ التمويل', mln(shown.reduce((s, p) => s + Number(p.amount || 0), 0)), 'دينار')}${kpi('موقعها بالـGPS', `<span class="num">${shown.length - noGps}</span>`, noGps ? `${noGps} بموقع تقريبي` : 'كلها موثقة')}`}
      </div>
      <div class="map-filters card">
        ${isCh ? `<div class="seg sm">${[['projects', '📍 المشاريع الممولة'], ['members', '🏪 محلات التجار المنتسبين']].map(([k, t]) => `<label class="${F.layer === k ? 'on' : ''}"><input type="radio" name="pl" value="${k}" ${F.layer === k ? 'checked' : ''}>${t}</label>`).join('')}</div>` : ''}
        ${!singleGov && govList.length > 1 ? `<select class="input sm" data-gov><option value="">كل المحافظات</option>${govList.map(g => `<option ${F.gov === g ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select>` : ''}
        ${mem ? '' : `<div class="seg sm">${[['all', 'كل الحالات'], ['done', 'مكتملة'], ['live', 'قيد التنفيذ']].map(([k, t]) => `<label class="${F.status === k ? 'on' : ''}"><input type="radio" name="pst" value="${k}" ${F.status === k ? 'checked' : ''}>${t}</label>`).join('')}</div>`}
        <input class="input sm" data-q placeholder="ابحث برقم أو اسم أو نشاط أو منطقة" value="${esc(F.q)}" style="min-width:200px">
        <div class="chips" style="flex-basis:100%">${chips || '<span class="muted small">لا بيانات بعد</span>'}</div>
      </div>
      <div class="card"><h3>${mem ? 'محلات التجار المنتسبين' : 'خريطة المشاريع'} <span class="sp"></span><span class="small muted"><span class="num">${shown.filter(x => x.lat).length}</span> على الخريطة</span></h3>
        <div data-map style="height:440px;border-radius:12px;z-index:1"></div>
        <p class="small muted" style="margin:8px 0 0">${mem ? 'اللون حسب النشاط التجاري. الموقع كما ثبّته مفتش الغرفة.' : '● ممتلئة = مكتملة · ○ حلقة = قيد التنفيذ. اللون حسب التخصص. الموقع الأدق: زيارة المدقق الهندسي، ثم موقع نصب المنظومة، ثم عنوان المشروع بالـGPS، ثم تقريبي.'}</p></div>
      <div class="card flush mt"><h3>القائمة <span class="sp"></span><button class="btn sm ghost" data-csv>⬇ تصدير CSV</button></h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الرقم</th><th>${mem ? 'المحل' : 'التخصص'}</th><th>${mem ? 'النشاط' : 'النشاط أو المشروع'}</th><th>العنوان</th><th>الحالة</th><th></th></tr></thead><tbody>
        ${shown.map(x => `<tr><td class="num" style="white-space:nowrap">${esc(x.code || '')}</td>
          <td>${mem ? esc(x.name) : `<i class="sw" style="background:${colOf(x.sector)}"></i> ${esc(fullName(x.sector))}`}</td>
          <td class="small">${mem ? esc(COM_CATS[x.cat] || x.cat) : `${x.name ? `<b>${esc(x.name)}</b> ` : ''}${esc(subTxt(x))}${x.kw ? ` <span class="muted">${subTxt(x) || x.name ? '· ' : ''}<span class="num">${num(x.kw)}</span> kW</span>` : ''}`}</td>
          <td class="small">${addr(x)}</td>
          <td class="small">${mem ? esc(MEM_ST[x.status] || x.status) : x.status === 'completed' ? 'مكتمل' : `المرحلة <span class="num">${x.stage}</span>`}</td>
          <td>${x.lat ? `<button class="btn sm ghost" data-go="${x.id}">📍</button>` : '<span class="muted small">بلا موقع</span>'}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا نتائج لهذا الفلتر</td></tr>'}
      </tbody></table></div></div>`;

    body.querySelectorAll('input[name=pl]').forEach(r => r.onchange = () => { F.layer = r.value; paint(); });
    body.querySelectorAll('input[name=pst]').forEach(r => r.onchange = () => { F.status = r.value; paint(); });
    body.querySelectorAll('[data-sec]').forEach(c => c.onchange = () => { F.sectors = [...body.querySelectorAll('[data-sec]:checked')].map(x => x.value); paint(); });
    body.querySelectorAll('[data-cat]').forEach(c => c.onchange = () => { F.cats = [...body.querySelectorAll('[data-cat]:checked')].map(x => x.value); paint(); });
    const gs = body.querySelector('[data-gov]'); if (gs) gs.onchange = () => { F.gov = gs.value; paint(); };
    const qi = body.querySelector('[data-q]'); let tm;
    qi.oninput = () => { clearTimeout(tm); tm = setTimeout(() => { F.q = qi.value; paint().then(() => { const n = body.querySelector('[data-q]'); n.focus(); n.setSelectionRange(n.value.length, n.value.length); }); }, 400); };
    body.querySelector('[data-csv]').onclick = () => csv(shown, mem);

    const box = body.querySelector('[data-map]');
    try {
      const L = await loadLeaflet();
      const m = L.map(box, { zoomControl: true }).setView([33.2, 43.7], 6);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(m);
      const pts = [], mk = {};
      shown.forEach(x => {
        if (!x.lat) return;
        const ll = [Number(x.lat), Number(x.lng)]; pts.push(ll);
        const col = mem ? (CAT_COL[x.cat] || '#6b7280') : colOf(x.sector), fin = mem ? x.status === 'approved' : x.status === 'completed';
        mk[x.id] = L.circleMarker(ll, { radius: mem ? 7 : Math.min(13, 6 + Number(x.kw || 0) / 3), color: fin ? '#fff' : col, weight: fin ? 2 : 3, fillColor: col, fillOpacity: fin ? 0.9 : 0.2, ...(x.src === 'approx' ? { dashArray: '3 3' } : {}) })
          .bindPopup(`<div dir="rtl" style="font-family:Cairo;min-width:190px"><b class="num">${esc(x.code || '')}</b> — ${mem ? esc(COM_CATS[x.cat] || '') : esc(fullName(x.sector))}
            ${x.name ? `<br><b>${esc(x.name)}</b>` : ''}${!mem && subTxt(x) ? `<br>${esc(subTxt(x))}` : ''}
            <br>${addr(x)}
            <br>${mem ? esc(MEM_ST[x.status] || '') : `${x.status === 'completed' ? 'مكتمل' : 'قيد التنفيذ — المرحلة ' + x.stage}${x.kw ? ` · ${num(x.kw)} kW` : ''}`}
            <br><small>${mem ? '📍 موقع المحل' : esc(SRC_TXT[x.src] || '')}</small> · <a href="${mapsLink({ lat: x.lat, lng: x.lng })}" target="_blank" rel="noopener">خرائط</a></div>`).addTo(m);
      });
      if (pts.length > 1) m.fitBounds(pts, { padding: [30, 30], maxZoom: 13 }); else if (pts.length === 1) m.setView(pts[0], 13);
      body.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { const k = mk[b.dataset.go]; if (!k) return; box.scrollIntoView({ behavior: 'smooth', block: 'center' }); m.setView(k.getLatLng(), 16); k.openPopup(); });
    } catch { box.innerHTML = '<div class="empty">تعذّر تحميل الخريطة — تحقق من الاتصال</div>'; }
  };
  await paint();
}

function csv(rows, mem) {
  const head = mem ? ['الرقم', 'المحل', 'النشاط', 'المحافظة', 'المدينة', 'العنوان', 'الحالة', 'خط العرض', 'خط الطول']
    : ['الرقم', 'التخصص', 'اسم النشاط', 'النشاط', 'المحافظة', 'المدينة', 'العنوان', 'الحالة', 'المرحلة', 'kW', 'مصدر الموقع', 'خط العرض', 'خط الطول'];
  const body = rows.map(x => mem ? [x.code, x.name, COM_CATS[x.cat] || x.cat, x.gov, x.city, x.address, MEM_ST[x.status] || x.status, x.lat, x.lng]
    : [x.code, fullName(x.sector), x.name, subTxt(x), x.gov, x.city, x.address, x.status === 'completed' ? 'مكتمل' : 'قيد التنفيذ', x.stage, x.kw, SRC_TXT[x.src] || '', x.lat, x.lng]);
  const t = '﻿' + [head, ...body].map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([t], { type: 'text/csv;charset=utf-8' }));
  a.download = `${mem ? 'محلات-التجار' : 'خريطة-المشاريع'}-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
