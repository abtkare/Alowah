// ألواح — الجلسة 50: تثبيت البوابة تطبيقاً على الشاشة.
// ملف مستقل لا يغيّر شيئاً في منطق البوابة ولا في شاشة البداية: يسجّل ملف الخدمة،
// ويعرض بعد الدخول فقط شريطاً صغيراً «ثبّت التطبيق» يمكن إغلاقه.
(function () {
  'use strict';
  try {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {}); });
    }

    const standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
    if (standalone) return;   // مثبّت ويعمل كتطبيق — لا حاجة لأي شيء

    const seg = location.pathname.split('/')[1] || '';
    const KEY = 'alwah-pwa-hide-' + seg;
    const ua = navigator.userAgent || '';
    const isIOS = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    const isMacSafari = !isIOS && /Macintosh/.test(ua) && /Safari\//.test(ua) && !/Chrome|Chromium|Edg|Firefox/.test(ua);
    const name = (document.querySelector('meta[name="apple-mobile-web-app-title"]') || {}).content || 'البوابة';

    let deferred = null, bar = null;
    const hidden = () => { try { return Date.now() < Number(localStorage.getItem(KEY) || 0); } catch (e) { return false; } };
    const hideFor = days => { try { localStorage.setItem(KEY, String(Date.now() + days * 864e5)); } catch (e) {} };

    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; check(); });
    window.addEventListener('appinstalled', () => { deferred = null; remove(); hideFor(3650); });

    // يظهر بعد الدخول فقط: لا شاشة الدخول (.lx) ولا شاشة التحميل
    function loggedIn() {
      const app = document.getElementById('app');
      return !!app && !app.querySelector('.lx') && !app.querySelector('.loading') && app.children.length > 0;
    }
    function canOffer() { return !!deferred || isIOS || isMacSafari; }
    function check() { if (!bar && !hidden() && canOffer() && loggedIn()) show(); }

    function remove() { if (bar) { bar.remove(); bar = null; } }

    function show() {
      bar = document.createElement('div');
      bar.setAttribute('dir', 'rtl');
      bar.style.cssText = 'position:fixed;top:calc(10px + env(safe-area-inset-top,0px));left:12px;right:12px;margin:0 auto;z-index:2147483000;' +
        'display:flex;align-items:center;gap:10px;max-width:460px;box-sizing:border-box;padding:10px 12px 10px 14px;border-radius:14px;' +
        'background:#0b1220;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.35);font:600 14px/1.4 Cairo,system-ui,sans-serif';
      bar.innerHTML = '<span style="font-size:18px">📲</span><span style="flex:1">ثبّت «' + name.replace(/[<>&"]/g, '') + '» على شاشتك</span>' +
        '<button type="button" data-a="go" style="font:inherit;border:0;border-radius:10px;padding:8px 14px;background:#05DBF3;color:#050810;cursor:pointer">ثبّت</button>' +
        '<button type="button" data-a="x" aria-label="إغلاق" style="font:inherit;border:0;background:none;color:#9aa4b8;font-size:18px;padding:4px 6px;cursor:pointer">✕</button>';
      bar.addEventListener('click', async ev => {
        const a = ev.target.closest('button') && ev.target.closest('button').dataset.a;
        if (a === 'x') { hideFor(7); remove(); }
        if (a === 'go') {
          if (deferred) {
            deferred.prompt();
            try { const r = await deferred.userChoice; if (r && r.outcome === 'accepted') hideFor(3650); } catch (e) {}
            deferred = null; remove();
          } else { help(); }
        }
      });
      document.body.appendChild(bar);
    }

    // آيفون وماك سفاري: لا يسمح النظام بالتثبيت بزر — نعرض الخطوتين
    function help() {
      const ios = isIOS;
      const box = document.createElement('div');
      box.setAttribute('dir', 'rtl');
      box.style.cssText = 'position:fixed;inset:0;z-index:2147483001;background:rgba(5,8,16,.6);display:flex;align-items:flex-end;justify-content:center';
      const share = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0a84ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px"><path d="M12 3v12"/><path d="M8 7l4-4 4 4"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/></svg>';
      const steps = ios
        ? '<li>اضغط زر المشاركة ' + share + ' أسفل الشاشة (أو أعلاها في الآيباد)</li><li>اختر «إضافة إلى الشاشة الرئيسية» ثم «إضافة»</li>'
        : '<li>من شريط القوائم في الأعلى اختر «ملف» (File)</li><li>اختر «إضافة إلى Dock» (Add to Dock) ثم «إضافة»</li>';
      box.innerHTML = '<div style="background:#fff;color:#0b1220;width:100%;max-width:440px;border-radius:18px 18px 0 0;padding:20px 20px calc(20px + env(safe-area-inset-bottom,0px));font:15px/1.8 Cairo,system-ui,sans-serif">' +
        '<p style="margin:0 0 8px;font-weight:800;font-size:17px">تثبيت «' + name.replace(/[<>&"]/g, '') + '»</p>' +
        '<ol style="margin:0 0 14px;padding-inline-start:20px">' + steps + '</ol>' +
        '<button type="button" style="font:inherit;font-weight:700;width:100%;border:0;border-radius:12px;padding:12px;background:#0b1220;color:#fff;cursor:pointer">حسناً</button></div>';
      box.addEventListener('click', ev => { if (ev.target === box || ev.target.tagName === 'BUTTON') box.remove(); });
      document.body.appendChild(box);
    }

    // البوابة تبني شاشاتها ديناميكياً — نراقب #app لنعرض الشريط بعد الدخول ونخفيه عند الخروج
    function watch() {
      const app = document.getElementById('app');
      if (!app) return;
      new MutationObserver(() => { if (loggedIn()) check(); else remove(); }).observe(app, { childList: true });
      check();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch); else watch();
  } catch (e) { /* أي خطأ هنا لا يؤثر على البوابة */ }
})();
