// بوابة المورد — العروض والطلبات والتركيب وتوثيق التشغيل
import { esc, iqd, mln, num, kpi, appsTable, openApp, stageActions, tabs, enrichVet, isVet, rpc, toast, cleanErr, modal, badge } from '../core.js';
import { assignAllows } from '../team.js';

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  const [apps, offers, tiers] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('supplier_offers').select('*').eq('supplier_id', org.id).then(r => r.data || []),
    sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
  ]);
  await enrichVet(sb, apps);
  const meta = org.meta || {};
  const vetSup = meta.kind === 'vet';
  const rules = await sb.rpc('my_assignment_rules').then(r => r.data || []).catch(() => []);
  const inbox = apps.filter(a => a.stage === 31 && a.status === 'active' && assignAllows(rules, a, profile));
  const done = apps.filter(a => a.status === 'completed');

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}</h1><p>${meta.legacy ? '<span class="badge ok">معتمد — تعامل سابق</span> ' : '<span class="badge info">معتمد</span> '}مؤشراتك تحسبها المنصة ولا تُدخلها الشركة.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظار التركيب أو التوثيق', `<span class="num">${inbox.length}</span>`, 'طلبات في صندوقك', true)}
      ${kpi('تركيبات منجزة', `<span class="num">${num((meta.installs || 0) + done.length)}</span>`, 'منها على المنصة ' + done.length)}
      ${kpi('نسبة المطابقة في التدقيق', `<span class="num">${meta.match_rate || 0}%</span>`)}
      ${kpi('متوسط مدة التنفيذ', `<span class="num">${meta.avg_days || 0}</span> أيام`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const isAdm = profile.role === 'supplier_admin';
  const defs = [{ key: 'inbox', label: 'أوامر الشراء: التركيب والتوثيق', count: inbox.length }, { key: 'all', label: 'كل طلباتي' }, ...(vetSup || !isAdm ? [] : [{ key: 'offers', label: 'عروضي في الكتالوج' }]), ...(isAdm ? [{ key: 'team', label: 'الفريق الفني' }, { key: 'pay', label: 'المبالغ المصروفة والعمولة' }] : [])];
  ctx.supTab = defs.find(d => d.key === ctx.supTab) ? ctx.supTab : 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.supTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.supTab));
  ctx.hide = ['guarantee'];
  // الجلسة 17: الفني يوثّق التركيب في الموقع، ومدير حساب المورد وحده يعتمد المحضر
  const open = a => openApp(ctx, a, { actions: isAdm && a.stage === 31 && a.status === 'active' ? stageActions(ctx, a).slice(0, 2) : [] });

  function show(k) {
    if (k === 'inbox') body.innerHTML = vetSup ? `<div class="notice">⚕ مورد معتمد في مبادرة الطب البيطري: يصلك الطلب بعد أمر الشراء من المصرف. افتح الطلب ووثّق بالترتيب: <b>التوريد</b> ← <b>التركيب</b> ← <b>التشغيل التجريبي</b>. كل توثيق يفتح دفعتك لدى أمين الصندوق، والدفعة الأخيرة بعد إجازة دائرة البيطرة. ثم اعتمد المحضر.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'stage', 'updated'] })}</div>` : `<div class="notice">📍 تصلك المعاملة بعد صدور أمر الشراء من المصرف. افتحها وأنت في موقع المقترض: <b>ثبّت موقع التركيب بالـGPS</b> ← <b>صورة الألواح</b> ← <b>صورة العاكس والبطاريات</b> ← <b>فيديو التشغيل</b>. كل دليل يُختم بالموقع والوقت والرمز الوظيفي، ولا يُقبل من المعرض، ولا يُعتمد المحضر قبل اكتمالها${isAdm ? '' : ' — ثم يعتمده مدير حساب المورد'}. بعدها تكشف لجنة المصرف على التركيب وتستلمه، ثم يُصرف مبلغك.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'stage', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'bank', 'stage', 'status'] })}</div>`;
    if (k === 'team') return teamTab();
    if (k === 'pay') return import('../repay-ui.js').then(m => m.supplierPayoutsView(ctx, body));
    if (k === 'offers' && vetSup) return;
    if (k === 'offers') return offersTab();
  }
  // ───────── الجلسة 63: المورد يضيف عروضه إلى الكتالوج ويعدّلها — تُنشر بعد مراجعة مشغّل النظام ─────────
  const OST = { published: ['منشور في الكتالوج', 'ok'], review: ['بانتظار مراجعة المنصة', 'warn'], archived: ['مسحوب', 'muted'], draft: ['مسودة', 'muted'] };
  function offersTab() {
    body.innerHTML = `<div class="notice"><span>🛒</span><span class="small">أضف منظومتك بقدرتها وسعرها ومكوّناتها وصورتها وفيديو تشغيلها. يدخل العرض <b>بانتظار مراجعة المنصة</b>، وبعد نشره يظهر للمقترضين في الكتالوج. أي تعديل على عرض منشور يعيده للمراجعة، ولا يؤثر على الطلبات القائمة.</span></div>
      <div class="row mb"><span class="sp"></span><button type="button" class="btn cyan" data-new>＋ إضافة عرض منظومة</button></div>
      ${offers.length ? `<div class="grid g3">${offers.map(o => {
        const t = tiers.find(x => x.id === o.tier_id);
        return `<div class="card offer">${o.image_url ? `<img src="${esc(o.image_url)}" alt="" style="width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:10px;margin-bottom:8px">` : ''}
          <div class="row"><b style="font-size:18px"><span class="num">${num(t?.kw)}</span> kW</b><span class="sp"></span>${badge(OST[o.status] || [o.status, 'muted'])}</div>
          <div class="small muted">نسخة <span class="num">${o.version}</span>${o.video_url ? ' · فيديو ✓' : ' · بلا فيديو'}</div>
          <div class="price">${iqd(o.price)}</div><div class="small muted">سقف البرنامج لهذه القدرة: ${iqd(t?.price_cap)}</div>
          <ul class="small" style="margin:6px 0;padding-inline-start:18px">${(o.components || []).map(c => `<li>${esc(c.item)}: ${esc(c.brand)} ${esc(c.model)} × <span class="num">${c.qty}</span></li>`).join('')}</ul>
          <div class="small muted">${esc(o.warranty || '')}</div>
          <div class="row mt"><button type="button" class="btn ghost sm" data-ed="${o.id}">تعديل</button>${o.status !== 'archived' ? `<button type="button" class="btn ghost sm" data-wd="${o.id}">سحب من الكتالوج</button>` : ''}</div></div>`;
      }).join('')}</div>` : '<div class="card empty">لا عروض بعد — أضف أول منظومة لك.</div>'}`;
    body.querySelector('[data-new]').onclick = () => offerForm(null);
    body.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => offerForm(offers.find(o => o.id === b.dataset.ed)));
    body.querySelectorAll('[data-wd]').forEach(b => b.onclick = async () => {
      if (!confirm('سحب العرض من الكتالوج؟ لن يظهر للمقترضين الجدد.')) return;
      b.disabled = true;
      try { const o = await rpc(sb, 'supplier_offer_withdraw', { p_id: b.dataset.wd }); Object.assign(offers.find(x => x.id === o.id), o); toast('سُحب العرض', 'ok'); offersTab(); }
      catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    });
  }
  async function upload(file, kind) {
    const ext = (file.name.split('.').pop() || (kind === 'video' ? 'mp4' : 'jpg')).toLowerCase().replace(/[^a-z0-9]/g, '');
    const path = `${org.id}/${Date.now()}-${kind}.${ext}`;
    const { error } = await sb.storage.from('offer-media').upload(path, file, { contentType: file.type || (kind === 'video' ? 'video/mp4' : 'image/jpeg'), upsert: false });
    if (error) throw error;
    return sb.storage.from('offer-media').getPublicUrl(path).data.publicUrl;
  }
  function offerForm(o) {
    const DEF = [['ألواح', '', '', ''], ['عاكس هجين', '', '', '1'], ['بطاريات ليثيوم', '', '', ''], ['حماية وتأريض', '', '', '1']];
    const comps = (o?.components?.length ? o.components.map(c => [c.item, c.brand, c.model, String(c.qty)]) : DEF).map(r => r.slice());
    const m = modal(`<h3>${o ? 'تعديل عرض المنظومة' : 'إضافة عرض منظومة'}</h3>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>القدرة ★</label><select class="input" data-f="tier_id">${tiers.map(t => `<option value="${t.id}" ${o?.tier_id === t.id ? 'selected' : ''}>${num(t.kw)} kW — سقف ${iqd(t.price_cap)}</option>`).join('')}</select></div>
        <div class="field"><label>السعر الكامل بالدينار ★</label><input class="input" data-f="price" inputmode="numeric" dir="ltr" value="${o ? o.price : ''}" placeholder="8370000"></div>
        <div class="field"><label>سعة البطاريات (kWh)</label><input class="input" data-f="battery_kwh" inputmode="decimal" dir="ltr" value="${o?.battery_kwh ?? ''}" placeholder="10.24"></div>
      </div>
      <div class="field"><label>المكوّنات ★ — لكل مكوّن: الصنف والعدد، ثم الماركة والموديل</label><div data-comps></div><button type="button" class="btn ghost sm" data-addc>＋ مكوّن</button></div>
      <div class="field"><label>الوصف (ما الذي تشغّله المنظومة، الإنتاج اليومي، يشمل النقل والتركيب…)</label><textarea class="input" rows="3" data-f="description">${esc(o?.description || '')}</textarea></div>
      <div class="field"><label>الضمان والصيانة ★</label><input class="input" data-f="warranty" value="${esc(o?.warranty || '')}" placeholder="الألواح 25 سنة، العاكس 5 سنوات، البطاريات 10 سنوات، صيانة مجانية سنتين"></div>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>صورة المنظومة (JPG أو PNG)${o?.image_url ? ' — موجودة' : ''}</label><input class="input" type="file" accept="image/jpeg,image/png,image/webp" data-img></div>
        <div class="field"><label>فيديو التشغيل (MP4 أفقي 16:9، حتى 25 ميغابايت)${o?.video_url ? ' — موجود' : ''}</label><input class="input" type="file" accept="video/mp4,video/quicktime" data-vid></div>
      </div>
      <p class="small muted" data-prog></p>
      <div class="row"><button type="button" class="btn ghost" data-x>إلغاء</button><span class="sp"></span><button type="button" class="btn cyan" data-go>${o ? 'حفظ وإرسال للمراجعة' : 'إضافة وإرسال للمراجعة'}</button></div>`);
    const box = m.el.querySelector('[data-comps]');
    const drawC = () => {
      box.innerHTML = comps.map((r, i) => `<div style="border:1px solid var(--line);border-radius:12px;padding:8px;margin-bottom:8px">
        <div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(0,1fr) auto;gap:6px;margin-bottom:6px">
          <input class="input" data-c="${i}" data-j="0" value="${esc(r[0])}" placeholder="الصنف: ألواح، عاكس…" aria-label="الصنف">
          <input class="input" inputmode="numeric" dir="ltr" data-c="${i}" data-j="3" value="${esc(r[3])}" placeholder="العدد" aria-label="العدد">
          <button type="button" class="btn ghost sm" data-rm="${i}" aria-label="حذف المكوّن">✕</button></div>
        <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:6px">
          <input class="input" dir="ltr" data-c="${i}" data-j="1" value="${esc(r[1])}" placeholder="Jinko" aria-label="الماركة">
          <input class="input" dir="ltr" data-c="${i}" data-j="2" value="${esc(r[2])}" placeholder="585W" aria-label="الموديل"></div></div>`).join('');
      box.querySelectorAll('[data-c]').forEach(x => x.oninput = () => { comps[x.dataset.c][x.dataset.j] = x.value; });
      box.querySelectorAll('[data-rm]').forEach(x => x.onclick = () => { comps.splice(Number(x.dataset.rm), 1); drawC(); });
    };
    drawC();
    m.el.querySelector('[data-addc]').onclick = () => { comps.push(['', '', '', '']); drawC(); };
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-go]').onclick = async e => {
      const p = {}; m.el.querySelectorAll('[data-f]').forEach(x => p[x.dataset.f] = x.value.trim());
      p.components = comps.map(([item, brand, model, qty]) => ({ item: item.trim(), brand: brand.trim(), model: model.trim(), qty: String(qty).replace(/[^\d]/g, '') }));
      const img = m.el.querySelector('[data-img]').files[0], vid = m.el.querySelector('[data-vid]').files[0], prog = m.el.querySelector('[data-prog]');
      if (img && img.size > 5 * 1048576) return toast('الصورة أكبر من 5 ميغابايت', 'bad');
      if (vid && vid.size > 25 * 1048576) return toast('الفيديو أكبر من 25 ميغابايت — صدّره بدقة 1280×720', 'bad');
      e.target.disabled = true;
      try {
        if (img) { prog.textContent = 'جارِ رفع الصورة…'; p.image_url = await upload(img, 'image'); }
        if (vid) { prog.textContent = 'جارِ رفع الفيديو… لا تغلق الصفحة'; p.video_url = await upload(vid, 'video'); }
        prog.textContent = '';
        const r = await rpc(sb, 'supplier_offer_save', { p_id: o?.id || null, p });
        const i = offers.findIndex(x => x.id === r.id); if (i >= 0) offers[i] = r; else offers.unshift(r);
        m.close(); toast('أُرسل العرض لمراجعة المنصة — يظهر للمقترضين بعد نشره', 'ok'); offersTab();
      } catch (er) { prog.textContent = ''; toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }
  // الجلسة 17: مدير حساب المورد يضيف فنيي التركيب ويوقفهم
  async function teamTab() {
    body.innerHTML = '<div class="card"><div class="spin"></div></div>';
    let list = [];
    try { list = await rpc(sb, 'supplier_team', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
    body.innerHTML = `<div class="notice">فنيو التركيب يدخلون من <b>بوابة المورد</b> بحساباتهم، ويوثّقون التركيب في موقع المقترض. لا يعتمدون المحضر ولا يرون العروض. أول دخول يطلب تغيير كلمة المرور المؤقتة.</div>
      <div class="card flush"><h3>الفريق <span class="sp"></span><button class="btn cyan sm" data-add>إضافة فني</button></h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الرمز الوظيفي</th><th>الدور</th><th>الحالة</th><th></th></tr></thead><tbody>
      ${list.map(u => `<tr><td>${esc(u.full_name)}</td><td class="num" dir="ltr">${esc(u.username)}</td><td class="num">${esc(u.staff_code || '')}</td><td class="small">${esc(u.title)}</td>
        <td>${u.disabled ? badge(['موقوف', 'bad']) : u.must_change_password ? badge(['بانتظار أول دخول', 'warn']) : badge(['فعّال', 'ok'])}</td>
        <td>${u.role === 'supplier_tech' ? `<button class="btn sm ${u.disabled ? 'ok' : 'ghost'}" data-dis="${u.id}" data-v="${u.disabled ? '0' : '1'}">${u.disabled ? 'تفعيل' : 'إيقاف'}</button>` : ''}</td></tr>`).join('')}
      </tbody></table></div></div>`;
    body.querySelectorAll('[data-dis]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      try { await rpc(sb, 'supplier_set_tech', { p_user: b.dataset.dis, p_disabled: b.dataset.v === '1' }); toast('حُدّث الحساب', 'ok'); teamTab(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    });
    body.querySelector('[data-add]').onclick = () => {
      const m = modal(`<h3>إضافة فني تركيب</h3>
        <div class="field"><label>الاسم الكامل</label><input class="input" data-k="full_name"></div>
        <div class="field"><label>اسم المستخدم (حروف إنجليزية صغيرة)</label><input class="input" data-k="username" dir="ltr" placeholder="tech.ali"></div>
        <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" dir="ltr" inputmode="tel" placeholder="07xxxxxxxxx"></div>
        <div class="field"><label>كلمة مرور مؤقتة</label><input class="input" data-k="password" dir="ltr" placeholder="8 أحرف وأرقام على الأقل"></div>
        <div class="row"><span class="sp"></span><button class="btn cyan" data-go>إنشاء الحساب</button></div>`);
      m.el.querySelector('[data-go]').onclick = async e => {
        const d = {}; m.el.querySelectorAll('[data-k]').forEach(x => d[x.dataset.k] = x.value.trim());
        e.target.disabled = true;
        try { const r = await rpc(sb, 'supplier_add_tech', { p: d }); m.close(); toast(`أُنشئ الحساب ${r.username} (${r.staff_code})`, 'ok'); teamTab(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    };
  }
  show(ctx.supTab);
}
