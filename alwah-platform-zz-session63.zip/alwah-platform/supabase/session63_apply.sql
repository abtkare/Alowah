-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 63: المورد يضيف عروضه إلى الكتالوج بنفسه
--  • supplier_offer_save: مدير حساب المورد يضيف عرض منظومة أو يعدّله (القدرة، السعر ضمن سقف الفئة،
--    المكوّنات، البطارية، الوصف، الضمان، صورة وفيديو). العرض الجديد أو المعدَّل يدخل «بانتظار المراجعة»
--    ولا يظهر للمقترضين حتى ينشره مشغّل النظام من صفحة «العروض والموردون» (الطلبات القائمة لا تتأثر).
--  • supplier_offer_withdraw: المورد يسحب عرضه من الكتالوج.
--  • مخزن الوسائط offer-media (عام للقراءة): كل مورد يرفع داخل مجلد باسم معرّف شركته فقط.
-- آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════
set check_function_bodies = off;

-- ───────── مخزن صور العروض وفيديوهاتها ─────────
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('offer-media', 'offer-media', true, 26214400, array['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/quicktime'])
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists offer_media_insert on storage.objects;
create policy offer_media_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'offer-media' and public.my_portal() = 'supplier'
    and (storage.foldername(name))[1] = public.my_org()::text);
drop policy if exists offer_media_read on storage.objects;
create policy offer_media_read on storage.objects for select
  using (bucket_id = 'offer-media');

-- ───────── حفظ العرض ─────────
create or replace function public._sup_me() returns profiles
language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null or me.portal <> 'supplier' or coalesce(me.disabled, false) then raise exception 'عروض الكتالوج من بوابة المورد'; end if;
  if me.role <> 'supplier_admin' then raise exception 'إضافة العروض صلاحية مدير حساب المورد'; end if;
  if (select meta->>'kind' from orgs where id = me.org_id) = 'vet' then raise exception 'موردو المبادرة البيطرية لا يعرضون منظومات في الكتالوج'; end if;
  return me;
end $$;

create or replace function public.supplier_offer_save(p_id uuid, p jsonb) returns supplier_offers
language plpgsql security definer set search_path = public as $$
declare me profiles := _sup_me(); t capacity_tiers; o supplier_offers; old supplier_offers; comps jsonb := '[]'; c jsonb;
  v_price bigint; v_bat numeric; v_img text; v_vid text; v_org text;
begin
  select * into t from capacity_tiers where id = nullif(p->>'tier_id', '')::uuid;
  if t.id is null then raise exception 'اختر قدرة المنظومة'; end if;
  v_price := nullif(regexp_replace(coalesce(p->>'price', ''), '[^0-9]', '', 'g'), '')::bigint;
  if v_price is null or v_price < 100000 then raise exception 'اكتب سعر المنظومة بالدينار'; end if;
  if v_price > t.price_cap then raise exception 'السعر % يتجاوز سقف البرنامج لقدرة % kW (%)', to_char(v_price, 'FM999,999,999'), t.kw, to_char(t.price_cap, 'FM999,999,999'); end if;
  for c in select * from jsonb_array_elements(case when jsonb_typeof(p->'components') = 'array' then p->'components' else '[]' end) loop
    if trim(coalesce(c->>'item', '')) = '' then continue; end if;
    if coalesce(nullif(regexp_replace(coalesce(c->>'qty', ''), '[^0-9]', '', 'g'), '')::int, 0) < 1 then raise exception 'اكتب عدد «%»', trim(c->>'item'); end if;
    comps := comps || jsonb_build_object('item', left(trim(c->>'item'), 60), 'brand', left(trim(coalesce(c->>'brand', '')), 60),
      'model', left(trim(coalesce(c->>'model', '')), 60), 'qty', regexp_replace(c->>'qty', '[^0-9]', '', 'g')::int);
  end loop;
  if jsonb_array_length(comps) < 2 then raise exception 'اكتب مكوّنات المنظومة (الألواح والعاكس على الأقل)'; end if;
  if length(trim(coalesce(p->>'warranty', ''))) < 5 then raise exception 'اكتب الضمان والصيانة'; end if;
  v_bat := nullif(regexp_replace(coalesce(p->>'battery_kwh', ''), '[^0-9.]', '', 'g'), '')::numeric;
  v_org := me.org_id::text;
  -- الصورة والفيديو: من مخزن العروض في مجلد الشركة نفسها فقط (أو تبقى القديمة)
  v_img := nullif(trim(coalesce(p->>'image_url', '')), '');
  v_vid := nullif(trim(coalesce(p->>'video_url', '')), '');
  if v_img is not null and v_img !~ ('/storage/v1/object/public/offer-media/' || v_org || '/') and v_img !~ '^/media/offers/' then raise exception 'صورة العرض غير صالحة — ارفعها من جديد'; end if;
  if v_vid is not null and v_vid !~ ('/storage/v1/object/public/offer-media/' || v_org || '/') and v_vid !~ '^/media/offers/' then raise exception 'فيديو العرض غير صالح — ارفعه من جديد'; end if;

  if p_id is null then
    insert into supplier_offers(supplier_id, tier_id, title, price, components, description, warranty, battery_kwh, image_url, video_url, version, status)
    values (me.org_id, t.id, t.kw || ' kW — ' || (select name from orgs where id = me.org_id), v_price, comps,
      nullif(left(trim(coalesce(p->>'description', '')), 600), ''), left(trim(p->>'warranty'), 300), v_bat, v_img, v_vid, 1, 'review')
    returning * into o;
    perform _audit('إضافة عرض منظومة للمراجعة', o.title, jsonb_build_object('offer', o.id, 'price', v_price));
  else
    select * into old from supplier_offers where id = p_id for update;
    if old.id is null or old.supplier_id <> me.org_id then raise exception 'العرض غير موجود في شركتك'; end if;
    update supplier_offers set tier_id = t.id, title = t.kw || ' kW — ' || (select name from orgs where id = me.org_id), price = v_price, components = comps,
      description = nullif(left(trim(coalesce(p->>'description', '')), 600), ''), warranty = left(trim(p->>'warranty'), 300), battery_kwh = v_bat,
      image_url = coalesce(v_img, old.image_url), video_url = coalesce(v_vid, old.video_url),
      version = old.version + 1, status = 'review'
    where id = old.id returning * into o;
    perform _audit('تعديل عرض منظومة — بانتظار المراجعة', o.title, jsonb_build_object('offer', o.id, 'from', to_jsonb(old) - 'components', 'version', o.version));
  end if;
  return o;
end $$;

create or replace function public.supplier_offer_withdraw(p_id uuid) returns supplier_offers
language plpgsql security definer set search_path = public as $$
declare me profiles := _sup_me(); o supplier_offers;
begin
  update supplier_offers set status = 'archived' where id = p_id and supplier_id = me.org_id returning * into o;
  if o.id is null then raise exception 'العرض غير موجود في شركتك'; end if;
  perform _audit('سحب عرض منظومة من الكتالوج', o.title, null);
  return o;
end $$;

revoke all on function public._sup_me() from public, anon, authenticated;
revoke all on function public.supplier_offer_save(uuid, jsonb), public.supplier_offer_withdraw(uuid) from public, anon;
grant execute on function public.supplier_offer_save(uuid, jsonb), public.supplier_offer_withdraw(uuid) to authenticated;

reset check_function_bodies;
