// الجلسة 41: الهيئة الشرعية — الحزمة 2، في الطلب نفسه
//  • المقترض: «اقرأ ثم وقّع» للوعد أو العقد (النص المعتمد نفسه ببصمته)، و«عقدي» مع رمز QR للتحقق
//  • المصرف والجهات: «الامتثال الشرعي للطلب» — الحرّاس الآليون قائمةً، والمستندات الموقّعة
//  • المورد: إصدار الفاتورة باسم المصرف (المرابحة والإجارة)
import { esc, dt, badge, rpc, toast, cleanErr, modal, iqd, askOtp, resultScreen, el } from './core.js';
import { shortSha } from './sharia-ui.js';
import { qrSvg } from './qr.js';

export const verifyUrl = code => `${location.origin}/v/${code}`;
const KIND_IC = { promise: '🤝', invoice: '🧾', receipt: '📦', contract: '📜', shares: '⚖', share_sale: '🔁' };

// شاشة كاملة لقراءة نص (قبل التوقيع أو بعده)
function reader({ title, sub = '', seal = '', clauses = [], kv = [], foot = '', extra = '', actionLabel = '', onAction = null }) {
  const bg = el(`<div class="ct-bg" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="ct">
      <header class="ct-top"><button type="button" class="ct-x" aria-label="رجوع">→</button><div><b>${esc(title)}</b><small>${esc(sub)}</small></div></header>
      <div class="ct-body">
        ${seal}
        ${kv.length ? `<dl class="kv isl-kv">${kv.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v}</dd>`).join('')}</dl>` : ''}
        ${clauses.length ? `<ol class="ct-cls">${clauses.map(c => `<li><b>${esc(c.title)}</b><p>${esc(c.text)}</p></li>`).join('')}</ol>` : ''}
        ${extra}
        ${foot ? `<div class="small muted ct-foot">${foot}</div>` : ''}
      </div>
      <footer class="ct-act"><button type="button" class="btn ghost" data-back>رجوع</button>${onAction ? `<button type="button" class="btn cyan" data-act>${esc(actionLabel)}</button>` : ''}</footer>
    </div></div>`);
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  const close = () => { bg.classList.remove('on'); setTimeout(() => bg.remove(), 220); document.removeEventListener('keydown', k); };
  const k = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', k);
  bg.querySelector('.ct-x').onclick = close; bg.querySelector('[data-back]').onclick = close;
  const a = bg.querySelector('[data-act]'); if (a) a.onclick = () => onAction({ close, root: bg, btn: a });
  return { close, root: bg };
}

const SLM_F = [['goods', 'نوع السلعة', 'مثال: تمور زهدي درجة أولى'], ['qty', 'الكمية', 'مثال: 20 طناً'], ['quality', 'الجودة والمواصفات', 'مثال: رطوبة أقل من 18%'],
  ['delivery_date', 'موعد التسليم', ''], ['delivery_place', 'مكان التسليم', 'مثال: مخازن المصرف في البصرة']];

// «اقرأ ثم وقّع»: يعرض النص الذي سيُحفظ حرفياً، ثم رمز التحقق. after(code) لعملية تلي التوقيع بالرمز نفسه (مثل إرسال الطلب)
export async function signIslamic(sb, app, kind, { profile, actionLabel, after = null, onDone = null } = {}) {
  let T;
  try { T = await rpc(sb, 'islamic_sign_text', { p_app: app.id, p_kind: kind }); } catch (e) { return toast(cleanErr(e), 'bad'); }
  const two = ['MRB', 'IJM'].includes(T.type);
  const c = T.calc || {};
  const extra = kind === 'contract' && T.type === 'MSN'
    ? `<div class="field mt"><label>حصتك في رأس مال الشركة (بالدينار)</label><input class="input" data-client inputmode="numeric" dir="ltr" placeholder="مثال: 2000000"><small class="muted">حصة المصرف ${iqd(app.amount)} — تشتريها منه تدريجياً، وكل شراء عقد بيع مستقل.</small></div>`
    : kind === 'contract' && T.type === 'SLM'
      ? `<h3 class="ct-h">صف السلعة (إلزامي)</h3><div class="grid" style="gap:8px">${SLM_F.map(([k, l, ph]) => `<div class="field"><label>${l}</label><input class="input" data-spec="${k}" ${k === 'delivery_date' ? 'type="date"' : ''} placeholder="${esc(ph)}"></div>`).join('')}</div>`
      : '';
  const seal = `<div class="ct-seal"><span class="ct-ok">✓</span><div><b>معتمد شرعاً — قرار <span class="num">${esc(T.resolution || '—')}</span></b><small>${esc(T.product)} · نسخة العقد <span class="num">${esc(T.version)}</span></small></div></div>
    ${kind === 'promise' ? `<div class="notice mt"><span>ℹ</span><span class="small">هذا <b>وعد غير ملزم</b> لا يُنشئ ديناً عليك. بعد أن يشتري المصرف المنظومة ويقبضها نرسل لك ${T.type === 'IJM' ? 'عقد الإجارة' : 'عقد البيع'} لتوقّعه — بالربح نفسه المعلن هنا.</span></div>`
      : two ? '<div class="notice ok-n mt"><span>✓</span><span class="small">صارت المنظومة ملك المصرف وفي قبضه — يمكنك الآن توقيع العقد.</span></div>' : ''}
    <dl class="ct-sum isl-sum"><div><dt><i>💰</i>${T.type === 'IJM' ? 'الأجرة' : 'الثمن'}</dt><dd><b>${iqd(c.total)}</b> = ${iqd(c.installment)} × <span class="num">${esc(c.term)}</span> شهراً</dd></div>
      ${T.type !== 'IJM' ? `<div><dt><i>🧾</i>الكلفة + الربح</dt><dd>${iqd(c.cost)} + ${iqd(c.profit)}</dd></div>` : ''}</dl>
    <h3 class="ct-h">${kind === 'promise' ? 'نص الوعد كما ستوقّعه' : 'نص العقد كما ستوقّعه'}</h3>`;
  const R = reader({ title: T.title, sub: `${app.code}`, seal, clauses: T.clauses || [], extra,
    foot: kind === 'contract' ? `هذا هو النص المعتمد حرفياً مملوءاً ببيانات طلبك. بصمة النسخة المعتمدة ${shortSha(T.sha256)} — يُحفظ ما توقّعه ببصمة خاصة ورمز تحقق.` : 'يُحفظ النص الذي توقّعه حرفياً ببصمة رقمية ورمز تحقق QR.',
    actionLabel: actionLabel || `وقّع ${T.title.replace(/\s*\(.*\)$/, '')}`,
    onAction: async ({ close, root, btn }) => {
      const data = {};
      if (T.type === 'MSN' && kind === 'contract') data.client_share = root.querySelector('[data-client]')?.value || '';
      if (T.type === 'SLM' && kind === 'contract') { data.spec = {}; root.querySelectorAll('[data-spec]').forEach(i => { data.spec[i.dataset.spec] = i.value.trim(); }); }
      btn.disabled = true; root.style.visibility = 'hidden';   // نافذة الرمز فوق القارئ
      let res = null;
      const code = await askOtp({ kind: 'sign', title: `توقيع ${T.title}`, phone: profile?.phone, purpose: `${T.product} · ${iqd(c.total)}`,
        verify: async c2 => { res = await rpc(sb, 'islamic_sign', { p_app: app.id, p_kind: kind, p_otp: c2, p_data: data }); if (after) await after(c2); } });
      btn.disabled = false;
      if (!code) { root.style.visibility = ''; return; }
      close();
      if (after) { onDone?.(res); return; }
      await resultScreen({ title: `وقّعت ${T.title.replace(/\s*\(.*\)$/, '')}`, msg: two && kind === 'contract' ? 'أُبلغ المصرف — ينفّذ تمويلك ويصدر جدول أقساطك. تجد العقد دائماً في «عقدي».' : 'تجده دائماً في «عقدي» مع رمز التحقق.',
        rows: [['رمز التحقق', `<b class="num" dir="ltr">${esc(res?.verify_code || '')}</b>`]], seal: res?.doc_sha256 || '' });
      onDone?.(res);
    } });
  return R;
}

// قراءة مستند موقّع: النص المحفوظ نفسه، وسلامته، ورمز QR
export async function docReader(sb, id) {
  let D;
  try { D = await rpc(sb, 'islamic_app_doc', { p_doc: id }); } catch (e) { return toast(cleanErr(e), 'bad'); }
  const b = D.body || {}, kv = [];
  if (D.kind === 'invoice') kv.push(['رقم الفاتورة', `<b class="num" dir="ltr">${esc(b.invoice_no)}</b>`], ['البائع', esc(b.seller)], ['المشتري', `<b>${esc(b.buyer)}</b>`], ['المنظومة', esc(b.asset)], ['المبلغ', iqd(b.amount)], ['التاريخ', esc(b.date)]);
  if (D.kind === 'receipt') kv.push(['المنظومة', esc(b.asset)], ['المالك الآن', `<b>${esc(b.owner)}</b>`], ['المورد', esc(b.supplier)], ['فاتورة', `<span class="num" dir="ltr">${esc(b.invoice_no || '—')}</span>`], ['الموقع', esc(b.site)], ['المحضر', esc(b.statement)], ['بواسطة', esc(b.by_title || b.by || '')], ['التاريخ', esc(b.date)]);
  if (D.kind === 'shares') kv.push(['حصة المصرف', `${iqd(b.bank)} (<span class="num">${b.bank_pct}%</span>)`], ['حصتك', `${iqd(b.client)} (<span class="num">${b.client_pct}%</span>)`], ['عدد عقود بيع الحصص', `<span class="num">${b.units}</span>`]);
  if (D.kind === 'share_sale') kv.push(['الحصة المبيعة', `<span class="num">${b.pct}%</span>`], ['الثمن', iqd(b.price)], ['حصة المصرف بعدها', `<span class="num">${b.bank_pct_after}%</span>`], ['حصتك بعدها', `<span class="num">${b.client_pct_after}%</span>`]);
  if (b.calc && ['promise', 'contract'].includes(D.kind)) kv.push(['الثمن', `${iqd(b.calc.total)} = ${iqd(b.calc.installment)} × <span class="num">${b.calc.term}</span>`], ['الكلفة + الربح', `${iqd(b.calc.cost)} + ${iqd(b.calc.profit)}`]);
  if (b.shares) kv.push(['الحصص', `المصرف <span class="num">${b.shares.bank_pct}%</span> · أنت <span class="num">${b.shares.client_pct}%</span>`]);
  if (b.spec) kv.push(['وصف السلعة', esc(Object.values(b.spec).join(' · '))]);
  const url = D.verify_code ? verifyUrl(D.verify_code) : '';
  const seal = `<div class="ct-seal ${D.intact ? '' : 'bad'}"><span class="ct-ok">${D.intact ? '✓' : '!'}</span><div><b>${D.intact ? 'النص سليم — لم يتغير منذ التوقيع' : 'تحذير: النص المحفوظ لا يطابق بصمته'}</b>
    <small>${esc(D.by || '')}${D.by_title ? ` (${esc(D.by_title)})` : ''} · ${dt(D.at)}${D.signed_via ? ` · ${esc(D.signed_via)}` : ''}</small></div></div>`;
  const qr = url ? `<div class="isl-qr">${qrSvg(url, { size: 150 })}<div><b>تحقّق من هذا المستند</b><p class="small muted">امسح الرمز أو افتح الرابط — تظهر صفحة من «ألواح» تثبت أن النص مطابق للنسخة التي اعتمدتها الهيئة الشرعية.</p>
    <div class="row small" style="gap:6px;flex-wrap:wrap"><span>رمز التحقق <b class="num" dir="ltr">${esc(D.verify_code)}</b></span><a class="linkbtn" href="${esc(url)}" target="_blank" rel="noopener">افتح صفحة التحقق ↗</a></div></div></div>` : '';
  reader({ title: D.title, sub: D.app_code, seal, kv, clauses: b.clauses || [], extra: qr,
    foot: `بصمة النص ${shortSha(D.doc_sha256)}${D.version_sha256 ? ` · بصمة النسخة المعتمدة ${shortSha(D.version_sha256)}` : ''}${D.resolution ? ` · قرار الهيئة <span class="num">${esc(D.resolution)}</span>` : ''}` });
}

const stepsHtml = S => `<ol class="isl-steps">${S.steps.map(s => `<li class="${s.ok ? 'ok' : 'no'}"><i>${s.ok ? '✓' : '○'}</i><div><b>${esc(s.label)}</b>${s.note || s.at ? `<small>${s.note ? esc(s.note) : ''}${s.note && s.at ? ' · ' : ''}${s.at ? dt(s.at) : ''}</small>` : ''}</div>${s.stage ? `<span class="isl-st">المرحلة <span class="num">${s.stage}</span></span>` : ''}</li>`).join('')}</ol>`;
const docsHtml = S => S.docs.length ? `<div class="isl-docs">${S.docs.filter(d => d.kind !== 'share_sale').map(d => `<button type="button" class="isl-doc" data-doc="${d.id}"><i>${KIND_IC[d.kind] || '📄'}</i><span><b>${esc(d.title)}</b><small>${dt(d.at)}${d.verify_code ? ` · <span class="num" dir="ltr">${esc(d.verify_code)}</span>` : ''}</small></span><em>اقرأ</em></button>`).join('')}
  ${S.docs.some(d => d.kind === 'share_sale') ? `<div class="small muted">🔁 عقود بيع الحصص: <span class="num">${S.docs.filter(d => d.kind === 'share_sale').length}</span> — ${S.docs.filter(d => d.kind === 'share_sale').map(d => `<button type="button" class="linkbtn" data-doc="${d.id}">${d.n}</button>`).join(' ')}</div>` : ''}</div>` : '';

// المصرف والجهات والمورد: «الامتثال الشرعي للطلب»
export async function mountIslamicApp(ctx, app, box) {
  const { sb } = ctx;
  let S;
  try { S = await rpc(sb, 'islamic_app_state', { p_app: app.id }); } catch { return; }   // قبل تطبيق تحديث الجلسة 41
  if (!S) return;
  const bad = S.steps.filter(s => !s.ok);
  box.innerHTML = `<div class="card mb isl-card"><h3>🕌 الامتثال الشرعي — ${esc(S.type_name)}<span class="sp"></span>${badge(bad.length ? [`${bad.length} بانتظار التحقق`, 'warn'] : ['مستوفى', 'ok'])}</h3>
    <p class="small muted" style="margin:0 0 8px">${esc(S.product.name)} · قرار <b class="num">${esc(S.resolution || '—')}</b> · نسخة العقد <span class="num">${S.version}</span> ${shortSha(S.sha256)} — يمنع النظام آلياً أي انتقال يخالف شروط الصيغة.</p>
    ${S.can_invoice ? `<div class="notice warn mb"><span>🧾</span><span><b>المطلوب منك:</b> فاتورة المنظومة باسم <b>المصرف</b> لا المقترض — المصرف يشتري أولاً ثم يبيع. لا يُنجز التركيب قبلها.</span></div><button class="btn cyan mb" data-inv>إصدار الفاتورة باسم المصرف</button>` : ''}
    ${stepsHtml(S)}
    ${docsHtml(S)}</div>`;
  box.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => docReader(sb, b.dataset.doc));
  const iv = box.querySelector('[data-inv]');
  if (iv) iv.onclick = () => {
    const m = modal(`<h3>🧾 فاتورة المنظومة باسم المصرف</h3>
      <dl class="kv"><dt>المشتري</dt><dd><b>${esc((ctx.orgs || []).find(o => o.id === app.bank_id)?.name || 'المصرف')}</b></dd><dt>المنظومة</dt><dd>طلب <span class="num">${esc(app.code)}</span></dd><dt>المبلغ</dt><dd>${iqd(app.amount)} <span class="small muted">= كلفة المنظومة في الطلب</span></dd></dl>
      <div class="field mt"><label>رقم الفاتورة</label><input class="input" data-no dir="ltr" placeholder="مثل INV-2026-0451"></div>
      <p class="small muted">تُحفظ الفاتورة ببصمة رقمية ويُبلَّغ المصرف فوراً. بعدها أنجز التركيب كالمعتاد.</p>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إصدار الفاتورة</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-ok]').onclick = async e => {
      e.target.disabled = true;
      try {
        const r = await rpc(sb, 'islamic_supplier_invoice', { p_app: app.id, p: { invoice_no: m.el.querySelector('[data-no]').value } });
        m.close();
        await resultScreen({ title: 'صدرت الفاتورة باسم المصرف', msg: 'يمكنك الآن إنجاز التركيب وتوثيقه.', rows: [['رقم الفاتورة', `<b class="num" dir="ltr">${esc(r.invoice_no)}</b>`], ['المبلغ', iqd(r.amount)]], chips: ['المصرف'] });
        mountIslamicApp(ctx, app, box);
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

// المقترض: «عقدي» في «طلبي» — دائماً متاح
export async function mountMyContract(sb, app, box, { profile, onDone } = {}) {
  if (!box) return null;
  let S;
  try { S = await rpc(sb, 'islamic_app_state', { p_app: app.id }); } catch { box.innerHTML = ''; return null; }
  if (!S) { box.innerHTML = ''; return null; }
  const main = S.docs.slice().reverse().find(d => d.kind === 'contract') || S.docs.slice().reverse().find(d => d.kind === 'promise');
  box.innerHTML = `<div class="card mb isl-my"><h3>📜 عقدي<span class="sp"></span>${badge(['معتمد شرعاً', 'ok'])}</h3>
    <p class="small muted" style="margin:0 0 10px">${esc(S.product.name)} — ${esc(S.type_name)} · قرار الهيئة <b class="num">${esc(S.resolution || '—')}</b></p>
    ${S.next ? `<div class="isl-next"><b>${S.two_phase && S.next === 'contract' ? 'المنظومة صارت ملك المصرف ✓' : 'بقي توقيعك'}</b><p>وقّع ${esc(S.next_label)} — اقرأه أولاً ثم وقّع برمز يصلك.</p><button class="btn cyan big-btn" data-sign>وقّع ${esc(S.next_label)}</button></div>` : ''}
    ${main ? `<div class="isl-main"><button type="button" class="isl-qr-btn" data-doc="${main.id}" aria-label="رمز التحقق">${qrSvg(verifyUrl(main.verify_code), { size: 96 })}</button>
      <div><b>${esc(main.title)}</b><div class="small muted">وقّعته ${dt(main.at)} · رمز التحقق <span class="num" dir="ltr">${esc(main.verify_code)}</span></div>
      <div class="row mt" style="gap:8px;flex-wrap:wrap"><button class="btn ghost sm" data-doc="${main.id}">اقرأ ما وقّعته</button>${S.two_phase && !S.next && !S.docs.some(d => d.kind === 'contract') ? '<button class="btn ghost sm" data-preview>اقرأ العقد الذي ستوقّعه لاحقاً</button>' : ''}</div></div></div>`
    : '<button class="btn ghost sm" data-preview>اقرأ العقد</button>'}
    ${S.docs.length > 1 ? `<details class="mt"><summary class="small">كل المستندات (<span class="num">${S.docs.length}</span>) — الوعد، فاتورة المورد باسم المصرف، محضر القبض، العقد</summary>${docsHtml(S)}</details>` : ''}
    <p class="small muted" style="margin:10px 0 0">⏳ إن تأخرت في السداد: لا تُضاف أي زيادة على المبلغ لمصلحة المصرف.</p></div>`;
  box.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => docReader(sb, b.dataset.doc));
  const pv = box.querySelector('[data-preview]');
  if (pv) pv.onclick = async () => {
    try { const T = await rpc(sb, 'islamic_sign_text', { p_app: app.id, p_kind: 'contract' });
      reader({ title: T.title, sub: 'للاطلاع — ' + (S.two_phase ? 'توقّعه بعد أن يتملّك المصرف المنظومة' : 'النص المعتمد'), clauses: T.clauses, foot: `النسخة المعتمدة ${shortSha(T.sha256)} · قرار <span class="num">${esc(T.resolution || '—')}</span>` }); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
  const sg = box.querySelector('[data-sign]');
  if (sg) sg.onclick = () => signIslamic(sb, app, S.next, { profile, onDone });
  return S;
}

// التحصيل والمقترض: قاعدة التأخر، والتبرع لصندوق خيري إن قررته الهيئة
export async function islamicLateNotice(sb, app, info, onDone) {
  let L;
  try { L = await rpc(sb, 'islamic_late_info', { p_app: app.id }); } catch { return null; }
  if (!L) return null;
  return { L, html: `<div class="notice isl-late mb"><span>🕌</span><span class="small"><b>تمويل إسلامي — لا تُضاف أي زيادة على القسط أو الدين المتأخر لمصلحة المصرف.</b><br>${esc(L.rule)}<br><span class="muted">قرار الهيئة: ${esc(L.kind_label)}</span>
    ${L.charity.length ? `<div class="mt">تبرعات لصندوق خيري (خارج إيرادات المصرف): ${L.charity.map(c => `القسط <span class="num">${c.n}</span>: ${iqd(c.amount)}`).join(' · ')}</div>` : ''}</span>
    ${L.can_charity && (info.schedule || []).some(r => r.late > 0) ? '<button class="btn ghost sm" data-charity>تسجيل تبرع</button>' : ''}</div>`,
  wire: root => {
    const b = root.querySelector('[data-charity]'); if (!b) return;
    b.onclick = () => {
      const late = (info.schedule || []).filter(r => r.late > 0);
      const m = modal(`<h3>تبرع لصندوق خيري عن تأخر قسط</h3><p class="small muted">بقرار الهيئة الشرعية — يُسجَّل خارج إيرادات المصرف.</p>
        <div class="field"><label>القسط</label><select class="input" data-n>${late.map(r => `<option value="${r.n}">القسط ${r.n} — متأخر ${r.late} يوماً</option>`).join('')}</select></div>
        <div class="field"><label>المبلغ (دينار)</label><input class="input" data-a inputmode="numeric" dir="ltr"></div>
        <div class="field"><label>رقم وصل الصندوق الخيري</label><input class="input" data-r dir="ltr"></div>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>تسجيل</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      m.el.querySelector('[data-ok]').onclick = async () => {
        try { await rpc(sb, 'islamic_charity_record', { p_app: app.id, p_n: Number(m.el.querySelector('[data-n]').value), p_amount: Number(m.el.querySelector('[data-a]').value.replace(/\D/g, '')), p_ref: m.el.querySelector('[data-r]').value });
          m.close(); toast('سُجّل التبرع خارج إيرادات المصرف', 'ok'); onDone?.(); }
        catch (er) { toast(cleanErr(er), 'bad'); }
      };
    };
  } };
}
