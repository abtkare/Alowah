// الجلسة 17: الإشعارات داخل المنصة — جرس في الشريط العلوي مع تحديث لحظي
import { esc, ago, el, toast } from './core.js';

const ICON = { finance_circular: '💰', initiative: '📣', initiative_reply: '✉', letter: '🔒', exec: '⏱' };

export function mountBell(ctx, host) {
  const { sb } = ctx;
  const btn = el(`<button type="button" class="btn btn-dark sm bell" title="الإشعارات" aria-label="الإشعارات">🔔<i class="bell-n" hidden></i></button>`);
  host.before(btn);
  let data = { items: [], unread: 0 }, panel = null, seen = null;
  const n = btn.querySelector('.bell-n');
  const paintCount = () => { n.hidden = !data.unread; n.textContent = data.unread > 9 ? '9+' : data.unread; };
  const load = async () => {
    const r = await sb.rpc('my_notifications');
    if (r.error) return;
    const prev = seen; data = r.data || data; paintCount();
    const ids = new Set(data.items.map(x => x.id));
    if (prev) data.items.filter(x => !prev.has(x.id) && !x.read).slice(0, 2).forEach(x => toast(`${ICON[x.kind] || '🔔'} ${x.title}`, 'ok'));
    seen = ids;
    if (panel) draw();
  };
  const go = x => {
    close();
    if (x.kind === 'initiative' && ctx.portal === 'bank') { ctx.bankTab = 'initiatives'; location.hash = ''; ctx.refresh(); }
    else if (x.kind === 'initiative_reply' && ctx.portal === 'cbi') { ctx.cbiTab = 'initiatives'; location.hash = ''; ctx.refresh(); }
    else if (x.kind === 'letter') { if (ctx.portal === 'cbi') ctx.cbiTab = 'letters'; else ctx.nzTab = 'letters'; location.hash = ''; ctx.refresh(); }
  };
  const draw = () => {
    panel.innerHTML = `<div class="row" style="padding:10px 12px;border-bottom:1px solid var(--line)"><b>الإشعارات</b><span class="sp"></span>${data.unread ? '<button type="button" class="linkbtn" data-all>تعليم الكل كمقروء</button>' : ''}</div>
      <div class="bell-list">${data.items.map(x => `<button type="button" class="bell-it ${x.read ? '' : 'new'}" data-id="${x.id}"><span class="ic">${ICON[x.kind] || '🔔'}</span><span><b>${esc(x.title)}</b>${x.body ? `<small>${esc(x.body)}</small>` : ''}<small class="muted">${ago(x.at)}</small></span></button>`).join('') || '<div class="empty small">لا إشعارات بعد</div>'}</div>`;
    const all = panel.querySelector('[data-all]');
    if (all) all.onclick = async () => { await sb.rpc('notifications_read', { p_ids: null }); load(); };
    panel.querySelectorAll('[data-id]').forEach(b => b.onclick = async () => {
      const x = data.items.find(i => i.id === b.dataset.id);
      if (!x.read) { await sb.rpc('notifications_read', { p_ids: [x.id] }); load(); }
      go(x);
    });
  };
  const close = () => { panel && panel.remove(); panel = null; document.removeEventListener('click', outside, true); };
  const outside = e => { if (panel && !panel.contains(e.target) && !btn.contains(e.target)) close(); };
  btn.onclick = () => {
    if (panel) return close();
    panel = el('<div class="bell-pop"></div>'); document.body.appendChild(panel);
    const r = btn.getBoundingClientRect(); panel.style.top = `${r.bottom + 8 + scrollY}px`;
    draw(); setTimeout(() => document.addEventListener('click', outside, true));
  };
  load();
  sb.channel('alwah-notify').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, () => load()).subscribe();
  return { reload: load };
}
