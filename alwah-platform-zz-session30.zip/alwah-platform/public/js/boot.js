// ألواح — تشغيل البوابة: الدخول، التحقق من الدور، تحميل لوحة الجهة، التحديث اللحظي
import { PORTALS, ROLE_LABELS, esc, el, toast, cleanErr, setOtpClient } from './core.js';
import { loginShell, mountLogin } from './login-hero.js';

const CFG = window.ALWAH_CONFIG || {};
// «بوابة المقترض»: الرابط الجديد /borrower والقديم /citizen يفتحان البوابة نفسها
const seg = location.pathname.split('/')[1];
const portal = seg === 'borrower' ? 'citizen' : seg;
const P = PORTALS[portal];
const app = document.getElementById('app');
document.title = `ألواح — ${P?.title || 'البوابة'}`;

let sb;
try {
  const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm');
  // جلسة مستقلة لكل بوابة: يمكن فتح بوابة المقترض والمصرف في المتصفح نفسه معاً
  sb = createClient(CFG.url, CFG.key, { auth: { storageKey: `alwah-${portal}`, persistSession: true, autoRefreshToken: true } });
  setOtpClient(sb);   // الجلسة 23: نافذة رمز التحقق تطلب الرمز الحقيقي بهذا الاتصال
} catch (e) {
  console.error(e);
}

// وضع المطور (رمز التحقق الثابت) — يُقرأ من الخادم قبل الدخول
if (sb) {
  try { const { data } = await sb.rpc('public_config'); window.ALWAH_DEV = data || {}; } catch { window.ALWAH_DEV = {}; }
}

if (!P) location.replace('/');
else if (!sb) renderLogin('تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم أعد تحميل الصفحة.');
else {
  const { data: { session } } = await sb.auth.getSession();
  session ? start() : renderLogin();
}

function renderLogin(err = '') {
  app.innerHTML = '';
  if (portal === 'citizen' && sb) return renderCitizenLogin(err);
  const v = el(loginShell(P, portal, `<form autocomplete="on">
      <h2>تسجيل الدخول</h2><p class="sub">أدخل اسم المستخدم وكلمة المرور الخاصة بـ${esc(P.short)}</p>
      <div class="err ${err ? 'on' : ''}">${esc(err)}</div>
      <div class="field"><label for="u">اسم المستخدم</label><input class="input" id="u" name="username" autocomplete="username" dir="ltr" required></div>
      <div class="field"><label for="p">كلمة المرور</label><input class="input" id="p" name="password" type="password" autocomplete="current-password" dir="ltr" required></div>
      <button class="btn cyan block" type="submit">دخول</button>
    </form>`));
  app.appendChild(v);
  mountLogin(v, { sb, portal, P });
  const f = v.querySelector('form'), e = v.querySelector('.err');
  f.onsubmit = async ev => {
    ev.preventDefault();
    const btn = f.querySelector('button'); btn.disabled = true; btn.textContent = 'جارِ التحقق…'; e.classList.remove('on');
    const username = f.u.value.trim().toLowerCase();
    const email = username.includes('@') ? username : `${username}@alwah.demo`;
    const { error } = await sb.auth.signInWithPassword({ email, password: f.p.value });
    if (error) {
      e.textContent = /banned/i.test(error.message || '') ? 'هذا الحساب موقوف — راجع مشغّل النظام' : 'اسم المستخدم أو كلمة المرور غير صحيحة'; e.classList.add('on');
      btn.disabled = false; btn.textContent = 'دخول'; return;
    }
    start();
  };
}

async function renderCitizenLogin(err) {
  const { mountCitizenAuth } = await import('./auth-citizen.js');
  const v = el(loginShell(P, portal, ''));
  app.appendChild(v);
  mountLogin(v, { sb, portal, P });
  mountCitizenAuth(v.querySelector('.box'), { sb, err, onDone: o => { if (o?.fresh) location.hash = '#catalog'; start(); } });
}

async function start() {
  app.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  const { data: { user } } = await sb.auth.getUser();
  const { data: profile } = await sb.from('profiles').select('*').eq('id', user?.id).maybeSingle();
  if (!profile) { await sb.auth.signOut(); return renderLogin('الحساب غير مفعّل على المنصة'); }
  if (profile.disabled) { await sb.auth.signOut(); return renderLogin('هذا الحساب موقوف — راجع مشغّل النظام'); }
  if (profile.portal !== portal) {
    await sb.auth.signOut();
    return renderLogin(`هذا الحساب يخص «${PORTALS[profile.portal]?.title}» — استخدم رابط تلك البوابة`);
  }
  const [orgs, stages] = await Promise.all([
    sb.from('orgs').select('*').then(r => r.data || []),
    sb.from('stages').select('*').order('n').then(r => r.data || []),
  ]);
  const org = orgs.find(o => o.id === profile.org_id);

  app.innerHTML = '';
  const top = el(`<header class="topbar"><div class="in${portal !== 'citizen' ? ' tb-staff' : ''}">
    <a class="brand" href="/"><img src="/alwah-logo/alwah-icon-128.webp" alt=""><span><b>ألواح</b><small>ألواح الشمس</small></span></a>
    <span class="tb-ent" data-tbent hidden></span><span class="portal-name">${esc(P.short)}</span><span class="sp"></span>
    ${window.ALWAH_DEV?.dev_mode ? (window.ALWAH_DEV?.sms ? '<span class="devtag" title="الرسائل الحقيقية تعمل، والرمز 1234 مقبول أيضاً حتى يُطفأ وضع المطور">رسائل حقيقية + وضع المطور 1234</span>' : '<span class="devtag" title="رمز التحقق في كل الشاشات: 1234">وضع المطور · OTP 1234</span>') : ''}
    <span class="live" title="تحديث لحظي"><i class="dot"></i>مباشر</span>
    <${portal === 'citizen' ? 'a href="#profile" title="ملفي الشخصي"' : 'div'} class="who"><div class="meta" style="text-align:left"><div>${esc(profile.full_name)}</div><div class="org">${esc(org?.name || ROLE_LABELS[profile.role])}</div></div>
    <div class="av">${esc(profile.full_name.trim()[0])}</div></${portal === 'citizen' ? 'a' : 'div'}>
    ${portal !== 'citizen' ? `${profile.manage_scope ? '<a class="btn btn-dark sm" href="#team" title="إدارة موظفي نطاقك">فريقي</a>' : ''}<a class="btn btn-dark sm" href="#account" title="كلمة المرور والهاتف">حسابي</a>` : ''}
    <button class="btn btn-dark sm" data-out>خروج</button></div></header>`);
  const main = el('<main class="wrap"></main>');
  app.append(top, main);
  top.querySelector('[data-out]').onclick = async () => { await sb.auth.signOut(); location.reload(); };
  // الجلسة 27: شعار جهة المستخدم (مصرفه أو جهته القطاعية) إن رفعه مشغّل النظام
  if (portal !== 'citizen') sb.rpc('my_brand').then(({ data }) => { const t = top.querySelector('[data-tbent]'); if (data?.logo && t) { t.innerHTML = `<img src="${esc(data.logo)}" alt="">`; t.hidden = false; } }).catch(() => {});

  const ctx = { sb, profile, org, orgs, stages, root: main, portal, refresh: () => {} };
  // الجلسة 17: جرس الإشعارات لبوابات الموظفين
  if (portal !== 'citizen') import('./notify.js').then(m => { ctx.bell = m.mountBell(ctx, top.querySelector('[data-out]')); }).catch(e => console.error(e));
  // الجلسة 11: «حسابي» و«فريقي» لكل بوابات الموظفين، وإجبار تغيير كلمة المرور المؤقتة قبل أي عمل
  const team = portal !== 'citizen' ? await import('./team.js') : null;
  const view = () => (portal !== 'citizen' && ['#account', '#team'].includes(location.hash)) ? location.hash.slice(1) : 'portal';
  try {
    const mod = await import(`./portals/${portal}.js`);
    ctx.mod = mod;
    let busy = false;
    ctx.refresh = async () => {
      if (busy) return; busy = true;
      try {
        if (profile.must_change_password && team) team.renderForceChange(ctx, () => { location.hash = ''; ctx.refresh(); });
        else if (view() === 'account') await team.renderAccount(ctx);
        else if (view() === 'team' && profile.manage_scope) await team.renderTeam(ctx);
        else await mod.render(ctx);
      } catch (e) { console.error(e); toast(cleanErr(e), 'bad'); }
      busy = false;
    };
    if (team) window.addEventListener('hashchange', () => { if (['', '#', '#account', '#team'].includes(location.hash)) { window.scrollTo(0, 0); ctx.refresh(); } });
    await ctx.refresh();
  } catch (e) {
    console.error(e);
    main.innerHTML = `<div class="card empty">تعذّر تحميل اللوحة: ${esc(cleanErr(e))}</div>`;
  }

  // تحديث لحظي: أي تغيير لدى جهة أخرى يظهر هنا دون إعادة تحميل
  let t;
  const bump = () => { clearTimeout(t); t = setTimeout(() => {
    if (ctx.mod?.shouldRefresh && !ctx.mod.shouldRefresh(ctx)) return; if (profile.must_change_password || view() !== 'portal') return; if (!document.querySelector('.drawer')) ctx.refresh(); else ctx.pending = true; }, 400); };
  sb.channel('alwah-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'applications' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'mortgage_referrals' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'salary_referrals' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'expert_referrals' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'integrity_alerts' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bank_allocations' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'application_events' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'cbi_batches' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'vet_memberships' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'vet_projects' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'vet_tranches' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'initiatives' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'initiative_banks' }, bump)
    .subscribe();
  document.addEventListener('click', e => { if (ctx.pending && e.target.closest('[data-close],.drawer-bg')) { ctx.pending = false; setTimeout(ctx.refresh, 300); } });
}
