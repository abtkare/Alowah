// بوابة المقترض — طلبي، كتالوج المنظومات، تفاصيل المنظومة وتقييماتها، معالج طلب التمويل (المراحل 1–5)، الملف الشخصي
import { cameraCapture, docThumb } from '../capture.js';
import {
  esc, num, iqd, dt, ago, badge, statusBadge, stageBar, stageList, eventsList, GUARANTEE, ADVANCE_LABEL, rpc, toast, cleanErr,
  GOVS, govOptions, installment, maskPhone, maskId, stars, modal, askOtp, serverOtp, normPhone, validPhone, digits, el, PAY_METHODS, PAY_LABEL, VET_TYPES, isVet, what
} from '../core.js';
import { initVet, vetBanner, pageVetStart, homeDraftVet, vetTrackCard, pageApplyVet } from './vet.js';
import { PURPOSE, PURPOSE_HINT, viewDoc, purposeText, SITE_TYPE, PROJECT_KINDS } from '../core.js';
import { sitePicker, sitePayload, sitePanel } from '../site-ui.js';
import { fzPicker, fzLine, fzDialog } from '../fz-office.js';
import { loadIntake, checklistHtml, studiesHtml, refsHtml, pickFile } from '../intake-ui.js';
import { placePanel, shareLink, loadFix, mountBorrowerFix, scheduleAckHtml, bindScheduleAck, bankOpt } from '../journey22.js';
import { mountSmsBanner } from '../sms-ui.js';
import { MOT_DEPTS } from '../core.js';
import { wizHead, wireWizHead } from '../wizard-ui.js';
import { loadGuarantee, currentChecks, guaranteeOptions, kindOf, isSalaryG } from '../guarantee31.js';

const S = { ref: null };   // بيانات مرجعية تُحمَّل مرة واحدة
let C;                     // سياق البوابة

const route = () => { const [r, id] = location.hash.slice(1).split('/'); return { r: r || 'home', id }; };
// التحديث اللحظي يعيد رسم «طلبي» فقط، فلا تضيع مدخلات النماذج
export const shouldRefresh = () => route().r === 'home' || (route().r === 'apply' && !!C?.czVetWait);
// المصرف يعمل مع موردين معتمدين لديه (القائمة الفارغة = كل الموردين)
const accepts = (b, supplierId) => !b?.terms?.suppliers?.length || b.terms.suppliers.includes(supplierId);

export async function render(ctx) {
  C = ctx;
  if (!ctx.czInit) { ctx.czInit = true; window.addEventListener('hashchange', () => { window.scrollTo(0, 0); go(); }); }
  initVet({ S, C: () => C, load, saveStep, pageApply, step1, step4, cancelApp, accepts });
  await load();
  await go();
}

// ───────── البيانات ─────────
async function load(force) {
  const { sb } = C;
  if (!S.ref || force) {
    const [tiers, offers, terms, settings] = await Promise.all([
      sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
      sb.from('supplier_offers').select('*').eq('status', 'published').order('price').then(r => r.data || []),
      sb.from('bank_terms').select('*').then(r => r.data || []),
      sb.from('settings').select('*').then(r => r.data || []),
    ]);
    S.ref = { tiers, offers, terms, set: Object.fromEntries(settings.map(s => [s.key, Number(s.value)])) };
  }
  const [apps, reviews, me] = await Promise.all([
    sb.from('applications').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('offer_reviews').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('profiles').select('*').eq('id', C.profile.id).maybeSingle().then(r => r.data),
  ]);
  if (me) C.profile = me;
  S.apps = apps; S.reviews = reviews;
  const set = S.ref.set;
  const banks = C.orgs.filter(o => o.type === 'bank').map(b => ({ ...b, terms: S.ref.terms.find(t => t.bank_id === b.id), open: b.meta?.accepting !== false }));
  S.banks = banks;
  const bestRate = Math.min(...banks.filter(b => b.open && b.terms).map(b => b.terms.margin)) + set.cbi_rate;
  S.offers = S.ref.offers.map(o => {
    const tier = S.ref.tiers.find(t => t.id === o.tier_id), sup = C.orgs.find(x => x.id === o.supplier_id);
    const rs = reviews.filter(r => r.offer_id === o.id);
    const avg = k => rs.length ? rs.reduce((s, r) => s + (r[k] || 0), 0) / rs.length : 0;
    const dist = [5, 4, 3, 2, 1].map(n => rs.filter(r => r.rating === n).length);
    return { ...o, tier, kw: Number(tier?.kw), sup, rs, rating: avg('rating'), q: avg('quality'), ins: avg('install'), srv: avg('service'), dist,
      from: installment(o.price, bestRate, Math.min(84, set.term_max_months || 84)), panels: o.components?.find(c => c.item === 'ألواح')?.qty };
  });
  // شارات: الأقل سعراً والأعلى تقييماً في كل فئة
  S.ref.tiers.forEach(t => {
    const os = S.offers.filter(o => o.tier_id === t.id); if (!os.length) return;
    os.reduce((a, b) => a.price <= b.price ? a : b).cheap = true;
    os.reduce((a, b) => a.rating >= b.rating ? a : b).top = true;
  });
  S.active = apps.find(a => ['active', 'returned'].includes(a.status));
}
const offerById = id => S.offers.find(o => o.id === id);
const guaranteeFor = price => price <= S.ref.set.guarantee_t1 ? 'single_salary' : price <= S.ref.set.guarantee_t2 ? 'multi_salary' : 'mortgage';
const G_HINT = { single_salary: 'كفيل واحد موظف', multi_salary: 'كفيلان موظفان', mortgage: 'رهن عقار' };

// ───────── الهيكل والتنقل ─────────
async function go() {
  const { r, id } = route();
  const { root } = C;
  if (!root.querySelector('.cz-shell')) {
    // الجلسة 34: شريط سفلي أوضح — أيقونات مرسومة، أسماء قصيرة، مساحة لمس كبيرة
    const ic = d => `<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
    root.innerHTML = `<div class="cz-shell"><nav class="cz-nav" aria-label="أقسام بوابة المقترض">
      <a href="#home" data-n="home">${ic('<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5"/><path d="M9 13l2 2 4-4"/>')}<span>طلبي</span></a>
      <a href="#catalog" data-n="catalog">${ic('<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M3 10h18M9 4v12M15 4v12M8 20h8M12 16v4"/>')}<span>المنظومات</span></a>
      <a href="#vet" data-n="vet">${ic('<circle cx="5.5" cy="10" r="2"/><circle cx="9.5" cy="5.5" r="2"/><circle cx="14.5" cy="5.5" r="2"/><circle cx="18.5" cy="10" r="2"/><path d="M12 11c-2.6 0-5 3.2-5 5.6 0 1.6 1.2 2.4 2.6 2.4 1 0 1.6-.5 2.4-.5s1.4.5 2.4.5c1.4 0 2.6-.8 2.6-2.4 0-2.4-2.4-5.6-5-5.6z"/>')}<span>البيطري</span></a>
      <a href="#profile" data-n="profile">${ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>')}<span>حسابي</span></a></nav><div id="cz"></div></div>`;
    // الجلسة 35: الضغط على القسم الحالي نفسه يعيد عرضه (لا يحدث «hashchange» حين يكون الرابط هو نفسه)
    root.querySelectorAll('.cz-nav a').forEach(a => a.addEventListener('click', e => {
      const cur = location.hash || '#home';
      if (a.getAttribute('href') === cur) { e.preventDefault(); window.scrollTo(0, 0); go(); }
    }));
  }
  // الجلسة 34: وضع التركيز أثناء تعبئة الطلب — يختفي الشريط السفلي في الهاتف ويظهر زر «التالي» ثابتاً أسفل الشاشة
  root.querySelector('.cz-shell').classList.toggle('cz-focus', r === 'start' || r === 'apply');
  const navKey = { offer: 'catalog', apply: 'home', start: 'home' }[r] || r;
  root.querySelectorAll('.cz-nav a').forEach(a => { const on = a.dataset.n === navKey; a.classList.toggle('on', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
  // الجلسة 35: كل عرض لصفحة له حاوية خاصة ورقم تسلسل — العرض الأقدم (مثل تحديث لحظي لـ«طلبي» بدأ قبل الضغط على «البيطري»)
  // لا يكتب فوق الصفحة الجديدة. عند الانتقال لقسم آخر يظهر مؤشر التحميل فوراً؛ وعند تحديث القسم نفسه تبقى الصفحة حتى تجهز الجديدة.
  const seq = ++navSeq, host = root.querySelector('#cz'), key = `${r}/${id || ''}`, same = host.dataset.r === key;
  host.dataset.r = key;
  host.querySelectorAll(':scope > .cz-pg[hidden]').forEach(n => n.remove());
  const body = document.createElement('div'); body.className = 'cz-pg';
  if (same && host.firstElementChild) { body.hidden = true; host.append(body); }
  else { body.innerHTML = '<div class="cz-load" role="status" aria-live="polite"><div class="spin"></div><span>جارِ التحميل…</span></div>'; host.replaceChildren(body); }
  try {
    if (r === 'catalog') pageCatalog(body);
    else if (r === 'offer') pageOffer(body, id);
    else if (r === 'apply') await pageApply(body);
    else if (r === 'start') pageStart(body);
    else if (r === 'profile') pageProfile(body);
    else if (r === 'vet') await pageVetStart(body);
    else await pageHome(body);
  } catch (e) { console.error(e); body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
  if (seq !== navSeq || !body.isConnected) return;
  if (body.hidden) { [...host.children].forEach(n => n !== body && n.remove()); body.hidden = false; }
}
let navSeq = 0;
const refreshAll = async () => { await load(); await go(); };

// ───────── الرئيسية: طلبي ─────────
// الجلسة 21 (المقترح 3): ست محطات بلغة المقترض — مراحل الإجراء الداخلية تبقى كما هي لموظفي المصرف وتظهر للمقترض تحت «التفاصيل»
const STATIONS = [
  [6, 7, 'استلمنا طلبك وفتحنا حسابك', 'يدقق الفرع أوراقك ويفتح لك حساباً باسمك'],
  [8, 16, 'ندرس طلبك ونكشف على المكان', 'موافقة الفرع والكفالة، وزيارة لجنة إلى مكان المنظومة'],
  [17, 24, 'الموافقة النهائية', 'موافقة الإدارة واستكمال الضمان وتمويل المصرف'],
  [25, 29, 'وقّع عقدك من هاتفك', 'العقد والكمبيالة بتوقيع إلكتروني'],
  [30, 32, 'نركّب منظومتك', 'المورد يركّب، ولجنة المصرف تكشف على التركيب'],
  [33, 99, 'أقساطك', 'جدول أقساطك وبدء السداد'],
];
// المطلوب من المقترض في كل مرحلة: [النص، الزر (اختياري): [العنوان، ما يفعله]]
// غير المذكور = لا شيء مطلوب منه
const NOW = {
  6: ['أبقِ هاتفك قريباً — قد يتصل بك موظف المصرف للتأكد من بياناتك.'],
  7: ['أبقِ هاتفك قريباً — قد يتصل بك المصرف لإكمال فتح حسابك.'],
  9: ['يذهب كل كفيل إلى المصرف الذي يستلم فيه راتبه ويوقّع «تخويل الاستقطاع» (موافقته على أخذ القسط من راتبه إن لم تدفع).', null, g => isSalaryG(g)],
  14: ['ستزور لجنة من المصرف مكان المنظومة — تأكد أن أحداً هناك يستقبلها.'],
  19: ['قد يطلب منك الفرع الحضور لإكمال الضمان — سنخبرك هنا إن احتاجك.'],
  25: ['بقي توقيع عقد التمويل والكمبيالة.'],   // الجلسة 24: يُستبدل بـ signStep حسب حالة التوقيع
  31: ['سيتصل بك المورد لتحديد موعد التركيب — كن حاضراً في المكان.'],
  34: ['جدول أقساطك جاهز — راجعه ووقّع على استلامه في فرعك.', ['عرض جدول أقساطي', '[data-repay-box]']],
};
// الجلسة 24: «المطلوب منك الآن» في المحطة الرابعة حسب حالة توقيع العقد — جملة واضحة وزر يعمل مباشرة
const ASK_LINK = 'طلب المقترض رابط توقيع إلكتروني للعقد', ASK_BRANCH = 'أبلغ المقترض أنه سيوقّع العقد حضورياً في الفرع';
function signStep(app, es, events, branch) {
  const brName = branch?.name ? `فرع ${esc(branch.name.replace(/^فرع\s*/, ''))}` : 'فرعك';
  if (app.stage >= 26 || es?.status === 'completed') {
    const t = app.stage === 26 ? 'يدقق مدير الفرع عقدك الموقّع الآن.' : app.stage >= 27 ? 'يعتمد المصرف الآن تنفيذ تمويلك، ثم يطلب منظومتك من المورد.' : 'يدقق الفرع عقدك الموقّع، ثم يعتمد المصرف التنفيذ ويطلب منظومتك من المورد.';
    return { nowT: `<span class="ok-ic sm">✓</span> وقّعت عقدك — لا شيء مطلوب منك الآن. ${t} سنخبرك برسالة حين نحتاجك.`, nowB: null, nowK: 'dark', nowB2: null };
  }
  // آخر طلب أرسله المقترض للفرع بعد آخر طلب توقيع
  const since = es ? new Date(es.created_at) : 0;
  const ask = events.slice().reverse().find(e => [ASK_LINK, ASK_BRANCH].includes(e.action) && new Date(e.created_at) > since);
  const tel = branch?.complaint_phone ? [`اتصل بالفرع`, `tel:${branch.complaint_phone}`] : null;
  if (es?.status === 'sent') {
    if (ask?.action === ASK_BRANCH) return { nowT: `راجع ${brName} مع بطاقتك الوطنية الموحدة لتوقيع العقد والكمبيالة — أبلغنا الفرع ليجهّز عقدك.`, nowB: tel, nowK: 'warn', nowB2: ['غيّرت رأيي — أوقّع من هاتفي الآن', 'esign:sign'] };
  return { nowT: `عقدك جاهز — وقّعه من هاتفك الآن، يستغرق دقيقتين. <span class="small">(الرابط صالح حتى ${dt(es.expires_at)})</span>`, nowB: ['وقّع عقدك الآن', 'esign:sign'], nowK: 'warn', nowB2: ['لا أستطيع — سأوقّع في الفرع', 'esign:branch'] };
  }
  if ((es?.status === 'manual_review' && ask?.action !== ASK_LINK) || ask?.action === ASK_BRANCH)
    return { nowT: `راجع ${brName} مع بطاقتك الوطنية الموحدة لتوقيع العقد والكمبيالة — أبلغنا الفرع ليجهّز عقدك.`, nowB: tel, nowK: 'warn', nowB2: ['أريد التوقيع من هاتفي بدلاً من ذلك', 'esign:link'] };
  if (ask?.action === ASK_LINK)
    return { nowT: `<span class="ok-ic sm">✓</span> طلبت رابط التوقيع من ${brName} ${ago(ask.created_at)} — سيصلك برسالة ويظهر هنا زر «وقّع عقدك الآن». لا شيء آخر مطلوب منك.`, nowB: null, nowK: 'dark', nowB2: ['تأخّر؟ سأوقّع في الفرع', 'esign:branch'] };
  const why = { expired: 'انتهت صلاحية رابط التوقيع قبل أن توقّع.', cancelled: 'أُلغي رابط التوقيع السابق.', failed: 'تعذّر إتمام التوقيع السابق.' }[es?.status];
  return { nowT: why ? `${why} اطلب رابطاً جديداً بضغطة واحدة، أو وقّع في الفرع.` : 'صدرت الموافقة على تمويلك 🎉 بقي توقيع عقد التمويل والكمبيالة — اختر كيف توقّع:',
    nowB: [why ? 'اطلب رابط توقيع جديد' : 'أريد التوقيع من هاتفي', 'esign:link'], nowK: 'warn', nowB2: ['سأوقّع في الفرع', 'esign:branch'] };
}
async function pageHome(body) {
  const app = S.active || S.apps.find(a => a.status !== 'cancelled');
  const first = C.profile.full_name.split(' ')[0];
  if (!app || app.status === 'cancelled') return homeEmpty(body, first);
  if (['active', 'returned'].includes(app.status) && app.stage <= 5) return isVet(app) ? homeDraftVet(body, app, first) : homeDraft(body, app, first);
  const { sb, stages } = C;
  const cur = stages.find(s => s.n === app.stage);
  const days = Math.max(0, Math.round((Date.now() - new Date(app.updated_at)) / 864e5));
  const [events, branch, pays, fixes, esg, gs, clk] = await Promise.all([
    sb.from('application_events').select('*').eq('application_id', app.id).order('id').then(r => r.data || []),
    app.branch_id ? sb.from('branches').select('*').eq('id', app.branch_id).maybeSingle().then(r => r.data) : null,
    sb.from('payments').select('*').eq('application_id', app.id).eq('status', 'paid').then(r => r.data || []),
    isVet(app) ? [] : loadFix(sb, app.id).catch(() => []),
    app.stage >= 25 && app.stage <= 29 ? rpc(sb, 'esign_status', { p_app: app.id }).catch(() => null) : null,
    !isVet(app) && app.stage <= 19 && (isSalaryG(app.guarantee_type) || app.guarantee_type === 'gold') ? loadGuarantee(sb, app) : null,
    app.stage >= 6 && app.stage <= 19 && ['active', 'returned'].includes(app.status) ? rpc(sb, 'app_clock', { p_app: app.id }).catch(() => null) : null,
  ]);

  const o = offerById(app.offer_id), bank = C.orgs.find(x => x.id === app.bank_id);
  const openFix = fixes.filter(r => r.status === 'open'), ackHtml = isVet(app) ? '' : scheduleAckHtml(app, bank);
  const lastNote = events.slice().reverse().find(e => e.note && ['إعادة للاستكمال', 'رفض مسبب'].includes(e.action));
  const canReview = !isVet(app) && (app.status === 'completed' || app.stage >= 32) && !S.reviews.some(r => r.application_id === app.id);
  const vetCard = isVet(app) ? await vetTrackCard(app) : '';
  const done = app.status === 'completed', live = ['active', 'returned'].includes(app.status);
  // الجلسة 24: حالة توقيع العقد تحدد المطلوب من المقترض في المحطة الرابعة
  const es = esg?.request && esg.request.status !== 'superseded' ? esg.request : null;
  const signed = app.stage >= 26 || es?.status === 'completed';
  let J = isVet(app) ? STATIONS.map(j => j[0] === 30 ? [30, 32, 'نورّد أجهزتك ونركّبها', 'دفعات المورد، وإجازة دائرة البيطرة'] : j) : STATIONS;
  if (signed) J = J.map(j => j[0] === 25 ? [25, 29, 'وقّعت عقدك ✓', 'يدقق الفرع العقد، ثم يعتمد المصرف تنفيذ تمويلك'] : j);
  const si = done ? J.length - 1 : Math.max(0, J.findIndex(([a, z]) => app.stage >= a && app.stage <= z));
  // المدة المتبقية التقديرية: مجموع المدد المسموحة للمراحل الباقية (أيام عمل ≈ ×1.4 أيام تقويمية)
  const left = n => stages.filter(s => s.n >= app.stage && s.n <= n).reduce((t, s) => t + Number(s.sla_days || 0), 0);
  const eta = n => { const d = new Date(Date.now() + left(n) * 1.4 * 864e5); return d.toLocaleDateString('ar-IQ-u-nu-latn', { day: 'numeric', month: 'long' }); };
  const pay = pays.find(x => x.bank_id === app.bank_id) || pays[0];
  const needSite = !isVet(app) && !app.site_geo && app.stage > 5 && app.stage <= 30 && live;
  // بطاقة «المطلوب منك الآن»: جملة واحدة وزر واحد على الأكثر
  let nowT, nowB = null, nowK = 'dark', nowB2 = null;
  const gRows = gs ? currentChecks(app, gs) : [], gRej = gRows.filter(x => x.ck?.status === 'rejected'), gPend = gRows.filter(x => x.ck?.status === 'pending');
  if (app.status === 'rejected') { nowT = `رُفض طلبك: ${esc(lastNote?.note || 'راجع فرعك لمعرفة السبب')}`; nowK = 'bad'; }
  else if (openFix.length && live) {
    const n = openFix.reduce((t, r) => t + r.items.filter(i => !i.done).length, 0);
    nowT = `المصرف يطلب منك ${n === 1 ? 'شيئاً واحداً' : `<span class="num">${n}</span> أشياء`} — أصلحها من هاتفك الآن.`; nowB = ['أصلح النواقص', '[data-fixbox]']; nowK = 'warn';
  } else if (live && gRej.length) {
    // الجلسة 31: رفضت وزارة التجارة الكفيل — يعيد المصرف الطلب ليختار المقترض ضماناً آخر
    nowT = `رفضت وزارة التجارة كفالة <b>${esc(gRej.map(x => x.g.name).join('، '))}</b>: ${esc(gRej.flatMap(x => x.ck.reasons || []).join('، '))}.<br>سيعيد إليك المصرف طلبك لتختار <b>كفيلاً آخر أو رهن ذهب أو عقار</b> — يظهر لك هنا زر واحد لذلك، دون مراجعة الفرع.`; nowK = 'bad';
  } else if (live && gPend.length && app.stage <= 9) {
    nowT = `بانتظار تأييد وزارة التجارة لراتب كفيلك <b>${esc(gPend.map(x => x.g.name).join('، '))}</b> — لا شيء مطلوب منك الآن. سنخبرك هنا فور صدور القرار.`;
  } else if (live && app.guarantee_type === 'gold' && !app.guarantee?.custody && app.stage <= 19) {
    nowT = `خذ ذهبك (<span class="num">${num(app.guarantee?.grams)}</span> غرام عيار <span class="num">${esc(app.guarantee?.karat || '')}</span>) إلى ${esc(branch?.name || 'فرعك')} ليُوزن ويُقيَّم ويُعطيك وصلاً باستلامه.`; nowK = 'warn';
    if (branch?.complaint_phone) nowB = ['اتصل بالفرع', `tel:${branch.complaint_phone}`];
  } else if (app.status === 'returned') {
    // إرجاع داخلي بين موظفي المصرف — ما يحتاجه المصرف من المقترض يصله «طلب نواقص» يصلحه من هاتفه
    nowT = 'يُكمل المصرف نقصاً داخلياً في معاملتك — لا شيء مطلوب منك الآن. إن احتاج شيئاً منك يظهر هنا مع زر لإصلاحه.';
  } else if (ackHtml) { nowT = 'جدول أقساطك جاهز — راجعه ووقّع على استلامه من هاتفك، دون زيارة الفرع.'; nowB = ['استلم جدول أقساطي', '[data-ackbox]']; nowK = 'warn'; }
  else if (needSite) { nowT = 'حدّد مكان المنظومة — من هاتفك وأنت هناك، أو برابط ترسله لشخص هناك. يحتاجه المصرف لزيارة المكان.'; nowB = ['حدّد المكان الآن', '[data-sitelate]']; nowK = 'warn'; }
  else if (done || app.stage >= 35) { nowT = 'ادفع قسطك الشهري في موعده.'; nowB = ['جدول أقساطي', '[data-repay-box]']; }
  else {
    const n = NOW[app.stage];
    if (n && (!n[2] || n[2](app.guarantee_type))) { nowT = esc(n[0]); nowB = n[1] || null; nowK = n[1] ? 'warn' : 'dark'; }
    else nowT = 'لا شيء — نعمل على طلبك، وسنخبرك هنا حين نحتاجك.';
    if (app.stage >= 25 && app.stage <= 29) ({ nowT, nowB, nowK, nowB2 } = signStep(app, es, events, branch));
    if (app.stage === 14 && app.site_geo?.source === 'manual' && !app.site_geo.confirmed_at) nowT = 'ستزور لجنة من المصرف مكان المنظومة وتتأكد من المكان الذي حددته على الخريطة — تأكد أن أحداً هناك يستقبلها.';
  }
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>طلب رقم <b class="num">${esc(app.code)}</b> ${statusBadge(app.status)}</p></div></div>
    ${canReview ? `<div class="card mb rate-cta"><div><h3>رُكّبت منظومتك — كيف كانت التجربة؟</h3><p class="muted small">تقييمك يساعد غيرك على الاختيار.</p></div><span class="sp"></span><button class="btn warn" data-rate>قيّم المنظومة</button></div>` : ''}
    <div class="card mb now-card ${nowK}">
      <div class="now-h">المطلوب منك الآن</div>
      <p class="now-t">${nowT}</p>
      ${nowB ? (nowB[1].startsWith('tel:') ? `<a class="btn cyan big-btn" href="${esc(nowB[1])}">${esc(nowB[0])} <span class="num">${esc(nowB[1].slice(4))}</span></a>` : `<button type="button" class="btn cyan big-btn" data-now="${esc(nowB[1])}">${esc(nowB[0])}</button>`) : ''}
      ${nowB2 ? `<div class="now-alt"><button type="button" class="linkbtn" data-now="${esc(nowB2[1])}">${esc(nowB2[0])}</button></div>` : ''}
    </div>
    ${clk ? `<div class="notice ${clk.left < 0 ? 'bad' : 'info'} mb"><span>⏱</span><span>${clk.left >= 0 ? `المصرف ملزم بإنهاء إجراءاته حتى الضمان النهائي خلال <b class="num">${clk.budget}</b> يوم دوام — مضى <b class="num">${clk.used}</b> وبقي <b class="num">${clk.left}</b>.` : `تجاوز المصرف المدة المسموحة بـ <b class="num">${-clk.left}</b> يوم دوام — صُعِّد التأخير آلياً.`} <span class="small">لن يُرفض طلبك بسبب تأخير لم تتسبب فيه، وكل تأخير يُسجَّل على الموظف المسؤول.</span></span></div>` : ''}
    <div class="card mb"><h3>أين وصل طلبك${live && app.stage < 31 ? `<span class="sp"></span><span class="small muted">التركيب المتوقع نحو <b>${eta(31)}</b></span>` : ''}</h3>
      <ol class="journey">${J.map(([a, z, t, d], i) => { const st = done || i < si ? 'done' : i === si ? (app.status === 'rejected' ? 'bad' : app.status === 'returned' ? 'ret' : 'cur') : '';
        return `<li class="${st}"><span class="n">${st === 'done' ? '✓' : st === 'bad' ? '✕' : i + 1}</span><div><b>${t}</b><small>${d}</small></div></li>`; }).join('')}</ol>
    </div>
    <div data-fixbox></div>
    ${ackHtml}
    ${needSite ? '<div data-sitelate></div>' : ''}
    ${app.stage >= 25 ? '<div data-esign-box></div>' : ''}
    ${!isVet(app) && (app.stage >= 34 || app.status === 'completed') ? '<div data-repay-box></div>' : ''}
    ${!isVet(app) && app.purpose && app.purpose !== 'household' ? '<div data-xbox></div>' : ''}
    <details class="card mb home-det"><summary><b>التفاصيل</b> <span class="small muted">— المرحلة الداخلية، حسابك، المبالغ، منظومتك، وكل ما حدث على طلبك</span></summary>
      <div class="mt">
        <dl class="kv"><dt>المرحلة الداخلية</dt><dd>${done ? 'اكتملت المعاملة' : `<span class="num">${app.stage}</span> من <span class="num">${stages.length}</span> — ${esc(cur?.name)}`}</dd>
          <dt>الطلب الآن لدى</dt><dd>${esc(done ? '—' : cur?.owner_label)}</dd><dt>في هذه المرحلة منذ</dt><dd><span class="num">${days}</span> يوم</dd></dl>
        ${stageBar(app, stages.length)}
        <div class="grid g2 mt">
          <div class="card"><h3>حسابك في المصرف</h3>${app.bank_account ? `<dl class="kv"><dt>المصرف</dt><dd>${esc(bank?.name || '—')}</dd>${branch ? `<dt>الفرع</dt><dd>${esc(branch.name)}</dd>` : ''}<dt>رقم الحساب</dt><dd><b class="num">${esc(app.bank_account)}</b></dd><dt>فُتح في</dt><dd>${dt(app.account_opened_at)}</dd>${branch?.complaint_phone ? `<dt>رقم الشكاوى</dt><dd><a class="num" href="tel:${esc(branch.complaint_phone)}">${esc(branch.complaint_phone)}</a></dd>` : ''}</dl>`
            : `<p class="muted" style="margin:0">${app.status === 'rejected' ? 'لم يُفتح حساب.' : `يفتح لك ${esc(bank?.name || 'المصرف')} حساباً باسمك بعد تدقيق أوراقك، ويظهر رقمه هنا.`}</p>`}</div>
          ${vetCard || `<div class="card">${o ? `<img class="mini-img" src="${esc(o.image_url)}" alt="" loading="lazy">` : ''}<h3>منظومتي</h3><dl class="kv"><dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> كيلوواط ${what('kw')}</dd><dt>المورد</dt><dd>${esc(C.orgs.find(x => x.id === app.supplier_id)?.name)}</dd>
            <dt>السعر</dt><dd>${iqd(app.price)}</dd>${app.cbi_fee ? `<dt>عمولة البنك المركزي</dt><dd>${iqd(app.cbi_fee)} <span class="muted small">لمرة واحدة</span></dd>` : ''}<dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])}</dd>
            <dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd><dt>عدد الأقساط</dt><dd><span class="num">${app.term_months}</span> شهراً</dd></dl>
            ${o ? `<a class="btn ghost sm mt" href="#offer/${o.id}">تفاصيل المنظومة</a>` : ''}</div>`}
        </div>
        ${pay ? `<div class="card mt"><h3>ما دفعته عند التقديم</h3><dl class="kv">${(pay.items || []).map(i => `<dt>${esc(i.label)}</dt><dd>${iqd(i.amount)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(pay.amount)}</b></dd></dl>
          <div class="row small mt"><span class="muted">رقم العملية <b class="num">${esc(pay.ref)}</b></span><span class="sp"></span><button class="linkbtn" data-rcpt>الإيصال</button></div></div>` : ''}
        <details class="mt"><summary class="small">كل مراحل الإجراء الداخلية (<span class="num">${stages.length}</span>)</summary>${stageList(app, stages)}</details>
        <h3 class="mt">كل ما حدث على طلبي</h3>${eventsList(events)}
      </div>
    </details>
    ${pastApps(app.id)}`;
  body.querySelectorAll('[data-now]').forEach(nb => nb.onclick = async () => {
    const k = nb.dataset.now;
    if (k.startsWith('esign:')) {   // الجلسة 24: أزرار توقيع العقد تعمل مباشرة
      const { borrowerSign, borrowerAsk } = await import('../esign-ui.js');
      if (k === 'esign:sign') return borrowerSign(sb, app, nb);
      return borrowerAsk(sb, app, k.slice(6), nb, { branch, onDone: async () => { await load(); pageHome(body); } });
    }
    const t = body.querySelector(k); if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); t.querySelector('button')?.focus({ preventScroll: true }); }
  });
  const eb = body.querySelector('[data-esign-box]'); if (eb) import('../esign-ui.js').then(m => m.mountEsignBorrower(sb, app, eb, { branch, onDone: async () => { await load(); pageHome(body); } }));
  // الجلسة 19: طلب قديم وصل المصرف بلا عنوان GPS — يثبّته المقترض من هنا مرة واحدة
  const slb = body.querySelector('[data-sitelate]');
  if (slb) placePanel(slb, app, { sb, bank, late: true, accMax: S.ref?.set?.site_gps_accuracy_m || 100, onSaved: async () => { await load(); pageHome(body); } });
  // الجلسة 22: النواقص التي يصلحها من هاتفه، واستلام جدول الأقساط برمز تحقق (خيار المصرف)
  mountBorrowerFix(body.querySelector('[data-fixbox]'), fixes, { sb, onDone: () => pageHome(body) });
  mountSmsBanner(sb, C.profile, body);   // الجلسة 23
  bindScheduleAck(sb, app, C.profile, body, { onDone: async () => { await load(); pageHome(body); } });
  // الجلسة 18: جدول أقساطي
  const rpb = body.querySelector('[data-repay-box]'); if (rpb) import('../repay-ui.js').then(m => m.mountRepay({ sb }, app, rpb, { borrower: true }));
  // الجلسة 16: حالة دراسة الجدوى لدى الخبير المعتمد (دون اسم الخبير)
  const xb = body.querySelector('[data-xbox]');
  if (xb) loadIntake(sb, app).then(d => { if (!d) return;
    const fz = d.docs.filter(x => x.kind === 'feasibility');
    xb.innerHTML = `<div class="card mb"><h3>دراسة الجدوى <span class="sp"></span>${badge([`الغرض: ${PURPOSE[app.purpose]}`, 'info'])}${app.feasibility_rejections ? ' ' + badge(['مرفوض سابقاً بسبب دراسة الجدوى', 'bad']) : ''}</h3>
      <p class="small muted" style="margin:0 0 8px">${esc(({ none: 'وصلت دراستك إلى موظف الاستقبال — ستُحال إلى خبير معتمد', pending: 'أُحيلت دراستك إلى خبير معتمد — بانتظار استلامه', received: 'دراستك قيد الدراسة لدى الخبير المعتمد', conforming: 'قرار الخبير: مطابق ✓', non_conforming: 'قرار الخبير: غير مطابق', stale: 'وصلت دراستك المحدّثة — بانتظار إحالتها للخبير', no_study: 'لم تُرفق دراسة الجدوى' })[d.ck?.expert?.state] || '')} — يدرسها خبير معتمد مختص من خارج المصرف.</p>${fz.length ? studiesHtml(fz, d.refs) : ''}${refsHtml(d.refs, { named: false })}</div>`;
    xb.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.doc)); });
  const rb = body.querySelector('[data-rate]'); if (rb) rb.onclick = () => rateDialog(app);
  const rc = body.querySelector('[data-rcpt]'); if (rc) rc.onclick = () => receipt(app, pay);
}

function homeEmpty(body, first) {
  const top = S.offers.slice().sort((a, b) => b.rating - a.rating).slice(0, 3);
  const p = C.profile, dataOk = profileReady(p);
  const steps = [
    ['إنشاء الحساب', 'تم', true],
    ['بياناتك من البطاقة الوطنية', p.national_id ? 'مقروءة من البطاقة' : 'تُكمل في الخطوة الأولى', !!p.national_id],
    ['العنوان والعمل والدخل', dataOk ? 'مكتملة' : 'مطلوبة قبل البدء', dataOk],
    ['اختيار المصرف ثم المنظومة', 'المنظومات المعتمدة لدى المصرف فقط', false],
    ['دفع عمولة المصرف والرسوم', 'إلكترونياً قبل الإرسال', false],
    ['فتح حسابك في المصرف', 'يفتحه المصرف بعد استلام طلبك', false],
    ['متابعة معاملتك مرحلة بمرحلة', 'حتى تركيب المنظومة وجدول الأقساط', false]];
  body.innerHTML = `
    <section class="cz-hero">
      <div><span class="pill">ألواح · مستقبل التمويل في العراق</span><h1>أهلاً ${esc(first)} — تمويلك يبدأ من هاتفك، لا من طابور المصرف</h1>
        <p>اختر مصرفك وقارن عمولته، ثم اختر منظومتك من الموردين المعتمدين لديه، وادفع العمولة إلكترونياً، وتابع طلبك لحظة بلحظة — كل خطوة محفوظة لا تُعدَّل.</p>
        <div class="row"><a class="btn cyan" href="#start">ابدأ طلب تمويل منظومة شمسية</a><a class="btn btn-dark" href="#vet">تمويل مشروع بيطري</a><button class="btn ghost-l" data-help>ساعدني أختار القدرة</button></div></div>
      <ol class="how">${['أكمل بياناتك', 'اختر المصرف', 'اختر المنظومة المعتمدة لديه', 'ادفع العمولة ووقّع', 'تابع طلبك بعد فتح حسابك'].map((s, i) => `<li><i>${i + 1}</i>${s}</li>`).join('')}</ol>
    </section>
    <div class="card mb"><h3>رحلتك في ألواح<span class="sp"></span>${dataOk ? '' : '<a class="btn cyan sm" href="#start">أكمل بياناتك</a>'}</h3>
      <ol class="journey">${steps.map(([t, d, ok], i) => `<li class="${ok ? 'done' : i === steps.findIndex(x => !x[2]) ? 'cur' : ''}"><span class="n">${ok ? '✓' : i + 1}</span><div><b>${t}</b><small>${d}</small></div></li>`).join('')}</ol></div>
    ${vetBanner()}
    <div class="row" style="margin:6px 0 12px"><h2 style="font-size:19px">الأعلى تقييماً من المواطنين</h2><span class="sp"></span><a href="#catalog" class="small">كل المنظومات ←</a></div>
    <div class="offers">${top.map(offerCard).join('')}</div>
    ${pastApps()}`;
  body.querySelector('[data-help]').onclick = helpChoose;
  wireCards(body);
}
const profileReady = p => !!(p.governorate && p.employer && Number(p.monthly_salary) > 0);

function homeDraft(body, app, first) {
  if (app.return_kind === 'guarantee') return homeGuaranteeReturn(body, app, first);
  const o = offerById(app.offer_id);
  const ret = app.returned_from === 6, rej = ret && app.feasibility_rejections > 0 && (app.intake_missing || []).some(i => i.key === 'feasibility_update');
  const steps = ['التحقق من الهوية', 'رقم «أور»', 'تأكيد المصرف والمنظومة', 'الكفيل أو العقار', 'الدفع والإرسال'];
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>${ret ? 'أُعيد طلبك إليك — أكمل المطلوب وأعد إرساله بنفس رقمه.' : 'طلبك محفوظ — أكمل الخطوات المتبقية وأرسله للمصرف.'}</p></div></div>
    ${ret ? `<div class="ret-card">
      <h2>${rej ? 'رُفضت دراسة الجدوى — ارفع دراسة محدّثة' : 'أعاد المصرف طلبك — أكمل النواقص'}</h2>
      <p class="small muted" style="margin:0">${esc(app.returned_by_title || '')} · ${dt(app.returned_at)}</p>
      <p style="margin:10px 0 12px"><b>المطلوب منك:</b> اضغط كل سطر أحمر وأكمله من هاتفك، ثم اضغط «أعد إرسال الطلب». ${rej ? 'تُحفظ دراستك السابقة مع الحديثة.' : ''} يبقى رقم طلبك وبياناته كما هي.</p>
      <div data-retlist><div class="spin"></div></div>
    </div><div data-fixbox></div>` : ''}
    <div class="card mb draft">
      ${o ? `<img src="${esc(o.image_url)}" alt="" class="draft-img">` : ''}
      <div class="draft-b">
        <div class="row">${ret ? '<span class="badge warn"><i class="dot"></i>مُعاد للاستكمال</span>' : '<span class="badge info"><i class="dot"></i>مسودة</span>'}${app.feasibility_rejections ? badge(['مرفوض سابقاً بسبب دراسة الجدوى', 'bad']) : ''}<b class="num">${esc(app.code)}</b><span class="sp"></span><span class="small muted">بدأ ${ago(app.created_at)}</span></div>
        <h2 style="font-size:21px;margin:8px 0 2px">${esc(o?.title || '')}</h2>
        <div class="muted">${iqd(app.price)} · الضمان: ${esc(GUARANTEE[app.guarantee_type])}</div>
        <div class="prog"><i style="width:${(app.stage - 1) * 20}%"></i></div>
        <div class="small muted">أنجزت <b class="num">${app.stage - 1}</b> من 5 خطوات — التالية: <b style="color:var(--text)">${esc(steps[app.stage - 1])}</b></div>
        ${ret ? '<div class="row mt"><span class="sp"></span><button type="button" class="linkbtn muted-l" data-cancel>إلغاء الطلب</button></div>'
          : `<a class="btn cyan big-btn mt" href="#apply">أكمل طلبك — الخطوة <span class="num">${app.stage}</span> ←</a><div class="row" style="margin-top:8px"><span class="sp"></span><button type="button" class="linkbtn muted-l" data-cancel>إلغاء الطلب</button></div>`}
      </div>
    </div>
    ${ret ? "" : "<div data-fixbox></div>"}
    ${pastApps(app.id)}`;
  body.querySelector('[data-cancel]').onclick = () => cancelApp(app);
  mountSmsBanner(C.sb, C.profile, body);   // الجلسة 23: تفعيل الرسائل النصية
  // الجلسة 22 (المقترح 10): كل نقص في سطر، مع زر يصلحه من الهاتف — بدل «تواصل مع فرعك»
  if (ret) {
    const rl = body.querySelector('[data-retlist]');
    Promise.all([rpc(C.sb, 'intake_checklist', { p_app: app.id }).catch(() => null), loadFix(C.sb, app.id).catch(() => [])]).then(([ck, reqs]) => {
      const miss = (ck?.items || []).filter(i => !i.ok && !['payment', 'signed'].includes(i.key) && i.fix !== 'req');
      const note = (app.intake_missing || []).find(i => i.key === 'note');
      const openReq = reqs.some(r => r.status === 'open');
      rl.innerHTML = `${note ? `<div class="fix-note"><span>✎</span><span>${esc(note.label)}<small>ملاحظة موظف المصرف</small></span></div>` : ''}
        ${miss.length ? `<div class="fix-rows">${miss.map(i => fixRow(i.label, i.fix, i.key)).join('')}</div>` : ''}
        ${openReq ? '<p class="small" style="margin:10px 0 0">↓ وطلب المصرف منك أيضاً بنوداً في البطاقة أدناه.</p>' : ''}
        ${!miss.length && !openReq ? '<div class="notice ok-n" style="margin:0 0 10px"><span>✓</span><span>أكملت كل النواقص — بقي أن تعيد إرسال الطلب.</span></div><button type="button" class="btn cyan big-btn" data-fix="5">أعد إرسال الطلب ←</button>'
          : `<button type="button" class="btn cyan big-btn mt is-off" data-wait>أعد إرسال الطلب — بعد إكمال ${miss.length ? 'الأسطر الحمراء' : 'البنود'}</button>`}`;
      rl.querySelectorAll('[data-fix]').forEach(b => b.onclick = () => fixGo(b.dataset.fix, b.dataset.key));
      const w = rl.querySelector('[data-wait]'); if (w) w.onclick = () => toast('أكمل الأسطر ذات النجمة ★ أولاً — اضغط كل سطر', 'bad');
      mountBorrowerFix(body.querySelector('[data-fixbox]'), reqs, { sb: C.sb, onDone: () => homeDraft(body, app, first) });
    });
  }
}

function pastApps(exceptId) {
  const list = S.apps.filter(a => a.id !== exceptId);
  if (!list.length) return '';
  return `<div class="card mt"><h3>طلباتي السابقة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المبلغ</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>
    ${list.map(a => `<tr><td><b class="num">${esc(a.code)}</b></td><td>${isVet(a) ? 'مشروع بيطري' : `<span class="num">${num(a.kw)}</span> kW`}</td><td>${iqd(a.amount)}</td><td>${statusBadge(a.status)}</td><td class="small muted">${dt(a.created_at)}</td></tr>`).join('')}</tbody></table></div></div>`;
}

async function cancelApp(app) {
  const m = modal(`<h3>إلغاء الطلب ${esc(app.code)}</h3><p class="muted">يمكنك تقديم طلب جديد بعد الإلغاء. هذا الإجراء يُسجَّل في سجل التدقيق.</p>
    <div class="field"><label>سبب الإلغاء (اختياري)</label><select class="input" data-r><option>أريد اختيار منظومة أخرى</option><option>غيّرت رأيي</option><option>لا أملك ضماناً مناسباً</option><option>سبب آخر</option></select></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-no>تراجع</button><button class="btn bad" data-yes>إلغاء الطلب</button></div>`);
  m.el.querySelector('[data-no]').onclick = m.close;
  m.el.querySelector('[data-yes]').onclick = async () => {
    try { await rpc(C.sb, 'cancel_my_application', { p_app: app.id, p_reason: m.el.querySelector('[data-r]').value }); m.close(); toast('أُلغي الطلب', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الكتالوج ─────────
function offerCard(o) {
  const g = guaranteeFor(o.price);
  return `<article class="ocard" data-id="${o.id}">
    <div class="media" data-play="${o.id}" role="button" tabindex="0" aria-label="تشغيل فيديو شرح المنظومة">
      <img src="${esc(o.image_url)}" alt="منظومة ${num(o.kw)} kW من ${esc(o.sup?.name)}" loading="lazy">
      <span class="play"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></span>
      <span class="dur">فيديو 0:40</span>
      <div class="flags">${o.cheap ? '<span class="badge ok">الأقل سعراً</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
    </div>
    <div class="ob">
      <div class="row" style="gap:6px"><span class="kw num">${num(o.kw)} kW</span><span class="muted small">${esc(o.sup?.name)}</span></div>
      <div class="row" style="gap:6px">${stars(o.rating)}<b class="num small">${o.rating.toFixed(1)}</b><span class="muted small">(<span class="num">${o.rs.length}</span> تقييم)</span></div>
      <div class="price">${iqd(o.price)}</div>
      <div class="small muted">قسط يبدأ من <b style="color:var(--text)">${iqd(o.from)}</b> شهرياً</div>
      <div class="chips"><span><b class="num">${num(o.panels)}</b> لوح</span><span>بطاريات <b class="num">${num(o.battery_kwh)}</b> kWh</span><span>~<b class="num">${num(o.tier?.daily_kwh)}</b> kWh/يوم</span></div>
      <div class="small">الضمان المطلوب: <b>${G_HINT[g]}</b></div>
      <div class="row mt" style="gap:8px"><a class="btn ghost sm" href="#offer/${o.id}">التفاصيل والتقييمات</a><span class="sp"></span><button class="btn cyan sm" data-apply="${o.id}">اطلب التمويل</button></div>
    </div></article>`;
}
function wireCards(root) {
  root.querySelectorAll('[data-play]').forEach(m => { m.onclick = () => playVideo(offerById(m.dataset.play)); m.onkeydown = e => { if (e.key === 'Enter') m.click(); }; });
  root.querySelectorAll('[data-apply]').forEach(b => b.onclick = () => startFlow(offerById(b.dataset.apply)));
}
function playVideo(o) {
  const m = modal(`<div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls autoplay playsinline preload="metadata"></video></div>
    <div class="row mt"><div><b>${esc(o.title)}</b><div class="small muted">فيديو شرح المنظومة · أقل من دقيقة</div></div><span class="sp"></span><a class="btn ghost sm" href="#offer/${o.id}" data-x>التفاصيل</a><button class="btn cyan sm" data-a>اطلب التمويل</button></div>`, { wide: true });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-a]').onclick = () => { m.close(); startFlow(o); };
}

function pageCatalog(body) {
  C.czCat = C.czCat || { kw: 'all', sort: 'price' };
  const st = C.czCat;
  body.innerHTML = `
    <div class="page-head"><div><h1>كتالوج المنظومات</h1><p>كل عرض بصورته وفيديو شرح قصير وتقييمات المواطنين الذين ركّبوه فعلاً.</p></div><span class="sp"></span><button class="btn ghost" data-help>ساعدني أختار القدرة</button></div>
    <div class="filters">
      <div class="seg sm">${[['all', 'الكل'], ...S.ref.tiers.map(t => [String(Number(t.kw)), `${num(t.kw)} kW`])].map(([k, l]) => `<button class="${st.kw === k ? 'on' : ''}" data-kw="${k}">${l}</button>`).join('')}</div>
      <span class="sp"></span>
      <label class="small muted" for="srt">الترتيب</label>
      <select class="input sm" id="srt"><option value="price">الأقل سعراً</option><option value="rating">الأعلى تقييماً</option><option value="speed">الأسرع تركيباً</option><option value="reviews">الأكثر تقييماً</option></select>
    </div>
    <div data-tier></div>
    <div class="offers" data-list></div>
    <p class="small muted mt">الأسعار تشمل النقل والتركيب والهيكل. القسط التقديري بأقل هامش متاح ولأطول مدة؛ القسط النهائي يحدده المصرف الذي تختاره. التقييمات في نسخة العرض تجريبية.</p>`;
  const sel = body.querySelector('#srt'); sel.value = st.sort;
  sel.onchange = () => { st.sort = sel.value; paint(); };
  body.querySelectorAll('[data-kw]').forEach(b => b.onclick = () => { st.kw = b.dataset.kw; body.querySelectorAll('[data-kw]').forEach(x => x.classList.toggle('on', x === b)); paint(); });
  body.querySelector('[data-help]').onclick = helpChoose;
  paint();
  function paint() {
    let list = S.offers.filter(o => st.kw === 'all' || String(o.kw) === st.kw);
    const key = { price: (a, b) => a.price - b.price, rating: (a, b) => b.rating - a.rating, speed: (a, b) => (a.sup?.meta?.avg_days || 99) - (b.sup?.meta?.avg_days || 99), reviews: (a, b) => b.rs.length - a.rs.length }[st.sort];
    list.sort((a, b) => key(a, b) || a.kw - b.kw);
    const t = st.kw !== 'all' && S.ref.tiers.find(x => String(Number(x.kw)) === st.kw);
    body.querySelector('[data-tier]').innerHTML = t ? `<div class="notice dark tier-note"><b class="num">${num(t.kw)} kW</b> — إنتاج يومي ~<b class="num">${num(t.daily_kwh)}</b> kWh · تشغّل: ${esc(t.loads)} · سقف السعر ${iqd(t.price_cap)} · الضمان: <b>${G_HINT[guaranteeFor(t.price_cap)]}</b> أو حسب السعر</div>` : '';
    const L = body.querySelector('[data-list]'); L.innerHTML = list.map(offerCard).join('') || '<div class="card empty">لا عروض</div>';
    wireCards(L);
  }
}

function helpChoose() {
  const items = [['ac', 'مكيف 1.5 طن', 9.6, 0], ['cooler', 'مبردة هواء', 2.5, 1], ['fridge', 'ثلاجة', 1.6, 1], ['freezer', 'مجمدة', 1.4, 0], ['washer', 'غسالة', 0.8, 1], ['pump', 'مضخة ماء', 1.5, 0]];
  const m = modal(`<h3>ما الأجهزة التي تريد تشغيلها؟</h3><p class="muted small">نحسب الاستهلاك اليومي ونقترح أصغر قدرة تكفيه (الإنارة والتلفاز والشحن محسوبة دائماً).</p>
    <div class="counters">${items.map(([k, l, , d]) => `<div class="ctr"><span>${l}</span><span class="sp"></span><button type="button" data-d="${k}">−</button><b class="num" data-v="${k}">${d}</b><button type="button" data-i="${k}">+</button></div>`).join('')}</div>
    <div class="card mt" style="background:var(--surface-2);box-shadow:none" data-res></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>اعرض المنظومات المناسبة</button></div>`);
  const v = Object.fromEntries(items.map(i => [i[0], i[3]]));
  let pick;
  const calc = () => {
    const need = 2.5 + items.reduce((s, [k, , kwh]) => s + v[k] * kwh, 0);
    pick = S.ref.tiers.find(t => Number(t.daily_kwh) >= need * 1.1) || S.ref.tiers[S.ref.tiers.length - 1];
    m.el.querySelector('[data-res]').innerHTML = `استهلاكك اليومي التقديري <b class="num">${need.toFixed(1)}</b> kWh — القدرة المقترحة: <b class="num" style="color:var(--indigo);font-size:20px">${num(pick.kw)} kW</b> (إنتاج ~<span class="num">${num(pick.daily_kwh)}</span> kWh)`;
  };
  m.el.querySelectorAll('[data-i],[data-d]').forEach(b => b.onclick = () => { const k = b.dataset.i || b.dataset.d; v[k] = Math.max(0, Math.min(6, v[k] + (b.dataset.i ? 1 : -1))); m.el.querySelector(`[data-v="${k}"]`).textContent = v[k]; calc(); });
  calc();
  m.el.querySelector('[data-go]').onclick = () => { C.czCat = { ...(C.czCat || { sort: 'price' }), kw: String(Number(pick.kw)) }; m.close(); if (route().r === 'catalog') go(); else location.hash = '#catalog'; };
}

// ───────── تفاصيل المنظومة ─────────
function pageOffer(body, id) {
  const o = offerById(id);
  if (!o) { body.innerHTML = '<div class="card empty">العرض غير موجود. <a href="#catalog">العودة للكتالوج</a></div>'; return; }
  const set = S.ref.set, g = guaranteeFor(o.price), meta = o.sup?.meta || {};
  const siblings = S.offers.filter(x => x.tier_id === o.tier_id).sort((a, b) => a.price - b.price);
  body.innerHTML = `
    <a href="#catalog" class="back">→ العودة للكتالوج</a>
    <div class="od">
      <div class="od-media card flush">
        <div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls playsinline preload="none"></video></div>
        <div class="od-thumbs"><span>فيديو شرح المنظومة · <span class="num">0:40</span></span><span class="sp"></span><a href="${esc(o.image_url)}" target="_blank" rel="noopener" class="small">فتح الصورة</a></div>
      </div>
      <div class="od-sum card">
        <div class="row"><span class="kw num">${num(o.kw)} kW</span>${o.cheap ? '<span class="badge ok">الأقل سعراً في فئته</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
        <h1 style="font-size:24px;margin:8px 0 2px">منظومة هجينة <span class="num">${num(o.kw)} kW</span> ${what('kw')}</h1>
        <div class="muted">${esc(o.sup?.name)}</div>
        <a href="#rv" class="row" style="gap:6px;margin-top:6px;color:inherit">${stars(o.rating, 18)}<b class="num">${o.rating.toFixed(1)}</b><span class="muted small">من <span class="num">${o.rs.length}</span> مواطن ركّبها</span></a>
        <div class="price big">${iqd(o.price)}</div>
        <div class="small muted">يشمل النقل والتركيب والهيكل المجلفن · سقف الفئة ${iqd(o.tier?.price_cap)}</div>
        <dl class="kv mt"><dt>الإنتاج اليومي</dt><dd>~<span class="num">${num(o.tier?.daily_kwh)}</span> kWh</dd><dt>تشغّل</dt><dd>${esc(o.tier?.loads)}</dd>
          <dt>البطاريات</dt><dd><span class="num">${num(o.battery_kwh)}</span> kWh</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[g]}</dd></dl>
        <div class="row mt"><button class="btn cyan" data-apply="${o.id}" style="flex:1">اطلب تمويل هذه المنظومة</button></div>
      </div>
    </div>
    <div class="grid g-side mt">
      <div>
        <div class="card mb"><h3>المكونات</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المكوّن</th><th>العلامة</th><th>الطراز</th><th>العدد</th></tr></thead><tbody>
          ${(o.components || []).map(c => `<tr><td>${esc(c.item)}</td><td><span class="num">${esc(c.brand)}</span></td><td><span class="num">${esc(c.model)}</span></td><td class="num">${num(c.qty)}</td></tr>`).join('')}</tbody></table></div>
          <p class="small muted" style="margin:10px 0 0">${esc(o.description || '')}</p></div>
        <div class="card mb"><h3>الضمان والصيانة</h3><ul class="ticks">${(o.warranty || '').split('،').map(w => `<li>${esc(w.trim())}</li>`).join('')}</ul></div>
        <div class="card mb" id="calc"></div>
        <div class="card" id="rv"></div>
      </div>
      <div>
        <div class="card mb"><h3>عن المورد</h3><b>${esc(o.sup?.name)}</b>
          <div class="grid g2 mt" style="gap:10px">
            <div class="stat"><b class="num">${num(meta.installs)}</b><span>منظومة مركّبة</span></div>
            <div class="stat"><b class="num">${num(meta.avg_days)}</b><span>يوماً متوسط التركيب</span></div>
            <div class="stat"><b class="num">${num(meta.match_rate)}%</b><span>مطابقة التدقيق الهندسي</span></div>
            <div class="stat"><b>${meta.legacy ? 'مسجّل' : 'جديد'}</b><span>${meta.legacy ? 'منذ المرحلة الأولى' : 'في المبادرة'}</span></div>
          </div></div>
        <div class="card"><h3>عروض أخرى بنفس القدرة</h3>
          ${siblings.map(s => `<a class="sib ${s.id === o.id ? 'on' : ''}" href="#offer/${s.id}"><img src="${esc(s.image_url)}" alt=""><div><b>${esc(s.sup?.name)}</b><div class="small">${stars(s.rating, 12)} <span class="num">${s.rating.toFixed(1)}</span></div></div><span class="sp"></span><b class="small">${iqd(s.price)}</b></a>`).join('')}
        </div>
      </div>
    </div>`;
  body.querySelector('[data-apply]').onclick = () => startFlow(o);
  // حاسبة القسط
  const calc = body.querySelector('#calc'); let term = 60;
  const drawCalc = () => {
    calc.innerHTML = `<h3>احسب قسطك<span class="sp"></span><span class="small muted">مدة السداد <b class="num">${term}</b> شهراً</span></h3>
      <input type="range" min="12" max="${set.term_max_months || 84}" step="6" value="${term}" class="range" aria-label="مدة السداد">
      <div class="banks">${S.banks.map(b => { if (!b.terms) return ''; const rate = set.cbi_rate + Number(b.terms.margin); const ins = installment(o.price, rate, Math.min(term, b.terms.max_term_months));
        return `<div class="bk ${b.open ? '' : 'off'}"><i style="background:${esc(b.meta?.color || '#4356A3')}"></i><div><b>${esc(b.name)}</b><div class="small muted">${b.is_islamic ? `مرابحة ${what('murabaha')}` : 'تجاري'} · ربح <span class="num">${rate.toFixed(2)}%</span> سنوياً</div></div><span class="sp"></span><div style="text-align:left">${b.open ? `<b>${iqd(ins)}</b><div class="small muted">شهرياً</div>` : '<span class="small muted">لا يستقبل طلبات حالياً</span>'}</div></div>`; }).join('')}</div>
      <p class="small muted" style="margin:8px 0 0">النسبة = عوائد المصرف السنوية المتناقصة (بحد أعلى <span class="num">${set.margin_max}%</span>). تُضاف عمولة البنك المركزي لمرة واحدة <span class="num">${set.cbi_fee_small}%</span> (حتى 20 مليون) ولا تُسترجع، حسب سياسة التمويل.</p>`;
    calc.querySelector('.range').oninput = e => { term = Number(e.target.value); drawCalc(); calc.querySelector('.range').focus(); };
  };
  drawCalc();
  drawReviews(body.querySelector('#rv'), o);
}

function drawReviews(box, o, filter = 0, all = false) {
  const n = o.rs.length, list = o.rs.filter(r => !filter || r.rating === filter), shown = all ? list : list.slice(0, 5);
  box.innerHTML = `<h3>تقييمات المواطنين<span class="sp"></span><span class="badge muted">من ركّبوا المنظومة فقط</span></h3>
    <div class="rv-top">
      <div class="rv-avg"><b class="num">${o.rating.toFixed(1)}</b>${stars(o.rating, 18)}<span class="small muted"><span class="num">${n}</span> تقييم</span></div>
      <div class="rv-dist">${[5, 4, 3, 2, 1].map((s, i) => `<button class="rv-row ${filter === s ? 'on' : ''}" data-f="${s}"><span class="num">${s}</span>★<span class="bar"><i style="width:${n ? o.dist[i] / n * 100 : 0}%"></i></span><span class="num small muted">${o.dist[i]}</span></button>`).join('')}</div>
      <div class="rv-sub">${[['جودة المنظومة', o.q], ['التركيب', o.ins], ['خدمة المورد', o.srv]].map(([l, v]) => `<div><span class="small">${l}</span><span class="bar"><i style="width:${v / 5 * 100}%"></i></span><b class="num small">${v.toFixed(1)}</b></div>`).join('')}</div>
    </div>
    ${filter ? `<div class="small mb">تعرض تقييمات <b class="num">${filter}</b> نجوم فقط — <button class="linkbtn" data-f="0">عرض الكل</button></div>` : ''}
    <ul class="rv-list">${shown.map(r => `<li><div class="row" style="gap:8px"><span class="av sm">${esc(r.author_name.trim()[0])}</span><div><b>${esc(shortName(r.author_name))}</b><div class="small muted">${esc(r.governorate || '')} · ${ago(r.created_at)}</div></div><span class="sp"></span>${stars(r.rating, 14)}</div>
      ${r.comment ? `<p>${esc(r.comment)}</p>` : ''}${r.verified ? '<span class="badge ok sm">تركيب موثّق عبر المنصة</span>' : ''}</li>`).join('') || '<li class="muted">لا تقييمات بهذا العدد من النجوم.</li>'}</ul>
    ${!all && list.length > 5 ? `<button class="btn ghost block" data-all>عرض كل التقييمات (<span class="num">${list.length}</span>)</button>` : ''}`;
  box.querySelectorAll('[data-f]').forEach(b => b.onclick = () => drawReviews(box, o, Number(b.dataset.f) === filter ? 0 : Number(b.dataset.f)));
  const a = box.querySelector('[data-all]'); if (a) a.onclick = () => drawReviews(box, o, filter, true);
}
const shortName = n => { const p = n.trim().split(/\s+/); return p.length > 1 ? `${p[0]} ${p[1][0]}.` : p[0]; };

// ───────── بدء الطلب: بياناتك ← المصرف ← المنظومة المعتمدة لديه ← موقع التركيب ─────────
function startFlow(o) {
  if (S.active) {
    if (S.active.stage <= 5) {
      const m = modal(`<h3>لديك طلب لم يكتمل</h3><p class="muted">طلبك <b class="num">${esc(S.active.code)}</b> محفوظ. يمكنك تغيير المصرف أو المنظومة من خطوة «المصرف والمنظومة» داخل الطلب نفسه.</p>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إغلاق</button><button class="btn cyan" data-go>متابعة طلبي</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close; m.el.querySelector('[data-go]').onclick = () => { m.close(); location.hash = '#apply'; };
    } else toast('لديك طلب قائم لدى المصرف — تابعه من «طلبي»', 'bad');
    return;
  }
  C.czStart = { ...(C.czStart || {}), offer: o?.id || C.czStart?.offer || null };
  if (route().r === 'start') go(); else location.hash = '#start';
}

// الجلسة 34: خمس شاشات، لكل شاشة سؤال واحد وزر «التالي»
const START = [['بياناتك', 'العنوان والعمل والدخل'], ['المصرف', 'القسط والعمولة'], ['المنظومة', 'المعتمدة لدى المصرف'], ['المكان', 'أين ستُركَّب'], ['التأكيد', 'راجع ثم ابدأ']];
function pageStart(body) {
  if (S.active) { location.hash = S.active.stage <= 5 ? '#apply' : '#home'; return; }
  const st = C.czStart = C.czStart || {};
  const set = S.ref.set, p = C.profile;
  st.term = Math.min(st.term || 60, set.term_max_months || 60);
  const banks = S.banks.filter(b => b.terms);
  if (st.step == null) st.step = profileReady(p) ? 1 : 0;
  if (st.step >= 2 && !banks.some(b => b.id === st.bank && b.open)) st.step = 1;
  if (st.step >= 3 && !st.offer) st.step = 2;
  if (st.step >= 4 && !st.place?.ok) st.step = 3;
  const offerOk = (b, o) => o && accepts(b, o.supplier_id);
  body.innerHTML = `
    ${wizHead({ title: 'طلب تمويل منظومة شمسية', sub: 'يُحفظ ما تكتبه — يمكنك الخروج والعودة', steps: START, cur: st.step, done: st.step, reach: st.step - 1, exitLabel: 'خروج' })}
    <div class="card wiz-body" id="sb"></div>`;
  wireWizHead(body, i => { st.step = i; pageStart(body); });
  const sb = body.querySelector('#sb');
  const next = n => { st.step = n; pageStart(body); window.scrollTo(0, 0); };
  [startData, startBank, startOffer, startPlace, startGo][st.step]();

  // أ) بيانات المقترض: من البطاقة الوطنية + العنوان والعمل والدخل
  function startData() {
    sb.innerHTML = `<h2>بياناتك</h2><p class="muted">بياناتك الشخصية مقروءة من بطاقتك الوطنية. أكمل العنوان والعمل والدخل — يحتاجها المصرف لدراسة طلبك ويُحسب منها مدى تحمّلك للقسط.</p>
      <div class="review"><dl class="kv"><dt>الاسم</dt><dd>${esc(p.full_name)}</dd><dt>رقم البطاقة</dt><dd><span class="num">${esc(maskId(p.national_id))}</span>${p.id_source === 'ocr' ? ' ' + badge(['مقروء من البطاقة', 'ok']) : ''}</dd><dt>الهاتف</dt><dd><span class="num">${esc(p.phone || '—')}</span></dd></dl></div>
      <form data-f novalidate><div class="grid g2" style="gap:12px">
        <div class="field"><label>المحافظة *</label><select class="input" name="governorate">${govOptions(p.governorate || '')}</select></div>
        <div class="field"><label>المدينة / القضاء</label><input class="input" name="city" value="${esc(p.city || '')}"></div>
        <div class="field" style="grid-column:1/-1"><label>العنوان التفصيلي</label><input class="input" name="address" value="${esc(p.address || '')}" placeholder="المحلة، الزقاق، الدار"></div>
        <div class="field"><label>جهة العمل *</label><input class="input" name="employer" value="${esc(p.employer || '')}" placeholder="دائرة حكومية، شركة، عمل حر"></div>
        <div class="field"><label>الدخل الشهري (د.ع) *</label><input class="input" name="monthly_salary" inputmode="numeric" dir="ltr" value="${esc(p.monthly_salary || '')}"></div>
      </div><div class="row mt"><span class="sp"></span><button class="btn cyan">التالي: اختر المصرف ←</button></div></form>`;
    sb.querySelector('[data-f]').onsubmit = async e => {
      e.preventDefault(); const f = e.target, d = {};
      ['governorate', 'city', 'address', 'employer', 'monthly_salary'].forEach(k => d[k] = (f[k].value || '').trim());
      d.monthly_salary = digits(d.monthly_salary);
      if (!d.governorate) return toast('اختر المحافظة', 'bad');
      if (d.employer.length < 2) return toast('اكتب جهة العمل', 'bad');
      if (!(Number(d.monthly_salary) > 0)) return toast('اكتب الدخل الشهري', 'bad');
      const b = f.querySelector('button'); b.disabled = true;
      try { C.profile = await rpc(C.sb, 'update_my_profile', { p: d }); toast('حُفظت بياناتك', 'ok'); next(1); }
      catch (er) { toast(cleanErr(er), 'bad'); b.disabled = false; }
    };
  }

  // ب) المصرف: العمولة والرسوم والنسبة والمدة، وعدد المنظومات المعتمدة لديه
  function startBank() {
    const o = offerById(st.offer), ref = o?.price || S.offers.reduce((m, x) => Math.min(m, x.price), Infinity);
    const draw = () => {
      sb.innerHTML = `<h2>اختر مصرفك</h2><p class="muted">قارن رقمين فقط: كم تدفع كل شهر، وكم تدفع الآن قبل إرسال الطلب. ${o ? `الأرقام لمنظومتك المختارة (${iqd(o.price)}).` : `الأرقام تقريبية لأرخص منظومة (${iqd(ref)}) — تتحدد بعد اختيار منظومتك.`}</p>
        <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${st.term}</span> شهراً (<span class="num">${(st.term / 12).toFixed(1)}</span> سنة)</b></div>
        <input type="range" class="range" min="12" max="${set.term_max_months}" step="6" value="${st.term}" aria-label="مدة السداد">
        ${bankCardsHtml(banks, { amt: ref, term: st.term, sel: st.bank,
          enabled: b => b.open && (!o || offerOk(b, o)) && S.offers.some(x => accepts(b, x.supplier_id)),
          note: b => !b.open ? 'لا يستقبل طلبات عبر المنصة حالياً' : o && !offerOk(b, o) ? 'لا يتعامل مع مورد منظومتك المختارة' : !S.offers.some(x => accepts(b, x.supplier_id)) ? 'لا منظومات معتمدة لديه حالياً' : '' })}
        <div class="row mt"><button class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-ok ${banks.some(b => b.id === st.bank && b.open) ? '' : 'disabled'}>${banks.some(b => b.id === st.bank && b.open) ? (o ? 'التالي: مكان المنظومة ←' : 'التالي: اختر المنظومة ←') : 'اختر مصرفاً أولاً'}</button></div>`;
      sb.querySelector('.range').oninput = e => { st.term = Number(e.target.value); draw(); sb.querySelector('.range').focus(); };
      sb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { st.bank = r.value; draw(); });
      wireBankDetails(sb);
      sb.querySelector('[data-back]').onclick = () => next(0);
      sb.querySelector('[data-ok]').onclick = () => { const b = banks.find(x => x.id === st.bank); st.term = Math.min(st.term, b.terms.max_term_months); next(o && offerOk(b, o) ? 3 : 2); };
    };
    draw();
  }

  // ج) المنظومة: فقط عروض الموردين المعتمدين لدى المصرف المختار، بقسطها وعمولتها لديه
  function startOffer() {
    const b = banks.find(x => x.id === st.bank), list = S.offers.filter(x => accepts(b, x.supplier_id));
    sb.innerHTML = `<h2>اختر المنظومة</h2><p class="muted">المنظومات المعروضة من الموردين المعتمدين لدى <b>${esc(b.name)}</b>، بقسطها وعمولتها لدى هذا المصرف لمدة <span class="num">${st.term}</span> شهراً.</p>
      <div class="pick-list">${S.ref.tiers.map(t => { const os = list.filter(x => x.tier_id === t.id); if (!os.length) return '';
        return `<div class="pl-h"><b>${esc(t.loads)}</b> <span class="small muted">— قدرة <span class="num">${num(t.kw)}</span> كيلوواط</span> ${what('kw')}</div>${os.map(x => { const k = bankCalc(x.price, b, st.term);
          return `<label class="pl ${x.id === st.offer ? 'on' : ''}"><input type="radio" name="of" value="${x.id}" ${x.id === st.offer ? 'checked' : ''}><img src="${esc(x.image_url)}" alt=""><div><b>${esc(x.sup?.name)}</b><div class="small">${stars(x.rating, 12)} <span class="num">${x.rating.toFixed(1)}</span> · ${G_HINT[guaranteeFor(x.price)]}</div><div class="small muted">قسط ${iqd(k.ins)} · عمولة ${iqd(k.comm)}</div></div><span class="sp"></span><b class="small">${iqd(x.price)}</b></label>`; }).join('')}`; }).join('') || '<div class="empty">لا منظومات معتمدة لدى هذا المصرف حالياً — اختر مصرفاً آخر.</div>'}</div>
      <div class="row mt"><button class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-ok ${list.some(x => x.id === st.offer) ? '' : 'disabled'}>التالي: مكان المنظومة ←</button></div>`;
    sb.querySelectorAll('input[name=of]').forEach(r => r.onchange = () => { st.offer = r.value; sb.querySelectorAll('.pl').forEach(l => l.classList.toggle('on', l.querySelector('input').checked)); sb.querySelector('[data-ok]').disabled = false; });
    sb.querySelector('[data-back]').onclick = () => next(1);
    sb.querySelector('[data-ok]').onclick = () => next(3);
  }

  // د) مكان المنظومة — شاشة مستقلة (الجلسة 34)
  // الجلسة 22 (المقترحان 5 و6): نوع المكان وسؤال «هل المنظومة في عنوان سكنك؟» — الموقع بالضبط يُحدَّد لاحقاً قبل الإرسال
  function startPlace() {
    const q = st.place = st.place || { site_type: '', purpose: '', purpose_other: '', home: null, gov: '', city: '' };
    q.fz = q.fz || { mode: '', id: '', name: '', search: '' };
    let fzPk = null;   // الجلسة 25: الجهة التي أعدّت دراسة الجدوى
    const valid = () => !!q.site_type && (q.site_type === 'residential' || (q.purpose && (q.purpose !== 'other' || q.purpose_other.trim().length >= 3) && !!fzPk && fzPk.valid()))
      && (q.home === true ? !!p.governorate : q.home === false && !!q.gov);
    const hint = () => !q.site_type ? 'اختر أين ستُركَّب' : q.site_type === 'project' && !q.purpose ? 'اختر نوع المشروع' : q.home == null ? 'أجب: هل هي في عنوان سكنك؟' : q.home === false && !q.gov ? 'اختر المحافظة' : 'أكمل الأسئلة أعلاه';
    const draw = () => {
      sb.innerHTML = `<h2>أين ستُركَّب المنظومة؟</h2><p class="muted">أجب عن سؤالين. لا يلزمك أن تكون في المكان الآن — تحدده بالضبط قبل إرسال الطلب.</p>
        <label class="lbl">1. نوع المكان ★</label>
        <div class="seg big">${Object.entries(SITE_TYPE).map(([k, t]) => `<label class="${q.site_type === k ? 'on' : ''}"><input type="radio" name="stype" value="${k}" ${q.site_type === k ? 'checked' : ''}><span class="seg-ic">${k === 'residential' ? '🏠' : '🏭'}</span>${esc(t)}</label>`).join('')}</div>
        ${q.site_type === 'project' ? `<label class="lbl mt">نوع المشروع ★</label>
          <div class="chips">${PROJECT_KINDS.map(([k, t]) => `<label class="chip ${q.purpose === k ? 'on' : ''}"><input type="radio" name="pkind" value="${k}" ${q.purpose === k ? 'checked' : ''}>${esc(t)}</label>`).join('')}</div>
          ${q.purpose === 'other' ? `<div class="field mt"><label>اكتب نوع المشروع ★</label><input class="input" data-other maxlength="60" value="${esc(q.purpose_other)}" placeholder="مثال: مستوصف أهلي، مدرسة"></div>` : ''}
          <p class="small muted" style="margin:6px 0 0">طلبات المشاريع تتطلب عرض المورد ودراسة جدوى يدرسها خبير معتمد.</p>
          ${q.purpose ? '<div data-fz></div>' : ''}` : ''}
        ${q.site_type ? `<label class="lbl mt">2. هل المنظومة في عنوان سكنك${p.governorate ? ` (${esc(p.governorate)}${p.city ? ' — ' + esc(p.city) : ''})` : ''}؟ ★</label>
          <div class="seg big"><label class="${q.home === true ? 'on' : ''}"><input type="radio" name="home" value="1" ${q.home === true ? 'checked' : ''}>نعم</label><label class="${q.home === false ? 'on' : ''}"><input type="radio" name="home" value="0" ${q.home === false ? 'checked' : ''}>لا، في مكان آخر</label></div>
          ${q.home === false ? `<div class="grid g2 mt" style="gap:12px"><div class="field"><label>المحافظة ★</label><select class="input" data-gv>${govOptions(q.gov)}</select></div>
            <div class="field"><label>المدينة أو الحي</label><input class="input" data-ct value="${esc(q.city)}" placeholder="مثال: الزبير"></div></div>` : ''}` : ''}
        <div class="row mt"><button class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-ok disabled>التالي: راجع طلبك ←</button></div>`;
      const ok = sb.querySelector('[data-ok]');
      const upd = () => { q.ok = false; const v = valid(); ok.disabled = !v; ok.textContent = v ? 'التالي: راجع طلبك ←' : hint(); };
      sb.querySelectorAll('input[name=stype]').forEach(r => r.onchange = () => { q.site_type = r.value; if (r.value === 'residential') q.purpose = ''; draw(); });
      sb.querySelectorAll('input[name=pkind]').forEach(r => r.onchange = () => { q.purpose = r.value; draw(); });
      sb.querySelectorAll('input[name=home]').forEach(r => r.onchange = () => { q.home = r.value === '1'; draw(); });
      const o = sb.querySelector('[data-other]'); if (o) o.oninput = () => { q.purpose_other = o.value; upd(); };
      const gv = sb.querySelector('[data-gv]'); if (gv) gv.onchange = () => { q.gov = gv.value; upd(); };
      const ct = sb.querySelector('[data-ct]'); if (ct) ct.oninput = () => { q.city = ct.value; };
      const fb = sb.querySelector('[data-fz]');
      fzPk = fb ? fzPicker(fb, C.sb, { state: q.fz, gov: q.home === false ? q.gov : p.governorate, onChange: upd }) : null;
      sb.querySelector('[data-back]').onclick = () => next(2);
      ok.onclick = () => {
        if (!valid()) return toast(hint(), 'bad');
        q.fzPay = q.site_type === 'project' && fzPk?.valid() ? fzPk.payload() : null;
        q.ok = true; next(4);
      };
      upd();
    };
    draw();
  }

  // هـ) المراجعة ثم بدء الطلب
  function startGo() {
    const b = banks.find(x => x.id === st.bank), o = offerById(st.offer), k = bankCalc(o.price, b, st.term), f = feeItems(o.price, b), tot = f.reduce((t, x) => t + x[1], 0);
    const q = st.place;
    const gov = q.home ? p.governorate : q.gov, city = q.home ? (p.city || null) : (q.city.trim() || null);
    const placeTxt = `${q.site_type === 'project' ? esc(PROJECT_KINDS.find(x => x[0] === q.purpose)?.[1] || q.purpose_other || SITE_TYPE.project) : esc(SITE_TYPE[q.site_type])} — ${esc(gov || '')}${city ? ' / ' + esc(city) : ''}`;
    sb.innerHTML = `<h2>راجع طلبك ثم ابدأ</h2><p class="muted">تأكد من الأرقام. يمكنك الرجوع لأي خطوة بالضغط عليها في الأعلى.</p>
      <div class="sum-hero"><div class="sum-k">قسطك الشهري</div><div class="sum-v">${iqd(k.ins)}</div><div class="small">لمدة <b class="num">${k.t}</b> شهراً لدى <b>${esc(b.name)}</b></div></div>
      <div class="pick big"><img src="${esc(o.image_url)}" alt=""><div><b style="font-size:17px">${esc(o.title)}</b><div class="small muted">${esc(o.sup?.name)} · <a href="#offer/${o.id}">التفاصيل</a></div><div class="price">${iqd(o.price)}</div></div></div>
      <div class="review"><dl class="kv">
        ${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${commPct(b)}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}
        <dt><b>تدفعه الآن قبل الإرسال</b></dt><dd><b>${iqd(tot)}</b></dd><dt>الضمان المطلوب</dt><dd>${G_HINT[guaranteeFor(o.price)]}</dd><dt>مكان المنظومة</dt><dd>${placeTxt}</dd></dl>
        <p class="small muted" style="margin:6px 0 0">تدفع العمولة والرسوم إلكترونياً في آخر خطوة قبل إرسال الطلب. عمولة البنك المركزي لمرة واحدة تُستوفى لاحقاً في الفرع.</p></div>
      <div class="notice mt"><span>ℹ</span><span class="small">بعد البدء خمس خطوات قصيرة: صورة وجهك، رقم «أور» ${what('ur')}، تأكيد اختيارك، الضمان، ثم الدفع والإرسال. يُحفظ تقدمك تلقائياً.</span></div>
      <div class="row mt"><button class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-go>ابدأ الطلب ✓</button></div>`;
    sb.querySelector('[data-back]').onclick = () => next(3);
    sb.querySelector('[data-go]').onclick = async e => {
      if (q.home === true && !p.governorate) return toast('أكمل محافظة سكنك في «بياناتك»', 'bad');
      e.target.disabled = true;
      try {
        const a = await rpc(C.sb, 'start_application_bank', { p_offer: o.id, p_bank: b.id, p_term: k.t, p_governorate: gov, p_city: city, p_lat: null, p_lng: null });
        try { await rpc(C.sb, 'set_app_site', { p_app: a.id, p: { site_type: q.site_type, purpose: q.site_type === 'project' ? q.purpose : 'household', purpose_other: q.purpose === 'other' ? q.purpose_other.trim() : null, at_home: q.home, governorate: gov, city } }); }
        catch (er) { toast(`بدأ الطلب، لكن تعذّر حفظ نوع المكان: ${cleanErr(er)} — أعد اختياره من صفحة الطلب`, 'bad'); }
        if (q.site_type === 'project' && q.fzPay) {
          try { await rpc(C.sb, 'set_fz_office', { p_app: a.id, p: q.fzPay }); }
          catch (er) { toast(`بدأ الطلب، لكن تعذّر حفظ الجهة المُعِدّة لدراسة الجدوى: ${cleanErr(er)} — حدّدها في الخطوة 3`, 'bad'); }
        }
        C.czStart = null; await load(); C.czStep = null; location.hash = '#apply';
        toast('بدأ طلبك — الخطوة الأولى: التحقق من الهوية', 'ok');
      } catch (err) { toast(cleanErr(err), 'bad'); e.target.disabled = false; }
    };
  }
}

// ───────── معالج الطلب: المراحل 1–5 ─────────
const STEPS = [['الهوية', 'التحقق بالسيلفي'], ['«أور»', 'ربط الرقم'], ['التأكيد', 'المصرف والمنظومة والمستندات'], ['الضمان', 'كفيل أو ذهب أو عقار'], ['الدفع والإرسال', 'العمولة والتوقيع']];
async function pageApply(body) {
  const app = S.active;
  if (!app || app.stage > 5) { location.hash = app ? '#home' : '#catalog'; return; }
  C.czVetWait = false;
  if (isVet(app)) return pageApplyVet(body, app);
  const step = Math.min(C.czStep || app.stage, app.stage);
  // الجلسة 35: شاشة فرعية داخل الخطوة (3: المستندات، 5: راجع ← ادفع ← وقّع)
  const sub = C.czSub?.step === step ? C.czSub.v : null;
  if (C.czSub && C.czSub.step !== step) C.czSub = null;
  body.innerHTML = `
    ${wizHead({ title: 'طلب تمويل', sub: `رقم <b class="num">${esc(app.code)}</b> · ${iqd(app.amount)}`, steps: STEPS, cur: step - 1, done: app.stage - 1, reach: app.stage - 1 })}
    ${app.return_kind === 'guarantee' ? `<div class="notice warn"><span>⚠</span><span><b>أعاد المصرف طلبك لاستبدال الضمان</b><div style="white-space:pre-line">${esc(String(app.return_note || '').replace(/★\s*/g, '• '))}</div>
      <div class="small mt">${app.stage <= 4 ? '① اختر ضماناً جديداً في خطوة «الضمان» ← ② وقّع وأعد الإرسال.' : '✓ اخترت الضمان الجديد — بقي ② التوقيع وإعادة الإرسال في الخطوة 5.'} ${(app.returned_from || 6) >= 8 ? 'بعدها يعود طلبك إلى مدير الفرع ليوافق على ضمانك الجديد، ثم يكمل المصرف من حيث توقف.' : 'بعدها يعود طلبك إلى المصرف من حيث توقف.'}</div></span></div>` : ''}
    <div id="wsite"></div><div class="card wiz-body" id="wb"></div><div id="wdocs"></div>`;
  wireWizHead(body, i => { C.czStep = i + 1; C.czSub = null; pageApply(body); });
  const wb = body.querySelector('#wb');
  // الجلسة 22 (المقترحان 6 و7 و8): مكان المنظومة لا يوقف البدء — يُطلب قبل الإرسال (الخطوة 5)، من الهاتف أو برابط لشخص هناك أو بدبوس إن سمح المصرف
  const ws = body.querySelector('#wsite'), accMax = S.ref?.set?.site_gps_accuracy_m || 100, reload = async () => { await load(); pageApply(body); };
  // الجلسة 34: شاشة واحدة لكل خطوة — مكان المنظومة يظهر في خطوة الإرسال فقط (أو إن لم يُحدَّد نوع المكان بعد)
  if (!app.site_type) sitePanel(ws, app, { sb: C.sb, accMax, onSaved: reload });
  else if (step === 5 && (!sub || sub === 'review')) placePanel(ws, app, { sb: C.sb, bank: chosenBank(app), accMax, required: !app.site_geo, onSaved: reload });
  const done = step < app.stage;
  // الجلسة 35: المستندات شاشة مستقلة بعد تأكيد المصرف والمنظومة (كانت تحت الخطوة فيفوتها المقترض)
  if (step === 3 && sub === 'docs') return docsScreen(wb, app);
  [step1, step2, step3, step4, step5][step - 1](wb, app, done);
}
const DOC_KEYS = ['quote', 'fz_office', 'feasibility', 'feasibility_update'];
// الانتقال لشاشة داخل المعالج (يُستخدم من الأزرار)
const goStep = (n, v = null) => { C.czStep = n; C.czSub = v ? { step: n, v } : null; pageApply(C.root.querySelector('#cz')); window.scrollTo(0, 0); };

// ───────── الجلسة 16 + 35: المستندات — شاشة مستقلة «ارفع مستنداتك»، كل مستند في بطاقة بزر واحد ─────────
async function docsScreen(wb, app) {
  wb.innerHTML = '<div class="cz-load"><div class="spin"></div><span>جارِ تحميل مستنداتك…</span></div>';
  let d = await loadIntake(C.sb, app);
  if (!wb.isConnected) return;
  if (!d) { wb.innerHTML = '<p class="muted">لا مستندات مطلوبة لهذا الطلب.</p><div class="row mt"><span class="sp"></span><button class="btn cyan" data-next>التالي ←</button></div>'; wb.querySelector('[data-next]').onclick = () => goStep(app.stage); return; }
  const paint = () => {
    const p = app.purpose || 'household', needFz = p !== 'household';
    const lastRej = d.refs.filter(r => r.status === 'non_conforming').slice(-1)[0];
    const fz = d.docs.filter(x => x.kind === 'feasibility'), q = d.docs.filter(x => x.kind === 'quote').slice(-1)[0];
    const it = k => (d.ck?.items || []).find(i => i.key === k);
    const needUpd = it('feasibility_update') && !it('feasibility_update').ok;
    const fzLock = d.refs.some(r => ['pending', 'received', 'conforming'].includes(r.status));
    const miss = (d.ck?.items || []).filter(i => DOC_KEYS.includes(i.key) && !i.ok);
    const st = ok => ok ? '<span class="dt-st ok">✓ مرفق</span>' : '<span class="dt-st miss">★ مطلوب</span>';
    const tile = (k, ok, ic, title, hint, inner, btn) => `<div class="doc-tile ${ok ? 'ok' : 'miss'}" data-tile="${k}">
      <div class="dt-h"><span class="dt-ic" aria-hidden="true">${ic}</span><div class="dt-t"><b>${title} ${st(ok)}</b><small>${hint}</small></div></div>${inner}${btn}</div>`;
    const quoteOk = !!q, fzOk = fz.length && !needUpd, offOk = !it('fz_office') || it('fz_office').ok;
    const nextN = app.stage > 3 ? STEPS[app.stage - 1][0] : 'تأكيد المصرف';
    wb.innerHTML = `<ol class="sub-steps" aria-label="الخطوة 3"><li class="done">✓ المصرف والمنظومة</li><li class="cur">المستندات</li></ol>
      <h2>ارفع مستنداتك</h2>
      <p class="muted" style="margin-top:0">${miss.length ? `بقي <b class="num">${miss.length}</b> ${miss.length === 1 ? 'مستند' : 'مستندات'} — اضغط الزر تحت كل مستند. يكفي تصويره بالهاتف أو اختيار ملف.` : '✓ أرفقت كل المستندات المطلوبة — اضغط «التالي».'}</p>
      ${lastRej ? `<div class="notice warn"><span>⚠</span><span><b>رفض الخبير المعتمد دراسة الجدوى السابقة</b> (${esc(lastRej.specialty_label)} · ${dt(lastRej.decided_at)})
        <div style="white-space:pre-line;margin-top:4px">${esc(lastRej.decision_text || '')}${lastRej.notes ? `\n<b>المطلوب:</b> ${esc(lastRej.notes)}` : ''}</div>
        ${needUpd ? '<div class="small mt"><b>ارفع دراسة جدوى حقيقية محدّثة بأرقام واقعية</b> — تُحفظ دراستك السابقة معها.</div>' : '<div class="small mt" style="color:var(--ok)">✓ رُفعت دراسة محدّثة.</div>'}</span></div>` : ''}
      <div class="doc-tiles">
        ${tile('quote', quoteOk, '📄', 'عرض سعر المورد', 'عرض السعر الرسمي بختم المورد وتوقيعه — صورة أو PDF حتى 3 ميغابايت.', q ? studiesHtml([q]) : '',
          `<button type="button" class="btn ${quoteOk ? 'ghost' : 'cyan'} big-btn" data-up="quote">${quoteOk ? 'استبدال العرض' : '📎 ارفع عرض المورد'}</button>`)}
        ${needFz ? tile('feasibility', fzOk, '📊', 'دراسة الجدوى', 'كلفة المشروع، الإيراد أو التوفير المتوقع، كلف التشغيل، ومدة استرداد التمويل — PDF حتى 5 ميغابايت. يدرسها خبير معتمد من خارج المصرف.',
          fz.length ? studiesHtml(fz, d.refs) : '', `<button type="button" class="btn ${fzOk ? 'ghost' : 'cyan'} big-btn" data-up="feasibility">${fz.length ? (needUpd ? '📎 ارفع الدراسة المحدّثة' : 'رفع دراسة محدّثة') : '📎 ارفع دراسة الجدوى'}</button>`) : ''}
        ${needFz && (it('fz_office') || d.ck?.fz_office?.set) ? tile('fz_office', offOk, '🏢', 'من أعدّ الدراسة؟', 'مكتب أو مركز دراسات جدوى — من القائمة المعتمدة أو تكتب اسمه.', fzLine(d.ck?.fz_office, { sla: d.ck?.fz_sla }),
          fzLock ? '<p class="small muted" style="margin:0">لا تُغيَّر الجهة بعد إحالة الدراسة إلى الخبير.</p>' : `<button type="button" class="btn ${d.ck?.fz_office?.set ? 'ghost' : 'cyan'} big-btn" data-fzc>${d.ck?.fz_office?.set ? 'تغيير الجهة' : 'اختر الجهة'}</button>`) : ''}
      </div>
      <p class="small muted mt">الغرض: <b>${esc(app.site_type ? SITE_TYPE[app.site_type] + ' — ' : '')}${esc(purposeText(app))}</b> — ${esc(PURPOSE_HINT[p] || '')}.</p>
      <div class="row mt"><button type="button" class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button type="button" class="btn cyan ${miss.length ? 'is-off' : ''}" data-next>${miss.length ? `ارفع المطلوب أولاً (${miss.length})` : `التالي: ${esc(nextN)} ←`}</button></div>
      ${miss.length ? `<p class="later"><button type="button" class="linkbtn" data-later>سأرفعها لاحقاً — تابع إلى «${esc(nextN)}»</button><small>لا يُرسل الطلب للمصرف قبل إرفاقها.</small></p>` : ''}`;
    const next = () => app.stage > 3 ? goStep(app.stage) : goStep(3);
    wb.querySelector('[data-back]').onclick = () => goStep(3);
    wb.querySelector('[data-next]').onclick = () => {
      if (!miss.length) return next();
      const t = wb.querySelector('.doc-tile.miss'); t?.scrollIntoView({ behavior: 'smooth', block: 'center' }); t?.classList.add('flash'); setTimeout(() => t?.classList.remove('flash'), 1200);
      toast(`ارفع أولاً: ${miss.map(i => i.label).join('، ')}`, 'bad');
    };
    const lt = wb.querySelector('[data-later]'); if (lt) lt.onclick = next;
    wb.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(C.sb, b.dataset.doc));
    const fzc = wb.querySelector('[data-fzc]'); if (fzc) fzc.onclick = () => fzDialog(C.sb, app, { current: d.ck?.fz_office, onSaved: async () => { d = await loadIntake(C.sb, app); paint(); } });
    wb.querySelectorAll('[data-up]').forEach(b => b.onclick = async () => {
      const kind = b.dataset.up, f = await pickFile({ maxMB: kind === 'feasibility' ? 5 : 3 });
      if (!f) return;
      b.disabled = true; b.textContent = 'جارِ الرفع…';
      try { await rpc(C.sb, 'add_document', { p_app: app.id, p_kind: kind, p_data: f.data, p_source: 'file', p_meta: f.meta }); d = await loadIntake(C.sb, app); toast(kind === 'quote' ? '✓ رُفع عرض المورد' : '✓ رُفعت دراسة الجدوى', 'ok'); }
      catch (e) { toast(cleanErr(e), 'bad'); }
      paint();
    });
  };
  paint();
}
async function saveStep(app, n, data, msg, next) {
  await rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: n, p_data: data });
  await load();
  C.czStep = next?.step || null; C.czSub = next?.sub ? { step: next.step, v: next.sub } : null;
  toast(msg || 'تم الحفظ', 'ok');
  if (S.active?.stage > 5) { location.hash = '#home'; return; }
  pageApply(C.root.querySelector('#cz')); window.scrollTo(0, 0);
}
const doneBox = (title, rows, onEdit, onNext, nextLabel) => {
  const d = el(`<div><div class="done-box"><span class="ok-ic">✓</span><div><b>${title}</b><dl class="kv mt">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl></div></div>
    <div class="row mt"><button class="btn ghost" data-edit>تعديل</button><span class="sp"></span><button class="btn cyan" data-next>${nextLabel || 'الخطوة التالية ←'}</button></div></div>`);
  d.querySelector('[data-edit]').onclick = onEdit;
  d.querySelector('[data-next]').onclick = onNext || (() => goStep(null));
  return d;
};

// 1) التحقق من الهوية بالسيلفي (eKYC — محاكاة المطابقة)
function step1(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('تم التحقق من هويتك', [['رقم البطاقة', `<span class="num">${maskId(app.kyc?.national_id || C.profile.national_id)}</span>`], ['مطابقة الوجه', `<span class="num">${app.kyc?.match_score ?? '—'}%</span>`], ['فحص الحيوية', badge(['ناجح', 'ok'])]], () => step1(wb, app, done, true))); return; }
  const k = { live: false, score: 0 };
  wb.innerHTML = `<h2>التحقق من الهوية</h2><p class="muted">نطابق وجهك مع صورة بطاقتك الوطنية الموحدة ونتأكد أنك حاضر فعلاً (فحص الحيوية).</p>
    <div class="grid g2">
      <div>
        <div class="field"><label>رقم البطاقة الوطنية</label><input class="input" data-nid inputmode="numeric" maxlength="12" dir="ltr" value="${esc(C.profile.national_id || '')}" ${C.profile.national_id ? 'readonly' : ''}></div>
        ${C.profile.id_source === 'ocr' ? `<div class="idnote ok">✓ صُوّرت بطاقتك الوطنية وقُرئت عند إنشاء الحساب${C.profile.id_mrz_verified ? ' وتحققنا منها بالشريط السفلي' : ''}</div>` : '<p class="small muted">أدخل رقمك الوطني كما في البطاقة الموحدة.</p>'}
      </div>
      <div class="selfie">
        <div class="cam"><video playsinline muted autoplay></video><canvas hidden></canvas><img hidden alt="الصورة الملتقطة"><div class="oval"></div><div class="hint">اضغط «بدء الفحص» وضع وجهك داخل الإطار</div></div>
        <div class="row mt"><button class="btn" data-cam>بدء الفحص بالكاميرا</button><button class="btn ghost" data-sim>محاكاة بدون كاميرا</button></div>
        <div class="kyc-res" hidden></div>
      </div>
    </div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok disabled>${ADVANCE_LABEL[1]}</button></div>`;
  const v = wb.querySelector('video'), cv = wb.querySelector('canvas'), im = wb.querySelector('.cam img'), hint = wb.querySelector('.hint'), res = wb.querySelector('.kyc-res'), ok = wb.querySelector('[data-ok]');
  let stream;
  const stop = () => { stream?.getTracks().forEach(t => t.stop()); stream = null; };
  const sequence = async (withCam) => {
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => b.disabled = true);
    const cam = wb.querySelector('.cam'); cam.classList.add('scan');
    for (const h of ['انظر إلى الكاميرا مباشرة', 'ارمش بعينيك مرتين', 'أدر رأسك قليلاً إلى اليمين', 'ثبّت وجهك… جارِ الالتقاط']) { hint.textContent = h; await new Promise(r => setTimeout(r, 1100)); }
    if (withCam && v.videoWidth) { cv.width = v.videoWidth; cv.height = v.videoHeight; cv.getContext('2d').drawImage(v, 0, 0); im.src = cv.toDataURL('image/jpeg', .7); im.hidden = false; v.hidden = true; }
    stop(); cam.classList.remove('scan'); cam.classList.add('ok');
    hint.textContent = 'تم الالتقاط — جارِ المطابقة مع صورة البطاقة…';
    await new Promise(r => setTimeout(r, 1200));
    k.live = true; k.score = Math.round((92 + Math.random() * 7) * 10) / 10;
    hint.textContent = 'اكتمل الفحص';
    res.hidden = false; res.innerHTML = `<div class="row"><span class="ok-ic">✓</span><div><b>مطابقة الوجه <span class="num">${k.score}%</span></b><div class="small muted">فحص الحيوية ناجح · الحد الأدنى للقبول 80%</div></div></div>`;
    ok.disabled = false;
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => { b.disabled = false; });
    wb.querySelector('[data-cam]').textContent = 'إعادة الفحص';
  };
  wb.querySelector('[data-cam]').onclick = async () => {
    im.hidden = true; v.hidden = false; wb.querySelector('.cam').classList.remove('ok');
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } }); v.srcObject = stream; await v.play().catch(() => {}); sequence(true); }
    catch { toast('تعذّر فتح الكاميرا — استخدم «محاكاة بدون كاميرا»', 'bad'); }
  };
  wb.querySelector('[data-sim]').onclick = () => { im.hidden = true; v.hidden = true; wb.querySelector('.cam').classList.add('sim'); sequence(false); };
  ok.onclick = async () => {
    const nid = digits(wb.querySelector('[data-nid]').value);
    if (!/^\d{12}$/.test(nid)) return toast('رقم البطاقة الوطنية 12 رقماً', 'bad');
    ok.disabled = true;
    try { await saveStep(app, 1, { national_id: nid, liveness: k.live, match_score: k.score, card_side: 'front+back', id_source: C.profile.id_source === 'ocr' ? 'ocr' : 'manual' }, 'تم التحقق من هويتك'); }
    catch (e) { toast(cleanErr(e), 'bad'); ok.disabled = false; }
  };
  window.addEventListener('hashchange', stop, { once: true });
}

// 2) رقم «أور» برمز تحقق
function step2(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('رقم «أور» مربوط بطلبك', [['رقم «أور»', `<span class="num">${esc(app.ur_number)}</span>`], ['التحقق النهائي', 'يتحقق منه موظف خدمة العملاء في المصرف (المرحلة 7)']], () => step2(wb, app, done, true))); return; }
  wb.innerHTML = `<h2>رقم «أور» ${what('ur')}</h2><p class="muted">اكتب رقمك في «أور»، وسيصلك رمز على هاتفك لتأكيده.</p>
    <div class="field" style="max-width:420px"><label>رقم «أور» (10 أرقام)</label><input class="input" data-ur inputmode="numeric" maxlength="10" dir="ltr" placeholder="0000000000" value="${esc(app.ur_number || '')}"></div>
    <div class="notice"><span>ℹ</span><span>تجده في تطبيق «أور» ← الملف الشخصي. في نسخة العرض اكتب أي 10 أرقام.</span></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>إرسال رمز التحقق ←</button></div>`;
  wb.querySelector('[data-ok]').onclick = async () => {
    const ur = digits(wb.querySelector('[data-ur]').value);
    if (!/^\d{10}$/.test(ur)) return toast('رقم «أور» 10 أرقام', 'bad');
    await askOtp({ kind: 'ur', title: 'رمز التحقق من «أور»', phone: C.profile.phone, purpose: 'لربط حسابك في «أور» بطلب التمويل', verify: c => saveStep(app, 2, { ur_number: ur, otp: c }, 'تم ربط رقم «أور»') });
  };
}

// ───────── المصرف والعمولة (مشتركة بين المرحلتين 3 و5) ─────────
const commPct = b => Number(b?.terms?.commission_pct ?? 1);
const bankCalc = (amount, b, term) => {
  const rate = S.ref.set.cbi_rate + Number(b.terms.margin), t = Math.min(term, b.terms.max_term_months), ins = installment(amount, rate, t);
  return { rate, t, ins, total: ins * t, profit: ins * t - amount, comm: Math.round(amount * commPct(b) / 100) };
};
const feeItems = (amount, b) => [['عمولة المصرف', Math.round(amount * commPct(b) / 100), true], ['رسم دراسة الملف', Number(b.terms.file_fee || 0)],
  ['أجور الكشف الموقعي', Number(S.ref.set.inspection_fee || 0)], ['عمولة المنصة', Number(S.ref.set.platform_fee || 0)]];
const chosenBank = app => S.banks.find(b => b.id === (app.bank_choice?.bank_id || app.bank_id));

// الجلسة 21 (المقترح 2): بطاقة المصرف برقمين فقط — «تدفع شهرياً» و«تدفع الآن» — وشارة «الأقل قسطاً»، والباقي تحت «التفاصيل»
const openDet = new Set();
const payNow = (amount, b) => feeItems(amount, b).reduce((t, x) => t + x[1], 0);
function bankCardsHtml(banks, { amt, term, sel, enabled, note }) {
  const en = banks.filter(b => enabled(b));
  const best = en.length > 1 ? en.reduce((a, b) => bankCalc(amt, a, term).ins <= bankCalc(amt, b, term).ins ? a : b).id : null;
  return `<div class="bcards">${banks.map(b => { const ok = enabled(b), k = bankCalc(amt, b, term), why = note(b);
    return `<label class="bcard ${b.id === sel ? 'on' : ''} ${ok ? '' : 'off'}"><input type="radio" name="bk" value="${b.id}" ${b.id === sel ? 'checked' : ''} ${ok ? '' : 'disabled'}>
      <div class="row"><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i><b>${esc(b.name)}</b><span class="sp"></span>${b.id === best ? '<span class="badge ok">الأقل قسطاً</span>' : ''}</div>
      ${!ok && why ? `<div class="small mt" style="color:var(--warn)">${why}</div>` : `<div class="bk-two"><div><small>تدفع شهرياً</small><b>${iqd(k.ins)}</b></div><div><small>تدفع الآن</small><b>${iqd(payNow(amt, b))}</b></div></div>
      ${why ? `<div class="small" style="color:var(--warn)">${why}</div>` : ''}
      <details class="bk-det" data-det="${b.id}" ${openDet.has(b.id) ? 'open' : ''}><summary>التفاصيل</summary><dl class="kv small">
        <dt>عدد الأقساط</dt><dd><span class="num">${k.t}</span> شهراً</dd>
        <dt>عمولة المصرف ${what('commission')}</dt><dd>${iqd(k.comm)} <span class="num">(${commPct(b)}%)</span></dd>
        <dt>رسوم الملف والكشف والمنصة</dt><dd>${iqd(payNow(amt, b) - k.comm)}</dd>
        <dt>نسبة الربح السنوية ${what('rate')}</dt><dd class="num">${k.rate.toFixed(2)}%</dd>
        ${b.is_islamic ? `<dt>طريقة التمويل</dt><dd>مرابحة ${what('murabaha')}</dd>` : ''}
        <dt>أقصى مدة</dt><dd><span class="num">${b.terms.max_term_months}</span> شهراً</dd>
        <dt>مدة دراسة الطلب</dt><dd><span class="num">${b.terms.processing_days}</span> أيام عمل</dd>
        <dt>الموردون</dt><dd>${b.terms.suppliers?.length ? 'موردون محددون' : 'كل الموردين'}</dd></dl></details>`}
    </label>`; }).join('')}</div>`;
}
// «التفاصيل» داخل بطاقة قابلة للاختيار: تفتح وتُغلق دون أن تغيّر المصرف المختار
function wireBankDetails(root) {
  root.querySelectorAll('.bk-det > summary').forEach(sm => sm.onclick = e => {
    e.preventDefault(); const d = sm.parentElement, id = d.dataset.det;
    d.open = !d.open; d.open ? openDet.add(id) : openDet.delete(id);
  });
}

// 3) المصرف ثم المنظومة المعتمدة لديه: النظام يحسب السعر والقسط وعمولة المصرف حسب نسبته
function step3(wb, app, done, edit) {
  const set = S.ref.set, banks = S.banks.filter(b => b.terms);
  // الجلسة 21 (المقترح 1): المصرف والمنظومة اختيرا عند البدء — هنا تأكيد بضغطة واحدة مع زر «تغيير»، لا اختيار ثانٍ
  if (!done && !edit && app.bank_choice && chosenBank(app) && offerById(app.offer_id)) {
    const o = offerById(app.offer_id), b = chosenBank(app), c = bankCalc(app.amount, b, app.bank_choice.term_months || 60);
    wb.innerHTML = `<h2>تأكيد مصرفك ومنظومتك</h2><p class="muted">هذا ما اخترته عند البدء. إن كان صحيحاً اضغط الزر الأزرق في الأسفل، وبعده ترفع مستنداتك.</p>
      <div class="pick big"><img src="${esc(o.image_url)}" alt=""><div><b style="font-size:18px">${esc(o.title)}</b><div class="small muted">${esc(o.sup?.name)} · <span class="num">${num(o.kw)}</span> كيلوواط ${what('kw')}</div><div class="price">${iqd(o.price)}</div></div></div>
      <div class="bk-two big"><div><small>تدفع شهرياً</small><b>${iqd(c.ins)}</b><em>لمدة <span class="num">${c.t}</span> شهراً</em></div><div><small>تدفع الآن</small><b>${iqd(payNow(app.amount, b))}</b><em>قبل إرسال الطلب</em></div></div>
      <dl class="kv mt"><dt>المصرف</dt><dd>${esc(b.name)}${b.is_islamic ? ` · مرابحة ${what('murabaha')}` : ''}</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[app.guarantee_type] || esc(GUARANTEE[app.guarantee_type])} ${what(app.guarantee_type === 'mortgage' ? 'mortgage' : 'guarantor')}</dd></dl>
      <div class="row mt"><button class="btn ghost" data-chg>تغيير</button><span class="sp"></span><button class="btn cyan" data-ok>صحيح، التالي: المستندات ←</button></div>`;
    wb.querySelector('[data-chg]').onclick = () => step3(wb, app, done, true);
    wb.querySelector('[data-ok]').onclick = async e => {
      e.target.disabled = true;
      try { await saveStep(app, 3, { bank_id: b.id, term_months: c.t }, 'تم تأكيد المصرف والمنظومة', { step: 3, sub: 'docs' }); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
    return;
  }
  if (done && !edit && app.bank_choice) {
    const o = offerById(app.offer_id), b = chosenBank(app), c = b && bankCalc(app.amount, b, app.bank_choice.term_months || 60);
    wb.innerHTML = ''; wb.appendChild(doneBox('المصرف والمنظومة مثبّتان', [['المصرف', esc(b?.name || '—')], ['المنظومة', esc(o?.title)], ['السعر', iqd(app.price)],
      ['عمولة المصرف', c ? `${iqd(c.comm)} <span class="muted small">(${commPct(b)}% — تُدفع قبل الإرسال)</span>` : '—'], ['القسط الشهري', c ? `${iqd(c.ins)} × <span class="num">${c.t}</span> شهراً` : '—'],
      ['الضمان المطلوب', esc(GUARANTEE[app.guarantee_type])]], () => step3(wb, app, done, true), () => goStep(3, 'docs'), 'التالي: المستندات ←')); return;
  }
  let of = app.offer_id, term = Math.min(app.bank_choice?.term_months || app.term_months || 60, set.term_max_months);
  let sel = app.bank_choice?.bank_id || banks.find(b => b.open && accepts(b, offerById(of)?.supplier_id))?.id;
  const paint = () => {
    const sb_ = banks.find(b => b.id === sel), list = sb_ ? S.offers.filter(x => accepts(sb_, x.supplier_id)) : [];
    const o = offerById(of), okO = !!(sb_ && o && accepts(sb_, o.supplier_id)), amt = o?.price || app.amount, g = guaranteeFor(amt), c = okO && bankCalc(amt, sb_, term);
    wb.innerHTML = `<h2>تغيير المصرف أو المنظومة</h2><p class="muted">اختر المصرف، ثم منظومة من الموردين المعتمدين لديه. القسط والمبلغ المدفوع الآن يُحسبان حسب المصرف.</p>
      <h3>1. المصرف ومدة السداد</h3>
      <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${term}</span> شهراً (<span class="num">${(term / 12).toFixed(1)}</span> سنة)</b></div>
      <input type="range" class="range" min="12" max="${set.term_max_months}" step="6" value="${term}" aria-label="مدة السداد">
      ${bankCardsHtml(banks, { amt, term, sel, enabled: b => b.open,
        note: b => !b.open ? 'لا يستقبل طلبات عبر المنصة حالياً' : o && !accepts(b, o.supplier_id) ? 'لا يتعامل مع مورد منظومتك الحالية' : '' })}
      <h3 class="mt">2. المنظومة ${sb_ ? `<span class="small muted">— المعتمدة لدى ${esc(sb_.name)}</span>` : ''}</h3>
      ${o && sb_ && !okO ? `<div class="notice warn">${esc(sb_.name)} لا يتعامل مع مورد منظومتك الحالية (${esc(o.sup?.name)}) — اختر منظومة من القائمة أو مصرفاً آخر.</div>` : ''}
      <div class="pick-list">${S.ref.tiers.map(t => { const os = list.filter(x => x.tier_id === t.id); if (!os.length) return '';
        return `<div class="pl-h"><b>${esc(t.loads)}</b> <span class="small muted">— قدرة <span class="num">${num(t.kw)}</span> كيلوواط</span> ${what('kw')}</div>${os.map(x => { const k = bankCalc(x.price, sb_, term);
          return `<label class="pl ${x.id === of ? 'on' : ''}"><input type="radio" name="of" value="${x.id}" ${x.id === of ? 'checked' : ''}><img src="${esc(x.image_url)}" alt=""><div><b>${esc(x.sup?.name)}</b><div class="small">${stars(x.rating, 12)} <span class="num">${x.rating.toFixed(1)}</span> · ${G_HINT[guaranteeFor(x.price)]}</div><div class="small muted">قسط ${iqd(k.ins)} · عمولة ${iqd(k.comm)}</div></div><span class="sp"></span><b class="small">${iqd(x.price)}</b></label>`; }).join('')}`; }).join('') || '<div class="empty">اختر مصرفاً لعرض منظوماته المعتمدة.</div>'}</div>
      ${c ? `<div class="review"><h3>ما يحسبه النظام</h3><dl class="kv"><dt>سعر المنظومة (مبلغ التمويل)</dt><dd>${iqd(amt)}</dd>
        <dt>عمولة ${esc(sb_.name)} (<span class="num">${commPct(sb_)}%</span>)</dt><dd><b class="cm">${iqd(c.comm)}</b> <span class="muted small">واجبة الدفع قبل إرسال الطلب</span></dd>
        <dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(c.ins)} × <span class="num">${c.t}</span> شهراً</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[g]}${g !== app.guarantee_type ? ' <span class="badge warn">تغيّر — ستعيد خطوة الضمان</span>' : ''}</dd></dl></div>` : ''}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok ${c ? '' : 'disabled'}>${c ? 'تثبيت، التالي: المستندات ←' : 'اختر المصرف والمنظومة'}</button></div>`;
    wb.querySelector('.range').oninput = e => { term = Number(e.target.value); paint(); wb.querySelector('.range').focus(); };
    wb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { sel = r.value; paint(); });
    wireBankDetails(wb);
    wb.querySelectorAll('input[name=of]').forEach(r => r.onchange = () => { of = r.value; paint(); });
    wb.querySelector('[data-ok]').onclick = async e => {
      e.target.disabled = true;
      try { await saveStep(app, 3, { ...(of !== app.offer_id ? { offer_id: of } : {}), bank_id: sel, term_months: c.t }, 'تم تثبيت المصرف والمنظومة', { step: 3, sub: 'docs' }); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  paint();
}

// 4) الضمان: كفلاء بموافقة OTP أو رهن عقار
// الجلسة 31: خطوة الضمان — اختيار النوع (كفيل موظف / ذهب / عقار) ثم نموذجه
function step4(wb, app, done, edit) {
  if (done && !edit && C.czEdit4) { edit = true; C.czEdit4 = false; }
  if (isVet(app) || (done && !edit)) return step4Core(wb, app, done, edit);
  const base = guaranteeFor(app.price), cur = kindOf(app.guarantee_type), opts = guaranteeOptions(base);
  // الجلسة 34: شاشتان — (أ) اختر نوع الضمان ← التالي، (ب) بيانات الضمان المختار. لا شاشة طويلة واحدة
  const G4 = C.czG4 = C.czG4?.id === app.id ? C.czG4 : { id: app.id, picked: false };
  // من اختار نوعاً غير الافتراضي (مثل الذهب) أو أضاف كفلاء يذهب مباشرة إلى بياناته
  if (!G4.picked && app.return_kind !== 'guarantee' && (kindOf(base) !== cur || (app.guarantee?.guarantors || []).length)) G4.picked = true;
  const cOpt = opts.find(o => o[0] === cur) || opts[0];
  if (!G4.picked) {
    let sel = opts.some(o => o[0] === cur) ? cur : opts[0][0];
    const nxt = { salary: 'بيانات الكفيل', gold: 'بيانات الذهب', mortgage: 'بيانات العقار' };
    wb.innerHTML = `<h2>ما الضمان الذي تقدّمه؟ ${what(cur === 'mortgage' ? 'mortgage' : 'guarantor')}</h2>
      <p class="muted" style="margin-top:0">مبلغ تمويلك ${iqd(app.amount)}. اختر واحداً — يمكنك تغييره قبل الإرسال.</p>
      <div class="gpick" role="radiogroup">${opts.map(([k, ic, t, d]) => `<button type="button" role="radio" aria-checked="${k === sel}" data-gk="${k}" class="${k === sel ? 'on' : ''}"><i>${ic}</i><span><b>${t}</b><small>${d}</small></span></button>`).join('')}</div>
      <div class="row mt"><span class="sp"></span><button type="button" class="btn cyan" data-ok>التالي: ${nxt[sel]} ←</button></div>`;
    const ok = wb.querySelector('[data-ok]');
    wb.querySelectorAll('[data-gk]').forEach(b => b.onclick = () => {
      sel = b.dataset.gk; wb.querySelectorAll('[data-gk]').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', x === b); });
      ok.textContent = `التالي: ${nxt[sel]} ←`;
    });
    ok.onclick = async () => {
      if (sel === cur) { G4.picked = true; return step4(wb, app, done, edit); }
      ok.disabled = true;
      try { await rpc(C.sb, 'set_guarantee_kind', { p_app: app.id, p_kind: sel }); G4.picked = true; await load(); C.czStep = 4; pageApply(C.root.querySelector('#cz')); }
      catch (e) { toast(cleanErr(e), 'bad'); ok.disabled = false; }
    };
    return;
  }
  wb.innerHTML = `<div class="g-chosen"><span class="g-ic">${cOpt[1]}</span><span>الضمان: <b>${cOpt[2]}</b></span><span class="sp"></span><button type="button" class="linkbtn" data-gchg>تغيير</button></div>
    <div data-g4></div>`;
  wb.querySelector('[data-gchg]').onclick = () => { G4.picked = false; step4(wb, app, done, edit); };
  const inner = wb.querySelector('[data-g4]');
  if (app.guarantee_type === 'gold') return step4Gold(inner, app);
  step4Core(inner, app, done, edit);
}
function step4Core(wb, app, done, edit) {
  const vet = isVet(app);
  // المشروع البيطري: حدود ضمان المبادرة، والقسط الفعلي بعد السماح
  const set = vet ? { ...S.ref.set, guarantee_t1: S.ref.set.vet_guarantee_t1, guarantee_t2: S.ref.set.vet_guarantee_t2 } : S.ref.set, gt = app.guarantee_type;
  const est = vet ? Number(app.monthly_installment || 0) : installment(app.amount, set.cbi_rate + set.margin_max, 60), need = Math.ceil(est * set.salary_safety);
  if (done && !edit) {
    const g = app.guarantee || {};
    const rows = gt === 'gold' ? [['نوع الضمان', 'رهن ذهب'], ['الذهب', `<span class="num">${num(g.grams)}</span> غرام عيار <span class="num">${esc(g.karat)}</span>${g.items ? ` — ${esc(g.items)}` : ''}`], ['القيمة التقديرية', iqd(g.value)], ['يُسلَّم', 'للفرع بعد الإرسال ليُوزن ويُقيَّم بوصل']]
      : gt === 'mortgage' ? [['نوع الضمان', 'رهن عقار'], ['السند', `<span class="num">${esc(g.deed_no)}</span>`], ['القيمة المرجعية', iqd(g.ref_value)], ['نسبة التمويل للقيمة', `<span class="num">${g.ltv}%</span>`]]
      : [['نوع الضمان', esc(GUARANTEE[gt])], ...(g.guarantors || []).map((x, i) => [`الكفيل ${i + 1}`, `${esc(x.name)} · ${esc(x.employer)} · ${badge([x.consent_via === 'link' ? 'وافق من هاتفه عبر الرابط' : 'وافق برمز التحقق', 'ok'])}`]), ['مجموع الرواتب', iqd(g.total_salary)]];
    wb.innerHTML = ''; wb.appendChild(doneBox('الضمان مؤكد', rows, () => step4(wb, app, done, true))); return;
  }
  const rules = `<div class="rules">${[['single_salary', `حتى ${num(set.guarantee_t1 / 1e6)} مليون`, 'كفيل واحد موظف'], ['multi_salary', `حتى ${num(set.guarantee_t2 / 1e6)} مليون`, 'كفيلان موظفان'], ['mortgage', `أكثر من ${num(set.guarantee_t2 / 1e6)} مليون`, 'رهن عقار']].map(([k, a, b]) => `<div class="${k === gt ? 'on' : ''}"><small>${a}</small><b>${b}</b></div>`).join('')}</div>`;
  if (gt === 'mortgage') return step4Mortgage(wb, app, rules);
  const min = gt === 'single_salary' ? 1 : 2;
  const list = (app.guarantee?.guarantors || []).map(g => ({ ...g, otp: null, link: null, linkOk: false }));
  let rejected = [];   // الجلسة 31: كفلاء رفضتهم وزارة التجارة لهذا الطلب
  const isRej = g => !!g.phone && rejected.some(c => c.phone === normPhone(g.phone));
  const rejWhy = g => (rejected.find(c => c.phone === normPhone(g.phone))?.reasons || []).join('، ');
  const empOf = g => g.ministry === 'trade' ? ((g.dept || '').trim() ? `وزارة التجارة — ${(g.dept || '').trim()}` : '') : (g.employer || '').trim();
  if (!vet) loadGuarantee(C.sb, app).then(x => { rejected = (x?.checks || []).filter(c => c.status === 'rejected'); if (rejected.length && wb.isConnected) paint(); });
  while (list.length < min) list.push({ name: '', phone: '', employer: '', salary: '', relation: 'قريب', otp: null });
  wb.innerHTML = `<h2>الكفيل ${what('guarantor')}</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب <b>${G_HINT[gt]}</b>. يوافق كل كفيل برمز يصل هاتفه: إن كان معك الآن اكتب الرمز هنا، وإن لم يكن معك أرسل له رابطاً فيوافق من هاتفه.</p>${rules}
    <div data-gs></div>
    <div class="cover"><div class="row"><span class="small">مجموع رواتب الكفلاء مقابل المطلوب (${vet ? 'القسط' : 'القسط التقديري'} ${iqd(est)} × <span class="num">${set.salary_safety}</span>)</span><span class="sp"></span><b data-sum></b></div><div class="bar"><i data-bar></i></div></div>
    <div class="row mt"><button class="btn ghost" data-add>＋ إضافة كفيل</button><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const gs = wb.querySelector('[data-gs]');
  const paint = () => {
    const ok = g => !!(g.otp || g.linkOk) && !isRej(g);
    gs.innerHTML = list.map((g, i) => `<fieldset class="gcard ${ok(g) ? 'ok' : ''}" data-i="${i}"><legend>الكفيل ${i + 1} ${isRej(g) ? badge(['رفضته وزارة التجارة', 'bad']) : ok(g) ? badge([g.linkOk ? 'وافق من هاتفه' : 'وافق', 'ok']) : g.declined ? badge(['اعتذر عن الكفالة', 'bad']) : g.link ? badge(['أرسلنا له رابطاً — بانتظار موافقته', 'info']) : badge(['بانتظار الموافقة', 'warn'])}</legend>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>الاسم الثلاثي</label><input class="input" data-k="name" value="${esc(g.name)}"></div>
        <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(g.phone)}"></div>
        <div class="field"><label>أين يعمل؟</label><select class="input" data-k="ministry"><option value="">جهة أخرى (دائرة أو شركة)</option><option value="trade" ${g.ministry === 'trade' ? 'selected' : ''}>وزارة التجارة</option></select></div>
        ${g.ministry === 'trade' ? `<div class="field"><label>دائرته في وزارة التجارة</label><input class="input" data-k="dept" list="motdepts" placeholder="اختر أو اكتب" value="${esc(g.dept || '')}"></div>`
          : `<div class="field"><label>اسم جهة العمل</label><input class="input" data-k="employer" value="${esc(g.employer)}"></div>`}
        <div class="field"><label>الراتب الشهري (د.ع)</label><input class="input" data-k="salary" inputmode="numeric" dir="ltr" value="${esc(g.salary)}"></div>
        ${vet ? '' : `<div class="field"><label>المصرف الذي يستلم فيه راتبه <span class="muted small">(اختياري — يسرّع طلبك)</span></label><select class="input" data-k="salary_bank_id"><option value="">لا أعرف</option>${C.orgs.filter(x => x.type === 'bank').map(b => `<option value="${b.id}" ${g.salary_bank_id === b.id ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>
        <div class="field"><label>رقم حساب راتبه أو IBAN <span class="muted small">(اختياري)</span></label><input class="input" data-k="salary_account" dir="ltr" value="${esc(g.salary_account || '')}"></div>`}
        <div class="field"><label>صلة القرابة</label><select class="input" data-k="relation">${['قريب', 'زميل عمل', 'صديق', 'جار'].map(r => `<option ${r === g.relation ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
        <div class="field" style="justify-content:flex-end"><div class="row" style="flex-wrap:wrap;gap:6px">${ok(g) ? `<span class="ok-ic sm">✓</span><span class="small">${g.linkOk ? 'وافق الكفيل من هاتفه عبر الرابط' : 'وافق الكفيل على الكفالة'}</span>`
          : `${isRej(g) ? '' : `<button type="button" class="btn sm" data-consent="${i}">الكفيل معي — رمز الموافقة</button>`}${vet || isRej(g) ? '' : `<button type="button" class="btn cyan sm" data-glink="${i}">${g.link ? 'أعد إرسال الرابط' : 'أرسل له رابطاً'}</button>`}`}${list.length > min ? `<span class="sp"></span><button type="button" class="linkbtn" data-rm="${i}">حذف</button>` : ''}</div></div>
      </div>${g.ministry === 'trade' && !isRej(g) ? '<p class="small muted" style="margin:0 0 10px">🏪 تصل وزارة التجارة طلب تأييد راتبه آلياً بعد الإرسال: يُقبل إن كان راتبه حراً (غير ضامن لقرض آخر ولم يسحب سلفة) ويغطي حصته من القسط.</p>' : ''}
      ${isRej(g) ? `<div class="notice bad" style="margin:0 0 10px"><span>✕</span><span><b>رفضت وزارة التجارة كفالته:</b> ${esc(rejWhy(g))}<div class="mt"><button type="button" class="btn sm" data-swap="${i}">استبدله بكفيل آخر</button></div></span></div>` : ''}</fieldset>`).join('') + `<datalist id="motdepts">${MOT_DEPTS.map(x => `<option value="${esc(x)}">`).join('')}</datalist>`;
    gs.querySelectorAll('[data-k]').forEach(inp => inp.oninput = inp.onchange = () => {
      const i = Number(inp.closest('[data-i]').dataset.i), k = inp.dataset.k;
      const old = list[i][k]; list[i][k] = inp.value;
      if (k === 'ministry') { if (inp.value === 'trade') list[i].employer = ''; paint(); return; }
      if (k === 'phone' && list[i].otp && normPhone(old) !== normPhone(inp.value)) { list[i].otp = null; paint(); }
      // الموافقة عبر الرابط على بيانات بعينها — تغييرها يلغي الموافقة ويلزم رابطاً جديداً
      if (['name', 'phone', 'salary'].includes(k) && list[i].link && old !== inp.value) { list[i].link = null; list[i].linkOk = false; list[i].declined = false; paint(); }
      sum();
    });
    gs.querySelectorAll('[data-consent]').forEach(b => b.onclick = async () => {
      const g = list[Number(b.dataset.consent)];
      const ph = normPhone(g.phone);
      if (g.name.trim().split(/\s+/).length < 3) return toast('اكتب الاسم الثلاثي للكفيل', 'bad');
      if (!validPhone(ph)) return toast('رقم هاتف الكفيل غير صحيح', 'bad');
      if (ph === C.profile.phone) return toast('لا يكفل المتقدم نفسه', 'bad');
      if (list.some(x => x !== g && normPhone(x.phone) === ph)) return toast('رقم هاتف مكرر بين الكفلاء', 'bad');
      const c = await askOtp({ kind: 'guarantor', ref: app.id, title: `موافقة الكفيل ${g.name.split(' ')[0]}`, phone: ph, purpose: `يوافق على كفالة ${C.profile.full_name} في تمويل ${num(app.amount)} د.ع`, verify: serverOtp(C.sb, ph, 'guarantor') });
      if (c) { g.phone = ph; g.otp = c; paint(); toast('سُجّلت موافقة الكفيل', 'ok'); }
    });
    gs.querySelectorAll('[data-glink]').forEach(b => b.onclick = async () => {
      const i = Number(b.dataset.glink), g = list[i];
      const ph = normPhone(g.phone);
      if (g.name.trim().split(/\s+/).length < 3) return toast('اكتب الاسم الثلاثي للكفيل', 'bad');
      if (!validPhone(ph)) return toast('رقم هاتف الكفيل غير صحيح', 'bad');
      if (!empOf(g)) return toast(g.ministry === 'trade' ? 'اختر دائرة الكفيل في وزارة التجارة' : 'اكتب جهة عمل الكفيل', 'bad');
      if (!(Number(digits(g.salary)) >= 250000)) return toast('اكتب راتب الكفيل', 'bad');
      try {
        const r = await rpc(C.sb, 'link_create', { p_app: app.id, p_kind: 'guarantor', p_data: { i, name: g.name.trim(), phone: ph, employer: empOf(g), salary: Number(digits(g.salary)), relation: g.relation } });
        g.phone = ph; g.link = r.token; g.linkOk = false; g.declined = false; paint(); watch();
        shareLink({ title: `أرسل رابط الموافقة إلى ${g.name.split(' ')[0]}`, url: `${location.origin}/l/${r.token}`, expires: r.expires_at, sms: { sb: C.sb, token: r.token, masked: maskPhone(ph) },
          text: `السلام عليكم ${g.name.split(' ')[0]}، أرجو أن توافق على كفالتي في تمويل منظومة شمسية عبر منصة ألواح — افتح الرابط واقرأ التفاصيل ثم اكتب الرمز الذي يصل هاتفك:` });
      } catch (e) { toast(cleanErr(e), 'bad'); }
    });
    gs.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { list.splice(Number(b.dataset.rm), 1); paint(); });
    gs.querySelectorAll('[data-swap]').forEach(b => b.onclick = () => { list[Number(b.dataset.swap)] = { name: '', phone: '', employer: '', ministry: '', dept: '', salary: '', relation: 'زميل عمل', otp: null }; paint(); gs.querySelector(`[data-i="${b.dataset.swap}"] input`)?.focus(); });
    wb.querySelector('[data-add]').hidden = list.length >= 3;
    sum();
  };
  const sum = () => {
    const t = list.reduce((s, g) => s + (Number(digits(g.salary)) || 0), 0);
    wb.querySelector('[data-sum]').innerHTML = `${iqd(t)} / ${iqd(need)}`;
    const b = wb.querySelector('[data-bar]'); b.style.width = Math.min(100, t / need * 100) + '%'; b.style.background = t >= need ? 'var(--ok)' : 'var(--sun)';
  };
  wb.querySelector('[data-add]').onclick = () => { list.push({ name: '', phone: '', employer: '', salary: '', relation: 'زميل عمل', otp: null }); paint(); };
  wb.querySelector('[data-ok]').onclick = async e => {
    if (list.some(isRej)) return toast('استبدل الكفيل الذي رفضته وزارة التجارة بكفيل آخر — أو اختر رهن ذهب أو عقار من الأعلى', 'bad');
    if (list.some(g => !g.otp && !g.linkOk)) return toast(list.some(g => g.link && !g.linkOk) ? 'بانتظار موافقة الكفيل من هاتفه — يظهر هنا فور موافقته' : 'يلزم أن يوافق كل كفيل برمز التحقق', 'bad');
    e.target.disabled = true;
    try { await saveStep(app, 4, { guarantors: list.map(g => ({ name: g.name.trim(), phone: normPhone(g.phone), employer: empOf(g), ministry: g.ministry || null, dept: g.ministry === 'trade' ? (g.dept || '').trim() : null, salary_bank_id: g.salary_bank_id || null, salary_account: (g.salary_account || '').replace(/\s/g, '') || null, salary: Number(digits(g.salary)), relation: g.relation, otp: g.otp, link: g.linkOk ? g.link : null })) }, 'تم تأكيد الضمان'); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  // الجلسة 22 (المقترح 9): روابط الكفلاء — نعرض الروابط المرسلة سابقاً ونتابع موافقتهم لحظياً
  let timer = null;
  const sync = async () => {
    if (!wb.isConnected) { clearInterval(timer); return; }
    const r = await C.sb.from('app_links').select('token,g_index,data,result,used_at,revoked_at,expires_at').eq('application_id', app.id).eq('kind', 'guarantor').is('revoked_at', null).order('created_at');
    let changed = false;
    (r.data || []).forEach(l => {
      let g = list.find(x => x.link === l.token);
      if (!g) {   // بعد إعادة فتح الصفحة: نعيد ربط الرابط بكفيله
        const i = l.g_index ?? 0; while (list.length <= i) list.push({ name: '', phone: '', employer: '', salary: '', relation: 'قريب', otp: null });
        g = list[i]; if (g.otp) return;
        if (!g.name || normPhone(g.phone) === l.data.phone) { Object.assign(g, { name: l.data.name, phone: l.data.phone, employer: l.data.employer, salary: String(l.data.salary), relation: l.data.relation || g.relation, link: l.token }); changed = true; } else return;
      }
      const okNow = l.result?.accepted === true, dec = l.result && l.result.accepted === false;
      if (okNow !== !!g.linkOk || dec !== !!g.declined) { g.linkOk = okNow; g.declined = dec; changed = true; if (okNow) toast(`وافق ${g.name.split(' ')[0]} على الكفالة من هاتفه ✓`, 'ok'); }
    });
    if (changed) paint();
    if (!list.some(g => g.link && !g.linkOk && !g.declined)) { clearInterval(timer); timer = null; }
  };
  const watch = () => { if (!timer) timer = setInterval(sync, 6000); };
  paint();
  if (!vet) sync().then(watch).catch(() => {});
}
// قراءة السند العقاري آلياً عبر خدمة القراءة إن كانت تدعمه (وإلا يُكمل المقترض يدوياً)
async function readDeed(dataUrl) {
  const base = ((window.ALWAH_CONFIG || {}).ocr || '').replace(/\/+$/, ''); if (!base) return null;
  const blob = await (await fetch(dataUrl)).blob(), body = new FormData(); body.append('front', blob, 'deed.jpg');
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 25000);
  try {
    const r = await fetch(base + '/api/v1/documents/property-deed', { method: 'POST', body, signal: ctl.signal });
    if (!r.ok) return null;
    const d = await r.json(), f = d.fields || {}, v = k => String((f[k] && typeof f[k] === 'object' ? f[k].value : f[k]) || '').trim();
    const out = { deed_no: v('deed_no') || v('deed_number'), owner_name: v('owner_name'), owner_national_id: v('owner_national_id').replace(/\D/g, ''),
      district: v('district') || v('muqataa'), land_area: v('land_area').replace(/[^\d.]/g, ''), governorate: v('governorate'), use_type: v('use_type') };
    return out.deed_no || out.owner_name ? out : null;
  } catch { return null; } finally { clearTimeout(t); }
}
const nameKey = n => String(n || '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim().split(' ').slice(0, 3).join(' ');

function step4Mortgage(wb, app, rules) {
  const set = S.ref.set, g = app.guarantee || {}, own0 = app.ownership || {};
  const st = { owner: own0.is_owner === false ? 'other' : own0.is_owner ? 'self' : '', deed: null, poa: null, oid: null, otp: null, read: null };
  wb.innerHTML = `<h2>رهن عقار ${what('mortgage')}</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب رهن عقار. يحيله المصرف إلكترونياً إلى دائرة التسجيل العقاري للتحقق من خلوه ومطابقة السند، ثم يُؤشَّر الرهن بعد موافقة إدارة المصرف.</p>${rules}
    <div class="card soft mb"><h3>1. صوّر سند العقار</h3><p class="small muted" style="margin-top:0">بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف. نحاول قراءة السند ومطابقته مع بياناتك تلقائياً.</p>
      <div class="doc-row" data-deedbox>${docThumb(null, 'سند العقار')}</div><button type="button" class="btn cyan sm" data-shoot="deed">📷 تصوير السند</button>
      <div class="idbusy" data-deedbusy hidden><i></i><span>جارِ قراءة السند ومطابقته…</span></div><div data-deedres></div></div>
    <div class="card soft mb"><h3>2. علاقتك بالعقار</h3>
      <div class="seg" style="margin-bottom:10px"><button type="button" data-own="self">أنا المالك</button><button type="button" data-own="other">المالك شخص آخر</button></div>
      <div data-other hidden>
        <p class="small muted" style="margin-top:0">يلزم <b>وكالة من مالك العقار بالرهن</b> مصوّرة بالكاميرا، مع بيانات المالك ورقم هاتفه. نرسل للمالك رمز تحقق يُدخله هنا موافقةً على الرهن.</p>
        <div class="grid g2" style="gap:12px">
          <div class="field"><label>صلتك بالمالك</label><select class="input" data-o="relation">${['وكيل عن المالك', 'أب أو أم', 'زوج أو زوجة', 'أخ أو أخت', 'ابن أو ابنة', 'قريب آخر', 'شريك'].map(r => `<option ${r === own0.relation ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
          <div class="field"><label>اسم المالك الثلاثي كما في السند</label><input class="input" data-o="owner_name" value="${esc(own0.is_owner === false ? own0.owner_name || '' : '')}"></div>
          <div class="field"><label>الرقم الوطني للمالك (12 رقماً)</label><input class="input" data-o="owner_national_id" inputmode="numeric" dir="ltr" maxlength="12" value="${esc(own0.is_owner === false ? own0.owner_national_id || '' : '')}"></div>
          <div class="field"><label>رقم هاتف المالك</label><input class="input" data-o="owner_phone" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(own0.owner_phone || '')}"></div>
        </div>
        <div class="doc-row" data-poabox>${docThumb(null, 'وكالة المالك بالرهن')}</div>
        <div class="row" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn sm" data-shoot="poa">📷 تصوير الوكالة</button><button type="button" class="btn ghost sm" data-shoot="owner_id_front">📷 بطاقة المالك (اختياري)</button></div>
        <div class="row mt" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn cyan sm" data-consent>إرسال رمز الموافقة لهاتف المالك</button><span class="small" data-consented></span></div>
      </div></div>
    <div class="card soft mb"><h3>3. بيانات العقار</h3>
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>رقم السند العقاري (القطعة/المقاطعة) كما في الصورة</label><input class="input" data-k="deed_no" value="${esc(g.deed_no || own0.deed_no || '')}" placeholder="مثال: 1452/87 الكرادة"></div>
      <div class="field"><label>المحافظة</label><select class="input" data-k="governorate">${govOptions(app.governorate)}</select></div>
      <div class="field"><label>المنطقة أو المقاطعة</label><input class="input" data-k="district" value=""></div>
      <div class="field"><label>نوع الاستعمال</label><select class="input" data-k="use_type"><option>سكني</option><option>تجاري</option><option>زراعي</option></select></div>
      <div class="field"><label>مساحة الأرض (م²)</label><input class="input" data-k="land_area" inputmode="numeric" dir="ltr"></div>
      <div class="field"><label>القيمة التقديرية (د.ع)</label><input class="input" data-k="estimated_value" inputmode="numeric" dir="ltr" value="${esc(g.ref_value || '')}"></div>
    </div>
    <div class="cover"><div class="row"><span class="small">نسبة التمويل إلى قيمة العقار (الحد الأعلى <span class="num">${set.ltv_max}%</span>)</span><span class="sp"></span><b data-ltv>—</b></div><div class="bar"><i data-bar></i></div></div></div>
    <p class="small muted">تُطابق المنصة اسم المالك ورقمه الوطني مع السجل العقاري إن كان السند مسجلاً، وإلا تطابقها دائرة التسجيل العقاري مع صورة السند.</p>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const val = () => Number(digits(wb.querySelector('[data-k=estimated_value]').value));
  const upd = () => { const v = val(), r = v ? app.amount / v * 100 : 0, b = wb.querySelector('[data-bar]');
    wb.querySelector('[data-ltv]').innerHTML = v ? `<span class="num">${r.toFixed(1)}%</span>` : '—'; b.style.width = Math.min(100, r / set.ltv_max * 100) + '%'; b.style.background = r <= set.ltv_max ? 'var(--ok)' : 'var(--bad)'; };
  wb.querySelector('[data-k=estimated_value]').oninput = upd; upd();
  const paintOwn = () => {
    wb.querySelectorAll('[data-own]').forEach(b => b.classList.toggle('on', b.dataset.own === st.owner));
    wb.querySelector('[data-other]').hidden = st.owner !== 'other';
    wb.querySelector('[data-consented]').innerHTML = st.otp ? '<span class="ok-ic sm">✓</span> وافق المالك على الرهن' : '';
  };
  wb.querySelectorAll('[data-own]').forEach(b => b.onclick = () => { st.owner = b.dataset.own; paintOwn(); });
  paintOwn();
  const setK = (k, v) => { const i = wb.querySelector(`[data-k=${k}]`); if (!i || !v) return; if (i.tagName === 'SELECT') { const o = [...i.options].find(x => x.text === v || x.value === v); if (o) i.value = o.value; } else i.value = v; };
  const setO = (k, v) => { const i = wb.querySelector(`[data-o=${k}]`); if (i && v) i.value = v; };
  // بعد تصوير السند: قراءة آلية ثم مطابقة اسم المالك مع اسم المقترض
  const afterDeed = async shot => {
    const busy = wb.querySelector('[data-deedbusy]'), res = wb.querySelector('[data-deedres]');
    busy.hidden = false; res.innerHTML = '';
    const r = await readDeed(shot.data); busy.hidden = true; st.read = r;
    if (!r) { res.innerHTML = '<div class="notice warn" style="margin:10px 0 0">تعذرت قراءة السند تلقائياً — حدّد علاقتك بالعقار واكتب رقم السند كما في الصورة.</div>'; return; }
    ['deed_no', 'district', 'land_area', 'use_type', 'governorate'].forEach(k => setK(k, r[k]));
    const mine = r.owner_name && nameKey(r.owner_name) === nameKey(C.profile.full_name) && (!r.owner_national_id || r.owner_national_id === C.profile.national_id);
    if (mine) { st.owner = 'self'; res.innerHTML = `<div class="idnote ok" style="margin:10px 0 0">✓ قرأنا السند <b class="num">${esc(r.deed_no)}</b> — العقار مسجل باسمك</div>`; }
    else {
      st.owner = 'other'; setO('owner_name', r.owner_name); setO('owner_national_id', r.owner_national_id);
      res.innerHTML = `<div class="notice warn" style="margin:10px 0 0">قرأنا السند <b class="num">${esc(r.deed_no || '')}</b>${r.owner_name ? ` باسم <b>${esc(r.owner_name)}</b>` : ''} — لا يطابق اسمك. صوّر وكالة المالك بالرهن وأكمل بياناته وموافقته.</div>`;
    }
    paintOwn();
  };
  const LBL = { deed: 'سند العقار', poa: 'وكالة المالك بالرهن', owner_id_front: 'البطاقة الوطنية للمالك' };
  wb.querySelectorAll('[data-shoot]').forEach(b => b.onclick = async () => {
    const kind = b.dataset.shoot;
    const shot = await cameraCapture({ title: kind === 'deed' ? 'صوّر سند العقار' : kind === 'poa' ? 'صوّر وكالة المالك بالرهن (الصفحة كاملة)' : 'صوّر وجه البطاقة الوطنية لمالك العقار', ratio: kind === 'owner_id_front' ? 1.586 : 0.72 });
    if (!shot) return;
    b.disabled = true;
    try {
      await rpc(C.sb, 'add_document', { p_app: app.id, p_kind: kind, p_data: shot.data, p_source: 'camera', p_meta: shot.meta });
      st[{ deed: 'deed', poa: 'poa', owner_id_front: 'oid' }[kind]] = shot;
      const box = wb.querySelector(kind === 'deed' ? '[data-deedbox]' : '[data-poabox]');
      if (kind === 'owner_id_front') box.insertAdjacentHTML('beforeend', docThumb({ ...shot, source: 'camera' }, LBL[kind]));
      else box.innerHTML = docThumb({ ...shot, source: 'camera' }, LBL[kind]) + (kind === 'poa' && st.oid ? docThumb({ ...st.oid, source: 'camera' }, LBL.owner_id_front) : '');
      toast('حُفظت الصورة مع طلبك', 'ok');
      if (kind === 'deed') afterDeed(shot);
    } catch (e) { toast(cleanErr(e), 'bad'); }
    b.disabled = false;
  });
  const ownerData = () => { const d = {}; wb.querySelectorAll('[data-o]').forEach(i => d[i.dataset.o] = i.value.trim()); d.owner_national_id = digits(d.owner_national_id); d.owner_phone = normPhone(d.owner_phone); return d; };
  wb.querySelector('[data-consent]').onclick = async () => {
    const d = ownerData();
    if (!st.poa) return toast('صوّر وكالة المالك بالرهن أولاً', 'bad');
    if (d.owner_name.split(/\s+/).length < 3) return toast('اكتب اسم المالك الثلاثي', 'bad');
    if (!/^\d{12}$/.test(d.owner_national_id)) return toast('الرقم الوطني للمالك 12 رقماً', 'bad');
    if (!validPhone(d.owner_phone)) return toast('رقم هاتف المالك غير صحيح', 'bad');
    if (d.owner_phone === C.profile.phone) return toast('هذا رقم هاتفك — اكتب رقم هاتف المالك', 'bad');
    const c = await askOtp({ kind: 'owner', ref: app.id, title: 'موافقة مالك العقار', phone: d.owner_phone, purpose: `يوافق على رهن عقاره ضماناً لتمويل ${C.profile.full_name} بمبلغ ${num(app.amount)} د.ع`, verify: serverOtp(C.sb, d.owner_phone, 'owner') });
    if (c) { st.otp = c; paintOwn(); }
  };
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = {}; wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    d.estimated_value = String(val()); d.land_area = digits(d.land_area);
    if (!st.deed && !app.ownership) return toast('صوّر سند العقار بكاميرا الهاتف أولاً', 'bad');
    if (!st.owner) return toast('حدّد علاقتك بالعقار: أنت المالك أم شخص آخر؟', 'bad');
    if (!d.deed_no) return toast('اكتب رقم السند العقاري', 'bad');
    const od = st.owner === 'other' ? ownerData() : {};
    if (st.owner === 'other' && !st.poa && !(app.ownership && app.ownership.is_owner === false)) return toast('صوّر وكالة المالك بالرهن', 'bad');
    if (st.owner === 'other' && !st.otp) return toast('يلزم موافقة مالك العقار برمز التحقق', 'bad');
    e.target.disabled = true;
    try {
      await rpc(C.sb, 'set_property_ownership', { p_app: app.id, p_data: { is_owner: st.owner === 'self', deed_no: d.deed_no, ...od, owner_otp: st.otp, auto_read: !!st.read } });
      await saveStep(app, 4, d, 'تم تأكيد ضمان الرهن');
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 5) دفع عمولة المصرف والرسوم ثم التوقيع الإلكتروني وإرسال الطلب
// الجلسة 22 (المقترح 10): زر إصلاح كل نقص يذهب إلى مكانه مباشرة
// ───────── الجلسة 31: رهن الذهب ─────────
function step4Gold(wb, app) {
  const set = S.ref.set, price = Number(set.gold_gram_21 || 130000), ltv = Number(set.gold_ltv || 80), g = app.guarantee || {};
  const needVal = Math.ceil(app.amount * 100 / ltv);
  const st = { grams: g.grams || '', karat: Number(g.karat || 21), items: g.items || '' };
  wb.innerHTML = `<h2>رهن ذهب</h2>
    <p class="muted" style="margin-top:0">اكتب وزن ذهبك وعياره — نحسب قيمته التقديرية فوراً. بعد الإرسال تسلّمه إلى الفرع فيُوزن ويُقيَّم بوصل، ويعود إليك كاملاً بعد سداد آخر قسط.</p>
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>الوزن (غرام)</label><input class="input" data-grams inputmode="decimal" dir="ltr" placeholder="مثل 75" value="${esc(st.grams)}"></div>
      <div class="field"><label>العيار</label><div class="seg sm" data-karat>${[21, 18, 22, 24].map(k => `<button type="button" data-v="${k}" class="${k === st.karat ? 'on' : ''}">${k}</button>`).join('')}</div></div>
    </div>
    <div class="field"><label>ما هو؟ (اختياري)</label><input class="input" data-items placeholder="مثل: سوار وقلادة وخاتمان" value="${esc(st.items)}"></div>
    <div class="gold-calc"><div class="row small"><span>القيمة التقديرية مقابل المطلوب</span><span class="sp"></span><b data-sum></b></div><div class="bar"><i data-bar></i></div>
      <p class="small muted" style="margin:6px 0 0" data-hint></p></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const val = () => Math.round((Number(String(st.grams).replace(/[^\d.]/g, '')) || 0) * price * st.karat / 21);
  const sum = () => {
    const v = val(), okv = v >= needVal;
    wb.querySelector('[data-sum]').innerHTML = `${iqd(v)} / ${iqd(needVal)}`;
    const b = wb.querySelector('[data-bar]'); b.style.width = Math.min(100, v / needVal * 100) + '%'; b.style.background = okv ? 'var(--ok)' : 'var(--sun)';
    wb.querySelector('[data-hint]').innerHTML = okv ? '✓ ذهبك يكفي لضمان تمويلك.'
      : `يلزم ذهب بقيمة ${iqd(needVal)} على الأقل — نحو <b class="num">${num(Math.ceil(needVal / (price * st.karat / 21)))}</b> غرام عيار ${st.karat}. (سعر غرام عيار 21 للتقييم: ${iqd(price)})`;
  };
  wb.querySelector('[data-grams]').oninput = e => { st.grams = e.target.value; sum(); };
  wb.querySelector('[data-items]').oninput = e => { st.items = e.target.value; };
  wb.querySelectorAll('[data-karat] button').forEach(b => b.onclick = () => { st.karat = Number(b.dataset.v); wb.querySelectorAll('[data-karat] button').forEach(x => x.classList.toggle('on', x === b)); sum(); });
  wb.querySelector('[data-ok]').onclick = async e => {
    if (val() < needVal) return toast('قيمة الذهب لا تكفي — زد الوزن أو اختر ضماناً آخر من الأعلى', 'bad');
    e.target.disabled = true;
    try { await saveStep(app, 4, { grams: String(st.grams).replace(/[^\d.]/g, ''), karat: st.karat, items: st.items }, 'تم تأكيد رهن الذهب'); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  sum();
}

// ───────── الجلسة 31: أعاد المصرف الطلب لاستبدال الضمان — شاشة واحدة واضحة بخطوتين ─────────
function homeGuaranteeReturn(body, app, first) {
  const bank = C.orgs.find(x => x.id === (app.bank_id || app.bank_choice?.bank_id));
  const base = guaranteeFor(app.price), cur = kindOf(app.guarantee_type), gDone = app.stage >= 5 && !!app.guarantee;
  const why = String(app.return_note || '').replace(/★\s*/g, '• ');
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>طلب رقم <b class="num">${esc(app.code)}</b> ${badge(['أُعيد إليك — يحتاج ضماناً آخر', 'warn'])}</p></div></div>
    <div class="ret-card">
      <h2>الضمان الذي قدّمته لم يُقبل</h2>
      <p class="small muted" style="margin:0">${esc(app.returned_by_title || bank?.name || 'المصرف')} · ${dt(app.returned_at)}</p>
      <div class="why">${esc(why)}</div>
      <p style="margin:0 0 12px"><b>المطلوب منك:</b> اختر ضماناً آخر من هاتفك ثم وقّع وأرسل. يبقى رقم طلبك وكل بياناته وعمولتك المدفوعة، ويعود الطلب إلى ${esc(bank?.name || 'المصرف')} ليوافق مدير الفرع على ضمانك الجديد ثم يكمل من حيث توقف — لا تبدأ من جديد ولا تراجع الفرع.</p>
      <div class="gpick">${guaranteeOptions(base).map(([k, ic, t, d]) => `<button type="button" data-gk="${k}" class="${gDone && k === cur ? 'on' : ''}"><i>${ic}</i><span><b>${k === 'salary' ? 'كفيل موظف آخر' : t}</b><small>${d}</small></span></button>`).join('')}</div>
      <ol class="ret-steps">
        <li class="${gDone ? 'done' : 'cur'}"><span class="n">${gDone ? '✓' : '1'}</span><span class="t"><b>اختر الضمان الجديد</b><small>${gDone ? `${esc(GUARANTEE[app.guarantee_type])} — تم` : 'اضغط أحد الأزرار أعلاه'}</small></span>${gDone ? '<button type="button" class="btn ghost sm" data-g4>تعديل</button>' : ''}</li>
        <li class="${gDone ? 'cur' : ''}"><span class="n">2</span><span class="t"><b>وقّع وأعد الإرسال</b><small>برمز يصل هاتفك — دون دفع مرة أخرى</small></span></li>
      </ol>
      ${gDone ? '<button type="button" class="btn cyan big-btn mt" data-g5>وقّع وأعد الإرسال الآن ←</button>' : '<p class="small muted" style="margin:10px 0 0">↑ ابدأ باختيار الضمان الجديد من الأزرار أعلاه.</p>'}
      <div data-retlist></div>
    </div>
    <div data-fixbox></div>
    ${pastApps(app.id)}`;
  mountSmsBanner(C.sb, C.profile, body);
  body.querySelectorAll('[data-gk]').forEach(b => b.onclick = async () => {
    const k = b.dataset.gk;
    body.querySelectorAll('[data-gk]').forEach(x => x.disabled = true);
    try {
      if (k !== cur) { await rpc(C.sb, 'set_guarantee_kind', { p_app: app.id, p_kind: k }); await load(); }
      else C.czEdit4 = true;   // النوع نفسه (كفيل آخر): نفتح الخطوة للتعديل مباشرة
      C.czStep = 4; C.czSub = null; location.hash = '#apply';
    } catch (e) { toast(cleanErr(e), 'bad'); body.querySelectorAll('[data-gk]').forEach(x => x.disabled = false); }
  });
  const g4 = body.querySelector('[data-g4]'); if (g4) g4.onclick = () => { C.czEdit4 = true; C.czStep = 4; location.hash = '#apply'; };
  const g5 = body.querySelector('[data-g5]'); if (g5) g5.onclick = () => { C.czStep = 5; C.czSub = null; location.hash = '#apply'; };
  // نواقص أخرى في الطلب (إن وُجدت) — كل نقص بزر يصلحه
  const rl = body.querySelector('[data-retlist]');
  Promise.all([rpc(C.sb, 'intake_checklist', { p_app: app.id }).catch(() => null), loadFix(C.sb, app.id).catch(() => [])]).then(([ck, reqs]) => {
    const miss = (ck?.items || []).filter(i => !i.ok && !['payment', 'signed', 'guarantee', 'deed'].includes(i.key) && i.fix !== 'req');
    if (miss.length) rl.innerHTML = `<p class="small" style="margin:12px 0 6px"><b>ونقص آخر في طلبك يلزم إكماله قبل الإرسال — اضغط كل سطر:</b></p><div class="fix-rows">${miss.map(i => fixRow(i.label, i.fix, i.key)).join('')}</div>`;
    rl.querySelectorAll('[data-fix]').forEach(b => b.onclick = () => fixGo(b.dataset.fix, b.dataset.key));
    mountBorrowerFix(body.querySelector('[data-fixbox]'), reqs, { sb: C.sb, onDone: () => homeGuaranteeReturn(body, app, first) });
  });
}

// الجلسة 35: «أصلح الآن» يفتح الشاشة المعنية مباشرة — المستندات تفتح شاشة «ارفع مستنداتك»
function fixGo(fix, key) {
  if (fix === 'profile') { location.hash = '#profile'; return; }
  const cz = C.root.querySelector('#cz');
  const scrollTo = sel => setTimeout(() => C.root.querySelector('#cz')?.querySelector(sel)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
  if (fix === 'req') { location.hash = '#home'; scrollTo('[data-fixbox]'); return; }
  if (fix === 'site' || key === 'site') { C.czStep = 5; C.czSub = { step: 5, v: 'review' }; }
  else { C.czStep = Number(fix) || null; C.czSub = Number(fix) === 3 && DOC_KEYS.includes(key) ? { step: 3, v: 'docs' } : null; }
  if (location.hash !== '#apply') location.hash = '#apply'; else { pageApply(cz); window.scrollTo(0, 0); }
  if (fix === 'site' || key === 'site') scrollTo('#wsite');
}
// الجلسة 35: الدفع والإرسال بثلاث شاشات قصيرة — راجع ← ادفع ← وقّع، بزر واحد في كل شاشة
function step5(wb, app) {
  const o = offerById(app.offer_id), bk = chosenBank(app);
  if (!bk || !bk.terms) {
    wb.innerHTML = `<h2>الدفع والإرسال</h2><div class="notice warn">لم يُختر المصرف بعد — اختره مع المنظومة لنحسب العمولة.</div><div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>اختيار المصرف ←</button></div>`;
    wb.querySelector('[data-go]').onclick = () => goStep(3); return;
  }
  const c = bankCalc(app.amount, bk, app.bank_choice?.term_months || 60), f = feeItems(app.amount, bk), tot = f.reduce((t, x) => t + x[1], 0);
  let paid = null, method = 'zaincash', ck = null, ckDone = false, ack = false;
  wb.innerHTML = '<div class="cz-load"><div class="spin"></div><span>جارِ التحميل…</span></div>';
  C.sb.from('payments').select('*').eq('application_id', app.id).then(r => { paid = r.data || []; paint(); });
  rpc(C.sb, 'intake_checklist', { p_app: app.id }).then(x => { ck = x; }).catch(() => {}).finally(() => { ckDone = true; paint(); });
  const isPaid = () => (paid || []).find(x => x.bank_id === bk.id && x.status === 'paid');
  const blockers = () => (ck?.items || []).filter(i => !i.ok && !['payment', 'signed'].includes(i.key));
  const go = v => { C.czSub = { step: 5, v }; pageApply(C.root.querySelector('#cz')); window.scrollTo(0, 0); };
  const subs = () => { const p = !!isPaid() && app.return_kind === 'guarantee'; return p ? [['review', 'راجع'], ['sign', 'وقّع وأرسل']] : [['review', 'راجع'], ['pay', isPaid() ? 'ادفع ✓' : 'ادفع'], ['sign', 'وقّع وأرسل']]; };
  const subBar = cur => { const L = subs(), i = L.findIndex(x => x[0] === cur);
    return `<ol class="sub-steps" aria-label="خطوات الإرسال">${L.map(([, t], j) => `<li class="${j < i ? 'done' : j === i ? 'cur' : ''}">${j < i ? '✓ ' : ''}${t}</li>`).join('')}</ol>`; };
  const paint = () => {
    if (!paid || !ckDone || !wb.isConnected) return;
    const p = isPaid();
    let sub = C.czSub?.step === 5 ? C.czSub.v : (p && !blockers().length && app.site_geo ? 'sign' : 'review');
    if (sub === 'pay' && p) sub = 'sign';
    if (sub === 'sign' && !p) sub = 'pay';
    const bl = blockers(), needSite = !app.site_geo && !bl.some(i => i.key === 'site');
    if (sub === 'review') {
      const n = bl.length + (needSite ? 1 : 0);
      wb.innerHTML = `${subBar('review')}<h2>راجع طلبك</h2>
        ${app.return_kind === 'guarantee' ? `<div class="notice"><span>↩</span><span>بعد توقيعك يعود طلبك إلى <b>${esc(bk.name)}</b> بالضمان الجديد${(app.returned_from || 6) >= 8 ? ' — يوافق عليه مدير الفرع أولاً ثم يكمل المصرف من حيث توقف' : ''}. العمولة مدفوعة سابقاً ولا تُدفع مرة أخرى.</span></div>` : ''}
        ${app.returned_from === 6 && app.return_note ? `<div class="notice warn"><span>⚠</span><span><b>${app.feasibility_rejections && (app.intake_missing || []).some(i => i.key === 'feasibility_update') ? 'رُفض طلبك بسبب دراسة الجدوى' : 'أعاد المصرف طلبك لإكمال النواقص'}</b><div style="white-space:pre-line">${esc(app.return_note)}</div></span></div>` : ''}
        ${n ? `<div class="miss-box"><h3>★ بقي <span class="num">${n}</span> ${n === 1 ? 'شيء' : 'أشياء'} قبل الإرسال</h3><p class="small muted" style="margin:0 0 8px">اضغط كل سطر لإكماله، ثم ارجع هنا.</p>
          <div class="fix-rows">${bl.map(i => fixRow(i.label, i.fix, i.key)).join('')}${needSite ? fixRow('مكان المنظومة — حدّده في الأعلى', 'site', 'site') : ''}</div></div>`
          : '<div class="notice ok-n"><span>✓</span><span>طلبك مكتمل — لا نواقص.</span></div>'}
        <div class="review"><h3>ملخص طلبك</h3><dl class="kv">
          <dt>المنظومة</dt><dd>${esc(o?.title)}</dd><dt>غرض التمويل</dt><dd>${esc(PURPOSE[app.purpose] || 'منزلي')}</dd><dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])} ${badge(['مؤكد', 'ok'])}</dd>
          <dt>المصرف</dt><dd>${esc(bk.name)} <button type="button" class="linkbtn" data-chg>تغيير</button></dd><dt>المدة</dt><dd><span class="num">${c.t}</span> شهراً</dd>
          <dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px"><b>${iqd(c.ins)}</b></dd><dt>أول قسط</dt><dd>بعد شهر من صرف المبلغ للمورد</dd></dl></div>
        <div class="row mt"><span class="sp"></span><button type="button" class="btn cyan ${n ? 'is-off' : ''}" data-next>${n ? `أكمل النواقص أولاً (${n})` : p ? 'التالي: وقّع وأرسل ←' : `التالي: ادفع ${iqd(tot)} ←`}</button></div>`;
      wb.querySelector('[data-chg]').onclick = () => goStep(3);
      wb.querySelectorAll('[data-fix]').forEach(b => b.onclick = () => fixGo(b.dataset.fix, b.dataset.key));
      wb.querySelector('[data-next]').onclick = () => {
        if (n) { const t = wb.querySelector('.miss-box') ; t?.scrollIntoView({ behavior: 'smooth', block: 'center' }); t?.classList.add('flash'); setTimeout(() => t?.classList.remove('flash'), 1200); return toast('أكمل البنود ذات النجمة ★ أولاً — اضغط كل سطر', 'bad'); }
        go(p ? 'sign' : 'pay');
      };
      return;
    }
    if (sub === 'pay') {
      wb.innerHTML = `${subBar('pay')}<h2>ادفع العمولة والرسوم</h2><p class="muted" style="margin-top:0">تُدفع مرة واحدة قبل إرسال طلبك إلى ${esc(bk.name)}.</p>
        <div class="sum-hero"><div class="sum-k">المبلغ المطلوب الآن</div><div class="sum-v">${iqd(tot)}</div><div class="small">عمولة المصرف والرسوم — القسط الشهري لاحقاً ${iqd(c.ins)}</div></div>
        <details class="review"><summary><b>تفاصيل المبلغ</b></summary><dl class="kv mt">${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${commPct(bk)}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(tot)}</b></dd></dl>
          <p class="small muted" style="margin:6px 0 0">عمولة البنك المركزي (لمرة واحدة) تُستوفى لاحقاً في الفرع مع فتح الإضبارة.</p></details>
        <h3 class="mt">اختر طريقة الدفع</h3>
        <div class="paygrid">${PAY_METHODS.map(([k, t, col]) => `<button type="button" data-m="${k}" class="${k === method ? 'on' : ''}" aria-pressed="${k === method}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>
        <div class="row mt"><button type="button" class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button type="button" class="btn cyan" data-pay>ادفع ${iqd(tot)} ←</button></div>`;
      wb.querySelector('[data-back]').onclick = () => go('review');
      wb.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; wb.querySelectorAll('[data-m]').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); }); });
      wb.querySelector('[data-pay]').onclick = async () => {
        const code = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: C.profile.phone, purpose: `دفع ${num(tot)} د.ع (عمولة ${bk.name} والرسوم)`,
          verify: async c2 => { const x = await rpc(C.sb, 'pay_application_fees', { p_app: app.id, p_bank: bk.id, p_method: method, p_otp: c2 }); paid = paid.filter(y => y.id !== x.id).concat(x); } });
        if (code) { toast('✓ تم الدفع — بقي التوقيع', 'ok'); go('sign'); }
      };
      return;
    }
    // sign
    wb.innerHTML = `${subBar('sign')}<h2>وقّع وأرسل طلبك</h2>
      <div class="review"><dl class="kv"><dt>المصرف</dt><dd><b>${esc(bk.name)}</b></dd><dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>القسط الشهري</dt><dd><b>${iqd(c.ins)}</b> × <span class="num">${c.t}</span> شهراً</dd>
        <dt>العمولة</dt><dd>${badge(['مدفوعة ✓', 'ok'])} <span class="small muted">رقم العملية <b class="num">${esc(p.ref)}</b></span> <button type="button" class="linkbtn" data-rcpt>الإيصال</button></dd></dl></div>
      <label class="check big-check"><input type="checkbox" data-ack ${ack ? 'checked' : ''}><span>أقرّ بصحة البيانات، وأفوّض المصرف بالاستعلام عن الضمان، وأوافق على استقطاع القسط الشهري.</span></label>
      <p class="small muted" style="margin:8px 0 0">ضع علامة ✓ ثم اضغط الزر — يصلك رمز على هاتفك تكتبه للتوقيع.</p>
      <div class="row mt"><button type="button" class="btn ghost" data-back>→ رجوع</button><span class="sp"></span><button type="button" class="btn cyan ${ack ? '' : 'is-off'}" data-ok>وقّع وأرسل الطلب ✓</button></div>`;
    wb.querySelector('[data-back]').onclick = () => go('review');
    wb.querySelector('[data-rcpt]').onclick = () => receipt(app, p);
    const ab = wb.querySelector('[data-ack]'), ok = wb.querySelector('[data-ok]');
    ab.onchange = () => { ack = ab.checked; ok.classList.toggle('is-off', !ack); };
    ok.onclick = async () => {
      if (blockers().length) { toast(`أكمل النواقص أولاً: ${blockers().map(i => i.label).join('، ')}`, 'bad'); return go('review'); }
      if (!ab.checked) { ab.closest('label').classList.add('flash'); setTimeout(() => ab.closest('label')?.classList.remove('flash'), 1200); return toast('ضع علامة ✓ على الإقرار أولاً', 'bad'); }
      const code = await askOtp({ kind: 'sign', title: 'التوقيع الإلكتروني', phone: C.profile.phone, purpose: `توقيع طلب تمويل ${num(app.amount)} د.ع لدى ${bk.name}`,
        verify: c2 => rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: 5, p_data: { bank_id: bk.id, term_months: c.t, otp: c2 } }) });
      if (!code) return;
      const back = app.return_kind === 'guarantee' && (app.returned_from || 6) > 6 ? Math.min(app.returned_from, 8) : 0;
      await load(); C.czStep = null; C.czSub = null;
      const m = modal(back ? `<div style="text-align:center"><div class="big-ok">✓</div><h2>عاد طلبك إلى ${esc(bk.name)}</h2>
        <p class="muted">بالضمان الجديد${back === 8 ? ' — الآن لدى <b>مدير الفرع</b> ليوافق عليه، ثم يكمل المصرف من حيث توقف' : ''}. تابع ما يحدث لحظة بلحظة من «طلبي».</p>
        <a class="btn cyan big-btn" href="#home" data-x>متابعة طلبي</a></div>` : `<div style="text-align:center"><div class="big-ok">✓</div><h2>أُرسل طلبك إلى ${esc(bk.name)}</h2>
        <p class="muted">رقم الطلب <b class="num">${esc(app.code)}</b> — الآن لدى <b>خدمة الزبائن في الفرع</b> لتدقيق المستمسكات والاستعلام الائتماني، ثم يفتح لك المصرف حساباً باسمك. ستتابع كل مرحلة لحظة بلحظة من «طلبي».</p>
        <a class="btn cyan big-btn" href="#home" data-x>متابعة طلبي</a></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      location.hash = '#home';
    };
  };
}
// سطر نقص قابل للضغط كاملاً: النجمة، الاسم، ومكان إصلاحه، وزر واضح
const FIX_WHERE = { 1: 'الخطوة 1 — الهوية', 2: 'الخطوة 2 — «أور»', 3: 'الخطوة 3 — المصرف والمستندات', 4: 'الخطوة 4 — الضمان', 5: 'الخطوة 5', profile: 'حسابي', site: 'مكان المنظومة', req: 'طلبي' };
function fixRow(label, fix, key, verb) {
  const v = verb || (DOC_KEYS.includes(key) ? 'ارفع' : fix === 'site' || key === 'site' ? 'حدّد' : 'أكمل');
  return `<button type="button" class="fix-go" data-fix="${esc(fix || '')}" data-key="${esc(key || '')}"><span class="ck-m">★</span><span class="fx-t"><b>${esc(label)}</b><small>${esc(key === 'site' ? 'مكان المنظومة' : FIX_WHERE[fix] || '')}</small></span><span class="fx-a">${v} ←</span></button>`;
}
function receipt(app, p) {
  const bank = C.orgs.find(o => o.id === p.bank_id);
  const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h3 style="margin:4px 0">إيصال دفع إلكتروني</h3><p class="muted small" style="margin:0">ألواح · ${esc(bank?.name || '')}</p></div>
    <dl class="kv mt"><dt>رقم العملية</dt><dd><b class="num">${esc(p.ref)}</b></dd><dt>رقم الطلب</dt><dd><span class="num">${esc(app.code)}</span></dd><dt>المقترض</dt><dd>${esc(C.profile.full_name)}</dd>
      ${(p.items || []).map(i => `<dt>${esc(i.label)}</dt><dd>${iqd(i.amount)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(p.amount)}</b></dd>
      <dt>طريقة الدفع</dt><dd>${esc(PAY_LABEL[p.method] || p.method)}</dd><dt>التاريخ</dt><dd>${dt(p.paid_at)}</dd></dl>
    <p class="small muted">يودع المصرف هذه المبالغ في إضبارتك (المرحلة 10). عمولة البنك المركزي لمرة واحدة تُستوفى في الفرع.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-pr>طباعة</button><button class="btn cyan" data-x>إغلاق</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-pr]').onclick = () => window.print();
}

// ───────── التقييم بعد التركيب ─────────
function rateDialog(app) {
  const v = { rating: 0, quality: 0, install: 0, service: 0 };
  const row = (k, l) => `<div class="rate-row"><span>${l}</span><span class="sp"></span><span class="rate" data-r="${k}">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-n="${n}" aria-label="${n}">★</button>`).join('')}</span></div>`;
  const m = modal(`<h3>قيّم منظومتك</h3><p class="muted small">يظهر تقييمك باسمك المختصر ومحافظتك.</p>
    ${row('rating', '<b>التقييم العام</b>')}${row('quality', 'جودة المنظومة')}${row('install', 'التركيب')}${row('service', 'خدمة المورد')}
    <div class="field mt"><label>تعليقك (اختياري)</label><textarea class="input" rows="3" data-c maxlength="400" placeholder="كيف الأداء؟ هل كفت البطاريات الليل؟"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-s>نشر التقييم</button></div>`);
  m.el.querySelectorAll('[data-r]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => {
    v[g.dataset.r] = Number(b.dataset.n); g.querySelectorAll('button').forEach(x => x.classList.toggle('on', Number(x.dataset.n) <= v[g.dataset.r]));
  }));
  m.el.querySelector('[data-s]').onclick = async () => {
    if (!v.rating) return toast('اختر التقييم العام', 'bad');
    try { await rpc(C.sb, 'submit_review', { p_app: app.id, p_rating: v.rating, p_quality: v.quality || v.rating, p_install: v.install || v.rating, p_service: v.service || v.rating, p_comment: m.el.querySelector('[data-c]').value }); m.close(); toast('شكراً — نُشر تقييمك', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الملف الشخصي للمقترض ─────────
function pageProfile(body) {
  const p = C.profile, set = S.ref.set;
  const fin = S.apps.find(a => a.bank_id && a.monthly_installment && !['cancelled', 'rejected'].includes(a.status));
  const age = p.birth_date ? Math.floor((Date.now() - new Date(p.birth_date)) / (365.25 * 864e5)) : null;
  const myReviews = S.reviews.filter(r => r.citizen_id === p.id);
  body.innerHTML = `
    <div class="prof-head card">
      <div class="av xl">${esc(p.full_name.trim()[0])}</div>
      <div><h1 style="font-size:22px">${esc(p.full_name)}</h1>
        <div class="row" style="gap:8px;margin-top:4px">${p.kyc_status === 'verified' ? badge(['هوية موثّقة بالسيلفي', 'ok']) : badge(['الهوية غير موثّقة بعد', 'warn'])}<span class="small" style="color:#9FB4D6">عضو منذ ${dt(p.created_at).split('،')[0]}</span></div></div>
      <span class="sp"></span>
      <div class="prof-kpis"><div><b class="num">${S.apps.length}</b><span>طلب</span></div><div><b>${fin ? iqd(fin.monthly_installment) : '—'}</b><span>القسط الشهري</span></div><div><b class="num">${myReviews.length}</b><span>تقييم</span></div></div>
    </div>
    <div class="grid g2 mt">
      <div class="card"><h3>البيانات الشخصية<span class="sp"></span><span class="badge muted">من البطاقة الوطنية</span></h3>
        <dl class="kv"><dt>الاسم</dt><dd>${esc(p.full_name)}</dd><dt>رقم البطاقة</dt><dd><span class="num">${esc(maskId(p.national_id))}</span></dd>
          <dt>تاريخ الميلاد</dt><dd>${p.birth_date ? `<span class="num">${esc(p.birth_date)}</span> (<span class="num">${age}</span> سنة)` : '—'}</dd>
          <dt>رقم الهاتف</dt><dd><span class="num">${esc(p.phone || '—')}</span> <button class="linkbtn" data-phone>تغيير</button></dd>
          <dt>اسم الدخول</dt><dd><span class="num">${esc(p.username)}</span></dd>
          <dt>التحقق</dt><dd>${p.kyc_at ? `${dt(p.kyc_at)}` : 'يتم في أول خطوة من طلب التمويل'}</dd></dl>
        <p class="small muted" style="margin:10px 0 0">الاسم ورقم البطاقة لا يُعدَّلان بعد التحقق من الهوية.</p></div>
      <form class="card" data-f="contact" novalidate><h3>العنوان والتواصل</h3>
        <div class="grid g2" style="gap:10px">
          <div class="field"><label>المحافظة</label><select class="input" name="governorate">${govOptions(p.governorate || '')}</select></div>
          <div class="field"><label>المدينة / القضاء</label><input class="input" name="city" value="${esc(p.city || '')}"></div>
        </div>
        <div class="field"><label>العنوان التفصيلي</label><input class="input" name="address" value="${esc(p.address || '')}" placeholder="المحلة، الزقاق، الدار"></div>
        <div class="field"><label>البريد الإلكتروني (اختياري)</label><input class="input" name="email" type="email" dir="ltr" value="${esc(p.email || '')}"></div>
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="work" novalidate><h3>العمل والدخل</h3>
        <div class="field"><label>جهة العمل</label><input class="input" name="employer" value="${esc(p.employer || '')}" placeholder="دائرة حكومية، شركة، عمل حر"></div>
        <div class="field"><label>الدخل الشهري (د.ع)</label><input class="input" name="monthly_salary" inputmode="numeric" dir="ltr" value="${esc(p.monthly_salary || '')}"></div>
        ${fin && p.monthly_salary ? `<div class="cover"><div class="row"><span class="small">القسط من دخلك</span><span class="sp"></span><b class="num">${(fin.monthly_installment / p.monthly_salary * 100).toFixed(1)}%</b></div><div class="bar"><i style="width:${Math.min(100, fin.monthly_installment / p.monthly_salary * 100)}%;background:${fin.monthly_installment / p.monthly_salary < .35 ? 'var(--ok)' : 'var(--sun)'}"></i></div></div>` : ''}
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="pw" novalidate><h3>الأمان — تغيير كلمة المرور</h3>
        <div class="field"><label>كلمة المرور الحالية</label><input class="input" name="old" type="password" dir="ltr" autocomplete="current-password"></div>
        <div class="field"><label>كلمة المرور الجديدة</label><input class="input" name="nw" type="password" dir="ltr" autocomplete="new-password"><small class="muted">8 أحرف على الأقل، حروف إنجليزية وأرقام</small></div>
        <div class="row"><span class="sp"></span><button class="btn">تغيير كلمة المرور</button></div></form>
    </div>
    <div class="card mt" id="sched"></div>
    <div class="card mt"><h3>طلباتي</h3>${S.apps.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المصرف</th><th>المبلغ</th><th>المرحلة</th><th>الحالة</th></tr></thead><tbody>
      ${S.apps.map(a => `<tr class="click" data-go="${a.id}"><td><b class="num">${esc(a.code)}</b></td><td>${isVet(a) ? 'مشروع بيطري' : `<span class="num">${num(a.kw)}</span> kW`}</td><td>${esc(C.orgs.find(x => x.id === a.bank_id)?.name || '—')}</td><td>${iqd(a.amount)}</td><td><span class="num">${a.stage}</span> / ${C.stages.length}</td><td>${statusBadge(a.status)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">لا طلبات بعد. <a href="#catalog">ابدأ من الكتالوج</a></p>'}</div>
    ${myReviews.length ? `<div class="card mt"><h3>تقييماتي</h3><ul class="rv-list">${myReviews.map(r => `<li><div class="row">${stars(r.rating)}<span class="small muted">${ago(r.created_at)}</span></div>${r.comment ? `<p>${esc(r.comment)}</p>` : ''}</li>`).join('')}</ul></div>` : ''}
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-out>تسجيل الخروج</button></div>`;
  // جدول الأقساط
  const sc = body.querySelector('#sched');
  if (!fin) sc.innerHTML = `<h3>جدول الأقساط</h3><p class="muted">يظهر جدول أقساطك بعد اختيار المصرف وتوقيع الطلب.</p>`;
  else {
    const rate = set.cbi_rate + Number(fin.margin || 0), r = rate / 1200, n = fin.term_months, ins = fin.monthly_installment;
    const start = fin.status === 'completed' ? new Date(fin.updated_at) : null;
    const paid = start ? Math.max(0, Math.floor((Date.now() - start) / (30.44 * 864e5))) : 0;
    let bal = fin.amount; const rows = [];
    for (let i = 1; i <= n; i++) { const it = Math.round(bal * r), pr = Math.min(bal, ins - it); bal = Math.max(0, bal - pr); rows.push({ i, it, pr, bal, due: start ? new Date(start.getFullYear(), start.getMonth() + i, start.getDate()) : null }); }
    const all = C.czAllRows;
    sc.innerHTML = `<h3>جدول الأقساط<span class="sp"></span><span class="small muted">${esc(C.orgs.find(x => x.id === fin.bank_id)?.name)} · <span class="num">${rate.toFixed(2)}%</span></span></h3>
      <div class="grid g4" style="gap:10px;margin-bottom:12px">
        <div class="stat"><b>${iqd(fin.amount)}</b><span>مبلغ التمويل</span></div><div class="stat"><b>${iqd(ins)}</b><span>القسط الشهري</span></div>
        <div class="stat"><b>${iqd(ins * n)}</b><span>إجمالي السداد</span></div><div class="stat"><b><span class="num">${paid}</span> / <span class="num">${n}</span></b><span>أقساط مسددة</span></div></div>
      ${start ? '' : '<div class="notice"><span>ℹ</span><span>يبدأ أول قسط بعد صرف المبلغ للمورد وتسليمك جدول الأقساط (بعد مدة السماح إن وُجدت). التواريخ تظهر عند الصرف.</span></div>'}
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>الاستحقاق</th><th>القسط</th><th>أصل</th><th>${fin.margin ? 'فائدة/ربح' : 'فائدة'}</th><th>المتبقي</th><th>الحالة</th></tr></thead><tbody>
      ${rows.slice(0, all ? n : 12).map(x => `<tr><td class="num">${x.i}</td><td class="small">${x.due ? x.due.toLocaleDateString('ar-IQ-u-nu-latn', { year: 'numeric', month: 'short' }) : `الشهر <span class="num">${x.i}</span>`}</td><td>${iqd(ins)}</td><td>${iqd(x.pr)}</td><td>${iqd(x.it)}</td><td>${iqd(x.bal)}</td><td>${x.i <= paid ? badge(['مسدد', 'ok']) : x.i === paid + 1 && start ? badge(['القادم', 'warn']) : badge(['مجدول', 'muted'])}</td></tr>`).join('')}</tbody></table></div>
      ${n > 12 ? `<button class="btn ghost block mt" data-rows>${all ? 'عرض أول 12 قسطاً' : `عرض كل الأقساط (<span class="num">${n}</span>)`}</button>` : ''}`;
    const rb = sc.querySelector('[data-rows]'); if (rb) rb.onclick = () => { C.czAllRows = !C.czAllRows; pageProfile(body); };
  }
  body.querySelectorAll('[data-go]').forEach(tr => tr.onclick = () => { location.hash = '#home'; });
  const save = async (f, keys) => {
    const d = {}; keys.forEach(k => d[k] = (f[k].value || '').trim());
    if ('monthly_salary' in d) d.monthly_salary = digits(d.monthly_salary);
    const b = f.querySelector('button'); b.disabled = true;
    try { C.profile = await rpc(C.sb, 'update_my_profile', { p: d }); toast('حُفظت التغييرات', 'ok'); pageProfile(body); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  };
  body.querySelector('[data-f=contact]').onsubmit = e => { e.preventDefault(); save(e.target, ['governorate', 'city', 'address', 'email']); };
  body.querySelector('[data-f=work]').onsubmit = e => { e.preventDefault(); save(e.target, ['employer', 'monthly_salary']); };
  body.querySelector('[data-f=pw]').onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    if (f.nw.value.length < 8 || !/\d/.test(f.nw.value) || !/[A-Za-z]/.test(f.nw.value)) return toast('كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً', 'bad');
    try { await rpc(C.sb, 'change_my_password', { p_old: f.old.value, p_new: f.nw.value }); f.reset(); toast('تم تغيير كلمة المرور', 'ok'); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
  body.querySelector('[data-phone]').onclick = () => {
    const m = modal(`<h3>تغيير رقم الهاتف</h3><p class="muted small">نرسل رمز تحقق إلى الرقم الجديد.${p.self_registered ? ' سيصبح الرقم الجديد اسم دخولك.' : ''}</p>
      <div class="field"><label>الرقم الجديد</label><input class="input" data-ph inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الرمز</button></div>`);
    m.el.querySelector('[data-s]').onclick = async () => {
      const ph = normPhone(m.el.querySelector('[data-ph]').value);
      if (!validPhone(ph)) return toast('رقم الهاتف غير صحيح', 'bad');
      m.close();
      const c = await askOtp({ kind: 'phone_change', title: 'تأكيد الرقم الجديد', phone: ph, verify: async code => { C.profile = await rpc(C.sb, 'change_my_phone', { p_new_phone: ph, p_otp: code }); } });
      if (c) { toast('تم تغيير رقم الهاتف', 'ok'); pageProfile(body); }
    };
  };
  body.querySelector('[data-out]').onclick = async () => { await C.sb.auth.signOut(); location.hash = ''; location.reload(); };
}
