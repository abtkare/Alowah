// بوابة المصرف — دورة الطلب مطابقة لإجراء تمويل المبادرة: الفرع ← قسم المبادرات ← الإدارة العليا ← البنك المركزي ← التنفيذ
// فصل مهام كامل: كل مرحلة لدور واحد، ومراحل الفرع لموظفي الفرع نفسه
import { ROLE_LABELS, esc, iqd, mln, pct, num, kpi, appsTable, openApp, stageActions, rpc, badge, REF_STATUS, BATCH_STATUS, tabs, dt, toast, cleanErr, modal } from '../core.js';
import { perfView, myPerf, canSeePerf } from '../perf.js';

const UNIT_HINT = {
  bank_cs: 'خدمة الزبائن في الفرع: تدقيق المستمسكات والاستعلام الائتماني، الضمان الأولي، الإضبارة والوعد بالشراء، توقيع العقد، تسليم جدول الأقساط وحفظ العقود.',
  bank_compliance: 'التحقق من وجود حساب للزبون أو فتحه، وفحص الامتثال. لا تعدّل البيانات.',
  bank_branch_mgr: 'الموافقة المبدئية، قرار اللجنة الائتمانية في الفرع، تدقيق العقد والكمبيالة، وتدقيق قيد الصرف.',
  bank_initiatives: 'استلام الإضبارة وقائمة التدقيق، استكمال الضمان النهائي، وتجميع الطلبات في سلفة تجميعية للبنك المركزي.',
  bank_credit: 'مسؤول شعبة ائتمان المبادرات: التحقق من النواقص، الدراسة الائتمانية والتوصية، إبلاغ الفرع بعد تعزيز السلفة من ائتمان المصرف، وطلب التنفيذ.',
  bank_inspection: 'لجنة الكشف الموقعي: الكشف قبل الدراسة، ثم الكشف على التركيب واستلام البضاعة.',
  bank_initiatives_mgr: 'قرار قسم المبادرات على الدراسة، والتحقق من مطابقة طلب التنفيذ للسياسة.',
  bank_legal: 'القرار القانوني على الإضبارة والضمانات. لا يغيّر شروط القرار الائتماني.',
  bank_md: 'الموافقة ضمن الصلاحيات، توقيع كتاب السلفة التجميعية، واعتماد طلب التنفيذ.',
  bank_admin: 'إرسال كتاب السلفة التجميعية الموقّع إلى البنك المركزي للسحب من ائتمان المصرف، وإعادة محاولة التعزيز إن لم يكفِ الائتمان.',
  bank_ops: 'تسجيل طلب التنفيذ وأمر الشراء من المورد، ثم تنفيذ التمويل وإصدار جدول الأقساط.',
  bank_teller: 'صرف المبلغ للمورد وتوقيع القيد. لا يقرر ولا يعدّل العقد.',
  bank_collection: 'الاستقطاع الشهري والمتأخرات ومطالبة الكفيل أو التأمين. لا إعفاء دون قرار.',
  bank_committee: 'اللجنة الائتمانية العليا: تُعرض عليها الاستثناءات من السياسة بغض النظر عن قيمة التمويل.',
  bank_risk: 'ترى ولا تنفذ: مؤشرات الأداء والتأخير واستخدام الحصة.',
};

export async function render(ctx) {
  const { sb, profile, org, stages, root } = ctx;
  const [apps, alloc, refs, terms, batches, branches] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
    sb.from('mortgage_referrals').select('*').then(r => r.data || []),
    sb.from('bank_terms').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
    sb.from('cbi_batches').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('branches').select('*').then(r => r.data || []),
  ]);
  const reasons = Object.fromEntries((((await sb.from('rejection_reasons').select('code,label')).data) || []).map(x => [x.code, x.label]));
  ctx.branches = branches;
  const myBranch = branches.find(b => b.id === profile.branch_id);
  const myStages = stages.filter(s => s.owner_role === profile.role).map(s => s.n);
  const live = a => ['active', 'returned'].includes(a.status);
  const inbox = apps.filter(a => myStages.includes(a.stage) && live(a) && !stages.find(s => s.n === a.stage)?.batch_only);
  const active = apps.filter(live);
  const completed = apps.filter(a => a.status === 'completed');
  const toBatch = apps.filter(a => a.stage === 20 && a.status === 'active');
  const batchInbox = batches.filter(b => (profile.role === 'bank_md' && b.status === 'draft') || (profile.role === 'bank_admin' && ['signed', 'sent'].includes(b.status)) || (profile.role === 'bank_initiatives' && b.status === 'draft'));
  const used = alloc ? (alloc.reserved + alloc.disbursed) / alloc.allocated * 100 : 0;
  const avail = alloc ? alloc.allocated - alloc.reserved - alloc.disbursed : 0;
  const isRisk = profile.role === 'bank_risk';
  const batchRole = ['bank_initiatives', 'bank_md', 'bank_admin'].includes(profile.role);
  const batchCount = profile.role === 'bank_initiatives' ? toBatch.length : batchInbox.length;

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}${org.is_islamic ? ' <span class="badge ok">مصرف إسلامي — مسار المرابحة</span>' : ''}</h1>
      <p>${esc(ROLE_LABELS[profile.role])}${myBranch ? ` — <b>${esc(myBranch.name)}</b>` : ' — الإدارة العامة'}. ${esc(UNIT_HINT[profile.role] || '')}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('في صندوق وحدتي', `<span class="num">${inbox.length + (batchRole ? batchCount : 0)}</span>`, 'معاملات تنتظر إجراءك', true)}
      ${kpi('قيد المعالجة', `<span class="num">${active.length}</span>`, myBranch ? 'في فرعك' : 'في كل الفروع')}
      ${kpi('مكتملة', `<span class="num">${completed.length}</span>`, `صُرف لها ${mln(completed.reduce((s, a) => s + a.amount, 0))} دينار`)}
      ${kpi('المتاح من الحصة', mln(avail), `استخدام ${pct(used)} من المخصص`)}
    </div>
    ${used >= 80 ? `<div class="notice warn">⚠ استخدام الحصة بلغ ${pct(used)} — ${used >= 95 ? 'أُوقفت العروض الجديدة لحين التعزيز' : used >= 90 ? 'مؤشر أحمر لدى البنك المركزي' : 'يُنصح برفع طلب تعزيز إلى البنك المركزي'}.</div>` : ''}
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [
    ...(isRisk ? [] : [{ key: 'inbox', label: 'صندوق وحدتي', count: inbox.length }]),
    ...(batchRole ? [{ key: 'batch', label: 'السلف التجميعية', count: batchCount }] : []),
    { key: 'all', label: myBranch ? 'طلبات الفرع' : 'كل طلبات المصرف' },
    ...(canSeePerf(profile.role) ? [{ key: 'perf', label: 'تحليل الأداء' }] : [{ key: 'me', label: 'أدائي' }]),
    { key: 'quota', label: 'دفتر الحصة والشروط' },
    ...(['bank_cs', 'bank_initiatives', 'bank_legal', 'bank_risk'].includes(profile.role) ? [{ key: 'mortgage', label: 'إحالات الرهن' }] : []),
  ];
  ctx.bankTab = defs.find(d => d.key === ctx.bankTab) ? ctx.bankTab : defs[0].key;
  tabs(root.querySelector('#tabs'), defs, k => { ctx.bankTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.bankTab));

  const open = a => {
    const mine = inbox.includes(a);
    const ref = refs.filter(r => r.application_id === a.id).sort((x, y) => y.created_at.localeCompare(x.created_at))[0];
    let actions = mine ? stageActions(ctx, a) : [];
    const canRefer = a.guarantee_type === 'mortgage' && (!ref || ['rejected', 'released', 'encumbered'].includes(ref.status))
      && ((profile.role === 'bank_cs' && a.stage === 9) || (profile.role === 'bank_initiatives' && a.stage === 19));
    if (mine && canRefer) {
      actions = [{ label: 'إحالة الرهن إلى التسجيل العقاري', kind: 'cyan', done: 'أُحيل الرهن إلى دائرة التسجيل العقاري', run: n => rpc(sb, 'refer_mortgage', { p_app: a.id, p_note: n }) }, ...actions];
    }
    const extra = a.guarantee_type === 'mortgage' ? `<div class="card mb"><h3>رهن العقار</h3>${ref
      ? `<div class="row">حالة الإحالة: ${badge(REF_STATUS[ref.status])}${ref.annotation_no ? `<span class="muted small">رقم التأشير: <b class="num">${esc(ref.annotation_no)}</b></span>` : ''}</div>
        ${ref.status === 'rejected' ? `<div class="notice warn mt"><b>رفضت دائرة التسجيل العقاري التأشير:</b> ${esc(reasons[ref.reject_reason] || '—')}${ref.note ? ` — ${esc(ref.note)}` : ''}<br><span class="small">القرار: ${esc(ref.decided_by_title || '')} · ${dt(ref.decided_at)} · الدليل مرفق في «المستندات»</span></div>` : ''}`
      : '<p class="muted small" style="margin:0">لم يُحَل الرهن بعد.</p>'}
      <p class="small muted" style="margin:8px 0 0">الإجراء الأولي (الخلو والمطابقة) من الفرع في المرحلة 9، والإجراء النهائي (التأشير) بعد موافقة الإدارة العليا في المرحلة 19.</p></div>` : '';
    openApp(ctx, a, { actions, extra });
  };

  function show(k) {
    if (k === 'inbox') body.innerHTML = `<div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'amount', 'guarantee', 'stage', 'status', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'gov', 'amount', 'stage', 'status', 'updated'] })}</div>`;
    if (k === 'mortgage') body.innerHTML = `<div class="card flush">${appsTable(apps.filter(a => a.guarantee_type === 'mortgage'), ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'amount', 'stage', 'status'] })}</div>`;
    if (k === 'perf') perfView(ctx, body, { mode: 'bank' });
    if (k === 'me') myPerf(ctx, body);
    if (k === 'batch') showBatches();
    if (k === 'quota') {
      const a = alloc || { allocated: 0, reserved: 0, disbursed: 0 };
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      body.innerHTML = `<div class="grid g2">
        <div class="card"><h3>دفتر حصة المصرف</h3>
          <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
          <div class="legend"><span><i style="background:var(--indigo)"></i>مصروف</span><span><i style="background:var(--sun)"></i>محجوز</span><span><i style="background:#E8EDF5"></i>متاح</span></div>
          <dl class="kv mt"><dt>ائتمان المصرف لدى البنك المركزي</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز بسلف معزَّزة</dt><dd>${iqd(a.reserved)}</dd>
          <dt>المصروف للموردين</dt><dd>${iqd(a.disbursed)}</dd><dt>المتاح</dt><dd>${iqd(avail)}</dd></dl>
          <p class="small muted mt">يُحجز المبلغ من ائتمان المصرف لحظة تعزيز السلفة التجميعية (آلياً عند إرسال كتابها إن كان الائتمان كافياً)، ويتحول إلى «مصروف» عند صرف أمين الصندوق للمورد. يجب التنفيذ خلال شهر من التعزيز، وبعد 3 أشهر تُفرض الغرامة.</p></div>
        <div class="card"><h3>شروط التمويل المعلنة</h3>
          <dl class="kv"><dt>عوائد المصرف السنوية</dt><dd>${pct(terms?.margin)} متناقصة</dd><dt>رسم دراسة الملف</dt><dd>${iqd(terms?.file_fee)}</dd>
          <dt>عمولة المصرف (يدفعها المقترض قبل الإرسال)</dt><dd>${pct(terms?.commission_pct ?? 1)} من مبلغ التمويل</dd>
          <dt>أقصى مدة</dt><dd><span class="num">${num(terms?.max_term_months)}</span> شهراً شاملة السماح</dd><dt>مدة المعالجة المعلنة</dt><dd><span class="num">${num(terms?.processing_days)}</span> أيام</dd>
          <dt>سقف الموافقة الأحادية</dt><dd>${iqd(terms?.single_approval_cap)}</dd></dl>
          <p class="small muted mt">عمولة البنك المركزي تُستوفى لمرة واحدة ولا تُسترجع. الاستثناءات من السياسة تُعرض على اللجنة الائتمانية العليا.</p></div></div>`;
    }
  }

  // السلف التجميعية: إداري المبادرات يجمع ← الإدارة العليا توقّع ← قسم الإدارة يرسل ← تُعزَّز آلياً من ائتمان المصرف لدى البنك المركزي
  function showBatches() {
    const cap = 200000000;
    const pickable = profile.role === 'bank_initiatives' ? toBatch : [];
    body.innerHTML = `
      ${pickable.length ? `<div class="card flush mb"><h3>طلبات جاهزة للتجميع <span class="sp"></span><span class="small muted">سقف السلفة الواحدة ${mln(cap)} دينار</span></h3>
        <div class="tbl-wrap"><table class="tbl batch-pick"><thead><tr><th></th><th>رقم الطلب</th><th>المتقدم</th><th>الفرع</th><th>المبلغ</th><th>الضمان</th></tr></thead><tbody>
        ${pickable.map(a => `<tr><td><input type="checkbox" data-pick="${a.id}" data-amt="${a.amount}" checked></td><td><b class="num">${esc(a.code)}</b></td><td>${esc(a.citizen_name)}</td><td>${esc(branches.find(b => b.id === a.branch_id)?.name || '—')}</td><td>${iqd(a.amount)}</td><td class="small">${esc(a.guarantee_type === 'mortgage' ? 'رهن عقار' : 'كفالة راتب')}</td></tr>`).join('')}
        </tbody></table></div>
        <div class="sumbar"><span>المجموع: <b data-sum></b></span><span class="sp"></span><button class="btn cyan" data-make>إنشاء السلفة التجميعية</button></div></div>`
        : profile.role === 'bank_initiatives' ? '<div class="notice">لا طلبات في مرحلة التجميع الآن (المرحلة 20).</div>' : ''}
      <div class="card flush"><h3>سجل السلف التجميعية</h3>${batches.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>السلفة</th><th>الطلبات</th><th>المبلغ</th><th>الحالة</th><th>الكتاب</th><th>التواريخ</th><th></th></tr></thead><tbody>
        ${batches.map(b => {
          const act = (profile.role === 'bank_md' && b.status === 'draft') ? ['sign', 'توقيع الكتاب', 'ok'] : (profile.role === 'bank_admin' && b.status === 'signed') ? ['send', 'إرسال وتعزيز من ائتمان المصرف', 'cyan'] : (profile.role === 'bank_admin' && b.status === 'sent') ? ['fund', 'إعادة محاولة التعزيز', 'warn'] : (profile.role === 'bank_initiatives' && b.status === 'draft') ? ['dissolve', 'فك السلفة', 'ghost'] : null;
          return `<tr><td><b class="num">${esc(b.code)}</b></td><td class="num">${b.apps_count}</td><td>${iqd(b.total)}</td><td>${badge(BATCH_STATUS[b.status])}</td><td class="num small">${esc(b.letter_ref || '—')}</td>
          <td class="small muted">أُنشئت ${dt(b.created_at)}${b.signed_at ? `<br>وُقّعت ${dt(b.signed_at)}` : ''}${b.sent_at ? `<br>أُرسلت ${dt(b.sent_at)}` : ''}${b.decided_at ? `<br>${b.status === 'approved' ? 'عُزّزت' : 'القرار'} ${dt(b.decided_at)}` : ''}${b.status === 'rejected' && b.decision_note ? `<br>${esc(b.decision_note)}` : ''}${(b.oversight_notes || []).map(o => `<br><span style="color:var(--warn)">تدخل رقابي من البنك المركزي ${dt(o.at)}: ${esc(o.note)}</span>`).join('')}</td>
          <td>${act ? `<button class="btn sm ${act[2]}" data-act="${act[0]}" data-b="${b.id}">${act[1]}</button>` : ''}</td></tr>`;
        }).join('')}</tbody></table></div>` : '<div class="empty">لا سلف بعد.</div>'}</div>`;
    const sumEl = body.querySelector('[data-sum]');
    const recalc = () => {
      if (!sumEl) return;
      const t = [...body.querySelectorAll('[data-pick]:checked')].reduce((s, x) => s + Number(x.dataset.amt), 0);
      sumEl.innerHTML = `${iqd(t)} ${t > cap ? '<span class="badge bad">يتجاوز السقف</span>' : ''}`;
    };
    body.querySelectorAll('[data-pick]').forEach(x => x.onchange = recalc); recalc();
    const mk = body.querySelector('[data-make]');
    if (mk) mk.onclick = async () => {
      const ids = [...body.querySelectorAll('[data-pick]:checked')].map(x => x.dataset.pick);
      mk.disabled = true;
      try { const b = await rpc(sb, 'batch_create', { p_apps: ids }); toast(`أُنشئت السلفة ${b.code} — بانتظار توقيع الإدارة العليا`, 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); mk.disabled = false; }
    };
    body.querySelectorAll('[data-act]').forEach(btn => btn.onclick = async () => {
      btn.disabled = true;
      try { await rpc(sb, 'batch_action', { p_batch: btn.dataset.b, p_action: btn.dataset.act }); toast('تم', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
    });
  }

  show(ctx.bankTab);
}

// لا يُعاد رسم الشاشة أثناء العمل على لوحة الأداء أو اختيار طلبات السلفة
export const shouldRefresh = ctx => ctx.bankTab !== 'perf';
