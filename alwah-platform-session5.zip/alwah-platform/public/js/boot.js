// ألواح — تشغيل البوابة: الدخول، التحقق من الدور، تحميل لوحة الجهة، التحديث اللحظي
import { PORTALS, ROLE_LABELS, esc, el, toast, cleanErr } from './core.js';

const CFG = window.ALWAH_CONFIG || {};
const portal = location.pathname.split('/')[1];
const P = PORTALS[portal];
const app = document.getElementById('app');
document.title = `ألواح — ${P?.title || 'البوابة'}`;

let sb;
try {
  const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm');
  // جلسة مستقلة لكل بوابة: يمكن فتح بوابة المواطن والمصرف في المتصفح نفسه معاً
  sb = createClient(CFG.url, CFG.key, { auth: { storageKey: `alwah-${portal}`, persistSession: true, autoRefreshToken: true } });
} catch (e) {
  console.error(e);
}

// وضع المطور (رمز التحقق الثابت) — يُقرأ من الخادم قبل الدخول
if (sb) {
  try { const { data } = await sb.rpc('public_config'); window.ALWAH_DEV = data || {}; } catch { window.ALWAH_DEV = {}; }
}

if (!P) location.replace('/');
else if (!sb) renderLogin('تعذّر الاتصال بالخادم. تحقق من الإنترنت ثم أعد تحميل الصفحة.');
else {
  const { data: { session } } = await sb.auth.getSession();
  session ? start() : renderLogin();
}

function renderLogin(err = '') {
  app.innerHTML = '';
  if (portal === 'citizen' && sb) return renderCitizenLogin(err);
  const v = el(`<div class="login">
    <section class="side"><div class="sun"></div>
      <a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ألواح</b><small>ألواح الشمس</small></span></a>
      <div style="position:relative"><span class="portal-name" style="padding:4px 12px;border-radius:999px;background:rgba(5,219,243,.12);color:var(--cyan);font-size:13px;font-weight:700">${esc(P.short)}</span>
        <h1>${esc(P.title)}</h1><p>${esc(P.sub)}</p>
        <ul>${P.points.map(p => `<li>${esc(p)}</li>`).join('')}</ul></div>
      <small style="color:#5E6F8C;position:relative">نسخة العرض · البيانات تجريبية</small>
    </section>
    <section class="form"><form class="box" autocomplete="on">
      <h2>تسجيل الدخول</h2><p class="sub">أدخل اسم المستخدم وكلمة المرور الخاصة بـ${esc(P.short)}</p>
      <div class="err ${err ? 'on' : ''}">${esc(err)}</div>
      <div class="field"><label for="u">اسم المستخدم</label><input class="input" id="u" name="username" autocomplete="username" dir="ltr" required></div>
      <div class="field"><label for="p">كلمة المرور</label><input class="input" id="p" name="password" type="password" autocomplete="current-password" dir="ltr" required></div>
      <button class="btn cyan block" type="submit">دخول</button>
      <p class="other"><a href="/">العودة إلى الصفحة الرئيسية</a></p>
    </form></section></div>`);
  app.appendChild(v);
  const f = v.querySelector('form'), e = v.querySelector('.err');
  f.onsubmit = async ev => {
    ev.preventDefault();
    const btn = f.querySelector('button'); btn.disabled = true; btn.textContent = 'جارِ التحقق…'; e.classList.remove('on');
    const username = f.u.value.trim().toLowerCase();
    const email = username.includes('@') ? username : `${username}@alwah.demo`;
    const { error } = await sb.auth.signInWithPassword({ email, password: f.p.value });
    if (error) {
      e.textContent = 'اسم المستخدم أو كلمة المرور غير صحيحة'; e.classList.add('on');
      btn.disabled = false; btn.textContent = 'دخول'; return;
    }
    start();
  };
}

async function renderCitizenLogin(err) {
  const { mountCitizenAuth } = await import('./auth-citizen.js');
  const v = el(`<div class="login">
    <section class="side"><div class="sun"></div>
      <a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ألواح</b><small>ألواح الشمس</small></span></a>
      <div style="position:relative"><span class="portal-name" style="padding:4px 12px;border-radius:999px;background:rgba(5,219,243,.12);color:var(--cyan);font-size:13px;font-weight:700">${esc(P.short)}</span>
        <h1>${esc(P.title)}</h1><p>${esc(P.sub)}</p>
        <ul>${P.points.map(p => `<li>${esc(p)}</li>`).join('')}</ul></div>
      <small style="color:#5E6F8C;position:relative">نسخة العرض · البيانات تجريبية</small>
    </section>
    <section class="form"><div class="box"></div></section></div>`);
  app.appendChild(v);
  mountCitizenAuth(v.querySelector('.box'), { sb, err, onDone: o => { if (o?.fresh) location.hash = '#catalog'; start(); } });
}

async function start() {
  app.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  const { data: { user } } = await sb.auth.getUser();
  const { data: profile } = await sb.from('profiles').select('*').eq('id', user?.id).maybeSingle();
  if (!profile) { await sb.auth.signOut(); return renderLogin('الحساب غير مفعّل على المنصة'); }
  if (profile.portal !== portal) {
    await sb.auth.signOut();
    return renderLogin(`هذا الحساب يخص «${PORTALS[profile.portal]?.title}» — استخدم رابط تلك البوابة`);
  }
  const [orgs, stages] = await Promise.all([
    sb.from('orgs').select('*').then(r => r.data || []),
    sb.from('stages').select('*').order('n').then(r => r.data || []),
  ]);
  const org = orgs.find(o => o.id === profile.org_id);

  app.innerHTML = '';
  const top = el(`<header class="topbar"><div class="in">
    <a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ألواح</b><small>ألواح الشمس</small></span></a>
    <span class="portal-name">${esc(P.short)}</span><span class="sp"></span>
    ${window.ALWAH_DEV?.dev_mode ? '<span class="devtag" title="رمز التحقق في كل الشاشات: 1234">وضع المطور · OTP 1234</span>' : ''}
    <span class="live" title="تحديث لحظي"><i class="dot"></i>مباشر</span>
    <${portal === 'citizen' ? 'a href="#profile" title="ملفي الشخصي"' : 'div'} class="who"><div class="meta" style="text-align:left"><div>${esc(profile.full_name)}</div><div class="org">${esc(org?.name || ROLE_LABELS[profile.role])}</div></div>
    <div class="av">${esc(profile.full_name.trim()[0])}</div></${portal === 'citizen' ? 'a' : 'div'}>
    <button class="btn btn-dark sm" data-out>خروج</button></div></header>`);
  const main = el('<main class="wrap"></main>');
  app.append(top, main);
  top.querySelector('[data-out]').onclick = async () => { await sb.auth.signOut(); location.reload(); };

  const ctx = { sb, profile, org, orgs, stages, root: main, portal, refresh: () => {} };
  try {
    const mod = await import(`./portals/${portal}.js`);
    ctx.mod = mod;
    let busy = false;
    ctx.refresh = async () => {
      if (busy) return; busy = true;
      try { await mod.render(ctx); } catch (e) { console.error(e); toast(cleanErr(e), 'bad'); }
      busy = false;
    };
    await ctx.refresh();
  } catch (e) {
    console.error(e);
    main.innerHTML = `<div class="card empty">تعذّر تحميل اللوحة: ${esc(cleanErr(e))}</div>`;
  }

  // تحديث لحظي: أي تغيير لدى جهة أخرى يظهر هنا دون إعادة تحميل
  let t;
  const bump = () => { clearTimeout(t); t = setTimeout(() => {
    if (ctx.mod?.shouldRefresh && !ctx.mod.shouldRefresh(ctx)) return; if (!document.querySelector('.drawer')) ctx.refresh(); else ctx.pending = true; }, 400); };
  sb.channel('alwah-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'applications' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'mortgage_referrals' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'integrity_alerts' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bank_allocations' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'application_events' }, bump)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'cbi_batches' }, bump)
    .subscribe();
  document.addEventListener('click', e => { if (ctx.pending && e.target.closest('[data-close],.drawer-bg')) { ctx.pending = false; setTimeout(ctx.refresh, 300); } });
}
