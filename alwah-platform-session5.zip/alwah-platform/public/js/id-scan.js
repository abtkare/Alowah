// تصوير البطاقة الوطنية وقراءتها تلقائياً عبر خدمة loan-ocr (على سيرفر المنصة الخاص)
// الكاميرا تملأ الشاشة، والالتقاط تلقائي حين تكون البطاقة واضحة وثابتة داخل الإطار:
// وجه البطاقة ← «اقلب البطاقة» ← ظهرها ← القراءة. لا يُقبل اختيار صورة من المعرض.
import { esc, GOVS } from './core.js';

const OCR = () => ((window.ALWAH_CONFIG || {}).ocr || '').replace(/\/+$/, '');
export const ocrEnabled = () => !!OCR();

const CARD = 1.586;        // نسبة عرض البطاقة إلى ارتفاعها
const PAD = 0.06;          // هامش حول الإطار تُكتشف فيه حواف البطاقة
const TARGET_MS = 15000;   // زمن القراءة المتوقع
const HARD_MS = 45000;     // أقصى انتظار قبل طلب إعادة المحاولة
const MANUAL_AFTER = 10000; // إن لم يلتقط تلقائياً خلال 10 ثوانٍ يظهر زر احتياطي

// ───────── تحليل إطار الفيديو (دالة نقية تُختبر خارج المتصفح) ─────────
// g: تدرج رمادي Uint8 بطول w*h لمنطقة الإطار مع الهامش. pad: الهامش بالبكسل
export function analyzeFrame(g, w, h, pad, side = 'front') {
  let sum = 0, glare = 0;
  for (let i = 0; i < g.length; i++) { sum += g[i]; if (g[i] >= 250) glare++; }
  const mean = sum / g.length, glareFrac = glare / g.length;
  const at = (x, y) => g[y * w + x];
  const band = Math.max(3, Math.round(pad * 2.2));
  // قوة الحافة: أعلى متوسط تدرج لعمود أو صف داخل شريط الحافة
  const colEdge = (x0, x1) => { let best = 0; for (let x = Math.max(1, x0); x < Math.min(w - 1, x1); x++) { let s = 0, n = 0; for (let y = Math.round(h * .2); y < h * .8; y += 2) { s += Math.abs(at(x + 1, y) - at(x - 1, y)); n++; } best = Math.max(best, s / n); } return best; };
  const rowEdge = (y0, y1) => { let best = 0; for (let y = Math.max(1, y0); y < Math.min(h - 1, y1); y++) { let s = 0, n = 0; for (let x = Math.round(w * .2); x < w * .8; x += 2) { s += Math.abs(at(x, y + 1) - at(x, y - 1)); n++; } best = Math.max(best, s / n); } return best; };
  const edges = [colEdge(0, band), colEdge(w - band, w), rowEdge(0, band), rowEdge(h - band, h)];
  const edgeCount = edges.filter(e => e >= 20).length;
  // الحدة: متوسط مطلق لابلاس داخل البطاقة
  let lap = 0, ln = 0;
  for (let y = band + 1; y < h - band - 1; y += 2) for (let x = band + 1; x < w - band - 1; x += 2) {
    lap += Math.abs(4 * at(x, y) - at(x - 1, y) - at(x + 1, y) - at(x, y - 1) - at(x, y + 1)); ln++;
  }
  const sharp = ln ? lap / ln : 0;
  // امتلاء الإطار: البطاقة فاتحة اللون، فالجزء الداخلي يجب أن يكون فاتحاً في أغلبه (يرفض البطاقة الصغيرة البعيدة)
  // العتبة نسبةً إلى أفتح 10% في الصورة (البطاقة أفتح ما في الإطار عادةً)
  const hist = new Uint32Array(256); for (let i = 0; i < g.length; i += 3) hist[g[i]]++;
  let acc = 0, p90 = 255; const lim = (g.length / 3) * 0.9; for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= lim) { p90 = v; break; } }
  const thr = Math.max(100, p90 * 0.72);
  // كل جانب من البطاقة يجب أن يكون فاتحاً قرب حافة الإطار (أضعف جانب هو المقياس)
  let light = 0, tot = 0; const sl = [0, 0, 0, 0], sn = [0, 0, 0, 0], k = band * 1.8;
  for (let y = band; y < h - band; y += 2) for (let x = band; x < w - band; x += 2) {
    const v = at(x, y) > thr ? 1 : 0; light += v; tot++;
    if (x < k) { sl[0] += v; sn[0]++; } if (x > w - k) { sl[1] += v; sn[1]++; }
    if (y < k) { sl[2] += v; sn[2]++; } if (y > h - k) { sl[3] += v; sn[3]++; }
  }
  const sides = sl.map((v, i) => sn[i] ? v / sn[i] : 0), fill = tot ? light / tot : 0;
  // ثلاثة جوانب فاتحة على الأقل (الجانب الرابع قد تغطيه صورة الوجه في البطاقة)
  const rim = sides.filter(x => x >= 0.6).length;
  // الظهر: شريط الأحرف السفلي يعطي طاقة نصية عالية في الثلث الأسفل
  let mrz = 0;
  if (side === 'back') { let s = 0, n = 0; for (let y = Math.round(h * .62); y < h - band; y++) for (let x = band; x < w - band - 1; x += 2) { s += Math.abs(at(x + 1, y) - at(x, y)); n++; } mrz = n ? s / n : 0; }
  let msg = '', ok = false;
  if (mean < 55) msg = 'الإضاءة ضعيفة — انتقل إلى مكان أكثر إضاءة';
  else if (edgeCount < 3 || fill < 0.5 || rim < 3) msg = 'ضع البطاقة داخل الإطار وقرّبها حتى تلامس حوافه';
  else if (glareFrac > 0.05) msg = 'يوجد انعكاس ضوء على البطاقة — أمِلها قليلاً أو ابتعد عن الضوء المباشر';
  else if (sharp < 7) msg = 'الصورة غير واضحة — ثبّت الهاتف';
  else if (side === 'back' && mrz < 9) msg = 'اقلب البطاقة: نحتاج الوجه الخلفي مع الشريط السفلي';
  else { ok = true; msg = 'ممتاز — لا تتحرك…'; }
  return { ok, msg, mean, glareFrac, edges, edgeCount, sharp, mrz, fill, rim, sides };
}

const diff = (a, b) => { if (!a || a.length !== b.length) return 255; let s = 0; for (let i = 0; i < a.length; i += 3) s += Math.abs(a[i] - b[i]); return s / (a.length / 3); };

// ───────── قراءة البيانات من الخادم ─────────
const VAL = f => k => { const x = f[k]; return x && typeof x === 'object' ? (x.value ?? '') : (x ?? ''); };
const pick = (v, ...ks) => { for (const k of ks) { const s = String(v(k) || '').trim(); if (s) return s; } return ''; };
const isoDate = s => { s = String(s || '').trim().replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  let m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; return ''; };
const normAr = s => String(s || '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim();

// مطابقة مكان الولادة مع قائمة المحافظات («النجف-النجف»، «بغداد / الكرخ»…)
export function matchGov(place) {
  if (!place) return '';
  const p = normAr(place);
  const hit = GOVS.find(([g]) => { const n = normAr(g); return p.includes(n) || p.includes(n.replace(/^ال/, '')); });
  if (hit) return hit[0];
  const alias = [['قادسيه', 'الديوانية'], ['ناصريه', 'ذي قار'], ['موصل', 'نينوى'], ['رمادي', 'الأنبار'], ['حله', 'بابل'], ['كوت', 'واسط'], ['عماره', 'ميسان'], ['سماوه', 'المثنى'], ['بعقوبه', 'ديالى'], ['تكريت', 'صلاح الدين'], ['اربيل', 'أربيل'], ['سليمانيه', 'السليمانية']];
  const a = alias.find(([k]) => p.includes(k)); return a ? a[1] : '';
}

// تقسيم الاسم إلى: الاسم، الأب، الجد، اللقب (الأسماء المركبة «عبد …» و«… الدين» تبقى كلمة واحدة)
export function splitName(full) {
  const raw = String(full || '').replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
  const t = [];
  for (let i = 0; i < raw.length; i++) {
    const w = raw[i];
    if (/^(عبد|عبدال|ابو|أبو)$/.test(w) && raw[i + 1]) { t.push(w + ' ' + raw[++i]); continue; }
    if (/^(الدين|الله)$/.test(w) && t.length && !/^(عبد|ابو|أبو)\s/.test(t[t.length - 1])) { t[t.length - 1] += ' ' + w; continue; }
    t.push(w);
  }
  const r = { first: t[0] || '', father: t[1] || '', grand: '', fourth: '', surname: '' };
  if (t.length === 3) { if (/^ال/.test(t[2])) r.surname = t[2]; else r.grand = t[2]; }
  else if (t.length === 4) { r.grand = t[2]; r.surname = t[3]; }
  else if (t.length >= 5) { r.grand = t[2]; r.fourth = t.slice(3, -1).join(' '); r.surname = t[t.length - 1]; }
  return r;
}

export function parseIdResponse(data) {
  const f = data.fields || data.data || {}; const v = VAL(f);
  const full = pick(v, 'full_name', 'name_ar', 'name');
  const parts = splitName(full);
  const first = pick(v, 'first_name', 'given_name'), father = pick(v, 'father_name'), grand = pick(v, 'grandfather_name', 'grand_father_name');
  const surname = pick(v, 'surname', 'family_name', 'last_name', 'tribe', 'laqab', 'title_name');
  if (first) parts.first = first; if (father) parts.father = father; if (grand) parts.grand = grand; if (surname) parts.surname = surname;
  const nid = String(pick(v, 'national_id_number', 'national_id', 'personal_number')).replace(/\D/g, '');
  const place = pick(v, 'place_of_birth', 'birth_place', 'pob');
  const g = pick(v, 'gender', 'sex').toLowerCase();
  const conf = k => { const x = f[k]; return x && typeof x === 'object' ? Number(x.confidence ?? 1) : 1; };
  return {
    parts, name: full,
    nid: nid.length === 12 ? nid : '',
    bd: isoDate(pick(v, 'date_of_birth', 'birth_date', 'dob')),
    place, gov: matchGov(place),
    mother: pick(v, 'mother_name', 'mother_full_name'),
    gender: /^(m|male|ذكر)/.test(g) ? 'male' : /^(f|female|انثى|أنثى)/.test(g) ? 'female' : '',
    cardNo: pick(v, 'card_number', 'document_number'), expiry: isoDate(pick(v, 'expiry_date', 'date_of_expiry')),
    issue: isoDate(pick(v, 'issue_date', 'date_of_issue')), issuer: pick(v, 'issuer', 'issuing_authority'),
    family: pick(v, 'family_number', 'family_no'), blood: pick(v, 'blood_type', 'blood_group'), latin: pick(v, 'name_latin', 'name_en', 'mrz_name'),
    warnings: data.warnings || [], verified: !!data.mrz_verified,
    weak: [['full_name', 'الاسم'], ['national_id_number', 'الرقم الوطني'], ['date_of_birth', 'تاريخ الميلاد']].filter(([k]) => f[k] && v(k) && conf(k) < 0.8).map(([, l]) => l),
    keys: Object.keys(f),
  };
}

export async function readNationalId(front, back, onSlow) {
  const body = new FormData();
  if (front) body.append('front', front, 'front.jpg');
  if (back) body.append('back', back, 'back.jpg');
  const ctl = new AbortController();
  const slow = setTimeout(() => onSlow && onSlow(), TARGET_MS);
  const t = setTimeout(() => ctl.abort(), HARD_MS);
  let res;
  try { res = await fetch(OCR() + '/api/v1/documents/national-id', { method: 'POST', body, signal: ctl.signal }); }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'استغرقت القراءة وقتاً طويلاً — أعد المحاولة' : 'تعذر الاتصال بخدمة قراءة البطاقة، تحقق من الإنترنت'); }
  finally { clearTimeout(t); clearTimeout(slow); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data.error && data.error.message) || 'تعذرت قراءة البطاقة');
  return parseIdResponse(data);
}

// ───────── الكاميرا الكاملة بالالتقاط التلقائي ─────────
// تعيد { front, back } (Blob لكل وجه) أو null عند الإغلاق
function autoCapture() {
  return new Promise(resolve => {
    const bg = document.createElement('div');
    bg.className = 'cam idcam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <div class="cam-frame"><i></i><i></i><i></i><i></i><b class="cam-prog"></b></div>
      <div class="cam-top"><button type="button" class="cam-x" aria-label="إغلاق">✕</button><span class="cam-step"></span></div>
      <p class="cam-hint"><span data-t></span><small data-s></small></p>
      <div class="cam-flip" hidden><div class="flipcard"><i></i></div><b>✓ تم تصوير وجه البطاقة</b><span>اقلب البطاقة الآن على الوجه الخلفي</span></div>
      <div class="cam-bar"><button type="button" class="cam-shoot" hidden aria-label="التقاط يدوي"></button></div>`;
    document.body.appendChild(bg);
    document.documentElement.classList.add('noscroll');
    const video = bg.querySelector('video'), frame = bg.querySelector('.cam-frame'), prog = bg.querySelector('.cam-prog');
    const T = bg.querySelector('[data-t]'), Sm = bg.querySelector('[data-s]'), stepEl = bg.querySelector('.cam-step'), shoot = bg.querySelector('.cam-shoot');
    const work = document.createElement('canvas'), wctx = work.getContext('2d', { willReadFrequently: true });
    const shots = {}; let side = 'front', stream = null, timer = 0, good = 0, prev = null, sideAt = 0, closed = false, busy = false;

    const finish = v => { if (closed) return; closed = true; clearInterval(timer); stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); document.documentElement.classList.remove('noscroll'); resolve(v); };
    bg.querySelector('.cam-x').onclick = () => finish(null);

    const setSide = s => {
      side = s; good = 0; prev = null; sideAt = Date.now(); shoot.hidden = true;
      stepEl.textContent = s === 'front' ? '١ من ٢ — وجه البطاقة' : '٢ من ٢ — ظهر البطاقة';
      T.textContent = s === 'front' ? 'ضع وجه البطاقة (الصورة والاسم) داخل الإطار' : 'ضع ظهر البطاقة داخل الإطار والشريط السفلي ظاهر';
      Sm.textContent = 'سيُلتقط تلقائياً حين تكون واضحة — أخرجها من الغلاف وتجنّب الشمس المباشرة';
    };
    // منطقة الإطار في إحداثيات الفيديو
    const region = (padK = PAD) => {
      const VW = video.videoWidth, VH = video.videoHeight; if (!VW) return null;
      const vr = video.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      const k = Math.max(vr.width / VW, vr.height / VH);
      const x0 = vr.left + (vr.width - VW * k) / 2, y0 = vr.top + (vr.height - VH * k) / 2, p = padK * fr.width;
      let sx = (fr.left - p - x0) / k, sy = (fr.top - p - y0) / k, sw = (fr.width + 2 * p) / k, sh = (fr.height + 2 * p) / k;
      sx = Math.max(0, sx); sy = Math.max(0, sy); sw = Math.min(VW - sx, sw); sh = Math.min(VH - sy, sh);
      return { sx, sy, sw, sh, padPx: p / k };
    };
    const grab = () => new Promise(r => {
      const R = region(0.03); if (!R) return r(null);
      const c = document.createElement('canvas'), s = Math.min(1, 1600 / R.sw);
      c.width = Math.round(R.sw * s); c.height = Math.round(R.sh * s);
      c.getContext('2d').drawImage(video, R.sx, R.sy, R.sw, R.sh, 0, 0, c.width, c.height);
      c.toBlob(b => r(b), 'image/jpeg', 0.92);
    });
    const take = async () => {
      if (busy) return; busy = true;
      const b = await grab(); busy = false; if (!b) return;
      shots[side] = b;
      if (navigator.vibrate) navigator.vibrate(60);
      frame.classList.add('snap'); setTimeout(() => frame.classList.remove('snap'), 350);
      if (side === 'front') {
        const fl = bg.querySelector('.cam-flip'); fl.hidden = false; clearInterval(timer);
        setTimeout(() => { if (closed) return; fl.hidden = true; setSide('back'); timer = setInterval(tick, 200); }, 2200);
      } else finish(shots);
    };
    shoot.onclick = take;
    const tick = () => {
      if (busy || !video.videoWidth) return;
      const R = region(); if (!R) return;
      const W = 320, H = Math.round(W * R.sh / R.sw);
      work.width = W; work.height = H;
      wctx.drawImage(video, R.sx, R.sy, R.sw, R.sh, 0, 0, W, H);
      const px = wctx.getImageData(0, 0, W, H).data, gray = new Uint8Array(W * H);
      for (let i = 0, j = 0; j < gray.length; i += 4, j++) gray[j] = (px[i] * 77 + px[i + 1] * 150 + px[i + 2] * 29) >> 8;
      const a = analyzeFrame(gray, W, H, R.padPx * W / R.sw, side);
      const still = diff(prev, gray) < 7; prev = gray;
      const ok = a.ok && still;
      good = ok ? good + 1 : 0;
      T.textContent = ok ? 'ممتاز — لا تتحرك…' : (a.ok ? 'ثبّت الهاتف قليلاً' : a.msg);
      frame.classList.toggle('good', ok);
      prog.style.width = Math.min(100, good / 4 * 100) + '%';
      if (good >= 4) { good = 0; take(); return; }
      if (Date.now() - sideAt > MANUAL_AFTER && shoot.hidden) { shoot.hidden = false; Sm.textContent = 'إن لم يُلتقط تلقائياً، اضغط الزر حين تكون البطاقة واضحة'; }
    };
    const fit = () => { const w = Math.min(innerWidth * 0.92, innerHeight * 0.5 * CARD, 620); frame.style.width = w + 'px'; frame.style.height = w / CARD + 'px'; };
    fit(); addEventListener('resize', fit);
    setSide('front');
    (navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      ? navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false })
      : Promise.reject())
      .then(st => {
        stream = st; video.srcObject = st;
        const tr = st.getVideoTracks()[0];
        try { tr.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {}); } catch { /* غير مدعوم */ }
        timer = setInterval(tick, 200);
      })
      .catch(() => { T.textContent = 'تعذر فتح الكاميرا'; Sm.textContent = 'اسمح للموقع باستخدام الكاميرا من إعدادات المتصفح ثم أعد المحاولة. لا يُقبل اختيار صورة من المعرض حمايةً لبياناتك.'; });
  });
}

// ───────── واجهة الخطوة ─────────
export function mountIdScan(root, { onResult, onSkip, onBack, errBox }) {
  root.innerHTML = `<h2>صوّر بطاقتك الوطنية</h2>
    <p class="sub">نقرأ بياناتك ونتحقق منها تلقائياً لفتح حسابك المصرفي. تفتح الكاميرا على كامل الشاشة وتلتقط البطاقة وحدها حين تكون واضحة.</p>
    ${errBox('')}
    <ol class="idhow"><li><b>وجه البطاقة</b><span>ضعه داخل الإطار ولا تضغط شيئاً</span></li><li><b>اقلب البطاقة</b><span>نلتقط الظهر مع الشريط السفلي</span></li><li><b>القراءة والتحقق</b><span>خلال ثوانٍ تُملأ بياناتك</span></li></ol>
    <div class="idtips small muted">• أخرج البطاقة من الغلاف البلاستيكي &nbsp;• ضعها على سطح داكن &nbsp;• تجنّب الشمس المباشرة والانعكاس</div>
    <div class="idbusy" hidden><i></i><span data-busy>جارِ قراءة البطاقة والتحقق منها…</span></div>
    <div class="idprev" hidden></div>
    <button class="btn cyan block" type="button" data-start>ابدأ تصوير البطاقة</button>
    <div class="row mt"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button type="button" class="linkbtn" data-skip>الإدخال يدوياً بدلاً من ذلك</button></div>`;
  const btn = root.querySelector('[data-start]'), busy = root.querySelector('.idbusy'), busyT = root.querySelector('[data-busy]'), prevBox = root.querySelector('.idprev');
  const showErr = m => { const e = root.querySelector('.err'); e.textContent = m; e.classList.toggle('on', !!m); if (m) e.scrollIntoView({ block: 'nearest' }); };
  root.querySelector('[data-skip]').onclick = onSkip;
  root.querySelector('[data-back]').onclick = onBack;
  btn.onclick = async () => {
    showErr('');
    const shots = await autoCapture();
    if (!shots) return;
    prevBox.hidden = false;
    prevBox.innerHTML = ['front', 'back'].map(k => `<figure><img alt="" src="${URL.createObjectURL(shots[k])}"><figcaption>${k === 'front' ? 'الوجه' : 'الظهر'}</figcaption></figure>`).join('');
    btn.disabled = true; btn.textContent = 'جارِ القراءة…'; busy.hidden = false; busyT.textContent = 'جارِ قراءة البطاقة والتحقق منها…';
    const t0 = Date.now();
    try {
      const r = await readNationalId(shots.front, shots.back, () => { busyT.textContent = 'القراءة أبطأ من المعتاد — لحظات من فضلك…'; });
      if (!r.parts.first && !r.nid) throw new Error('لم نتمكن من قراءة البيانات — أعد التصوير بإضاءة أفضل أو أدخلها يدوياً');
      r.ms = Date.now() - t0; r.shots = shots;
      onResult(r);
    } catch (e) {
      showErr(e.message); btn.disabled = false; btn.textContent = 'إعادة تصوير البطاقة';
    } finally { busy.hidden = true; }
  };
}

export const scanNote = r => `<div class="idnote ${r.verified ? 'ok' : ''}">${r.verified ? '✓ قُرئت بياناتك وتحققنا منها بالشريط السفلي للبطاقة' : '✓ قُرئت البيانات من بطاقتك تلقائياً'} — راجعها قبل الإرسال${r.ms ? ` · خلال <span class="num">${(r.ms / 1000).toFixed(1)}</span> ثانية` : ''}${r.weak && r.weak.length ? `<small>• تأكد خاصةً من: ${esc(r.weak.join('، '))}</small>` : ''}${!r.bd ? '<small>• لم يُقرأ تاريخ الميلاد — اختره يدوياً</small>' : ''}${(r.warnings || []).map(w => `<small>• ${esc(w)}</small>`).join('')}</div>`;
