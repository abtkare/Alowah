// الجلسة 41: صفحة التحقق العامة — تفتح من رمز QR على الوعد أو العقد أو الفاتورة أو المحضر، دون تسجيل دخول
// تثبت أمرين: 1) النص المحفوظ لم يتغير منذ التوقيع  2) قالبه هو النسخة التي اعتمدتها الهيئة الشرعية حرفياً
const CFG = window.ALWAH_CONFIG || {};
const app = document.getElementById('app');
const code = decodeURIComponent(location.pathname.split('/')[2] || '').trim().toUpperCase();
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const iqd = n => n == null ? '—' : `${Math.round(Number(n)).toLocaleString('en-US')} د.ع`;
const day = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'long' }) : '—';
const KIND = { promise: 'وعد غير ملزم', contract: 'عقد موقّع', invoice: 'فاتورة المورد باسم المصرف', receipt: 'محضر استلام وقبض', shares: 'سجل الحصص', share_sale: 'عقد بيع حصة' };
const shell = inner => {
  app.innerHTML = `<div class="lk"><header class="lk-h"><a class="brand" href="/"><img src="/alwah-logo/alwah-icon-128.webp" alt=""><span><b>ألواح</b><small>التحقق من المستندات</small></span></a></header>
    <main class="card lk-b vf">${inner}</main><p class="small muted lk-f">صفحة عامة من منصة «ألواح» — تعرض ما يكفي للتحقق فقط، دون بيانات المقترض الشخصية.</p></div>`;
};
const row = (ok, t, d) => `<li class="${ok ? 'ok' : 'no'}"><i>${ok ? '✓' : '✗'}</i><div><b>${t}</b>${d ? `<small>${d}</small>` : ''}</div></li>`;

try {
  if (!/^[A-Z0-9]{6,16}$/.test(code)) throw new Error('missing');
  // الجلسة 52: كتب اتحاد الصناعات العراقي وهوياته (رموزها تبدأ بـ IF)
  if (code.startsWith('IF') && await unionVerify()) throw new Error('done');
  if (code.startsWith('CC') && await chamberVerify()) throw new Error('done');   // الجلسة 56
  const r = await fetch(`${CFG.url}/rest/v1/rpc/islamic_verify`, { method: 'POST', headers: { apikey: CFG.key, Authorization: `Bearer ${CFG.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_code: code }) });
  if (!r.ok) throw new Error('net');
  const d = await r.json();
  if (!d?.found) throw new Error('missing');
  const all = d.doc_intact && d.version_intact && d.approved && !d.void;
  shell(`<div class="vf-top ${all ? 'ok' : 'bad'}"><div class="vf-ic">${all ? '✓' : '!'}</div><div><h2>${all ? 'مستند سليم ومطابق للنسخة المعتمدة' : d.void ? 'هذا المستند استُبدل بنسخة أحدث' : 'تعذّر إثبات سلامة المستند'}</h2>
      <p class="muted">${esc(KIND[d.kind] || d.kind)} — ${esc(d.title)}</p></div></div>
    <ul class="vf-checks">
      ${row(d.doc_intact, 'النص لم يتغير منذ التوقيع', 'بصمة النص المحفوظ تطابق بصمته لحظة التوقيع')}
      ${row(d.version_intact, 'قالب العقد هو النسخة المعتمدة حرفياً', `النسخة <span class="num">${esc(d.version)}</span> من عقد «${esc(d.product)}»`)}
      ${row(d.approved, 'معتمد من الهيئة الشرعية', d.resolution ? `قرار <b class="num">${esc(d.resolution)}</b> — ${esc(d.board || '')} · ${day(d.resolution_at)}` : 'لا قرار اعتماد لهذه النسخة')}
    </ul>
    <dl class="kv vf-kv"><dt>المصرف</dt><dd>${esc(d.bank)}</dd><dt>الصيغة</dt><dd>${esc(d.type_name)}</dd><dt>الطلب</dt><dd><span class="num" dir="ltr">${esc(d.app)}</span></dd>
      <dt>${d.kind === 'invoice' || d.kind === 'receipt' ? 'أصدره' : 'وقّعه'}</dt><dd>${esc(d.signer)} — ${esc(d.signer_title || '')}</dd><dt>التاريخ</dt><dd>${day(d.at)}</dd>
      ${d.amount ? `<dt>المبلغ</dt><dd>${iqd(d.amount)}</dd>` : ''}<dt>رمز التحقق</dt><dd><b class="num" dir="ltr">${esc(code)}</b></dd></dl>
    <details class="small mt"><summary>البصمات الرقمية (SHA-256)</summary><p class="num vf-sha" dir="ltr">النص: ${esc(d.doc_sha256)}<br>النسخة المعتمدة: ${esc(d.version_sha256)}</p></details>`);
} catch (e) {
  if (e.message !== 'done') shell(`<div class="vf-top bad"><div class="vf-ic">!</div><div><h2>${e.message === 'net' ? 'تعذّر الاتصال — حاول مجدداً' : 'رمز التحقق غير صحيح'}</h2>
    <p class="muted">${e.message === 'net' ? 'تحقق من اتصالك بالإنترنت ثم أعد فتح الرابط.' : 'تأكد أنك مسحت الرمز كاملاً، أو اكتب الرمز المطبوع تحت رمز QR كما هو.'}</p></div></div>`);
}

async function unionVerify() {
  const r = await fetch(`${CFG.url}/rest/v1/rpc/union_verify`, { method: 'POST', headers: { apikey: CFG.key, Authorization: `Bearer ${CFG.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_code: code }) });
  if (!r.ok) return false;
  const d = await r.json();
  if (!d?.found) return false;
  const KN = { membership: 'قرار انتماء وهوية صناعية', endorse: 'كتاب تأييد صناعي لمصرف', install: 'تأييد نصب المكائن', production: 'تأييد بدء الإنتاج', followup: 'تقرير كشف متابعة',
    certificate: 'كتاب تأييد عضوية', cancel: 'كتاب إلغاء الانتماء وبراءة الذمة' };
  // الجلسة 53: رمز نسخة قديمة من الهوية (صدر بدلها بدل ضائع أو تالف)
  if (d.type === 'member_old') {
    shell(`<div class="vf-top bad"><div class="vf-ic">!</div><div><h2>هذه النسخة من الهوية ملغاة</h2><p class="muted">اتحاد الصناعات العراقي — صدرت بدلها نسخة أحدث (بدل ضائع أو تالف)</p></div></div>
      <dl class="kv vf-kv"><dt>رقم الهوية</dt><dd><b class="num" dir="ltr">${esc(d.member)}</b></dd><dt>المعمل</dt><dd>${esc(d.factory)}</dd><dt>النسخة النافذة</dt><dd class="num">${esc(d.version)}</dd></dl>
      <p class="small muted">اطلب من صاحب الهوية رمز النسخة الأحدث من هاتفه.</p>`);
    return true;
  }
  if (d.type === 'member') {
    const ok = d.valid && d.intact;
    shell(`<div class="vf-top ${ok ? 'ok' : 'bad'}"><div class="vf-ic">${ok ? '✓' : '!'}</div><div><h2>${ok ? 'هوية صناعية نافذة' : d.status === 'suspended' ? 'الهوية معلّقة' : d.status === 'cancelled' ? 'أُلغي الانتماء — الهوية غير نافذة' : d.status === 'expired' ? 'الهوية منتهية' : 'الهوية غير نافذة'}</h2>
      <p class="muted">اتحاد الصناعات العراقي</p></div></div>
      <ul class="vf-checks">${row(d.intact, 'بيانات الهوية لم تتغير منذ إصدارها', 'بصمتها الرقمية مطابقة')}${row(d.valid, 'العضوية نافذة', d.valid_until ? `حتى ${day(d.valid_until)}` : '')}</ul>
      <dl class="kv vf-kv"><dt>رقم الهوية</dt><dd><b class="num" dir="ltr">${esc(d.member)}</b></dd><dt>المعمل</dt><dd>${esc(d.factory)}</dd><dt>صاحبه</dt><dd>${esc(d.owner)}</dd>
        <dt>الصنف</dt><dd>${esc(d.category)}</dd><dt>المحافظة</dt><dd>${esc(d.governorate)}</dd><dt>الانتماء</dt><dd>${day(d.joined)}</dd></dl>`);
    return true;
  }
  const ok = d.intact && !d.revoked && !d.expired && (d.result == null || d.result === 'ok') && (d.kind !== 'certificate' || d.member_valid);
  shell(`<div class="vf-top ${ok ? 'ok' : 'bad'}"><div class="vf-ic">${ok ? '✓' : '!'}</div><div><h2>${d.revoked ? 'هذا الكتاب مسحوب' : !d.intact ? 'تحذير: نص الكتاب تغيّر' : d.expired ? 'انتهت مدة نفاذ الكتاب' : d.result === 'not_ok' ? 'كتاب صحيح — نتيجته غير مطابقة' : 'كتاب صحيح ونافذ'}</h2>
    <p class="muted">${esc(KN[d.kind] || '')} — اتحاد الصناعات العراقي</p></div></div>
    <ul class="vf-checks">${row(d.intact, 'النص لم يتغير منذ الإصدار', 'بصمة النص المحفوظ تطابق بصمته لحظة الإصدار')}${row(!d.revoked, 'غير مسحوب', d.revoked ? esc(d.revoke_reason || '') : '')}
      ${d.valid_until ? row(!d.expired, 'ضمن مدة النفاذ', `حتى ${day(d.valid_until)}`) : ''}${d.kind === 'certificate' ? row(d.member_valid, 'هوية المنتسب نافذة الآن', d.member_valid ? '' : 'انتهت الهوية أو عُلّقت بعد صدور الكتاب') : ''}${d.kind === 'endorse' ? row(d.ack, 'استلمه المصرف', d.ack_at ? day(d.ack_at) : 'لم يؤكد المصرف الاستلام بعد') : ''}</ul>
    <dl class="kv vf-kv"><dt>العدد</dt><dd><b class="num" dir="ltr">${esc(d.no)}</b></dd><dt>العنوان</dt><dd>${esc(d.title)}</dd><dt>المعمل</dt><dd>${esc(d.factory)} — <span class="num">${esc(d.member || '')}</span></dd>
      ${d.bank ? `<dt>المصرف</dt><dd>${esc(d.bank)}</dd>` : ''}${d.to ? `<dt>موجّه إلى</dt><dd>${esc(d.to)}</dd><dt>الغرض</dt><dd>${esc(d.purpose || '')}</dd>` : ''}${d.amount ? `<dt>المبلغ</dt><dd>${iqd(d.amount)}</dd>` : ''}<dt>أصدره</dt><dd>${esc(d.issuer)} — ${esc(d.issuer_title || '')}</dd><dt>التاريخ</dt><dd>${day(d.issued_at)}</dd>
      <dt>رمز التحقق</dt><dd><b class="num" dir="ltr">${esc(code)}</b></dd></dl>
    <details class="small mt"><summary>البصمة الرقمية (SHA-256)</summary><p class="num vf-sha" dir="ltr">${esc(d.sha256)}</p></details>`);
  return true;
}

// الجلسة 56: كتب اتحاد الغرف التجارية وهوياته (رموزها تبدأ بـ CC)
async function chamberVerify() {
  const r = await fetch(`${CFG.url}/rest/v1/rpc/chamber_verify`, { method: 'POST', headers: { apikey: CFG.key, Authorization: `Bearer ${CFG.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_code: code }) });
  if (!r.ok) return false;
  const d = await r.json();
  if (!d?.found) return false;
  const KN = { membership: 'قرار انتماء وهوية غرفة تجارية', endorse: 'كتاب تأييد تجاري لمصرف', install: 'تأييد تجهيز المحل', production: 'تأييد مزاولة النشاط', followup: 'تقرير كشف متابعة',
    certificate: 'كتاب تأييد عضوية', cancel: 'كتاب إلغاء الانتماء وبراءة الذمة' };
  // الجلسة 53: رمز نسخة قديمة من الهوية (صدر بدلها بدل ضائع أو تالف)
  if (d.type === 'member_old') {
    shell(`<div class="vf-top bad"><div class="vf-ic">!</div><div><h2>هذه النسخة من الهوية ملغاة</h2><p class="muted">اتحاد الغرف التجارية العراقية — صدرت بدلها نسخة أحدث (بدل ضائع أو تالف)</p></div></div>
      <dl class="kv vf-kv"><dt>رقم الهوية</dt><dd><b class="num" dir="ltr">${esc(d.member)}</b></dd><dt>المحل</dt><dd>${esc(d.factory)}</dd><dt>النسخة النافذة</dt><dd class="num">${esc(d.version)}</dd></dl>
      <p class="small muted">اطلب من صاحب الهوية رمز النسخة الأحدث من هاتفه.</p>`);
    return true;
  }
  if (d.type === 'member') {
    const ok = d.valid && d.intact;
    shell(`<div class="vf-top ${ok ? 'ok' : 'bad'}"><div class="vf-ic">${ok ? '✓' : '!'}</div><div><h2>${ok ? 'هوية غرفة تجارية نافذة' : d.status === 'suspended' ? 'الهوية معلّقة' : d.status === 'cancelled' ? 'أُلغي الانتماء — الهوية غير نافذة' : d.status === 'expired' ? 'الهوية منتهية' : 'الهوية غير نافذة'}</h2>
      <p class="muted">اتحاد الغرف التجارية العراقية</p></div></div>
      <ul class="vf-checks">${row(d.intact, 'بيانات الهوية لم تتغير منذ إصدارها', 'بصمتها الرقمية مطابقة')}${row(d.valid, 'العضوية نافذة', d.valid_until ? `حتى ${day(d.valid_until)}` : '')}</ul>
      <dl class="kv vf-kv"><dt>رقم الهوية</dt><dd><b class="num" dir="ltr">${esc(d.member)}</b></dd><dt>المحل</dt><dd>${esc(d.factory)}</dd><dt>صاحبه</dt><dd>${esc(d.owner)}</dd>
        <dt>النشاط</dt><dd>${esc(d.category)}</dd><dt>المحافظة</dt><dd>${esc(d.governorate)}</dd><dt>الانتماء</dt><dd>${day(d.joined)}</dd></dl>`);
    return true;
  }
  const ok = d.intact && !d.revoked && !d.expired && (d.result == null || d.result === 'ok') && (d.kind !== 'certificate' || d.member_valid);
  shell(`<div class="vf-top ${ok ? 'ok' : 'bad'}"><div class="vf-ic">${ok ? '✓' : '!'}</div><div><h2>${d.revoked ? 'هذا الكتاب مسحوب' : !d.intact ? 'تحذير: نص الكتاب تغيّر' : d.expired ? 'انتهت مدة نفاذ الكتاب' : d.result === 'not_ok' ? 'كتاب صحيح — نتيجته غير مطابقة' : 'كتاب صحيح ونافذ'}</h2>
    <p class="muted">${esc(KN[d.kind] || '')} — اتحاد الغرف التجارية العراقية</p></div></div>
    <ul class="vf-checks">${row(d.intact, 'النص لم يتغير منذ الإصدار', 'بصمة النص المحفوظ تطابق بصمته لحظة الإصدار')}${row(!d.revoked, 'غير مسحوب', d.revoked ? esc(d.revoke_reason || '') : '')}
      ${d.valid_until ? row(!d.expired, 'ضمن مدة النفاذ', `حتى ${day(d.valid_until)}`) : ''}${d.kind === 'certificate' ? row(d.member_valid, 'هوية المنتسب نافذة الآن', d.member_valid ? '' : 'انتهت الهوية أو عُلّقت بعد صدور الكتاب') : ''}${d.kind === 'endorse' ? row(d.ack, 'استلمه المصرف', d.ack_at ? day(d.ack_at) : 'لم يؤكد المصرف الاستلام بعد') : ''}</ul>
    <dl class="kv vf-kv"><dt>العدد</dt><dd><b class="num" dir="ltr">${esc(d.no)}</b></dd><dt>العنوان</dt><dd>${esc(d.title)}</dd><dt>المحل</dt><dd>${esc(d.factory)} — <span class="num">${esc(d.member || '')}</span></dd>
      ${d.bank ? `<dt>المصرف</dt><dd>${esc(d.bank)}</dd>` : ''}${d.to ? `<dt>موجّه إلى</dt><dd>${esc(d.to)}</dd><dt>الغرض</dt><dd>${esc(d.purpose || '')}</dd>` : ''}${d.amount ? `<dt>المبلغ</dt><dd>${iqd(d.amount)}</dd>` : ''}<dt>أصدره</dt><dd>${esc(d.issuer)} — ${esc(d.issuer_title || '')}</dd><dt>التاريخ</dt><dd>${day(d.issued_at)}</dd>
      <dt>رمز التحقق</dt><dd><b class="num" dir="ltr">${esc(code)}</b></dd></dl>
    <details class="small mt"><summary>البصمة الرقمية (SHA-256)</summary><p class="num vf-sha" dir="ltr">${esc(d.sha256)}</p></details>`);
  return true;
}
