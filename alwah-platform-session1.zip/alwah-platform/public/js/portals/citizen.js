// بوابة المواطن — طلبي ومراحله، والكتالوج (الاختيار الكامل في الجلسة 2)
import { esc, iqd, num, statusBadge, stageBar, stageList, eventsList, GUARANTEE, ADVANCE_LABEL, rpc, toast, cleanErr, tabs } from '../core.js';

export async function render(ctx) {
  const { sb, root, profile, stages, orgs } = ctx;
  const [apps, tiers, offers] = await Promise.all([
    sb.from('applications').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
    sb.from('supplier_offers').select('*').eq('status', 'published').order('price').then(r => r.data || []),
  ]);
  const org = id => orgs.find(o => o.id === id);
  const app = apps[0];

  root.innerHTML = `<div class="page-head"><div><h1>أهلاً ${esc(profile.full_name.split(' ')[0])}</h1><p>تابع طلب تمويل منظومتك، وكل جهة تمسكه، وكم مضى عليه.</p></div></div><div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'mine', label: 'طلبي' }, { key: 'catalog', label: 'كتالوج القدرات' }];
  ctx.czTab = ctx.czTab || (app ? 'mine' : 'catalog');
  tabs(root.querySelector('#tabs'), defs, k => { ctx.czTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.czTab));

  async function show(k) {
    if (k === 'mine') {
      if (!app) { body.innerHTML = '<div class="card empty"><h3>لا يوجد طلب بعد</h3><p>ابدأ من «كتالوج القدرات» واختر القدرة التي تناسب منزلك.</p></div>'; return; }
      const cur = stages.find(s => s.n === app.stage);
      const days = Math.max(0, Math.round((Date.now() - new Date(app.updated_at)) / 864e5));
      const events = (await sb.from('application_events').select('*').eq('application_id', app.id).order('id')).data || [];
      const myTurn = cur?.owner_role === 'citizen' && ['active', 'returned'].includes(app.status);
      body.innerHTML = `
        <div class="card mb" style="background:linear-gradient(135deg,#0A1630,#14264F);color:#fff;border:0">
          <div class="row"><div><div class="small" style="color:#9FB4D6">رقم الطلب</div><h2 class="num" style="font-size:26px">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}</div>
          ${stageBar(app)}
          <div class="row mt"><div><div class="small" style="color:#9FB4D6">المرحلة الحالية</div><b style="font-size:18px">${app.stage}. ${esc(cur?.name)}</b></div><span class="sp"></span>
          <div><div class="small" style="color:#9FB4D6">الطلب الآن لدى</div><b style="color:var(--cyan)">${esc(app.status === 'completed' ? 'مكتمل' : cur?.owner_label)}</b></div>
          <div><div class="small" style="color:#9FB4D6">منذ</div><b><span class="num">${days}</span> يوم</b></div></div>
          ${myTurn ? `<div class="row mt"><button class="btn cyan" id="adv">${esc(ADVANCE_LABEL[app.stage])}</button><span class="small" style="color:#9FB4D6">هذه المرحلة بانتظارك</span></div>` : ''}
        </div>
        <div class="grid g3">
          <div class="card"><h3>منظومتي</h3><dl class="kv"><dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd><dt>المورد</dt><dd>${esc(org(app.supplier_id)?.name)}</dd>
            <dt>السعر</dt><dd>${iqd(app.price)}</dd><dt>المصرف</dt><dd>${esc(org(app.bank_id)?.name || '—')}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])}</dd>
            <dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً</dd></dl></div>
          <div class="card"><h3>المراحل الأربع عشرة</h3>${stageList(app, stages)}</div>
          <div class="card"><h3>كل ما حدث على طلبي</h3>${eventsList(events)}</div>
        </div>`;
      const adv = body.querySelector('#adv');
      if (adv) adv.onclick = async () => {
        adv.disabled = true;
        try { await rpc(sb, 'advance_application', { p_app: app.id, p_action: 'advance', p_note: null }); toast('تم — انتقل طلبك للمرحلة التالية', 'ok'); ctx.refresh(); }
        catch (e) { toast(cleanErr(e), 'bad'); adv.disabled = false; }
      };
    }
    if (k === 'catalog') {
      body.innerHTML = `<div class="notice">اختر القدرة أولاً، ثم قارن عروض الموردين لها. السعر يحدد الضمان المطلوب. (التقديم الكامل من الكتالوج يُفعَّل في المرحلة التالية من البناء.)</div>
        ${tiers.map(t => {
          const os = offers.filter(o => o.tier_id === t.id);
          return `<div class="card mb"><h3><span class="num">${num(t.kw)}</span> kW <span class="muted small" style="font-weight:600">— إنتاج يومي ~<span class="num">${num(t.daily_kwh)}</span> kWh · ${esc(t.loads)}</span><span class="sp"></span><span class="small muted">سقف السعر ${iqd(t.price_cap)}</span></h3>
            <div class="grid g3">${os.map((o, i) => `<div class="card offer" style="box-shadow:none;background:var(--surface-2)"><div class="row"><b>${esc(org(o.supplier_id)?.name)}</b><span class="sp"></span>${i === 0 ? '<span class="badge ok">الأقل سعراً</span>' : ''}</div>
              <div class="price">${iqd(o.price)}</div><div class="small muted">بطاريات <span class="num">${num(o.battery_kwh)}</span> kWh · ${esc(o.warranty.split('،')[0])}</div>
              <div class="small">الضمان المطلوب: <b>${o.price <= 10e6 ? 'راتب موظف واحد' : o.price <= 20e6 ? 'رواتب عدة موظفين' : 'رهن عقار'}</b></div></div>`).join('')}</div></div>`;
        }).join('')}`;
    }
  }
  show(ctx.czTab);
}
