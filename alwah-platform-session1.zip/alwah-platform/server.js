// خادم «ألواح» — بلا حزم خارجية. يخدم الملفات الثابتة ويوجّه روابط البوابات.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://chjeqtjyywomtcenizxp.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_yewCPqcDPAFW8RPqeJgrow_QTx57Ixy';

// كل بوابة لها رابط دخول مستقل
const PORTALS = ['citizen', 'bank', 'registry', 'cbi', 'supplier', 'integrity'];

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json',
  '.ico': 'image/x-icon', '.mp4': 'video/mp4', '.woff2': 'font/woff2'
};

function send(res, code, body, type, extra = {}) {
  res.writeHead(code, {
    'Content-Type': type,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'X-Frame-Options': 'SAMEORIGIN',
    ...extra
  });
  res.end(body);
}

function serveFile(res, file) {
  fs.readFile(file, (err, data) => {
    if (err) return serveFile404(res);
    const ext = path.extname(file).toLowerCase();
    const cache = ext === '.html' ? 'no-cache' : 'public, max-age=300';
    send(res, 200, data, TYPES[ext] || 'application/octet-stream', { 'Cache-Control': cache });
  });
}

function serveFile404(res) {
  fs.readFile(path.join(PUB, '404.html'), (e, d) => send(res, 404, d || 'Not found', 'text/html; charset=utf-8'));
}

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  let p = decodeURIComponent(url.pathname);

  if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
  if (p === '/config.js') {
    const js = `window.ALWAH_CONFIG=${JSON.stringify({ url: SUPABASE_URL, key: SUPABASE_ANON_KEY })};`;
    return send(res, 200, js, TYPES['.js'], { 'Cache-Control': 'no-cache' });
  }

  const first = p.split('/')[1];
  if (p === '/' || p === '') return serveFile(res, path.join(PUB, 'index.html'));
  if (PORTALS.includes(first) && !path.extname(p)) return serveFile(res, path.join(PUB, 'portal.html'));
  if (first === 'demo' && !path.extname(p)) return serveFile(res, path.join(PUB, 'demo.html'));

  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) return serveFile404(res);
  serveFile(res, file);
}).listen(PORT, () => console.log(`Alwah running on :${PORT}`));
