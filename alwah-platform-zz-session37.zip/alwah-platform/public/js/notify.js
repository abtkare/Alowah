// الجلسة 17: الإشعارات داخل المنصة — جرس في الشريط العلوي مع تحديث لحظي
// الجلسة 37: صوت تنبيه على الحاسوب والهاتف، واهتزاز، وتنبيه نظام التشغيل حين تكون النافذة في الخلفية،
//            وعدد غير المقروء في عنوان التبويب، ومفتاحا «الصوت» و«تنبيهات الجهاز» داخل القائمة.
import { esc, ago, el, toast, openApp } from './core.js';
import { chime, buzz, soundOn, setSound, unlockAudio } from './sound.js';

const ICON = { sla_late: '⏱', employer_check: '🏪', finance_circular: '💰', initiative: '📣', initiative_reply: '✉', letter: '🔒', exec: '⏱',
  eng_order: '🔍', eng_task: '🧰', eng_review: '📋', eng_result: '🏗' };
const NOTIF_PREF = 'alwah-sysnotify';
const sysOn = () => { try { return 'Notification' in window && Notification.permission === 'granted' && localStorage.getItem(NOTIF_PREF) !== 'off'; } catch { return false; } };
const baseTitle = document.title.replace(/^\(\d+\+?\)\s*/, '');

export function mountBell(ctx, host) {
  const { sb } = ctx;
  const btn = el(`<button type="button" class="btn btn-dark sm bell" title="الإشعارات" aria-label="الإشعارات">🔔<i class="bell-n" hidden></i></button>`);
  host.before(btn);
  let data = { items: [], unread: 0 }, panel = null, seen = null;
  const n = btn.querySelector('.bell-n');
  const paintCount = () => {
    n.hidden = !data.unread; n.textContent = data.unread > 9 ? '9+' : data.unread;
    document.title = (data.unread ? `(${data.unread > 9 ? '9+' : data.unread}) ` : '') + baseTitle;
  };
  // تنبيه بإشعار جديد: صوت + اهتزاز + رسالة + تنبيه النظام إن كانت النافذة مخفية
  const announce = fresh => {
    if (!fresh.length) return;
    chime('notify'); buzz([80, 60, 80]);
    btn.classList.remove('ring'); void btn.offsetWidth; btn.classList.add('ring');
    fresh.slice(0, 2).forEach(x => toast(`${ICON[x.kind] || '🔔'} ${x.title}`, 'ok'));
    if (sysOn() && (document.hidden || !document.hasFocus())) {
      fresh.slice(0, 3).forEach(x => {
        try {
          const nt = new Notification(x.title, { body: x.body || '', icon: '/alwah-logo/alwah-icon-128.webp', badge: '/alwah-logo/favicon/favicon-32.png', tag: x.id, lang: 'ar', dir: 'rtl' });
          nt.onclick = () => { window.focus(); nt.close(); go(x); };
        } catch { /* بعض المتصفحات تمنع الإنشاء المباشر */ }
      });
    }
  };
  const load = async () => {
    const r = await sb.rpc('my_notifications');
    if (r.error) return;
    const prev = seen; data = r.data || data; paintCount();
    const ids = new Set(data.items.map(x => x.id));
    if (prev) announce(data.items.filter(x => !prev.has(x.id) && !x.read));
    seen = ids;
    if (panel) draw();
  };
  const go = async x => {
    close();
    if (x.kind === 'initiative' && ctx.portal === 'bank') { ctx.bankTab = 'initiatives'; location.hash = ''; ctx.refresh(); }
    else if (x.kind === 'initiative_reply' && ctx.portal === 'cbi') { ctx.cbiTab = 'initiatives'; location.hash = ''; ctx.refresh(); }
    else if (x.kind === 'letter') { if (ctx.portal === 'cbi') ctx.cbiTab = 'letters'; else ctx.nzTab = 'letters'; location.hash = ''; ctx.refresh(); }
    else if (['eng_order', 'eng_task', 'eng_review'].includes(x.kind) && ctx.portal === 'auditor' && x.ref) { ctx.engOpen = x.ref; location.hash = ''; ctx.refresh(); }
    else if (x.kind === 'eng_result' && x.ref) {
      const { data: app } = await sb.from('applications').select('*').eq('id', x.ref).maybeSingle();
      if (app) openApp(ctx, app);
    }
  };
  const toggles = () => {
    const can = 'Notification' in window;
    const perm = can ? Notification.permission : 'unsupported';
    return `<div class="bell-set">
      <button type="button" class="bell-tg ${soundOn() ? 'on' : ''}" data-snd aria-pressed="${soundOn()}"><span>${soundOn() ? '🔊' : '🔇'}</span><b>الصوت</b><i></i></button>
      ${can ? `<button type="button" class="bell-tg ${sysOn() ? 'on' : ''}" data-sys aria-pressed="${sysOn()}" ${perm === 'denied' ? 'title="التنبيهات مرفوضة في إعدادات المتصفح لهذا الموقع"' : ''}><span>💻</span><b>تنبيهات الجهاز</b><i></i></button>` : ''}
      ${perm === 'denied' ? '<small class="bell-hint">التنبيهات ممنوعة في المتصفح — افتح إعدادات الموقع (رمز القفل بجانب الرابط) واسمح بالإشعارات.</small>'
        : !can && /iPhone|iPad/i.test(navigator.userAgent) ? '<small class="bell-hint">على آيفون: أضف المنصة إلى الشاشة الرئيسية (مشاركة ← إضافة إلى الشاشة الرئيسية) لتصلك تنبيهات الجهاز. الصوت يعمل والصفحة مفتوحة.</small>' : ''}
    </div>`;
  };
  const draw = () => {
    panel.innerHTML = `<div class="row" style="padding:10px 12px;border-bottom:1px solid var(--line)"><b>الإشعارات</b><span class="sp"></span>${data.unread ? '<button type="button" class="linkbtn" data-all>تعليم الكل كمقروء</button>' : ''}</div>
      ${toggles()}
      <div class="bell-list">${data.items.map(x => `<button type="button" class="bell-it ${x.read ? '' : 'new'}" data-id="${x.id}"><span class="ic">${ICON[x.kind] || '🔔'}</span><span><b>${esc(x.title)}</b>${x.body ? `<small>${esc(x.body)}</small>` : ''}<small class="muted">${ago(x.at)}</small></span></button>`).join('') || '<div class="empty small">لا إشعارات بعد</div>'}</div>`;
    const all = panel.querySelector('[data-all]');
    if (all) all.onclick = async () => { await sb.rpc('notifications_read', { p_ids: null }); load(); };
    panel.querySelector('[data-snd]').onclick = () => { unlockAudio(); setSound(!soundOn()); if (soundOn()) chime('notify'); draw(); };
    const sy = panel.querySelector('[data-sys]');
    if (sy) sy.onclick = async () => {
      if (Notification.permission === 'default') {
        const p = await Notification.requestPermission();
        try { localStorage.setItem(NOTIF_PREF, p === 'granted' ? 'on' : 'off'); } catch { /* لا شيء */ }
        if (p === 'granted') { try { new Notification('ألواح', { body: 'ستصلك تنبيهات المنصة على هذا الجهاز', icon: '/alwah-logo/alwah-icon-128.webp', lang: 'ar', dir: 'rtl' }); } catch { /* لا شيء */ } }
      } else if (Notification.permission === 'granted') {
        try { localStorage.setItem(NOTIF_PREF, sysOn() ? 'off' : 'on'); } catch { /* لا شيء */ }
      }
      draw();
    };
    panel.querySelectorAll('[data-id]').forEach(b => b.onclick = async () => {
      const x = data.items.find(i => i.id === b.dataset.id);
      if (!x.read) { await sb.rpc('notifications_read', { p_ids: [x.id] }); load(); }
      go(x);
    });
  };
  const close = () => { panel && panel.remove(); panel = null; document.removeEventListener('click', outside, true); };
  const outside = e => { if (panel && !panel.contains(e.target) && !btn.contains(e.target)) close(); };
  btn.onclick = () => {
    if (panel) return close();
    panel = el('<div class="bell-pop"></div>'); document.body.appendChild(panel);
    const r = btn.getBoundingClientRect(); panel.style.top = `${r.bottom + 8 + scrollY}px`;
    draw(); setTimeout(() => document.addEventListener('click', outside, true));
  };
  load();
  sb.channel('alwah-notify').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, () => load()).subscribe();
  // احتياط: إن انقطع الاتصال اللحظي (هاتف في الخلفية) نعيد الفحص عند العودة وكل دقيقة
  document.addEventListener('visibilitychange', () => { if (!document.hidden) load(); });
  setInterval(load, 60000);
  return { reload: load };
}
