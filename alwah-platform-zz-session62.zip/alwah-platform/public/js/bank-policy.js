// الجلسة 62: السياسة الائتمانية للمصرف — النموذج الداخلي يقرأ النص ويحوّله إلى شروط،
// الإدارة العليا تراجعها وتجرّبها (مقترض افتراضي + طلبات المصرف السابقة) ثم تعتمدها بإصدار وبصمة.
// بعد الاعتماد تُطبَّق على كل مقترض يختار المصرف: يطابق ← يكمل، يتعارض ← يُرفض ويُنصح بمصرف آخر.
import { esc, num, dt, badge, rpc, toast, cleanErr, modal, GOVS } from './core.js';
import { FIELDS, OPS, SET_VALUES, parsePolicy, ruleText, fmtVal } from './policy-model.js';

const SAMPLE = `1. يُشترط ألا يقل عمر المقترض عن 21 سنة ولا يزيد على 60 سنة عند تقديم الطلب.
2. ألا يتجاوز عمر المقترض 65 سنة عند انتهاء التمويل.
3. ألا يقل الدخل الشهري الصافي عن مليون دينار.
4. ألا يتجاوز القسط الشهري 50% من الدخل.
5. يُمنح التمويل للموظفين في القطاع الحكومي والقطاع الخاص فقط، ولا يُقبل أصحاب العمل الحر.
6. الحد الأعلى للتمويل 30 مليون دينار.`;
const ST = { active: ['نافذة', 'ok'], superseded: ['استُبدلت', 'muted'], disabled: ['موقوفة', 'warn'] };
const opsFor = f => FIELDS[f]?.kind === 'num' ? ['gte', 'lte'] : ['in', 'not_in'];

export async function bankPolicy(ctx, body) {
  const { sb, profile, org } = ctx;
  const md = profile.role === 'bank_md';
  body.innerHTML = '<div class="spin"></div>';
  const [list, stats] = await Promise.all([
    sb.from('bank_policies').select('*').eq('bank_id', org.id).order('version', { ascending: false }).then(r => r.data || []),
    rpc(sb, 'policy_stats', { p_bank: org.id, p_days: 30 }).catch(() => null),
  ]);
  const act = list.find(p => p.status === 'active');
  const st = ctx.polEd = ctx.polEd || null;   // مسودة التحرير: { title, text, rules, unparsed, warnings }
  const reload = () => bankPolicy(ctx, body);

  const reasons = Object.entries(stats?.reasons || {}).sort((a, b) => b[1] - a[1]);
  body.innerHTML = `
    <div class="notice"><span>🤖</span><span class="small"><b>فحص السياسة الائتمانية بالنموذج الداخلي:</b> تكتب الإدارة العليا سياسة المصرف بلغتها المعتادة، فيقرؤها نموذج داخل المنصة ويحوّلها إلى شروط
      (العمر، الدخل، نسبة القسط من الدخل، نوع العمل، المحافظة، المبلغ، المدة، نوع المشروع، الضمان). بعد الاعتماد يُسقطها النظام على بيانات كل مقترض يختار مصرفكم:
      إن طابقت <b>يكمل التقديم</b>، وإن تعارضت <b>يُرفض التقديم فوراً</b> مع السبب ويُنصح بمصرف تطابق سياسته. نص السياسة وبيانات المقترضين لا تخرج من المنصة.${md ? '' : ' <b>أنت تطّلع وتجرّب فقط</b> — الاعتماد للإدارة العليا.'}</span></div>
    ${act ? `<div class="card mb"><div class="row"><h3 style="margin:0">${esc(act.title || 'السياسة الائتمانية')}</h3><span class="sp"></span>${badge(ST.active)}</div>
      <div class="small muted">الإصدار <span class="num">${act.version}</span> · اعتمدها ${esc(act.created_by_name || '—')} · ${dt(act.created_at)} · البصمة <span class="num" dir="ltr">${esc((act.sha256 || '').slice(0, 12))}</span></div>
      <ol class="small" style="margin:10px 0 0;padding-inline-start:20px">${(act.rules || []).map(r => `<li style="margin-bottom:4px"><b>${esc(ruleText(r))}</b>${r.text ? `<div class="muted">«${esc(r.text)}»</div>` : ''}</li>`).join('')}</ol>
      ${md ? `<div class="row mt"><button type="button" class="btn cyan sm" data-edit>تعديل السياسة (إصدار جديد)</button><button type="button" class="btn ghost sm" data-off>إيقاف السياسة</button></div>` : ''}</div>`
      : `<div class="card mb"><h3 style="margin:0 0 4px">لا سياسة ائتمانية نافذة</h3><p class="small muted" style="margin:0">لا يُفحص المقترضون الآن على سياسة مصرفكم — كل طلب يصل كما هو.${md ? ' اكتب السياسة أدناه.' : ''}</p></div>`}
    <div class="grid g4 mb">${[['فُحص', stats?.total], ['طابق', stats?.pass], ['رُفض التقديم', stats?.fail], ['مقترضون', stats?.citizens]].map(([l, v]) => `<div class="card soft" style="margin:0"><div class="small muted">${l} — آخر 30 يوماً</div><b class="num" style="font-size:22px">${num(v || 0)}</b></div>`).join('')}</div>
    ${reasons.length ? `<div class="card mb"><h3>أكثر أسباب رفض التقديم</h3>${reasons.map(([k, v]) => `<div class="row small"><span>${esc(k)}</span><span class="sp"></span><b class="num">${num(v)}</b></div>`).join('')}</div>` : ''}
    <div data-editor></div>
    <div data-test></div>
    ${list.length ? `<div class="card"><h3>سجل الإصدارات</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الإصدار</th><th>الحالة</th><th>الشروط</th><th>اعتمدها</th><th>التاريخ</th></tr></thead><tbody>
      ${list.map(p => `<tr><td class="num">${p.version}</td><td>${badge(ST[p.status])}</td><td class="num">${(p.rules || []).length}</td><td class="small">${esc(p.created_by_name || '')}</td><td class="small">${dt(p.created_at)}${p.ended_at ? `<div class="muted">انتهت ${dt(p.ended_at)}${p.ended_by_name ? ' — ' + esc(p.ended_by_name) : ''}</div>` : ''}</td></tr>`).join('')}
      </tbody></table></div></div>` : ''}`;

  const edBox = body.querySelector('[data-editor]'), testBox = body.querySelector('[data-test]');
  body.querySelector('[data-edit]')?.addEventListener('click', () => {
    ctx.polEd = { title: act.title || '', text: act.policy_text, rules: JSON.parse(JSON.stringify(act.rules || [])), unparsed: act.unparsed || [], warnings: [] };
    reload();
  });
  body.querySelector('[data-off]')?.addEventListener('click', () => {
    const m = modal(`<h3>إيقاف السياسة الائتمانية</h3><p class="muted">بعد الإيقاف لا يُفحص المقترضون على سياسة مصرفكم حتى تعتمدوا إصداراً جديداً.</p>
      <div class="field"><label>السبب ★</label><input class="input" data-n></div><div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn warn" data-ok>أوقف</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-ok]').onclick = async e => { e.target.disabled = true;
      try { await rpc(sb, 'bank_policy_disable', { p_note: m.el.querySelector('[data-n]').value }); m.close(); toast('أُوقفت السياسة', 'ok'); reload(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; } };
  });

  // ── المحرّر (الإدارة العليا) ──
  const ed = st || (md && !act ? (ctx.polEd = { title: '', text: '', rules: null, unparsed: [], warnings: [] }) : null);
  if (ed && md) drawEditor();
  drawTest();

  function drawEditor() {
    edBox.innerHTML = `<div class="card mb"><h3>${act ? `الإصدار الجديد (<span class="num">${(list[0]?.version || 0) + 1}</span>)` : 'اكتب سياسة المصرف'}</h3>
      <div class="field"><label>عنوان السياسة</label><input class="input" data-title maxlength="120" value="${esc(ed.title)}" placeholder="مثال: سياسة الائتمان الشخصي 2026"></div>
      <div class="field"><label>نص السياسة كما هو معتمد لديكم — كل شرط في سطر</label><textarea class="input" rows="8" data-text placeholder="${esc(SAMPLE)}">${esc(ed.text)}</textarea></div>
      <div class="row"><button type="button" class="btn ghost sm" data-sample>املأ بمثال</button><span class="sp"></span><button type="button" class="btn cyan" data-parse>🤖 حلّل بالنموذج الداخلي</button></div>
      <div data-rules></div></div>`;
    const tx = edBox.querySelector('[data-text]'), ti = edBox.querySelector('[data-title]');
    tx.oninput = () => { ed.text = tx.value; }; ti.oninput = () => { ed.title = ti.value; };
    edBox.querySelector('[data-sample]').onclick = () => { ed.text = tx.value = SAMPLE; };
    edBox.querySelector('[data-parse]').onclick = () => {
      if (ed.text.trim().length < 20) return toast('اكتب نص السياسة أولاً', 'bad');
      const r = parsePolicy(ed.text);
      Object.assign(ed, { rules: r.rules, unparsed: r.unparsed, warnings: r.warnings });
      drawRules();
      toast(`فهم النموذج ${r.rules.length} شرطاً${r.unparsed.length ? ` — ${r.unparsed.length} جملة تحتاج مراجعتك` : ''}`, r.rules.length ? 'ok' : 'bad');
    };
    if (ed.rules) drawRules();
  }

  function drawRules() {
    const box = edBox.querySelector('[data-rules]');
    const rows = ed.rules.map((r, i) => {
      const f = FIELDS[r.field];
      const valHtml = f.kind === 'num'
        ? `<input class="input" style="max-width:170px" inputmode="decimal" dir="ltr" data-v="${i}" value="${esc(r.value)}"> <span class="small muted">${esc(f.unit)}</span>`
        : `<div class="chips">${SET_VALUES[r.field].map(([k, l]) => `<label class="chip ${(r.value || []).includes(k) ? 'on' : ''}"><input type="checkbox" hidden data-s="${i}" value="${esc(k)}" ${(r.value || []).includes(k) ? 'checked' : ''}>${esc(l)}</label>`).join('')}</div>`;
      return `<div class="card soft" style="margin:0 0 8px"><div class="row" style="flex-wrap:wrap;gap:6px">
          <select class="input" style="max-width:200px" data-f="${i}">${Object.entries(FIELDS).map(([k, d]) => `<option value="${k}" ${k === r.field ? 'selected' : ''}>${esc(d.label)}</option>`).join('')}</select>
          <select class="input" style="max-width:150px" data-o="${i}">${opsFor(r.field).map(o => `<option value="${o}" ${o === r.op ? 'selected' : ''}>${OPS[o]}</option>`).join('')}</select>
          <span class="sp"></span><button type="button" class="btn ghost sm" data-del="${i}" aria-label="حذف الشرط">✕</button></div>
        <div class="mt">${valHtml}</div>${r.text ? `<div class="small muted mt">من النص: «${esc(r.text)}»</div>` : '<div class="small muted mt">شرط أُضيف يدوياً</div>'}</div>`;
    }).join('');
    box.innerHTML = `<h3 class="mt">ما فهمه النموذج — <span class="num">${ed.rules.length}</span> شرطاً</h3>
      <p class="small muted" style="margin:0 0 8px">راجع كل شرط مقابل جملته، وصحّح أي قيمة. هذه الشروط هي التي ستُطبَّق حرفياً على المقترضين.</p>
      ${ed.warnings.map(w => `<div class="notice warn"><span>⚠</span><span class="small">${esc(w)}</span></div>`).join('')}
      ${rows || '<div class="empty">لم يستخرج النموذج أي شرط — أضف الشروط يدوياً.</div>'}
      <button type="button" class="btn ghost sm" data-add>＋ أضف شرطاً يدوياً</button>
      ${ed.unparsed.length ? `<div class="notice mt"><span>?</span><span class="small"><b>جمل لم يحوّلها النموذج إلى شرط آلي</b> (تبقى في نص السياسة للمراجعة البشرية في المصرف، ولا يُرفض بسببها أحد آلياً):<ul style="margin:4px 0 0;padding-inline-start:18px">${ed.unparsed.map(u => `<li>${esc(u)}</li>`).join('')}</ul></span></div>` : ''}
      <div class="row mt"><button type="button" class="btn ghost" data-cancel>إلغاء</button><span class="sp"></span><button type="button" class="btn ghost" data-try>جرّب أولاً ↓</button><button type="button" class="btn cyan" data-save>اعتمد السياسة ✓</button></div>`;
    box.querySelectorAll('[data-f]').forEach(s => s.onchange = () => { const r = ed.rules[s.dataset.f]; r.field = s.value; r.op = opsFor(s.value)[0]; r.value = FIELDS[s.value].kind === 'num' ? 0 : []; drawRules(); });
    box.querySelectorAll('[data-o]').forEach(s => s.onchange = () => { ed.rules[s.dataset.o].op = s.value; });
    box.querySelectorAll('[data-v]').forEach(s => s.oninput = () => { ed.rules[s.dataset.v].value = s.value.replace(/[^\d.]/g, ''); });
    box.querySelectorAll('[data-s]').forEach(c => c.onchange = () => {
      const r = ed.rules[c.dataset.s]; r.value = c.checked ? [...new Set([...(r.value || []), c.value])] : (r.value || []).filter(x => x !== c.value);
      c.closest('.chip').classList.toggle('on', c.checked);
    });
    box.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { ed.rules.splice(Number(b.dataset.del), 1); drawRules(); });
    box.querySelector('[data-add]').onclick = () => { ed.rules.push({ field: 'salary', op: 'gte', value: 0, text: '' }); drawRules(); };
    box.querySelector('[data-cancel]').onclick = () => { ctx.polEd = null; reload(); };
    box.querySelector('[data-try]').onclick = () => testBox.scrollIntoView({ behavior: 'smooth' });
    box.querySelector('[data-save]').onclick = async e => {
      e.target.disabled = true;
      try {
        const p = await rpc(sb, 'bank_policy_save', { p_text: ed.text, p_rules: ed.rules, p_unparsed: ed.unparsed, p_title: ed.title || null });
        ctx.polEd = null; toast(`اعتُمدت السياسة — الإصدار ${p.version}. تُطبَّق الآن على كل مقترض يختار مصرفكم`, 'ok'); reload();
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }

  // ── الاختبار: مقترض افتراضي، وطلبات المصرف السابقة ──
  function drawTest() {
    const rulesNow = () => (ed && md && ed.rules) ? ed.rules : (act?.rules || []);
    const which = (ed && md && ed.rules) ? 'الشروط التي تحررها الآن (قبل الاعتماد)' : act ? `السياسة النافذة (الإصدار ${act.version})` : null;
    if (!which) { testBox.innerHTML = ''; return; }
    const sel = (k, opts, v = '') => `<select class="input" data-t="${k}"><option value="">—</option>${opts.map(([a, b]) => `<option value="${esc(a)}" ${a === v ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select>`;
    testBox.innerHTML = `<div class="card mb"><h3>🧪 اختبار تطبيق السياسة</h3><p class="small muted" style="margin:0 0 8px">يُختبر الآن: <b>${esc(which)}</b>. المحرّك نفسه الذي يفحص المقترضين.</p>
      <h4 style="margin:8px 0">١. مقترض افتراضي</h4>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>العمر</label><input class="input" data-t="age" inputmode="numeric" dir="ltr" value="45"></div>
        <div class="field"><label>الدخل الشهري (د.ع)</label><input class="input" data-t="salary" inputmode="numeric" dir="ltr" value="800000"></div>
        <div class="field"><label>نوع العمل</label>${sel('employment', SET_VALUES.employment, 'self')}</div>
        <div class="field"><label>المحافظة</label>${sel('governorate', GOVS.map(([g]) => [g, g]), 'البصرة')}</div>
        <div class="field"><label>مبلغ التمويل (د.ع)</label><input class="input" data-t="amount" inputmode="numeric" dir="ltr" value="8000000"></div>
        <div class="field"><label>مدة السداد (شهراً)</label><input class="input" data-t="term" inputmode="numeric" dir="ltr" value="60"></div>
        <div class="field"><label>نوع المشروع</label>${sel('sector', SET_VALUES.sector, 'residential')}</div>
        <div class="field"><label>الضمان</label>${sel('guarantee', SET_VALUES.guarantee)}</div>
      </div>
      <div class="row"><span class="sp"></span><button type="button" class="btn cyan sm" data-sim>افحص المقترض</button></div><div data-simr></div>
      <h4 style="margin:14px 0 6px">٢. طلبات المصرف السابقة</h4>
      <p class="small muted" style="margin:0 0 6px">كم طلباً من آخر 500 طلب وصلت مصرفكم كان سيُرفض تقديمه لو كانت هذه الشروط نافذة؟</p>
      <div class="row"><span class="sp"></span><button type="button" class="btn ghost sm" data-bt>شغّل الاختبار الرجعي</button></div><div data-btr></div></div>`;
    testBox.querySelector('[data-sim]').onclick = async e => {
      const c = {}; testBox.querySelectorAll('[data-t]').forEach(i => { const v = i.value.trim(); if (v) c[i.dataset.t] = FIELDS[i.dataset.t].kind === 'num' ? Number(v.replace(/[^\d.]/g, '')) : v; });
      e.target.disabled = true;
      try { testBox.querySelector('[data-simr]').innerHTML = resultHtml(await rpc(sb, 'policy_simulate', { p_rules: rulesNow(), p_ctx: c })); }
      catch (er) { toast(cleanErr(er), 'bad'); } finally { e.target.disabled = false; }
    };
    testBox.querySelector('[data-bt]').onclick = async e => {
      e.target.disabled = true;
      try {
        const r = await rpc(sb, 'policy_backtest', { p_rules: rulesNow() }), rs = Object.entries(r.reasons || {}).sort((a, b) => b[1] - a[1]);
        testBox.querySelector('[data-btr]').innerHTML = `<div class="card soft mt" style="margin-bottom:0"><div class="row"><span>فُحص <b class="num">${num(r.total)}</b> طلباً</span><span class="sp"></span>${badge([`يطابق ${num(r.pass)}`, 'ok'])} ${badge([`يُرفض ${num(r.fail)}`, r.fail ? 'bad' : 'muted'])}</div>
          ${rs.map(([k, v]) => `<div class="row small"><span>${esc(k)}</span><span class="sp"></span><b class="num">${num(v)}</b></div>`).join('')}
          ${(r.samples || []).length ? `<details class="mt"><summary class="small">أمثلة (<span class="num">${r.samples.length}</span>)</summary>${r.samples.map(s => `<div class="small" style="margin-top:6px"><b class="num">${esc(s.code)}</b> — ${esc(s.name)}<div class="muted">${(s.fails || []).map(esc).join('؛ ')}</div></div>`).join('')}</details>` : ''}</div>`;
      } catch (er) { toast(cleanErr(er), 'bad'); } finally { e.target.disabled = false; }
    };
  }
}

export function resultHtml(r) {
  const c = r.ctx || {};
  const derived = ['installment', 'dti', 'age_end'].filter(k => c[k] != null).map(k => `${FIELDS[k].label}: <b>${esc(fmtVal(k, c[k]))}</b>`).join(' · ');
  if (r.result === 'no_policy') return '<div class="notice mt"><span>i</span><span class="small">لا شروط للفحص.</span></div>';
  return `<div class="notice ${r.result === 'pass' ? 'ok' : 'warn'} mt"><span>${r.result === 'pass' ? '✓' : '✗'}</span><span class="small">
    <b>${r.result === 'pass' ? `يطابق السياسة — يكمل التقديم (${r.passed} من ${r.rules} شرطاً)` : 'يتعارض مع السياسة — يُرفض التقديم ويُنصح بمصرف آخر'}</b>
    ${(r.fails || []).length ? `<ul style="margin:4px 0 0;padding-inline-start:18px">${r.fails.map(f => `<li>${esc(f.msg)}</li>`).join('')}</ul>` : ''}
    ${(r.unknown || []).length ? `<div class="muted">لم يُفحص لنقص البيانات: ${r.unknown.map(u => esc(u.label)).join('، ')}</div>` : ''}
    ${derived ? `<div class="muted">محسوب: ${derived}</div>` : ''}</span></div>`;
}
