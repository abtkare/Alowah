// الجلسة 52: بوابة اتحاد الغرف التجارية العراقية
// قسم العضوية والتسجيل: يدقق ويحيل للكشف أو يعيد · المفتش: يكشف على المحل بالـGPS والصور ويقدّر الموجودات وأسعار المعدات والبضائع
// لجنة التصنيف: توصي · رئيس الاتحاد: يقرر ويصدر الكتاب المختوم، ويسحب الكتاب ويعلّق العضوية · الحسابات: الأجور
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, mapsLink, iqd, num, resultScreen, COM_CATS, GUARANTEE } from '../core.js';
import { UF_ST, UF_KIND, UM_ST, SITE_ST, REC, ufBadge, umBadge, catLabel, stepsBar, letterHtml, openLetter, memberCard, SVC_KINDS, RENEW_MODE, FIELD_LABEL, fieldVal } from '../chamber-ui.js';

let D;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg,.un-act');

const SG = r => r === 'chamber_pres' || r === 'chamber_head';   // الجلسة 56: رئيس الغرفة يقرّر في محافظته كرئيس الاتحاد
const ROLE_IC = { chamber_pres: '🏛', chamber_head: '🏢', chamber_reg: '🗂', chamber_eng: '📍', chamber_committee: '⚖️', chamber_fin: '💳' };
const money = v => String(v ?? '').replace(/[^0-9]/g, '');
const fmt = v => v ? Number(v).toLocaleString('en-US') : '';
const ACTIVE = ['new', 'inspection', 'committee', 'signing'];

// الجلسة 53: موظف التسجيل في غرفة محافظة يرى وارد محافظاته، وموظف المقر العام يرى وارد المحافظات التي لا فريق في غرفتها
const myGov = (me, f) => me.govs ? me.govs.includes(f.member?.governorate) : !(D.office_govs || []).includes(f.member?.governorate);
function mine(me) {
  const r = me.role;
  return D.files.filter(f =>
    (f.status === 'new' && SG(r)) || (f.status === 'new' && r === 'chamber_reg' && myGov(me, f)) ||
    (f.status === 'inspection' && f.engineer_id === me.id) ||
    (f.status === 'committee' && (r === 'chamber_committee' || r === 'chamber_head')) ||
    (f.status === 'signing' && SG(r)));
}
const hint = r => ({ chamber_reg: 'تصلك المعاملات الواردة: طلبات الانتساب بمستمسكاتها، وتجديد الهويات المتأخرة، وتحديث البيانات، وتأييد القروض التجارية.', chamber_eng: 'تصلك الكشوف الموقعية المسندة إليك: انتماء، تأييد قرض، نصب معدات، بدء إنتاج، متابعة.',
  chamber_committee: 'تصلك المعاملات بعد الكشف لتوصية لجنة التصنيف.', chamber_pres: 'يصلك ما ينتظر قرارك، وكل الوارد من كل المحافظات.', chamber_head: 'رئيس الغرفة: يصلك وارد محافظتك وما ينتظر قرارك، وتدير فريق غرفتك من «فريقي».', chamber_fin: 'تابع الأجور المستحصلة والمستحقة من تبويب «الأجور».' }[r] || '');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'chamber_inbox');
  if (ctx.ccOpen) return fileDetail(ctx, ctx.ccOpen);
  if (ctx.unMem) return memberDetail(ctx, ctx.unMem);
  const me = D.me, my = mine(me);
  const open = D.files.filter(f => ACTIVE.includes(f.status));
  const late = open.filter(f => f.late).length;
  const valid = D.members.filter(m => m.status === 'approved').length;
  const tabs = [['todo', `مهامي (${my.length})`], ['files', 'المعاملات'], ['members', 'سجل الأعضاء'],
    ...(['chamber_pres', 'chamber_head', 'chamber_fin'].includes(me.role) ? [['fees', 'الأجور']] : []), ...(D.team ? [['team', 'الفريق']] : []), ['rules', 'الضوابط']];
  const tab = tabs.some(t => t[0] === ctx.ccTab) ? ctx.ccTab : (me.role === 'chamber_fin' ? 'fees' : 'todo');
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(D.org?.name || 'اتحاد الغرف التجارية العراقية')}</h1>
      <p>${ROLE_IC[me.role] || ''} ${esc(me.role_title)}${me.office ? ` — ${esc(me.office)}` : me.governorate && me.role === 'chamber_eng' ? ` — ${esc(me.governorate)}` : ''}</p></div></div>
    ${D.team && !D.team.ready?.ok ? `<a class="card mb tr-ready bad" href="#team" style="display:block"><b>⚠️ أكمل فريق الاتحاد</b> <span class="small muted">— ${esc((D.team.ready.missing || []).map(x => x.t + (x.branch_name ? ` (${x.branch_name})` : '')).join('، '))}</span></a>` : ''}
    <div class="grid g4 mb">
      ${kpi('بانتظارك', `<span class="num">${my.length}</span>`, hint(me.role).split('،')[0], true)}
      ${kpi('قيد العمل', `<span class="num">${open.length}</span>`, late ? `<span style="color:var(--bad)">${late} متأخرة عن المهلة</span>` : 'ضمن المهلة')}
      ${kpi('أعضاء بهوية نافذة', `<span class="num">${valid}</span>`, `${D.members.filter(m => m.expiring).length} تنتهي خلال شهر · ${D.members.filter(m => m.status === 'expired').length} منتهية`)}
      ${kpi('تأييدات القروض', `<span class="num">${D.files.filter(f => f.kind === 'endorse' && ['issued', 'delivered'].includes(f.status)).length}</span>`, `${D.files.filter(f => f.kind === 'endorse' && f.status === 'rejected').length} مرفوضة`)}
    </div>
    <div class="eng-tabs seg ins-tabs" role="tablist">${tabs.map(([k, t]) => `<label class="${tab === k ? 'on' : ''}"><input type="radio" name="ut" value="${k}" ${tab === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('input[name=ut]').forEach(r => r.onchange = () => { ctx.ccTab = r.value; render(ctx); });
  const body = root.querySelector('[data-body]');
  if (tab === 'todo') {
    body.innerHTML = my.length ? `<div class="eng-cards">${my.map(fCard).join('')}</div>` : `<div class="card empty">لا شيء بانتظارك الآن ✓<div class="small muted" style="margin-top:6px">${hint(me.role)}</div></div>`;
  } else if (tab === 'files') {
    const F = ctx.unF || { st: '', k: '' };
    const list = D.files.filter(f => (!F.st || f.status === F.st) && (!F.k || f.kind === F.k));
    body.innerHTML = `<div class="og-filter">${[['', 'الكل']].concat(Object.entries(UF_KIND).map(([k, v]) => [k, `${v[1]} ${v[0]}`])).map(([k, t]) => `<label class="chip ${F.k === k ? 'on' : ''}"><input type="radio" name="fk" value="${k}" ${F.k === k ? 'checked' : ''}>${esc(t)} <b class="num">${D.files.filter(f => !k || f.kind === k).length}</b></label>`).join('')}</div>
      <div class="og-filter"><label class="chip ${!F.st ? 'on' : ''}"><input type="radio" name="fs" value="" ${!F.st ? 'checked' : ''}>كل الحالات</label>${Object.entries(UF_ST).filter(([k]) => D.files.some(f => f.status === k)).map(([k, v]) => `<label class="chip ${F.st === k ? 'on' : ''}"><input type="radio" name="fs" value="${k}" ${F.st === k ? 'checked' : ''}>${esc(v[0])} <b class="num">${D.files.filter(f => f.status === k).length}</b></label>`).join('')}</div>
      ${list.length ? `<div class="eng-cards">${list.map(fCard).join('')}</div>` : '<div class="card empty">لا معاملات.</div>'}`;
    body.querySelectorAll('input[name=fk]').forEach(r => r.onchange = () => { ctx.unF = { ...F, k: r.value }; render(ctx); });
    body.querySelectorAll('input[name=fs]').forEach(r => r.onchange = () => { ctx.unF = { ...F, st: r.value }; render(ctx); });
  } else if (tab === 'members') {
    const q = (ctx.unQ || '').trim(), mf = ctx.unMF || '';
    const MF = [['', 'الكل', () => true], ['approved', 'نافذة', m => m.status === 'approved'], ['expiring', 'تنتهي خلال شهر', m => m.expiring], ['expired', 'منتهية', m => m.status === 'expired'],
      ['pending', 'قيد الدراسة', m => m.status === 'pending'], ['suspended', 'معلّقة', m => m.status === 'suspended'], ['cancelled', 'ملغاة', m => m.status === 'cancelled']];
    const fn = (MF.find(x => x[0] === mf) || MF[0])[2];
    const list = D.members.filter(m => fn(m) && (!q || [m.code, m.factory, m.owner, m.governorate, m.phone].some(x => String(x || '').includes(q))));
    body.innerHTML = `<div class="og-filter">${MF.map(([k, t, f]) => `<label class="chip ${mf === k ? 'on' : ''}"><input type="radio" name="mf" value="${k}" ${mf === k ? 'checked' : ''}>${esc(t)} <b class="num">${D.members.filter(f).length}</b></label>`).join('')}</div>
      <div class="card mb"><input class="input" data-q placeholder="ابحث برقم الهوية أو اسم المحل أو صاحبه أو المحافظة أو الهاتف" value="${esc(q)}"></div>
      <div class="card"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الهوية</th><th>المحل</th><th>النشاط</th><th>المحافظة</th><th>الحالة</th><th>نافذة حتى</th></tr></thead><tbody>
      ${list.map(m => `<tr class="click" data-m="${m.id}"><td><b class="num">${esc(m.code || '—')}</b></td><td>${esc(m.factory)}<div class="small muted">${esc(m.owner)}</div></td><td class="small">${esc(m.category_label)}</td>
        <td>${esc(m.governorate)}</td><td>${umBadge(m.status)}${m.expiring ? ' <span class="tag warn-t">تنتهي قريباً</span>' : ''}</td><td class="num small">${esc(m.valid_until || '—')}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">لا نتائج</td></tr>'}</tbody></table></div></div>`;
    const qi = body.querySelector('[data-q]');
    qi.onchange = () => { ctx.unQ = qi.value; render(ctx); };
    body.querySelectorAll('input[name=mf]').forEach(r => r.onchange = () => { ctx.unMF = r.value; render(ctx); });
    body.querySelectorAll('[data-m]').forEach(tr => tr.onclick = () => { ctx.unMem = tr.dataset.m; window.scrollTo(0, 0); render(ctx); });
  } else if (tab === 'fees') {
    const fe = D.fees || {};
    const BK = fe.by_kind || {};
    body.innerHTML = `<div class="grid g3 mb">${kpi('المستحصل', iqd(fe.paid), 'دُفع إلكترونياً عبر المنصة أو بوصل')}${kpi('هذا الشهر', iqd(fe.month), 'كل الخدمات')}${kpi('المستحق', iqd(fe.due), 'يُدفع مع عمولة المصرف قبل إرسال القرض')}</div>
      ${Object.keys(BK).length ? `<div class="card mb"><h3>المستحصل حسب الخدمة</h3><dl class="kv sm">${Object.entries(BK).map(([k, v]) => `<dt>${UF_KIND[k]?.[1] || ''} ${esc(UF_KIND[k]?.[0] || k)}</dt><dd>${iqd(v)}</dd>`).join('')}</dl></div>` : ''}
      <div class="card"><h3>الأجور حسب المعاملة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المعاملة</th><th>النوع</th><th>المحل</th><th>المبلغ</th><th>الدفع</th></tr></thead><tbody>
      ${(fe.rows || []).map(x => `<tr><td class="num">${esc(x.code)}</td><td class="small">${esc(x.kind)}</td><td>${esc(x.factory)}</td><td>${iqd(x.fee)}</td><td class="small">${x.paid_at ? `✓ ${dt(x.paid_at)}<div class="num muted">${esc(x.ref || '')}</div>` : badge(['مستحق', 'warn'])}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">لا أجور بعد</td></tr>'}</tbody></table></div></div>`;
  } else if (tab === 'team') {
    teamTab(body);
  } else {
    const s = D.settings || {};
    body.innerHTML = `<div class="card"><h3>ضوابط العمل في الاتحاد</h3><dl class="kv">
      <dt>بدل الانتماء والهوية</dt><dd>${iqd(s.member_fee)} سنوياً</dd>
      <dt>أجور الكشف للقرض</dt><dd><span class="num">${s.insp_pct}%</span> من مبلغ القرض (من ${iqd(s.insp_min)} إلى ${iqd(s.insp_max)})</dd>
      <dt>مهلة إنجاز المعاملة</dt><dd><span class="num">${s.sla}</span> أيام</dd><dt>نفاذ كتاب التأييد</dt><dd><span class="num">${s.letter_days}</span> يوماً</dd>
      <dt>تأييد مزاولة النشاط</dt><dd>خلال <span class="num">${s.prod_days}</span> يوماً من صرف القرض</dd>
      <dt>تجديد الهوية</dt><dd>يُفتح قبل الانتهاء بـ<span class="num">${s.early}</span> يوماً · <b>فوري</b> حتى <span class="num">${s.grace}</span> يوماً بعد الانتهاء · <b>بمراجعة قسم العضوية</b> حتى <span class="num">${s.insp_days}</span> يوماً · بعدها <b>بكشف موقعي</b> وقرار رئيس الاتحاد</dd>
      <dt>بعد الانتهاء</dt><dd>غرامة ${iqd(s.late_month)} عن كل شهر (حتى ${iqd(s.late_max)})، وبدل كل سنة متأخرة</dd>
      <dt>كتاب تأييد العضوية</dt><dd>فوري آلي لحامل الهوية النافذة · ${iqd(s.cert_fee)} · نافذ <span class="num">${s.cert_days}</span> يوماً</dd>
      <dt>بدل ضائع أو تالف</dt><dd>فوري برمز تحقق جديد · ${iqd(s.replace_fee)}</dd>
      <dt>التذكير</dt><dd>إشعار للمنتسب قبل الانتهاء بـ<span class="num">${s.remind}</span> يوماً، وعند الانتهاء، وقبل نهاية مهلة التجديد الفوري</dd>
      <dt>الأنشطة التجارية</dt><dd>${Object.values(COM_CATS).map(x => `<span class="tag">${esc(x)}</span>`).join(' ')}</dd>
      <dt>المرجع</dt><dd>قانون غرف التجارة النافذ والنظام الداخلي للاتحاد (تُثبَّت أرقامها حين يزوّدنا بها الاتحاد) — الانتساب بقرار رئيس الغرفة أو رئيس الاتحاد، ويُعترض على الرفض خلال 30 يوماً.</dd></dl>
      <p class="small muted">تُعدَّل القيم من مشغّل النظام ← الإعدادات.</p></div>`;
  }
  body.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { ctx.ccOpen = b.dataset.f; window.scrollTo(0, 0); render(ctx); });
}

function fCard(f) {
  const m = f.member || {}, k = UF_KIND[f.kind] || ['', ''];
  return `<button type="button" class="eng-card un-c cc-c ${f.late ? 'late' : ''}" data-f="${f.id}">
    <div class="row"><b class="num">${esc(f.code)}</b><span class="tag">${k[1]} ${esc(k[0])}</span>${f.appeal ? '<span class="tag warn-t">اعتراض</span>' : ''}${f.new_member ? '<span class="tag">عضو جديد</span>' : ''}<span class="sp"></span>${ufBadge(f.status)}</div>
    <div class="eng-proj">🏪 ${esc(m.factory || '')}</div>
    <div class="small muted">${esc(m.owner || '')} · ${esc(m.category_label || '')} · 📍 ${esc(m.governorate || '')}</div>
    <div class="row small"><span>${f.app ? `قرض <span class="num">${esc(f.app.code)}</span> · ${esc(f.app.bank || '')}` : f.mode ? esc(RENEW_MODE[f.mode]?.[0] || '') : SVC_KINDS.includes(f.kind) ? 'خدمة منتسب' : 'دون قرض'}</span><span class="sp"></span>${f.amount ? iqd(f.amount) : ''}</div>
    <div class="row small muted"><span>${f.status === 'inspection' && f.engineer ? `📍 ${esc(f.engineer)}` : ''}</span><span class="sp"></span>
      ${ACTIVE.includes(f.status) ? `<span class="${f.late ? 'bad-t' : ''}">${f.late ? '⚠ تجاوز المهلة' : `المهلة ${dt(f.due_at)}`}</span>` : `<span>${dt(f.updated_at)}</span>`}</div></button>`;
}

const back = (ctx, root) => { root.querySelector('[data-back]').onclick = () => { ctx.ccOpen = null; ctx.unMem = null; render(ctx); }; };
const logBlock = L => (L || []).length ? `<details class="card mb" open><summary><b>سجل المعاملة</b> <span class="small muted">(${L.length})</span></summary>${L.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')}${l.title ? ` · ${esc(l.title)}` : ''} · ${dt(l.at)}</div></div>`).join('')}</details>` : '';
const confirmBox = (word, key) => `<div class="field"><label>للتأكيد اكتب: <b>${word}</b></label><input class="input" data-${key}><button type="button" class="btn ghost sm" style="margin-top:6px" data-fill-${key}>✍ ${word}</button></div>`;
const wireFill = (root, word, key) => { const b = root.querySelector(`[data-fill-${key}]`); if (b) b.onclick = () => { root.querySelector(`[data-${key}]`).value = word; }; };

async function viewDoc(ctx, fn, args) {
  try {
    const d = await rpc(ctx.sb, fn, args);
    modal(`<h3>${esc(d.label || '')}</h3>${String(d.mime || '').startsWith('image/') ? `<img src="${d.data}" alt="" style="width:100%;border-radius:10px">` : `<iframe src="${d.data}" style="width:100%;height:70vh;border:0"></iframe>`}
      <p class="small muted num" dir="ltr" style="word-break:break-all">SHA-256: ${esc(d.sha256 || '')}</p>`, { wide: true });
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

// ───────── ملف المعاملة ─────────
async function fileDetail(ctx, id) {
  const { sb, root } = ctx;
  let F;
  try { F = await rpc(sb, 'chamber_file', { p_id: id }); } catch (e) { ctx.ccOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const m = F.member_full || {}, L = F.loan, ins = F.inspection, c = F.can, k = UF_KIND[F.kind] || ['', ''];
  const photos = (F.docs || []).filter(d => d.kind === 'visit_photo'), mdocs = (F.docs || []).filter(d => d.kind !== 'visit_photo');
  root.innerHTML = `
    <button type="button" class="linkbtn eng-back" data-back>→ كل المعاملات</button>
    <div class="card mb eng-head">
      <div class="row"><h2 class="num" style="margin:0">${esc(F.code)}</h2><span class="tag">${k[1]} ${esc(k[0])}</span>${F.appeal ? '<span class="tag warn-t">اعتراض</span>' : ''}<span class="sp"></span>${ufBadge(F.status)}</div>
      ${stepsBar(F)}
      <div class="eng-proj big">🏪 ${esc(m.factory_name || '')}</div>
      <dl class="kv sm">
        <dt>صاحب المحل</dt><dd>${esc(m.owner_name || '')}${m.phone ? ` · <a href="tel:${esc(m.phone)}" class="num">📞 ${esc(m.phone)}</a>` : ''}</dd>
        <dt>هوية الغرفة التجارية</dt><dd>${m.code ? `<b class="num">${esc(m.code)}</b> ` : ''}${umBadge(m.status)}${m.valid_until ? ` · حتى <span class="num">${esc(m.valid_until)}</span>` : ''}${F.new_member ? ' <span class="tag">يُدرس انتماؤه مع القرض</span>' : ''}</dd>
        <dt>النشاط</dt><dd>${esc(m.category_label || '')}</dd>
        <dt>العنوان</dt><dd>${esc([m.governorate, m.city, m.address].filter(Boolean).join(' — '))}${m.site_geo ? ` · <a href="${mapsLink(m.site_geo)}" target="_blank" rel="noopener">📍 الخريطة — للوصول</a>` : ''}</dd>
        <dt>السجل التجاري</dt><dd class="num">${esc(m.trade_name_no || '—')}</dd>
        <dt>إجازة النشاط</dt><dd>${m.dev_license_no ? `<span class="num">${esc(m.dev_license_no)}</span>` : '—'}</dd>
        <dt>البضائع وحجم النشاط</dt><dd>${esc(m.products || '—')}${m.capacity ? ` · ${esc(m.capacity)}` : ''}${m.workers ? ` · <span class="num">${m.workers}</span> عاملاً` : ''}</dd>
        ${F.origin ? `<dt>مصدر المعاملة</dt><dd>${esc(F.origin)}</dd>` : ''}
        ${ACTIVE.includes(F.status) ? `<dt>المهلة</dt><dd class="${F.late ? 'bad-t' : ''}">${dt(F.due_at)}${F.late ? ' — متأخرة' : ''}</dd>` : ''}
        <dt>الأجور</dt><dd>${F.fee ? `${iqd(F.fee)} ${F.fee_paid_at ? badge(['مدفوعة', 'ok']) : badge(['تُدفع مع إرسال القرض', 'muted'])}` : '—'}</dd>
      </dl>
    </div>
    ${F.appeal_data ? `<div class="notice warn mb"><b>اعتراض التاجر على الرفض</b> — ${esc(F.appeal_data.note)} <span class="small muted">· ${dt(F.appeal_data.at)}</span>${F.appeal_data.prev?.reason ? `<div class="small">سبب الرفض السابق: ${esc(F.appeal_data.prev.reason)}</div>` : ''}</div>` : ''}
    ${F.return_note ? `<div class="notice warn mb"><b>أُعيدت للتاجر:</b> ${esc(F.return_note)}</div>` : ''}
    ${svcCard(F)}${checklistCard(F)}
    <div data-act></div>
    ${L ? `<div class="card mb"><h3>💳 القرض المطلوب</h3><dl class="kv sm">
      <dt>الطلب</dt><dd><span class="num">${esc(L.code)}</span> · المرحلة <span class="num">${L.stage}</span> ${esc(L.stage_name || '')}</dd>
      <dt>البرنامج</dt><dd>${esc(L.program || '')} — ${esc(L.bank || '')}</dd>
      <dt>المبلغ</dt><dd><b>${iqd(L.amount)}</b> · <span class="num">${L.term}</span> شهراً منها <span class="num">${L.grace || 0}</span> سماح · فائدة <span class="num">${L.rate}%</span></dd>
      <dt>الغرض</dt><dd>${esc(L.purpose || '')}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[L.guarantee] || '—')}</dd></dl>
      ${(F.app_docs || []).length ? `<h4 style="margin:10px 0 6px">مستندات الطلب</h4><div class="row" style="gap:8px;flex-wrap:wrap">${F.app_docs.map(d => `<button type="button" class="btn ghost sm" data-ad="${d.id}">📎 ${esc(d.label)}</button>`).join('')}</div>` : ''}</div>` : ''}
    ${mdocs.length && !F.checklist ? `<div class="card mb"><h3>مستندات التاجر</h3><div class="row" style="gap:8px;flex-wrap:wrap">${mdocs.map(d => `<button type="button" class="btn ghost sm" data-ud="${d.id}">📎 ${esc(d.label)}</button>`).join('')}</div></div>` : ''}
    ${ins ? `<div class="card mb"><h3>📍 الكشف الموقعي <span class="sp"></span>${badge(SITE_ST[ins.site_state] || ['—', 'muted'])} ${ins.result === 'ok' ? badge(['مطابق', 'ok']) : badge(['عليه ملاحظات', 'warn'])}</h3><dl class="kv sm">
      <dt>المفتش</dt><dd>${esc(ins.by || '')} <span class="num">${esc(ins.code || '')}</span> · ${dt(ins.at)}</dd>
      ${ins.gps ? `<dt>الزيارة</dt><dd>📍 <a href="${mapsLink(ins.gps)}" target="_blank" rel="noopener">على الخريطة</a> · ±<span class="num">${ins.gps.acc}</span> م</dd>` : ''}
      ${ins.assessed_value ? `<dt>القيمة المقدّرة للموجودات</dt><dd>${iqd(ins.assessed_value)}</dd>` : ''}
      ${ins.quotes_total ? `<dt>عروض أسعار المعدات والبضائع</dt><dd>${iqd(ins.quotes_total)}${ins.fair_value ? ` · العادلة ${iqd(ins.fair_value)}` : ''} · ${ins.price_ok ? badge(['معقولة', 'ok']) : badge(['مبالغ فيها أو عليها ملاحظة', 'warn'])}</dd>` : ''}
      ${ins.machines_match != null ? `<dt>المعدات والبضائع المنصوبة</dt><dd>${ins.machines_match ? badge(['مطابقة لما مُوّل', 'ok']) : badge(['غير مطابقة', 'bad'])}</dd>` : ''}
      ${ins.capacity ? `<dt>حجم النشاط</dt><dd>${esc(ins.capacity)}</dd>` : ''}${ins.workers ? `<dt>العاملون</dt><dd class="num">${ins.workers}</dd>` : ''}
      ${(ins.checks || []).length ? `<dt>الفحص</dt><dd>${ins.checks.map(x => `<span class="tag">✓ ${esc(x)}</span>`).join(' ')}</dd>` : ''}
      ${ins.note ? `<dt>الملاحظات</dt><dd>${esc(ins.note)}</dd>` : ''}</dl>
      ${photos.length ? `<div class="un-grid mt">${photos.map(p => `<button type="button" class="un-ph" data-ud="${p.id}"><span>📷 صورة الكشف · ${dt(p.at)}</span></button>`).join('')}</div>` : ''}</div>` : ''}
    ${F.committee ? `<div class="card mb"><h3>⚖️ توصية لجنة التصنيف <span class="sp"></span>${badge(REC[F.committee.rec] || ['—', 'muted'])}</h3><dl class="kv sm"><dt>اللجنة</dt><dd>${esc(F.committee.by || '')} · ${dt(F.committee.at)}</dd>
      ${F.committee.recommended_amount ? `<dt>المبلغ الموصى به</dt><dd>${iqd(F.committee.recommended_amount)}</dd>` : ''}${F.committee.note ? `<dt>الملاحظات</dt><dd>${esc(F.committee.note)}</dd>` : ''}</dl></div>` : ''}
    ${F.decision ? `<div class="card mb"><h3>🏛 ${SVC_KINDS.includes(F.kind) && F.status === 'done' ? 'القرار' : 'قرار رئيس الاتحاد'} <span class="sp"></span>${F.decision.result === 'rejected' ? badge([SVC_KINDS.includes(F.kind) ? 'الرفض' : 'عدم التأييد', 'bad']) : F.decision.result === 'not_ok' ? badge(['غير مطابق', 'bad']) : badge([SVC_KINDS.includes(F.kind) ? 'الموافقة' : 'التأييد', 'ok'])}</h3>
      <dl class="kv sm"><dt>صدر عن</dt><dd>${esc(F.decision.by || '')} · ${dt(F.decision.at)}</dd>${F.decision.reason ? `<dt>الأسباب</dt><dd>${esc(F.decision.reason)}</dd>` : ''}${F.decision.note ? `<dt>الملاحظات</dt><dd>${esc(F.decision.note)}</dd>` : ''}${F.decision.revoked ? `<dt>سحب الكتاب</dt><dd class="bad-t">${esc(F.decision.revoke_reason || '')}</dd>` : ''}</dl></div>` : ''}
    ${(F.letters || []).map(l => `<div class="mb">${letterHtml(l)}</div>`).join('')}
    ${logBlock(F.log)}`;
  back(ctx, root);
  root.querySelectorAll('[data-ad]').forEach(b => b.onclick = () => viewDoc(ctx, 'chamber_app_doc', { p_file: F.id, p_doc: b.dataset.ad }));
  root.querySelectorAll('[data-ud]').forEach(b => b.onclick = () => viewDoc(ctx, 'chamber_doc', { p_id: b.dataset.ud }));
  // صور الكشف مصغرة
  photos.forEach(p => rpc(sb, 'chamber_doc', { p_id: p.id }).then(d => { const b = root.querySelector(`.un-ph[data-ud="${p.id}"]`); if (b && String(d.mime).startsWith('image/')) b.insertAdjacentHTML('afterbegin', `<img src="${d.data}" alt="">`); }).catch(() => {}));
  const box = root.querySelector('[data-act]');
  const run = async (btn, p, okTitle, rows = []) => {
    btn.disabled = true;
    try {
      const r = await rpc(sb, 'chamber_act', { p_id: F.id, p });
      resultScreen({ ok: true, title: okTitle, ref: F.code, rows: [...rows, ...(r?.letter ? [['الكتاب', `<span class="num" dir="ltr">${esc(r.letter)}</span>`]] : []), ...(r?.member ? [['هوية الغرفة التجارية', `<b class="num">${esc(r.member)}</b>`]] : [])], msg: 'سُجّل الإجراء باسمك ورمزك الوظيفي في سجل المعاملة.' });
      ctx.ccOpen = (p.action === 'issue' || p.action === 'visit' || p.action === 'recommend') ? F.id : null; render(ctx);
    } catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
  };
  const note = () => box.querySelector('[data-note]')?.value.trim() || '';

  if (c.triage && SVC_KINDS.includes(F.kind)) {
    const A = { renewal: 'اعتماد التجديد ✓', update: F.meta?.needs_sg ? 'دُقّق — رفع لرئيس الاتحاد ←' : 'اعتماد التحديث ✓', cancel: 'دُقّق — رفع لرئيس الاتحاد ←' }[F.kind];
    const canInsp = F.kind !== 'cancel';
    box.innerHTML = `<div class="card mb un-act"><h3>🗂 ${esc(k[0])} — قسم العضوية</h3>
      <p class="small muted" style="margin-top:0">${c.must_inspect ? 'هذا الطلب يتطلب كشفاً موقعياً قبل الاعتماد — أحِله للمفتش.' : F.kind === 'renewal' ? 'راجع سبب المراجعة والمستندات أعلاه، ثم اعتمد التجديد فتصير الهوية نافذة فوراً — أو أحِله للكشف إن شككت بحال المحل.' : F.kind === 'update' ? 'طابق التغيير مع المستندات، ثم اعتمده.' : 'تأكد من عدم وجود التزامات قائمة، ثم ارفعه لرئيس الاتحاد.'}</p>
      ${canInsp ? `<div class="field"><label>مفتش الغرفة (عند الإحالة)</label>${engSelect(m.governorate)}</div>` : ''}
      <div class="field"><label>ملاحظة أو النقص (إلزامية للإعادة والرفض)</label><textarea class="input" rows="2" data-note></textarea></div>
      <div class="row" style="gap:8px;flex-wrap:wrap">${c.approve ? `<button class="btn cyan" data-a="approve">${A}</button>` : ''}${canInsp ? `<button class="btn ${c.must_inspect ? 'cyan' : 'ghost'}" data-a="accept">إحالة للكشف الموقعي ←</button>` : ''}
        <button class="btn warn" data-a="return">إعادة للتاجر</button><span class="sp"></span><button class="btn ghost bad" data-a="reject_form">رفض</button></div></div>`;
    box.querySelectorAll('[data-a]').forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (['return', 'reject_form'].includes(a) && note().length < 5) return toast('اكتب النقص أو السبب', 'bad');
      if (a === 'reject_form' && !window.confirm('رفض الطلب؟ يحق للتاجر الاعتراض خلال 30 يوماً.')) return;
      run(b, { action: a, note: note(), engineer: box.querySelector('[data-eng]')?.value || null }, { approve: 'سُجّل الاعتماد', accept: 'أُحيل للكشف الموقعي', return: 'أُعيد للتاجر', reject_form: 'رُفض الطلب' }[a]);
    });
  } else if (c.triage) {
    const dm = F.can?.docs_missing || [];
    box.innerHTML = `<div class="card mb un-act"><h3>🗂 التدقيق والإحالة</h3><p class="small muted" style="margin-top:0">تأكد من اكتمال البيانات والمستندات، ثم أحِل المعاملة لمفتش الغرفة — أو أعدها للتاجر بالنقص.</p>
      <div class="field"><label>مفتش الغرفة</label>${engSelect(m.governorate)}</div>
      <div class="field"><label>ملاحظة أو النقص (للإعادة أو الرفض)</label><textarea class="input" rows="2" data-note></textarea></div>
      ${dm.length ? `<div class="notice warn">المستمسكات الناقصة: <b>${esc(dm.join('، '))}</b> — أعد الطلب للتاجر.</div>` : ''}
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn cyan ${dm.length ? 'is-off' : ''}" data-a="accept">إحالة للكشف الموقعي ←</button><button class="btn warn" data-a="return">إعادة للتاجر</button><span class="sp"></span><button class="btn ghost bad" data-a="reject_form">رفض شكلي</button></div></div>`;
    box.querySelectorAll('[data-a]').forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (a !== 'accept' && note().length < 5) return toast('اكتب النقص أو السبب', 'bad');
      if (a === 'reject_form' && !window.confirm('رفض المعاملة؟ يحق للتاجر الاعتراض خلال 30 يوماً.')) return;
      run(b, { action: a, note: note(), engineer: box.querySelector('[data-eng]')?.value || null }, { accept: 'أُحيلت للكشف الموقعي', return: 'أُعيدت للتاجر', reject_form: 'رُفضت المعاملة' }[a]);
    });
  } else if (c.visit) {
    visitForm(ctx, F, box);
  } else if (c.recommend) {
    let rec = 'approve';
    box.innerHTML = `<div class="card mb un-act"><h3>⚖️ توصية لجنة التصنيف — ${esc(m.category_label || '')}</h3>
      <div class="seg mb" data-rec>${Object.entries(REC).map(([k, v]) => `<button type="button" data-r="${k}" class="${k === rec ? 'on' : ''}">${esc(v[0])}</button>`).join('')}</div>
      ${F.kind === 'endorse' ? `<div class="field"><label>المبلغ الموصى به (اختياري — إن كان أقل من المطلوب)</label><input class="input num" dir="ltr" inputmode="numeric" data-ra></div>` : ''}
      <div class="field"><label>الشروط أو الأسباب</label><textarea class="input" rows="3" data-note placeholder="مثال: التأييد بشرط تقديم عرض سعر ثانٍ للمكينة الرئيسية"></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-go>رفع التوصية لرئيس الاتحاد ←</button></div></div>`;
    box.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { rec = b.dataset.r; box.querySelectorAll('[data-r]').forEach(z => z.classList.toggle('on', z === b)); });
    box.querySelector('[data-go]').onclick = e => run(e.target, { action: 'recommend', rec, note: note(), recommended_amount: money(box.querySelector('[data-ra]')?.value) }, 'رُفعت التوصية لرئيس الاتحاد');
  } else if (c.sign) {
    const isReq = ['membership', 'endorse'].includes(F.kind), svc = SVC_KINDS.includes(F.kind);
    box.innerHTML = `<div class="card mb un-act"><h3>🏛 قرار رئيس الاتحاد</h3>
      <p class="small" style="margin-top:0">${svc ? ({ renewal: 'الموافقة تجدّد الهوية سنة من اليوم وتصل المنتسب إشعاراً. الرفض يبقيها منتهية ويحق له الاعتراض.', update: 'الموافقة تطبّق التغييرات على سجل المنتسب وهويته (وموقع الكشف إن نُقل المحل).', cancel: 'الموافقة تلغي الانتماء وتُصدر كتاب براءة ذمة برمز تحقق، وتصير الهوية غير نافذة.' }[F.kind]) : isReq ? `التأييد يُصدر ${F.kind === 'endorse' ? 'كتاب تأييد تجاري موجّهاً إلى المصرف' : 'قرار الانتماء وهوية الغرفة التجارية'} مختوماً ببصمة رقمية ورمز تحقق${F.new_member ? '، ويمنح التاجر هويته التجارية' : ''}.` : `يُصدر ${esc(k[0])} بنتيجة الكشف ويصل المصرف آلياً${ins && (ins.result !== 'ok' || ins.machines_match === false || ins.site_state !== 'operating') ? ' — <b class="bad-t">النتيجة غير مطابقة وتصل هيئة النزاهة أيضاً</b>' : ''}.`}</p>
      <div class="field"><label>ملاحظات أو أسباب (الأسباب إلزامية للرفض والإعادة)</label><textarea class="input" rows="2" data-note></textarea></div>
      ${confirmBox('أوافق', 'cf')}
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn cyan" data-go>${svc ? { renewal: 'الموافقة على التجديد', update: 'الموافقة على التحديث', cancel: 'الموافقة وإصدار براءة الذمة' }[F.kind] : isReq ? 'التأييد وإصدار الكتاب' : 'إصدار الكتاب'}</button>
        <select class="input" data-to style="width:auto"><option value="">إعادة إلى…</option><option value="new">قسم العضوية والتسجيل</option>${F.kind !== 'cancel' ? '<option value="inspection">مفتش الغرفة</option>' : ''}${isReq ? '<option value="committee">لجنة التصنيف</option>' : ''}</select>
        <span class="sp"></span>${isReq || svc ? `<button class="btn ghost bad" data-rej>${F.appeal ? 'رفض نهائي' : svc ? 'الرفض' : 'عدم التأييد'}</button>` : ''}</div></div>`;
    wireFill(box, 'أوافق', 'cf');
    box.querySelector('[data-go]').onclick = e => {
      if (box.querySelector('[data-cf]').value.trim() !== 'أوافق') return toast('اكتب «أوافق» للتأكيد', 'bad');
      run(e.target, { action: 'issue', confirm: 'أوافق', note: note() }, svc ? 'سُجّلت الموافقة' : 'صدر الكتاب');
    };
    box.querySelector('[data-to]').onchange = e => { if (!e.target.value) return; if (note().length < 5) { e.target.value = ''; return toast('اكتب سبب الإعادة أولاً', 'bad'); } run(e.target, { action: 'return_to', to: e.target.value, note: note() }, 'أُعيدت المعاملة'); };
    const rj = box.querySelector('[data-rej]');
    if (rj) rj.onclick = () => { if (note().length < 10) return toast('اكتب أسباب الرفض بوضوح', 'bad'); if (!window.confirm('تأكيد عدم التأييد؟')) return; run(rj, { action: 'reject', note: note() }, 'سُجّل عدم التأييد'); };
  } else if (c.revoke) {
    box.innerHTML = `<details class="card mb un-act"><summary><b>سحب الكتاب</b> <span class="small muted">— لخطأ جوهري أو تغيّر حال المحل</span></summary>
      <div class="field mt"><label>سبب السحب (يصل المصرف وهيئة النزاهة)</label><textarea class="input" rows="2" data-note></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn bad" data-rv>سحب الكتاب</button></div></details>`;
    box.querySelector('[data-rv]').onclick = e => { if (note().length < 10) return toast('اكتب السبب', 'bad'); if (!window.confirm('سحب الكتاب؟ لا يمكن التراجع.')) return; run(e.target, { action: 'revoke', note: note() }, 'سُحب الكتاب'); };
  }
  if (c.reassign && !c.visit) {
    box.insertAdjacentHTML('beforeend', `<details class="card mb un-act"><summary><b>إعادة إسناد الكشف</b> <span class="small muted">— حالياً: ${esc(F.engineer || '—')}</span></summary>
      <div class="row mt" style="gap:8px">${engSelect(m.governorate, F.engineer_id)}<button class="btn sm cyan" data-ra2>إسناد</button></div></details>`);
    box.querySelector('[data-ra2]').onclick = e => run(e.target, { action: 'reassign', engineer: box.querySelectorAll('[data-eng]')[box.querySelectorAll('[data-eng]').length - 1].value || null }, 'أُعيد الإسناد');
  }
}
// الجلسة 53: تفاصيل طلب الخدمة (تجديد، تحديث، إلغاء، كتاب، بدل) وقائمة المستمسكات
function svcCard(F) {
  const M = F.meta || {};
  if (F.kind === 'renewal' && M.quote) {
    const q = M.quote, md = RENEW_MODE[M.mode] || RENEW_MODE.auto;
    return `<div class="card mb"><h3>🔄 طلب التجديد <span class="sp"></span>${badge([md[0], md[1]])}</h3><dl class="kv sm">
      <dt>الهوية</dt><dd>${q.days_expired ? `منتهية منذ <b class="num">${q.days_expired}</b> يوماً` : `تنتهي بعد <span class="num">${q.days_left}</span> يوماً`} (<span class="num">${esc(q.valid_until || '')}</span>)</dd>
      <dt>المدفوع</dt><dd>${iqd(F.fee)} — بدل <span class="num">${q.years}</span> سنة${q.late_fee ? ` + غرامة ${iqd(q.late_fee)}` : ''} ${F.fee_ref ? `<span class="num small muted" dir="ltr">· ${esc(F.fee_ref)}</span>` : ''}</dd>
      ${(q.why || []).length ? `<dt>سبب المراجعة</dt><dd>${q.why.map(esc).join('<br>')}</dd>` : ''}
      <dt>إقرار المنتسب</dt><dd>${M.confirm ? '✓ بيانات المحل لم تتغير' : '—'}</dd>${M.cash ? '<dt>الدفع</dt><dd>بوصل قبض في مقر الاتحاد</dd>' : ''}</dl></div>`;
  }
  if (F.kind === 'update' && M.changes) return `<div class="card mb"><h3>✏️ التغييرات المطلوبة ${M.needs_insp ? '<span class="tag warn-t">نقل — يتطلب كشفاً</span>' : ''}${M.needs_sg ? ' <span class="tag">قرار رئيس الاتحاد</span>' : ''}</h3>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>الحقل</th><th>الحالي</th><th>المطلوب</th></tr></thead><tbody>${Object.entries(M.changes).map(([k, v]) => `<tr><td>${esc(FIELD_LABEL[k] || k)}</td><td class="muted">${esc(fieldVal(k, v.from))}</td><td><b>${esc(fieldVal(k, v.to))}</b></td></tr>`).join('')}</tbody></table></div>
    ${F.note ? `<p class="small">ملاحظة المنتسب: ${esc(F.note)}</p>` : ''}</div>`;
  if (F.kind === 'cancel') return `<div class="card mb"><h3>🚪 طلب إلغاء الانتماء</h3><p class="small">سبب المنتسب: <b>${esc(F.note || '')}</b></p></div>`;
  if (F.kind === 'certificate') return `<div class="card mb"><h3>📄 كتاب تأييد عضوية — صدر آلياً</h3><dl class="kv sm"><dt>إلى</dt><dd>${esc(M.to || '')}</dd><dt>الغرض</dt><dd>${esc(M.purpose || '')}</dd><dt>الأجور</dt><dd>${iqd(F.fee)} <span class="num small muted" dir="ltr">${esc(F.fee_ref || '')}</span></dd></dl></div>`;
  if (F.kind === 'replace') return `<div class="card mb"><h3>🪪 بدل ${({ lost: 'ضائع', stolen: 'مسروق', damaged: 'تالف' })[M.reason] || ''} — صدر آلياً</h3><dl class="kv sm"><dt>النسخة الجديدة</dt><dd class="num">${esc(M.version || '')}</dd><dt>الرمز المُبطَل</dt><dd class="num" dir="ltr">${esc(M.old_code || '')}</dd></dl></div>`;
  return '';
}
function checklistCard(F) {
  if (!F.checklist) return '';
  const miss = F.checklist.filter(d => d.required && !d.doc).length;
  return `<div class="card mb"><h3>🗂 مستمسكات طالب الانتساب <span class="sp"></span>${miss ? badge([`ناقص ${miss}`, 'warn']) : badge(['مكتملة', 'ok'])}</h3>
    ${F.checklist.map(d => `<div class="un-doc ${d.doc ? 'ok' : ''}"><span class="un-dk">${d.doc ? '✅' : d.required ? '❌' : '▫️'}</span><div style="flex:1"><b>${esc(d.label)}</b>${d.required ? '' : ' <span class="small muted">(اختياري)</span>'}
      ${d.valid_until ? `<div class="small muted">نافذ حتى <span class="num">${esc(d.valid_until)}</span></div>` : ''}</div>${d.doc ? `<button type="button" class="btn ghost sm" data-ud="${d.doc}">عرض</button>` : ''}</div>`).join('')}</div>`;
}

const engSelect = (gov, sel) => `<select class="input" data-eng><option value="">تلقائي — مفتش غرفة ${gov ? esc(gov) : 'المحافظة'} الأقل انشغالاً</option>${(D.engineers || []).map(e => `<option value="${e.id}" ${e.id === sel ? 'selected' : ''}>${esc(e.name)} — ${esc(e.office || 'المقر العام')}${e.away ? ' · غائب' : ''} (${e.open} مفتوحة)</option>`).join('')}</select>`;

// ───────── الجلسة 53: الفريق (رئيس الاتحاد) ─────────
const ROLE_ORDER = ['chamber_pres', 'chamber_head', 'chamber_reg', 'chamber_eng', 'chamber_committee', 'chamber_fin'];
function teamTab(body) {
  const T = D.team || {}, R = T.ready || {};
  const group = list => ROLE_ORDER.map(r => [r, list.filter(p => p.role === r)]).filter(([, a]) => a.length);
  const people = list => group(list).map(([r, a]) => `<div class="un-row"><span>${ROLE_IC[r] || ''} <b>${esc(a[0].title.split(' — ')[0])}</b></span><span class="sp"></span><span class="small">${a.map(p => esc(p.name) + (p.away ? ' <span class="tag warn-t">غائب</span>' : '') + (p.pending_pw ? ' <span class="tag">لم يدخل بعد</span>' : '')).join('، ')}</span></div>`).join('') || '<p class="muted small">لا موظفين بعد.</p>';
  body.innerHTML = `<div class="card mb tr-ready ${R.ok ? 'ok' : 'bad'}"><b>${R.ok ? '✓ فريق الاتحاد مكتمل' : '⚠️ أكمل فريق الاتحاد'}</b>
      ${(R.missing || []).map(x => `<div class="tr-row"><span>${esc(x.t)}${x.branch_name ? ` <small class="muted">— ${esc(x.branch_name)}</small>` : ''}</span></div>`).join('')}
      ${(R.warn || []).length ? `<ul class="small muted tr-warn">${R.warn.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <div class="row mt"><span class="sp"></span><a class="btn cyan sm" href="#team">إدارة الفريق والغرف ←</a></div></div>
    <div class="card mb"><h3>🏛 المقر العام — بغداد <span class="small muted">(يخدم المحافظات التي لا فريق في غرفتها)</span></h3>${people(T.hq || [])}</div>
    ${(T.offices || []).map(o => `<div class="card mb"><h3>📍 ${esc(o.name)}</h3><p class="small muted" style="margin-top:0">${esc((o.govs || []).join('، '))}</p>${people(o.staff || [])}</div>`).join('')
      || '<div class="card mb empty">لا مكاتب محافظات بعد — أضفها من «فريقي ← غرف المحافظات» فتُوجَّه معاملات محافظاتها إليها آلياً.</div>'}
    <p class="small muted">التوجيه الآلي: طلب أي منتسب يصل موظف التسجيل في غرفة محافظة محله، والكشف يُسند لمفتش الغرفة الأقل انشغالاً (وغير الغائب)، وإن لم يوجد فللمقر العام.</p>`;
}

// ───────── المفتش: الكشف الموقعي ─────────
function visitForm(ctx, F, box) {
  const st = { gps: null, photos: [], site: F.kind === 'install' ? 'operating' : '', result: '', price_ok: null, match: null };
  const CHECKS = F.kind === 'membership' ? ['المحل قائم في العنوان المذكور', 'النشاط الفعلي يطابق السجل التجاري', 'اللافتة والاسم التجاري مطابقان', 'المحل مفتوح ويمارس النشاط']
    : F.kind === 'endorse' ? ['المحل قائم في العنوان المذكور', 'المخزن أو المحل يستوعب البضاعة الجديدة', 'حجم المبيعات يتناسب مع مبلغ القرض', 'البضاعة المطلوبة من صلب النشاط', 'اطّلعت على عروض الأسعار أو فواتير الشراء الأصلية']
    : F.kind === 'install' ? ['البضاعة أو المعدات واصلة', 'الكميات تطابق الفواتير'] : ['المحل يعمل', 'يوجد مخزون وحركة بيع', 'البضاعة الممولة موجودة أو بيعت ضمن النشاط'];
  const yn = (key, a, b) => `<div class="un-yn" data-yn="${key}"><button type="button" data-v="1" class="btn ghost">${a}</button><button type="button" data-v="0" class="btn ghost">${b}</button></div>`;
  box.innerHTML = `<div class="card mb un-act"><h3>📍 الكشف الموقعي — ${esc(UF_KIND[F.kind]?.[0] || '')}</h3>
    <div class="eng-visit" data-gpsbox><b>١. ثبّت موقعك وأنت داخل المحل</b><p class="small muted" style="margin:4px 0 10px">لا يُقبل الكشف دون موقع بدقة ±150 م أو أفضل.</p><button class="btn cyan big-btn" data-gps>📍 ثبّت موقعي الآن</button></div>
    <div class="eng-visit mt" data-phbox><b>٢. صوّر المحل والمعدات والبضائع</b> <span class="small muted">(صورة واحدة على الأقل)</span><div class="un-grid mt" data-ph></div><button class="btn ghost mt" data-cam>📷 التقط صورة</button></div>
    <div class="field mt"><label>٣. حالة المحل</label><div class="seg" data-site style="flex-wrap:wrap">${Object.entries(SITE_ST).map(([k, v]) => `<button type="button" data-s="${k}" class="${st.site === k ? 'on' : ''}">${esc(v[0])}</button>`).join('')}</div></div>
    <div class="field"><label>الفحص</label><div class="chips">${CHECKS.map(x => `<label class="chip"><input type="checkbox" value="${esc(x)}">${esc(x)}</label>`).join('')}</div></div>
    <div class="grid g2" style="gap:10px">
      ${['membership', 'endorse'].includes(F.kind) ? `<div class="field"><label>القيمة المقدّرة للموجودات الحالية (د.ع)</label><input class="input num" dir="ltr" inputmode="numeric" data-av></div>` : ''}
      ${F.kind === 'endorse' ? `<div class="field"><label>مجموع عروض أسعار المعدات والبضائع (د.ع)</label><input class="input num" dir="ltr" inputmode="numeric" data-qt value="${fmt(F.loan?.amount)}"></div>
        <div class="field"><label>القيمة العادلة بتقديرك (د.ع، اختياري)</label><input class="input num" dir="ltr" inputmode="numeric" data-fv></div>` : ''}
      <div class="field"><label>حجم النشاط</label><input class="input" data-cap value="${esc(F.member_full?.capacity || '')}"></div>
      <div class="field"><label>العاملون الموجودون</label><input class="input num" dir="ltr" inputmode="numeric" data-wk value="${esc(F.member_full?.workers || '')}"></div>
    </div>
    ${F.kind === 'endorse' ? `<div class="field"><label>هل أسعار المعدات والبضائع معقولة قياساً بالسوق؟</label>${yn('price', 'نعم، معقولة', 'لا، مبالغ فيها')}</div>` : ''}
    ${F.kind === 'install' ? `<div class="field"><label>هل المعدات والبضائع المنصوبة مطابقة لما مُوّل؟</label>${yn('match', 'نعم، مطابقة', 'لا')}</div>` : ''}
    <div class="field"><label>النتيجة</label>${yn('result', '✓ مطابق', '⚠ عليه ملاحظات')}</div>
    <div class="field"><label>الملاحظات</label><textarea class="input" rows="3" data-note></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-go>حفظ الكشف ورفعه ←</button></div></div>`;
  const paintPh = () => { box.querySelector('[data-ph]').innerHTML = st.photos.map(p => `<div class="un-ph"><img src="${p.data}" alt=""><span>✓ محفوظة</span></div>`).join(''); };
  box.querySelector('[data-gps]').onclick = async () => {
    const { gpsDialog } = await import('../geo.js');
    const g = await gpsDialog({ title: 'تثبيت زيارة المحل', hint: 'قف داخل المحل أو بجانب المعدات والبضائع.', want: 25, accMax: 150 });
    if (!g) return;
    st.gps = g;
    const b = box.querySelector('[data-gpsbox]'); b.classList.add('ok');
    b.innerHTML = `<div class="row"><span class="eng-pin">📍</span><div><b>ثُبّت موقعك</b><div class="small muted">دقة ±<span class="num">${Math.round(g.acc)}</span> م</div></div></div>`;
  };
  box.querySelector('[data-cam]').onclick = async e => {
    const { cameraCapture } = await import('../capture.js');
    const shot = await cameraCapture({ title: 'صورة المحل أو المعدات والبضائع', hint: '', ratio: 0.75 });
    if (!shot) return;
    e.target.disabled = true;
    try { const id = await rpc(ctx.sb, 'chamber_doc_add', { p_file: F.id, p_kind: 'visit_photo', p_data: shot.data, p_meta: shot.meta || {} }); st.photos.push({ id, data: shot.data }); paintPh(); }
    catch (er) { toast(cleanErr(er), 'bad'); }
    e.target.disabled = false;
  };
  box.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { st.site = b.dataset.s; box.querySelectorAll('[data-s]').forEach(z => z.classList.toggle('on', z === b)); });
  box.querySelectorAll('[data-yn]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => {
    const v = b.dataset.v === '1', k = g.dataset.yn;
    if (k === 'price') st.price_ok = v; else if (k === 'match') st.match = v; else st.result = v ? 'ok' : 'issues';
    g.querySelectorAll('button').forEach(z => { z.classList.toggle('cyan', z === b); z.classList.toggle('ghost', z !== b); });
  }));
  box.querySelector('[data-go]').onclick = async e => {
    if (!st.gps) return toast('ثبّت موقعك أولاً', 'bad');
    if (!st.photos.length) return toast('التقط صورة واحدة على الأقل', 'bad');
    if (!st.site) return toast('حدّد حالة المحل', 'bad');
    if (F.kind === 'endorse' && st.price_ok == null) return toast('حدّد معقولية الأسعار', 'bad');
    if (F.kind === 'install' && st.match == null) return toast('حدّد مطابقة المعدات والبضائع', 'bad');
    if (!st.result) return toast('حدّد النتيجة', 'bad');
    const p = { action: 'visit', gps: { lat: st.gps.lat, lng: st.gps.lng, acc: st.gps.acc }, photos: st.photos.map(x => x.id), site_state: st.site, result: st.result,
      note: box.querySelector('[data-note]').value.trim(), checks: [...box.querySelectorAll('.chips input:checked')].map(i => i.value),
      capacity: box.querySelector('[data-cap]').value.trim(), workers: money(box.querySelector('[data-wk]').value) };
    if (box.querySelector('[data-av]')) p.assessed_value = money(box.querySelector('[data-av]').value);
    if (box.querySelector('[data-qt]')) { p.quotes_total = money(box.querySelector('[data-qt]').value); p.fair_value = money(box.querySelector('[data-fv]').value); }
    if (st.price_ok != null) p.price_ok = st.price_ok;
    if (st.match != null) p.machines_match = st.match;
    e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'chamber_act', { p_id: F.id, p });
      resultScreen({ ok: true, title: 'حُفظ الكشف', ref: F.code, msg: r.next === 'committee' ? 'رُفعت المعاملة إلى لجنة التصنيف.' : 'رُفعت المعاملة لقرار رئيس الاتحاد.', rows: [['حالة المحل', esc(SITE_ST[st.site][0])], ['الصور', `<span class="num">${st.photos.length}</span>`]] });
      ctx.ccOpen = null; render(ctx);
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── سجل العضو ─────────
async function memberDetail(ctx, id) {
  const { sb, root } = ctx;
  let M;
  try { M = await rpc(sb, 'chamber_member', { p_id: id }); } catch (e) { ctx.unMem = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const me = D.me;
  root.innerHTML = `<button type="button" class="linkbtn eng-back" data-back>→ سجل الأعضاء</button>
    <div class="mb">${memberCard(M)}</div>
    <div class="card mb"><dl class="kv sm">
      <dt>صاحب المحل</dt><dd>${esc(M.owner_name)}${M.phone ? ` · <span class="num">${esc(M.phone)}</span>` : ''}</dd><dt>النشاط</dt><dd>${esc(M.category_label)}</dd>
      <dt>العنوان</dt><dd>${esc([M.governorate, M.city, M.address].filter(Boolean).join(' — '))}${M.site_geo ? ` · <a href="${mapsLink(M.site_geo)}" target="_blank" rel="noopener">📍 الخريطة</a>` : ''}</dd>
      <dt>السجل التجاري</dt><dd class="num">${esc(M.trade_name_no || '—')}</dd><dt>إجازة النشاط</dt><dd><span class="num">${esc(M.dev_license_no || '—')}</span>${M.dev_license_kind ? ` · ${M.dev_license_kind === 'complete' ? 'كاملة التأسيس' : 'تحت التأسيس'}` : ''}</dd>
      <dt>البضائع</dt><dd>${esc(M.products || '—')}${M.capacity ? ` · ${esc(M.capacity)}` : ''}</dd>${M.joined_at ? `<dt>تاريخ الانتماء</dt><dd class="num">${esc(M.joined_at)}</dd>` : ''}
      ${M.reason ? `<dt>ملاحظة</dt><dd>${esc(M.reason)}</dd>` : ''}</dl></div>
    ${M.quote?.allowed ? `<div class="card mb"><h3>🔄 التجديد الآن <span class="sp"></span>${badge([RENEW_MODE[M.quote.mode][0], RENEW_MODE[M.quote.mode][1]])}</h3><dl class="kv sm">
      <dt>المبلغ المستحق</dt><dd><b>${iqd(M.quote.total)}</b> — بدل <span class="num">${M.quote.years}</span> سنة${M.quote.late_fee ? ` + غرامة ${iqd(M.quote.late_fee)}` : ''}</dd>
      ${(M.quote.why || []).length ? `<dt>ملاحظة</dt><dd>${M.quote.why.map(esc).join('<br>')}</dd>` : ''}</dl></div>` : ''}
    <div data-mact></div>
    <div class="card mb"><h3>🗂 مستمسكات المنتسب</h3>${(M.docs || []).length ? M.docs.map(d => `<div class="un-doc ${d.expired ? '' : 'ok'}"><span class="un-dk">${d.expired ? '⚠️' : '📎'}</span><div style="flex:1"><b>${esc(d.label)}</b>
      <div class="small muted">${dt(d.at)}${d.valid_until ? ` · ${d.expired ? '<span class="bad-t">انتهى</span>' : 'نافذ حتى'} <span class="num">${esc(d.valid_until)}</span>` : ''}</div></div><button type="button" class="btn ghost sm" data-ud="${d.id}">عرض</button></div>`).join('') : '<p class="muted small">لا مستمسكات محفوظة.</p>'}</div>
    ${(M.letters || []).length ? `<div class="card mb"><h3>📜 كتب الاتحاد للمنتسب</h3>${M.letters.map(l => `<div class="un-row"><button type="button" class="linkbtn" data-l="${l.id}">${esc(l.title)}</button><span class="sp"></span><span class="num small" dir="ltr">${esc(l.no)}</span>${l.revoked_at ? badge(['مسحوب', 'bad']) : ''}</div>`).join('')}</div>` : ''}
    <div class="card mb"><h3>معاملات العضو</h3>${(M.files || []).length ? `<div class="eng-cards">${M.files.map(fCard).join('')}</div>` : '<p class="muted">لا معاملات.</p>'}</div>
    ${(M.log || []).length ? `<details class="card mb"><summary><b>سجل الهوية</b></summary>${M.log.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')} · ${dt(l.at)}</div></div>`).join('')}</details>` : ''}`;
  back(ctx, root);
  root.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { ctx.unMem = null; ctx.ccOpen = b.dataset.f; window.scrollTo(0, 0); render(ctx); });
  root.querySelectorAll('[data-ud]').forEach(b => b.onclick = () => viewDoc(ctx, 'chamber_doc', { p_id: b.dataset.ud }));
  root.querySelectorAll('[data-l]').forEach(b => b.onclick = () => openLetter(M.letters.find(x => x.id === b.dataset.l)));
  const box = root.querySelector('[data-mact]'), sg = SG(me.role);
  const acts = [];
  if (M.quote?.allowed && ['chamber_pres', 'chamber_head', 'chamber_reg', 'chamber_fin'].includes(me.role) && (M.quote.mode !== 'inspection' || sg)) acts.push(['renew', `تجديد بوصل قبض (${num(M.quote.total)} د.ع)`, 'cyan']);
  if (sg && ['approved', 'expired'].includes(M.status)) acts.push(['suspend', 'تعليق العضوية', 'ghost bad']);
  if (sg && M.status === 'suspended') acts.push(['reinstate', 'إعادة العضوية', 'cyan']);
  if (sg && ['approved', 'expired', 'suspended'].includes(M.status)) acts.push(['cancel', 'إلغاء الانتماء', 'ghost bad']);
  if (!acts.length) return;
  box.innerHTML = `<div class="card mb un-act"><h3>إجراءات الهوية</h3><div class="grid g2" style="gap:10px"><div class="field"><label>رقم وصل القبض (للتجديد)</label><input class="input num" dir="ltr" data-ref></div>
    <div class="field"><label>السبب أو الملاحظة</label><input class="input" data-note></div></div>
    <div class="row" style="gap:8px">${acts.map(([k, t, cls]) => `<button class="btn ${cls}" data-ma="${k}">${t}</button>`).join('')}</div></div>`;
  box.querySelectorAll('[data-ma]').forEach(b => b.onclick = async () => {
    if (b.dataset.ma === 'cancel' && !window.confirm('إلغاء انتماء هذا المنتسب؟ تصير هويته غير نافذة.')) return;
    b.disabled = true;
    try { await rpc(sb, 'chamber_member_act', { p_id: M.id, p: { action: b.dataset.ma, ref: box.querySelector('[data-ref]').value.trim(), note: box.querySelector('[data-note]').value.trim() } }); toast('تم', 'ok'); memberDetail(ctx, id); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
}
