// الجلسة 52 + 53: بوابة المقترض — صفحة «اتحاد الصناعات العراقي»
// الصفحة الرئيسية: هويتي الصناعية + خدماتي + معاملاتي + كتبي
// #union/apply   طلب الانتساب بأربع خطوات: المعمل ← المستمسكات ← الموقع ← الدفع
// #union/renew   تجديد الهوية (فوري، أو بمراجعة، أو بكشف — يقرره النظام من مدة الانتهاء)
// #union/update  تحديث بيانات المعمل · #union/cert كتاب تأييد عضوية فوري · #union/replace بدل ضائع
// #union/docs    مستمسكاتي · #union/cancel إلغاء الانتماء
import { esc, dt, iqd, num, rpc, toast, cleanErr, modal, askOtp, govOptions, PAY_METHODS, PAY_LABEL, IND_CATS, resultScreen } from './core.js';
import { cameraCapture } from './capture.js';
import { ufBadge, UF_KIND, stepsBar, memberCard, openLetter, RENEW_MODE, FIELD_LABEL, fieldVal } from './union-ui.js';
import { wizHead, wireWizHead } from './wizard-ui.js';

export function unionBanner() {
  return `<a class="card mb vet-banner" href="#union" style="border-inline-start:4px solid #4d5b2a"><div class="vb-ic">🏭</div><div><span class="pill">اتحاد الصناعات العراقي</span>
    <h2>صاحب معمل أو ورشة إنتاجية؟</h2><p>انتسب للاتحاد واحصل على هويتك الصناعية وجدّدها من هاتفك، واطلب كتاب تأييد عضوية فورياً لأي جهة.</p></div><span class="go">هويتي الصناعية ←</span></a>`;
}

const sub = () => (location.hash.slice(1).split('/')[1] || '');
const days = d => Math.round((new Date(d) - new Date(new Date().toDateString())) / 864e5);
const payGrid = (attr = 'pm') => `<div class="paygrid">${PAY_METHODS.map(([k, t, col], i) => `<button type="button" data-${attr}="${k}" class="${i === 0 ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>`;
function wirePay(box, attr = 'pm') {
  const st = { m: PAY_METHODS[0][0] };
  box.querySelectorAll(`[data-${attr}]`).forEach(b => b.onclick = () => { st.m = b.dataset[attr]; box.querySelectorAll(`[data-${attr}]`).forEach(z => z.classList.toggle('on', z === b)); });
  return st;
}
const back = (t = 'اتحاد الصناعات') => `<a class="linkbtn eng-back" href="#union">→ ${esc(t)}</a>`;
const head = (t, p) => `<div class="page-head"><div><h1>${t}</h1>${p ? `<p>${p}</p>` : ''}</div></div>`;
const ICON = { renew: '🔄', cert: '📄', update: '✏️', docs: '🗂', replace: '🪪', cancel: '🚪' };

async function snapDoc(kind, label, hint = '') {
  return cameraCapture({ title: `صوّر: ${label}`, hint, allowFile: true, ratio: ['photo'].includes(kind) ? 0.8 : ['id_front', 'id_back', 'residence'].includes(kind) ? 1.55 : 0.72 });
}
async function viewDoc(sb, id) {
  try {
    const d = await rpc(sb, 'union_doc', { p_id: id });
    modal(`<h3>${esc(d.label || '')}</h3>${String(d.mime || '').startsWith('image/') ? `<img src="${d.data}" alt="" style="width:100%;border-radius:10px">` : `<iframe src="${d.data}" style="width:100%;height:70vh;border:0"></iframe>`}
      ${d.valid_until ? `<p class="small">نافذ حتى <b class="num">${esc(d.valid_until)}</b></p>` : ''}<p class="small muted">رُفع ${dt(d.at)}</p>`, { wide: true });
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

export async function pageUnion(body, ctx) {
  const U = await rpc(ctx.sb, 'union_my');
  const mem = U.members || [];
  const cur = mem.find(m => m.code) || null;
  const s = sub();
  if (s === 'apply') return pageApply(body, ctx, U);
  if (cur && s === 'renew') return pageRenew(body, ctx, U, cur);
  if (cur && s === 'update') return pageUpdate(body, ctx, U, cur);
  if (cur && s === 'cert') return pageCert(body, ctx, U, cur);
  if (cur && s === 'replace') return pageReplace(body, ctx, U, cur);
  if (cur && s === 'docs') return pageDocs(body, ctx, U, cur);
  if (cur && s === 'cancel') return pageCancel(body, ctx, U, cur);
  return pageHome(body, ctx, U, cur);
}

// ───────── الصفحة الرئيسية ─────────
function pageHome(body, ctx, U, cur) {
  const files = U.files || [], letters = U.letters || [];
  const openMem = files.find(f => ['new', 'returned', 'inspection', 'committee', 'signing'].includes(f.status) && ['membership', 'endorse'].includes(f.kind));
  const q = cur?.quote || {};
  let banner = '';
  if (cur) {
    if (cur.status === 'suspended') banner = `<div class="notice bad mb"><b>عضويتك معلّقة</b>${cur.reason ? ` — ${esc(cur.reason)}` : ''}<div class="small">راجع الاتحاد لإعادتها.</div></div>`;
    else if (q.pending) banner = `<div class="notice info mb">🔄 طلب تجديد هويتك قيد الدراسة في الاتحاد — تابعه في «معاملاتي» أدناه.</div>`;
    else if (cur.status === 'expired') banner = `<div class="card mb un-alert bad"><b>انتهت هويتك منذ <span class="num">${q.days_expired ?? Math.abs(days(cur.valid_until))}</span> يوماً</b>
      <p class="small" style="margin:4px 0 10px">${q.mode === 'auto' ? `جدّدها الآن فتصير نافذة فوراً. المبلغ ${iqd(q.total)}.` : esc(RENEW_MODE[q.mode]?.[2] || '')}</p>
      <a class="btn cyan block" href="#union/renew">جدّد هويتي ←</a></div>`;
    else if (q.allowed) banner = `<div class="card mb un-alert warn"><b>تنتهي هويتك خلال <span class="num">${q.days_left}</span> يوماً</b>
      <p class="small" style="margin:4px 0 10px">جدّدها الآن وتُضاف السنة الجديدة بعد تاريخ انتهائها — دون غرامة.</p><a class="btn cyan block" href="#union/renew">جدّد هويتي ←</a></div>`;
  }
  const tiles = cur && cur.status !== 'pending' ? [
    ['renew', 'تجديد الهوية', q.allowed ? (cur.status === 'expired' ? 'منتهية — جدّدها الآن' : 'متاح الآن') : q.early ? `يُفتح ${esc(q.opens_at || '')}` : 'غير متاح الآن'],
    ['cert', 'كتاب تأييد عضوية', cur.valid ? `فوري لأي جهة — ${num(U.fees?.cert)} د.ع` : 'يحتاج هوية نافذة'],
    ['update', 'تحديث بيانات المعمل', cur.open_update ? 'طلبك قيد الدراسة' : 'العنوان، المنتجات، العاملون…'],
    ['docs', 'مستمسكاتي', `${(cur.docs || []).length} مستند محفوظ${(cur.docs || []).some(d => d.expired) ? ' · أحدها منتهٍ' : ''}`],
    ['replace', 'بدل ضائع أو تالف', `هوية جديدة برمز جديد — ${num(U.fees?.replace)} د.ع`]] : [];
  const draft = U.draft;
  const dMiss = draft ? (draft.docs || []).filter(d => d.required && !d.doc).length : 0;
  body.innerHTML = `
    ${head(`🏭 ${esc(U.org?.name || 'اتحاد الصناعات العراقي')}`, 'هويتك الصناعية وخدماتك ومعاملاتك لدى الاتحاد')}
    ${cur ? `<div class="mb">${memberCard(cur)}</div>${banner}
      ${tiles.length ? `<h2 class="un-h2">خدماتي</h2><div class="un-svc mb">${tiles.map(([k, t, d]) => `<a class="un-tile" href="#union/${k}"><span class="un-ti">${ICON[k]}</span><b>${esc(t)}</b><small>${d}</small></a>`).join('')}</div>` : ''}`
    : draft ? `<div class="card mb un-alert info"><b>أكمل طلب انتسابك</b><p class="small" style="margin:4px 0 10px">${esc(draft.member?.factory_name || '')} — ${dMiss ? `بقي <b class="num">${dMiss}</b> من المستمسكات` : 'المستمسكات مكتملة، بقي الدفع والتقديم'}</p>
        <a class="btn cyan block" href="#union/apply">أكمل الطلب ←</a></div>`
    : openMem ? '' : applyCta(U)}
    ${files.length ? `<h2 class="un-h2">معاملاتي لدى الاتحاد</h2>${files.map(f => fileCard(f, U)).join('')}` : ''}
    ${letters.length ? `<h2 class="un-h2">كتبي من الاتحاد</h2><div class="card mb">${letters.map(l => `<div class="un-row"><button type="button" class="linkbtn" data-l="${l.id}">📜 ${esc(l.title)}</button><span class="sp"></span><span class="num small" dir="ltr">${esc(l.no)}</span>${l.revoked_at ? ' <span class="badge bad">مسحوب</span>' : l.valid_until && days(l.valid_until) < 0 ? ' <span class="badge muted">انتهى نفاذه</span>' : ''}</div>`).join('')}</div>` : ''}
    ${cur && !['pending', 'suspended'].includes(cur.status) && !cur.open_cancel ? `<p class="small" style="text-align:center"><a class="linkbtn muted" href="#union/cancel">إلغاء الانتماء للاتحاد</a></p>` : ''}
    <p class="small muted">قانون اتحاد الصناعات العراقي رقم (44) لسنة 1989: الانتماء اختياري، ويُعترض على قرار الرفض خلال ${U.fees?.appeal_days || 30} يوماً.</p>`;
  wireFiles(body, ctx, U);
}

function applyCta(U) {
  const fee = Number(U.fees?.member || 0) + Number(U.fees?.insp || 0);
  return `<div class="card mb"><h3 style="margin-top:0">انتسب إلى اتحاد الصناعات</h3>
    <p class="small muted" style="margin-top:0">إن كنت ستطلب قرضاً صناعياً فلا حاجة لهذا الطلب — يُدرس انتماؤك مع القرض. هنا تطلب الهوية الصناعية وحدها.</p>
    <ol class="un-how"><li>بيانات معملك</li><li>صوّر مستمسكاتك: البطاقة الوطنية، بطاقة السكن، صورتك، الاسم التجاري، عقد الأرض، واجهة المعمل</li><li>ثبّت موقع المعمل (إن كنت فيه)</li><li>ادفع ${iqd(fee)} — بدل سنة وأجور الكشف</li></ol>
    <p class="small muted">بعدها يدقق قسم العضوية طلبك، ويزور مهندس الاتحاد معملك، ثم تصلك هويتك على هاتفك برمز QR.</p>
    <a class="btn cyan block" href="#union/apply">ابدأ طلب الانتساب ←</a></div>`;
}

function fileCard(f, U) {
  const m = f.meta || {};
  return `<div class="card mb">
    <div class="row"><b>${UF_KIND[f.kind]?.[1] || ''} ${esc(f.kind_label)}</b><span class="num small muted">${esc(f.code)}</span><span class="sp"></span>${ufBadge(f.status)}</div>
    ${stepsBar(f)}
    ${f.app ? `<p class="small muted" style="margin:4px 0">لطلب القرض <span class="num">${esc(f.app)}</span></p>` : ''}
    ${f.kind === 'renewal' && m.quote ? `<p class="small muted" style="margin:4px 0">${esc(RENEW_MODE[m.mode]?.[0] || '')} · بدل ${num(m.quote.years)} سنة${m.quote.late_fee ? ` + غرامة ${num(m.quote.late_fee)}` : ''}</p>` : ''}
    ${f.kind === 'update' && m.changes ? `<div class="small" style="margin:4px 0">${Object.entries(m.changes).map(([k, v]) => `${esc(FIELD_LABEL[k] || k)}: <s class="muted">${esc(fieldVal(k, v.from))}</s> ← <b>${esc(fieldVal(k, v.to))}</b>`).join('<br>')}</div>` : ''}
    ${f.kind === 'certificate' && m.to ? `<p class="small muted" style="margin:4px 0">إلى ${esc(m.to)} — ${esc(m.purpose || '')}</p>` : ''}
    ${f.status === 'returned' ? `<div class="notice warn">أعادها الاتحاد للاستكمال: <b>${esc(f.return_note || '')}</b></div>` : ''}
    ${f.status === 'rejected' ? `<div class="notice bad"><b>لم يوافق الاتحاد:</b> ${esc(f.reason || '')}${f.appeal ? '<div class="small">قدّمت اعتراضاً — قرار الأمين العام بعده نهائي.</div>' : ''}</div>` : ''}
    ${f.status === 'returned' && f.kind !== 'endorse' ? `<div class="mt"><b class="small">المستندات</b>${(f.checklist || (f.docs || []).map(d => ({ kind: d.kind, label: d.label, doc: d.id, required: false }))).map(d => `
      <div class="row" style="gap:8px;margin-top:6px"><span>${d.doc ? '✅' : d.required ? '⬜' : '▫️'}</span><span class="small" style="flex:1">${esc(d.label)}</span>
        <button type="button" class="btn sm ${d.doc ? 'ghost' : 'cyan'}" data-doc="${d.kind}" data-lbl="${esc(d.label)}" data-file="${f.id}">${d.doc ? 'استبدال' : '📷 إرفاق'}</button></div>`).join('')}
      <div class="row" style="gap:8px;margin-top:6px"><span>➕</span><span class="small" style="flex:1">مستند آخر يطلبه الاتحاد</span><button type="button" class="btn sm ghost" data-doc="other" data-lbl="مستند آخر" data-file="${f.id}">📷 إرفاق</button></div></div>` : ''}
    <div class="row mt" style="gap:8px">${f.status === 'returned' && f.kind !== 'endorse' ? `<button class="btn cyan sm" data-resub="${f.id}">أكملت النواقص — أعدها للاتحاد</button>` : ''}
      ${f.status === 'returned' && f.kind === 'endorse' ? `<a class="btn cyan sm" href="#apply">صحّح طلب القرض</a>` : ''}
      ${f.can_appeal ? `<button class="btn warn sm" data-appeal="${f.id}">اعتراض على القرار</button>` : ''}
      <span class="sp"></span><span class="small muted">${f.fee ? `${iqd(f.fee)} ${f.fee_paid_at ? '✓ مدفوعة' : f.kind === 'endorse' ? '(تُدفع مع رسوم القرض)' : ''}` : ''}</span></div></div>`;
}

function wireFiles(body, ctx, U) {
  const { sb } = ctx, letters = U.letters || [], redo = () => pageUnion(body, ctx);
  body.querySelectorAll('[data-l]').forEach(b => b.onclick = () => openLetter(letters.find(x => x.id === b.dataset.l)));
  body.querySelectorAll('[data-doc]').forEach(b => b.onclick = async () => {
    const shot = await snapDoc(b.dataset.doc, b.dataset.lbl);
    if (!shot) return;
    try { await rpc(sb, 'union_doc_add', { p_file: b.dataset.file, p_kind: b.dataset.doc, p_data: shot.data, p_meta: shot.meta || {} }); toast('حُفظ المستند', 'ok'); redo(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  });
  body.querySelectorAll('[data-resub]').forEach(b => b.onclick = async () => {
    b.disabled = true;
    try { await rpc(sb, 'union_resubmit', { p_file: b.dataset.resub, p_note: null }); toast('أُعيدت المعاملة للاتحاد', 'ok'); redo(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
  body.querySelectorAll('[data-appeal]').forEach(b => b.onclick = () => {
    const m = modal(`<h3>الاعتراض على قرار الاتحاد</h3><p class="small muted">يعود اعتراضك إلى الأمين العام، وقراره بعده نهائي داخل الاتحاد.</p>
      <div class="field"><label>أسباب اعتراضك</label><textarea class="input" rows="4" data-n></textarea></div><div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الاعتراض</button></div>`);
    m.el.querySelector('[data-s]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'union_appeal', { p_file: b.dataset.appeal, p_note: m.el.querySelector('[data-n]').value.trim() }); m.close(); toast('أُرسل الاعتراض', 'ok'); redo(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  });
}

// ───────── طلب الانتساب بأربع خطوات ─────────
const AP_STEPS = [['المعمل', 'بياناتك'], ['المستمسكات', 'صوّرها بهاتفك'], ['الموقع', 'اختياري'], ['الدفع', 'وتقديم الطلب']];
async function pageApply(body, ctx, U) {
  const { sb, profile } = ctx;
  if ((U.members || []).some(m => m.valid)) { location.hash = '#union'; return; }
  const D = U.draft;
  const st = ctx.unAp = ctx.unAp || { step: D ? ((D.docs || []).some(d => d.required && !d.doc) ? 1 : 2) : 0 };
  if (!D && st.step > 0) st.step = 0;
  const missing = D ? (D.docs || []).filter(d => d.required && !d.doc) : [];
  const reach = !D ? 0 : missing.length ? 1 : 3;
  const m = D?.member || {};
  const go = n => { st.step = n; pageApply(body, ctx, U); window.scrollTo(0, 0); };
  const reload = async () => { const U2 = await rpc(sb, 'union_my'); return pageApply(body, ctx, U2); };
  const wz = wizHead({ title: 'طلب الانتساب لاتحاد الصناعات', sub: D ? `<span class="num">${esc(D.code)}</span> · مسودة محفوظة` : '', steps: AP_STEPS, cur: st.step,
    done: !D ? 0 : missing.length ? 1 : Math.max(st.step, 2), reach, exit: '#union', exitLabel: 'حفظ والخروج' });
  const f = (k, l, ph = '', a = '', v = m[k] ?? '') => `<div class="field"><label>${l}</label><input class="input" data-k="${k}" placeholder="${esc(ph)}" value="${esc(v)}" ${a}></div>`;

  if (st.step === 0) {
    const lf = m.legal_form || 'individual', dk = m.dev_license_kind || '';
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      ${f('factory_name', 'اسم المعمل أو الورشة ★', 'كما في شهادة الاسم التجاري')}
      <div class="field"><label>صنف الصناعة ★</label><select class="input" data-k="category"><option value="">اختر</option>${Object.entries(IND_CATS).map(([k, t]) => `<option value="${k}" ${m.category === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
      ${f('products', 'المنتجات ★', 'مثال: أبواب وشبابيك حديد')}
      <div class="field"><label>الشكل القانوني</label><div class="seg" data-lf><button type="button" data-v="individual" class="${lf === 'individual' ? 'on' : ''}">فرد (صاحب المعمل)</button><button type="button" data-v="company" class="${lf === 'company' ? 'on' : ''}">شركة</button></div></div>
      ${f('trade_name_no', 'رقم تسجيل الاسم التجاري لدى غرفة الصناعة ★', '', 'dir="ltr"')}
      <div class="grid g2" style="gap:12px">${f('dev_license_no', 'رقم إجازة التنمية الصناعية (إن وُجدت)', '', 'dir="ltr"')}
        <div class="field"><label>نوع الإجازة</label><select class="input" data-k="dev_license_kind"><option value="">—</option><option value="under" ${dk === 'under' ? 'selected' : ''}>تحت التأسيس</option><option value="complete" ${dk === 'complete' ? 'selected' : ''}>كاملة التأسيس</option></select></div></div>
      <div class="grid g2" style="gap:12px"><div class="field"><label>المحافظة ★</label><select class="input" data-k="governorate">${govOptions(m.governorate || profile.governorate || '')}</select></div>${f('city', 'المدينة / المنطقة الصناعية')}</div>
      ${f('address', 'عنوان المعمل ★', 'الشارع، أقرب نقطة دالة')}
      <div class="grid g2" style="gap:12px">${f('workers', 'عدد العاملين', '', 'inputmode="numeric" dir="ltr"')}${f('capacity', 'الطاقة الإنتاجية', 'مثال: 300 باب شهرياً')}</div>
      ${f('capital', 'رأس المال التقريبي (د.ع)', '', 'inputmode="numeric" dir="ltr"', m.capital ? num(m.capital) : '')}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-next>التالي: المستمسكات ←</button></div></div></div>`;
    let legal = lf;
    body.querySelectorAll('[data-lf] button').forEach(b => b.onclick = () => { legal = b.dataset.v; body.querySelectorAll('[data-lf] button').forEach(z => z.classList.toggle('on', z === b)); });
    body.querySelector('[data-next]').onclick = async e => {
      const d = { legal_form: legal }; body.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
      if (!d.factory_name || !d.category || !d.products || !d.trade_name_no || !d.governorate || !d.address) return toast('أكمل الحقول المعلَّمة ★', 'bad');
      e.target.disabled = true;
      try { await rpc(sb, 'union_member_draft', { p: d }); st.step = 1; await reload(); window.scrollTo(0, 0); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  } else if (st.step === 1) {
    const docs = D.docs || [];
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <p class="small muted" style="margin-top:0">صوّر كل مستمسك بهاتفك في إضاءة جيدة، أو ارفعه ملف PDF. المعلَّم ★ مطلوب قبل الدفع.</p>
      ${docs.map(d => `<div class="un-doc ${d.doc ? 'ok' : ''}"><span class="un-dk">${d.doc ? '✅' : d.required ? '⬜' : '▫️'}</span>
        <div style="flex:1"><b>${esc(d.label)}</b>${d.required ? ' <span class="small bad-t">★</span>' : ' <span class="small muted">(اختياري)</span>'}${d.kind === 'ind_lease' ? `<div class="small muted">${d.valid_until ? `نافذ حتى <span class="num">${esc(d.valid_until)}</span>` : 'إن كان عقد إيجار اكتب تاريخ انتهائه'}</div>` : ''}</div>
        ${d.doc ? `<button type="button" class="btn ghost sm" data-see="${d.doc}">عرض</button>` : ''}<button type="button" class="btn sm ${d.doc ? 'ghost' : 'cyan'}" data-up="${d.kind}" data-lbl="${esc(d.label)}">${d.doc ? 'استبدال' : '📷 صوّر'}</button></div>`).join('')}
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span>
        <button class="btn cyan ${missing.length ? 'is-off' : ''}" data-next>${missing.length ? `بقي ${missing.length} من المستمسكات` : 'التالي: موقع المعمل ←'}</button></div></div></div>`;
    body.querySelector('[data-prev]').onclick = () => go(0);
    body.querySelectorAll('[data-see]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.see));
    body.querySelectorAll('[data-up]').forEach(b => b.onclick = async () => {
      const kind = b.dataset.up; let meta = {};
      if (kind === 'ind_lease') {
        const until = await new Promise(res => {
          const md = modal(`<h3>عقد إيجار الأرض أو سند الملكية</h3><div class="field"><label>إن كان عقد إيجار: تاريخ انتهائه</label><input class="input" type="date" data-d dir="ltr"></div>
            <p class="small muted">سند الملكية لا ينتهي — اترك التاريخ فارغاً.</p><div class="row"><span class="sp"></span><button class="btn cyan" data-ok>التالي: صوّره ←</button></div>`, { onClose: () => res(undefined) });
          md.el.querySelector('[data-ok]').onclick = () => { const v = md.el.querySelector('[data-d]').value; res(v || null); md.close(); };
        });
        if (until === undefined) return;
        if (until) meta.valid_until = until;
      }
      const shot = await snapDoc(kind, b.dataset.lbl);
      if (!shot) return;
      b.disabled = true;
      try { await rpc(sb, 'union_doc_add', { p_file: D.id, p_kind: kind, p_data: shot.data, p_meta: { ...(shot.meta || {}), ...meta } }); toast('حُفظ ✓', 'ok'); await reload(); }
      catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    });
    body.querySelector('[data-next]').onclick = () => { if (missing.length) return toast(`بقي: ${missing.map(d => d.label).join('، ')}`, 'bad'); go(2); };
  } else if (st.step === 2) {
    const g = m.site_geo;
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <div class="eng-visit ${g ? 'ok' : ''}" data-gbox>${g ? `<div class="row"><span class="eng-pin">📍</span><div><b>ثُبّت موقع المعمل</b><div class="small muted">دقة ±<span class="num">${num(g.acc)}</span> م — يصل المهندس مباشرة بالخريطة</div></div></div>`
        : '<b>هل أنت داخل المعمل الآن؟</b><p class="small muted" style="margin:4px 0 10px">ثبّت موقعه ليصل مهندس الاتحاد بالخريطة دون اتصال. إن لم تكن فيه تخطَّ هذه الخطوة — يثبّته المهندس عند الزيارة.</p>'}
        <button class="btn ${g ? 'ghost' : 'cyan'} big-btn" data-gps>📍 ${g ? 'أعد التثبيت' : 'ثبّت موقع المعمل الآن'}</button></div>
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-next>${g ? 'التالي: الدفع ←' : 'تخطَّ — التالي: الدفع ←'}</button></div></div></div>`;
    body.querySelector('[data-prev]').onclick = () => go(1);
    body.querySelector('[data-next]').onclick = () => go(3);
    body.querySelector('[data-gps]').onclick = async e => {
      const { gpsDialog } = await import('./geo.js');
      const gg = await gpsDialog({ title: 'موقع المعمل', hint: 'قف داخل المعمل أو أمام بابه.', want: 30, accMax: 150 });
      if (!gg) return;
      e.target.disabled = true;
      const d = { ...m, site_geo: { lat: gg.lat, lng: gg.lng, acc: gg.acc } };
      try { await rpc(sb, 'union_member_draft', { p: d }); toast('ثُبّت الموقع', 'ok'); await reload(); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  } else {
    body.innerHTML = `${wz}<div class="wiz-body"><div class="card">
      <dl class="kv sm"><dt>المعمل</dt><dd><b>${esc(m.factory_name)}</b> — ${esc(IND_CATS[m.category] || '')}</dd><dt>المنتجات</dt><dd>${esc(m.products || '')}</dd>
        <dt>العنوان</dt><dd>${esc([m.governorate, m.city, m.address].filter(Boolean).join(' — '))}${m.site_geo ? ' · 📍 مثبّت' : ''}</dd>
        <dt>الاسم التجاري</dt><dd class="num">${esc(m.trade_name_no || '')}</dd><dt>المستمسكات</dt><dd>${(D.docs || []).filter(d => d.doc).length} مرفوعة ✓</dd></dl>
      <div class="review mt"><dl class="kv"><dt>بدل الانتماء لسنة + أجور الكشف على المعمل</dt><dd><b>${iqd(D.fee)}</b></dd></dl>${payGrid()}</div>
      <label class="row small mt" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" data-cf style="margin-top:4px"> <span>أقر بأن البيانات صحيحة وأن المستمسكات أصلية، وأعلم أن الاتحاد يكشف على المعمل قبل منح الهوية.</span></label>
      <div class="row mt"><button class="btn ghost" data-prev>→ رجوع</button><span class="sp"></span><button class="btn cyan" data-go>ادفع وقدّم الطلب ←</button></div>
      <p class="small" style="text-align:center;margin-top:10px"><button type="button" class="linkbtn muted" data-del>حذف المسودة والبدء من جديد</button></p></div></div>`;
    const pay = wirePay(body);
    body.querySelector('[data-prev]').onclick = () => go(2);
    body.querySelector('[data-del]').onclick = async () => { if (!window.confirm('حذف المسودة ومستمسكاتها؟')) return; try { await rpc(sb, 'union_draft_discard', { p_file: D.id }); ctx.unAp = null; location.hash = '#union'; } catch (e) { toast(cleanErr(e), 'bad'); } };
    body.querySelector('[data-go]').onclick = async () => {
      if (!body.querySelector('[data-cf]').checked) return toast('ضع علامة الإقرار أولاً', 'bad');
      let res;
      const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: profile.phone, purpose: `بدل الانتماء وأجور الكشف ${num(D.fee)} د.ع`,
        verify: async c => { res = await rpc(sb, 'union_member_submit', { p_file: D.id, p: { method: pay.m, otp: c, confirm: true } }); } });
      if (!ok) return;
      ctx.unAp = null;
      await resultScreen({ ok: true, title: 'قُدّم طلب انتسابك', ref: res?.code, msg: 'يدقق قسم العضوية مستمسكاتك، ثم يتصل بك مهندس الاتحاد لزيارة المعمل. تصلك كل خطوة إشعاراً.',
        rows: [['المدفوع', iqd(res?.fee)], ['مرجع الدفع', `<span class="num" dir="ltr">${esc(res?.ref || '')}</span>`]] });
      location.hash = '#union';
    };
  }
  wireWizHead(body, go);
}

// ───────── التجديد ─────────
async function pageRenew(body, ctx, U, cur) {
  const { sb, profile } = ctx;
  const r = await rpc(sb, 'union_renew_start', { p_member: cur.id });
  const q = r.quote || {};
  if (!r.file) {
    body.innerHTML = `${back()}${head('🔄 تجديد الهوية الصناعية')}<div class="mb">${memberCard(cur)}</div>
      <div class="card"><b>${q.early ? 'هويتك نافذة' : 'التجديد غير متاح الآن'}</b><p class="small">${(q.why || []).map(esc).join('<br>')}</p>
      ${q.early ? `<p class="small muted">سنذكّرك قبل انتهائها. يُفتح التجديد في <b class="num">${esc(q.opens_at)}</b>.</p>` : ''}</div>`;
    return;
  }
  const md = RENEW_MODE[q.mode] || RENEW_MODE.auto;
  body.innerHTML = `${back()}${head('🔄 تجديد الهوية الصناعية', `<span class="num">${esc(cur.code)}</span> — ${esc(cur.factory_name)}`)}
    <div class="card mb un-renew ${md[1]}"><div class="row"><b>${esc(md[0])}</b><span class="sp"></span><span class="badge ${md[1]}">${esc(md[0])}</span></div>
      <p class="small" style="margin:6px 0 0">${esc(md[2])}${q.mode === 'auto' ? ` — نافذة حتى <b class="num">${esc(String(q.new_valid).slice(0, 10))}</b>` : ''}.</p>
      ${(q.why || []).length ? `<ul class="small muted" style="margin:6px 0 0;padding-inline-start:18px">${q.why.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}</div>
    <div class="card mb"><h3 style="margin-top:0">المبلغ</h3><dl class="kv sm">
      <dt>بدل الهوية السنوي</dt><dd>${iqd(q.fee_year)}</dd>
      ${q.years > 1 ? `<dt>بدلات السنوات المتأخرة (${num(q.years - 1)})</dt><dd>${iqd(q.arrears)}</dd>` : ''}
      ${q.late_fee ? `<dt>غرامة التأخير (<span class="num">${num(q.late_months)}</span> شهر)</dt><dd>${iqd(q.late_fee)}</dd>` : ''}
      <dt><b>المجموع</b></dt><dd><b>${iqd(q.total)}</b></dd></dl></div>
    ${q.lease_until || q.lease_expired || q.new_lease ? `<div class="card mb un-doc ${q.lease_expired ? '' : 'ok'}"><span class="un-dk">${q.lease_expired ? '⚠️' : '✅'}</span>
      <div style="flex:1"><b>عقد إيجار أرض المعمل</b><div class="small ${q.lease_expired ? 'bad-t' : 'muted'}">${q.new_lease ? `رفعت عقداً جديداً${r.lease?.valid_until ? ` نافذاً حتى <span class="num">${esc(r.lease.valid_until)}</span>` : ''}` : q.lease_expired ? `انتهى في <span class="num">${esc(q.lease_until)}</span> — ارفع الجديد` : `نافذ حتى <span class="num">${esc(q.lease_until)}</span>`}</div></div>
      <button class="btn sm ${q.lease_expired ? 'cyan' : 'ghost'}" data-lease>${q.lease_expired ? '📷 ارفع العقد الجديد' : 'تغيّر العقد؟'}</button></div>` : ''}
    <div class="card mb"><label class="row small" style="gap:8px;align-items:flex-start;flex-wrap:nowrap"><input type="checkbox" data-cf style="margin-top:4px">
      <span>أقر بأن بيانات معملي (العنوان، الصنف، المالك) لم تتغير. <a href="#union/update">تغيّرت؟ حدّثها أولاً</a></span></label>
      <div class="review mt">${payGrid()}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan ${q.lease_expired ? 'is-off' : ''}" data-go>${q.lease_expired ? 'ارفع عقد الإيجار الجديد أولاً' : `ادفع ${num(q.total)} د.ع وجدّد ←`}</button></div></div>`;
  const pay = wirePay(body);
  const lb = body.querySelector('[data-lease]');
  if (lb) lb.onclick = async () => {
    const until = await new Promise(res => {
      const m2 = modal(`<h3>عقد الإيجار الجديد</h3><div class="field"><label>تاريخ انتهائه</label><input class="input" type="date" data-d dir="ltr"></div><div class="row"><span class="sp"></span><button class="btn cyan" data-ok>التالي: صوّره ←</button></div>`, { onClose: () => res(undefined) });
      m2.el.querySelector('[data-ok]').onclick = () => { res(m2.el.querySelector('[data-d]').value || null); m2.close(); };
    });
    if (until === undefined) return;
    const shot = await snapDoc('ind_lease', 'عقد الإيجار الجديد');
    if (!shot) return;
    try { await rpc(sb, 'union_doc_add', { p_file: r.file, p_kind: 'ind_lease', p_data: shot.data, p_meta: { ...(shot.meta || {}), ...(until ? { valid_until: until } : {}) } }); toast('حُفظ العقد', 'ok'); pageRenew(body, ctx, U, cur); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
  body.querySelector('[data-go]').onclick = async () => {
    if (q.lease_expired) return toast('ارفع عقد الإيجار الجديد أولاً', 'bad');
    if (!body.querySelector('[data-cf]').checked) return toast('ضع علامة الإقرار أولاً — أو حدّث بياناتك', 'bad');
    let res;
    const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: profile.phone, purpose: `تجديد الهوية الصناعية ${num(q.total)} د.ع`,
      verify: async c => { res = await rpc(sb, 'union_renew_submit', { p_file: r.file, p: { method: pay.m, otp: c, confirm: true } }); } });
    if (!ok) return;
    await resultScreen(res.mode === 'auto'
      ? { ok: true, title: 'جُدّدت هويتك ✓', msg: 'هويتك نافذة الآن، ورمزها يُظهر التاريخ الجديد لكل من يمسحه.', ref: res.code, rows: [['نافذة حتى', `<b class="num">${esc(res.valid_until)}</b>`], ['مرجع الدفع', `<span class="num" dir="ltr">${esc(res.ref)}</span>`]] }
      : { ok: true, title: 'وصل طلب التجديد للاتحاد', msg: res.mode === 'inspection' ? 'سيتصل بك مهندس الاتحاد لزيارة المعمل، ثم يصدر قرار الأمين العام.' : 'يراجعه قسم العضوية خلال أيام، وتصلك النتيجة إشعاراً.', ref: res.code,
          rows: [['مرجع الدفع', `<span class="num" dir="ltr">${esc(res.ref)}</span>`]] });
    location.hash = '#union';
  };
}

// ───────── تحديث البيانات ─────────
function pageUpdate(body, ctx, U, cur) {
  const { sb } = ctx;
  const f = (k, l, a = '', v = cur[k] ?? '') => `<div class="field"><label>${l}</label><input class="input" data-k="${k}" value="${esc(v)}" ${a}></div>`;
  body.innerHTML = `${back()}${head('✏️ تحديث بيانات المعمل', 'المنتجات والعاملون تُحدَّث فوراً. نقل المعمل أو تغيير اسمه أو صنفه يراجعه الاتحاد.')}
    ${cur.open_update ? '<div class="notice warn mb">لديك طلب تحديث قيد الدراسة — تُحدَّث الآن الحقول الفورية فقط.</div>' : ''}
    <div class="card mb"><h3 style="margin-top:0">⚡ يُحدَّث فوراً</h3>
      ${f('products', 'المنتجات')}<div class="grid g2" style="gap:12px">${f('workers', 'عدد العاملين', 'inputmode="numeric" dir="ltr"')}${f('capacity', 'الطاقة الإنتاجية')}</div>
      ${f('capital', 'رأس المال التقريبي (د.ع)', 'inputmode="numeric" dir="ltr"', cur.capital ? num(cur.capital) : '')}</div>
    <div class="card mb"><h3 style="margin-top:0">🗂 يراجعه الاتحاد</h3>
      ${f('factory_name', 'اسم المعمل')}
      <div class="field"><label>صنف الصناعة</label><select class="input" data-k="category">${Object.entries(IND_CATS).map(([k, t]) => `<option value="${k}" ${cur.category === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
      <div class="grid g2" style="gap:12px"><div class="field"><label>المحافظة</label><select class="input" data-k="governorate">${govOptions(cur.governorate)}</select></div>${f('city', 'المدينة')}</div>
      ${f('address', 'العنوان')}
      <div class="grid g2" style="gap:12px">${f('trade_name_no', 'رقم الاسم التجاري', 'dir="ltr"')}${f('dev_license_no', 'رقم إجازة التنمية', 'dir="ltr"')}</div>
      <div class="field"><label>نوع الإجازة</label><select class="input" data-k="dev_license_kind"><option value="">—</option><option value="under" ${cur.dev_license_kind === 'under' ? 'selected' : ''}>تحت التأسيس</option><option value="complete" ${cur.dev_license_kind === 'complete' ? 'selected' : ''}>كاملة التأسيس</option></select></div>
      <div class="field"><label>ملاحظة للاتحاد (اختياري)</label><input class="input" data-note placeholder="مثال: انتقلنا إلى المنطقة الصناعية الجديدة"></div>
      <p class="small muted">نقل المعمل (المحافظة أو العنوان) يتطلب كشفاً موقعياً على العنوان الجديد. تغيير الاسم أو الصنف يقرره الأمين العام.</p></div>
    <div class="row mb"><span class="sp"></span><button class="btn cyan" data-go>حفظ التحديث ←</button></div>`;
  body.querySelector('[data-go]').onclick = async e => {
    const p = {}; body.querySelectorAll('[data-k]').forEach(i => { p[i.dataset.k] = i.value.trim(); });
    p.note = body.querySelector('[data-note]').value.trim();
    e.target.disabled = true;
    try {
      const r = await rpc(sb, 'union_update_request', { p_member: cur.id, p });
      const ap = (r.applied || []).map(k => FIELD_LABEL[k] || k);
      await resultScreen({ ok: true, title: r.file ? 'وصل طلب التحديث للاتحاد' : 'حُدّثت بياناتك', ref: r.file || '',
        msg: r.file ? (r.needs_insp ? 'نقل المعمل يتطلب كشفاً على العنوان الجديد — سيتصل بك مهندس الاتحاد.' : 'يراجعه قسم العضوية، وتصلك النتيجة إشعاراً.') : 'حُفظت التغييرات في سجلك لدى الاتحاد.',
        rows: ap.length ? [['حُدّث فوراً', esc(ap.join('، '))]] : [] });
      location.hash = '#union';
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── كتاب تأييد عضوية ─────────
const CERT_TO = ['الهيئة العامة للكمارك', 'الهيئة العامة للضرائب', 'وزارة الكهرباء — دائرة التوزيع', 'وزارة النفط — حصة الوقود', 'المديرية العامة للتنمية الصناعية', 'مصرف'];
const CERT_FOR = ['إعفاء كمركي للمكائن والمواد الأولية', 'تسعيرة الكهرباء الصناعية', 'تخصيص حصة وقود للمعمل', 'فتح حساب أو تسهيلات مصرفية', 'تأييد ممارسة النشاط الصناعي'];
function pageCert(body, ctx, U, cur) {
  const { sb, profile } = ctx;
  if (!cur.valid) {
    body.innerHTML = `${back()}${head('📄 كتاب تأييد عضوية')}<div class="card"><b>هويتك غير نافذة</b><p class="small">جدّد هويتك أولاً ثم اطلب الكتاب فوراً.</p><a class="btn cyan" href="#union/renew">جدّد هويتي ←</a></div>`;
    return;
  }
  const chips = (arr, k) => `<div class="chips" data-ch="${k}">${arr.map(x => `<button type="button" class="chip" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div>`;
  body.innerHTML = `${back()}${head('📄 كتاب تأييد عضوية', 'يصدر فوراً باسم الاتحاد، مختوماً ببصمة رقمية ورمز QR تتحقق منه الجهة دون مراجعة الاتحاد.')}
    <div class="card mb"><div class="field"><label>إلى أي جهة؟</label>${chips(CERT_TO, 'to')}<input class="input mt" data-to placeholder="أو اكتب اسم الجهة"></div>
      <div class="field"><label>لأي غرض؟</label>${chips(CERT_FOR, 'for')}<input class="input mt" data-for placeholder="أو اكتب الغرض"></div>
      <div class="review"><dl class="kv"><dt>أجور الكتاب</dt><dd><b>${iqd(U.fees?.cert)}</b></dd><dt>مدة النفاذ</dt><dd><span class="num">${num(U.fees?.cert_days)}</span> يوماً (لا تتجاوز نفاذ هويتك)</dd></dl>${payGrid()}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>ادفع وأصدر الكتاب ←</button></div></div>`;
  body.querySelectorAll('[data-ch]').forEach(g => g.querySelectorAll('[data-v]').forEach(b => b.onclick = () => {
    g.querySelectorAll('[data-v]').forEach(z => z.classList.toggle('on', z === b));
    const inp = body.querySelector(g.dataset.ch === 'to' ? '[data-to]' : '[data-for]'); inp.value = b.dataset.v === 'مصرف' ? 'مصرف ' : b.dataset.v; if (b.dataset.v === 'مصرف') inp.focus();
  }));
  const pay = wirePay(body);
  body.querySelector('[data-go]').onclick = async () => {
    const to = body.querySelector('[data-to]').value.trim(), purpose = body.querySelector('[data-for]').value.trim();
    if (to.length < 3) return toast('اختر الجهة أو اكتبها', 'bad');
    if (purpose.length < 3) return toast('اختر الغرض أو اكتبه', 'bad');
    let res;
    const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: profile.phone, purpose: `كتاب تأييد عضوية ${num(U.fees?.cert)} د.ع`,
      verify: async c => { res = await rpc(sb, 'union_cert_request', { p_member: cur.id, p: { to, purpose, method: pay.m, otp: c } }); } });
    if (!ok) return;
    toast(`صدر الكتاب ${res.letter.no}`, 'ok');
    location.hash = '#union';
    setTimeout(() => openLetter(res.letter), 300);
  };
}

// ───────── بدل ضائع أو تالف ─────────
function pageReplace(body, ctx, U, cur) {
  const { sb, profile } = ctx;
  body.innerHTML = `${back()}${head('🪪 بدل هوية ضائعة أو تالفة', 'تصدر نسخة جديدة برمز تحقق جديد فوراً، ويُبطَل رمز النسخة القديمة — من يمسحه يرى أنها ملغاة.')}
    <div class="mb">${memberCard(cur)}</div>
    <div class="card"><div class="field"><label>السبب</label><div class="seg" data-rs><button type="button" data-v="lost" class="on">ضاعت</button><button type="button" data-v="stolen">سُرقت</button><button type="button" data-v="damaged">تلفت</button></div></div>
      <div class="review"><dl class="kv"><dt>الأجور</dt><dd><b>${iqd(U.fees?.replace)}</b></dd></dl>${payGrid()}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>ادفع وأصدر النسخة الجديدة ←</button></div></div>`;
  let reason = 'lost';
  body.querySelectorAll('[data-rs] button').forEach(b => b.onclick = () => { reason = b.dataset.v; body.querySelectorAll('[data-rs] button').forEach(z => z.classList.toggle('on', z === b)); });
  const pay = wirePay(body);
  body.querySelector('[data-go]').onclick = async () => {
    let res;
    const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[pay.m]}`, phone: profile.phone, purpose: `بدل الهوية ${num(U.fees?.replace)} د.ع`,
      verify: async c => { res = await rpc(sb, 'union_card_replace', { p_member: cur.id, p: { reason, method: pay.m, otp: c } }); } });
    if (!ok) return;
    await resultScreen({ ok: true, title: 'صدرت النسخة الجديدة', msg: 'هويتك في هذه الصفحة هي النسخة النافذة. الرمز القديم لم يعد صالحاً.', rows: [['النسخة', `<b class="num">${res.version}</b>`]] });
    location.hash = '#union';
  };
}

// ───────── مستمسكاتي ─────────
function pageDocs(body, ctx, U, cur) {
  const docs = cur.docs || [];
  body.innerHTML = `${back()}${head('🗂 مستمسكاتي لدى الاتحاد', 'آخر نسخة من كل مستند رفعته. تُستعمل في كل معاملاتك فلا ترفعها مرة أخرى إلا إن تغيّرت.')}
    <div class="card">${docs.length ? docs.map(d => `<div class="un-doc ${d.expired ? '' : 'ok'}"><span class="un-dk">${d.expired ? '⚠️' : '📎'}</span>
      <div style="flex:1"><b>${esc(d.label)}</b><div class="small muted">رُفع ${dt(d.at)}${d.valid_until ? ` · ${d.expired ? '<span class="bad-t">انتهى</span>' : 'نافذ حتى'} <span class="num">${esc(d.valid_until)}</span>` : ''}</div></div>
      <button class="btn ghost sm" data-see="${d.id}">عرض</button></div>`).join('') : '<p class="muted">لا مستمسكات محفوظة بعد.</p>'}
      ${docs.some(d => d.expired && d.kind === 'ind_lease') ? '<p class="small">عقد الإيجار المنتهي يُستبدل عند تجديد الهوية: <a href="#union/renew">جدّد هويتي</a>.</p>' : ''}</div>`;
  body.querySelectorAll('[data-see]').forEach(b => b.onclick = () => viewDoc(ctx.sb, b.dataset.see));
}

// ───────── إلغاء الانتماء ─────────
function pageCancel(body, ctx, U, cur) {
  const { sb } = ctx;
  body.innerHTML = `${back()}${head('🚪 إلغاء الانتماء للاتحاد')}
    <div class="card"><p class="small" style="margin-top:0">يُلغى انتماؤك بقرار الأمين العام، وتصلك «براءة ذمة» برمز تحقق، وتصير هويتك ${esc(cur.code)} غير نافذة. لا يُلغى الانتماء ولديك قرض صناعي قائم.</p>
      <div class="field"><label>سبب الإلغاء</label><textarea class="input" rows="3" data-n placeholder="مثال: أغلقت المعمل نهائياً"></textarea></div>
      <div class="row"><a class="btn ghost" href="#union">تراجع</a><span class="sp"></span><button class="btn bad" data-go>أرسل طلب الإلغاء</button></div></div>`;
  body.querySelector('[data-go]').onclick = async e => {
    if (!window.confirm('تأكيد طلب إلغاء الانتماء؟')) return;
    e.target.disabled = true;
    try { const r = await rpc(sb, 'union_cancel_request', { p_member: cur.id, p_note: body.querySelector('[data-n]').value.trim() }); toast(`أُرسل الطلب ${r.code}`, 'ok'); location.hash = '#union'; }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}
