// الجلسة 47: برامج المصرف — الإدارة العليا تطلق البرامج وتحدد ثوابتها ومتغيراتها وتديرها،
// وتنضم إلى مبادرتي المنصة (الطاقة الشمسية، البيطري) أو تنسحب منهما. باقي موظفي المصرف يطّلعون فقط.
import { esc, num, iqd, dt, badge, rpc, toast, cleanErr, modal, GOVS, TRADE_KINDS, TRADE_DOCS, TRADE_FIXED_DOCS } from './core.js';

const ST = { draft: ['مسودة', 'muted'], active: ['مُطلق — يستقبل الطلبات', 'ok'], paused: ['متوقف مؤقتاً', 'warn'], closed: ['مغلق', 'bad'] };
const G = { single_salary: 'كفيل موظف واحد', multi_salary: 'كفيلان موظفان أو أكثر', mortgage: 'رهن عقار', gold: 'رهن ذهب' };
const DISB = { supplier: 'للموردين بفواتير', account: 'لحساب المقترض', mixed: 'للموردين بفواتير والباقي لحساب المقترض' };
const FUND = { bank: 'أموال المصرف', initiative: 'مبادرة البنك المركزي', eu: 'تمويل الاتحاد الأوروبي', other: 'مصدر آخر' };
const INIT = [['solar', 'مبادرة الطاقة الشمسية', 'تمويل منظومات الطاقة الشمسية للأفراد والزراعة والصناعة'], ['vet', 'مبادرة الأطباء البيطريين', 'تمويل مختبرات وعيادات ومعامل أعضاء النقابة']];
const mlnT = n => `${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })} مليون`;

export async function bankPrograms(ctx, body, apps) {
  const { sb, profile, org } = ctx;
  const md = profile.role === 'bank_md';
  body.innerHTML = '<div class="spin"></div>';
  const [progs, log, o] = await Promise.all([
    sb.from('bank_programs').select('*').eq('bank_id', org.id).order('created_at').then(r => r.data || []),
    sb.from('bank_program_log').select('*').eq('bank_id', org.id).order('created_at', { ascending: false }).limit(200).then(r => r.data || []),
    sb.from('orgs').select('meta').eq('id', org.id).maybeSingle().then(r => r.data),
  ]);
  const meta = o?.meta || org.meta || {}, inits = Array.isArray(meta.programs) ? meta.programs : ['solar', 'vet'];
  const used = id => apps.filter(a => a.program_id === id && a.stage >= 6 && !['rejected', 'cancelled'].includes(a.status));
  const reload = () => bankPrograms(ctx, body, apps);
  body.innerHTML = `
    <div class="notice"><span>🏷</span><span class="small"><b>برامج المصرف تطلقها الإدارة العليا وتديرها:</b> تحدد لكل برنامج متغيراته (المبالغ والمدد والنسب والسقف) وثوابته (الضمانات والمستندات وشروط الأهلية)، ثم تطلقه فيظهر للمقترضين فوراً. التعديل يسري على الطلبات الجديدة فقط، والإيقاف والإغلاق لا يمسّان الطلبات القائمة.${md ? '' : ' <b>أنت تطّلع فقط</b> — الإدارة والإطلاق للإدارة العليا.'}</span></div>
    <div class="card mb"><h3>مبادرات المنصة</h3><div class="grid g2" style="gap:10px">${INIT.map(([k, t, d]) => { const on = inits.includes(k);
      return `<div class="card soft" style="margin:0"><div class="row"><b>${t}</b><span class="sp"></span>${badge(on ? ['منضمّ', 'ok'] : ['غير منضمّ', 'muted'])}</div>
        <p class="small muted" style="margin:4px 0 8px">${d} — شروطها من البنك المركزي.</p>
        ${md ? `<button type="button" class="btn sm ${on ? 'ghost' : 'cyan'}" data-init="${k}" data-on="${on ? 0 : 1}">${on ? 'الانسحاب من المبادرة' : 'الانضمام إلى المبادرة'}</button>` : ''}</div>`; }).join('')}</div></div>
    <div class="row mb"><h3 style="margin:0">برامج المصرف <span class="badge muted num">${progs.length}</span></h3><span class="sp"></span>${md ? '<button type="button" class="btn cyan" data-new>＋ برنامج جديد</button>' : ''}</div>
    ${progs.length ? `<div class="grid g2" style="gap:12px">${progs.map(p => { const pp = p.params || {}, u = used(p.id), uAmt = u.reduce((t, a) => t + Number(a.amount || 0), 0);
      const bud = Number(pp.budget || 0), pc = bud ? Math.min(100, Math.round(uAmt * 100 / bud)) : 0;
      return `<div class="card" style="margin:0"><div class="row"><span class="badge info">${esc(TRADE_KINDS[p.kind])}</span><span class="sp"></span>${badge(ST[p.status])}</div>
        <h3 style="margin:8px 0 2px">${esc(p.name)}</h3><div class="small muted"><span class="num">${esc(p.code)}</span> · الإصدار <span class="num">${p.version}</span>${p.launched_at ? ` · أُطلق ${dt(p.launched_at)}` : ''}</div>
        ${p.summary ? `<p class="small" style="margin:6px 0">${esc(p.summary)}</p>` : ''}
        <dl class="kv small"><dt>المبلغ</dt><dd>${mlnT(pp.min_amount)} — ${mlnT(pp.max_amount)} د.ع</dd><dt>المدة</dt><dd><span class="num">${pp.min_term}</span>–<span class="num">${pp.max_term}</span> شهراً، سماح حتى <span class="num">${pp.grace_max}</span></dd>
          <dt>الفائدة / العمولة</dt><dd><span class="num">${pp.rate}%</span> سنوياً · عمولة <span class="num">${pp.commission_pct}%</span> · رسم الملف ${iqd(pp.file_fee)}</dd>
          <dt>الضمانات</dt><dd>${(pp.guarantees || []).map(g => esc(G[g])).join('، ')}</dd><dt>الصرف</dt><dd>${DISB[pp.disburse] || ''} · ${FUND[pp.funding] || ''}</dd>
          <dt>الطلبات</dt><dd><span class="num">${u.length}</span> مرسلة · ${iqd(uAmt)}${bud ? ` من سقف ${mlnT(bud)} (<span class="num">${pc}%</span>)` : ' · بلا سقف'}</dd></dl>
        ${bud ? `<div class="prog"><i style="width:${pc}%"></i></div>` : ''}
        <div class="row mt" style="gap:6px;flex-wrap:wrap">
          ${md && p.status !== 'closed' ? `<button type="button" class="btn ghost sm" data-edit="${p.id}">تعديل</button>` : ''}
          ${md && ['draft', 'paused'].includes(p.status) ? `<button type="button" class="btn ok sm" data-st="${p.id}" data-to="active">${p.status === 'draft' ? '🚀 إطلاق' : 'إعادة تشغيل'}</button>` : ''}
          ${md && p.status === 'active' ? `<button type="button" class="btn warn sm" data-st="${p.id}" data-to="paused">إيقاف مؤقت</button>` : ''}
          ${md && ['active', 'paused'].includes(p.status) ? `<button type="button" class="btn bad sm" data-st="${p.id}" data-to="closed">إغلاق</button>` : ''}
          <span class="sp"></span><button type="button" class="linkbtn small" data-log="${p.id}">السجل</button></div></div>`; }).join('')}</div>`
      : `<div class="card empty">لا برامج بعد.${md ? ' اضغط «＋ برنامج جديد» لتصميم أول برنامج.' : ''}</div>`}`;
  body.querySelectorAll('[data-init]').forEach(b => b.onclick = async () => {
    b.disabled = true;
    try { await rpc(sb, 'bank_initiative_join', { p_kind: b.dataset.init, p_on: b.dataset.on === '1' }); toast('حُفظ', 'ok'); reload(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
  const nb = body.querySelector('[data-new]'); if (nb) nb.onclick = () => editor(ctx, null, reload);
  body.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editor(ctx, progs.find(p => p.id === b.dataset.edit), reload));
  body.querySelectorAll('[data-st]').forEach(b => b.onclick = () => statusDlg(ctx, progs.find(p => p.id === b.dataset.st), b.dataset.to, reload));
  body.querySelectorAll('[data-log]').forEach(b => b.onclick = () => {
    const p = progs.find(x => x.id === b.dataset.log), l = log.filter(x => x.program_id === p.id);
    modal(`<h3>سجل البرنامج ${esc(p.name)}</h3>${l.length ? `<ul class="timeline">${l.map(x => `<li><div><b>${esc(x.action)}</b>${x.note ? ` — ${esc(x.note)}` : ''}</div><div class="t">${esc(x.actor_name || '')} · ${dt(x.created_at)}</div></li>`).join('')}</ul>` : '<p class="muted">لا شيء بعد.</p>'}`);
  });
}

function statusDlg(ctx, p, to, reload) {
  const t = { active: p.status === 'draft' ? 'إطلاق البرنامج' : 'إعادة تشغيل البرنامج', paused: 'إيقاف البرنامج مؤقتاً', closed: 'إغلاق البرنامج نهائياً' }[to];
  const needNote = to !== 'active';
  const m = modal(`<h3>${t}</h3><p class="muted">${to === 'active' ? 'يظهر البرنامج للمقترضين فوراً ويبدأ استقبال الطلبات.' : to === 'paused' ? 'يختفي البرنامج عن المقترضين الجدد. الطلبات القائمة تستمر.' : 'لا يمكن إعادة تشغيله بعد الإغلاق. الطلبات القائمة تستمر.'}</p>
    ${needNote ? '<div class="field"><label>السبب ★</label><input class="input" data-n></div>' : ''}
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn ${to === 'active' ? 'ok' : to === 'paused' ? 'warn' : 'bad'}" data-s>${t}</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const n = m.el.querySelector('[data-n]')?.value.trim() || null;
    if (needNote && !n) return toast('اكتب السبب', 'bad');
    e.target.disabled = true;
    try { await rpc(ctx.sb, 'bank_program_status', { p_id: p.id, p_status: to, p_note: n }); m.close(); toast(t + ' — تم', 'ok'); reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// محرر البرنامج: النوع والاسم، المتغيرات، الثوابت
function editor(ctx, p, reload) {
  const kind0 = p?.kind || 'export';
  const pp = p?.params || { min_amount: 5000000, max_amount: 100000000, min_term: 12, max_term: 60, grace_max: 3, rate: 6, commission_pct: 1, file_fee: 50000, budget: 0,
    min_activity_months: 6, disburse: 'supplier', funding: kind0 === 'export' ? 'eu' : 'bank', guarantees: ['single_salary', 'multi_salary', 'mortgage', 'gold'], docs: [], governorates: [], purposes: [], conditions: '' };
  const S = { kind: kind0 };
  const fx = () => TRADE_FIXED_DOCS[S.kind] || [];
  const numIn = (k, l, hint = '') => `<div class="field"><label>${l}</label><input class="input num" dir="ltr" inputmode="decimal" data-p="${k}" value="${esc(pp[k] ?? '')}">${hint ? `<small class="muted">${hint}</small>` : ''}</div>`;
  const m = modal(`<h3>${p ? `تعديل البرنامج ${esc(p.code)}` : 'برنامج جديد'}</h3>
    ${p && p.status !== 'draft' ? '<div class="notice warn"><span>ℹ</span><span class="small">البرنامج مُطلق — التعديل ينشئ إصداراً جديداً يسري على الطلبات الجديدة فقط.</span></div>' : ''}
    <div class="card soft mb"><h3>1. النوع والاسم</h3>
      ${p ? `<p><span class="badge info">${esc(TRADE_KINDS[p.kind])}</span></p>` : `<div class="seg" data-kinds>${Object.entries(TRADE_KINDS).map(([k, t]) => `<button type="button" data-k="${k}" class="${k === S.kind ? 'on' : ''}">${t}</button>`).join('')}</div>`}
      <div class="field"><label>اسم البرنامج كما يراه المقترض ★</label><input class="input" data-name value="${esc(p?.name || '')}" placeholder="مثال: تمويل المصدّرين — ما قبل الشحن"></div>
      <div class="field"><label>وصف قصير</label><textarea class="input" rows="2" data-sum>${esc(p?.summary || '')}</textarea></div></div>
    <div class="card soft mb"><h3>2. المتغيرات</h3><div class="grid g3" style="gap:10px">
      ${numIn('min_amount', 'أدنى مبلغ (د.ع)')}${numIn('max_amount', 'أعلى مبلغ (د.ع)')}${numIn('budget', 'سقف البرنامج الكلي (د.ع)', '0 = بلا سقف')}
      ${numIn('min_term', 'أدنى مدة (شهر)')}${numIn('max_term', 'أعلى مدة (شهر)')}${numIn('grace_max', 'أعلى سماح (شهر)')}
      ${numIn('rate', 'الفائدة أو الربح السنوي %')}${numIn('commission_pct', 'عمولة المصرف %')}${numIn('file_fee', 'رسم دراسة الملف (د.ع)')}</div></div>
    <div class="card soft mb"><h3>3. الثوابت — الأهلية والضمان والمستندات</h3>
      <div class="field"><label>الضمانات المقبولة ★</label><div class="adm-sup">${Object.entries(G).map(([k, t]) => `<label class="${(pp.guarantees || []).includes(k) ? 'on' : ''}"><input type="checkbox" data-g value="${k}" ${(pp.guarantees || []).includes(k) ? 'checked' : ''}>${t}</label>`).join('')}</div></div>
      <div class="field"><label>المستندات المطلوبة من المقترض</label><div class="adm-sup" data-docs></div><small class="muted">المعلَّمة 🔒 ثابتة لهذا النوع بحكم الضوابط ولا تُزال.</small></div>
      <div class="grid g2" style="gap:10px">
        ${numIn('min_activity_months', 'أدنى مدة لممارسة النشاط (شهر)', '0 = لا يُشترط')}
        <div class="field"><label>طريقة الصرف</label><select class="input" data-disb>${Object.entries(DISB).map(([k, t]) => `<option value="${k}" ${pp.disburse === k ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
        <div class="field"><label>مصدر التمويل</label><select class="input" data-fund>${Object.entries(FUND).map(([k, t]) => `<option value="${k}" ${pp.funding === k ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
        <div class="field"><label>أغراض التمويل (كل غرض في سطر — فارغ = يكتبه المقترض)</label><textarea class="input" rows="3" data-pur>${esc((pp.purposes || []).join('\n'))}</textarea></div></div>
      <div class="field"><label>المحافظات المشمولة (بلا اختيار = كل المحافظات)</label><div class="adm-sup">${GOVS.map(g => `<label class="${(pp.governorates || []).includes(g[0]) ? 'on' : ''}"><input type="checkbox" data-gov value="${esc(g[0])}" ${(pp.governorates || []).includes(g[0]) ? 'checked' : ''}>${esc(g[0])}</label>`).join('')}</div></div>
      <div class="field"><label>شروط أخرى يقرؤها المقترض قبل التقديم</label><textarea class="input" rows="2" data-cond>${esc(pp.conditions || '')}</textarea></div></div>
    ${p ? '<div class="field"><label>ملاحظة التعديل (تُحفظ في السجل)</label><input class="input" data-note></div>' : ''}
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn cyan" data-s>${p ? 'حفظ التعديل' : 'حفظ كمسودة'}</button></div>`, { wide: true });
  const el = m.el;
  const paintDocs = () => {
    const sel = new Set([...(pp.docs || []), ...[...el.querySelectorAll('[data-d]:checked')].map(i => i.value)]);
    el.querySelector('[data-docs]').innerHTML = Object.entries(TRADE_DOCS).map(([k, t]) => { const fixed = fx().includes(k), on = fixed || sel.has(k);
      return `<label class="${on ? 'on' : ''}"><input type="checkbox" data-d value="${k}" ${on ? 'checked' : ''} ${fixed ? 'disabled' : ''}>${fixed ? '🔒 ' : ''}${esc(t)}</label>`; }).join('');
    wireChk();
  };
  const wireChk = () => el.querySelectorAll('.adm-sup input').forEach(i => i.onchange = () => i.closest('label').classList.toggle('on', i.checked));
  paintDocs();
  el.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { S.kind = b.dataset.k; el.querySelectorAll('[data-k]').forEach(x => x.classList.toggle('on', x === b)); paintDocs(); });
  el.querySelector('[data-x]').onclick = m.close;
  el.querySelector('[data-s]').onclick = async e => {
    const params = {};
    el.querySelectorAll('[data-p]').forEach(i => { params[i.dataset.p] = String(i.value).replace(/[,٬\s]/g, '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)); });
    params.guarantees = [...el.querySelectorAll('[data-g]:checked')].map(i => i.value);
    params.docs = [...el.querySelectorAll('[data-d]:checked')].map(i => i.value).filter(k => !fx().includes(k));
    params.governorates = [...el.querySelectorAll('[data-gov]:checked')].map(i => i.value);
    params.purposes = el.querySelector('[data-pur]').value.split('\n').map(x => x.trim()).filter(Boolean);
    params.disburse = el.querySelector('[data-disb]').value; params.funding = el.querySelector('[data-fund]').value; params.conditions = el.querySelector('[data-cond]').value.trim();
    const name = el.querySelector('[data-name]').value.trim();
    if (name.length < 4) return toast('اكتب اسم البرنامج', 'bad');
    if (!params.guarantees.length) return toast('اختر ضماناً واحداً على الأقل', 'bad');
    e.target.disabled = true;
    try {
      await rpc(ctx.sb, 'bank_program_save', { p_id: p?.id || null, p: { kind: S.kind, name, summary: el.querySelector('[data-sum]').value.trim(), params, note: el.querySelector('[data-note]')?.value.trim() || null } });
      m.close(); toast(p ? 'حُفظ التعديل' : 'حُفظ البرنامج كمسودة — اضغط «إطلاق» حين يكون جاهزاً', 'ok'); reload();
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}
