// خادم «ألواح» — بلا حزم خارجية. يخدم الملفات الثابتة ويوجّه روابط البوابات.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://chjeqtjyywomtcenizxp.supabase.co';
const OCR_URL = process.env.OCR_URL || '';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_yewCPqcDPAFW8RPqeJgrow_QTx57Ixy';
// الجلسة 15: التوقيع الإلكتروني — السر المشترك مع قاعدة البيانات يوضع في Render فقط (ESIGN_DB_SECRET)
const esignHandle = require('./esign.js')({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET: process.env.ESIGN_DB_SECRET || '', PUBLIC_URL: process.env.PUBLIC_URL || '' });
// الجلسة 23: الرسائل النصية الحقيقية — المزوّد ومفاتيحه في Render فقط (انظر sms.js)
const SMS = require('./sms.js')({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET: process.env.ESIGN_DB_SECRET || '', PUBLIC_URL: process.env.PUBLIC_URL || 'https://alwah-platform.onrender.com' });

// ── تحديث قاعدة البيانات تلقائياً عند التشغيل (دون نسخ أو لصق) ──
// يعمل فقط إن وُضع في Render المتغير SUPABASE_ACCESS_TOKEN (رمز وصول من حساب Supabase).
// يتحقق أولاً: إن كان التحديث مطبقاً لا يفعل شيئاً. يمكن حذف الرمز من Render بعد النجاح.
const SB_TOKEN = process.env.SUPABASE_ACCESS_TOKEN || '';
const SB_REF = process.env.SUPABASE_PROJECT_REF || (SUPABASE_URL.match(/https:\/\/([a-z0-9]+)\.supabase/) || [])[1] || '';
const MIGRATIONS = [
  { name: 'الجلسة 4: آلية التمويل والأداء والدفع والمستندات والتواقيع', file: 'supabase/session4_apply.sql', done: "select to_regclass('public.event_signatures') is not null as done" },
  { name: 'الجلسة 5: عمولة كل مصرف، طرق الدفع، وكالة المالك، ودور البنك المركزي الرقابي', file: 'supabase/session5_apply.sql', done: "select exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'bank_terms' and column_name = 'commission_pct') and position('bank_choice' in pg_get_functiondef(coalesce(to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)'), 'public.citizen_step(uuid,integer,jsonb)'::regprocedure))) > 0 and position('''poa''' in pg_get_functiondef('public.set_property_ownership(uuid,jsonb)'::regprocedure)) > 0 and to_regprocedure('public.cbi_oversight_note(uuid,text)') is not null as done" },
  { name: 'فك ارتباط البطاقة الوطنية بالحساب التجريبي القديم (بطلب صاحبها)', file: 'supabase/session5_release_id.sql', done: "select exists (select 1 from profiles where username like 'archived-%') as done" },
  { name: 'الجلسة 6: مبادرة تمويل مشاريع الأطباء البيطريين — النقابة ودائرة البيطرة والدفعات', file: 'supabase/session6_apply.sql', done: "select to_regclass('public.vet_tranches') is not null and to_regprocedure('public.cbi_set_setting(text,numeric,text)') is not null and to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)') is not null and exists (select 1 from profiles where username = 'vetdept1') as done" },
  { name: 'الجلسة 7: سجل مراجعة قراءة البطاقة الوطنية', file: 'supabase/session7_apply.sql', done: "select exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'id_review') and position('id_review' in pg_get_functiondef('public.update_my_id_card(jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 9: ربط المواطن بالمصرف المختار، رقم الحساب عند فتحه، ولوحة مشغّل النظام', file: 'supabase/session9_apply.sql', done: "select to_regprocedure('public.admin_app_action(uuid,text,text)') is not null and to_regprocedure('public.start_application_bank(uuid,uuid,integer,text,text,numeric,numeric)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_open_account') and exists (select 1 from profiles where username = 'superadmin') as done" },
  { name: 'الجلسة 11: إدارة الموظفين داخل كل جهة — مدير الجهة والفرع والقسم، توزيع المهام والبديل، «حسابي» وإجبار تغيير كلمة المرور', file: 'supabase/session11_apply.sql', done: "select to_regclass('public.stage_assignments') is not null and to_regprocedure('public.team_set_assignment(integer,uuid,uuid,uuid)') is not null and to_regprocedure('public.update_my_staff_phone(text,text)') is not null and position('_assignment_ok' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and to_regprocedure('public.my_account()') is not null as done" },
  { name: 'الجلسة 12: تأكيد مكتوب من كل موظف عند الإنجاز، والإرجاع الموجَّه بالنواقص وأولوية «مستعجل»', file: 'supabase/session12_apply.sql', done: "select to_regprocedure('public.stage_decision(uuid,text,text,text,integer)') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'applications' and column_name = 'returned_from') and position('alwah.confirmed' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 13: رقم السلفة التجميعية فريد على مستوى المنصة', file: 'supabase/session13_apply.sql', done: "select exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = 'batch_create' and routine_definition like '%pg_advisory_xact_lock%') as done" },
  { name: 'الجلسة 14: كتاب الرهن وصورة إشارة الحجز إلزاميان، ومفاتحة المصرف الموطَّن لراتب الكفيل لتفعيل الاستقطاع المباشر', file: 'supabase/session14_apply.sql', done: "select to_regclass('public.salary_referrals') is not null and to_regprocedure('public.registry_annotate(uuid,jsonb)') is not null and to_regprocedure('public.payroll_inbox()') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'mortgage_referrals' and column_name = 'mark_doc') and exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = 'advance_application' and routine_definition like '%salary_referrals%') as done" },
  { name: 'الجلسة 15: التوقيع الإلكتروني لعقد التمويل والكمبيالة من «بوابة المقترض» — التحقق من الوجه وبصمة الجهاز', file: 'supabase/session15_apply.sql', done: "select to_regclass('public.esign_requests') is not null and to_regprocedure('public.esign_apply(text,uuid,text,jsonb,text)') is not null and position('esign_requests' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and position('kyc_face' in pg_get_functiondef('public.add_document(uuid,text,text,text,jsonb,uuid)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 16: غرض التمويل ومستنداته، قائمة التدقيق في الاستقبال والرفض الفوري لإكمال النواقص، و«بوابة الخبراء» لدراسات الجدوى', file: 'supabase/session16_apply.sql', done: "select to_regclass('public.expert_referrals') is not null and to_regprocedure('public.expert_action(uuid,text,jsonb)') is not null and to_regprocedure('public.intake_return(uuid,text)') is not null and position('_intake_gate' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and position('rejdoc' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and exists (select 1 from profiles where username = 'exp.ind') as done" },
  { name: 'الجلسة 17: توثيق التركيب بالـGPS والصورة والفيديو، عنوان المنظومة ونوع الموقع، مهلة التنفيذ، حسابات النزاهة والمخاطبات السرية، إعلان المبادرات والإشعارات، والتحليل', file: 'supabase/session17_apply.sql', done: "select to_regclass('public.oversight_letters') is not null and to_regclass('public.initiatives') is not null and to_regclass('public.notifications') is not null and to_regprocedure('public.install_proof(uuid,text,text,jsonb)') is not null and to_regprocedure('public.set_app_site(uuid,jsonb)') is not null and to_regprocedure('public.exec_extend(uuid,integer,text)') is not null and to_regprocedure('public.cbi_analytics()') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'applications' and column_name = 'install_geo') and exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = '_intake_items' and routine_definition like '%site_geo%') as done" },
  { name: 'الجلسة 18: الصرف للمورد مع استقطاع عمولة المنصة، جدول الأقساط ومتابعة التحصيل، والاطلاع الرقابي للبنك المركزي والنزاهة', file: 'supabase/session18_apply.sql', done: "select to_regclass('public.disbursements') is not null and to_regclass('public.installments') is not null and to_regprocedure('public.repay_info(uuid)') is not null and to_regprocedure('public.installment_collect(uuid,integer,text)') is not null and to_regprocedure('public.oversight_repayments()') is not null and to_regprocedure('public.admin_revenue()') is not null and to_regprocedure('public._implied_rate(numeric,numeric,integer)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_repay_hooks') and exists (select 1 from settings where key = 'supplier_commission_pct') as done" },
  { name: 'الجلسة 19: استكمال عنوان المنظومة بالـGPS من المقترض للطلبات القديمة التي وصلت المصرف بلا عنوان', file: 'supabase/session19_apply.sql', done: "select position('site_gps' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 22: تبسيط رحلة المقترض — المحافظة من الموقع، البدء دون الموقع، النواقص من الهاتف، رابط الموقع ورابط الكفيل، الدبوس اليدوي واستلام جدول الأقساط (خياران للمصرف)', file: 'supabase/session22_apply.sql', done: "select to_regclass('public.app_links') is not null and to_regclass('public.app_fix_requests') is not null and to_regprocedure('public.schedule_ack(uuid,text)') is not null and to_regprocedure('public.site_confirm(uuid,jsonb)') is not null and to_regprocedure('public.bank_set_option(text,boolean)') is not null and position('_g_link_ok' in pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure)) > 0 and position('app_fix_requests' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and position('_put_site_geo' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 23: رسائل SMS حقيقية — رمز التحقق يصل هاتف المعني (المقترض والكفيل ومالك العقار)، وإشعار المقترض برسالة بكل ما يُطلب منه', file: 'supabase/session23_apply.sql', done: "select to_regclass('private.sms_outbox') is not null and to_regprocedure('public.otp_check(text,text)') is not null and to_regprocedure('public._otp_ok(text,text)') is not null and position('_otp_ok(g->>''otp'', ph)' in pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure)) > 0 and position('_otp_ok(p_otp, l.data->>''phone'')' in pg_get_functiondef('public.link_guarantor_consent(text,text,boolean)'::regprocedure)) > 0 and position('_sms_live' in pg_get_functiondef('public.admin_set_setting(text,numeric)'::regprocedure)) > 0 and exists (select 1 from pg_trigger where tgname = 'trg_borrower_asks') and exists (select 1 from pg_trigger where tgname = 'trg_sms_notify') as done" },
  { name: 'الجلسة 24: إجراء واضح للمقترض في مرحلة توقيع العقد — طلب رابط جديد أو التوقيع في الفرع، وإشعار الفرع فور التوقيع', file: 'supabase/session24_apply.sql', done: "select to_regprocedure('public.esign_borrower_ask(uuid,text)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_esign_done_notify') as done" },
  { name: 'الجلسة 25: مكاتب ومراكز دراسات الجدوى المعتمدة من البنك المركزي (اختيار أو كتابة الاسم في أول الطلب، ومسار ميسّر لدى الخبير)، ومشروع التصدير', file: 'supabase/session25_apply.sql', done: "select to_regclass('public.feasibility_offices') is not null and to_regprocedure('public.set_fz_office(uuid,jsonb)') is not null and to_regprocedure('public.admin_save_fz_office(jsonb)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_fz_ref_sla') and position('fz_office' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and position('''export''' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
];
const MIG = { state: SB_TOKEN ? 'pending' : 'no_token', log: [] };
async function sbQuery(sql) {
  const r = await fetch(`https://api.supabase.com/v1/projects/${SB_REF}/database/query`, {
    method: 'POST', headers: { Authorization: `Bearer ${SB_TOKEN}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ query: sql }),
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${t.slice(0, 600)}`);
  try { return JSON.parse(t); } catch { return t; }
}
async function runMigrations() {
  if (!SB_TOKEN || !SB_REF) return;
  MIG.state = 'running';
  try {
    for (const m of MIGRATIONS) {
      const chk = await sbQuery(m.done);
      if (Array.isArray(chk) && chk[0] && chk[0].done) { MIG.log.push(`✓ ${m.name}: مطبق مسبقاً`); continue; }
      MIG.log.push(`… ${m.name}: جارِ التطبيق`);
      await sbQuery(fs.readFileSync(path.join(__dirname, m.file), 'utf8'));
      const ok = await sbQuery(m.done);
      if (!(Array.isArray(ok) && ok[0] && ok[0].done)) throw new Error('انتهى التنفيذ دون أن يظهر أثر التحديث');
      MIG.log.push(`✓ ${m.name}: طُبّق بنجاح`);
    }
    MIG.state = 'done';
  } catch (e) { MIG.state = 'failed'; MIG.log.push('✗ ' + String(e.message || e)); }
  MIG.at = new Date().toISOString();
  console.log('[migrate]', MIG.state, MIG.log.join(' | '));
}

// كل بوابة لها رابط دخول مستقل
const PORTALS = ['citizen', 'borrower', 'bank', 'registry', 'cbi', 'supplier', 'integrity', 'syndicate', 'vetdept', 'admin', 'expert'];

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json',
  '.ico': 'image/x-icon', '.mp4': 'video/mp4', '.webm': 'video/webm', '.vtt': 'text/vtt; charset=utf-8', '.woff2': 'font/woff2'
};
const SECURITY = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' };

function send(res, code, body, type, extra = {}) {
  res.writeHead(code, { 'Content-Type': type, ...SECURITY, ...extra });
  res.end(body);
}

// يدعم طلبات المدى (Range) — ضروري لتشغيل الفيديو على آيفون وسفاري
function serveFile(req, res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return serve404(res);
    const ext = path.extname(file).toLowerCase();
    const type = TYPES[ext] || 'application/octet-stream';
    const cache = ext === '.html' ? 'no-cache' : (ext === '.mp4' || ext === '.jpg' || ext === '.webm') ? 'public, max-age=86400' : 'public, max-age=300';
    const head = { 'Content-Type': type, 'Cache-Control': cache, 'Accept-Ranges': 'bytes', ...SECURITY };
    const range = req.headers.range;
    let start = 0, end = st.size - 1, code = 200;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (m) {
        if (m[1] === '' && m[2] !== '') { start = Math.max(0, st.size - Number(m[2])); }
        else { start = Number(m[1] || 0); if (m[2] !== '') end = Math.min(Number(m[2]), st.size - 1); }
        if (start > end || start >= st.size) {
          res.writeHead(416, { 'Content-Range': `bytes */${st.size}`, ...SECURITY }); return res.end();
        }
        code = 206; head['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
      }
    }
    head['Content-Length'] = end - start + 1;
    res.writeHead(code, head);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.end()).pipe(res);
  });
}

function serve404(res) {
  fs.readFile(path.join(PUB, '404.html'), (e, d) => send(res, 404, d || 'Not found', 'text/html; charset=utf-8'));
}

http.createServer((req, res) => {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { return serve404(res); }

  if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
  if (SMS.handle(req, res, p)) return;
  if (esignHandle(req, res, p)) return;
  if (p === '/migrate') {
    const label = { no_token: 'لم يُضَف رمز SUPABASE_ACCESS_TOKEN في Render — لا يُطبَّق أي تحديث', pending: 'بانتظار البدء', running: 'جارِ التطبيق… أعد فتح الصفحة بعد دقيقة', done: '✓ تم — قاعدة البيانات محدّثة. يمكنك الآن حذف الرمز من Render ومن حساب Supabase', failed: '✗ فشل التحديث — أرسل لقطة من هذه الصفحة' }[MIG.state];
    const html = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>تحديث قاعدة البيانات</title>
      <body style="font-family:system-ui,sans-serif;max-width:560px;margin:24px auto;padding:0 16px;line-height:1.8"><h2>تحديث قاعدة البيانات</h2>
      <p style="font-size:18px"><b>${label}</b></p><pre style="white-space:pre-wrap;background:#f3f5f9;padding:12px;border-radius:10px">${MIG.log.map(x => x.replace(/[<>&]/g, '')).join('\n') || '—'}</pre>
      <p style="color:#667">${MIG.at || ''}</p></body></html>`;
    return send(res, 200, html, 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  }
  if (p === '/config.js') {
    const js = `window.ALWAH_CONFIG=${JSON.stringify({ url: SUPABASE_URL, key: SUPABASE_ANON_KEY, ocr: OCR_URL })};`;
    return send(res, 200, js, TYPES['.js'], { 'Cache-Control': 'no-cache' });
  }

  const first = p.split('/')[1];
  if (p === '/' || p === '') return serveFile(req, res, path.join(PUB, 'index.html'));
  if (PORTALS.includes(first) && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'portal.html'));
  if (first === 'demo' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'demo.html'));
  // الجلسة 22: روابط لمرة واحدة — تحديد مكان المنظومة، وموافقة الكفيل (دون تسجيل)
  if (first === 'l' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'link.html'));

  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) return serve404(res);
  serveFile(req, res, file);
}).listen(PORT, () => { console.log(`Alwah running on :${PORT}`); runMigrations().finally(() => SMS.start()); });
