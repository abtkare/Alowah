// ألواح — أدوات مشتركة لكل البوابات
export const PORTALS = {
  citizen:   { title: 'بوابة المقترض', short: 'المقترض', sub: 'تمويلك كله من هاتفك: قدّم وقارن ووقّع وتابع — دون مراجعات ولا أوراق', points: ['هويتك تُقرأ من بطاقتك الوطنية مباشرة', 'قارن المصارف وعمولاتها قبل أن تختار', 'وقّع عقدك إلكترونياً بوجهك وبصمة جهازك', 'تابع طلبك لحظة بلحظة وكل جهة تمسكه'] },
  bank:      { title: 'بوابة المصرف', short: 'المصرف', sub: 'دورة الطلب كاملة داخل المصرف: الفرع ← قسم المبادرات ← الإدارة العليا (قرار الإقراض) ← تعزيز السلفة من ائتمان المصرف لدى البنك المركزي ← التنفيذ والصرف', points: ['صندوق مستقل لكل وحدة وفرع', 'السلفة التجميعية بكتاب موقّع للبنك المركزي', 'سجل زمني لكل مرحلة ومن أنجزها', 'تحليل أداء الفروع والموظفين'] },
  registry:  { title: 'بوابة التسجيل العقاري', short: 'التسجيل العقاري', sub: 'إحالات الرهن الواردة من المصارف', points: ['استعلام الخلو من الإشارات', 'مطابقة السند وهوية المالك', 'تأشير الرهن برقم موثق', 'فك الرهن بعد براءة الذمة'] },
  cbi:       { title: 'لوحة البنك المركزي العراقي', short: 'البنك المركزي', sub: 'جهة قطاعية رقابية: تراقب وتدقق أداء المصارف واستخدام ائتماناتها — لا توافق ولا ترفض الإقراض، وتتدخل عند الحاجة فقط', points: ['قرار السلف التجميعية', 'حصص المصارف ومهل التنفيذ', 'مقارنة أداء المصارف والفروع', 'خريطة المنظومات المركّبة'] },
  supplier:  { title: 'بوابة المورد', short: 'المورد', sub: 'الكتالوج والطلبات والتركيب وتوثيق التشغيل', points: ['عروضك لكل فئة قدرة', 'الطلبات التي اختارك فيها المواطن', 'محضر التركيب بالأرقام التسلسلية', 'توثيق التشغيل بالكاميرا'] },
  integrity: { title: 'لوحة هيئة النزاهة', short: 'هيئة النزاهة', sub: 'قراءة كاملة وتنبيهات آلية — دون أي تعديل أو إيقاف', points: ['تنبيهات الأسعار والعمولات', 'كشف التكرار والتواطؤ', 'سجل تدقيق متسلسل لا يُمحى', 'تصدير ملف أي طلب'] },
  syndicate: { title: 'بوابة نقابة الأطباء البيطريين', short: 'النقابة', sub: 'تأييد عضوية الطبيب البيطري وسريان إجازة ممارسته لهذه السنة — النقابة لا تقرر الإقراض', points: ['طلبات تأييد العضوية', 'مطابقة هوية النقابة وإجازة الممارسة', 'كتاب تأييد إلكتروني برقم', 'سجل الأعضاء المستفيدين من المبادرة'] },
  admin:     { title: 'لوحة مشغّل النظام', short: 'مشغّل النظام', sub: 'الإدارة العامة للمنصة: المستخدمون والصلاحيات، المصارف وعمولاتها ومورّدوها المعتمدون، العروض، إعدادات المنصة، ومتابعة كل الطلبات', points: ['نظرة شاملة على كل الطلبات والمدفوعات', 'إنشاء حسابات الموظفين وإيقافها وإعادة كلمات المرور', 'شروط كل مصرف وعمولته ومورديه المعتمدين', 'سجل إداري لكل تغيير باسم منفّذه'] },
  expert:    { title: 'بوابة الخبراء', short: 'الخبير المعتمد', sub: 'خبراء مختصون معتمدون خارج المصارف يدرسون دراسات جدوى طلبات تمويل الأغراض الزراعية والصناعية والمشاريع ويصدرون قرارهم المستقل', points: ['استلام الطلب المحال من المصرف', 'دراسة الجدوى وعرض المورد', 'القرار: مطابق أو غير مطابق', 'كتابة القرار والملاحظة بالرمز الوظيفي والختم'] },
  audit:     { title: 'لوحة ديوان الرقابة المالية الاتحادي', short: 'ديوان الرقابة المالية', sub: 'جهة رقابية حكومية: اطلاع كامل وتقارير مالية — دون أي كتابة على المعاملات أو تعديل أو إيقاف', points: ['الموقف المالي للمبادرة وائتمان كل مصرف', 'الصرف للمورد مقابل التركيب الموثّق', 'مؤشرات تدقيق آلية: الأسعار والعمولات والقيود', 'تقرير رقابي للطباعة وتصدير Excel'] },
  planning:  { title: 'لوحة وزارة التخطيط — خارطة الطريق ومؤشرات الأداء', short: 'وزارة التخطيط', sub: 'تضع الوزارة خارطة طريق المبادرة بمراحلها وأهدافها، ويقيس النظام الإنجاز آلياً ويحلل الفجوات', points: ['خارطة طريق بمراحل زمنية وأهداف بقيم مستهدفة', 'قياس آلي لكل هدف: متحقق، على المسار، معرّض، متأخر', 'توقع الإنجاز بنهاية المرحلة والمطلوب شهرياً للّحاق', 'أربعة محاور: المال، الطاقة، التوزيع العادل، الاقتصاد'] },
  finance:   { title: 'لوحة وزارة المالية — الأثر المالي للمبادرة', short: 'وزارة المالية', sub: 'ترى الوزارة أثر المبادرة على المال العام بأرقام مجمّعة، وتصدر تعاميمها للمصارف والموردين — دون الكتابة على أي معاملة', points: ['الانكشاف على رواتب موظفي الدولة الكفلاء', 'كلفة دعم الفائدة على الموازنة بمحاكٍ فوري', 'أثر الإعفاء الكمركي على سعر الكيلوواط', 'المبيعات الخاضعة للضريبة وتعاميم الوزارة'] },
  trade:     { title: 'بوابة وزارة التجارة — تأييد رواتب الكفلاء', short: 'وزارة التجارة', sub: 'حين يكفل موظف في إحدى دوائر الوزارة مقترضاً يصلكم طلب تأييد راتبه آلياً: تدققون سجله، والنظام يقرر الموافقة أو الرفض المسبَّب — دون الكتابة على المعاملة', points: ['طلبات تأييد رواتب الكفلاء من موظفي الوزارة', 'هل الراتب حر؟ غير ضامن لقرض ولا عليه سلفة', 'النظام يحسب حصة الكفيل من القسط والصافي المطلوب', 'رفض مسبَّب يعود إلى المصرف ثم إلى المقترض لاستبدال الضمان'] },
  vetdept:   { title: 'بوابة دائرة البيطرة', short: 'دائرة البيطرة', sub: 'الموافقة المبدئية على المشروع البيطري وموقعه قبل التقديم للمصرف، ثم إجازة النشاط بعد التشغيل', points: ['دراسات المشاريع الواردة', 'الموافقة أو الإعادة أو الرفض مسبباً', 'إجازة النشاط بعد الكشف الفني', 'متابعة التوريد والتركيب والتشغيل'] },
};

export const ROLE_LABELS = {
  citizen: 'مواطن', bank_cs: 'خدمة العملاء', bank_compliance: 'الامتثال ومكافحة غسل الأموال', bank_credit: 'ائتمان المبادرات',
  bank_committee: 'اللجنة الائتمانية العليا', bank_legal: 'الشؤون القانونية', bank_ops: 'العمليات المصرفية', bank_collection: 'التحصيل والمتابعة',
  bank_risk: 'المخاطر والتدقيق الداخلي', bank_branch_mgr: 'مدير الفرع', bank_initiatives: 'إداري قسم المبادرات الائتمانية',
  bank_initiatives_mgr: 'مدير قسم المبادرات ومعاونه', bank_md: 'الإدارة العليا للمصرف', bank_inspection: 'لجنة الكشف الموقعي',
  bank_admin: 'قسم الإدارة', bank_teller: 'أمين الصندوق', bank_payroll: 'توطين الرواتب — الاستقطاع المباشر', registry_officer: 'موظف التسجيل العقاري', cbi_admin: 'البنك المركزي',
  supplier_admin: 'مدير حساب المورد', supplier_tech: 'فني التركيب — المورد', integrity_viewer: 'مدقق النزاهة', syndicate_officer: 'لجنة التسجيل — النقابة', vetdept_officer: 'قسم الإجازات — دائرة البيطرة', expert: 'خبير معتمد — دراسات الجدوى', audit_viewer: 'مراقب مالي — ديوان الرقابة المالية', planning_officer: 'مخطط — وزارة التخطيط', finance_officer: 'محلل مالي — وزارة المالية', trade_officer: 'مدقق رواتب الكفلاء — وزارة التجارة', platform_admin: 'مشغّل النظام'
};

// ───────── الجلسة 6: مبادرة تمويل مشاريع الأطباء البيطريين ─────────
export const VET_TYPES = { lab: 'مختبر بيطري', clinic: 'عيادة بيطرية', hospital: 'مستشفى بيطري', pharma: 'معمل أدوية ولقاحات بيطرية', supplies: 'معمل مستلزمات بيطرية' };
export const VET_STEPS = ['التحقق من الهوية', 'العضوية وتأييد النقابة', 'المشروع والمصرف', 'الضمان', 'الدفع والإرسال'];
export const MEMBER_STATUS = { draft: ['لم تُرسل بعد', 'muted'], pending: ['بانتظار تأييد النقابة', 'warn'], endorsed: ['مؤيدة من النقابة', 'ok'], returned: ['أعادتها النقابة للاستكمال', 'warn'], rejected: ['لم تؤيدها النقابة', 'bad'] };
export const VETDEPT_STATUS = { draft: ['لم تُرسل بعد', 'muted'], pending: ['بانتظار موافقة دائرة البيطرة', 'warn'], approved: ['موافقة مبدئية من دائرة البيطرة', 'ok'], returned: ['أعادتها دائرة البيطرة للاستكمال', 'warn'], rejected: ['رفضتها دائرة البيطرة', 'bad'] };
export const TRANCHE_STATUS = { pending: ['غير مستحقة بعد', 'muted'], ready: ['مستحقة — بانتظار الصرف', 'warn'], paid: ['مصروفة', 'ok'] };
export const MILESTONES = [['delivered', 'توريد الأجهزة وخط الإنتاج'], ['installed', 'التركيب'], ['operating', 'التشغيل التجريبي']];
export const isVet = a => a?.program === 'vet';

export const PAY_METHODS = [['zaincash', 'زين كاش', '#D6246E'], ['qicard', 'كي كارد', '#E39B00'], ['asiapay', 'آسيا باي', '#C8102E'], ['fastpay', 'فاست باي', '#25307A'],
  ['fib', 'FIB', '#00877F'], ['visa', 'Visa', '#1A1F71'], ['mastercard', 'Mastercard', '#C4161C'], ['other', 'محفظة أو بطاقة أخرى', '#5B6B82']];
export const PAY_LABEL = Object.fromEntries(PAY_METHODS.map(([k, t]) => [k, t]));
export const GUARANTEE = { single_salary: 'راتب موظف واحد', multi_salary: 'رواتب عدة موظفين', mortgage: 'رهن عقار', gold: 'رهن ذهب' };
// الجلسة 31: تأييد وزارة التجارة لراتب الكفيل
export const ECHK_STATUS = { pending: ['بانتظار تأييد وزارة التجارة', 'warn'], approved: ['أيّدت الوزارة: الراتب حر ويطابق الشروط', 'ok'], rejected: ['رفضت وزارة التجارة', 'bad'], cancelled: ['ملغى', 'muted'] };
export const MOT_DEPTS = ['مركز الوزارة', 'الشركة العامة لتجارة المواد الغذائية', 'الشركة العامة لتجارة الحبوب', 'الشركة العامة لتصنيع الحبوب', 'الشركة العامة للأسواق المركزية', 'الشركة العامة للمعارض والخدمات التجارية العراقية', 'دائرة تسجيل الشركات', 'دائرة الرقابة التجارية والمالية'];
export const EMPLOYMENT = { permanent: 'موظف على الملاك الدائم', contract: 'عقد', daily: 'أجر يومي', retired: 'محال على التقاعد أو منقطع', not_found: 'لا يوجد في سجلات الدائرة' };
export const STATUS = {
  active: ['قيد المعالجة', 'info'], returned: ['مُعاد للاستكمال', 'warn'], rejected: ['مرفوض', 'bad'],
  completed: ['مكتمل', 'ok'], court_hold: ['موقوف بأمر قضائي', 'bad'], cancelled: ['ملغى', 'muted']
};
export const REF_STATUS = {
  pending: ['بانتظار استعلام الخلو', 'warn'], clear: ['خالٍ — بانتظار المطابقة', 'info'], encumbered: ['عليه إشارة', 'bad'],
  matched: ['مطابق — بانتظار التأشير', 'info'], annotated: ['رهن مؤشَّر', 'ok'], released: ['مفكوك', 'muted'], rejected: ['مرفوض', 'bad']
};
// الجلسة 14: مفاتحة المصرف الموطَّن لراتب الكفيل لتفعيل الاستقطاع المباشر
export const SREF_STATUS = { pending: ['بانتظار المصرف الموطَّن', 'warn'], confirmed: ['تأيَّد التوطين — بانتظار التفعيل', 'info'], activated: ['الاستقطاع المباشر مفعَّل', 'ok'], rejected: ['رفض المصرف الموطَّن', 'bad'], cancelled: ['ملغاة', 'muted'] };
export const DD_MODE = { on_default: 'يُستقطع عند تخلّف المقترض عن السداد', monthly: 'استقطاع القسط شهرياً' };
export const DOC_LABEL = { fix: 'مستند طلبه المصرف من المقترض', deed: 'سند العقار', poa: 'وكالة مالك العقار بالرهن', owner_id_front: 'البطاقة الوطنية لمالك العقار', owner_id_back: 'ظهر بطاقة المالك', evidence: 'دليل القرار المرفق',
  quote: 'عرض سعر المورد', site: 'صورة موقع المشروع', mortgage_letter: 'كتاب الرهن', annotation_mark: 'إشارة حجز العقار على السند', dd_auth: 'نموذج تخويل الاستقطاع الموقّع من الكفيل', dd_letter: 'كتاب تفعيل الاستقطاع المباشر', kyc_face: 'الصورة المرجعية لوجه المقترض', contract_signed: 'عقد التمويل والكمبيالة — موقّع إلكترونياً', feasibility: 'دراسة الجدوى', expert_report: 'تقرير الخبير المعتمد', install_panels: 'صورة الألواح المركّبة', install_inverter: 'صورة العاكس والبطاريات', install_video: 'فيديو تشغيل المنظومة', other: 'مستند' };
// الجلسة 16: غرض التمويل، اختصاصات الخبراء، وحالات إحالة دراسة الجدوى
export const PURPOSE = { household: 'سكن (منزلي)', industrial: 'صناعي', project: 'تجاري أو خدمي', agricultural: 'زراعي', vet: 'بيطري', export: 'تصدير', other: 'مشروع آخر' };
export const PURPOSE_HINT = { household: 'منظومة للسكن — يُرفق عرض المورد المقدَّم', agricultural: 'مشروع زراعي — عرض المورد + دراسة جدوى', industrial: 'مصنع أو ورشة — عرض المورد + دراسة جدوى', project: 'مشروع تجاري أو خدمي — عرض المورد + دراسة جدوى', vet: 'عيادة أو مشروع بيطري — عرض المورد + دراسة جدوى', export: 'مشروع إنتاج أو تجهيز للتصدير — عرض المورد + دراسة جدوى', other: 'مشروع من نوع آخر تكتبه — عرض المورد + دراسة جدوى' };
// الجلسة 17: نوع الموقع ونوع المشروع، وتصنيف القطاعات في خريطة البنك المركزي وتحليلاته
export const SITE_TYPE = { residential: 'سكن', project: 'مشروع' };
export const PROJECT_KINDS = [['industrial', 'صناعي'], ['project', 'تجاري'], ['agricultural', 'زراعي'], ['vet', 'بيطري'], ['export', 'تصدير'], ['other', 'أخرى']];
export const SECTORS = { residential: ['سكني', '#2a78d6'], industrial: ['صناعي', '#eb6834'], project: ['تجاري أو خدمي', '#1baf7a'], agricultural: ['زراعي', '#eda100'], vet: ['بيطري — منظومة شمسية', '#e87ba4'], vet_program: ['مبادرة الأطباء البيطريين', '#008300'], export: ['تصدير', '#0e7490'], other: ['مشاريع أخرى', '#6250d6'] };
export const sectorOf = a => a?.program === 'vet' ? 'vet_program' : (!a?.purpose || a.purpose === 'household') ? 'residential' : a.purpose;
export const purposeText = a => a?.purpose === 'other' && a?.purpose_other ? `مشروع آخر: ${a.purpose_other}` : (PURPOSE[a?.purpose] || PURPOSE.household);
export const mapsLink = g => g ? `https://www.google.com/maps?q=${Number(g.lat).toFixed(6)},${Number(g.lng).toFixed(6)}` : '';
export const fmtM = m => m == null ? '—' : Number(m) >= 1000 ? `<span class="num">${(Number(m) / 1000).toFixed(1)}</span> كم` : `<span class="num">${Math.round(Number(m))}</span> م`;
export const SPECIALTY = { industrial: 'صناعي', agricultural: 'زراعي', energy: 'طاقة وهندسة كهربائية', economic: 'اقتصادي ومالي' };
export const PURPOSE_SPEC = { industrial: 'industrial', agricultural: 'agricultural', project: 'economic', vet: 'economic', export: 'economic', other: 'economic' };
export const XREF_STATUS = { pending: ['محالة — بانتظار استلام الخبير', 'warn'], received: ['قيد الدراسة لدى الخبير', 'info'], conforming: ['مطابق', 'ok'], non_conforming: ['غير مطابق', 'bad'], cancelled: ['ملغاة', 'muted'] };
export const PROP_STATUS = { free: ['خالٍ', 'ok'], mortgaged: ['مرهون', 'warn'], seized: ['محجوز', 'bad'], frozen: ['موقوف', 'bad'] };

// نص زر الإنجاز لمراحل المصرف يأتي من جدول المراحل (action_label)؛ ولمراحل المواطن الخمس:
export const ADVANCE_LABEL = { 1: 'إكمال التحقق من الهوية', 2: 'تأكيد رقم «أور»', 3: 'تثبيت العرض المختار', 4: 'تأكيد الضمان', 5: 'تأكيد اختيار المصرف' };
export const BATCH_STATUS = { draft: ['مسودة — بانتظار توقيع الإدارة العليا', 'warn'], signed: ['موقّع — بانتظار الإرسال', 'info'], sent: ['مرسل — بانتظار كفاية ائتمان المصرف', 'warn'], approved: ['معزَّزة من ائتمان المصرف', 'ok'], rejected: ['مرفوضة (قبل تصحيح دور المركزي)', 'muted'] };
export const wdTxt = d => d == null ? '—' : Number(d) < 1 ? `<span class="num">${Math.max(1, Math.round(Number(d) * 8))}</span> ساعة دوام` : `<span class="num">${Number(d).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> يوم`;

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const num = n => n == null ? '—' : Number(n).toLocaleString('en-US');
export const iqd = n => n == null ? '—' : `<span class="num">${num(Math.round(n))}</span> د.ع`;
export const mln = n => `<span class="num">${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`;
export const pct = n => `<span class="num">${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 1 })}%</span>`;
export const dt = s => s ? new Date(s).toLocaleString('ar-IQ-u-nu-latn', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
export const ago = s => {
  const m = Math.round((Date.now() - new Date(s)) / 60000);
  if (m < 1) return 'الآن'; if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.round(m / 60); if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.round(h / 24)} يوم`;
};
export const badge = ([t, k]) => `<span class="badge ${k}"><i class="dot"></i>${esc(t)}</span>`;
export const statusBadge = s => badge(STATUS[s] || [s, 'muted']);

export function el(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }

let toastTimer;
export function toast(msg, kind = '') {
  let t = document.querySelector('.toast');
  if (!t) { t = el('<div class="toast"></div>'); document.body.appendChild(t); }
  t.className = 'toast ' + kind; t.textContent = msg;
  requestAnimationFrame(() => t.classList.add('on'));
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 3800);
}

// شريط المراحل
export function stageBar(app, total = 37) {
  let out = '';
  for (let i = 1; i <= total; i++) {
    let c = '';
    if (app.status === 'completed' || i < app.stage) c = 'done';
    else if (i === app.stage) c = app.status === 'rejected' ? 'bad' : 'cur';
    out += `<span class="s ${c}" title="${i}"></span>`;
  }
  return `<div class="stages" style="grid-template-columns:repeat(${total},1fr)">${out}</div>`;
}

export function stageList(app, stages) {
  let phase = '';
  // المشروع البيطري: خطوات المقترض الخمس بأسمائها في هذا البرنامج
  if (app?.program === 'vet') stages = stages.map(x => x.n <= 5 ? { ...x, name: VET_STEPS[x.n - 1], proc_ref: null } : x);
  return `<ol class="stage-list">${stages.map(s => {
    const done = app.status === 'completed' || s.n < app.stage;
    const cur = s.n === app.stage && app.status !== 'completed';
    const head = s.phase && s.phase !== phase ? `<li class="ph">${esc(phase = s.phase)}</li>` : '';
    return `${head}<li class="${done ? 'done' : cur ? (app.status === 'returned' ? 'cur ret' : 'cur') : ''}"><span class="n">${done ? '✓' : s.n}</span><span>${esc(s.name)}${s.proc_ref ? `<small class="ref">${esc(s.proc_ref)}</small>` : ''}</span><span class="who">${esc(s.owner_label)}</span></li>`;
  }).join('')}</ol>`;
}

// السجل الزمني للمعاملة: كم استغرقت كل مرحلة مقابل المدة المسموحة ومن أنجزها
export function timelineCard(rows, app, settings = {}) {
  if (!rows?.length) return '';
  const bank = rows.filter(r => r.stage >= 6);
  const sum = bank.reduce((t, r) => t + Number(r.wd || 0), 0);
  const late = bank.filter(r => r.sla > 0 && Number(r.wd) > Number(r.sla));
  const max = Math.max(1, ...bank.map(r => Math.max(Number(r.wd || 0), Number(r.sla || 0))));
  const day = 864e5, now = Date.now();
  const dl = [];
  // الجلسة 31: سقف المصرف (مجموع مدد المراحل 6–19) بدل سقوط الموافقة المبدئية — التأخير على الموظف لا على المقترض
  if (app.stage >= 6 && app.stage <= 19 && !['rejected', 'cancelled', 'completed'].includes(app.status)) {
    const budget = Number(settings.bank_sla_budget_days || 38), used = bank.filter(r => r.stage <= 19).reduce((t, r) => t + Number(r.wd || 0), 0), left = budget - used;
    dl.push(`<span class="badge ${left < 0 ? 'bad' : left < budget * 0.25 ? 'warn' : 'info'}">سقف المصرف حتى الضمان النهائي: ${left >= 0 ? `بقي <b class="num">${Math.round(left * 10) / 10}</b> من <span class="num">${budget}</span> يوم دوام` : `تجاوز بـ <b class="num">${Math.round(-left * 10) / 10}</b> يوم دوام — يُصعَّد آلياً`}</span>`);
  }
  if (app.cbi_approved_at && app.stage < 35 && app.status === 'active') {
    const used = (now - new Date(app.cbi_approved_at)) / day, win = settings.execution_window_days || 30;
    dl.push(`<span class="badge ${used > 90 ? 'bad' : used > win ? 'warn' : 'info'}">${used > 90 ? `تجاوز 3 أشهر من التعزيز — غرامة ${settings.late_penalty_pct || 5}%` : used > win ? `تجاوز مهلة التنفيذ (${win} يوماً)` : `مهلة التنفيذ: <b class="num">${Math.ceil(win - used)}</b> يوماً متبقية`}</span>`);
  }
  return `<div class="card mb"><h3>السجل الزمني للمعاملة <span class="sp"></span><span class="badge muted">أيام دوام</span></h3>
    <div class="row mb" style="flex-wrap:wrap;gap:8px"><span class="badge info">لدى المصرف حتى الآن: ${wdTxt(sum)}</span>
      <span class="badge ${late.length ? 'bad' : 'ok'}">${late.length ? `<b class="num">${late.length}</b> مرحلة تجاوزت المدة` : 'كل المراحل ضمن المدة'}</span>${dl.join('')}</div>
    <div class="tl">${bank.map(r => {
      const over = r.sla > 0 && Number(r.wd) > Number(r.sla);
      return `<div class="tl-r ${r.open ? 'open' : ''} ${over ? 'over' : ''}"><div class="tl-n"><b class="num">${r.stage}</b> ${esc(r.name)}<small>${esc(r.by || r.unit)}${r.returns ? ` · أعيد ${r.returns}` : ''}${r.outcome === 'rejected' ? ' · رفض' : ''}</small></div>
        <div class="tl-b"><i style="width:${(Number(r.wd) / max * 100).toFixed(1)}%"></i>${r.sla > 0 ? `<u style="inset-inline-start:${(r.sla / max * 100).toFixed(1)}%" title="المدة المسموحة"></u>` : ''}</div>
        <div class="tl-v">${wdTxt(r.wd)}${r.open ? ' <span class="badge warn">جارية</span>' : ''}<small>المسموح ${r.sla > 0 ? wdTxt(r.sla) : '—'}</small></div></div>`;
    }).join('')}</div></div>`;
}

// سجل الأحداث: منصب منفّذ كل إجراء ظاهر لكل من يرى المعاملة، ورمزه الوظيفي وختمه للمخوّلين فقط (sigs)
export function eventsList(events, sigs = []) {
  if (!events.length) return '<p class="muted small">لا أحداث بعد.</p>';
  const S = Object.fromEntries((sigs || []).map(x => [x.event_id, x]));
  return `<ul class="events">${events.slice().reverse().map(e => { const g = S[e.id]; return `
    <li><div><b>${esc(e.action)}</b> — <span class="muted">${esc(e.actor_name || '')}</span></div>
    ${e.actor_title ? `<div class="small muted">${esc(e.actor_title)}</div>` : ''}
    ${e.note ? `<div style="white-space:pre-line">${esc(e.note)}</div>` : ''}
    ${g ? `<div class="sig">${g.actor_code ? `الرمز الوظيفي <code>${esc(g.actor_code)}</code>` : ''} الختم الإلكتروني <code>${esc(g.seal)}</code></div>` : ''}
    <div class="t">${dt(e.created_at)} · المرحلة ${e.stage} · <span class="h" title="${esc(e.hash)}">#${esc((e.hash || '').slice(0, 12))}</span></div></li>`; }).join('')}</ul>`;
}

// عرض مستند بحجمه الكامل
function docBody(data) {
  return `${String(data.mime).includes('pdf') ? `<a class="btn" href="${data.data}" download="document.pdf">فتح ملف PDF</a>` : String(data.mime).startsWith('video/') ? `<video src="${data.data}" controls playsinline style="width:100%;max-height:70vh;border-radius:12px;background:#000"></video>` : `<img src="${data.data}" alt="">`}
    ${data.meta?.gps ? `<p class="small mt">📍 موقع الالتقاط: <a href="${mapsLink(data.meta.gps)}" target="_blank" rel="noopener">فتح على الخريطة</a> · دقة ±<span class="num">${Math.round(data.meta.gps.acc)}</span> م${data.meta.dist_m != null ? ` · يبعد ${fmtM(data.meta.dist_m)} عن موقع التركيب` : ''}${data.meta.by_code ? ` · <span class="num">${esc(data.meta.by_code)}</span>` : ''}</p>` : ''}
    <p class="small muted mt">${data.source === 'camera' ? 'التُقط بالكاميرا مباشرة' : data.source === 'demo' ? 'نموذج عرض' : 'ملف مرفوع'} · ${esc(data.uploaded_by_title || '')} · ${dt(data.created_at)}${data.sha256 ? `<br>البصمة <code dir="ltr">${esc(data.sha256.slice(0, 24))}…</code>` : ''}</p>`;
}
export async function viewDoc(sb, id) {
  const { data } = await sb.from('app_documents').select('*').eq('id', id).maybeSingle();
  if (!data) return toast('تعذر فتح المستند', 'bad');
  modal(`<div class="docview"><h3>${esc(docName(data))}</h3>${docBody(data)}</div>`, { wide: true });
}
const docName = d => (DOC_LABEL[d.kind] || 'مستند') + (d.kind === 'feasibility' && d.meta?.version ? ` — الإصدار ${d.meta.version}` : '');

// الجلسة 25: «مستندات الطلب» — كل مستند في الطلب مجمّعاً حسب نوعه، يُفتح ويُتصفّح (السابق/التالي) في أي مرحلة من دورة القرض
const DOC_GROUPS = [
  ['الهوية والتحقق', ['kyc_face', 'owner_id_front', 'owner_id_back']],
  ['المنظومة والمشروع ودراسة الجدوى', ['quote', 'feasibility', 'expert_report', 'site']],
  ['الضمان والعقار والراتب', ['deed', 'poa', 'mortgage_letter', 'annotation_mark', 'dd_auth', 'dd_letter']],
  ['العقد', ['contract_signed']],
  ['التركيب والتشغيل', ['install_panels', 'install_inverter', 'install_video']],
];
const docIcon = d => String(d.mime || '').includes('pdf') ? '📄' : String(d.mime || '').startsWith('video/') ? '🎬' : d.source === 'camera' ? '📷' : '🖼';
export function docsModal(sb, app, docs) {
  const known = DOC_GROUPS.flatMap(g => g[1]);
  const groups = [...DOC_GROUPS, ['مستندات أخرى', [...new Set(docs.map(d => d.kind).filter(k => !known.includes(k)))]]]
    .map(([t, ks]) => [t, docs.filter(d => ks.includes(d.kind))]).filter(g => g[1].length);
  const flat = groups.flatMap(g => g[1]);
  const m = modal('<div data-dm></div>', { wide: true });
  const box = m.el.querySelector('[data-dm]');
  const list = () => {
    box.innerHTML = `<h3>📎 مستندات الطلب <span class="num">${esc(app.code)}</span> <span class="badge muted"><span class="num">${flat.length}</span> مستند</span></h3>
      <p class="small muted" style="margin-top:0">كل ما أُرفق بالطلب من التقديم حتى الآن — اضغط أي مستند لعرضه. العرض مسجّل باسمك ضمن صلاحيتك على المعاملة.</p>
      ${flat.length ? `<div class="docs-files">${groups.map(([t, ds]) => `<div><h4>${esc(t)} (<span class="num">${ds.length}</span>)</h4><div style="display:grid;gap:6px">
        ${ds.map(d => `<button type="button" class="docs-row" data-i="${flat.indexOf(d)}"><span class="ic">${docIcon(d)}</span><span class="meta"><b>${esc(docName(d))}</b>
          ${d.meta?.superseded ? ' ' + badge(['سابقة', 'muted']) : d.meta?.updated ? ' ' + badge(['محدّثة', 'ok']) : ''}<small>${esc(d.uploaded_by_title || '')} · ${dt(d.created_at)}</small></span><span class="small" style="color:var(--indigo)">عرض ←</span></button>`).join('')}</div></div>`).join('')}</div>`
        : '<div class="empty">لا توجد مستندات مرفقة بهذا الطلب بعد.</div>'}`;
    box.querySelectorAll('[data-i]').forEach(b => b.onclick = () => show(+b.dataset.i));
  };
  const show = async i => {
    const d = flat[i];
    box.innerHTML = `<div class="docview"><button type="button" class="btn ghost sm" data-back>→ كل المستندات</button>
      <h3 class="mt">${esc(docName(d))}</h3><div data-body><div class="spin"></div></div>
      <div class="docnav"><button type="button" class="btn ghost sm" data-prev ${i ? '' : 'disabled'}>→ السابق</button><span class="sp"></span><span class="small muted"><span class="num">${i + 1}</span> من <span class="num">${flat.length}</span></span><span class="sp"></span><button type="button" class="btn ghost sm" data-next ${i < flat.length - 1 ? '' : 'disabled'}>التالي ←</button></div></div>`;
    box.querySelector('[data-back]').onclick = list;
    box.querySelector('[data-prev]').onclick = () => show(i - 1);
    box.querySelector('[data-next]').onclick = () => show(i + 1);
    const { data } = await sb.from('app_documents').select('*').eq('id', d.id).maybeSingle();
    const b = box.querySelector('[data-body]'); if (!b) return;
    b.innerHTML = data ? docBody(data) : '<div class="notice warn">تعذر فتح المستند — قد لا تشمله صلاحيتك.</div>';
  };
  list();
}

// درج تفاصيل الطلب — مشترك لكل البوابات
export async function openApp(ctx, app, { actions = [], extra = '' } = {}) {
  const { sb, stages } = ctx;
  closeDrawer();
  const bg = el('<div class="drawer-bg"></div>');
  const dr = el(`<aside class="drawer" role="dialog" aria-label="تفاصيل الطلب">
    <div class="dh"><div><div class="small" style="color:#8FA3C0">طلب تمويل</div><h2 class="num">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}<button class="btn btn-dark sm docs-btn" data-docs disabled title="عرض كل مستندات الطلب">📎 المستندات</button><button class="btn btn-dark sm" data-close>إغلاق</button></div>
    <div class="db"><div class="spin"></div></div>
    <div class="df" ${actions.length ? '' : 'hidden'}></div></aside>`);
  document.body.append(bg, dr);
  requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
  bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;

  const [events, tl, sigs, docs, pays] = await Promise.all([
    sb.from('application_events').select('*').eq('application_id', app.id).order('id').then(r => r.data || []),
    sb.rpc('app_timeline', { p_app: app.id }).then(r => r.data || []),
    sb.from('event_signatures').select('event_id,actor_code,seal').eq('application_id', app.id).then(r => r.data || []),
    sb.from('app_documents').select('id,kind,source,mime,uploaded_by_title,created_at,meta').eq('application_id', app.id).order('created_at').then(r => r.data || []),
    sb.from('payments').select('*').eq('application_id', app.id).then(r => r.data || []),
  ]);
  const DOCK = DOC_LABEL;
  const vet = isVet(app) ? await vetData(sb, app) : null;
  const own = app.ownership;
  if (!ctx.settings) ctx.settings = Object.fromEntries(((await sb.from('settings').select('key,value')).data || []).map(x => [x.key, Number(x.value)]));
  if (!ctx.branches) ctx.branches = (await sb.from('branches').select('*')).data || [];
  const branch = ctx.branches.find(b => b.id === app.branch_id);
  const cur = stages.find(s => s.n === app.stage);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  dr.querySelector('.db').innerHTML = `
    <div class="card mb">
      <div class="row"><b>${esc(app.citizen_name)}</b><span class="sp"></span><span class="muted small">${esc(app.governorate)}</span></div>
      <div class="row small" style="margin:6px 0 2px;gap:6px;flex-wrap:wrap"><span>رقم الطلب <b class="num">${esc(app.code)}</b></span><span class="sp"></span>${badge([`الضمان: ${GUARANTEE[app.guarantee_type] || '—'}`, app.guarantee_type === 'mortgage' ? 'warn' : 'info'])}</div>
      ${stageBar(app, stages.length)}
      <div class="small muted">المرحلة الحالية: <b style="color:var(--text)">${app.stage}. ${esc(cur?.name)}</b> — لدى ${esc(cur?.owner_label)}</div>
      ${docs.length ? `<button type="button" class="btn ghost sm mt" data-docs2>📎 اطّلع على مستندات الطلب (<span class="num">${docs.length}</span>)</button>` : ''}
    </div>
    ${app.returned_from ? `<div class="notice warn mb"><b>⚠ مستعجل — معاملة مُرجعة</b> من مرحلة «${esc(stages.find(s => s.n === app.returned_from)?.name || app.returned_from)}»${app.returned_by_title ? ` (${esc(app.returned_by_title)})` : ''} · ${dt(app.returned_at)}
      <div style="white-space:pre-line;margin-top:6px"><b>النقص:</b> ${esc(app.return_note || '—')}</div>
      <div class="small muted mt">بعد الاستكمال أنجز المرحلة لتعود المعاملة إلى من أرجعها، وتبقى بأولوية مستعجل حتى تتجاوزه.</div></div>` : ''}
    ${execCard(ctx, app)}
    ${extra}
    ${!vet && (app.stage >= 31 || app.install_geo) ? '<div data-install-box></div>' : ''}
    ${!vet && app.stage >= 30 && !ctx.hide?.includes('amount') ? '<div data-repay-box></div>' : ''}
    ${vet ? vetCards(ctx, app, vet) : ''}
    ${timelineCard(tl, app, ctx.settings)}
    <div class="card mb"><h3>بيانات الطلب</h3>
      <dl class="kv">
        ${vet ? `<dt>البرنامج</dt><dd>مبادرة تمويل مشاريع الأطباء البيطريين</dd><dt>المشروع</dt><dd>${esc(VET_TYPES[vet.p?.project_type] || '—')}</dd>` : `<dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd><dt>نوع الموقع والغرض</dt><dd>${app.site_type ? esc(SITE_TYPE[app.site_type]) + ' — ' : ''}${esc(purposeText(app))}${app.feasibility_rejections ? ` ${badge([`مرفوض سابقاً بسبب دراسة الجدوى (${app.feasibility_rejections})`, 'bad'])}` : ''}</dd>`}
        ${vet ? '' : `<dt>عنوان المنظومة</dt><dd>${app.site_geo ? `📍 <a href="${mapsLink(app.site_geo)}" target="_blank" rel="noopener">على الخريطة</a> · دقة ±<span class="num">${Math.round(app.site_geo.acc)}</span> م ${badge(['مثبّت بالـGPS', 'ok'])}${app.site_geo.address ? `<div class="small muted">${esc(app.site_geo.address)}</div>` : ''}` : badge(['لم يُثبَّت بالـGPS بعد', 'warn'])}</dd>`}
        <dt>المورد</dt><dd>${esc(org(app.supplier_id))}</dd>
        ${ctx.hide?.includes('amount') ? '' : `<dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)} × <span class="num">${app.term_months - (vet ? app.grace_months || 0 : 0)}</span> شهراً${vet && app.grace_months ? ` بعد سماح <span class="num">${app.grace_months}</span> شهراً` : ''}</dd>`}
        ${ctx.hide?.includes('guarantee') ? '' : `<dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type] || '—')}</dd>`}
        <dt>المصرف</dt><dd>${esc(org(app.bank_id))}${branch ? ` — ${esc(branch.name)}` : ''}</dd>
        ${app.cbi_fee && !ctx.hide?.includes('amount') ? `<dt>عمولة البنك المركزي</dt><dd>${iqd(app.cbi_fee)} <span class="muted small">لمرة واحدة ولا تُسترجع</span></dd>` : ''}
        ${app.fees_paid_at ? `<dt>إيداع العمولات وأجور الكشف</dt><dd>${dt(app.fees_paid_at)}</dd>` : ''}
        ${vet ? '' : `<dt>رقم «أور»</dt><dd><span class="num">${esc(app.ur_number || '—')}</span> ${app.ur_verified ? badge(['متحقق منه', 'ok']) : badge(['بانتظار التحقق', 'warn'])}</dd>`}
        ${app.inspection_result ? `<dt>التدقيق الهندسي</dt><dd>${badge([app.inspection_result, 'ok'])}</dd>` : ''}
        <dt>تاريخ التقديم</dt><dd>${dt(app.created_at)}</dd>
      </dl>
    </div>
    ${own || docs.length ? `<div class="card mb"><h3>${own ? 'المستندات وملكية العقار' : 'المستندات'}</h3>
      ${own ? `<p style="margin-top:0">${own.is_owner ? 'المقترض هو مالك العقار' : `المالك شخص آخر: <b>${esc(own.owner_name)}</b> (${esc(own.relation || '')}) — وافق على الرهن برمز التحقق`}
        · سند <b>${esc(own.deed_no)}</b> · ${own.match === 'matched' ? badge(['مطابق للسجل العقاري', 'ok']) : badge(['بانتظار مطابقة التسجيل العقاري', 'warn'])}</p>` : ''}
      <div class="row" style="gap:8px;flex-wrap:wrap">${docs.map(d => `<button type="button" class="btn ghost sm" data-doc="${d.id}">${esc(DOCK[d.kind] || d.kind)}${d.kind === 'feasibility' && d.meta?.version ? ` (الإصدار ${d.meta.version})${d.meta?.superseded ? ' — سابقة' : d.meta?.updated ? ' — محدّثة' : ''}` : ''} ${d.source === 'camera' ? '📷' : d.mime?.includes('pdf') ? 'PDF' : ''}</button>`).join('')}</div>
      <p class="small muted" style="margin:8px 0 0">صلاحية الطباعة تُحدد لكل قسم (قيد الاعتماد) — العرض متاح لمن يرى المعاملة.</p></div>` : ''}
    ${pays.length && !ctx.hide?.includes('amount') ? `<div class="card mb"><h3>المدفوعات قبل الإرسال</h3>${pays.map(p => `<div class="row small"><span>${(p.items || []).map(i => `${esc(i.label)}: ${iqd(i.amount)}`).join(' · ')}</span><span class="sp"></span><b>${iqd(p.amount)}</b> <span class="muted">${esc((PAY_LABEL[p.method] || p.method))} · <span class="num">${esc(p.ref)}</span></span></div>`).join('')}</div>` : ''}
    <div class="grid g2">
      <div class="card"><h3>المراحل</h3>${stageList(app, stages)}</div>
      <div class="card"><h3>سجل التدقيق <span class="sp"></span><span class="badge muted">متسلسل بالبصمة وموقّع</span></h3>${eventsList(events, sigs)}</div>
    </div>`;
  dr.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.doc));
  const dbt = dr.querySelector('[data-docs]');
  const db2 = dr.querySelector('[data-docs2]'); if (db2) db2.onclick = () => docsModal(sb, app, docs);
  if (dbt) { dbt.disabled = false; dbt.innerHTML = `📎 المستندات (<span class="num">${docs.length}</span>)`; dbt.onclick = () => docsModal(sb, app, docs); }
  if (vet) wireVet(ctx, app, vet, dr);
  wireExec(ctx, app, dr);
  const ib = dr.querySelector('[data-install-box]');
  if (ib) import('./install-ui.js').then(m => m.mountInstall(ctx, app, ib)).catch(e => console.error(e));
  // الجلسة 18: قيد الصرف وعمولة المنصة، وجدول الأقساط والتحصيل
  const rb = dr.querySelector('[data-repay-box]');
  if (rb) import('./repay-ui.js').then(m => m.mountRepay(ctx, app, rb)).catch(e => console.error(e));

  if (actions.length) {
    const f = dr.querySelector('.df');
    const needC = actions.some(a => a.needConfirm);
    const expect = needC ? await sb.rpc('stage_confirm_text', { p_app: app.id }).then(r => r.data || '').catch(() => '') : '';
    let capLine = '';
    if (needC && app.stage === 16 && app.bank_id) {
      const t = (await sb.from('bank_terms').select('single_approval_cap').eq('bank_id', app.bank_id).maybeSingle()).data;
      if (t?.single_approval_cap) capLine = app.amount <= t.single_approval_cap
        ? `<div class="small" style="color:var(--ok);margin-bottom:6px">✔ ضمن صلاحيات القسم (حتى ${iqd(t.single_approval_cap)}) — افحص واكتب «موافق»، أو أرجع المعاملة بالنقص.</div>`
        : `<div class="small" style="color:var(--warn);margin-bottom:6px">⚠ المبلغ يتجاوز صلاحيات القسم (${iqd(t.single_approval_cap)}) — موافقتك تُسجَّل توصيةً وتُرفع للإدارة العليا.</div>`;
    }
    f.innerHTML = `${needC ? `<div class="field" style="margin-bottom:8px"><label class="small"><b>تأكيد الإنجاز</b> — يُكتب ويُحفظ باسمك ورمزك الوظيفي</label>
        ${capLine}
        <input class="input" data-confirm placeholder="${esc(expect)}">
        ${expect ? `<button type="button" class="btn ghost sm" data-fillc style="margin-top:6px">✍ ${esc(expect)}</button>` : ''}</div>` : ''}
      <div class="field" style="margin-bottom:10px"><textarea class="input" rows="2" placeholder="${needC ? 'ملاحظة (اختيارية) — أو اكتب النقص هنا قبل ضغط «إرجاع»' : 'ملاحظة أو سبب (يُحفظ في سجل التدقيق)'}"></textarea></div><div class="row" style="flex-wrap:wrap;gap:8px"></div>`;
    const cIn = f.querySelector('[data-confirm]');
    const fill = f.querySelector('[data-fillc]');
    if (fill) fill.onclick = () => { cIn.value = expect; cIn.focus(); };
    // الجلسة 13: دفعات المورد البيطرية تظهر لأمين الصندوق فوق أزرار الإنجاز مباشرة
    if (vet && ctx.profile?.role === 'bank_teller' && app.stage >= 31 && app.stage <= 35 && app.status === 'active' && vet.tr.some(t => t.status !== 'paid')) {
      const lbl = { paid: '✓ صُرفت', ready: 'مستحقة', pending: 'غير مستحقة بعد' };
      const box = el(`<div class="df-pay"><div class="small" style="margin-bottom:6px"><b>دفعات المورد</b> — اصرفها أولاً، ثم أنجز المرحلة</div>
        ${vet.tr.map(t => `<div class="row small" style="margin-top:4px"><span><span class="num">${t.n}</span>. ${esc(t.label)} — ${iqd(t.amount)}</span><span class="sp"></span>
          ${t.status === 'ready' ? `<button type="button" class="btn ok sm" data-pay="${t.n}">صرف الدفعة ${t.n}</button>` : `<span class="muted">${lbl[t.status] || t.status}</span>`}</div>`).join('')}</div>`);
      f.prepend(box);
      wireVet(ctx, app, vet, box);
    }
    const row = f.querySelector(':scope > .row');
    actions.forEach(a => {
      const b = el(`<button class="btn ${a.kind || ''}">${esc(a.label)}</button>`);
      b.onclick = async () => {
        const note = f.querySelector('textarea').value.trim() || null;
        const confirm = cIn ? cIn.value.trim() : '';
        if (a.needConfirm && confirm.length < 3) { cIn.focus(); return toast(`اكتب تأكيد الإنجاز: «${expect || 'تم'}»`, 'bad'); }
        if (a.needNote && !note) { f.querySelector('textarea').focus(); return toast(a.noteHint || 'اكتب السبب أولاً', 'bad'); }
        if ((a.kind || '').includes('bad') && !window.confirm(`تأكيد: «${a.label}»؟\nلا يمكن التراجع عن هذا الإجراء.`)) return;
        row.querySelectorAll('button').forEach(x => x.disabled = true);
        try { await a.run(note, confirm); toast(a.done || 'تم تنفيذ الإجراء', 'ok'); closeDrawer(); ctx.refresh(); }
        catch (e) { toast(cleanErr(e), 'bad'); row.querySelectorAll('button').forEach(x => x.disabled = false); }
      };
      row.appendChild(b);
    });
  }
}

export function closeDrawer() {
  document.querySelectorAll('.drawer,.drawer-bg').forEach(n => { n.classList.remove('on'); setTimeout(() => n.remove(), 250); });
}

export const cleanErr = e => (e?.message || String(e)).replace(/^.*?ERROR:\s*/, '');

// إجراءات المسار العامة
export async function rpc(sb, fn, args) {
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw error;
  smsKick();   // الجلسة 23: قد تكون العملية أنشأت رسالة للمقترض — نبّه خدمة الإرسال
  return data;
}

export function stageActions(ctx, app) {
  const { sb } = ctx;
  const st = ctx.stages.find(x => x.n === app.stage);
  const acts = [];
  // الجلسة 12: مراحل المصرف تُنجز بتأكيد مكتوب، وتُرجع إلى مرحلة محددة مع كتابة النقص وأولوية «مستعجل»
  if (ctx.profile?.portal === 'bank' && st?.confirm_text) {
    if (!st.batch_only) acts.push({ label: st.action_label || 'إنجاز المرحلة', kind: 'ok', needConfirm: true, done: 'تم الإنجاز وسُجّل تأكيدك ونُقل الطلب للمرحلة التالية',
      run: (note, confirm) => rpc(sb, 'stage_decision', { p_app: app.id, p_action: 'advance', p_confirm: confirm, p_note: note }) });
    (st.return_targets || []).forEach(n => {
      const t = ctx.stages.find(x => x.n === n);
      if (!t) return;
      acts.push({ label: `إرجاع إلى ${t.phase === 'الفرع' && st.phase !== 'الفرع' ? 'الفرع' : t.owner_label} (${t.n}) — مستعجل`, kind: 'warn', needNote: true, noteHint: 'اكتب ما هو النقص',
        done: 'أُرجعت المعاملة بأولوية مستعجل', run: note => rpc(sb, 'stage_decision', { p_app: app.id, p_action: 'send_back', p_note: note, p_to: n }) });
    });
    if (!(st.return_targets || []).length) acts.push({ label: 'إعادة للاستكمال', kind: 'warn', needNote: true, done: 'أُعيد الطلب للاستكمال', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'return', p_note: note }) });
    acts.push({ label: 'رفض مسبب', kind: 'bad', needNote: true, done: 'رُفض الطلب', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'reject', p_note: note }) });
    return acts;
  }
  if (!st?.batch_only) acts.push({ label: st?.action_label || 'إنجاز المرحلة', kind: 'ok', done: 'تم إنجاز المرحلة ونُقل الطلب للمرحلة التالية', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'advance', p_note: note }) });
  acts.push({ label: 'إعادة للاستكمال', kind: 'warn', needNote: true, done: 'أُعيد الطلب للاستكمال', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'return', p_note: note }) });
  acts.push({ label: 'رفض مسبب', kind: 'bad', needNote: true, done: 'رُفض الطلب', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'reject', p_note: note }) });
  return acts;
}

export function appsTable(apps, ctx, { onOpen, cols = ['code', 'name', 'kw', 'amount', 'stage', 'status', 'updated'] } = {}) {
  if (!apps.length) return `<div class="empty">لا توجد طلبات هنا الآن.</div>`;
  const st = n => ctx.stages.find(s => s.n === n);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  const C = {
    code: ['رقم الطلب', a => `<b class="num">${esc(a.code)}</b>${a.priority === 'urgent' ? ' <span class="badge bad">مستعجل</span>' : ''}`],
    name: ['المتقدم', a => esc(a.citizen_name)],
    gov: ['المحافظة', a => esc(a.governorate)],
    kw: ['القدرة / المشروع', a => isVet(a) ? `<span class="badge info">بيطري</span> ${esc(VET_TYPES[a.vet_type] || 'مشروع بيطري')}` : `<span class="num">${num(a.kw)}</span> kW`],
    amount: ['التمويل', a => iqd(a.amount)],
    guarantee: ['الضمان', a => esc(GUARANTEE[a.guarantee_type] || '—')],
    bank: ['المصرف', a => esc(org(a.bank_id))],
    branch: ['الفرع', a => esc(ctx.branches?.find(b => b.id === a.branch_id)?.name || '—')],
    supplier: ['المورد', a => esc(org(a.supplier_id))],
    stage: ['المرحلة', a => `<span class="num">${a.stage}</span>. ${esc(st(a.stage)?.name)}`],
    status: ['الحالة', a => statusBadge(a.status)],
    updated: ['آخر تحديث', a => `<span class="muted small">${ago(a.updated_at)}</span>`],
  };
  const id = 't' + Math.random().toString(36).slice(2);
  setTimeout(() => {
    document.querySelectorAll(`#${id} tbody tr`).forEach((tr, i) => tr.onclick = () => onOpen && onOpen(apps[i]));
  });
  return `<div class="tbl-wrap"><table class="tbl" id="${id}"><thead><tr>${cols.map(c => `<th>${C[c][0]}</th>`).join('')}</tr></thead>
    <tbody>${apps.map(a => `<tr class="${onOpen ? 'click' : ''}">${cols.map(c => `<td>${C[c][1](a)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

export function kpi(label, value, sub = '', accent = false) {
  return `<div class="card kpi ${accent ? 'accent' : ''}"><span class="l">${label}</span><span class="v">${value}</span>${sub ? `<span class="s">${sub}</span>` : ''}</div>`;
}

export function tabs(root, defs, onChange) {
  const bar = el('<div class="tabs" role="tablist"></div>');
  defs.forEach((d, i) => {
    const b = el(`<button class="tab ${i === 0 ? 'on' : ''}" role="tab">${esc(d.label)}${d.count ? `<span class="count">${d.count}</span>` : ''}</button>`);
    b.onclick = () => { bar.querySelectorAll('.tab').forEach(x => x.classList.remove('on')); b.classList.add('on'); onChange(d.key); };
    bar.appendChild(b);
  });
  root.appendChild(bar);
}

// ───────── الجلسة 2: أدوات مشتركة إضافية ─────────

// المحافظات الثماني عشرة وإحداثيات تقريبية لمركز كل منها (لخريطة البنك المركزي)
export const GOVS = [
  ['بغداد', 33.31, 44.36], ['البصرة', 30.51, 47.78], ['نينوى', 36.34, 43.13], ['أربيل', 36.19, 44.01], ['النجف', 32.0, 44.33],
  ['كربلاء', 32.6, 44.02], ['بابل', 32.47, 44.42], ['ذي قار', 31.05, 46.26], ['الأنبار', 33.42, 43.3], ['ديالى', 33.75, 44.6],
  ['واسط', 32.5, 45.82], ['ميسان', 31.84, 47.14], ['الديوانية', 31.99, 44.92], ['صلاح الدين', 34.6, 43.68], ['كركوك', 35.47, 44.39],
  ['المثنى', 31.31, 45.28], ['السليمانية', 35.56, 45.43], ['دهوك', 36.87, 42.99]
];
export const govOptions = (sel = '') => `<option value="">اختر المحافظة</option>` + GOVS.map(([g]) => `<option ${g === sel ? 'selected' : ''}>${g}</option>`).join('');

// القسط الشهري بطريقة التقسيط المتناقص
export function installment(amount, ratePct, months) {
  const r = ratePct / 1200;
  if (!r) return Math.round(amount / months);
  return Math.round(amount * r / (1 - Math.pow(1 + r, -months)));
}

export const maskPhone = p => p ? String(p).replace(/^(\d{4})\d{4}(\d{3})$/, '$1••••$2') : '—';
export const maskId = s => s ? '••••••••' + String(s).slice(-4) : '—';

// نجوم التقييم (تقبل كسوراً)
export const stars = (v, size = 15) => `<span class="stars" style="--v:${Number(v || 0).toFixed(2)};font-size:${size}px" aria-label="${Number(v || 0).toFixed(1)} من 5"><span>★★★★★</span></span>`;

// الجلسة 21: «ما هذا؟» — شرح بجملة واحدة بجانب كل مصطلح لا بد منه
export const GLOSS = {
  ur: ['رقم «أور»', 'رقمك في بوابة «أور» الحكومية للخدمات الإلكترونية. تجده في تطبيق «أور» ← الملف الشخصي، وهو 10 أرقام.'],
  kambiala: ['الكمبيالة', 'ورقة تتعهد فيها بدفع مبلغ القرض للمصرف. توقّعها مع العقد ضماناً للسداد، ولا تدفع بها شيئاً إضافياً.'],
  murabaha: ['المرابحة', 'طريقة تمويل في المصرف الإسلامي: يشتري المصرف المنظومة ويبيعها لك بسعر معلوم تدفعه أقساطاً، بدل الفائدة.'],
  kw: ['كيلوواط (kW)', 'قدرة المنظومة: كم جهازاً تشغّل في الوقت نفسه. كل 1 كيلوواط يشغّل تقريباً مبردة هواء أو ثلاجة مع إنارة البيت.'],
  rate: ['نسبة الربح السنوية', 'ما يأخذه المصرف مقابل التمويل كل سنة. لا تحتاج حسابها — القسط الشهري المعروض يشملها.'],
  guarantor: ['الكفيل', 'موظف يضمنك: إن توقفت عن الدفع يُستقطع القسط من راتبه. يوافق برمز يصل إلى هاتفه.'],
  mortgage: ['رهن العقار', 'تضع عقاراً تملكه (أو بوكالة مالكه) ضماناً للقرض. يُرفع الرهن بعد سداد آخر قسط.'],
  commission: ['عمولة المصرف', 'مبلغ يدفعه المقترض مرة واحدة للمصرف عند تقديم الطلب. كل مصرف يحدد نسبته.'],
};
export const what = k => GLOSS[k] ? `<button type="button" class="what" data-what="${k}" aria-label="ما معنى ${esc(GLOSS[k][0])}؟">ما هذا؟</button>` : '';
if (typeof document !== 'undefined' && !window.__alwahWhat) {
  window.__alwahWhat = true;
  // يعمل حتى داخل بطاقات الاختيار (label): يمنع تبديل الاختيار عند الضغط على «ما هذا؟»
  document.addEventListener('click', e => {
    const b = e.target.closest?.('[data-what]'); if (!b) return;
    e.preventDefault(); e.stopPropagation();
    const [t, d] = GLOSS[b.dataset.what] || [];
    if (t) modal(`<div class="what-box"><div class="what-ic">؟</div><h3>${esc(t)}</h3><p>${esc(d)}</p></div>`);
  }, true);
}

// نافذة منبثقة عامة
export function modal(html, { wide = false, onClose } = {}) {
  const bg = el(`<div class="mdl-bg"><div class="mdl ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><button class="mdl-x" aria-label="إغلاق">×</button><div class="mdl-b"></div></div></div>`);
  bg.querySelector('.mdl-b').innerHTML = html;
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  const close = () => { bg.classList.remove('on'); setTimeout(() => bg.remove(), 200); onClose && onClose(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc_);
  bg.querySelector('.mdl-x').onclick = close;
  bg.addEventListener('click', e => { if (e.target === bg) close(); });
  return { el: bg.querySelector('.mdl-b'), close };
}

// ───────── الجلسة 23: رمز التحقق الحقيقي برسالة نصية ─────────
// الرمز يُطلب من قاعدة البيانات (otp_request) فتضعه في الصندوق الصادر، وخدمة الرسائل في الخادم ترسله فوراً.
// بعد إدخال الرمز الصحيح تعيد القاعدة «تذكرة» مربوطة برقم الهاتف تُمرَّر للعملية بدل الأرقام الأربعة.
let OTP_SB = null;
export function setOtpClient(sb) { OTP_SB = sb; }
let kickAt = 0;
export function smsKick() {
  if (Date.now() - kickAt < 1500) return; kickAt = Date.now();
  try { fetch('/api/sms/kick', { method: 'POST', keepalive: true }).catch(() => {}); } catch { /* لا شيء */ }
}
const missingFn = e => /PGRST202|Could not find the function|does not exist/i.test(String(e?.code || '') + ' ' + String(e?.message || e || ''));

// نافذة رمز التحقق — kind: register | reset | phone_change | guarantor | owner | pay | sign | ur | schedule | verify
// ref: رقم الطلب (للكفيل ومالك العقار من حساب المقترض) أو رمز رابط الكفيل.
// verify(ticket) تُستدعى للتحقق وترمي خطأ إن فشل. تعيد Promise بالتذكرة أو null عند الإلغاء.
export function askOtp({ title = 'رمز التحقق', phone = '', purpose = '', verify, kind = 'verify', ref = null, sb = null } = {}) {
  return new Promise(resolve => {
    const dev = window.ALWAH_DEV || {};
    const cli = sb || OTP_SB;
    const ph = normPhone(phone);
    let done = false;
    const m = modal(`<div class="otp">
      <div class="otp-ic">✉</div>
      <h3>${esc(title)}</h3>
      <p class="muted" data-msg>جارِ إرسال رمز من 4 أرقام برسالة نصية إلى <b class="num">${esc(maskPhone(phone))}</b>…</p>
      ${purpose ? `<p class="small muted" style="margin-top:-6px">${esc(purpose)}</p>` : ''}
      ${dev.dev_mode ? `<button type="button" class="devchip" data-fill>وضع المطور — الرمز <b class="num">${esc(dev.dev_otp || '1234')}</b> · اضغط للتعبئة</button>` : ''}
      <div class="otp-in" dir="ltr">${[0, 1, 2, 3].map(i => `<input inputmode="numeric" maxlength="1" aria-label="الرقم ${i + 1}" autocomplete="${i === 0 ? 'one-time-code' : 'off'}">`).join('')}</div>
      <div class="err-line" hidden></div>
      <button class="btn cyan block" data-ok>تأكيد</button>
      <p class="small muted" style="margin-top:12px">لم يصلك الرمز؟ <button type="button" class="linkbtn" data-re disabled>إعادة الإرسال <span data-t></span></button></p>
    </div>`, { onClose: () => { if (!done) { clearInterval(iv); resolve(null); } } });
    const ins = [...m.el.querySelectorAll('.otp-in input')], err = m.el.querySelector('.err-line'), ok = m.el.querySelector('[data-ok]');
    const msg = m.el.querySelector('[data-msg]');
    const code = () => ins.map(i => i.value).join('');
    const showErr = t => { err.hidden = false; err.textContent = t; };
    ins.forEach((inp, i) => {
      inp.addEventListener('input', () => {
        inp.value = inp.value.replace(/\D/g, '').slice(-1);
        if (inp.value && i < 3) ins[i + 1].focus();
        if (code().length === 4) submit();
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Backspace' && !inp.value && i > 0) ins[i - 1].focus(); if (e.key === 'Enter') submit(); });
      inp.addEventListener('paste', e => {
        const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 4);
        if (d.length) { e.preventDefault(); d.split('').forEach((c, k) => ins[k] && (ins[k].value = c)); if (d.length === 4) submit(); }
      });
    });
    setTimeout(() => ins[0].focus(), 60);
    const fill = m.el.querySelector('[data-fill]');
    if (fill) fill.onclick = () => { (dev.dev_otp || '1234').split('').forEach((c, k) => ins[k].value = c); submit(); };

    // العدّاد وإعادة الإرسال
    let t = 0, iv = null; const tEl = m.el.querySelector('[data-t]'), re = m.el.querySelector('[data-re]');
    const countdown = s => {
      clearInterval(iv); t = s; re.disabled = true; tEl.textContent = t;
      iv = setInterval(() => { t--; tEl.textContent = t; if (t <= 0) { clearInterval(iv); re.disabled = false; tEl.textContent = ''; } }, 1000);
    };
    async function send(again) {
      err.hidden = true;
      if (!cli) { msg.innerHTML = 'اكتب الرمز الذي وصلك برسالة نصية.'; countdown(30); return; }
      try {
        const { data, error } = await cli.rpc('otp_request', { p_phone: ph, p_kind: kind, p_ref: ref });
        if (error) throw error;
        if (data?.mode === 'dev') { msg.innerHTML = 'خدمة الرسائل غير مربوطة بعد — <b>وضع المطور</b>: اكتب الرمز الظاهر أدناه.'; countdown(30); return; }
        smsKick();
        if (data?.sent) {
          msg.innerHTML = `أرسلنا رمزاً من 4 أرقام برسالة نصية إلى <b class="num">${esc(maskPhone(phone))}</b>. يصل خلال دقيقة.`;
          if (again) toast('أُعيد إرسال الرمز', 'ok');
        } else {
          msg.innerHTML = `أُرسل رمز قبل قليل إلى <b class="num">${esc(maskPhone(phone))}</b> — اكتبه، أو اطلب رمزاً جديداً بعد انتهاء العدّاد.`;
        }
        countdown(Number(data?.wait) || 60);
      } catch (e) {
        if (missingFn(e)) { msg.innerHTML = 'اكتب رمز التحقق.'; countdown(30); return; }
        msg.innerHTML = `تعذّر إرسال الرمز إلى <b class="num">${esc(maskPhone(phone))}</b>.`;
        showErr(cleanErr(e)); countdown(30);
      }
    }
    re.onclick = () => { re.disabled = true; send(true); };
    send(false);

    let busy = false;
    async function submit() {
      if (busy) return;
      const c = code();
      if (c.length !== 4) return showErr('اكتب الأرقام الأربعة');
      busy = true; ok.disabled = true; ok.textContent = 'جارِ التحقق…'; err.hidden = true;
      try {
        let ticket = c;
        if (cli) {
          const { data, error } = await cli.rpc('otp_check', { p_phone: ph, p_code: c });
          if (error && !missingFn(error)) throw error;
          if (data && !data.ok) throw new Error(data.error || 'رمز التحقق غير صحيح');
          if (data?.ticket) ticket = data.ticket;
        }
        if (verify) await verify(ticket);
        done = true; clearInterval(iv); m.close(); resolve(ticket);
      } catch (e) {
        showErr(cleanErr(e));
        ins.forEach(i => i.value = ''); ins[0].focus();
        ok.disabled = false; ok.textContent = 'تأكيد'; busy = false;
      }
    }
    ok.onclick = submit;
  });
}

// تحقق موحّد من الرمز عبر الخادم (يرفض أي رمز غير صحيح)
export const serverOtp = (sb, phone, purpose) => async code => { await rpc(sb, 'verify_otp', { p_phone: phone, p_code: code, p_purpose: purpose }); };

export function normPhone(p) {
  let d = String(p || '').replace(/[^\d٠-٩]/g, '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  if (d.startsWith('00964')) d = '0' + d.slice(5); else if (d.startsWith('964')) d = '0' + d.slice(3); else if (/^7\d{9}$/.test(d)) d = '0' + d;
  return d;
}
export const validPhone = p => /^07[3-9]\d{8}$/.test(normPhone(p));
export const digits = s => String(s || '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/\D/g, '');

// ───────── الجلسة 6: المشروع البيطري داخل درج الطلب (لكل الجهات) ─────────
// إضافة نوع المشروع لصفوف الطلبات البيطرية (لعمود «القدرة / المشروع»)
export async function enrichVet(sb, apps) {
  const ids = apps.filter(isVet).map(a => a.id);
  if (!ids.length) return apps;
  const { data } = await sb.from('vet_projects').select('application_id,project_type,title,vetdept_status,milestones,license_no').in('application_id', ids);
  const P = Object.fromEntries((data || []).map(p => [p.application_id, p]));
  apps.forEach(a => { if (P[a.id]) { a.vet_type = P[a.id].project_type; a.vet = P[a.id]; } });
  return apps;
}

async function vetData(sb, app) {
  const [p, tr, m] = await Promise.all([
    sb.from('vet_projects').select('*').eq('application_id', app.id).maybeSingle().then(r => r.data),
    sb.from('vet_tranches').select('*').eq('application_id', app.id).order('n').then(r => r.data || []),
    sb.from('vet_memberships').select('id,membership_no,syndicate_branch,license_no,license_year,status,letter_no,valid_until,note,decided_at').eq('profile_id', app.citizen_id).maybeSingle().then(r => r.data),
  ]);
  return { p, tr, m };
}

function vetCards(ctx, app, { p, tr, m }) {
  if (!p) return '';
  const role = ctx.profile?.role, org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  const hideMoney = ctx.hide?.includes('amount');
  const ms = p.milestones || {};
  const own = { owned: 'ملك', rented: 'إيجار' }[p.site_ownership] || '—';
  const items = (p.items || []).map(i => `<tr><td>${esc(i.name)}</td><td class="num">${num(i.qty)}</td>${hideMoney ? '' : `<td>${iqd(i.price)}</td><td>${iqd(i.qty * i.price)}</td>`}</tr>`).join('');
  const nextMs = MILESTONES.find(([k]) => !ms[k]);
  const canMs = role === 'supplier_admin' && app.supplier_id === ctx.profile.org_id && app.stage === 31 && app.status === 'active' && nextMs;
  const canPay = role === 'bank_teller' && app.bank_id === ctx.profile.org_id && app.stage >= 31 && app.stage <= 35 && app.status === 'active';
  return `<div class="card mb vet-card"><h3>المشروع البيطري <span class="sp"></span><span class="badge info">${esc(VET_TYPES[p.project_type] || '')}</span></h3>
      <dl class="kv"><dt>اسم المشروع</dt><dd>${esc(p.title || '—')}</dd>
        <dt>الموقع</dt><dd>${esc([p.site_governorate, p.site_city, p.site_address].filter(Boolean).join(' — '))} · ${own}${p.site_area ? ` · <span class="num">${num(p.site_area)}</span> م²` : ''}</dd>
        ${p.products ? `<dt>المنتجات</dt><dd>${esc(p.products)}</dd>` : ''}${p.capacity ? `<dt>الطاقة الإنتاجية</dt><dd>${esc(p.capacity)}</dd>` : ''}
        ${p.staff_count ? `<dt>عدد العاملين</dt><dd class="num">${num(p.staff_count)}</dd>` : ''}
        <dt>المورد وعرض السعر</dt><dd>${esc(org(app.supplier_id))}${p.quote_no ? ` · عرض <span class="num">${esc(p.quote_no)}</span>` : ''}</dd>
        ${hideMoney ? '' : `<dt>كلفة الأجهزة</dt><dd>${iqd(p.equipment_cost)}</dd><dt>أعمال وتكاليف أخرى</dt><dd>${iqd(p.other_cost)}</dd><dt>الكلفة الكلية</dt><dd><b>${iqd(p.total_cost)}</b></dd>
        <dt>مساهمة الطبيب</dt><dd>${iqd(p.contribution)} <span class="muted small">(${p.total_cost ? Math.round(p.contribution / p.total_cost * 100) : 0}%)</span></dd><dt>القرض</dt><dd><b>${iqd(app.amount)}</b></dd>
        ${p.revenue_monthly ? `<dt>الإيراد الشهري المتوقع</dt><dd>${iqd(p.revenue_monthly)}</dd>` : ''}`}</dl>
      ${items ? `<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الجهاز / البند</th><th>العدد</th>${hideMoney ? '' : '<th>السعر</th><th>المجموع</th>'}</tr></thead><tbody>${items}</tbody></table></div>` : ''}
    </div>
    <div class="card mb"><h3>الموافقات الرسمية</h3>
      <dl class="kv"><dt>نقابة الأطباء البيطريين</dt><dd>${m ? `${badge(MEMBER_STATUS[m.status] || [m.status, 'muted'])} عضوية <span class="num">${esc(m.membership_no || '—')}</span> · إجازة <span class="num">${esc(m.license_no || '—')}</span> لسنة <span class="num">${esc(m.license_year || '—')}</span>${m.letter_no ? ` · كتاب <span class="num">${esc(m.letter_no)}</span>` : ''}${m.note ? `<div class="small muted">${esc(m.note)}</div>` : ''}` : badge(['لا عضوية مسجلة', 'bad'])}</dd>
        <dt>دائرة البيطرة — الموافقة المبدئية</dt><dd>${badge(VETDEPT_STATUS[p.vetdept_status] || [p.vetdept_status, 'muted'])}${p.vetdept_ref ? ` <span class="num">${esc(p.vetdept_ref)}</span>` : ''}${p.vetdept_note ? `<div class="small muted">${esc(p.vetdept_note)}</div>` : ''}</dd>
        <dt>إجازة ممارسة النشاط</dt><dd>${p.license_no ? `${badge(['ممنوحة', 'ok'])} <span class="num">${esc(p.license_no)}</span> · ${dt(p.license_at)}` : '<span class="muted">تُمنح بعد التشغيل والكشف الفني</span>'}</dd></dl>
    </div>
    ${tr.length ? `<div class="card mb"><h3>التوريد والصرف للمورد على دفعات</h3>
      <ol class="vet-ms">${MILESTONES.map(([k, l]) => `<li class="${ms[k] ? 'done' : ''}"><i>${ms[k] ? '✓' : ''}</i><span>${l}</span><small>${ms[k] ? dt(ms[k].at) : 'بانتظار توثيق المورد'}</small></li>`).join('')}
        <li class="${p.license_no ? 'done' : ''}"><i>${p.license_no ? '✓' : ''}</i><span>إجازة دائرة البيطرة</span><small>${p.license_no ? dt(p.license_at) : 'بعد التشغيل'}</small></li></ol>
      ${hideMoney ? '' : `<div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الدفعة</th><th>النسبة</th><th>المبلغ</th><th>الحالة</th><th></th></tr></thead><tbody>
        ${tr.map(t => `<tr><td><span class="num">${t.n}</span>. ${esc(t.label)}</td><td class="num">${num(t.pct)}%</td><td>${iqd(t.amount)}</td><td>${badge(TRANCHE_STATUS[t.status])}${t.ref ? ` <span class="num small muted">${esc(t.ref)}</span>` : ''}</td>
          <td>${canPay && t.status === 'ready' ? `<button type="button" class="btn ok sm" data-pay="${t.n}">صرف الدفعة</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`}
      ${canMs ? `<div class="row mt"><span class="small muted">الخطوة التالية: <b>${esc(nextMs[1])}</b></span><span class="sp"></span><button type="button" class="btn cyan sm" data-ms="${nextMs[0]}">توثيق: ${esc(nextMs[1])}</button></div>` : ''}
    </div>` : ''}`;
}

function wireVet(ctx, app, v, dr) {
  const { sb } = ctx;
  const ask = (title, body, run, okText = 'تأكيد') => {
    const m = modal(`<h3>${esc(title)}</h3><p class="muted">${body}</p><div class="field"><label>ملاحظة (اختياري — تُحفظ في سجل التدقيق)</label><textarea class="input" rows="2" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn cyan" data-y>${esc(okText)}</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-y]').onclick = async e => {
      e.target.disabled = true;
      try { await run(m.el.querySelector('[data-n]').value.trim() || null); m.close(); closeDrawer(); ctx.refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  dr.querySelectorAll('[data-ms]').forEach(b => b.onclick = () => {
    const k = b.dataset.ms, l = MILESTONES.find(x => x[0] === k)[1];
    ask(`توثيق: ${l}`, k === 'operating' ? 'بعد التشغيل التجريبي تكشف دائرة البيطرة وتمنح الإجازة، ثم تُصرف الدفعة الأخيرة.' : 'يفتح هذا التوثيق استحقاق الدفعة المرتبطة به لدى أمين الصندوق.',
      async n => { await rpc(sb, 'vet_milestone', { p_app: app.id, p_key: k, p_note: n }); toast(`وُثّق: ${l}`, 'ok'); }, 'توثيق');
  });
  dr.querySelectorAll('[data-pay]').forEach(b => b.onclick = () => {
    const t = v.tr.find(x => x.n === Number(b.dataset.pay));
    ask(`صرف الدفعة ${t.n} للمورد`, `${esc(t.label)} — ${iqd(t.amount)} إلى ${esc(ctx.orgs.find(o => o.id === app.supplier_id)?.name || 'المورد')}.`,
      async n => { await rpc(sb, 'vet_tranche_pay', { p_app: app.id, p_n: t.n, p_note: n }); toast('صُرفت الدفعة وسُجّل القيد', 'ok'); }, 'صرف');
  });
}

// ───────── الجلسة 17: مهلة التنفيذ (30 يوماً من تعزيز السلفة) والتمديد المسبّب ─────────
export function execInfo(ctx, app) {
  if (!app?.cbi_approved_at || app.stage < 24 || app.stage > 34 || !['active', 'returned'].includes(app.status)) return null;
  const win = Number(ctx.settings?.execution_window_days || 30);
  const base = new Date(app.cbi_approved_at).getTime() + win * 864e5;
  const dl = Math.max(base, app.exec_extended_until ? new Date(app.exec_extended_until).getTime() : 0);
  return { dl, left: (dl - Date.now()) / 864e5, extended: (app.exec_extensions || 0) > 0 };
}
function execCard(ctx, app) {
  const x = execInfo(ctx, app); if (!x) return '';
  const d = new Date(x.dl).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'medium' });
  const can = ctx.profile?.role === 'bank_md' && app.bank_id === ctx.profile.org_id && !x.extended && app.status === 'active';
  const cls = x.left < 0 ? 'bad' : x.left <= 5 ? 'warn' : '';
  return `<div class="notice ${cls} mb"><span>⏱</span><span style="flex:1"><b>مهلة التنفيذ:</b> ${x.left < 0 ? `<b>انتهت في ${d}</b> — لا تُنجز أي مرحلة قبل الصرف إلا بتمديد مسبّب من الإدارة العليا للمصرف، أو يُرفض الطلب ليعود المبلغ المحجوز إلى ائتمان المصرف.`
    : `تنتهي في <b>${d}</b> — متبقٍّ <b class="num">${Math.ceil(x.left)}</b> يوماً حتى الصرف للمورد.`}${x.extended ? `<div class="small">مُدّدت مرة واحدة: ${esc(app.exec_extension_note || '')}</div>` : ''}
    ${can ? `<div class="mt"><button type="button" class="btn warn sm" data-exec-ext>تمديد مسبّب (مرة واحدة)</button></div>` : ''}</span></div>`;
}
function wireExec(ctx, app, dr) {
  const b = dr.querySelector('[data-exec-ext]'); if (!b) return;
  b.onclick = () => {
    const mx = Number(ctx.settings?.exec_extension_max_days || 15);
    const m = modal(`<h3>تمديد مهلة التنفيذ — ${esc(app.code)}</h3>
      <p class="small muted">التمديد مرة واحدة فقط وحتى <span class="num">${mx}</span> يوماً. يُسجَّل باسم منصبك، ويصل تنبيه إلى هيئة النزاهة ويطّلع عليه البنك المركزي.</p>
      <div class="field"><label>عدد الأيام</label><input class="input" data-d inputmode="numeric" dir="ltr" value="${mx}"></div>
      <div class="field"><label>سبب التمديد</label><textarea class="input" rows="3" data-n placeholder="مثال: تأخر وصول الألواح من المورد بسبب الكمرك — مرفق كتاب المورد"></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn warn" data-go>تسجيل التمديد</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(ctx.sb, 'exec_extend', { p_app: app.id, p_days: Number(m.el.querySelector('[data-d]').value.replace(/\D/g, '')), p_note: m.el.querySelector('[data-n]').value.trim() }); m.close(); closeDrawer(); toast('مُدّدت مهلة التنفيذ وأُبلغت هيئة النزاهة', 'ok'); ctx.refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}
