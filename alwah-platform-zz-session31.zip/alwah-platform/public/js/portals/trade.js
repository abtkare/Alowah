// الجلسة 31: بوابة وزارة التجارة — تأييد رواتب الكفلاء من موظفي دوائر الوزارة
// يصل الطلب آلياً حين يكون كفيل المقترض موظفاً في الوزارة. الموظف المختص ينقل ما في سجل الكفيل،
// والنظام يقرر: راتب حر (غير ضامن لقرض آخر ولا عليه سلفة) ويغطي حصته من القسط ← موافقة، وإلا رفض مسبَّب.
// الوزارة ترى الكفيل والطلب الذي يكفله فقط، ولا تكتب على المعاملة نفسها.
import { esc, el, iqd, num, kpi, badge, dt, ago, rpc, toast, cleanErr, closeDrawer, tabs, ECHK_STATUS, EMPLOYMENT } from '../core.js';

export const shouldRefresh = () => !document.querySelector('.drawer');

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  let d;
  try { d = await rpc(sb, 'trade_inbox', {}); }
  catch (e) {
    root.innerHTML = `<div class="card empty">${/trade_inbox/.test(cleanErr(e)) ? 'لم يُطبَّق تحديث الجلسة 31 على قاعدة البيانات بعد — افتح ‎/migrate‎' : esc(cleanErr(e))}</div>`;
    return;
  }
  const all = d.checks || [], st = d.stats || {};
  const open = all.filter(c => c.status === 'pending');
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'وزارة التجارة')} — تأييد رواتب الكفلاء</h1>
      <p>${esc(profile.position_title || 'مدقق رواتب الكفلاء')}. حين يكفل أحد موظفي دوائر الوزارة مقترضاً يصلكم طلبه هنا آلياً. انقلوا ما في سجله — والنظام يقرر الموافقة أو الرفض المسبَّب.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظار قراركم', `<span class="num">${st.pending || 0}</span>`, 'طلب تأييد راتب كفيل', true)}
      ${kpi('أيّدتها الوزارة', `<span class="num">${st.approved || 0}</span>`, 'راتب حر ويطابق الشروط')}
      ${kpi('رفضتها الوزارة', `<span class="num">${st.rejected || 0}</span>`, 'عادت للمصرف ثم للمقترض')}
      ${kpi('متوسط مدة القرار', st.avg_hours == null ? '—' : `<span class="num">${st.avg_hours}</span> ساعة`, 'من وصول الطلب حتى القرار')}
    </div>
    <div class="notice mb"><span>⚖</span><span class="small"><b>قاعدة القرار:</b> يُؤيَّد الراتب إذا كان الكفيل على الملاك الدائم، <b>وراتبه حر</b> (غير ضامن لقرض آخر <b>ولم يسحب سلفة</b>)، وراتبه الصافي يغطي حصته من القسط × معامل الأمان. غير ذلك يُرفض مسبَّباً ويعود الطلب إلى موظف المصرف ليعيده إلى المقترض فيستبدل الكفيل أو يقدّم ضماناً آخر (ذهب أو عقار).</span></div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'open', label: 'بانتظار القرار', count: open.length }, { key: 'all', label: 'كل الطلبات' }, { key: 'stats', label: 'التحليل' }];
  ctx.trTab = defs.find(x => x.key === ctx.trTab) ? ctx.trTab : 'open';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.trTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.trTab));

  function show(k) {
    if (k === 'stats') return showStats();
    const list = k === 'open' ? open : all;
    body.innerHTML = list.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th>رقم الطلب</th><th>الكفيل</th><th>الدائرة</th><th>المصرف</th><th>حصة الكفيل من القسط</th><th>الصافي المطلوب</th><th>الحالة</th><th>ورد</th></tr></thead><tbody>
      ${list.map((c, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(c.code)}</b></td><td><b>${esc(c.guarantor_name)}</b></td><td class="small">${esc(c.dept || '—')}</td>
        <td class="small">${esc(c.bank_name || '—')}</td><td>${iqd(c.share)}</td><td>${iqd(c.required_net)}</td><td>${badge(ECHK_STATUS[c.status] || [c.status, 'muted'])}</td><td class="muted small">${ago(c.created_at)}</td></tr>`).join('')}
      </tbody></table></div></div>` : `<div class="card empty">${k === 'open' ? '✓ لا طلبات تنتظر قراركم الآن.' : 'لا طلبات بعد.'}</div>`;
    body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openCheck(list[+tr.dataset.i]));
  }

  function showStats() {
    const br = st.by_reason || [], bd = st.by_dept || [];
    const max = Math.max(1, ...br.map(x => x.n));
    body.innerHTML = `<div class="grid g2">
      <div class="card"><h3>أسباب الرفض</h3>${br.length ? br.map(x => `<div class="mb"><div class="row small"><span>${esc(x.label)}</span><span class="sp"></span><b class="num">${x.n}</b></div>
        <div class="bar"><i style="width:${x.n / max * 100}%;background:var(--bad)"></i></div></div>`).join('') : '<p class="muted small" style="margin:0">لا رفض بعد.</p>'}</div>
      <div class="card"><h3>حسب الدائرة</h3>${bd.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الدائرة</th><th>الطلبات</th><th>أُيّدت</th><th>رُفضت</th></tr></thead><tbody>
        ${bd.map(x => `<tr><td>${esc(x.dept)}</td><td class="num">${x.n}</td><td class="num">${x.ok}</td><td class="num">${x.bad}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small" style="margin:0">لا طلبات بعد.</p>'}</div></div>`;
  }
  show(ctx.trTab);

  function openCheck(c) {
    closeDrawer();
    const can = d.can_decide && c.status === 'pending';
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer"><div class="dh"><div><div class="small" style="color:#8FA3C0">طلب تأييد راتب كفيل</div><h2 class="num">${esc(c.code)}</h2></div><span class="sp"></span>${badge(ECHK_STATUS[c.status] || [c.status, 'muted'])}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">
        <div class="card mb letter" style="line-height:1.9">
          <p style="margin:0"><b>إلى/ وزارة التجارة — ${esc(c.dept || 'الدائرة المختصة')} — قسم الموارد البشرية والرواتب</b></p>
          <p style="margin:0"><b>م/ تأييد راتب كفيل</b></p>
          <p style="margin:8px 0 0">يرجى بيان حالة السيد/ة <b>${esc(c.guarantor_name)}</b>${c.guarantor_nid ? ` (الرقم الوطني <span class="num">${esc(c.guarantor_nid)}</span>)` : ''} الموظف لديكم في <b>${esc(c.dept || '—')}</b>:
          هل راتبه حر (غير ضامن لقرض آخر ولم يسحب سلفة)، وهل يغطي راتبه الصافي حصته من القسط البالغة <b>${iqd(c.share)}</b> شهرياً،
          بصفته كفيلاً للمقترض <b>${esc(c.borrower)}</b> في طلب التمويل <b class="num">${esc(c.app_code)}</b> لدى <b>${esc(c.bank_name || '')}</b>.</p>
          <p class="small muted" style="margin:6px 0 0">ورد آلياً من منصة «ألواح» · ${dt(c.created_at)}</p></div>
        <div class="card mb"><h3>ما يطلبه القرض من الكفيل</h3><dl class="kv">
          <dt>غرض التمويل</dt><dd>${esc(c.purpose || '—')} · ${iqd(c.amount)} على <span class="num">${num(c.term_months || 0)}</span> شهراً</dd>
          <dt>القسط الشهري للطلب</dt><dd>${iqd(c.installment)}${c.guarantors_n > 1 ? ` — يتقاسمه <span class="num">${c.guarantors_n}</span> كفلاء` : ''}</dd>
          <dt>حصة هذا الكفيل</dt><dd><b>${iqd(c.share)}</b> شهرياً</dd>
          <dt>الراتب الصافي المطلوب</dt><dd><b>${iqd(c.required_net)}</b> على الأقل <span class="muted small">(الحصة × معامل الأمان)</span></dd>
          ${c.declared_salary ? `<dt>الراتب كما ذكره المقترض</dt><dd>${iqd(c.declared_salary)} <span class="muted small">— يُدقَّق من سجلكم</span></dd>` : ''}</dl></div>
        ${c.status !== 'pending' ? decidedCard(c) : can ? '<div data-form></div>' : '<div class="notice">الاطلاع فقط — القرار من صلاحية مدقق رواتب الكفلاء في الوزارة.</div>'}
      </div><div class="df"><div class="row" data-foot></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    const close = () => { closeDrawer(); };
    bg.onclick = close; dr.querySelector('[data-close]').onclick = close;
    if (can) decideForm(c, dr.querySelector('[data-form]'), dr.querySelector('[data-foot]'));
    else dr.querySelector('.df').innerHTML = '<p class="muted small" style="margin:0">لا إجراء مطلوب على هذا الطلب.</p>';
  }

  function decidedCard(c) {
    return `<div class="card mb"><h3>قرار الوزارة ${badge(ECHK_STATUS[c.status] || [c.status, 'muted'])}</h3><dl class="kv">
      ${c.employment ? `<dt>الحالة الوظيفية</dt><dd>${esc(EMPLOYMENT[c.employment] || c.employment)}</dd>` : ''}
      ${c.net_salary ? `<dt>الراتب الصافي من السجل</dt><dd>${iqd(c.net_salary)}</dd>` : ''}
      ${c.other_guarantee != null ? `<dt>ضامن لقرض آخر؟</dt><dd>${c.other_guarantee ? 'نعم' : 'لا'}</dd>` : ''}
      ${c.has_advance != null ? `<dt>عليه سلفة؟</dt><dd>${c.has_advance ? `نعم${c.advance_monthly ? ` — ${iqd(c.advance_monthly)} شهرياً` : ''}` : 'لا'}</dd>` : ''}
      ${(c.reason_labels || []).length ? `<dt>أسباب الرفض</dt><dd>${c.reason_labels.map(x => `<div>★ ${esc(x)}</div>`).join('')}</dd>` : ''}
      ${c.note ? `<dt>ملاحظة</dt><dd>${esc(c.note)}</dd>` : ''}
      <dt>القرار</dt><dd>${esc(c.decided_by_name || '')} · ${esc(c.decided_by_title || '')} · <span class="num">${esc(c.decided_by_code || '')}</span><br><span class="small muted">${dt(c.decided_at)}</span></dd>
      ${c.status === 'cancelled' ? `<dt>أُلغي</dt><dd>${esc(c.cancel_note || '')}</dd>` : ''}</dl></div>`;
  }

  // نموذج القرار: أسئلة نعم/لا من سجل الموظف، والنتيجة تظهر فوراً
  function decideForm(c, box, foot) {
    const f = { employment: '', net: '', og: null, adv: null, advm: '', note: '', confirm: false, other: false };
    const yn = (k, q) => `<div class="field"><label>${q}</label><div class="seg" data-yn="${k}"><button type="button" data-v="0">لا</button><button type="button" data-v="1">نعم</button></div></div>`;
    box.innerHTML = `<div class="card mb"><h3>من سجل الموظف</h3>
      <div class="field"><label>1. حالته الوظيفية</label><div class="seg wrap" data-emp>${Object.entries(EMPLOYMENT).map(([k, t]) => `<button type="button" data-v="${k}">${esc(t)}</button>`).join('')}</div></div>
      <div data-more hidden>
        <div class="field"><label>2. الراتب الصافي الشهري (د.ع)</label><input class="input" data-net inputmode="numeric" dir="ltr" placeholder="مثل 950000"></div>
        ${yn('og', '3. هل هو ضامن (كفيل) لقرض آخر؟')}
        ${yn('adv', '4. هل سحب سلفة تُستقطع من راتبه الآن؟')}
        <div class="field" data-advm hidden><label>قسط السلفة الشهري (اختياري)</label><input class="input" data-advmv inputmode="numeric" dir="ltr"></div>
      </div>
      <div class="field"><label>ملاحظة (اختيارية)</label><textarea class="input" rows="2" data-note></textarea></div>
      <label class="row small" style="gap:8px;align-items:flex-start"><input type="checkbox" data-confirm style="margin-top:4px"><span>أؤكد أن ما أدخلته منقول من سجل الموظف الرسمي، ويُسجَّل باسمي ورمزي الوظيفي.</span></label></div>
      <div class="card mb verdict" data-verdict></div>`;
    const q = s => box.querySelector(s);
    const paint = () => {
      const fails = [];
      if (f.employment === 'not_found') fails.push('لا يوجد في سجلات الدائرة');
      else if (f.employment === 'retired') fails.push('محال على التقاعد أو منقطع عن الخدمة');
      else if (['contract', 'daily'].includes(f.employment)) fails.push('ليس على الملاك الدائم');
      if (f.og === true) fails.push('ضامن لقرض آخر — راتبه غير حر');
      if (f.adv === true) fails.push('عليه سلفة قائمة');
      const net = Number(String(f.net).replace(/\D/g, '')) || 0;
      if (f.employment && f.employment !== 'not_found' && net > 0 && net < c.required_net) fails.push(`الصافي ${num(net)} أقل من المطلوب ${num(c.required_net)}`);
      const need = !f.employment ? 'اختر حالته الوظيفية' : f.employment !== 'not_found' && (!net || f.og === null || f.adv === null) ? 'أكمل الأسئلة أعلاه' : '';
      const ok = !need && !fails.length;
      q('[data-more]').hidden = !f.employment || f.employment === 'not_found';
      q('[data-advm]').hidden = f.adv !== true;
      q('[data-verdict]').className = `card mb verdict ${need ? '' : ok ? 'ok' : 'bad'}`;
      q('[data-verdict]').innerHTML = need ? `<p class="muted" style="margin:0">${need} — تظهر النتيجة هنا.</p>`
        : ok ? `<h3 style="margin:0">النتيجة: الراتب حر ويطابق الشروط ✓</h3><p class="small" style="margin:6px 0 0">يُؤيَّد الكفيل ويُشعَر المصرف فوراً.</p>
            <button type="button" class="linkbtn small" data-other>${f.other ? 'تراجع — لا يوجد سبب آخر' : 'لدينا سبب آخر للرفض'}</button>`
        : `<h3 style="margin:0">النتيجة: لا يصح التأييد</h3>${fails.map(x => `<div class="small">★ ${esc(x)}</div>`).join('')}<p class="small muted" style="margin:6px 0 0">يُرفض مسبَّباً ويعود إلى موظف المصرف ليعيد الطلب للمقترض فيستبدل الكفيل أو الضمان.</p>`;
      const ob = q('[data-other]'); if (ob) ob.onclick = () => { f.other = !f.other; paint(); };
      const reject = !need && (!ok || f.other);
      foot.innerHTML = `<span class="sp"></span><button class="btn ${need ? 'ghost' : reject ? 'bad' : 'ok'}" data-go ${need ? 'disabled' : ''}>${need ? 'أكمل البيانات' : reject ? 'رفض مسبَّب وإشعار المصرف' : 'تأييد الراتب وإشعار المصرف'}</button>`;
      const go = foot.querySelector('[data-go]');
      if (go) go.onclick = () => submit(reject ? 'reject' : 'approve', go);
    };
    q('[data-emp]').querySelectorAll('button').forEach(b => b.onclick = () => { f.employment = b.dataset.v; q('[data-emp]').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); paint(); });
    box.querySelectorAll('[data-yn]').forEach(s => s.querySelectorAll('button').forEach(b => b.onclick = () => { f[s.dataset.yn] = b.dataset.v === '1'; s.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); paint(); }));
    q('[data-net]').oninput = e => { f.net = e.target.value; paint(); };
    q('[data-advmv]').oninput = e => { f.advm = e.target.value; };
    q('[data-note]').oninput = e => { f.note = e.target.value; };
    q('[data-confirm]').onchange = e => { f.confirm = e.target.checked; };
    const submit = async (decision, btn) => {
      if (!f.confirm) return toast('أكّد أن البيانات منقولة من سجل الموظف', 'bad');
      if (decision === 'reject' && f.other && f.note.trim().length < 10) return toast('اكتب سبب الرفض في الملاحظة', 'bad');
      btn.disabled = true;
      try {
        await rpc(sb, 'trade_decide', { p_id: c.id, p: { decision, employment: f.employment, net_salary: f.net, other_guarantee: f.og, has_advance: f.adv, advance_monthly: f.advm, note: f.note, confirm: true } });
        closeDrawer(); toast(decision === 'approve' ? 'أُيّد راتب الكفيل وأُشعر المصرف' : 'رُفض مسبَّباً وأُشعر المصرف', 'ok'); ctx.refresh();
      } catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
    };
    paint();
  }
}
