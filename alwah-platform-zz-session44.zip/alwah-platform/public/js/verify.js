// الجلسة 41: صفحة التحقق العامة — تفتح من رمز QR على الوعد أو العقد أو الفاتورة أو المحضر، دون تسجيل دخول
// تثبت أمرين: 1) النص المحفوظ لم يتغير منذ التوقيع  2) قالبه هو النسخة التي اعتمدتها الهيئة الشرعية حرفياً
const CFG = window.ALWAH_CONFIG || {};
const app = document.getElementById('app');
const code = decodeURIComponent(location.pathname.split('/')[2] || '').trim().toUpperCase();
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const iqd = n => n == null ? '—' : `${Math.round(Number(n)).toLocaleString('en-US')} د.ع`;
const day = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'long' }) : '—';
const KIND = { promise: 'وعد غير ملزم', contract: 'عقد موقّع', invoice: 'فاتورة المورد باسم المصرف', receipt: 'محضر استلام وقبض', shares: 'سجل الحصص', share_sale: 'عقد بيع حصة' };
const shell = inner => {
  app.innerHTML = `<div class="lk"><header class="lk-h"><a class="brand" href="/"><img src="/alwah-logo/alwah-icon-128.webp" alt=""><span><b>ألواح</b><small>التحقق من المستندات</small></span></a></header>
    <main class="card lk-b vf">${inner}</main><p class="small muted lk-f">صفحة عامة من منصة «ألواح» — تعرض ما يكفي للتحقق فقط، دون بيانات المقترض الشخصية.</p></div>`;
};
const row = (ok, t, d) => `<li class="${ok ? 'ok' : 'no'}"><i>${ok ? '✓' : '✗'}</i><div><b>${t}</b>${d ? `<small>${d}</small>` : ''}</div></li>`;

try {
  if (!/^[A-Z0-9]{6,16}$/.test(code)) throw new Error('missing');
  const r = await fetch(`${CFG.url}/rest/v1/rpc/islamic_verify`, { method: 'POST', headers: { apikey: CFG.key, Authorization: `Bearer ${CFG.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_code: code }) });
  if (!r.ok) throw new Error('net');
  const d = await r.json();
  if (!d?.found) throw new Error('missing');
  const all = d.doc_intact && d.version_intact && d.approved && !d.void;
  shell(`<div class="vf-top ${all ? 'ok' : 'bad'}"><div class="vf-ic">${all ? '✓' : '!'}</div><div><h2>${all ? 'مستند سليم ومطابق للنسخة المعتمدة' : d.void ? 'هذا المستند استُبدل بنسخة أحدث' : 'تعذّر إثبات سلامة المستند'}</h2>
      <p class="muted">${esc(KIND[d.kind] || d.kind)} — ${esc(d.title)}</p></div></div>
    <ul class="vf-checks">
      ${row(d.doc_intact, 'النص لم يتغير منذ التوقيع', 'بصمة النص المحفوظ تطابق بصمته لحظة التوقيع')}
      ${row(d.version_intact, 'قالب العقد هو النسخة المعتمدة حرفياً', `النسخة <span class="num">${esc(d.version)}</span> من عقد «${esc(d.product)}»`)}
      ${row(d.approved, 'معتمد من الهيئة الشرعية', d.resolution ? `قرار <b class="num">${esc(d.resolution)}</b> — ${esc(d.board || '')} · ${day(d.resolution_at)}` : 'لا قرار اعتماد لهذه النسخة')}
    </ul>
    <dl class="kv vf-kv"><dt>المصرف</dt><dd>${esc(d.bank)}</dd><dt>الصيغة</dt><dd>${esc(d.type_name)}</dd><dt>الطلب</dt><dd><span class="num" dir="ltr">${esc(d.app)}</span></dd>
      <dt>${d.kind === 'invoice' || d.kind === 'receipt' ? 'أصدره' : 'وقّعه'}</dt><dd>${esc(d.signer)} — ${esc(d.signer_title || '')}</dd><dt>التاريخ</dt><dd>${day(d.at)}</dd>
      ${d.amount ? `<dt>المبلغ</dt><dd>${iqd(d.amount)}</dd>` : ''}<dt>رمز التحقق</dt><dd><b class="num" dir="ltr">${esc(code)}</b></dd></dl>
    <details class="small mt"><summary>البصمات الرقمية (SHA-256)</summary><p class="num vf-sha" dir="ltr">النص: ${esc(d.doc_sha256)}<br>النسخة المعتمدة: ${esc(d.version_sha256)}</p></details>`);
} catch (e) {
  shell(`<div class="vf-top bad"><div class="vf-ic">!</div><div><h2>${e.message === 'net' ? 'تعذّر الاتصال — حاول مجدداً' : 'رمز التحقق غير صحيح'}</h2>
    <p class="muted">${e.message === 'net' ? 'تحقق من اتصالك بالإنترنت ثم أعد فتح الرابط.' : 'تأكد أنك مسحت الرمز كاملاً، أو اكتب الرمز المطبوع تحت رمز QR كما هو.'}</p></div></div>`);
}
