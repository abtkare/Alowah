// الجلسة 39: بوابة الهيئة الشرعية للتمويل الإسلامي (/sharia)
// الهيئة تعتمد المنتجات والعقود فقط — لا تراجع طلبات التمويل. كل الصيغ على المذهب الجعفري (من إعدادات الهيئة).
// أمين السر: يتحقق من اكتمال الملف ويحيله للأعضاء أو يعيده للمصرف بسبب.
// الأعضاء والرئيس: يعلّقون على بند محدد في نص العقد، ويرون الفروق بين النسخ، ويصوّتون.
// الرئيس: يصدر القرار برقم SH-… ويوقّعه برمز تحقق، ويعلّق المنتج أو يسحب اعتماده، ويضبط الإعدادات.
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, resultScreen, askOtp } from '../core.js';
import { shBadge, SECTORS, VOTE, DECISION, contractHtml, tallyHtml, resolutionHtml, shortSha } from '../sharia-ui.js';

let D;   // صندوق الهيئة

// التوقيع برمز تحقق على هاتف الرئيس. إن لم يُسجَّل له هاتف بعد: رمز وضع المطور فقط (والقاعدة تتحقق منه)
const noPhoneCli = { rpc: async fn => fn === 'otp_request' ? { data: { mode: 'dev' } } : { data: null } };
const signOtp = (ctx, o) => askOtp({ kind: 'sign', phone: ctx.profile.phone || '', ...(ctx.profile.phone ? {} : { sb: noPhoneCli }), ...o });

export const shouldRefresh = () => !document.querySelector('.mdl-bg,.rs-bg,.ct-bg');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'sharia_inbox');
  if (ctx.shOpen) {
    if (D.products.some(p => p.id === ctx.shOpen) || (D.oversight?.bank_products || []).some(p => p.id === ctx.shOpen)) return detail(ctx, ctx.shOpen);
    ctx.shOpen = null;
  }
  const me = D.me, b = D.board, P = D.products, OV = D.oversight, PAR = D.parent;
  const mine = p => (me.secretary && p.status === 'submitted') || (me.voter && p.status === 'deliberation' && !p.my_vote) || (me.head && p.status === 'deliberation' && p.votes >= b.quorum);
  const todo = P.filter(mine);
  const live = P.filter(p => ['approved', 'conditional'].includes(p.status));
  const tab = ctx.shTab || 'work';
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(b.name)}</h1>
      <p>${esc(me.name)} — ${esc(me.role_title)} · الصيغ على <b>${esc(b.madhhab_label)}</b>${b.marja ? ` · المرجع: ${esc(b.marja)}` : ''}${PAR ? ` · بإشراف ${esc(PAR.name)}` : ''}</p></div></div>
    ${scopeNotice()}
    <div class="notice"><span>ℹ</span><span class="small">الهيئة <b>تعتمد المنتجات والعقود فقط</b> ولا تراجع طلبات التمويل. بعد الاعتماد يطبّق النظام شروط الصيغة في كل طلب، ويوقّع المقترض النص المعتمد حرفياً.</span></div>
    <div class="grid g4 mb">
      ${kpi('المطلوب منك الآن', `<span class="num">${todo.length + (me.central_head ? OV.fit_pending : 0)}</span>`, me.central_head && OV.fit_pending ? `منها <span class="num">${OV.fit_pending}</span> ملاءمة أعضاء` : me.secretary ? 'ملفات بانتظار التحقق' : 'منتجات بانتظار صوتك أو قرارك', true)}
      ${kpi('قيد المداولة', `<span class="num">${P.filter(p => p.status === 'deliberation').length}</span>`, `النصاب <span class="num">${b.quorum}</span> من <span class="num">${b.voters}</span>`)}
      ${kpi('معتمدة نافذة', `<span class="num">${live.length}</span>`, `${live.filter(p => p.review_soon).length ? `<span class="warn-t">${live.filter(p => p.review_soon).length} مراجعتها قريبة</span>` : 'تظهر للمقترضين'}`)}
      ${kpi('القرارات الصادرة', `<span class="num">${D.resolutions.length}</span>`, 'سجل القرارات')}
    </div>
    <div class="seg sm sh-tabs" role="tablist">${[['work', `المنتجات (${P.length})`], ...(OV ? [['banks', `هيئات المصارف (${OV.boards.length})${OV.fit_pending ? ` · ${OV.fit_pending} ملاءمة` : ''}`]] : []), ['res', `سجل القرارات (${D.resolutions.length})`], ['lib', 'مكتبة الصيغ'], ['report', 'تقرير الامتثال'], ['board', me.head ? 'الهيئة والإعدادات' : 'الهيئة']]
      .map(([k, t]) => `<button type="button" class="${tab === k ? 'on' : ''}" data-tab="${k}">${t}</button>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('[data-tab]').forEach(x => x.onclick = () => { ctx.shTab = x.dataset.tab; render(ctx); });
  const body = root.querySelector('[data-body]');
  if (tab === 'res') return resList(ctx, body);
  if (tab === 'lib') return library(body, ctx);
  if (tab === 'report') return import('../sharia-report.js').then(m => m.mountShariaReport(ctx, body, { canIssue: me.head && me.fit, pickBoard: !!OV }));   // الجلسة 43-44
  if (tab === 'board') return boardView(ctx, body);
  if (tab === 'banks' && OV) return banksView(ctx, body);
  const rest = P.filter(p => !mine(p));
  body.innerHTML = `
    ${todo.length ? `<h3 class="sh-sec">المطلوب منك الآن</h3><div class="eng-cards">${todo.map(p => card(p, true)).join('')}</div>` : `<div class="card empty mb">لا شيء مطلوب منك الآن ✓</div>`}
    ${rest.length ? `<h3 class="sh-sec">كل المنتجات</h3><div class="eng-cards">${rest.map(p => card(p)).join('')}</div>` : ''}
    ${PAR?.inherited?.length ? `<h3 class="sh-sec">معتمدة من ${esc(PAR.name)} — نافذة حتى تعيدوا اعتمادها</h3>
      <p class="small muted" style="margin:-4px 0 10px">يقدّمها مسؤول المنتجات الإسلامية في المصرف لإعادة الاعتماد بالنص نفسه، فتمر بدورتكم كاملة. حتى ذلك تبقى نافذة للمقترضين إلى موعد مراجعتها.</p>
      <div class="eng-cards">${PAR.inherited.map(inhCard).join('')}</div>` : ''}`;
  body.querySelectorAll('[data-open]').forEach(x => x.onclick = () => { ctx.shOpen = x.dataset.open; window.scrollTo(0, 0); render(ctx); });
}

function card(p, hot = false) {
  const [ic] = SECTORS[p.sector] || ['•'];
  const own = p.board_id === D.board.id;
  const need = !own ? (p.status === 'deliberation' ? 'قيد المداولة لدى هيئة المصرف — اطلاع' : '')
    : D.me.secretary && p.status === 'submitted' ? 'تحقق من الاكتمال وأحِل أو أعِد'
    : D.me.voter && p.status === 'deliberation' && !p.my_vote ? 'صوّت على النسخة الحالية'
    : D.me.head && p.status === 'deliberation' && p.votes >= D.board.quorum ? 'اكتمل النصاب — أصدر القرار' : '';
  return `<button type="button" class="eng-card sh-card ${p.status} ${hot ? 'hot' : ''}" data-open="${p.id}">
    <div class="row"><b class="num">${esc(p.code)}</b><span class="tag">${esc(p.type)}</span><span class="sp"></span>${shBadge(p.status)}</div>
    <div class="eng-proj">${ic} ${esc(p.name)}</div>
    <div class="small muted">${esc(p.bank)} · ${esc(p.type_name)} · ${esc(p.sector_label)}${p.board_id !== D.board.id ? ` · <b>${esc(p.board_name)}</b>` : ''}</div>
    <div class="row small mt">
      <span>النسخة <b class="num">${p.version ?? '—'}</b></span>
      ${p.comments_open ? `<span class="warn-t">💬 <span class="num">${p.comments_open}</span> تعليق مفتوح</span>` : p.comments ? `<span class="muted">💬 <span class="num">${p.comments}</span></span>` : ''}
      ${p.status === 'deliberation' ? `<span>🗳 <span class="num">${own ? `${p.votes}/${D.board.quorum}` : p.votes}</span></span>` : ''}
      ${p.my_vote ? `<span class="ok-t">صوتك: ${esc(VOTE[p.my_vote][0])}</span>` : ''}
      <span class="sp"></span>${p.resolution ? `<span class="num small">${esc(p.resolution.code)}</span>` : `<span class="muted">${dt(p.updated_at)}</span>`}</div>
    ${p.amends ? `<div class="sh-amend">✎ تعديل على منتج معتمد <b class="num">${esc(p.amends.code)}</b> — نسخته المعتمدة نافذة حتى قراركم</div>` : ''}
    ${need ? `<div class="sh-need">← ${need}</div>` : ''}
    ${p.review_soon ? `<div class="sh-need warn">المراجعة الدورية قبل ${esc(p.review_due)}</div>` : ''}
    ${p.readopt ? `<div class="sh-amend">🕌 إعادة اعتماد منتج اعتمدته الهيئة المركزية <b class="num">${esc(p.amends.code)}</b> — النص نفسه</div>` : ''}
    ${p.suspended_by_central ? '<div class="sh-need warn">معلّق إشرافياً من الهيئة المركزية</div>' : ''}
    ${p.type_allowed === false ? '<div class="sh-need warn">صيغته ممنوعة الآن من الهيئة المركزية</div>' : ''}
  </button>`;
}

// الجلسة 44: منتج معتمد مركزياً لمصرف هذه الهيئة (اطلاع فقط)
function inhCard(p) {
  return `<div class="eng-card sh-card ${p.status}" style="cursor:default">
    <div class="row"><b class="num">${esc(p.code)}</b><span class="tag">${esc(p.type)}</span><span class="sp"></span>${shBadge(p.status)}</div>
    <div class="eng-proj">${(SECTORS[p.sector] || ['•'])[0]} ${esc(p.name)}</div>
    <div class="small muted">${esc(p.type_name)} · ${esc(p.sector_label)}${p.resolution ? ` · قرار <span class="num">${esc(p.resolution.code)}</span>` : ''}</div>
    <div class="sh-amend">🕌 نافذ${p.review_due ? ` حتى <span class="num">${esc(p.review_due)}</span>` : ''}${p.live ? '' : ' — <b class="warn-t">حلّ موعد المراجعة: لا يظهر للمقترضين</b>'}${p.amending ? ` · لديكم الآن: <b class="num">${esc(p.amending.code)}</b> ${esc(p.amending.status_label)}` : ' · لم يُقدَّم لكم بعد'}</div></div>`;
}

// الجلسة 44: حالة نطاق الاعتماد في رأس البوابة
function scopeNotice() {
  const b = D.board, PAR = D.parent, me = D.me;
  if (PAR) {
    if (!me.fit) return `<div class="notice warn"><span>⏳</span><span class="small"><b>${esc(PAR.my_fit_label || 'بانتظار الملاءمة')}:</b> لا يُحسب صوتك ولا تصدر قراراً حتى تعتمد ${esc(PAR.name)} ملاءمتك.</span></div>`;
    if (!PAR.ready) return `<div class="notice warn"><span>🕌</span><span class="small"><b>الهيئة لم تكتمل بعد:</b> ${(PAR.missing || []).map(esc).join('، ')}. حتى تكتمل تُقدَّم منتجات ${esc(PAR.bank)} إلى ${esc(PAR.name)}.${me.head ? ' أضف الأعضاء من «فريقي» في الأعلى — تصل ترشيحاتهم الهيئة المركزية للملاءمة.' : ''}</span></div>`;
    if (!PAR.active) return `<div class="notice"><span>🕌</span><span class="small">اكتملت الهيئة. تبدأ اعتماد منتجات ${esc(PAR.bank)} حين تفعّل ${esc(PAR.name)} <b>النطاق المصرفي</b>.</span></div>`;
    return `<div class="notice ok-n"><span>🕌</span><span class="small">تعتمد الهيئة منتجات <b>${esc(PAR.bank)}</b>، وتطّلع ${esc(PAR.name)} على قراراتها ولها تعليق أي منتج.</span></div>`;
  }
  if (D.oversight) return `<div class="notice ${D.oversight.fit_pending ? 'warn' : ''}"><span>🕌</span><span class="small">نطاق الاعتماد: <b>${D.oversight.approval_scope === 'bank' ? 'مصرفي' : 'مركزي'}</b> — ${D.oversight.approval_scope === 'bank' ? 'كل مصرف اكتملت هيئته تعتمد منتجاته هيئته، وتبقى الهيئة إشرافية' : 'الهيئة تعتمد منتجات كل المصارف الإسلامية'}.
    ${D.oversight.fit_pending ? `<b><span class="num">${D.oversight.fit_pending}</span> عضو بانتظار ملاءمتكم</b> في «هيئات المصارف».` : ''}</span></div>`;
  return '';
}

// ───────── ملف المنتج ─────────
async function detail(ctx, id) {
  const { sb, root } = ctx;
  let P;
  try { P = await rpc(sb, 'sharia_product', { p_id: id }); }
  catch (e) { ctx.shOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const me = D.me, sup = P.side === 'supervisor', delib = P.status === 'deliberation' && !sup;
  ctx.shDiff = ctx.shDiff ?? !!P.previous;
  const back = () => { ctx.shOpen = null; render(ctx); };
  root.innerHTML = `
    <button class="btn ghost sm eng-back" data-back>→ ${sup ? 'هيئات المصارف' : 'كل المنتجات'}</button>
    ${sup ? `<div class="notice mb"><span>👁</span><span class="small"><b>اطلاع إشرافي:</b> الملف لدى <b>${esc(P.board_name)}</b>، وهي التي تتداول وتصوّت وتصدر القرار. للهيئة المركزية تعليق المنتج إشرافياً ورفع تعليقها.</span></div>` : ''}
    <div class="card sh-head">
      <div class="row"><b class="num">${esc(P.code)}</b><span class="tag">${esc(P.type)}</span><span class="sp"></span>${shBadge(P.status)}</div>
      <h2>${(SECTORS[P.sector] || ['•'])[0]} ${esc(P.name)}</h2>
      ${P.amends ? `<div class="sh-amend mb">✎ تعديل على المنتج المعتمد <b class="num">${esc(P.amends.code)}</b> — قارن بـ«الفروق عن النسخة السابقة» (النسخة المعتمدة النافذة). تبقى نافذة للمقترضين حتى يصدر قراركم.</div>` : ''}
      <p class="muted" style="margin:2px 0 8px">${esc(P.line || '')}</p>
      <dl class="kv sm"><dt>المصرف</dt><dd>${esc(P.bank)}</dd><dt>الهيئة</dt><dd>${esc(P.board_name)}${P.inherited ? ' <span class="tag">موروث — نافذ حتى تعيد هيئة المصرف اعتماده</span>' : ''}</dd><dt>الصيغة</dt><dd>${esc(P.type_name)} — ${esc(P.type_essence)}</dd><dt>القطاع</dt><dd>${esc(P.sector_label)}</dd>
        <dt>نسخة العقد</dt><dd><span class="num">${P.current?.n ?? '—'}</span> · البصمة ${shortSha(P.current?.sha256)}${P.approved_version ? ` · المعتمدة: <span class="num">${P.approved_version.n}</span>` : ''}</dd>
        ${P.status_note ? `<dt>ملاحظة</dt><dd>${esc(P.status_note)}</dd>` : ''}${P.review_due ? `<dt>المراجعة الدورية</dt><dd class="${P.review_soon ? 'warn-t' : ''}">${esc(P.review_due)}</dd>` : ''}</dl>
    </div>
    <div data-act></div>
    <div class="row sh-ctl"><h3 class="sh-sec" style="margin:0">نص العقد — النسخة <span class="num">${P.current?.n ?? '—'}</span></h3><span class="sp"></span>
      ${P.previous ? `<label class="sh-sw"><input type="checkbox" data-diff ${ctx.shDiff ? 'checked' : ''}> الفروق عن النسخة <span class="num">${P.previous.n}</span></label>` : ''}
      ${!sup && ['deliberation', 'submitted'].includes(P.status) && me.role !== 'sharia_secretary' ? '<button class="btn ghost sm" data-general>ملاحظة عامة</button>' : ''}</div>
    ${P.current?.change_note && P.current.n > 1 ? `<div class="notice"><span>✎</span><span class="small"><b>ما عدّله المصرف في النسخة <span class="num">${P.current.n}</span>:</b> ${esc(P.current.change_note)}</span></div>` : ''}
    ${contractHtml(P, { showDiff: ctx.shDiff, canComment: !sup && ['deliberation', 'submitted'].includes(P.status), canResolve: !sup })}
    <div class="grid g2 mt">
      <div class="card"><h3>ضوابط الصيغة على ${esc(P.board.madhhab_label)}</h3>
        <ul class="ticks">${(P.type_rules?.conditions || []).map(c => `<li>${esc(c)}</li>`).join('')}</ul>
        <h4 class="mt">الحرّاس الآليون بعد الاعتماد</h4><ol class="small">${(P.type_rules?.guards || []).map(c => `<li>${esc(c)}</li>`).join('')}</ol></div>
      <div class="card"><h3>بيانات المنتج</h3><dl class="kv sm">
        <dt>نسبة الربح</dt><dd>${P.pricing?.profit_min != null ? `<span class="num">${P.pricing.profit_min}%</span> – <span class="num">${P.pricing.profit_max}%</span> سنوياً` : '—'}</dd>
        <dt>المدة</dt><dd>${P.pricing?.term_max ? `<span class="num">${P.pricing.term_min || 1}</span> – <span class="num">${P.pricing.term_max}</span> شهراً` : '—'}</dd>
        <dt>الضمانات</dt><dd>${(P.guarantees || []).map(g => ({ single_salary: 'كفالة راتب', multi_salary: 'كفالة رواتب', mortgage: 'رهن عقار', gold: 'رهن ذهب' }[g] || g)).join('، ') || '—'}</dd>
        <dt>الملحقات</dt><dd>${(P.attachments || []).map(esc).join('، ') || '—'}</dd></dl></div>
    </div>
    ${P.votes.length ? `<h3 class="sh-sec">الأصوات على النسخة <span class="num">${P.current?.n}</span></h3><div class="card">${P.votes.map(v => `<div class="sh-vote"><b>${esc(v.name)}</b>${v.head ? ' <span class="tag">الرئيس</span>' : ''} ${badge(VOTE[v.vote])}${v.counts === false ? ' <span class="tag warn">لا يُحسب — دون ملاءمة</span>' : ''}
      ${v.condition ? `<div class="small">الشرط: ${esc(v.condition)}</div>` : ''}${v.reason ? `<div class="small">السبب: ${esc(v.reason)}</div>` : ''}<div class="small muted">${dt(v.at)}</div></div>`).join('')}</div>` : ''}
    ${P.resolutions_list.length ? `<h3 class="sh-sec">قرارات الهيئة على هذا المنتج</h3>${P.resolutions_list.map(resolutionHtml).join('')}` : ''}
    <details class="card mt"><summary><b>نسخ العقد (<span class="num">${P.version_list.length}</span>) والسجل الزمني</b></summary>
      <div class="sh-vers">${P.version_list.map(v => `<div><b>النسخة <span class="num">${v.n}</span></b> · ${esc(v.status)} · ${dt(v.at)} · ${esc(v.by || '')} · ${shortSha(v.sha256)}${v.change_note ? `<div class="small muted">${esc(v.change_note)}</div>` : ''}</div>`).join('')}</div>
      <ul class="sh-log">${P.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.who || '')}</b> ${l.side === 'bank' ? '<span class="tag">المصرف</span>' : ''} — ${esc(l.action)}${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>`;
  root.querySelector('[data-back]').onclick = sup ? () => { ctx.shOpen = null; ctx.shTab = 'banks'; render(ctx); } : back;
  const dsw = root.querySelector('[data-diff]'); if (dsw) dsw.onchange = () => { ctx.shDiff = dsw.checked; detail(ctx, id); };
  const reload = () => detail(ctx, id);
  root.querySelectorAll('[data-comment]').forEach(x => x.onclick = () => comment(ctx, P, Number(x.dataset.comment), reload));
  const g = root.querySelector('[data-general]'); if (g) g.onclick = () => comment(ctx, P, null, reload);
  root.querySelectorAll('[data-resolve]').forEach(x => x.onclick = async () => {
    try { await rpc(sb, 'sharia_comment_resolve', { p_review: x.dataset.resolve, p_resolved: true }); toast('عُلّم التعليق معالَجاً', 'ok'); reload(); } catch (e) { toast(cleanErr(e), 'bad'); }
  });
  actionCard(ctx, P, root.querySelector('[data-act]'), reload);
}

function comment(ctx, P, n, reload) {
  const cl = n ? P.current.clauses.find(c => c.n === n) : null;
  const m = modal(`<h3>${n ? `تعليق على البند <span class="num">${n}</span>: ${esc(cl?.title || '')}` : 'ملاحظة عامة على المنتج'}</h3>
    ${cl ? `<blockquote class="sh-q">${esc(cl.text)}</blockquote>` : ''}
    <div class="field"><label>تعليقك (يراه المصرف وبقية الأعضاء)</label><textarea class="input" rows="4" data-b placeholder="مثال: يُنص على أن الوعد غير ملزم…"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إرسال التعليق</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = async e => {
    e.target.disabled = true;
    try { await rpc(ctx.sb, 'sharia_comment', { p_id: P.id, p: { clause_n: n, body: m.el.querySelector('[data-b]').value } }); m.close(); toast('أُرسل التعليق للمصرف', 'ok'); reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  setTimeout(() => m.el.querySelector('[data-b]').focus(), 80);
}

// «المطلوب منك الآن» حسب دورك وحالة المنتج
function actionCard(ctx, P, box, reload) {
  const me = D.me, sb = ctx.sb;
  if (P.side === 'supervisor') {   // الجلسة 44: الهيئة المركزية — تعليق إشرافي ورفعه
    const can = me.central_head && (['approved', 'conditional'].includes(P.status) || (P.status === 'suspended' && P.suspended_by_central));
    box.innerHTML = `<div class="card sh-now calm"><h3>${P.status === 'deliberation' ? 'المداولة جارية لدى ' + esc(P.board_name) : esc(P.status_label)}</h3>
      ${P.status === 'deliberation' ? tallyHtml(P.tally) : ''}
      ${can ? `<p class="small muted">التعليق الإشرافي يوقف الطلبات الجديدة فوراً، ولا يرفعه إلا قرار من هيئتكم. العقود الموقّعة تبقى على نسختها.</p>
        <div class="row">${P.status === 'suspended' ? '<button class="btn cyan" data-pa="reinstate">رفع التعليق الإشرافي</button>' : '<button class="btn ghost" data-pa="suspend" style="color:var(--bad)">تعليق إشرافي</button>'}</div>`
        : P.status === 'suspended' ? '<p class="small muted">علّقته هيئة المصرف — ترفع تعليقها هي.</p>' : ''}</div>`;
    box.querySelectorAll('[data-pa]').forEach(x => x.onclick = () => postAction(ctx, P, x.dataset.pa, reload));
    return;
  }
  if (P.status === 'submitted' && (me.secretary || me.head)) {
    const ok = P.checklist.every(c => c.ok);
    box.innerHTML = `<div class="card sh-now"><h3>المطلوب منك الآن: التحقق من اكتمال الملف</h3>
      <ul class="sh-check">${P.checklist.map(c => `<li class="${c.ok ? 'ok' : 'no'}"><i>${c.ok ? '✓' : '✗'}</i>${esc(c.label)}</li>`).join('')}</ul>
      ${ok ? '<p class="small ok-t">الملف مكتمل — أحِله للأعضاء.</p>' : '<p class="small warn-t">في الملف نقص — أعِده للمصرف مع السبب، أو أحِله إن رأيت ذلك.</p>'}
      <div class="row mt"><button class="btn ghost" data-ret>إعادة للمصرف بسبب</button><span class="sp"></span><button class="btn cyan" data-ref>إحالة للأعضاء للمداولة ←</button></div></div>`;
    box.querySelector('[data-ref]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'sharia_screen', { p_id: P.id, p: { action: 'refer' } });
        await resultScreen({ title: 'أُحيل للأعضاء', msg: 'بدأت المداولة على بنود العقد والتصويت.', chips: ['رئيس الهيئة', 'الأعضاء', P.bank] }); reload(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
    box.querySelector('[data-ret]').onclick = () => {
      const miss = P.checklist.filter(c => !c.ok).map(c => '• ' + c.label).join('\n');
      const m = modal(`<h3>إعادة الملف للمصرف</h3><div class="field"><label>السبب (يصل المصرف كما تكتبه)</label><textarea class="input" rows="5" data-n>${esc(miss ? 'الملف ناقص:\n' + miss : '')}</textarea></div>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إعادة للمصرف</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      m.el.querySelector('[data-ok]').onclick = async e => {
        e.target.disabled = true;
        try { await rpc(sb, 'sharia_screen', { p_id: P.id, p: { action: 'return', note: m.el.querySelector('[data-n]').value } }); m.close();
          await resultScreen({ title: 'أُعيد للمصرف', msg: 'يصل المصرفَ السببُ ويعدّل ثم يقدّم من جديد.', chips: [P.bank] }); reload(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    };
    return;
  }
  if (P.status === 'deliberation') {
    const mv = P.votes.find(v => v.mine);
    box.innerHTML = `<div class="card sh-now"><h3>${me.voter ? (mv ? 'صوتك مسجّل — يمكنك تغييره حتى صدور القرار' : 'المطلوب منك الآن: صوّت على النسخة <span class="num">' + P.current.n + '</span>') : 'المداولة جارية'}</h3>
      ${tallyHtml(P.tally)}
      ${me.voter ? `<div class="sh-votebtns mt">${Object.entries(VOTE).map(([k, [t]]) => `<button type="button" class="sh-vb ${k} ${mv?.vote === k ? 'on' : ''}" data-v="${k}">${k === 'approve' ? '✓' : k === 'approve_cond' ? '◐' : '✗'} ${t}</button>`).join('')}</div>` : ''}
      ${me.head ? `<div class="row mt"><span class="small muted">بعد اكتمال النصاب تصدر القرار وتوقّعه برمز تحقق.</span><span class="sp"></span><button class="btn cyan" data-dec>إصدار القرار ←</button></div>` : ''}</div>`;
    box.querySelectorAll('[data-v]').forEach(x => x.onclick = () => vote(ctx, P, x.dataset.v, reload));
    const dec = box.querySelector('[data-dec]'); if (dec) dec.onclick = () => decide(ctx, P, reload);
    return;
  }
  if (me.head && ['approved', 'conditional', 'suspended'].includes(P.status)) {
    box.innerHTML = `<div class="card sh-now calm"><h3>المنتج ${P.status === 'suspended' ? 'معلّق — لا يظهر للمقترضين' : 'نافذ ويظهر للمقترضين'}</h3>
      <p class="small muted">${P.suspended_by_central ? '<b class="warn-t">علّقته الهيئة المركزية إشرافياً — لا يُرفع إلا بقرارها.</b> ' : ''}التعليق أو السحب يوقف الطلبات الجديدة فقط، والعقود الموقّعة تبقى على نسختها.</p>
      <div class="row">${P.status === 'suspended' ? (P.suspended_by_central ? '' : '<button class="btn cyan" data-pa="reinstate">رفع التعليق</button>') : '<button class="btn ghost" data-pa="suspend">تعليق مؤقت</button>'}
        <button class="btn ghost" data-pa="withdraw" style="color:var(--bad)">سحب الاعتماد</button></div></div>`;
    box.querySelectorAll('[data-pa]').forEach(x => x.onclick = () => postAction(ctx, P, x.dataset.pa, reload));
    return;
  }
  box.innerHTML = '';
}

function vote(ctx, P, v, reload) {
  const need = v === 'approve_cond' ? 'الشرط' : v === 'reject' ? 'سبب عدم الموافقة' : '';
  const go = async (extra = {}) => {
    try { const t = await rpc(ctx.sb, 'sharia_vote', { p_id: P.id, p: { vote: v, ...extra } });
      toast(`سُجّل صوتك: ${VOTE[v][0]}${t.proposed ? ` — النتيجة الآن: ${t.proposed_label}` : ''}`, 'ok'); reload(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
  if (!need) return go();
  const m = modal(`<h3>${VOTE[v][0]}</h3><div class="field"><label>${need} ★</label><textarea class="input" rows="4" data-t></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>تسجيل الصوت</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = () => { const t = m.el.querySelector('[data-t]').value; m.close(); go(v === 'approve_cond' ? { condition: t } : { reason: t }); };
}

function decide(ctx, P, reload) {
  const t = P.tally, prop = t.proposed;
  const opts = [['approved', 'اعتماد'], ['conditional', 'اعتماد مشروط'], ['returned', 'إعادة للتعديل'], ['rejected', 'رفض']];
  // المتاح: الإعادة دائماً، وغيرها فقط إن طابق نتيجة التصويت بعد اكتمال النصاب
  const allowed = k => k === 'returned' || (t.quorum_ok && k === prop);
  let sel = allowed(prop) ? prop : 'returned';
  const m = modal(`<h3>إصدار قرار الهيئة — ${esc(P.name)}</h3>${tallyHtml(t)}
    <label class="lbl mt">القرار</label><div class="sh-decs">${opts.map(([k, l]) => `<label class="${allowed(k) ? '' : 'off'} ${sel === k ? 'on' : ''}"><input type="radio" name="dc" value="${k}" ${sel === k ? 'checked' : ''} ${allowed(k) ? '' : 'disabled'}>${l}</label>`).join('')}</div>
    ${!t.quorum_ok ? `<p class="small warn-t">لم يكتمل النصاب (<span class="num">${t.cast}/${t.quorum}</span>) — المتاح الآن الإعادة للتعديل فقط.</p>` : ''}
    <div class="field mt"><label>نص القرار <span class="muted small" data-req>(اختياري للاعتماد — يُكتب تلقائياً)</span></label><textarea class="input" rows="4" data-b></textarea></div>
    <p class="small muted">يُختم القرار ببصمة نسخة العقد <span class="num">${P.current.n}</span> (${shortSha(P.current.sha256)})، وتوقّعه برمز تحقق.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>توقيع وإصدار</button></div>`, { wide: true });
  const req = m.el.querySelector('[data-req]');
  m.el.querySelectorAll('input[name=dc]').forEach(r => r.onchange = () => { sel = r.value; m.el.querySelectorAll('.sh-decs label').forEach(l => l.classList.toggle('on', l.querySelector('input').checked)); req.textContent = ['returned', 'rejected'].includes(sel) ? '★ (السبب مطلوب)' : '(اختياري للاعتماد — يُكتب تلقائياً)'; });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = async () => {
    const body = m.el.querySelector('[data-b]').value;
    if (['returned', 'rejected'].includes(sel) && body.trim().length < 5) return toast('اكتب نص القرار وسببه', 'bad');
    m.close();
    let res;
    const tk = await signOtp(ctx, { title: 'توقيع قرار الهيئة', purpose: `${DECISION[sel][0]}: ${P.name}`,
      verify: async otp => { res = await rpc(ctx.sb, 'sharia_decide', { p_id: P.id, p: { decision: sel, body, otp } }); } });
    if (!tk || !res) return;
    await resultScreen({ ok: true, title: `صدر القرار: ${res.decision_label}`, ref: res.code,
      msg: ['approved', 'conditional'].includes(res.decision) ? 'المنتج يظهر الآن للمقترضين في المصرف، بالنسخة المعتمدة حرفياً.' : 'وصل القرار وسببه إلى المصرف.',
      chips: [P.bank, 'البنك المركزي العراقي', 'سجل قرارات الهيئة'], seal: res.seal });
    reload();
  };
}

async function postAction(ctx, P, act, reload) {
  const L = { suspend: ['تعليق مؤقت', 'سبب التعليق'], reinstate: ['رفع التعليق', ''], withdraw: ['سحب الاعتماد', 'سبب السحب'] }[act];
  let note = '';
  if (L[1]) {
    note = await new Promise(res => {
      const m = modal(`<h3>${L[0]} — ${esc(P.name)}</h3><div class="field"><label>${L[1]} ★</label><textarea class="input" rows="4" data-t></textarea></div>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>متابعة</button></div>`, { onClose: () => res(null) });
      m.el.querySelector('[data-x]').onclick = m.close;
      m.el.querySelector('[data-ok]').onclick = () => { const v = m.el.querySelector('[data-t]').value; if (v.trim().length < 5) return toast('اكتب السبب', 'bad'); res(v); m.close(); };
    });
    if (note == null) return;
  }
  let r;
  const tk = await signOtp(ctx, { title: `توقيع: ${L[0]}`, purpose: P.name,
    verify: async otp => { r = await rpc(ctx.sb, 'sharia_post_action', { p_id: P.id, p: { action: act, note, otp } }); } });
  if (!tk || !r) return;
  await resultScreen({ title: `صدر القرار: ${L[0]}`, ref: r.code, msg: act === 'reinstate' ? 'عاد المنتج للظهور للمقترضين.' : 'توقف عرض المنتج للطلبات الجديدة. العقود الموقّعة تبقى على نسختها.', chips: [P.bank, 'البنك المركزي العراقي'] });
  reload();
}

// ───────── سجل القرارات ─────────
// الجلسة 43: عمود «توقيع الرئيس» — يوقّع الرئيس قراره توقيعاً إلكترونياً موثوقاً (الوجه وبصمة الجهاز) عبر خدمة التوقيع
const ES = { signed: ['موقّع إلكترونياً ✓', 'ok'], sent: ['بانتظار توقيعك', 'warn'], expired: ['انتهى الرابط', 'bad'], cancelled: ['أُلغي', 'muted'], failed: ['تعذّر', 'bad'], manual_review: ['حضورياً', 'warn'] };
async function resList(ctx, body) {
  if (!D.resolutions.length) { body.innerHTML = '<div class="card empty">لم تصدر قرارات بعد</div>'; return; }
  let es = [];
  try { es = await rpc(ctx.sb, 'sharia_esign_list'); } catch { es = []; }
  const E = Object.fromEntries((es || []).map(x => [x.code, x])), head = D.me.head;
  const unsigned = es.filter(x => x.mine && x.status !== 'signed').length;
  body.innerHTML = `${head && unsigned ? `<div class="notice warn mb"><span>✍️</span><span><b><span class="num">${unsigned}</span> من قراراتك نافذة برمز التحقق ولم توقّعها توقيعاً إلكترونياً موثوقاً بعد.</b> اضغط «✍ وقّع»: تقرأ القرار ثم يُطابَق وجهك مع صورتك المرجعية وتؤكّد ببصمة جهازك، فتُحفظ نسخة PDF موقّعة بشهادة.</span></div>` : ''}
    <div class="card"><div class="tbl-wrap"><table class="tbl sh-rtbl"><thead><tr><th>رقم القرار</th><th>القرار</th><th>توقيع الرئيس</th><th>المنتج</th><th>المصرف</th><th>النسخة</th><th>التاريخ</th><th>الختم</th></tr></thead><tbody>
    ${D.resolutions.map(r => { const e = E[r.code] || {}, st = e.status;
      return `<tr data-open="${r.product_id}" style="cursor:pointer"><td class="num" style="white-space:nowrap"><b>${esc(r.code)}</b></td><td>${badge(DECISION[r.decision] || [r.decision, 'muted'])}</td><td class="sh-es">${st === 'signed' ? `${badge(ES.signed)} <button type="button" class="linkbtn" data-pdf="${e.id}">PDF</button>`
        : e.mine ? `${st ? badge(ES[st] || [st, 'muted']) + ' ' : ''}${st === 'sent' && e.url ? `<a class="btn sm cyan" href="${esc(e.url)}" target="_blank" rel="noopener" data-stop>أكمل ✍</a>` : `<button type="button" class="btn sm cyan" data-esign="${e.id}">✍ وقّع</button>`}`
        : badge(st ? ES[st] || [st, 'muted'] : ['رمز تحقق', 'muted'])}</td><td>${esc(r.product)}</td><td>${esc(r.bank)}</td><td class="num">${r.version ?? '—'}</td><td>${dt(r.issued_at)}</td><td>${shortSha(r.seal)}</td></tr>`; }).join('')}
    </tbody></table></div></div>`;
  body.querySelectorAll('[data-open]').forEach(x => x.onclick = e => { if (e.target.closest('[data-pdf],[data-esign],[data-stop]')) return; ctx.shOpen = x.dataset.open; ctx.shTab = 'work'; window.scrollTo(0, 0); render(ctx); });
  body.querySelectorAll('[data-pdf]').forEach(b => b.onclick = () => openResPdf(ctx, b.dataset.pdf));
  body.querySelectorAll('[data-esign]').forEach(b => b.onclick = () => esignRes(ctx, b.dataset.esign, b, () => resList(ctx, body)));
}
export async function openResPdf(ctx, id) {
  try { const d = await rpc(ctx.sb, 'sharia_resolution_pdf', { p_res: id });
    const m = modal(`<h3>القرار الموقّع إلكترونياً</h3><p class="small muted">النسخة كما وصلت من خدمة التوقيع، بشهادة التوقيع الملحقة.</p><div class="row"><a class="btn cyan" href="${d}" download="sharia-resolution.pdf">فتح ملف PDF</a><span class="sp"></span><button class="btn ghost" data-x>إغلاق</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
  } catch (e) { toast(cleanErr(e), 'bad'); }
}
async function esignRes(ctx, id, btn, again) {
  btn.disabled = true; const t = btn.textContent; btn.textContent = 'جارِ تجهيز القرار…';
  try {
    const tk = (await ctx.sb.auth.getSession()).data.session?.access_token || '';
    const r = await fetch('/api/esign/sharia/start', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tk}` }, body: JSON.stringify({ res_id: id }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'تعذّر الاتصال بخدمة التوقيع');
    toast('افتح صفحة التوقيع: اقرأ القرار، ثم صوّر وجهك وأكّد ببصمة جهازك', 'ok');
    if (j.signing_url) location.href = j.signing_url;
  } catch (e) {
    toast(cleanErr(e), 'bad'); btn.disabled = false; btn.textContent = t;
    if (/صورتك المرجعية/.test(e.message)) { ctx.shTab = 'board'; render(ctx); }
  }
  again?.();
}

// ───────── مكتبة الصيغ ─────────
function library(body, ctx) {
  body.innerHTML = `<div class="notice"><span>ℹ</span><span class="small">ملخص لضوابط التصميم على ${esc(D.board.madhhab_label)}. <b>النص الفقهي النهائي لكل صيغة وشروطها تعتمده الهيئة</b>، والحرّاس الآليون يمنعون أي خطوة تخالفها في مسار المصرف الإسلامي.</span></div>
    ${D.me.central_head ? '<p class="small muted">بصفتكم الهيئة المركزية تحددون <b>الصيغ المسموحة</b> لكل المصارف: الصيغة الممنوعة لا يُنشأ عليها منتج ولا تعتمدها أي هيئة. المنتجات النافذة عليها تبقى حتى تعلّقوها.</p>'
      : D.parent ? `<p class="small muted">الصيغ المسموحة تحددها ${esc(D.parent.name)}.</p>` : ''}
    <div class="sh-lib">${D.types.map(t => `<details class="card sh-type ${t.allowed ? '' : 'off'}"><summary><b class="num">${esc(t.code)}</b> <b>${esc(t.name)}</b> <span class="small muted">— ${esc(t.essence)}</span>
      <span class="sp"></span>${t.allowed ? '' : '<span class="tag warn">ممنوعة الآن</span>'}${t.sectors.map(s => `<span class="tag">${(SECTORS[s] || ['', s])[0]} ${(SECTORS[s] || ['', s])[1]}</span>`).join('')}</summary>
      ${D.me.central_head ? `<div class="row mb"><span class="small">${t.allowed ? 'مسموحة لكل المصارف' : 'ممنوعة — لا يُعتمد عليها منتج جديد'}</span><span class="sp"></span><button type="button" class="btn ghost sm" data-allow="${esc(t.code)}" data-v="${t.allowed ? 0 : 1}">${t.allowed ? 'منع الصيغة' : 'السماح بالصيغة'}</button></div>` : ''}
      <p class="small"><b>للمقترض:</b> ${esc(t.borrower_line)}</p>
      <h4>الضوابط</h4><ul class="ticks">${(t.rules.conditions || []).map(c => `<li>${esc(c)}</li>`).join('')}</ul>
      <h4>الحرّاس الآليون</h4><ol class="small">${(t.rules.guards || []).map(c => `<li>${esc(c)}</li>`).join('')}</ol></details>`).join('')}</div>
    <div class="card mt"><h3>ضابط عام في كل الصيغ — التأخر في السداد</h3><p class="small">يُمنع آلياً احتساب أي زيادة على الدين المتأخر لمصلحة المصرف. ما يُسمح به يحدده قرار الهيئة: المطالبة والضمانات، أو التعويض عن ضرر فعلي إن أقرّته، أو شرط تبرّع لصندوق خيري لا يدخل إيرادات المصرف.</p>
      ${D.board.late_rule ? `<p class="small"><b>قاعدة الهيئة الحالية:</b> ${esc(D.board.late_rule)}</p>` : ''}</div>`;
  body.querySelectorAll('[data-allow]').forEach(b => b.onclick = async e => {
    e.preventDefault();
    const allow = b.dataset.v === '1', t = D.types.find(x => x.code === b.dataset.allow);
    let note = null;
    if (!allow) { note = await askText(`منع الصيغة: ${t.name}`, 'سبب المنع (يصل هيئات المصارف)'); if (note == null) return; }
    try { const r = await rpc(ctx.sb, 'sharia_type_allow', { p_code: t.code, p_allowed: allow, p_note: note });
      toast(allow ? `سُمح بالصيغة ${t.name}` : `مُنعت الصيغة ${t.name}${r.live_products ? ` — ${r.live_products} منتج نافذ عليها يبقى حتى تعلّقوه` : ''}`, 'ok'); ctx.shTab = 'lib'; render(ctx); }
    catch (er) { toast(cleanErr(er), 'bad'); }
  });
}

// نافذة نص قصير (سبب) — تعيد النص أو null عند الإلغاء
function askText(title, label, min = 5) {
  return new Promise(res => {
    const m = modal(`<h3>${esc(title)}</h3><div class="field"><label>${esc(label)} ★</label><textarea class="input" rows="4" data-t></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>متابعة</button></div>`, { onClose: () => res(null) });
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-ok]').onclick = () => { const v = m.el.querySelector('[data-t]').value; if (v.trim().length < min) return toast('اكتب السبب', 'bad'); res(v); m.close(); };
    setTimeout(() => m.el.querySelector('[data-t]').focus(), 80);
  });
}

// ───────── الجلسة 44: هيئات المصارف (للهيئة المركزية) ─────────
const FIT = { pending: ['بانتظار الملاءمة', 'warn'], approved: ['ملاءمة معتمدة', 'ok'], rejected: ['لم تُعتمد', 'bad'], revoked: ['سُحبت الملاءمة', 'bad'] };
function memRow(m, b, head) {
  const pend = m.fit_status === 'pending';
  return `<div class="sh-mem ${pend ? 'pend' : ''}"><span class="av sm">${esc(m.name.replace(/^(الشيخ|السيد|د\.|م\.)\s*/g, '').trim()[0] || '؟')}</span>
    <div style="flex:1;min-width:0"><b>${esc(m.name)}</b><div class="small muted">${esc(m.role_title)}${m.specialty ? ' · ' + esc(m.specialty) : ''}${m.username ? ` · <span class="num" dir="ltr">${esc(m.username)}</span>` : ''}</div>
      <div class="small">${badge(FIT[m.fit_status] || [m.fit_status, 'muted'])}${m.fit_code ? ` <span class="num muted">${esc(m.fit_code)}</span>` : ''}${m.fit_at ? ` <span class="muted">${dt(m.fit_at)}</span>` : ''}${m.fit_note && !pend ? `<div class="muted">${esc(m.fit_note)}</div>` : ''}</div></div>
    ${head && b ? (pend ? `<div class="row" style="gap:6px"><button type="button" class="btn ghost sm" data-fit="reject" data-b="${b.id}" data-m="${m.profile_id}">لا</button><button type="button" class="btn cyan sm" data-fit="approve" data-b="${b.id}" data-m="${m.profile_id}">اعتماد الملاءمة</button></div>`
      : m.fit_status === 'approved' && m.role !== 'sharia_head' ? `<button type="button" class="linkbtn small" data-fit="revoke" data-b="${b.id}" data-m="${m.profile_id}" style="color:var(--bad)">سحب</button>` : '') : ''}</div>`;
}
function banksView(ctx, body) {
  const OV = D.oversight, head = D.me.central_head;
  const pend = OV.boards.flatMap(b => b.members.filter(m => m.fit_status === 'pending').map(m => ({ b, m })));
  const others = OV.bank_products;
  body.innerHTML = `
    <div class="card mb"><div class="row" style="flex-wrap:wrap;gap:8px"><h3 style="margin:0">الهيئة المركزية جهة إشراف</h3><span class="sp"></span>
      ${head && OV.banks_without.length ? '<button type="button" class="btn cyan sm" data-newb>＋ هيئة لمصرف</button>' : ''}</div>
      <ul class="small" style="margin:8px 0 0;padding-inline-start:18px;line-height:1.9">
        <li>لكل مصرف إسلامي هيئته، تعتمد منتجات مصرفها فقط — بنصاب من أعضاء <b>تعتمدون ملاءمتهم</b>.</li>
        <li>تحددون الصيغ المسموحة («مكتبة الصيغ»)، وتطّلعون على كل قرارات هيئات المصارف، ولكم <b>تعليق أي منتج</b>.</li>
        <li>نطاق الاعتماد الآن: <b>${OV.approval_scope === 'bank' ? 'مصرفي' : 'مركزي'}</b> — يُغيَّر من «الهيئة والإعدادات». الاعتمادات المركزية السابقة تبقى نافذة حتى تعيد هيئة المصرف اعتمادها أو يحلّ موعد مراجعتها.</li></ul>
      ${OV.banks_without.length ? `<p class="small warn-t" style="margin:6px 0 0">مصارف إسلامية بلا هيئة: ${OV.banks_without.map(b => esc(b.name)).join('، ')}</p>` : ''}</div>
    ${pend.length ? `<h3 class="sh-sec">المطلوب منكم الآن: ملاءمة <span class="num">${pend.length}</span> عضو</h3>
      <div class="card mb">${pend.map(({ b, m }) => `<div class="small muted" style="margin-top:6px">${esc(b.name)}</div>${memRow(m, b, head)}`).join('')}
      <p class="small muted" style="margin:8px 0 0">لا يُحسب صوت العضو في النصاب والقرار حتى تعتمدوا ملاءمته. القرار يوقَّع برمز تحقق ويصل العضو ورئيس هيئته.</p></div>` : ''}
    <h3 class="sh-sec">هيئات المصارف</h3>
    ${OV.boards.length ? `<div class="grid g2">${OV.boards.map(b => `<div class="card sh-bb ${b.active ? 'on' : ''}">
      <div class="row"><b>${esc(b.name)}</b><span class="sp"></span>${b.active ? badge(['تعتمد الآن', 'ok']) : b.ready ? badge(['مكتملة — بانتظار النطاق المصرفي', 'warn']) : badge(['غير مكتملة', 'warn'])}</div>
      <div class="small muted">${esc(b.bank)} · <span class="num">${esc(b.code)}</span> · النصاب <span class="num">${b.quorum}</span> · مصوّتون بملاءمة <span class="num">${b.voters}</span></div>
      ${b.missing.length ? `<div class="sh-need warn">ينقص: ${b.missing.map(esc).join('، ')}</div>` : ''}
      <div class="row small mt" style="gap:12px;flex-wrap:wrap"><span>نافذة <b class="num">${b.products_live}</b></span><span>قيد الاعتماد <b class="num">${b.products_open}</b></span>
        <span>موروثة من المركزية <b class="num">${b.inherited}</b></span><span>قرارات <b class="num">${b.resolutions}</b></span></div>
      <div class="mt">${b.members.map(m => memRow(m, b, head)).join('') || '<p class="small muted">لا أعضاء بعد — يضيفهم رئيس الهيئة من «فريقي».</p>'}</div>
      ${b.log.length ? `<details class="mt"><summary class="small"><b>سجل الهيئة</b></summary><ul class="sh-log">${b.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.who || '')}</b> — ${esc(l.action)}${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>` : ''}
    </div>`).join('')}</div>` : '<div class="card empty">لم تُنشأ هيئة لأي مصرف بعد.</div>'}
    <h3 class="sh-sec">منتجات لدى هيئات المصارف (<span class="num">${others.length}</span>)</h3>
    ${others.length ? `<div class="eng-cards">${others.map(p => card(p)).join('')}</div>` : '<div class="card empty">لا منتجات مقدَّمة لهيئات المصارف بعد</div>'}
    <h3 class="sh-sec">قرارات هيئات المصارف (<span class="num">${OV.bank_resolutions.length}</span>)</h3>
    ${OV.bank_resolutions.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم القرار</th><th>القرار</th><th>الهيئة</th><th>المنتج</th><th>النسخة</th><th>التاريخ</th><th>الختم</th></tr></thead><tbody>
      ${OV.bank_resolutions.map(r => `<tr data-open="${r.product_id}" style="cursor:pointer"><td class="num"><b>${esc(r.code)}</b></td><td>${badge(DECISION[r.decision] || [r.decision, 'muted'])}</td><td class="small">${esc(r.board)}</td><td>${esc(r.product)}</td><td class="num">${r.version ?? '—'}</td><td>${dt(r.issued_at)}</td><td>${shortSha(r.seal)}</td></tr>`).join('')}
      </tbody></table></div></div>` : '<div class="card empty">لم تصدر هيئات المصارف قرارات بعد</div>'}
    ${OV.log.length ? `<details class="card mt"><summary><b>سجل الإشراف</b></summary><ul class="sh-log">${OV.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.who || '')}</b> — ${esc(l.action)}${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>` : ''}`;
  body.querySelectorAll('[data-open]').forEach(x => x.onclick = () => { ctx.shOpen = x.dataset.open; window.scrollTo(0, 0); render(ctx); });
  body.querySelectorAll('[data-fit]').forEach(x => x.onclick = () => fitDecide(ctx, x.dataset.b, x.dataset.m, x.dataset.fit));
  const nb = body.querySelector('[data-newb]'); if (nb) nb.onclick = () => newBoard(ctx);
}

async function fitDecide(ctx, boardId, memberId, d) {
  const b = D.oversight.boards.find(x => x.id === boardId), m = b?.members.find(x => x.profile_id === memberId);
  if (!m) return;
  const L = { approve: 'اعتماد الملاءمة', reject: 'عدم اعتماد الملاءمة', revoke: 'سحب الملاءمة' }[d];
  let note = null;
  if (d !== 'approve') { note = await askText(`${L}: ${m.name}`, 'السبب (يصل العضو ورئيس هيئته)'); if (note == null) return; }
  let r;
  const tk = await signOtp(ctx, { title: `توقيع: ${L}`, purpose: `${m.name} — ${b.name}`,
    verify: async otp => { r = await rpc(ctx.sb, 'sharia_fit_decide', { p_board: boardId, p_profile: memberId, p: { decision: d, note, otp } }); } });
  if (!tk || !r) return;
  await resultScreen({ ok: r.status === 'approved', title: r.status_label, ref: r.code,
    msg: r.status === 'approved' ? `صار صوت ${m.name} يُحسب. ${r.ready ? 'الهيئة مكتملة النصاب.' : ''}` : `لا يُحسب صوت ${m.name}.${r.ready ? '' : ' الهيئة لم تكتمل الآن — تُقدَّم منتجات مصرفها إلى الهيئة المركزية حتى تكتمل.'}`,
    chips: [m.name, b.name] });
  ctx.shTab = 'banks'; render(ctx);
}

function newBoard(ctx) {
  const OV = D.oversight;
  const m = modal(`<h3>＋ هيئة رقابة شرعية لمصرف</h3>
    <p class="small muted">تُنشأ جهة الهيئة وحساب رئيسها (يغيّر كلمة المرور عند أول دخول). يضيف الرئيس الأعضاء وأمين السر من «فريقي»، وتصلكم ترشيحاتهم للملاءمة.</p>
    <form data-f class="grid" style="gap:10px">
      <div class="field"><label>المصرف الإسلامي ★</label><select class="input" name="bank">${OV.banks_without.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('')}</select></div>
      <div class="field"><label>اسم الهيئة</label><input class="input" name="name" placeholder="هيئة الرقابة الشرعية — اسم المصرف"></div>
      <div class="field"><label>النصاب (عدد المصوّتين)</label><input class="input" name="quorum" type="number" min="2" max="9" value="2" dir="ltr"><small class="muted">رئيس + عضو على الأقل.</small></div>
      <h4 style="margin:6px 0 0">رئيس الهيئة</h4>
      <div class="field"><label>الاسم الكامل ★</label><input class="input" name="hname"></div>
      <div class="field"><label>التخصص</label><input class="input" name="hspec" placeholder="فقه المعاملات"></div>
      <div class="grid g2" style="gap:10px"><div class="field"><label>اسم المستخدم ★</label><input class="input" name="huser" dir="ltr" autocapitalize="off" placeholder="xsh.head"></div>
        <div class="field"><label>كلمة مرور مؤقتة ★</label><input class="input" name="hpw" dir="ltr" autocapitalize="off" placeholder="8 أحرف وأرقام"></div></div>
      <div class="field"><label>الهاتف (لرمز التحقق عند توقيع القرارات)</label><input class="input" name="hphone" dir="ltr" inputmode="tel" placeholder="07XXXXXXXXX"></div>
      <div class="row"><span class="sp"></span><button type="button" class="btn ghost" data-x>إلغاء</button><button class="btn cyan">إنشاء الهيئة</button></div></form>`, { wide: true });
  const f = m.el.querySelector('[data-f]');
  m.el.querySelector('[data-x]').onclick = m.close;
  f.onsubmit = async e => {
    e.preventDefault();
    const p = { bank_id: f.bank.value, name: f.name.value, quorum: f.quorum.value, head: { full_name: f.hname.value, specialty: f.hspec.value, username: f.huser.value, password: f.hpw.value, phone: f.hphone.value } };
    if (p.head.full_name.trim().length < 3 || p.head.username.trim().length < 3 || p.head.password.length < 8) return toast('أكمل بيانات رئيس الهيئة', 'bad');
    m.close();
    let r;
    const tk = await signOtp(ctx, { title: 'توقيع: إنشاء هيئة لمصرف', purpose: OV.banks_without.find(b => b.id === p.bank_id)?.name || '',
      verify: async otp => { r = await rpc(ctx.sb, 'sharia_board_create', { p: { ...p, otp } }); } });
    if (!tk || !r) return;
    await resultScreen({ ok: true, title: 'أُنشئت الهيئة', ref: r.board, msg: `دخول رئيس الهيئة من بوابة الهيئة الشرعية باسم المستخدم «${r.username}» وكلمة المرور المؤقتة. يضيف أعضاءه من «فريقي».`, chips: [r.name] });
    ctx.shTab = 'banks'; render(ctx);
  };
}

// ───────── الهيئة والإعدادات ─────────
function boardView(ctx, body) {
  const b = D.board, head = D.me.head;
  body.innerHTML = `${head ? '<div data-face></div>' : ''}<div class="grid g2">
    <div class="card"><h3>أعضاء الهيئة</h3>${b.scope === 'bank' ? b.members.map(m => memRow(m, null, false)).join('') : b.members.map(m => `<div class="sh-mem"><span class="av sm">${esc(m.name.replace(/^(الشيخ|السيد|د\.|م\.)\s*/g, '').trim()[0] || '؟')}</span><div><b>${esc(m.name)}</b><div class="small muted">${esc(m.role_title)}${m.specialty ? ' · ' + esc(m.specialty) : ''} · <span class="num">${esc(m.code || '')}</span></div></div></div>`).join('')}
      <p class="small muted mt">${head ? 'تضيف عضواً جديداً من «فريقي» في الأعلى.' : ''} ${b.scope === 'bank'
        ? `هيئة <b>${esc(b.bank || '')}</b> بإشراف ${esc(D.parent?.name || 'الهيئة المركزية')}. العضو الجديد يُرشَّح تلقائياً للملاءمة، ولا يُحسب صوته حتى تعتمدها.`
        : `نطاق الاعتماد الآن: <b>${b.approval_scope === 'bank' ? 'مصرفي — كل مصرف اكتملت هيئته تعتمد منتجاته هيئته' : 'مركزي — هيئة واحدة لكل المصارف الإسلامية'}</b>.`}</p></div>
    <div class="card"><h3>إعدادات الهيئة</h3>
      <form data-f class="grid" style="gap:10px">
        <div class="field"><label>اسم الهيئة</label><input class="input" name="name" value="${esc(b.name)}" ${head ? '' : 'disabled'}></div>
        <div class="field"><label>المذهب</label><input class="input" value="${esc(b.madhhab_label)}" disabled><small class="muted">قرار المستخدم: كل الصيغ على المذهب الجعفري.</small></div>
        ${b.scope === 'central' ? `<div class="field"><label>نطاق الاعتماد</label><select class="input" name="approval_scope" ${head ? '' : 'disabled'}>
          <option value="central" ${b.approval_scope !== 'bank' ? 'selected' : ''}>مركزي — الهيئة المركزية تعتمد منتجات كل المصارف</option>
          <option value="bank" ${b.approval_scope === 'bank' ? 'selected' : ''}>مصرفي — هيئة كل مصرف تعتمد منتجاته متى اكتملت</option></select>
          <small class="muted">القرارات المركزية السابقة تبقى نافذة حتى تعيد هيئة المصرف اعتمادها أو يحلّ موعد مراجعتها. ما هو قيد المداولة لديكم يكمل لديكم.</small></div>` : ''}
        <div class="field"><label>المرجع الذي تُعتمد فتاواه</label><input class="input" name="marja" value="${esc(b.marja || '')}" placeholder="تحدده الهيئة" ${head ? '' : 'disabled'}></div>
        <div class="grid g2" style="gap:10px">
          <div class="field"><label>النصاب (عدد المصوّتين)</label><input class="input" name="quorum" type="number" min="1" max="${b.voters}" value="${b.quorum}" dir="ltr" ${head ? '' : 'disabled'}></div>
          <div class="field"><label>المراجعة الدورية (شهر)</label><input class="input" name="review_months" type="number" min="1" max="60" value="${b.review_months}" dir="ltr" ${head ? '' : 'disabled'}></div></div>
        <div class="field"><label>قاعدة الأغلبية</label><select class="input" name="majority" ${head ? '' : 'disabled'}><option value="simple" ${b.majority === 'simple' ? 'selected' : ''}>أغلبية بسيطة</option><option value="two_thirds" ${b.majority === 'two_thirds' ? 'selected' : ''}>ثلثا الأصوات</option></select></div>
        <label class="row small"><input type="checkbox" name="chair_casting" ${b.chair_casting ? 'checked' : ''} ${head ? '' : 'disabled'}> صوت الرئيس مرجّح عند التساوي</label>
        <div class="field"><label>معالجة التأخر في السداد</label><select class="input" name="late_kind" ${head ? '' : 'disabled'}>
          ${[['claim', 'المطالبة والرجوع إلى الضمانات'], ['damage', 'تعويض عن ضرر فعلي تقرّه الهيئة'], ['charity', 'التزام بالتبرع لصندوق خيري (لا يدخل إيرادات المصرف)']].map(([k, t]) => `<option value="${k}" ${(b.late_kind || 'claim') === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
          <small class="muted">في كل الأحوال: يمنع النظام آلياً أي زيادة على الدين المتأخر لمصلحة المصرف في جدول الأقساط والتحصيل.</small></div>
        <div class="field"><label>نص القاعدة كما يراه المقترض والتحصيل</label><textarea class="input" name="late_rule" rows="3" ${head ? '' : 'disabled'}>${esc(b.late_rule || '')}</textarea></div>
        ${head ? '<div class="row"><span class="sp"></span><button class="btn cyan">حفظ الإعدادات</button></div>' : '<p class="small muted">الإعدادات يضبطها رئيس الهيئة.</p>'}
      </form></div></div>`;
  const f = body.querySelector('[data-f]');
  if (head) f.onsubmit = async e => {
    e.preventDefault();
    const p = { name: f.name.value, marja: f.marja.value, quorum: f.quorum.value, review_months: f.review_months.value, majority: f.majority.value, chair_casting: f.chair_casting.checked, late_kind: f.late_kind.value, late_rule: f.late_rule.value,
      ...(f.approval_scope ? { approval_scope: f.approval_scope.value } : {}) };
    try { await rpc(ctx.sb, 'sharia_settings', { p }); toast('حُفظت إعدادات الهيئة', 'ok'); render(ctx); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
  if (head) faceCard(ctx, body.querySelector('[data-face]'));
}

// الجلسة 43: الصورة المرجعية لوجه الرئيس — تُطابَق مع وجهه عند كل توقيع إلكتروني لقرار
async function faceCard(ctx, box) {
  let F = null;
  try { F = await rpc(ctx.sb, 'sharia_face_status'); } catch { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="card mb sh-face"><div class="row" style="gap:12px;flex-wrap:wrap">${F.has ? `<img src="${esc(F.data)}" alt="" class="sh-face-img">` : '<span class="sh-face-img empty">👤</span>'}
    <div style="flex:1;min-width:200px"><h3 style="margin:0">التوقيع الإلكتروني الموثوق للقرارات</h3>
    <p class="small muted" style="margin:4px 0 0">${F.has ? `صورتك المرجعية مضافة (${dt(F.at)}). عند توقيع قرار: تقرأه، ثم يُطابَق وجهك مع هذه الصورة مع كشف الحيوية، ثم تؤكّد ببصمة جهازك — وتُحفظ نسخة PDF موقّعة بشهادة.` : '<b>الخطوة الأولى:</b> صوّر الوجه الأمامي لبطاقتك الوطنية الموحدة (أو وجهك من الأمام). تُستخدم للمطابقة عند كل توقيع.'}</p></div>
    <button type="button" class="btn ${F.has ? 'ghost' : 'cyan'}" data-shoot>${F.has ? 'تغيير الصورة المرجعية' : 'تصوير الصورة المرجعية'}</button></div></div>`;
  box.querySelector('[data-shoot]').onclick = async () => {
    const { cameraCapture } = await import('../capture.js');
    const r = await cameraCapture({ title: 'الصورة المرجعية لوجهك', hint: 'صوّر وجه البطاقة الوطنية الموحدة بوضوح دون انعكاس، أو وجهك من الأمام', ratio: 0.63, allowFile: true });
    if (!r) return;
    if (!String(r.data).startsWith('data:image/')) return toast('الصورة المرجعية يجب أن تكون صورة لا ملف PDF', 'bad');
    try { await rpc(ctx.sb, 'sharia_face_set', { p_data: r.data }); toast('حُفظت صورتك المرجعية', 'ok'); faceCard(ctx, box); } catch (e) { toast(cleanErr(e), 'bad'); }
  };
}
