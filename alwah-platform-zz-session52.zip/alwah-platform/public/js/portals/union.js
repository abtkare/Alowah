// الجلسة 52: بوابة اتحاد الصناعات العراقي
// قسم العضوية والتسجيل: يدقق ويحيل للكشف أو يعيد · المهندس: يكشف على المعمل بالـGPS والصور ويقدّر الموجودات وأسعار المكائن
// لجنة الصنف: توصي · الأمين العام: يقرر ويصدر الكتاب المختوم، ويسحب الكتاب ويعلّق العضوية · الحسابات: الأجور
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, mapsLink, iqd, num, resultScreen, IND_CATS, GUARANTEE } from '../core.js';
import { UF_ST, UF_KIND, UM_ST, SITE_ST, REC, ufBadge, umBadge, catLabel, stepsBar, letterHtml, openLetter, memberCard } from '../union-ui.js';

let D;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg,.un-act');

const ROLE_IC = { union_sg: '🏛', union_reg: '🗂', union_eng: '📍', union_committee: '⚖️', union_fin: '💳' };
const money = v => String(v ?? '').replace(/[^0-9]/g, '');
const fmt = v => v ? Number(v).toLocaleString('en-US') : '';
const ACTIVE = ['new', 'inspection', 'committee', 'signing'];

function mine(me) {
  const r = me.role;
  return D.files.filter(f =>
    (f.status === 'new' && ['union_reg', 'union_sg'].includes(r)) ||
    (f.status === 'inspection' && f.engineer_id === me.id) ||
    (f.status === 'committee' && r === 'union_committee') ||
    (f.status === 'signing' && r === 'union_sg'));
}
const hint = r => ({ union_reg: 'تصلك المعاملات الواردة: طلبات تأييد القروض الصناعية آلياً، وطلبات الانتماء.', union_eng: 'تصلك الكشوف الموقعية المسندة إليك: انتماء، تأييد قرض، نصب مكائن، بدء إنتاج، متابعة.',
  union_committee: 'تصلك المعاملات بعد الكشف لتوصية لجنة الصنف.', union_sg: 'يصلك ما ينتظر قرارك، وكل الوارد.', union_fin: 'تابع الأجور المستحصلة والمستحقة من تبويب «الأجور».' }[r] || '');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'union_inbox');
  if (ctx.unOpen) return fileDetail(ctx, ctx.unOpen);
  if (ctx.unMem) return memberDetail(ctx, ctx.unMem);
  const me = D.me, my = mine(me);
  const open = D.files.filter(f => ACTIVE.includes(f.status));
  const late = open.filter(f => f.late).length;
  const valid = D.members.filter(m => m.status === 'approved').length;
  const tabs = [['todo', `مهامي (${my.length})`], ['files', 'المعاملات'], ['members', 'سجل الأعضاء'],
    ...(['union_sg', 'union_fin'].includes(me.role) ? [['fees', 'الأجور']] : []), ['rules', 'الضوابط']];
  const tab = tabs.some(t => t[0] === ctx.unTab) ? ctx.unTab : (me.role === 'union_fin' ? 'fees' : 'todo');
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(D.org?.name || 'اتحاد الصناعات العراقي')}</h1>
      <p>${ROLE_IC[me.role] || ''} ${esc(me.role_title)}${me.governorate && me.role === 'union_eng' ? ` — ${esc(me.governorate)}` : ''}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظارك', `<span class="num">${my.length}</span>`, hint(me.role).split('،')[0], true)}
      ${kpi('قيد العمل', `<span class="num">${open.length}</span>`, late ? `<span style="color:var(--bad)">${late} متأخرة عن المهلة</span>` : 'ضمن المهلة')}
      ${kpi('أعضاء بهوية نافذة', `<span class="num">${valid}</span>`, `${D.members.filter(m => m.status === 'expired').length} منتهية · ${D.members.filter(m => m.status === 'pending').length} قيد الدراسة`)}
      ${kpi('تأييدات القروض', `<span class="num">${D.files.filter(f => f.kind === 'endorse' && ['issued', 'delivered'].includes(f.status)).length}</span>`, `${D.files.filter(f => f.kind === 'endorse' && f.status === 'rejected').length} مرفوضة`)}
    </div>
    <div class="eng-tabs seg ins-tabs" role="tablist">${tabs.map(([k, t]) => `<label class="${tab === k ? 'on' : ''}"><input type="radio" name="ut" value="${k}" ${tab === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('input[name=ut]').forEach(r => r.onchange = () => { ctx.unTab = r.value; render(ctx); });
  const body = root.querySelector('[data-body]');
  if (tab === 'todo') {
    body.innerHTML = my.length ? `<div class="eng-cards">${my.map(fCard).join('')}</div>` : `<div class="card empty">لا شيء بانتظارك الآن ✓<div class="small muted" style="margin-top:6px">${hint(me.role)}</div></div>`;
  } else if (tab === 'files') {
    const F = ctx.unF || { st: '', k: '' };
    const list = D.files.filter(f => (!F.st || f.status === F.st) && (!F.k || f.kind === F.k));
    body.innerHTML = `<div class="og-filter">${[['', 'الكل']].concat(Object.entries(UF_KIND).map(([k, v]) => [k, `${v[1]} ${v[0]}`])).map(([k, t]) => `<label class="chip ${F.k === k ? 'on' : ''}"><input type="radio" name="fk" value="${k}" ${F.k === k ? 'checked' : ''}>${esc(t)} <b class="num">${D.files.filter(f => !k || f.kind === k).length}</b></label>`).join('')}</div>
      <div class="og-filter"><label class="chip ${!F.st ? 'on' : ''}"><input type="radio" name="fs" value="" ${!F.st ? 'checked' : ''}>كل الحالات</label>${Object.entries(UF_ST).filter(([k]) => D.files.some(f => f.status === k)).map(([k, v]) => `<label class="chip ${F.st === k ? 'on' : ''}"><input type="radio" name="fs" value="${k}" ${F.st === k ? 'checked' : ''}>${esc(v[0])} <b class="num">${D.files.filter(f => f.status === k).length}</b></label>`).join('')}</div>
      ${list.length ? `<div class="eng-cards">${list.map(fCard).join('')}</div>` : '<div class="card empty">لا معاملات.</div>'}`;
    body.querySelectorAll('input[name=fk]').forEach(r => r.onchange = () => { ctx.unF = { ...F, k: r.value }; render(ctx); });
    body.querySelectorAll('input[name=fs]').forEach(r => r.onchange = () => { ctx.unF = { ...F, st: r.value }; render(ctx); });
  } else if (tab === 'members') {
    const q = (ctx.unQ || '').trim();
    const list = D.members.filter(m => !q || [m.code, m.factory, m.owner, m.governorate].some(x => String(x || '').includes(q)));
    body.innerHTML = `<div class="card mb"><input class="input" data-q placeholder="ابحث برقم الهوية أو اسم المعمل أو صاحبه أو المحافظة" value="${esc(q)}"></div>
      <div class="card"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الهوية</th><th>المعمل</th><th>الصنف</th><th>المحافظة</th><th>الحالة</th><th>نافذة حتى</th></tr></thead><tbody>
      ${list.map(m => `<tr class="click" data-m="${m.id}"><td><b class="num">${esc(m.code || '—')}</b></td><td>${esc(m.factory)}<div class="small muted">${esc(m.owner)}</div></td><td class="small">${esc(m.category_label)}</td>
        <td>${esc(m.governorate)}</td><td>${umBadge(m.status)}</td><td class="num small">${esc(m.valid_until || '—')}</td></tr>`).join('') || '<tr><td colspan="6" class="muted">لا نتائج</td></tr>'}</tbody></table></div></div>`;
    const qi = body.querySelector('[data-q]');
    qi.onchange = () => { ctx.unQ = qi.value; render(ctx); };
    body.querySelectorAll('[data-m]').forEach(tr => tr.onclick = () => { ctx.unMem = tr.dataset.m; window.scrollTo(0, 0); render(ctx); });
  } else if (tab === 'fees') {
    const fe = D.fees || {};
    body.innerHTML = `<div class="grid g2 mb">${kpi('المستحصل', iqd(fe.paid), 'دُفع إلكترونياً عبر المنصة أو بوصل')}${kpi('المستحق', iqd(fe.due), 'يُدفع مع عمولة المصرف قبل إرسال القرض')}</div>
      <div class="card"><h3>الأجور حسب المعاملة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المعاملة</th><th>النوع</th><th>المعمل</th><th>المبلغ</th><th>الدفع</th></tr></thead><tbody>
      ${(fe.rows || []).map(x => `<tr><td class="num">${esc(x.code)}</td><td class="small">${esc(x.kind)}</td><td>${esc(x.factory)}</td><td>${iqd(x.fee)}</td><td class="small">${x.paid_at ? `✓ ${dt(x.paid_at)}<div class="num muted">${esc(x.ref || '')}</div>` : badge(['مستحق', 'warn'])}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">لا أجور بعد</td></tr>'}</tbody></table></div></div>`;
  } else {
    const s = D.settings || {};
    body.innerHTML = `<div class="card"><h3>ضوابط العمل في الاتحاد</h3><dl class="kv">
      <dt>بدل الانتماء والهوية</dt><dd>${iqd(s.member_fee)} سنوياً</dd>
      <dt>أجور الكشف للقرض</dt><dd><span class="num">${s.insp_pct}%</span> من مبلغ القرض (من ${iqd(s.insp_min)} إلى ${iqd(s.insp_max)})</dd>
      <dt>مهلة إنجاز المعاملة</dt><dd><span class="num">${s.sla}</span> أيام</dd><dt>نفاذ كتاب التأييد</dt><dd><span class="num">${s.letter_days}</span> يوماً</dd>
      <dt>تأييد بدء الإنتاج</dt><dd>خلال <span class="num">${s.prod_days}</span> يوماً من صرف القرض</dd>
      <dt>الأصناف الصناعية</dt><dd>${Object.values(IND_CATS).map(x => `<span class="tag">${esc(x)}</span>`).join(' ')}</dd>
      <dt>المرجع</dt><dd>قانون اتحاد الصناعات العراقي رقم (44) لسنة 1989 والنظام الداخلي رقم (1) لسنة 2024 — الانتماء اختياري بقرار من المجلس أو من يخوّله، ويُعترض على الرفض خلال 30 يوماً.</dd></dl>
      <p class="small muted">تُعدَّل القيم من مشغّل النظام ← الإعدادات.</p></div>`;
  }
  body.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { ctx.unOpen = b.dataset.f; window.scrollTo(0, 0); render(ctx); });
}

function fCard(f) {
  const m = f.member || {}, k = UF_KIND[f.kind] || ['', ''];
  return `<button type="button" class="eng-card un-c ${f.late ? 'late' : ''}" data-f="${f.id}">
    <div class="row"><b class="num">${esc(f.code)}</b><span class="tag">${k[1]} ${esc(k[0])}</span>${f.appeal ? '<span class="tag warn-t">اعتراض</span>' : ''}${f.new_member ? '<span class="tag">عضو جديد</span>' : ''}<span class="sp"></span>${ufBadge(f.status)}</div>
    <div class="eng-proj">🏭 ${esc(m.factory || '')}</div>
    <div class="small muted">${esc(m.owner || '')} · ${esc(m.category_label || '')} · 📍 ${esc(m.governorate || '')}</div>
    <div class="row small"><span>${f.app ? `قرض <span class="num">${esc(f.app.code)}</span> · ${esc(f.app.bank || '')}` : 'دون قرض'}</span><span class="sp"></span>${f.amount ? iqd(f.amount) : ''}</div>
    <div class="row small muted"><span>${f.status === 'inspection' && f.engineer ? `📍 ${esc(f.engineer)}` : ''}</span><span class="sp"></span>
      ${ACTIVE.includes(f.status) ? `<span class="${f.late ? 'bad-t' : ''}">${f.late ? '⚠ تجاوز المهلة' : `المهلة ${dt(f.due_at)}`}</span>` : `<span>${dt(f.updated_at)}</span>`}</div></button>`;
}

const back = (ctx, root) => { root.querySelector('[data-back]').onclick = () => { ctx.unOpen = null; ctx.unMem = null; render(ctx); }; };
const logBlock = L => (L || []).length ? `<details class="card mb" open><summary><b>سجل المعاملة</b> <span class="small muted">(${L.length})</span></summary>${L.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')}${l.title ? ` · ${esc(l.title)}` : ''} · ${dt(l.at)}</div></div>`).join('')}</details>` : '';
const confirmBox = (word, key) => `<div class="field"><label>للتأكيد اكتب: <b>${word}</b></label><input class="input" data-${key}><button type="button" class="btn ghost sm" style="margin-top:6px" data-fill-${key}>✍ ${word}</button></div>`;
const wireFill = (root, word, key) => { const b = root.querySelector(`[data-fill-${key}]`); if (b) b.onclick = () => { root.querySelector(`[data-${key}]`).value = word; }; };

async function viewDoc(ctx, fn, args) {
  try {
    const d = await rpc(ctx.sb, fn, args);
    modal(`<h3>${esc(d.label || '')}</h3>${String(d.mime || '').startsWith('image/') ? `<img src="${d.data}" alt="" style="width:100%;border-radius:10px">` : `<iframe src="${d.data}" style="width:100%;height:70vh;border:0"></iframe>`}
      <p class="small muted num" dir="ltr" style="word-break:break-all">SHA-256: ${esc(d.sha256 || '')}</p>`, { wide: true });
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

// ───────── ملف المعاملة ─────────
async function fileDetail(ctx, id) {
  const { sb, root } = ctx;
  let F;
  try { F = await rpc(sb, 'union_file', { p_id: id }); } catch (e) { ctx.unOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const m = F.member_full || {}, L = F.loan, ins = F.inspection, c = F.can, k = UF_KIND[F.kind] || ['', ''];
  const photos = (F.docs || []).filter(d => d.kind === 'visit_photo'), mdocs = (F.docs || []).filter(d => d.kind !== 'visit_photo');
  root.innerHTML = `
    <button type="button" class="linkbtn eng-back" data-back>→ كل المعاملات</button>
    <div class="card mb eng-head">
      <div class="row"><h2 class="num" style="margin:0">${esc(F.code)}</h2><span class="tag">${k[1]} ${esc(k[0])}</span>${F.appeal ? '<span class="tag warn-t">اعتراض</span>' : ''}<span class="sp"></span>${ufBadge(F.status)}</div>
      ${stepsBar(F)}
      <div class="eng-proj big">🏭 ${esc(m.factory_name || '')}</div>
      <dl class="kv sm">
        <dt>صاحب المعمل</dt><dd>${esc(m.owner_name || '')}${m.phone ? ` · <a href="tel:${esc(m.phone)}" class="num">📞 ${esc(m.phone)}</a>` : ''}</dd>
        <dt>الهوية الصناعية</dt><dd>${m.code ? `<b class="num">${esc(m.code)}</b> ` : ''}${umBadge(m.status)}${m.valid_until ? ` · حتى <span class="num">${esc(m.valid_until)}</span>` : ''}${F.new_member ? ' <span class="tag">يُدرس انتماؤه مع القرض</span>' : ''}</dd>
        <dt>الصنف</dt><dd>${esc(m.category_label || '')}</dd>
        <dt>العنوان</dt><dd>${esc([m.governorate, m.city, m.address].filter(Boolean).join(' — '))}${m.site_geo ? ` · <a href="${mapsLink(m.site_geo)}" target="_blank" rel="noopener">📍 الخريطة — للوصول</a>` : ''}</dd>
        <dt>الاسم التجاري لدى الغرفة</dt><dd class="num">${esc(m.trade_name_no || '—')}</dd>
        <dt>إجازة التنمية الصناعية</dt><dd>${m.dev_license_no ? `<span class="num">${esc(m.dev_license_no)}</span> · ${m.dev_license_kind === 'complete' ? 'كاملة التأسيس' : 'تحت التأسيس'}` : '—'}</dd>
        <dt>المنتجات والطاقة</dt><dd>${esc(m.products || '—')}${m.capacity ? ` · ${esc(m.capacity)}` : ''}${m.workers ? ` · <span class="num">${m.workers}</span> عاملاً` : ''}</dd>
        ${F.origin ? `<dt>مصدر المعاملة</dt><dd>${esc(F.origin)}</dd>` : ''}
        ${ACTIVE.includes(F.status) ? `<dt>المهلة</dt><dd class="${F.late ? 'bad-t' : ''}">${dt(F.due_at)}${F.late ? ' — متأخرة' : ''}</dd>` : ''}
        <dt>الأجور</dt><dd>${F.fee ? `${iqd(F.fee)} ${F.fee_paid_at ? badge(['مدفوعة', 'ok']) : badge(['تُدفع مع إرسال القرض', 'muted'])}` : '—'}</dd>
      </dl>
    </div>
    ${F.appeal_data ? `<div class="notice warn mb"><b>اعتراض الصناعي على الرفض</b> — ${esc(F.appeal_data.note)} <span class="small muted">· ${dt(F.appeal_data.at)}</span>${F.appeal_data.prev?.reason ? `<div class="small">سبب الرفض السابق: ${esc(F.appeal_data.prev.reason)}</div>` : ''}</div>` : ''}
    ${F.return_note ? `<div class="notice warn mb"><b>أُعيدت للصناعي:</b> ${esc(F.return_note)}</div>` : ''}
    <div data-act></div>
    ${L ? `<div class="card mb"><h3>💳 القرض المطلوب</h3><dl class="kv sm">
      <dt>الطلب</dt><dd><span class="num">${esc(L.code)}</span> · المرحلة <span class="num">${L.stage}</span> ${esc(L.stage_name || '')}</dd>
      <dt>البرنامج</dt><dd>${esc(L.program || '')} — ${esc(L.bank || '')}</dd>
      <dt>المبلغ</dt><dd><b>${iqd(L.amount)}</b> · <span class="num">${L.term}</span> شهراً منها <span class="num">${L.grace || 0}</span> سماح · فائدة <span class="num">${L.rate}%</span></dd>
      <dt>الغرض</dt><dd>${esc(L.purpose || '')}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[L.guarantee] || '—')}</dd></dl>
      ${(F.app_docs || []).length ? `<h4 style="margin:10px 0 6px">مستندات الطلب</h4><div class="row" style="gap:8px;flex-wrap:wrap">${F.app_docs.map(d => `<button type="button" class="btn ghost sm" data-ad="${d.id}">📎 ${esc(d.label)}</button>`).join('')}</div>` : ''}</div>` : ''}
    ${mdocs.length ? `<div class="card mb"><h3>مستندات الصناعي</h3><div class="row" style="gap:8px;flex-wrap:wrap">${mdocs.map(d => `<button type="button" class="btn ghost sm" data-ud="${d.id}">📎 ${esc(d.label)}</button>`).join('')}</div></div>` : ''}
    ${ins ? `<div class="card mb"><h3>📍 الكشف الموقعي <span class="sp"></span>${badge(SITE_ST[ins.site_state] || ['—', 'muted'])} ${ins.result === 'ok' ? badge(['مطابق', 'ok']) : badge(['عليه ملاحظات', 'warn'])}</h3><dl class="kv sm">
      <dt>المهندس</dt><dd>${esc(ins.by || '')} <span class="num">${esc(ins.code || '')}</span> · ${dt(ins.at)}</dd>
      ${ins.gps ? `<dt>الزيارة</dt><dd>📍 <a href="${mapsLink(ins.gps)}" target="_blank" rel="noopener">على الخريطة</a> · ±<span class="num">${ins.gps.acc}</span> م</dd>` : ''}
      ${ins.assessed_value ? `<dt>القيمة المقدّرة للموجودات</dt><dd>${iqd(ins.assessed_value)}</dd>` : ''}
      ${ins.quotes_total ? `<dt>عروض أسعار المكائن</dt><dd>${iqd(ins.quotes_total)}${ins.fair_value ? ` · العادلة ${iqd(ins.fair_value)}` : ''} · ${ins.price_ok ? badge(['معقولة', 'ok']) : badge(['مبالغ فيها أو عليها ملاحظة', 'warn'])}</dd>` : ''}
      ${ins.machines_match != null ? `<dt>المكائن المنصوبة</dt><dd>${ins.machines_match ? badge(['مطابقة لما مُوّل', 'ok']) : badge(['غير مطابقة', 'bad'])}</dd>` : ''}
      ${ins.capacity ? `<dt>الطاقة الإنتاجية</dt><dd>${esc(ins.capacity)}</dd>` : ''}${ins.workers ? `<dt>العاملون</dt><dd class="num">${ins.workers}</dd>` : ''}
      ${(ins.checks || []).length ? `<dt>الفحص</dt><dd>${ins.checks.map(x => `<span class="tag">✓ ${esc(x)}</span>`).join(' ')}</dd>` : ''}
      ${ins.note ? `<dt>الملاحظات</dt><dd>${esc(ins.note)}</dd>` : ''}</dl>
      ${photos.length ? `<div class="un-grid mt">${photos.map(p => `<button type="button" class="un-ph" data-ud="${p.id}"><span>📷 صورة الكشف · ${dt(p.at)}</span></button>`).join('')}</div>` : ''}</div>` : ''}
    ${F.committee ? `<div class="card mb"><h3>⚖️ توصية لجنة الصنف <span class="sp"></span>${badge(REC[F.committee.rec] || ['—', 'muted'])}</h3><dl class="kv sm"><dt>اللجنة</dt><dd>${esc(F.committee.by || '')} · ${dt(F.committee.at)}</dd>
      ${F.committee.recommended_amount ? `<dt>المبلغ الموصى به</dt><dd>${iqd(F.committee.recommended_amount)}</dd>` : ''}${F.committee.note ? `<dt>الملاحظات</dt><dd>${esc(F.committee.note)}</dd>` : ''}</dl></div>` : ''}
    ${F.decision ? `<div class="card mb"><h3>🏛 قرار الأمين العام <span class="sp"></span>${F.decision.result === 'rejected' ? badge(['عدم التأييد', 'bad']) : F.decision.result === 'not_ok' ? badge(['غير مطابق', 'bad']) : badge(['التأييد', 'ok'])}</h3>
      <dl class="kv sm"><dt>صدر عن</dt><dd>${esc(F.decision.by || '')} · ${dt(F.decision.at)}</dd>${F.decision.reason ? `<dt>الأسباب</dt><dd>${esc(F.decision.reason)}</dd>` : ''}${F.decision.note ? `<dt>الملاحظات</dt><dd>${esc(F.decision.note)}</dd>` : ''}${F.decision.revoked ? `<dt>سحب الكتاب</dt><dd class="bad-t">${esc(F.decision.revoke_reason || '')}</dd>` : ''}</dl></div>` : ''}
    ${(F.letters || []).map(l => `<div class="mb">${letterHtml(l)}</div>`).join('')}
    ${logBlock(F.log)}`;
  back(ctx, root);
  root.querySelectorAll('[data-ad]').forEach(b => b.onclick = () => viewDoc(ctx, 'union_app_doc', { p_file: F.id, p_doc: b.dataset.ad }));
  root.querySelectorAll('[data-ud]').forEach(b => b.onclick = () => viewDoc(ctx, 'union_doc', { p_id: b.dataset.ud }));
  // صور الكشف مصغرة
  photos.forEach(p => rpc(sb, 'union_doc', { p_id: p.id }).then(d => { const b = root.querySelector(`.un-ph[data-ud="${p.id}"]`); if (b && String(d.mime).startsWith('image/')) b.insertAdjacentHTML('afterbegin', `<img src="${d.data}" alt="">`); }).catch(() => {}));
  const box = root.querySelector('[data-act]');
  const run = async (btn, p, okTitle, rows = []) => {
    btn.disabled = true;
    try {
      const r = await rpc(sb, 'union_act', { p_id: F.id, p });
      resultScreen({ ok: true, title: okTitle, ref: F.code, rows: [...rows, ...(r?.letter ? [['الكتاب', `<span class="num" dir="ltr">${esc(r.letter)}</span>`]] : []), ...(r?.member ? [['الهوية الصناعية', `<b class="num">${esc(r.member)}</b>`]] : [])], msg: 'سُجّل الإجراء باسمك ورمزك الوظيفي في سجل المعاملة.' });
      ctx.unOpen = (p.action === 'issue' || p.action === 'visit' || p.action === 'recommend') ? F.id : null; render(ctx);
    } catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
  };
  const note = () => box.querySelector('[data-note]')?.value.trim() || '';

  if (c.triage) {
    box.innerHTML = `<div class="card mb un-act"><h3>🗂 التدقيق والإحالة</h3><p class="small muted" style="margin-top:0">تأكد من اكتمال البيانات والمستندات، ثم أحِل المعاملة لمهندس الكشف — أو أعدها للصناعي بالنقص.</p>
      <div class="field"><label>مهندس الكشف</label>${engSelect(m.governorate)}</div>
      <div class="field"><label>ملاحظة أو النقص (للإعادة أو الرفض)</label><textarea class="input" rows="2" data-note></textarea></div>
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn cyan" data-a="accept">إحالة للكشف الموقعي ←</button><button class="btn warn" data-a="return">إعادة للصناعي</button><span class="sp"></span><button class="btn ghost bad" data-a="reject_form">رفض شكلي</button></div></div>`;
    box.querySelectorAll('[data-a]').forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (a !== 'accept' && note().length < 5) return toast('اكتب النقص أو السبب', 'bad');
      if (a === 'reject_form' && !window.confirm('رفض المعاملة؟ يحق للصناعي الاعتراض خلال 30 يوماً.')) return;
      run(b, { action: a, note: note(), engineer: box.querySelector('[data-eng]')?.value || null }, { accept: 'أُحيلت للكشف الموقعي', return: 'أُعيدت للصناعي', reject_form: 'رُفضت المعاملة' }[a]);
    });
  } else if (c.visit) {
    visitForm(ctx, F, box);
  } else if (c.recommend) {
    let rec = 'approve';
    box.innerHTML = `<div class="card mb un-act"><h3>⚖️ توصية لجنة الصنف — ${esc(m.category_label || '')}</h3>
      <div class="seg mb" data-rec>${Object.entries(REC).map(([k, v]) => `<button type="button" data-r="${k}" class="${k === rec ? 'on' : ''}">${esc(v[0])}</button>`).join('')}</div>
      ${F.kind === 'endorse' ? `<div class="field"><label>المبلغ الموصى به (اختياري — إن كان أقل من المطلوب)</label><input class="input num" dir="ltr" inputmode="numeric" data-ra></div>` : ''}
      <div class="field"><label>الشروط أو الأسباب</label><textarea class="input" rows="3" data-note placeholder="مثال: التأييد بشرط تقديم عرض سعر ثانٍ للمكينة الرئيسية"></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-go>رفع التوصية للأمين العام ←</button></div></div>`;
    box.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { rec = b.dataset.r; box.querySelectorAll('[data-r]').forEach(z => z.classList.toggle('on', z === b)); });
    box.querySelector('[data-go]').onclick = e => run(e.target, { action: 'recommend', rec, note: note(), recommended_amount: money(box.querySelector('[data-ra]')?.value) }, 'رُفعت التوصية للأمين العام');
  } else if (c.sign) {
    const isReq = ['membership', 'endorse'].includes(F.kind);
    box.innerHTML = `<div class="card mb un-act"><h3>🏛 قرار الأمين العام</h3>
      <p class="small" style="margin-top:0">${isReq ? `التأييد يُصدر ${F.kind === 'endorse' ? 'كتاب تأييد صناعي موجّهاً إلى المصرف' : 'قرار الانتماء والهوية الصناعية'} مختوماً ببصمة رقمية ورمز تحقق${F.new_member ? '، ويمنح الصناعي هويته الصناعية' : ''}.` : `يُصدر ${esc(k[0])} بنتيجة الكشف ويصل المصرف آلياً${ins && (ins.result !== 'ok' || ins.machines_match === false || ins.site_state !== 'operating') ? ' — <b class="bad-t">النتيجة غير مطابقة وتصل هيئة النزاهة أيضاً</b>' : ''}.`}</p>
      <div class="field"><label>ملاحظات أو أسباب (الأسباب إلزامية للرفض والإعادة)</label><textarea class="input" rows="2" data-note></textarea></div>
      ${confirmBox('أوافق', 'cf')}
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn cyan" data-go>${isReq ? 'التأييد وإصدار الكتاب' : 'إصدار الكتاب'}</button>
        <select class="input" data-to style="width:auto"><option value="">إعادة إلى…</option><option value="new">قسم العضوية والتسجيل</option><option value="inspection">مهندس الكشف</option>${isReq ? '<option value="committee">لجنة الصنف</option>' : ''}</select>
        <span class="sp"></span>${isReq ? `<button class="btn ghost bad" data-rej>${F.appeal ? 'رفض نهائي' : 'عدم التأييد'}</button>` : ''}</div></div>`;
    wireFill(box, 'أوافق', 'cf');
    box.querySelector('[data-go]').onclick = e => {
      if (box.querySelector('[data-cf]').value.trim() !== 'أوافق') return toast('اكتب «أوافق» للتأكيد', 'bad');
      run(e.target, { action: 'issue', confirm: 'أوافق', note: note() }, 'صدر الكتاب');
    };
    box.querySelector('[data-to]').onchange = e => { if (!e.target.value) return; if (note().length < 5) { e.target.value = ''; return toast('اكتب سبب الإعادة أولاً', 'bad'); } run(e.target, { action: 'return_to', to: e.target.value, note: note() }, 'أُعيدت المعاملة'); };
    const rj = box.querySelector('[data-rej]');
    if (rj) rj.onclick = () => { if (note().length < 10) return toast('اكتب أسباب الرفض بوضوح', 'bad'); if (!window.confirm('تأكيد عدم التأييد؟')) return; run(rj, { action: 'reject', note: note() }, 'سُجّل عدم التأييد'); };
  } else if (c.revoke) {
    box.innerHTML = `<details class="card mb un-act"><summary><b>سحب الكتاب</b> <span class="small muted">— لخطأ جوهري أو تغيّر حال المعمل</span></summary>
      <div class="field mt"><label>سبب السحب (يصل المصرف وهيئة النزاهة)</label><textarea class="input" rows="2" data-note></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn bad" data-rv>سحب الكتاب</button></div></details>`;
    box.querySelector('[data-rv]').onclick = e => { if (note().length < 10) return toast('اكتب السبب', 'bad'); if (!window.confirm('سحب الكتاب؟ لا يمكن التراجع.')) return; run(e.target, { action: 'revoke', note: note() }, 'سُحب الكتاب'); };
  }
  if (c.reassign && !c.visit) {
    box.insertAdjacentHTML('beforeend', `<details class="card mb un-act"><summary><b>إعادة إسناد الكشف</b> <span class="small muted">— حالياً: ${esc(F.engineer || '—')}</span></summary>
      <div class="row mt" style="gap:8px">${engSelect(m.governorate, F.engineer_id)}<button class="btn sm cyan" data-ra2>إسناد</button></div></details>`);
    box.querySelector('[data-ra2]').onclick = e => run(e.target, { action: 'reassign', engineer: box.querySelectorAll('[data-eng]')[box.querySelectorAll('[data-eng]').length - 1].value || null }, 'أُعيد الإسناد');
  }
}
const engSelect = (gov, sel) => `<select class="input" data-eng><option value="">تلقائي — الأقل انشغالاً${gov ? ` (يُفضَّل مهندس ${esc(gov)})` : ''}</option>${(D.engineers || []).map(e => `<option value="${e.id}" ${e.id === sel ? 'selected' : ''}>${esc(e.name)} — ${esc(e.governorate || '')} (${e.open} مفتوحة)</option>`).join('')}</select>`;

// ───────── المهندس: الكشف الموقعي ─────────
function visitForm(ctx, F, box) {
  const st = { gps: null, photos: [], site: F.kind === 'install' ? 'operating' : '', result: '', price_ok: null, match: null };
  const CHECKS = F.kind === 'membership' ? ['المعمل قائم في العنوان المذكور', 'المكائن مطابقة للإجازة', 'الاسم التجاري مسجل لدى الغرفة', 'شروط السلامة متوفرة']
    : F.kind === 'endorse' ? ['المعمل قائم في العنوان المذكور', 'الأرض والبناء يستوعبان المكائن الجديدة', 'الكهرباء والوقود كافيان', 'المكائن المطلوبة لازمة للنشاط', 'اطّلعت على عروض الأسعار الأصلية']
    : F.kind === 'install' ? ['المكائن واصلة ومنصوبة', 'الأرقام التسلسلية تطابق الفواتير', 'تشغيل تجريبي ناجح'] : ['المعمل يعمل', 'يوجد إنتاج ومخزون', 'العمال موجودون'];
  const yn = (key, a, b) => `<div class="un-yn" data-yn="${key}"><button type="button" data-v="1" class="btn ghost">${a}</button><button type="button" data-v="0" class="btn ghost">${b}</button></div>`;
  box.innerHTML = `<div class="card mb un-act"><h3>📍 الكشف الموقعي — ${esc(UF_KIND[F.kind]?.[0] || '')}</h3>
    <div class="eng-visit" data-gpsbox><b>١. ثبّت موقعك وأنت داخل المعمل</b><p class="small muted" style="margin:4px 0 10px">لا يُقبل الكشف دون موقع بدقة ±150 م أو أفضل.</p><button class="btn cyan big-btn" data-gps>📍 ثبّت موقعي الآن</button></div>
    <div class="eng-visit mt" data-phbox><b>٢. صوّر المعمل والمكائن</b> <span class="small muted">(صورة واحدة على الأقل)</span><div class="un-grid mt" data-ph></div><button class="btn ghost mt" data-cam>📷 التقط صورة</button></div>
    <div class="field mt"><label>٣. حالة المعمل</label><div class="seg" data-site style="flex-wrap:wrap">${Object.entries(SITE_ST).map(([k, v]) => `<button type="button" data-s="${k}" class="${st.site === k ? 'on' : ''}">${esc(v[0])}</button>`).join('')}</div></div>
    <div class="field"><label>الفحص</label><div class="chips">${CHECKS.map(x => `<label class="chip"><input type="checkbox" value="${esc(x)}">${esc(x)}</label>`).join('')}</div></div>
    <div class="grid g2" style="gap:10px">
      ${['membership', 'endorse'].includes(F.kind) ? `<div class="field"><label>القيمة المقدّرة للموجودات الحالية (د.ع)</label><input class="input num" dir="ltr" inputmode="numeric" data-av></div>` : ''}
      ${F.kind === 'endorse' ? `<div class="field"><label>مجموع عروض أسعار المكائن (د.ع)</label><input class="input num" dir="ltr" inputmode="numeric" data-qt value="${fmt(F.loan?.amount)}"></div>
        <div class="field"><label>القيمة العادلة بتقديرك (د.ع، اختياري)</label><input class="input num" dir="ltr" inputmode="numeric" data-fv></div>` : ''}
      <div class="field"><label>الطاقة الإنتاجية</label><input class="input" data-cap value="${esc(F.member_full?.capacity || '')}"></div>
      <div class="field"><label>العاملون الموجودون</label><input class="input num" dir="ltr" inputmode="numeric" data-wk value="${esc(F.member_full?.workers || '')}"></div>
    </div>
    ${F.kind === 'endorse' ? `<div class="field"><label>هل أسعار المكائن معقولة قياساً بالسوق؟</label>${yn('price', 'نعم، معقولة', 'لا، مبالغ فيها')}</div>` : ''}
    ${F.kind === 'install' ? `<div class="field"><label>هل المكائن المنصوبة مطابقة لما مُوّل؟</label>${yn('match', 'نعم، مطابقة', 'لا')}</div>` : ''}
    <div class="field"><label>النتيجة</label>${yn('result', '✓ مطابق', '⚠ عليه ملاحظات')}</div>
    <div class="field"><label>الملاحظات</label><textarea class="input" rows="3" data-note></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-go>حفظ الكشف ورفعه ←</button></div></div>`;
  const paintPh = () => { box.querySelector('[data-ph]').innerHTML = st.photos.map(p => `<div class="un-ph"><img src="${p.data}" alt=""><span>✓ محفوظة</span></div>`).join(''); };
  box.querySelector('[data-gps]').onclick = async () => {
    const { gpsDialog } = await import('../geo.js');
    const g = await gpsDialog({ title: 'تثبيت زيارة المعمل', hint: 'قف داخل المعمل أو بجانب المكائن.', want: 25, accMax: 150 });
    if (!g) return;
    st.gps = g;
    const b = box.querySelector('[data-gpsbox]'); b.classList.add('ok');
    b.innerHTML = `<div class="row"><span class="eng-pin">📍</span><div><b>ثُبّت موقعك</b><div class="small muted">دقة ±<span class="num">${Math.round(g.acc)}</span> م</div></div></div>`;
  };
  box.querySelector('[data-cam]').onclick = async e => {
    const { cameraCapture } = await import('../capture.js');
    const shot = await cameraCapture({ title: 'صورة المعمل أو المكائن', hint: '', ratio: 0.75 });
    if (!shot) return;
    e.target.disabled = true;
    try { const id = await rpc(ctx.sb, 'union_doc_add', { p_file: F.id, p_kind: 'visit_photo', p_data: shot.data, p_meta: shot.meta || {} }); st.photos.push({ id, data: shot.data }); paintPh(); }
    catch (er) { toast(cleanErr(er), 'bad'); }
    e.target.disabled = false;
  };
  box.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { st.site = b.dataset.s; box.querySelectorAll('[data-s]').forEach(z => z.classList.toggle('on', z === b)); });
  box.querySelectorAll('[data-yn]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => {
    const v = b.dataset.v === '1', k = g.dataset.yn;
    if (k === 'price') st.price_ok = v; else if (k === 'match') st.match = v; else st.result = v ? 'ok' : 'issues';
    g.querySelectorAll('button').forEach(z => { z.classList.toggle('cyan', z === b); z.classList.toggle('ghost', z !== b); });
  }));
  box.querySelector('[data-go]').onclick = async e => {
    if (!st.gps) return toast('ثبّت موقعك أولاً', 'bad');
    if (!st.photos.length) return toast('التقط صورة واحدة على الأقل', 'bad');
    if (!st.site) return toast('حدّد حالة المعمل', 'bad');
    if (F.kind === 'endorse' && st.price_ok == null) return toast('حدّد معقولية الأسعار', 'bad');
    if (F.kind === 'install' && st.match == null) return toast('حدّد مطابقة المكائن', 'bad');
    if (!st.result) return toast('حدّد النتيجة', 'bad');
    const p = { action: 'visit', gps: { lat: st.gps.lat, lng: st.gps.lng, acc: st.gps.acc }, photos: st.photos.map(x => x.id), site_state: st.site, result: st.result,
      note: box.querySelector('[data-note]').value.trim(), checks: [...box.querySelectorAll('.chips input:checked')].map(i => i.value),
      capacity: box.querySelector('[data-cap]').value.trim(), workers: money(box.querySelector('[data-wk]').value) };
    if (box.querySelector('[data-av]')) p.assessed_value = money(box.querySelector('[data-av]').value);
    if (box.querySelector('[data-qt]')) { p.quotes_total = money(box.querySelector('[data-qt]').value); p.fair_value = money(box.querySelector('[data-fv]').value); }
    if (st.price_ok != null) p.price_ok = st.price_ok;
    if (st.match != null) p.machines_match = st.match;
    e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'union_act', { p_id: F.id, p });
      resultScreen({ ok: true, title: 'حُفظ الكشف', ref: F.code, msg: r.next === 'committee' ? 'رُفعت المعاملة إلى لجنة الصنف.' : 'رُفعت المعاملة لقرار الأمين العام.', rows: [['حالة المعمل', esc(SITE_ST[st.site][0])], ['الصور', `<span class="num">${st.photos.length}</span>`]] });
      ctx.unOpen = null; render(ctx);
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── سجل العضو ─────────
async function memberDetail(ctx, id) {
  const { sb, root } = ctx;
  let M;
  try { M = await rpc(sb, 'union_member', { p_id: id }); } catch (e) { ctx.unMem = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const me = D.me;
  root.innerHTML = `<button type="button" class="linkbtn eng-back" data-back>→ سجل الأعضاء</button>
    <div class="mb">${memberCard(M)}</div>
    <div class="card mb"><dl class="kv sm">
      <dt>صاحب المعمل</dt><dd>${esc(M.owner_name)}${M.phone ? ` · <span class="num">${esc(M.phone)}</span>` : ''}</dd><dt>الصنف</dt><dd>${esc(M.category_label)}</dd>
      <dt>العنوان</dt><dd>${esc([M.governorate, M.city, M.address].filter(Boolean).join(' — '))}${M.site_geo ? ` · <a href="${mapsLink(M.site_geo)}" target="_blank" rel="noopener">📍 الخريطة</a>` : ''}</dd>
      <dt>الاسم التجاري</dt><dd class="num">${esc(M.trade_name_no || '—')}</dd><dt>إجازة التنمية</dt><dd><span class="num">${esc(M.dev_license_no || '—')}</span>${M.dev_license_kind ? ` · ${M.dev_license_kind === 'complete' ? 'كاملة التأسيس' : 'تحت التأسيس'}` : ''}</dd>
      <dt>المنتجات</dt><dd>${esc(M.products || '—')}${M.capacity ? ` · ${esc(M.capacity)}` : ''}</dd>${M.joined_at ? `<dt>تاريخ الانتماء</dt><dd class="num">${esc(M.joined_at)}</dd>` : ''}
      ${M.reason ? `<dt>ملاحظة</dt><dd>${esc(M.reason)}</dd>` : ''}</dl></div>
    <div data-mact></div>
    <div class="card mb"><h3>معاملات العضو</h3>${(M.files || []).length ? `<div class="eng-cards">${M.files.map(fCard).join('')}</div>` : '<p class="muted">لا معاملات.</p>'}</div>
    ${(M.log || []).length ? `<details class="card mb"><summary><b>سجل الهوية</b></summary>${M.log.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')} · ${dt(l.at)}</div></div>`).join('')}</details>` : ''}`;
  back(ctx, root);
  root.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { ctx.unMem = null; ctx.unOpen = b.dataset.f; window.scrollTo(0, 0); render(ctx); });
  const box = root.querySelector('[data-mact]'), sg = me.role === 'union_sg';
  const acts = [];
  if (['approved', 'expired'].includes(M.status) && M.code && ['union_sg', 'union_reg'].includes(me.role)) acts.push(['renew', 'تجديد سنة بوصل قبض', 'cyan']);
  if (sg && M.status === 'approved') acts.push(['suspend', 'تعليق العضوية', 'ghost bad']);
  if (sg && M.status === 'suspended') acts.push(['reinstate', 'إعادة العضوية', 'cyan']);
  if (!acts.length) return;
  box.innerHTML = `<div class="card mb un-act"><h3>إجراءات الهوية</h3><div class="grid g2" style="gap:10px"><div class="field"><label>رقم وصل القبض (للتجديد)</label><input class="input num" dir="ltr" data-ref></div>
    <div class="field"><label>السبب أو الملاحظة</label><input class="input" data-note></div></div>
    <div class="row" style="gap:8px">${acts.map(([k, t, cls]) => `<button class="btn ${cls}" data-ma="${k}">${t}</button>`).join('')}</div></div>`;
  box.querySelectorAll('[data-ma]').forEach(b => b.onclick = async () => {
    b.disabled = true;
    try { await rpc(sb, 'union_member_act', { p_id: M.id, p: { action: b.dataset.ma, ref: box.querySelector('[data-ref]').value.trim(), note: box.querySelector('[data-note]').value.trim() } }); toast('تم', 'ok'); memberDetail(ctx, id); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
}
