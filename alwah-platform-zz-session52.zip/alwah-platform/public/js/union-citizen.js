// الجلسة 52: بوابة المقترض — صفحة «اتحاد الصناعات العراقي»
// هويتي الصناعية (بطاقة برمز QR وتجديدها)، طلب الانتماء، متابعة المعاملات، الاعتراض على الرفض، كتب الاتحاد
import { esc, dt, iqd, num, rpc, toast, cleanErr, modal, askOtp, govOptions, PAY_METHODS, PAY_LABEL, IND_CATS } from './core.js';
import { cameraCapture } from './capture.js';
import { ufBadge, UF_KIND, stepsBar, memberCard, openLetter } from './union-ui.js';

export function unionBanner() {
  return `<a class="card mb vet-banner" href="#union" style="border-inline-start:4px solid #4d5b2a"><div class="vb-ic">🏭</div><div><span class="pill">اتحاد الصناعات العراقي</span>
    <h2>صاحب معمل أو ورشة إنتاجية؟</h2><p>احصل على هويتك الصناعية وجدّدها من هاتفك، وتابع كشف الاتحاد على معملك وكتاب تأييد قرضك الصناعي.</p></div><span class="go">هويتي الصناعية ←</span></a>`;
}

const DOCS = [['id_card', 'البطاقة الوطنية لصاحب المعمل'], ['ind_trade_name', 'شهادة تسجيل الاسم التجاري لدى غرفة الصناعة'], ['ind_dev_license', 'إجازة التأسيس من المديرية العامة للتنمية الصناعية'], ['ind_lease', 'عقد إيجار أرض المعمل أو سند ملكيتها']];

export async function pageUnion(body, ctx) {
  const { sb, profile } = ctx;
  const U = await rpc(sb, 'union_my');
  const mem = U.members || [], files = U.files || [], letters = U.letters || [];
  const valid = mem.find(m => m.valid), cur = valid || mem.find(m => m.code) || null;
  const open = files.find(f => ['new', 'returned', 'inspection', 'committee', 'signing'].includes(f.status) && ['membership', 'endorse'].includes(f.kind));
  const soon = cur?.valid_until && (new Date(cur.valid_until) - Date.now()) / 864e5 < 45;
  body.innerHTML = `
    <div class="page-head"><div><h1>🏭 ${esc(U.org?.name || 'اتحاد الصناعات العراقي')}</h1><p>هويتك الصناعية ومعاملاتك لدى الاتحاد</p></div></div>
    ${cur ? `<div class="mb">${memberCard(cur)}</div>
      ${cur.code && (soon || cur.status === 'expired') ? `<div class="card mb"><h3>${cur.status === 'expired' ? 'هويتك منتهية' : 'تنتهي هويتك قريباً'}</h3>
        <p class="small muted" style="margin-top:0">التجديد سنة كاملة ببدل ${iqd(U.fees?.member)} — ادفعه إلكترونياً الآن.</p>
        <div class="paygrid">${PAY_METHODS.map(([k, t, col], i) => `<button type="button" data-m="${k}" class="${i === 0 ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>
        <div class="row mt"><span class="sp"></span><button class="btn cyan" data-renew>جدّد هويتي ←</button></div></div>` : ''}`
      : open ? '' : `<div class="card mb" data-applybox></div>`}
    ${files.length ? `<h2 style="font-size:18px">معاملاتي لدى الاتحاد</h2>${files.map(f => `<div class="card mb">
      <div class="row"><b>${UF_KIND[f.kind]?.[1] || ''} ${esc(f.kind_label)}</b><span class="num small muted">${esc(f.code)}</span><span class="sp"></span>${ufBadge(f.status)}</div>
      ${stepsBar(f)}
      ${f.app ? `<p class="small muted" style="margin:4px 0">لطلب القرض <span class="num">${esc(f.app)}</span></p>` : ''}
      ${f.status === 'returned' ? `<div class="notice warn">أعادها الاتحاد للاستكمال: <b>${esc(f.return_note || '')}</b></div>` : ''}
      ${f.status === 'rejected' ? `<div class="notice bad"><b>لم يؤيد الاتحاد:</b> ${esc(f.reason || '')}${f.appeal ? '<div class="small">قدّمت اعتراضاً — قرار الأمين العام بعده نهائي.</div>' : ''}</div>` : ''}
      ${['new', 'returned'].includes(f.status) && f.kind === 'membership' ? `<div class="mt"><b class="small">المستندات</b>${DOCS.map(([k, t]) => { const h = (f.docs || []).find(d => d.kind === k); return `<div class="row" style="gap:8px;margin-top:6px"><span>${h ? '🖼' : '📎'}</span><span class="small" style="flex:1">${esc(t)}</span><button type="button" class="btn sm ${h ? 'ghost' : 'cyan'}" data-doc="${k}" data-file="${f.id}">${h ? 'استبدال' : '📷 إرفاق'}</button></div>`; }).join('')}</div>` : ''}
      <div class="row mt" style="gap:8px">${f.status === 'returned' && f.kind === 'membership' ? `<button class="btn cyan sm" data-resub="${f.id}">أكملت النواقص — أعدها للاتحاد</button>` : ''}
        ${f.status === 'returned' && f.kind === 'endorse' ? `<a class="btn cyan sm" href="#apply">صحّح طلب القرض</a>` : ''}
        ${f.can_appeal ? `<button class="btn warn sm" data-appeal="${f.id}">اعتراض على الرفض</button>` : ''}
        <span class="sp"></span><span class="small muted">${f.fee ? `الأجور ${iqd(f.fee)} ${f.fee_paid_at ? '✓' : '(تُدفع مع رسوم القرض)'}` : ''}</span></div></div>`).join('')}` : ''}
    ${letters.length ? `<h2 style="font-size:18px">كتب الاتحاد</h2><div class="card mb">${letters.map(l => `<div class="un-row"><button type="button" class="linkbtn" data-l="${l.id}">📜 ${esc(l.title)}</button><span class="sp"></span><span class="num small" dir="ltr">${esc(l.no)}</span>${l.revoked_at ? ' <span class="badge bad">مسحوب</span>' : ''}</div>`).join('')}</div>` : ''}
    <p class="small muted">قانون اتحاد الصناعات العراقي رقم (44) لسنة 1989: الانتماء اختياري، ويُعترض على قرار الرفض خلال ${U.fees?.appeal_days || 30} يوماً.</p>`;

  body.querySelectorAll('[data-l]').forEach(b => b.onclick = () => openLetter(letters.find(x => x.id === b.dataset.l)));
  body.querySelectorAll('[data-doc]').forEach(b => b.onclick = async () => {
    const shot = await cameraCapture({ title: `صوّر: ${DOCS.find(d => d[0] === b.dataset.doc)[1]}`, allowFile: true });
    if (!shot) return;
    try { await rpc(sb, 'union_doc_add', { p_file: b.dataset.file, p_kind: b.dataset.doc, p_data: shot.data, p_meta: shot.meta || {} }); toast('حُفظ المستند', 'ok'); pageUnion(body, ctx); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  });
  body.querySelectorAll('[data-resub]').forEach(b => b.onclick = async () => {
    b.disabled = true;
    try { await rpc(sb, 'union_resubmit', { p_file: b.dataset.resub, p_note: null }); toast('أُعيدت المعاملة للاتحاد', 'ok'); pageUnion(body, ctx); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
  body.querySelectorAll('[data-appeal]').forEach(b => b.onclick = () => {
    const m = modal(`<h3>الاعتراض على قرار الاتحاد</h3><p class="small muted">يعود اعتراضك إلى الأمين العام، وقراره بعده نهائي داخل الاتحاد.</p>
      <div class="field"><label>أسباب اعتراضك</label><textarea class="input" rows="4" data-n></textarea></div><div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الاعتراض</button></div>`);
    m.el.querySelector('[data-s]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'union_appeal', { p_file: b.dataset.appeal, p_note: m.el.querySelector('[data-n]').value.trim() }); m.close(); toast('أُرسل الاعتراض', 'ok'); pageUnion(body, ctx); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  });
  let method = PAY_METHODS[0][0];
  body.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; b.parentElement.querySelectorAll('[data-m]').forEach(z => z.classList.toggle('on', z === b)); });
  const rn = body.querySelector('[data-renew]');
  if (rn) rn.onclick = async () => {
    const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: profile.phone, purpose: `تجديد الهوية الصناعية ${num(U.fees?.member)} د.ع`,
      verify: c => rpc(sb, 'union_renew', { p_member: cur.id, p_method: method, p_otp: c }) });
    if (ok) { toast('جُدّدت هويتك سنة', 'ok'); pageUnion(body, ctx); }
  };
  const ab = body.querySelector('[data-applybox]');
  if (ab) applyForm(ab, ctx, U, () => pageUnion(body, ctx));
}

function applyForm(box, ctx, U, done) {
  const { sb, profile } = ctx;
  const fee = Number(U.fees?.member || 0) + 50000;
  let method = PAY_METHODS[0][0];
  const f = (k, l, ph = '', a = '') => `<div class="field"><label>${l}</label><input class="input" data-k="${k}" placeholder="${esc(ph)}" ${a}></div>`;
  box.innerHTML = `<h3>طلب الانتماء والهوية الصناعية</h3>
    <p class="small muted" style="margin-top:0">إن كنت ستطلب قرضاً صناعياً فلا حاجة لهذا الطلب — يُدرس انتماؤك مع القرض. هنا تطلب الهوية وحدها.</p>
    <div class="grid g2" style="gap:12px">
      ${f('factory_name', 'اسم المعمل أو الورشة')}
      <div class="field"><label>صنف الصناعة</label><select class="input" data-k="category"><option value="">اختر</option>${Object.entries(IND_CATS).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></div>
      ${f('products', 'المنتجات')}${f('capacity', 'الطاقة الإنتاجية (اختياري)')}
      ${f('trade_name_no', 'رقم تسجيل الاسم التجاري لدى غرفة الصناعة', '', 'dir="ltr"')}${f('dev_license_no', 'رقم إجازة التنمية الصناعية (إن وُجدت)', '', 'dir="ltr"')}
      <div class="field"><label>المحافظة</label><select class="input" data-k="governorate">${govOptions(profile.governorate || '')}</select></div>${f('city', 'المدينة / المنطقة الصناعية')}
      <div class="field" style="grid-column:1/-1"><label>عنوان المعمل</label><input class="input" data-k="address" placeholder="الشارع، أقرب نقطة دالة"></div>
      ${f('workers', 'عدد العاملين', '', 'inputmode="numeric" dir="ltr"')}${f('capital', 'رأس المال التقريبي (د.ع، اختياري)', '', 'inputmode="numeric" dir="ltr"')}
    </div>
    <div class="review mt"><dl class="kv"><dt>بدل الانتماء السنوي + أجور الكشف</dt><dd><b>${iqd(fee)}</b></dd></dl>
      <div class="paygrid">${PAY_METHODS.map(([k, t, col], i) => `<button type="button" data-pm="${k}" class="${i === 0 ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>ادفع وقدّم الطلب ←</button></div>`;
  box.querySelectorAll('[data-pm]').forEach(b => b.onclick = () => { method = b.dataset.pm; box.querySelectorAll('[data-pm]').forEach(z => z.classList.toggle('on', z === b)); });
  box.querySelector('[data-go]').onclick = async () => {
    const d = {}; box.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    if (!d.factory_name || !d.category || !d.address || !d.products || !d.trade_name_no) return toast('أكمل اسم المعمل والصنف والمنتجات والاسم التجاري والعنوان', 'bad');
    let res;
    const ok = await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: profile.phone, purpose: `بدل الانتماء وأجور الكشف ${num(fee)} د.ع`,
      verify: async c => { res = await rpc(sb, 'union_member_apply', { p: { ...d, method, otp: c } }); } });
    if (!ok) return;
    toast(`قُدّم طلبك ${res?.file || ''} — أرفق مستنداتك الآن`, 'ok');
    done();
  };
}
