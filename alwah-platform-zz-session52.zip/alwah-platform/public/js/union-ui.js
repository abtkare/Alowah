// الجلسة 52: اتحاد الصناعات العراقي — أدوات مشتركة بين بوابة الاتحاد وملف الطلب (المصرف والجهات) وبوابة المقترض
import { esc, dt, badge, iqd, rpc, toast, cleanErr, modal, mapsLink, IND_CATS } from './core.js';
import { qrSvg } from './qr.js';

export const UF_ST = {
  new: ['وارد — قسم العضوية والتسجيل', 'info'], returned: ['أُعيد للصناعي للاستكمال', 'warn'], inspection: ['الكشف الموقعي', 'warn'],
  committee: ['لجنة الصنف', 'warn'], signing: ['بانتظار قرار الأمين العام', 'warn'], issued: ['صدر الكتاب', 'ok'], delivered: ['استلمه المصرف', 'ok'],
  done: ['أُنجز', 'ok'], rejected: ['مرفوض', 'bad'], cancelled: ['ملغى', 'muted'],
};
export const UF_KIND = { membership: ['انتماء وهوية صناعية', '🪪'], endorse: ['تأييد صناعي لقرض', '📜'], install: ['تأييد نصب المكائن', '⚙️'], production: ['تأييد بدء الإنتاج', '🏭'], followup: ['كشف متابعة', '🔎'] };
export const UM_ST = { pending: ['قيد الدراسة', 'warn'], approved: ['نافذة', 'ok'], rejected: ['مرفوضة', 'bad'], suspended: ['معلّقة', 'bad'], expired: ['منتهية — تحتاج تجديداً', 'warn'] };
export const SITE_ST = { operating: ['يعمل وينتج', 'ok'], under_construction: ['قيد الإنشاء أو النصب', 'warn'], stopped: ['متوقف', 'bad'], not_found: ['غير موجود في العنوان', 'bad'] };
export const REC = { approve: ['التأييد', 'ok'], conditional: ['التأييد بشروط', 'warn'], reject: ['عدم التأييد', 'bad'] };
// خطوات معاملة التأييد كما يراها الجميع
export const UF_STEPS = [['new', 'التدقيق'], ['inspection', 'الكشف'], ['committee', 'لجنة الصنف'], ['signing', 'القرار'], ['issued', 'الكتاب'], ['delivered', 'استلام المصرف']];
export const UF_STEPS_SHORT = [['inspection', 'الكشف'], ['signing', 'القرار'], ['done', 'الكتاب']];
export const ufBadge = s => badge(UF_ST[s] || [s, 'muted']);
export const umBadge = s => badge(UM_ST[s] || [s, 'muted']);
export const catLabel = c => IND_CATS[c] || c || '';
export const verifyUrl = code => `${location.origin}/v/${encodeURIComponent(code || '')}`;
const day = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'medium' }) : '—';

export function stepsBar(f) {
  const steps = ['membership', 'endorse'].includes(f.kind) ? UF_STEPS.filter(x => f.kind === 'endorse' || x[0] !== 'delivered') : UF_STEPS_SHORT;
  const order = steps.map(x => x[0]);
  let i = order.indexOf(f.status);
  if (f.status === 'returned') i = 0;
  if (f.status === 'done' || f.status === 'delivered') i = order.length;
  if (f.status === 'issued') i = order.indexOf('issued') + 1;
  if (['rejected', 'cancelled'].includes(f.status)) return '';
  return `<div class="ins-steps">${steps.map(([k, t], j) => `<span class="${j < i ? 'done' : j === i ? 'on' : ''}"><i>${j < i ? '✓' : j + 1}</i>${t}</span>`).join('')}</div>`;
}

// نص الكتاب (تأييد صناعي، قرار انتماء، تأييد نصب أو إنتاج، تقرير متابعة) مع رمز QR للتحقق
export function letterHtml(l) {
  const b = l.body || {}, k = l.kind, rows = [];
  const add = (t, v) => { if (v != null && v !== '') rows.push(`<dt>${t}</dt><dd>${v}</dd>`); };
  add('الهوية الصناعية', b.member ? `<b class="num">${esc(b.member)}</b>${b.member_valid ? ` · نافذة حتى <span class="num">${esc(b.member_valid)}</span>` : ''}` : '');
  add('صاحب المعمل', esc(b.owner || '')); add('المعمل', esc(b.factory || '')); add('الصنف', esc(b.category || ''));
  add('الموقع', esc([b.governorate, b.address].filter(Boolean).join(' — ')) + (b.gps ? ` · <a href="${mapsLink(b.gps)}" target="_blank" rel="noopener">📍 الخريطة</a>` : ''));
  if (k === 'endorse') {
    add('إجازة التنمية الصناعية', b.dev_license ? `<span class="num">${esc(b.dev_license)}</span> · ${esc(b.dev_license_kind || '')}` : '');
    add('طلب القرض', `<span class="num">${esc(b.app || '')}</span> — ${esc(b.program || '')}`); add('المصرف', esc(b.bank || ''));
    add('مبلغ القرض', iqd(b.amount)); add('الغرض', esc(b.purpose || ''));
    add('حالة المعمل عند الكشف', SITE_ST[b.site_state] ? esc(SITE_ST[b.site_state][0]) : '');
    add('القيمة المقدّرة للموجودات', b.assessed_value ? iqd(b.assessed_value) : '');
    add('عروض أسعار المكائن', b.quotes_total ? `${iqd(b.quotes_total)}${b.fair_value ? ` · القيمة العادلة بتقدير المهندس ${iqd(b.fair_value)}` : ''} · ${b.price_ok ? '<b style="color:var(--ok)">معقولة</b>' : '<b style="color:var(--warn)">عليها ملاحظة</b>'}` : '');
    add('الطاقة الإنتاجية', esc(b.capacity || '')); add('العاملون', b.workers ? `<span class="num">${b.workers}</span>` : '');
    add('الكشف', `${esc(b.engineer || '')} · ${day(b.visit_at)}`);
    add('توصية لجنة الصنف', REC[b.committee] ? esc(REC[b.committee][0]) : ''); add('الشروط والملاحظات', esc(b.conditions || ''));
  } else if (k === 'membership') {
    add('تاريخ الانتماء', `<span class="num">${esc(b.joined || '')}</span>`);
  } else {
    add('طلب القرض', `<span class="num">${esc(b.app || '')}</span> — ${esc(b.bank || '')}`); add('مبلغ القرض', b.amount ? iqd(b.amount) : '');
    add('النتيجة', b.result === 'ok' ? '<b style="color:var(--ok)">مطابق</b>' : '<b style="color:var(--bad)">غير مطابق</b>');
    add('حالة المعمل', SITE_ST[b.site_state] ? esc(SITE_ST[b.site_state][0]) : '');
    if (k === 'install') add('مطابقة المكائن المنصوبة لما مُوّل', b.machines_match ? 'نعم' : 'لا');
    add('الطاقة الإنتاجية', esc(b.capacity || '')); add('الكشف', `${esc(b.engineer || '')} · ${day(b.visit_at)}`); add('الملاحظات', esc(b.note || ''));
  }
  return `<div class="un-letter ${l.revoked_at ? 'void' : ''}">
    <div class="un-lh"><div><b>اتحاد الصناعات العراقي</b><small>Iraqi Federation of Industries — تأسس 1956</small></div><span class="sp"></span>
      <div class="small" style="text-align:left">العدد <b class="num" dir="ltr">${esc(l.no)}</b><br>التاريخ <span class="num">${day(l.issued_at)}</span></div></div>
    <h3>${esc(l.title)}</h3>
    ${b.statement ? `<p class="un-stmt">${esc(b.statement)}</p>` : ''}
    <dl class="kv sm">${rows.join('')}</dl>
    <div class="un-lf"><div>${qrSvg(verifyUrl(l.verify_code), { size: 112, label: 'رمز التحقق من الكتاب' })}<div class="num small" dir="ltr" style="text-align:center">${esc(l.verify_code)}</div></div>
      <div class="small"><b>${esc(l.body?.issuer || l.issued_by_name || '')}</b><div class="muted">${esc(l.body?.issuer_title || l.issued_by_title || '')}</div>
        ${l.valid_until ? `<div>نافذ حتى <b class="num">${esc(l.valid_until)}</b></div>` : ''}
        <div class="muted" style="margin-top:6px">امسح الرمز أو افتح <span dir="ltr">${esc(location.host)}/v/${esc(l.verify_code)}</span> للتحقق من سلامة الكتاب</div></div></div>
    ${l.revoked_at ? `<div class="notice bad mt"><b>مسحوب</b> — ${esc(l.revoke_reason || '')} · ${dt(l.revoked_at)}</div>` : ''}
    ${l.ack_at ? `<div class="small mt" style="color:var(--ok)">✓ استلمه المصرف: ${esc(l.ack_by || '')} — <span class="num">${esc(l.ack_no || '')}</span> · ${dt(l.ack_at)}</div>` : ''}
    <details class="small mt"><summary>البصمة الرقمية (SHA-256)</summary><p class="num" dir="ltr" style="word-break:break-all;margin:4px 0 0">${esc(l.sha256 || '')}</p></details>
  </div>`;
}
export function openLetter(l) {
  const m = modal(`${letterHtml(l)}<div class="row mt"><button class="btn ghost" data-print>🖨 طباعة</button><span class="sp"></span><button class="btn ghost" data-x>إغلاق</button></div>`, { wide: true });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-print]').onclick = () => { const w = window.open('', '_blank'); if (!w) return; w.document.write(`<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>${esc(l.no)}</title><link rel="stylesheet" href="/css/app.css"><body style="padding:24px;background:#fff">${letterHtml(l)}<script>setTimeout(()=>print(),400)<\/script></body></html>`); w.document.close(); };
}

// بطاقة الهوية الصناعية برمز QR
export function memberCard(m) {
  return `<div class="un-card ${m.valid ? '' : 'off'}">
    <div class="row"><b>اتحاد الصناعات العراقي</b><span class="sp"></span>${umBadge(m.status)}</div>
    <div class="un-cb"><div style="flex:1"><small>الهوية الصناعية</small><div class="num un-no" dir="ltr">${esc(m.code || '—')}</div>
      <div><b>${esc(m.factory_name || '')}</b></div><div class="small">${esc(m.owner_name || '')} · ${esc(catLabel(m.category))}</div>
      <div class="small">${esc(m.governorate || '')}${m.valid_until ? ` · نافذة حتى <b class="num">${esc(m.valid_until)}</b>` : ''}</div></div>
      ${m.verify_code ? `<div>${qrSvg(verifyUrl(m.verify_code), { size: 92, label: 'رمز التحقق من الهوية' })}</div>` : ''}</div></div>`;
}

// ───────── ملف الطلب: صندوق الاتحاد للمصرف والجهات والمقترض ─────────
export async function mountUnionReport(ctx, app, box) {
  let R;
  try { R = await rpc(ctx.sb, 'union_app_report', { p_app: app.id }); } catch (e) { box.innerHTML = ''; return; }
  const m = R.member, F = R.files || [], L = R.letters || [];
  const isBank = ctx.profile?.portal === 'bank';
  const paint = () => {
    box.innerHTML = `<div class="card mb"><h3>🏭 اتحاد الصناعات العراقي<span class="sp"></span>${R.letter_ok ? badge(['تأييد نافذ', 'ok']) : badge(['لا تأييد نافذ', 'warn'])}</h3>
      ${m ? `<dl class="kv sm"><dt>الهوية الصناعية</dt><dd>${m.code ? `<b class="num">${esc(m.code)}</b>` : 'يُدرس انتماؤه مع القرض'} ${umBadge(m.status)}${m.valid_until ? ` · حتى <span class="num">${esc(m.valid_until)}</span>` : ''}</dd>
        <dt>المعمل</dt><dd>${esc(m.factory)} — ${esc(m.category)}</dd></dl>` : '<p class="muted small">لا هوية صناعية مرتبطة بالطلب.</p>'}
      ${F.map(f => `<div class="un-row"><span>${UF_KIND[f.kind]?.[1] || ''} <b>${esc(f.kind_label)}</b> <span class="num small muted">${esc(f.code)}</span></span><span class="sp"></span>${ufBadge(f.status)}
        ${f.late ? '<span class="tag bad-t">متأخرة</span>' : ''}<div class="small muted" style="width:100%">${f.engineer ? `المهندس: ${esc(f.engineer)} · ` : ''}${f.site_state ? `المعمل: ${esc(SITE_ST[f.site_state]?.[0] || '')} · ` : ''}${f.assessed_value ? `الموجودات ${iqd(f.assessed_value)} · ` : ''}${f.reason ? `السبب: ${esc(f.reason)}` : ''}${f.status === 'done' ? (f.result === 'ok' ? 'النتيجة: مطابق' : '<b style="color:var(--bad)">النتيجة: غير مطابق</b>') : ''}</div></div>`).join('') || '<p class="muted small">لم تُفتح معاملة لدى الاتحاد بعد — تُفتح آلياً حين يثبّت المقترض مبلغ القرض.</p>'}
      ${L.length ? `<h4 style="margin:12px 0 6px">الكتب الصادرة</h4>${L.map(l => `<div class="un-row"><button type="button" class="linkbtn" data-l="${l.id}">📜 ${esc(l.title)}</button><span class="sp"></span>
        <span class="num small" dir="ltr">${esc(l.no)}</span>${l.revoked_at ? badge(['مسحوب', 'bad']) : l.ack_at ? badge(['استُلم', 'ok']) : ''}
        ${isBank && R.can_ack && !l.revoked_at && !l.ack_at ? `<button type="button" class="btn sm cyan" data-ack="${l.id}">✓ تأكيد الاستلام</button>` : ''}</div>`).join('')}` : ''}
      ${isBank && R.can_ack && app.stage >= 33 && app.status === 'active' ? '<div class="row mt"><span class="sp"></span><button type="button" class="btn ghost sm" data-req>🔎 طلب كشف متابعة من الاتحاد</button></div>' : ''}
    </div>`;
    box.querySelectorAll('[data-l]').forEach(b => b.onclick = () => openLetter(L.find(x => x.id === b.dataset.l)));
    box.querySelectorAll('[data-ack]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      try { const r = await rpc(ctx.sb, 'union_letter_ack', { p_letter: b.dataset.ack }); toast(`سُجّل الاستلام — ${r.ack_no}`, 'ok'); R = await rpc(ctx.sb, 'union_app_report', { p_app: app.id }); L.splice(0, L.length, ...(R.letters || [])); paint(); }
      catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    });
    const rq = box.querySelector('[data-req]');
    if (rq) rq.onclick = () => {
      const md = modal(`<h3>🔎 طلب كشف متابعة</h3><p class="small muted">يزور مهندس الاتحاد المعمل ويصدر تقريراً بحالته (يعمل، متوقف…) يصلكم آلياً.</p>
        <div class="field"><label>سبب الطلب</label><textarea class="input" rows="3" data-n placeholder="مثال: تأخر سداد قسطين ونسمع عن توقف المعمل"></textarea></div>
        <div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الطلب</button></div>`);
      md.el.querySelector('[data-s]').onclick = async e => {
        e.target.disabled = true;
        try { const r = await rpc(ctx.sb, 'union_request', { p_app: app.id, p_note: md.el.querySelector('[data-n]').value.trim() }); md.close(); toast(`أُرسل الطلب — ${r.code}`, 'ok'); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    };
  };
  paint();
}
