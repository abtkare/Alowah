// خادم «ألواح» — بلا حزم خارجية. يخدم الملفات الثابتة ويوجّه روابط البوابات.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://chjeqtjyywomtcenizxp.supabase.co';
const OCR_URL = process.env.OCR_URL || '';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_yewCPqcDPAFW8RPqeJgrow_QTx57Ixy';
// الجلسة 15: التوقيع الإلكتروني — السر المشترك مع قاعدة البيانات يوضع في Render فقط (ESIGN_DB_SECRET)
const esignHandle = require('./esign.js')({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET: process.env.ESIGN_DB_SECRET || '', PUBLIC_URL: process.env.PUBLIC_URL || '' });
// الجلسة 23: الرسائل النصية الحقيقية — المزوّد ومفاتيحه في Render فقط (انظر sms.js)
// الجلسة 49: التحقق بالوجه (Face ID) قبل أي إجراء على معاملة — يفحص الخادم توقيع الجهاز
const faceHandle = require('./faceid.js')({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET: process.env.ESIGN_DB_SECRET || '' });
const { logoToIcon } = require('./pwa-icon.js');
const SMS = require('./sms.js')({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET: process.env.ESIGN_DB_SECRET || '', PUBLIC_URL: process.env.PUBLIC_URL || 'https://alwah-platform.onrender.com' });

// ── تحديث قاعدة البيانات تلقائياً عند التشغيل (دون نسخ أو لصق) ──
// يعمل فقط إن وُضع في Render المتغير SUPABASE_ACCESS_TOKEN (رمز وصول من حساب Supabase).
// يتحقق أولاً: إن كان التحديث مطبقاً لا يفعل شيئاً. يمكن حذف الرمز من Render بعد النجاح.
const SB_TOKEN = process.env.SUPABASE_ACCESS_TOKEN || '';
const SB_REF = process.env.SUPABASE_PROJECT_REF || (SUPABASE_URL.match(/https:\/\/([a-z0-9]+)\.supabase/) || [])[1] || '';
const MIGRATIONS = [
  { name: 'الجلسة 4: آلية التمويل والأداء والدفع والمستندات والتواقيع', file: 'supabase/session4_apply.sql', done: "select to_regclass('public.event_signatures') is not null as done" },
  { name: 'الجلسة 5: عمولة كل مصرف، طرق الدفع، وكالة المالك، ودور البنك المركزي الرقابي', file: 'supabase/session5_apply.sql', done: "select exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'bank_terms' and column_name = 'commission_pct') and position('bank_choice' in pg_get_functiondef(coalesce(to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)'), 'public.citizen_step(uuid,integer,jsonb)'::regprocedure))) > 0 and position('''poa''' in pg_get_functiondef('public.set_property_ownership(uuid,jsonb)'::regprocedure)) > 0 and to_regprocedure('public.cbi_oversight_note(uuid,text)') is not null as done" },
  { name: 'فك ارتباط البطاقة الوطنية بالحساب التجريبي القديم (بطلب صاحبها)', file: 'supabase/session5_release_id.sql', done: "select exists (select 1 from profiles where username like 'archived-%') as done" },
  { name: 'الجلسة 6: مبادرة تمويل مشاريع الأطباء البيطريين — النقابة ودائرة البيطرة والدفعات', file: 'supabase/session6_apply.sql', done: "select to_regclass('public.vet_tranches') is not null and to_regprocedure('public.cbi_set_setting(text,numeric,text)') is not null and to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)') is not null and exists (select 1 from profiles where username = 'vetdept1') as done" },
  { name: 'الجلسة 7: سجل مراجعة قراءة البطاقة الوطنية', file: 'supabase/session7_apply.sql', done: "select exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'id_review') and position('id_review' in pg_get_functiondef('public.update_my_id_card(jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 9: ربط المواطن بالمصرف المختار، رقم الحساب عند فتحه، ولوحة مشغّل النظام', file: 'supabase/session9_apply.sql', done: "select to_regprocedure('public.admin_app_action(uuid,text,text)') is not null and to_regprocedure('public.start_application_bank(uuid,uuid,integer,text,text,numeric,numeric)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_open_account') and exists (select 1 from profiles where username = 'superadmin') as done" },
  { name: 'الجلسة 11: إدارة الموظفين داخل كل جهة — مدير الجهة والفرع والقسم، توزيع المهام والبديل، «حسابي» وإجبار تغيير كلمة المرور', file: 'supabase/session11_apply.sql', done: "select to_regclass('public.stage_assignments') is not null and to_regprocedure('public.team_set_assignment(integer,uuid,uuid,uuid)') is not null and to_regprocedure('public.update_my_staff_phone(text,text)') is not null and position('_assignment_ok' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and to_regprocedure('public.my_account()') is not null as done" },
  { name: 'الجلسة 12: تأكيد مكتوب من كل موظف عند الإنجاز، والإرجاع الموجَّه بالنواقص وأولوية «مستعجل»', file: 'supabase/session12_apply.sql', done: "select to_regprocedure('public.stage_decision(uuid,text,text,text,integer)') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'applications' and column_name = 'returned_from') and position('alwah.confirmed' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 13: رقم السلفة التجميعية فريد على مستوى المنصة', file: 'supabase/session13_apply.sql', done: "select exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = 'batch_create' and routine_definition like '%pg_advisory_xact_lock%') as done" },
  { name: 'الجلسة 14: كتاب الرهن وصورة إشارة الحجز إلزاميان، ومفاتحة المصرف الموطَّن لراتب الكفيل لتفعيل الاستقطاع المباشر', file: 'supabase/session14_apply.sql', done: "select to_regclass('public.salary_referrals') is not null and to_regprocedure('public.registry_annotate(uuid,jsonb)') is not null and to_regprocedure('public.payroll_inbox()') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'mortgage_referrals' and column_name = 'mark_doc') and exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = 'advance_application' and routine_definition like '%salary_referrals%') as done" },
  { name: 'الجلسة 15: التوقيع الإلكتروني لعقد التمويل والكمبيالة من «بوابة المقترض» — التحقق من الوجه وبصمة الجهاز', file: 'supabase/session15_apply.sql', done: "select to_regclass('public.esign_requests') is not null and to_regprocedure('public.esign_apply(text,uuid,text,jsonb,text)') is not null and position('esign_requests' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and position('kyc_face' in pg_get_functiondef('public.add_document(uuid,text,text,text,jsonb,uuid)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 16: غرض التمويل ومستنداته، قائمة التدقيق في الاستقبال والرفض الفوري لإكمال النواقص، و«بوابة الخبراء» لدراسات الجدوى', file: 'supabase/session16_apply.sql', done: "select to_regclass('public.expert_referrals') is not null and to_regprocedure('public.expert_action(uuid,text,jsonb)') is not null and to_regprocedure('public.intake_return(uuid,text)') is not null and position('_intake_gate' in pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure)) > 0 and position('rejdoc' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and exists (select 1 from profiles where username = 'exp.ind') as done" },
  { name: 'الجلسة 17: توثيق التركيب بالـGPS والصورة والفيديو، عنوان المنظومة ونوع الموقع، مهلة التنفيذ، حسابات النزاهة والمخاطبات السرية، إعلان المبادرات والإشعارات، والتحليل', file: 'supabase/session17_apply.sql', done: "select to_regclass('public.oversight_letters') is not null and to_regclass('public.initiatives') is not null and to_regclass('public.notifications') is not null and to_regprocedure('public.install_proof(uuid,text,text,jsonb)') is not null and to_regprocedure('public.set_app_site(uuid,jsonb)') is not null and to_regprocedure('public.exec_extend(uuid,integer,text)') is not null and to_regprocedure('public.cbi_analytics()') is not null and exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'applications' and column_name = 'install_geo') and exists (select 1 from information_schema.routines where routine_schema = 'public' and routine_name = '_intake_items' and routine_definition like '%site_geo%') as done" },
  { name: 'الجلسة 18: الصرف للمورد مع استقطاع عمولة المنصة، جدول الأقساط ومتابعة التحصيل، والاطلاع الرقابي للبنك المركزي والنزاهة', file: 'supabase/session18_apply.sql', done: "select to_regclass('public.disbursements') is not null and to_regclass('public.installments') is not null and to_regprocedure('public.repay_info(uuid)') is not null and to_regprocedure('public.installment_collect(uuid,integer,text)') is not null and to_regprocedure('public.oversight_repayments()') is not null and to_regprocedure('public.admin_revenue()') is not null and to_regprocedure('public._implied_rate(numeric,numeric,integer)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_repay_hooks') and exists (select 1 from settings where key = 'supplier_commission_pct') as done" },
  { name: 'الجلسة 19: استكمال عنوان المنظومة بالـGPS من المقترض للطلبات القديمة التي وصلت المصرف بلا عنوان', file: 'supabase/session19_apply.sql', done: "select position('site_gps' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 22: تبسيط رحلة المقترض — المحافظة من الموقع، البدء دون الموقع، النواقص من الهاتف، رابط الموقع ورابط الكفيل، الدبوس اليدوي واستلام جدول الأقساط (خياران للمصرف)', file: 'supabase/session22_apply.sql', done: "select to_regclass('public.app_links') is not null and to_regclass('public.app_fix_requests') is not null and to_regprocedure('public.schedule_ack(uuid,text)') is not null and to_regprocedure('public.site_confirm(uuid,jsonb)') is not null and to_regprocedure('public.bank_set_option(text,boolean)') is not null and position('_g_link_ok' in pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure)) > 0 and position('app_fix_requests' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and position('_put_site_geo' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 23: رسائل SMS حقيقية — رمز التحقق يصل هاتف المعني (المقترض والكفيل ومالك العقار)، وإشعار المقترض برسالة بكل ما يُطلب منه', file: 'supabase/session23_apply.sql', done: "select to_regclass('private.sms_outbox') is not null and to_regprocedure('public.otp_check(text,text)') is not null and to_regprocedure('public._otp_ok(text,text)') is not null and position('_otp_ok(g->>''otp'', ph)' in pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure)) > 0 and position('_otp_ok(p_otp, l.data->>''phone'')' in pg_get_functiondef('public.link_guarantor_consent(text,text,boolean)'::regprocedure)) > 0 and position('_sms_live' in pg_get_functiondef('public.admin_set_setting(text,numeric)'::regprocedure)) > 0 and exists (select 1 from pg_trigger where tgname = 'trg_borrower_asks') and exists (select 1 from pg_trigger where tgname = 'trg_sms_notify') as done" },
  { name: 'الجلسة 24: إجراء واضح للمقترض في مرحلة توقيع العقد — طلب رابط جديد أو التوقيع في الفرع، وإشعار الفرع فور التوقيع', file: 'supabase/session24_apply.sql', done: "select to_regprocedure('public.esign_borrower_ask(uuid,text)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_esign_done_notify') as done" },
  { name: 'الجلسة 25: مكاتب ومراكز دراسات الجدوى المعتمدة من البنك المركزي (اختيار أو كتابة الاسم في أول الطلب، ومسار ميسّر لدى الخبير)، ومشروع التصدير', file: 'supabase/session25_apply.sql', done: "select to_regclass('public.feasibility_offices') is not null and to_regprocedure('public.set_fz_office(uuid,jsonb)') is not null and to_regprocedure('public.admin_save_fz_office(jsonb)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_fz_ref_sla') and position('fz_office' in pg_get_functiondef('public._intake_items(applications)'::regprocedure)) > 0 and position('''export''' in pg_get_functiondef('public.set_app_site(uuid,jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 26: ديوان الرقابة المالية الاتحادي — جهة رقابية بصلاحية اطلاع وتصدير فقط، مع لوحة الموقف المالي ومؤشرات التدقيق والتقرير الرقابي', file: 'supabase/session26_apply.sql', done: "select to_regprocedure('public.audit_overview(integer,uuid)') is not null and exists (select 1 from orgs where type = 'audit') and exists (select 1 from profiles where username = 'audit1' and portal = 'audit') and position('''audit''' in pg_get_functiondef('public._perf_scope(uuid)'::regprocedure)) > 0 and position('''audit''' in pg_get_functiondef('public.oversight_repayments()'::regprocedure)) > 0 and exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'applications' and policyname = 'read_apps' and qual like '%''audit''%') as done" },
  { name: 'الجلسة 27: هوية شاشات الدخول — شعار لكل جهة قطاعية ولكل مصرف يُدار من إعدادات مشغّل النظام', file: 'supabase/session27_apply.sql', done: "select to_regclass('public.brand_logos') is not null and to_regprocedure('public.public_brand(text)') is not null and to_regprocedure('public.admin_set_logo(text,text)') is not null and to_regprocedure('public.my_brand()') is not null as done" },
  { name: 'الجلسة 28: وزارة التخطيط — خارطة الطريق بمراحل وأهداف يقيسها النظام آلياً، وحساب planning1', file: 'supabase/session28_apply.sql', done: "select to_regclass('public.plan_goals') is not null and to_regprocedure('public.planning_overview()') is not null and exists (select 1 from public.profiles where username = 'planning1') and position('planning' in pg_get_functiondef('public._portal_of_role(text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 29: شعارات الجهات في الصفحة الرئيسية، ووزارة المالية — الأثر المالي والتعاميم، وحساب finance1', file: 'supabase/session29_apply.sql', done: "select to_regprocedure('public.public_logo_index()') is not null and to_regprocedure('public.finance_overview()') is not null and to_regclass('public.finance_circulars') is not null and exists (select 1 from public.profiles where username = 'finance1') and position('finance' in pg_get_functiondef('public._portal_of_role(text)'::regprocedure)) > 0 and position('''finance''' in pg_get_functiondef('public.public_brand(text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 31: وزارة التجارة — تأييد رواتب الكفلاء من موظفيها، وإعادة الطلب للمقترض لاستبدال الضمان (كفيل آخر أو ذهب أو عقار)، ورهن الذهب، وحساب trade1', file: 'supabase/session31_apply.sql', done: "select to_regclass('public.employer_checks') is not null and to_regprocedure('public.trade_inbox()') is not null and to_regprocedure('public.guarantee_return(uuid,text)') is not null and to_regprocedure('public.set_guarantee_kind(uuid,text)') is not null and exists (select 1 from public.profiles where username = 'trade1') and position('trade_officer' in coalesce(pg_get_functiondef(to_regprocedure('public._portal_of_role(text)')), '')) > 0 and position('''trade''' in coalesce(pg_get_functiondef(to_regprocedure('public.public_brand(text)')), '')) > 0 and position('employer_checks' in coalesce(pg_get_functiondef(to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)')), '')) > 0 and position('''gold''' in coalesce(pg_get_functiondef(to_regprocedure('public._intake_items(applications)')), '')) > 0 and exists (select 1 from pg_trigger where tgname = 'trg_a_resume_guarantee') and position('resume_to_initial_approval' in coalesce(pg_get_functiondef(to_regprocedure('public._resume_after_guarantee()')), '')) > 0 and exists (select 1 from pg_trigger where tgname = 'trg_guard_guarantee') and exists (select 1 from pg_trigger where tgname = 'trg_emp_checks') and position('initial_validity_days' in coalesce(pg_get_functiondef(to_regprocedure('public.advance_application(uuid,text,text)')), '')) = 0 and to_regprocedure('public._sla_scan()') is not null and to_regprocedure('public.app_clock(uuid)') is not null and position('auto_referrals_on_submit' in coalesce(pg_get_functiondef(to_regprocedure('public._emp_on_app()')), '')) > 0 and position('salary_bank_id' in coalesce(pg_get_functiondef(to_regprocedure('public._citizen_step_solar(uuid,integer,jsonb)')), '')) > 0 and position('stage < 6 or a.stage > 19' in coalesce(pg_get_functiondef(to_regprocedure('public.refer_salary(uuid,jsonb)')), '')) > 0 as done" },
  { name: 'الجلسة 32: وزارة التجارة — خمسة أدوار ومسار الأقسام (الموارد البشرية ← الحسابات ← الكفالات ← المسؤول الإداري ← صاحب الصلاحية)، احتساب الملاءة بنسبة استقطاع قابلة للضبط، سجل الاطلاع، وحسابات تجريبية', file: 'supabase/session32_apply.sql', done: "select to_regclass('public.employer_check_files') is not null and to_regclass('public.employer_check_log') is not null and to_regclass('public.trade_view_log') is not null and to_regclass('public.trade_deduct_limits') is not null and to_regprocedure('public.trade_signer_act(uuid,jsonb)') is not null and to_regprocedure('public.trade_check(uuid)') is not null and to_regprocedure('public.trade_set_limit(jsonb)') is not null and position('trade_signer' in coalesce(pg_get_functiondef(to_regprocedure('public._org_roles(text)')), '')) > 0 and position('trade_signer' in coalesce(pg_get_functiondef(to_regprocedure('public._portal_of_role(text)')), '')) > 0 and position('trade_signer' in coalesce(pg_get_functiondef(to_regprocedure('public._role_title(text)')), '')) > 0 and position('trade_signer' in coalesce(pg_get_functiondef(to_regprocedure('public._role_abbr(text)')), '')) > 0 and position('wf_label' in coalesce(pg_get_functiondef(to_regprocedure('public.guarantee_status(uuid)')), '')) > 0 and position('l.note' in coalesce(pg_get_functiondef(to_regprocedure('public.trade_inbox()')), '')) > 0 and exists (select 1 from pg_trigger where tgname = 'trg_ec_after_insert') and exists (select 1 from public.profiles where username = 'trade.sign') as done" },
  { name: 'الجلسة 33: حساب تجريبي citizen4 — طلب متوقف عند خطوة «الضمان» على «رهن الذهب» لعرض نافذته', file: 'supabase/session33_apply.sql', done: "select exists (select 1 from public.applications a join public.profiles p on p.id = a.citizen_id where p.username = 'citizen4') as done" },
  { name: 'الجلسة 37: بوابة شركات التدقيق الهندسي — أوامر الكشف وتوزيع البنود على المهندسين حسب التخصص، الزيارة بالـGPS، النتيجة على خريطة البنك المركزي وإشعار الجهات، وحسابات تجريبية', file: 'supabase/session37_apply.sql', done: "select to_regclass('public.eng_inspections') is not null and to_regprocedure('public.eng_finalize(uuid,jsonb)') is not null and to_regprocedure('public.eng_app_report(uuid)') is not null and exists (select 1 from public.profiles where username = 'eng.admin') and position('eng_result' in pg_get_functiondef('public._sms_from_notification()'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 39: الهيئة الشرعية للتمويل الإسلامي — مكتبة الصيغ على المذهب الجعفري، دورة اعتماد المنتجات والعقود (تحقق، مداولة على البنود، تصويت، قرار بالبصمة)، منتجات مصرف الواحة الإسلامي، وبطاقات المنتجات وعقودها للمقترض', file: 'supabase/session39_apply.sql', done: "select to_regclass('public.sharia_resolutions') is not null and to_regclass('public.islamic_products') is not null and to_regprocedure('public.app_choose_product(uuid,uuid)') is not null and to_regprocedure('public.islamic_contract_preview(uuid,numeric,integer,uuid,uuid)') is not null and position('''sharia''' in pg_get_functiondef('public.public_brand(text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 40: إضافة الجهات من مشغّل النظام (مصرف، مورد شمسي أو بيطري، فحص هندسي، تأمين) مع حساب الإدارة العليا، وفروع الجهة من «فريقي»، وبوابة شركات التأمين — الوثيقة والمطالبات', file: 'supabase/session40_apply.sql', done: "select to_regclass('public.ins_policies') is not null and to_regclass('public.ins_claims') is not null and to_regprocedure('public.admin_onboard_org(jsonb)') is not null and to_regprocedure('public.team_save_branch(jsonb)') is not null and exists (select 1 from public.profiles where username = 'ins.md') and position('insurer' in pg_get_functiondef('public._org_roles(text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 41: الهيئة الشرعية — الحزمة 2: الحرّاس الآليون في مسار المصرف الإسلامي، توقيع الوعد والعقد المعتمد ببصمته، «عقدي» ورمز التحقق، لا زيادة على المتأخر، وتعديل المنتج المعتمد بنسخة جديدة', file: 'supabase/session41_apply.sql', done: "select to_regclass('public.islamic_app_docs') is not null and to_regprocedure('public.islamic_sign(uuid,text,text,jsonb)') is not null and to_regprocedure('public.islamic_verify(text)') is not null and to_regprocedure('public.islamic_product_amend(uuid)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_isl_guard') as done" },
  { name: 'الجلسة 42: جاهزية الجهة — المشغّل والإدارة العليا يريان ما ينقص كل جهة (لكل قسم ولكل فرع)، ولا يصل عمل آلي لشركة تأمين أو فحص ناقصة، ولا يُفعَّل استقبال مصرف ناقص', file: 'supabase/session42_apply.sql', done: "select to_regprocedure('public.admin_orgs_readiness()') is not null and to_regprocedure('public.team_readiness()') is not null and position('_ins_branch_ready' in pg_get_functiondef('public._ins_pick_org(text)'::regprocedure)) > 0 and position('_ins_assert_ready' in pg_get_functiondef('public.ins_request(uuid,uuid,text)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 43: الهيئة الشرعية — الحزمة 3: المرحلة 25 للطلب الإسلامي «التعهدات والضمانات» فقط، منتجات إسلامية لمسار البيطري مع الحرّاس، توقيع رئيس الهيئة قراراته عبر خدمة التوقيع الإلكتروني، وتقرير الامتثال الشرعي الدوري للبنك المركزي', file: 'supabase/session43_apply.sql', done: "select to_regclass('public.sharia_compliance_reports') is not null and to_regclass('public.sharia_resolution_pdfs') is not null and to_regprocedure('public.sharia_compliance_report(date,date)') is not null and to_regprocedure('public.sharia_esign_apply(text,uuid,text,jsonb,text)') is not null and to_regprocedure('public._isl_esign_info(applications)') is not null and position('_isl_esign_info' in pg_get_functiondef('public.esign_prepare(uuid)'::regprocedure)) > 0 and position('الجلسة 43' in pg_get_functiondef('public._isl_guard()'::regprocedure)) > 0 and position('_isl_type(a)' in pg_get_functiondef('public.stage_confirm_text(uuid)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 44: الهيئة الشرعية — المرحلة الثانية: هيئة في كل مصرف إسلامي، ملاءمة أعضائها من الهيئة المركزية، الصيغ المسموحة، نطاق الاعتماد (مركزي / مصرفي) مع بقاء الاعتمادات السابقة نافذة، التعليق الإشرافي، وتقرير الامتثال لكل هيئة يجمعه تقرير البنك المركزي، وهيئة مصرف الواحة للعرض', file: 'supabase/session44_apply.sql', done: "select to_regclass('public.sharia_board_log') is not null and to_regprocedure('public.sharia_board_create(jsonb)') is not null and to_regprocedure('public.sharia_fit_decide(uuid,uuid,jsonb)') is not null and to_regprocedure('public.sharia_compliance_report(date,date,uuid)') is not null and position('_sh_live(p)' in pg_get_functiondef('public.islamic_offer_products(uuid,numeric,integer,text)'::regprocedure)) > 0 and exists (select 1 from public.sharia_boards where code = 'SHB-WAH') as done" },
  { name: 'الجلسة 45: هيئة الرقابة الشرعية في المصرف — نصاب 3 على الأقل، أمين السر شرط لاكتمال الهيئة، الملاءمة للهيئة المركزية مع إبلاغ البنك المركزي للاطلاع وسجل الملاءمة، وعضو ثالث لهيئة الواحة للعرض', file: 'supabase/session45_apply.sql', done: "select to_regprocedure('public.sharia_fit_register()') is not null and to_regprocedure('public._sh_bank_min_quorum()') is not null and position('sharia_secretary' in pg_get_functiondef('public._sh_board_ready(uuid)'::regprocedure)) > 0 and position('cbi' in pg_get_functiondef('public.sharia_fit_decide(uuid,uuid,jsonb)'::regprocedure)) > 0 and exists (select 1 from public.profiles where username = 'wsh.m3') and not exists (select 1 from public.sharia_boards where scope = 'bank' and quorum < 3) as done" },
  { name: 'الجلسة 46: رقم حساب المقترض يكتبه موظف المصرف بعد فتحه (لا توليد آلي)، المصارف بلا ربط تقني تعمل من بوابة ألواح، برامج التمويل لكل مصرف (الشمسي، البيطري، المصدّرون، التجاري، التجارة الإلكترونية)، وإضافة المصرف الصناعي العراقي ومصرف TPI', file: 'supabase/session46_apply.sql', done: "select to_regprocedure('public.bank_set_account(uuid,text,text)') is not null and to_regprocedure('public.admin_set_bank_mode(uuid,jsonb)') is not null and position('auth.uid()' in pg_get_functiondef('public._open_account()'::regprocedure)) > 0 and exists (select 1 from public.profiles where username = 'tpi.payroll') and exists (select 1 from public.profiles where username = 'ind.payroll') as done" },
  { name: 'الجلسة 47: برامج المصرف — الإدارة العليا تطلق برامج المصدّرين والتجاري والتجارة الإلكترونية وتحدد ثوابتها ومتغيراتها وتديرها، وتنضم إلى المبادرات؛ والمقترض يقدّم عليها بخمس خطوات', file: 'supabase/session47_apply.sql', done: "select to_regclass('public.bank_programs') is not null and to_regprocedure('public.bank_program_status(uuid,text,text)') is not null and to_regprocedure('public._trade_step(uuid,integer,jsonb)') is not null and position('_trade_step' in pg_get_functiondef('public.citizen_step(uuid,integer,jsonb)'::regprocedure)) > 0 and position('_bp_fee_quote' in pg_get_functiondef('public.pay_application_fees(uuid,uuid,text,text)'::regprocedure)) > 0 and to_regprocedure('public._bp_fee_quote(uuid,bigint)') is not null and exists (select 1 from public.profiles where username = 'citizen7') as done" },
  { name: 'الجلسة 48: برامج المصارف (المصدّرون، التجاري، التجارة الإلكترونية) قطاعات مستقلة في لوحات وزارة التخطيط ووزارة المالية والبنك المركزي وديوان الرقابة — لا تُحسب ضمن الطاقة الشمسية المنزلية', file: 'supabase/session48_apply.sql', done: "select to_regprocedure('public._app_sector(text,text)') is not null and position('_app_sector' in pg_get_functiondef('public._plan_apps(text,text)'::regprocedure)) > 0 and position('_app_sector' in pg_get_functiondef('public.finance_overview()'::regprocedure)) > 0 and position('_app_sector' in pg_get_functiondef('public.cbi_analytics()'::regprocedure)) > 0 and position('_app_sector' in pg_get_functiondef('public.audit_overview(integer,uuid)'::regprocedure)) > 0 and position('ecommerce_program' in pg_get_functiondef('public.planning_save_goal(jsonb,text)'::regprocedure)) > 0 and position('ecommerce_program' in pg_get_functiondef('public.cbi_publish_initiative(jsonb)'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 49: التحقق بالوجه (Face ID) — كل موظف في الجهات يسجّل بصمة وجهه على جهازه، ولا يُنفَّذ أي إجراء على معاملة دون التحقق منها، مع وضع مطور لتخطيه', file: 'supabase/session49_apply.sql', done: "select to_regclass('private.face_creds') is not null and to_regprocedure('public.face_done(text,text,text,jsonb)') is not null and to_regprocedure('public.admin_face_settings(jsonb)') is not null and exists (select 1 from pg_trigger where tgname = 'trg_zz_face_gate') and position('alwah.face_skip' in pg_get_functiondef('public.ins_inbox()'::regprocedure)) > 0 and position('face_dev' in pg_get_functiondef('public.public_config()'::regprocedure)) > 0 as done" },
  { name: 'الجلسة 52: اتحاد الصناعات العراقي (بوابة /union) — الهوية الصناعية وسجل الأعضاء، ودورة تأييد القرض الصناعي (الكشف الموقعي، لجنة الصنف، قرار الأمين العام، كتاب مختوم برمز تحقق، استلام المصرف)، ونوع برنامج «القرض الصناعي» وتأييد نصب المكائن وبدء الإنتاج', file: 'supabase/session52_apply.sql', done: "select to_regclass('public.union_files') is not null and to_regprocedure('public.union_act(uuid,jsonb)') is not null and to_regprocedure('public._ind_step(uuid,integer,jsonb)') is not null and position('_ind_step' in pg_get_functiondef('public.citizen_step(uuid,integer,jsonb)'::regprocedure)) > 0 and position('_un_fee_items' in pg_get_functiondef('public.pay_application_fees(uuid,uuid,text,text)'::regprocedure)) > 0 and exists (select 1 from public.profiles where username = 'union.sg') and exists (select 1 from public.bank_programs where code = 'P-IND-002') as done" },
];
const MIG = { state: SB_TOKEN ? 'pending' : 'no_token', log: [] };
async function sbQuery(sql) {
  const r = await fetch(`https://api.supabase.com/v1/projects/${SB_REF}/database/query`, {
    method: 'POST', headers: { Authorization: `Bearer ${SB_TOKEN}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ query: sql }),
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${t.slice(0, 600)}`);
  try { return JSON.parse(t); } catch { return t; }
}
async function runMigrations() {
  if (!SB_TOKEN || !SB_REF) return;
  MIG.state = 'running';
  try {
    // الجلسة 39: سجل الملفات المطبّقة. الملف المسجَّل لا يُعاد تطبيقه أبداً، حتى لو غيّرت جلسة لاحقة الدوال التي يفحصها شرطه
    // (كان شرط الجلستين 19 و22 يفشل بعد الجلسة 25، فتُعاد الملفات القديمة وتمحو تعديلات الجلسات 31 و37).
    await sbQuery("create schema if not exists private; create table if not exists private.alwah_migrations (file text primary key, applied_at timestamptz not null default now(), note text); revoke all on private.alwah_migrations from anon, authenticated;");
    const led = await sbQuery('select file from private.alwah_migrations');
    const applied = new Set((Array.isArray(led) ? led : []).map(r => r.file));
    const record = f => sbQuery(`insert into private.alwah_migrations(file) values ('${f.replace(/'/g, "''")}') on conflict do nothing`);
    for (const m of MIGRATIONS) {
      if (applied.has(m.file)) { MIG.log.push(`✓ ${m.name}: مطبق مسبقاً`); continue; }
      const chk = await sbQuery(m.done);
      if (Array.isArray(chk) && chk[0] && chk[0].done) { await record(m.file); MIG.log.push(`✓ ${m.name}: مطبق مسبقاً`); continue; }
      MIG.log.push(`… ${m.name}: جارِ التطبيق`);
      await sbQuery(fs.readFileSync(path.join(__dirname, m.file), 'utf8'));
      const ok = await sbQuery(m.done);
      if (!(Array.isArray(ok) && ok[0] && ok[0].done)) throw new Error('انتهى التنفيذ دون أن يظهر أثر التحديث');
      await record(m.file);
      MIG.log.push(`✓ ${m.name}: طُبّق بنجاح`);
    }
    MIG.state = 'done';
  } catch (e) { MIG.state = 'failed'; MIG.log.push('✗ ' + String(e.message || e)); }
  MIG.at = new Date().toISOString();
  console.log('[migrate]', MIG.state, MIG.log.join(' | '));
}

// كل بوابة لها رابط دخول مستقل
const PORTALS = ['citizen', 'borrower', 'bank', 'registry', 'cbi', 'supplier', 'integrity', 'syndicate', 'vetdept', 'admin', 'expert', 'audit', 'planning', 'finance', 'trade', 'auditor', 'sharia', 'insurance', 'union'];

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.mp4': 'video/mp4', '.webm': 'video/webm', '.vtt': 'text/vtt; charset=utf-8', '.woff2': 'font/woff2'
};
const SECURITY = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' };

function send(res, code, body, type, extra = {}) {
  res.writeHead(code, { 'Content-Type': type, ...SECURITY, ...extra });
  res.end(body);
}

// يدعم طلبات المدى (Range) — ضروري لتشغيل الفيديو على آيفون وسفاري
function serveFile(req, res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return serve404(res);
    const ext = path.extname(file).toLowerCase();
    const type = TYPES[ext] || 'application/octet-stream';
    const cache = ext === '.html' ? 'no-cache' : (ext === '.mp4' || ext === '.jpg' || ext === '.webm') ? 'public, max-age=86400' : 'public, max-age=300';
    const head = { 'Content-Type': type, 'Cache-Control': cache, 'Accept-Ranges': 'bytes', ...SECURITY };
    const range = req.headers.range;
    let start = 0, end = st.size - 1, code = 200;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (m) {
        if (m[1] === '' && m[2] !== '') { start = Math.max(0, st.size - Number(m[2])); }
        else { start = Number(m[1] || 0); if (m[2] !== '') end = Math.min(Number(m[2]), st.size - 1); }
        if (start > end || start >= st.size) {
          res.writeHead(416, { 'Content-Range': `bytes */${st.size}`, ...SECURITY }); return res.end();
        }
        code = 206; head['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
      }
    }
    head['Content-Length'] = end - start + 1;
    res.writeHead(code, head);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.end()).pipe(res);
  });
}

// ── الجلسة 29: شعارات الجهات للصفحة الرئيسية ──
// الشعار محفوظ في قاعدة البيانات؛ الخادم يجلبه مرة ويقدّمه صورةً عادية مع تخزين مؤقت،
// فتظهر شعارات كل الجهات في الصفحة الرئيسية دون تحميل ميغابايتات من البيانات على الهاتف.
const BRAND = { idx: null, idxAt: 0, img: new Map() };
async function sbRpc(fn, args) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: 'POST', headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify(args || {}),
  });
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}
async function brandHandle(req, res, p) {
  try {
    if (p === '/brand/index.json') {
      if (!BRAND.idx || Date.now() - BRAND.idxAt > 30000) { BRAND.idx = await sbRpc('public_logo_index'); BRAND.idxAt = Date.now(); }
      return send(res, 200, JSON.stringify(BRAND.idx), TYPES['.json'], { 'Cache-Control': 'no-cache' });
    }
    // /brand/logo/portal-cbi?v=… أو /brand/logo/org-<uuid>?v=…
    const m = /^\/brand\/logo\/(portal-[a-z]+|org-[0-9a-f-]{36})$/.exec(p);
    if (!m) return serve404(res);
    const key = m[1].replace('-', ':');
    const v = new URL(req.url, 'http://x').searchParams.get('v') || '';
    let hit = BRAND.img.get(key);
    if (!hit || hit.v !== v) {
      const d = await sbRpc('public_logo', { p_key: key });
      const mm = /^data:(image\/(?:png|webp|jpeg|svg\+xml));base64,(.+)$/.exec(d || '');
      if (!mm) { BRAND.img.delete(key); return serve404(res); }
      hit = { v, type: mm[1], buf: Buffer.from(mm[2], 'base64') };
      BRAND.img.set(key, hit);
    }
    const extra = { 'Cache-Control': v ? 'public, max-age=604800, immutable' : 'public, max-age=300' };
    if (hit.type === 'image/svg+xml') extra['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'";
    return send(res, 200, hit.buf, hit.type, extra);
  } catch { return send(res, 502, '', 'text/plain'); }
}

// ── الجلسة 50: تثبيت كل بوابة تطبيقاً مستقلاً على الشاشة (آيفون، أندرويد، ويندوز، ماك، لينكس) ──
// لكل بوابة ملف تعريف (manifest) وأيقونة باسمها ولونها. لا تغيير على منطق البوابات: الصفحة نفسها
// تُقدَّم مع روابط الأيقونة وملف التعريف الخاصين بالبوابة فقط.
const PWA = {
  citizen: ['بوابة المقترض', 'المقترض', '#0e7490'], bank: ['بوابة المصرف', 'المصرف', '#1d4ed8'],
  registry: ['التسجيل العقاري', 'التسجيل العقاري', '#7c3aed'], cbi: ['البنك المركزي العراقي', 'البنك المركزي', '#0f766e'],
  supplier: ['بوابة المورد', 'المورد', '#ea580c'], integrity: ['هيئة النزاهة', 'هيئة النزاهة', '#b91c1c'],
  syndicate: ['نقابة الأطباء البيطريين', 'النقابة', '#15803d'], vetdept: ['دائرة البيطرة', 'دائرة البيطرة', '#4d7c0f'],
  admin: ['مشغّل النظام', 'مشغّل النظام', '#334155'], expert: ['بوابة الخبراء', 'الخبراء', '#a16207'],
  audit: ['ديوان الرقابة المالية', 'ديوان الرقابة', '#9f1239'], planning: ['وزارة التخطيط', 'وزارة التخطيط', '#0369a1'],
  finance: ['وزارة المالية', 'وزارة المالية', '#047857'], trade: ['وزارة التجارة', 'وزارة التجارة', '#c2410c'],
  auditor: ['التدقيق الهندسي', 'التدقيق الهندسي', '#6d28d9'], sharia: ['الهيئة الشرعية', 'الهيئة الشرعية', '#166534'],
  insurance: ['شركات التأمين', 'التأمين', '#be185d'], union: ['اتحاد الصناعات العراقي', 'اتحاد الصناعات', '#4d5b2a'],
};
const pwaKey = seg => (seg === 'borrower' ? 'citizen' : seg);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

// ── الجلسة 51: الأيقونة من شعار الجهة الذي رفعه مشغّل النظام ──
// /app/icon/<البوابة>/<portal | معرّف الجهة>-<180|192|512>.png
// الترتيب: شعار الجهة (المصرف/شركة التأمين) ← شعار البوابة ← الأيقونة العامة للبوابة.
const LOGO = new Map();   // key → { at, buf }
async function logoBuf(key) {
  const hit = LOGO.get(key);
  if (hit && Date.now() - hit.at < 60000) return hit.buf;
  let buf = null;
  try {
    const d = await sbRpc('public_logo', { p_key: key });
    const mm = /^data:image\/png;base64,(.+)$/.exec(d || '');
    if (mm) buf = Buffer.from(mm[1], 'base64');
  } catch { if (hit) return hit.buf; }
  LOGO.set(key, { at: Date.now(), buf });
  return buf;
}
async function pwaIcon(req, res, seg, who, size) {
  const k = pwaKey(seg);
  const keys = (who !== 'portal' ? ['org:' + who] : []).concat('portal:' + k);
  for (const key of keys) {
    const buf = await logoBuf(key);
    const png = buf && logoToIcon(buf, size);
    if (png) return send(res, 200, req.method === 'HEAD' ? '' : png, 'image/png', { 'Cache-Control': 'public, max-age=300', 'Content-Length': png.length });
  }
  return serveFile(req, res, path.join(PUB, 'app', 'icons', `${k}-${size}.png`));
}

function pwaManifest(seg, org) {
  const k = pwaKey(seg), a = PWA[k];
  if (!a) return null;
  const who = org && UUID.test(org) ? org : 'portal';
  const ic = s => `/app/icon/${seg}/${who}-${s}.png`;
  return JSON.stringify({
    id: `/${seg}`, name: `ألواح — ${a[0]}`, short_name: a[1], lang: 'ar', dir: 'rtl',
    start_url: `/${seg}`, scope: `/${seg}`, display: 'standalone', orientation: 'any',
    background_color: '#050810', theme_color: '#050810',
    icons: [
      { src: ic(192), sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: ic(512), sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: ic(192), sizes: '192x192', type: 'image/png', purpose: 'maskable' },
      { src: ic(512), sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  });
}
let PORTAL_HTML = null;
function servePortal(req, res, seg) {
  const k = pwaKey(seg), a = PWA[k];
  const go = html => {
    if (a) {
      html = html
        .replace('<link rel="apple-touch-icon" href="/alwah-logo/favicon/apple-touch-icon.png">',
          `<link rel="apple-touch-icon" href="/app/icon/${seg}/portal-180.png">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-status-bar-style" content="black">\n<meta name="apple-mobile-web-app-title" content="${a[1]}">`)
        .replace('<link rel="manifest" href="/alwah-logo/site.webmanifest">', `<link rel="manifest" href="/app/${seg}.webmanifest">`)
        .replace('</body>', '<script src="/js/pwa.js" defer></script>\n</body>');
    }
    const buf = Buffer.from(html);
    res.writeHead(200, { 'Content-Type': TYPES['.html'], 'Cache-Control': 'no-cache', 'Content-Length': buf.length, ...SECURITY });
    res.end(req.method === 'HEAD' ? undefined : buf);
  };
  if (PORTAL_HTML) return go(PORTAL_HTML);
  fs.readFile(path.join(PUB, 'portal.html'), 'utf8', (e, d) => { if (e) return serve404(res); PORTAL_HTML = d; go(d); });
}

function serve404(res) {
  fs.readFile(path.join(PUB, '404.html'), (e, d) => send(res, 404, d || 'Not found', 'text/html; charset=utf-8'));
}

http.createServer((req, res) => {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { return serve404(res); }

  if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
  if (SMS.handle(req, res, p)) return;
  if (esignHandle(req, res, p)) return;
  if (faceHandle(req, res, p)) return;
  if (p === '/migrate') {
    const label = { no_token: 'لم يُضَف رمز SUPABASE_ACCESS_TOKEN في Render — لا يُطبَّق أي تحديث', pending: 'بانتظار البدء', running: 'جارِ التطبيق… أعد فتح الصفحة بعد دقيقة', done: '✓ تم — قاعدة البيانات محدّثة. يمكنك الآن حذف الرمز من Render ومن حساب Supabase', failed: '✗ فشل التحديث — أرسل لقطة من هذه الصفحة' }[MIG.state];
    const html = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>تحديث قاعدة البيانات</title>
      <body style="font-family:system-ui,sans-serif;max-width:560px;margin:24px auto;padding:0 16px;line-height:1.8"><h2>تحديث قاعدة البيانات</h2>
      <p style="font-size:18px"><b>${label}</b></p><pre style="white-space:pre-wrap;background:#f3f5f9;padding:12px;border-radius:10px">${MIG.log.map(x => x.replace(/[<>&]/g, '')).join('\n') || '—'}</pre>
      <p style="color:#667">${MIG.at || ''}</p></body></html>`;
    return send(res, 200, html, 'text/html; charset=utf-8', { 'Cache-Control': 'no-store' });
  }
  if (p.startsWith('/brand/')) return brandHandle(req, res, p);
  if (p === '/config.js') {
    const js = `window.ALWAH_CONFIG=${JSON.stringify({ url: SUPABASE_URL, key: SUPABASE_ANON_KEY, ocr: OCR_URL })};`;
    return send(res, 200, js, TYPES['.js'], { 'Cache-Control': 'no-cache' });
  }

  const first = p.split('/')[1];
  // الجلسة 50: ملف تعريف التطبيق لكل بوابة، وملف الخدمة (يجب ألا يُخزَّن مؤقتاً حتى تصل تحديثاته فوراً)
  const mm = /^\/app\/([a-z]+)\.webmanifest$/.exec(p);
  if (mm && PORTALS.includes(mm[1])) { const j = pwaManifest(mm[1], new URL(req.url, 'http://x').searchParams.get('o')); if (j) return send(res, 200, j, TYPES['.webmanifest'], { 'Cache-Control': 'no-cache' }); }
  const mi = /^\/app\/icon\/([a-z]+)\/(portal|[0-9a-f-]{36})-(180|192|512)\.png$/.exec(p);
  if (mi && PORTALS.includes(mi[1]) && (mi[2] === 'portal' || UUID.test(mi[2]))) { pwaIcon(req, res, mi[1], mi[2], Number(mi[3])).catch(() => serve404(res)); return; }
  if (p === '/sw.js') return fs.readFile(path.join(PUB, 'sw.js'), (e, d) => e ? serve404(res) : send(res, 200, d, TYPES['.js'], { 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/' }));
  if (p === '/' || p === '') return serveFile(req, res, path.join(PUB, 'index.html'));
  if (PORTALS.includes(first) && !path.extname(p)) return servePortal(req, res, first);
  if (first === 'demo' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'demo.html'));
  // الجلسة 22: روابط لمرة واحدة — تحديد مكان المنظومة، وموافقة الكفيل (دون تسجيل)
  if (first === 'l' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'link.html'));
  // الجلسة 41: صفحة التحقق العامة من العقد الإسلامي الموقّع (رمز QR)
  if (first === 'v' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'verify.html'));

  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) return serve404(res);
  serveFile(req, res, file);
}).listen(PORT, () => { console.log(`Alwah running on :${PORT}`); runMigrations().finally(() => SMS.start()); });
