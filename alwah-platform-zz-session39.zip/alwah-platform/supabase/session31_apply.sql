-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 31
--  (1) وزارة التجارة — بوابة /trade ودور trade_officer:
--      حين يكون كفيل المقترض موظفاً في إحدى دوائر وزارة التجارة تصل الوزارةَ آلياً «طلب تأييد راتب كفيل».
--      الموظف المختص يدقق سجل الكفيل ويسجّل: نوع التعيين، الراتب الصافي، هل هو ضامن لقرض آخر، هل عليه سلفة.
--      النظام يقرر: راتب حر (غير ضامن ولا سلفة) ويغطي حصته من القسط ← موافقة. غير ذلك ← رفض مسبَّب.
--      الوزارة لا ترى إلا كفلاءها، ولا تكتب على المعاملة نفسها.
--  (2) رفض الوزارة يعود إلى موظف المصرف، فيعيد الطلب إلى المقترض بزر واحد لاستبدال الضمان:
--      كفيل موظف آخر، أو رهن ذهب، أو رهن عقار. يعيد المقترض الإرسال فيرجع الطلب إلى الموافقة المبدئية (8) ليوافق مدير الفرع على الضمان الجديد.
--  (3) ضمان جديد: رهن الذهب (وزن وعيار وقيمة تقديرية، ثم استلام الفرع ووزنه وتقييمه).
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) وزارة التجارة: نوع الجهة والبوابة والدور ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance','trade']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance','trade']));

insert into public.orgs(code, type, name)
select 'mot', 'trade', 'وزارة التجارة'
where not exists (select 1 from public.orgs where type = 'trade');

-- الدور trade_officer يُضاف بجانب finance_officer في دوال الأدوار (دون المساس بباقي محتواها)
do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''finance_officer'' then ''MF''', 'when ''finance_officer'' then ''MF'' when ''trade_officer'' then ''MT'''],
  ['public._role_title(text)', 'when ''finance_officer'' then ''محلل مالي — وزارة المالية''', 'when ''finance_officer'' then ''محلل مالي — وزارة المالية'' when ''trade_officer'' then ''مدقق رواتب الكفلاء — وزارة التجارة'''],
  ['public._portal_of_role(text)', 'when r = ''finance_officer'' then ''finance''', 'when r = ''finance_officer'' then ''finance'' when r = ''trade_officer'' then ''trade'''],
  ['public._org_type_of_portal(text)', 'when ''finance'' then ''finance''', 'when ''finance'' then ''finance'' when ''trade'' then ''trade'''],
  ['public._org_roles(text)', 'when ''finance'' then array[''finance_officer'']', 'when ''finance'' then array[''finance_officer''] when ''trade'' then array[''trade_officer'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('trade' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
end $$;

-- شاشة الدخول: احتساب الوزارة ضمن الجهات الحكومية
do $$
declare d text;
begin
  d := pg_get_functiondef('public.public_brand(text)'::regprocedure);
  if position('''trade''' in d) = 0 then
    if position('''planning'',''finance'')' in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في public_brand'; end if;
    execute replace(d, '''planning'',''finance'')', '''planning'',''finance'',''trade'')');
  end if;
end $$;

-- ───────── 2) رهن الذهب: نوع الضمان والإعدادات ─────────
alter table public.applications drop constraint if exists applications_guarantee_type_check;
alter table public.applications add constraint applications_guarantee_type_check check (guarantee_type in ('single_salary','multi_salary','mortgage','gold'));
alter table public.applications add column if not exists return_kind text;
insert into public.settings(key, value, label) values
  ('gold_gram_21', 130000, 'سعر غرام الذهب عيار 21 للتقييم التقديري (د.ع)'),
  ('gold_ltv', 80, 'أقصى نسبة تمويل من قيمة الذهب المرهون (%)')
on conflict (key) do nothing;

-- ───────── 3) طلبات تأييد رواتب الكفلاء لدى وزارة التجارة ─────────
create table if not exists public.employer_checks (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                       -- MOT-2026-00001
  org_id uuid not null references public.orgs(id), -- الوزارة
  application_id uuid not null references public.applications(id) on delete cascade,
  bank_id uuid,
  g_index int not null default 0,
  guarantor_name text not null, guarantor_phone text, guarantor_nid text,
  dept text, declared_salary bigint,
  share bigint not null,                           -- حصة الكفيل من القسط الشهري
  required_net bigint not null,                    -- الراتب الصافي المطلوب = الحصة × معامل الأمان
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled')),
  employment text check (employment in ('permanent','contract','daily','retired','not_found')),
  net_salary bigint, other_guarantee boolean, has_advance boolean, advance_monthly bigint,
  reasons text[], note text,
  decided_by uuid, decided_by_name text, decided_by_code text, decided_by_title text, decided_at timestamptz,
  cancel_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists employer_checks_app on public.employer_checks(application_id);
create index if not exists employer_checks_org on public.employer_checks(org_id, status);

alter table public.employer_checks enable row level security;
drop policy if exists read_emp_checks on public.employer_checks;
create policy read_emp_checks on public.employer_checks for select using (
  (my_portal() = 'bank' and bank_id = my_org()) or (my_portal() = 'trade' and org_id = my_org())
  or my_portal() in ('cbi', 'integrity', 'audit', 'admin'));
grant select on public.employer_checks to authenticated;
revoke insert, update, delete on public.employer_checks from authenticated, anon;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'employer_checks') then
    alter publication supabase_realtime add table public.employer_checks; end if;
exception when undefined_object then null;
end $$;

insert into public.rejection_reasons(code, label, ctx, sort) values
  ('emp_other_guarantee', 'الكفيل ضامن لقرض آخر — راتبه غير حر', 'trade', 1),
  ('emp_advance', 'على الكفيل سلفة قائمة تُستقطع من راتبه', 'trade', 2),
  ('emp_salary_low', 'الراتب الصافي لا يطابق شروط القرض (لا يغطي حصته من القسط)', 'trade', 3),
  ('emp_not_permanent', 'الكفيل ليس على الملاك الدائم (عقد أو أجر يومي)', 'trade', 4),
  ('emp_retired', 'الكفيل محال على التقاعد أو منقطع عن الخدمة', 'trade', 5),
  ('emp_not_found', 'لا يوجد موظف بهذه البيانات في الدائرة المذكورة', 'trade', 6),
  ('emp_other', 'سبب آخر (مكتوب في الملاحظة)', 'trade', 99)
on conflict (code) do nothing;

-- إنشاء طلبات التأييد لكفلاء الطلب الموظفين في وزارة التجارة، وإلغاء ما لم يعد قائماً
create or replace function public._emp_sync(p_app uuid) returns int
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; g jsonb; i int := -1; mt orgs; n int; v_inst bigint; v_share bigint; v_need bigint; seq int; ck employer_checks; made int := 0;
begin
  select * into a from applications where id = p_app;
  select * into mt from orgs where type = 'trade' order by created_at limit 1;
  if a.id is null or mt.id is null then return 0; end if;
  update employer_checks c set status = 'cancelled', cancel_note = 'استُبدل الكفيل أو تغيّر نوع الضمان', updated_at = now()
  where c.application_id = a.id and c.status in ('pending', 'approved')
    and (coalesce(a.guarantee_type, '') not in ('single_salary', 'multi_salary')
         or not exists (select 1 from jsonb_array_elements(coalesce(a.guarantee->'guarantors', '[]'::jsonb)) x
                        where x->>'ministry' = 'trade' and x->>'phone' = c.guarantor_phone));
  if coalesce(a.guarantee_type, '') not in ('single_salary', 'multi_salary') or a.stage < 6 or a.status not in ('active', 'returned') then return 0; end if;
  n := greatest(jsonb_array_length(coalesce(a.guarantee->'guarantors', '[]'::jsonb)), 1);
  v_inst := coalesce(a.monthly_installment, _installment(a.amount, _setting('cbi_rate') + _setting('margin_max'), coalesce(a.term_months, 60)));
  v_share := ceil(v_inst::numeric / n);
  v_need := ceil(v_share * coalesce(_setting('salary_safety'), 1));
  for g in select * from jsonb_array_elements(coalesce(a.guarantee->'guarantors', '[]'::jsonb)) loop
    i := i + 1;
    if g->>'ministry' is distinct from 'trade' then continue; end if;
    if exists (select 1 from employer_checks where application_id = a.id and guarantor_phone = g->>'phone' and status in ('pending', 'approved', 'rejected')) then continue; end if;
    perform pg_advisory_xact_lock(hashtext('employer_checks_code'));
    select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from employer_checks where split_part(code, '-', 2) = to_char(now(), 'YYYY');
    insert into employer_checks(code, org_id, application_id, bank_id, g_index, guarantor_name, guarantor_phone, guarantor_nid, dept, declared_salary, share, required_net)
    values ('MOT-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 5, '0'), mt.id, a.id, a.bank_id, i, coalesce(g->>'name', '—'), g->>'phone', g->>'national_id',
      g->>'dept', nullif(g->>'salary', '')::bigint, v_share, v_need)
    returning * into ck;
    perform _notify(mt.id, 'trade', 'employer_check', 'طلب تأييد راتب كفيل — ' || ck.code,
      ck.guarantor_name || coalesce(' · ' || ck.dept, '') || ' — كفيل في طلب التمويل ' || a.code, a.id);
    insert into application_events(application_id, stage, action, note, actor_name, actor_role)
    values (a.id, a.stage, 'مفاتحة وزارة التجارة آلياً لتأييد راتب الكفيل ' || ck.guarantor_name || ' — ' || ck.code,
      'الدائرة: ' || coalesce(ck.dept, '—') || ' · حصة الكفيل من القسط ' || to_char(v_share, 'FM999,999,999') || ' د.ع · الصافي المطلوب ' || to_char(v_need, 'FM999,999,999') || ' د.ع',
      'النظام — إحالة آلية', 'system');
    made := made + 1;
  end loop;
  return made;
end $f$;

create or replace function public._emp_on_app() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.program = 'solar' and new.stage >= 6 and (old.stage <= 5 or new.guarantee is distinct from old.guarantee or new.guarantee_type is distinct from old.guarantee_type) then
    perform _emp_sync(new.id);
  end if;
  return null;
end $f$;
drop trigger if exists trg_emp_checks on public.applications;
create trigger trg_emp_checks after update of stage, guarantee, guarantee_type on public.applications for each row execute function public._emp_on_app();

-- ───────── 4) بوابة وزارة التجارة ─────────
create or replace function public._trade_reader() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal not in ('trade', 'admin') then raise exception 'غير مخوّل'; end if;
  return me;
end $f$;

create or replace function public.trade_inbox() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; v_org uuid;
begin
  me := _trade_reader();
  v_org := case when me.portal = 'trade' then me.org_id else (select id from orgs where type = 'trade' order by created_at limit 1) end;
  return jsonb_build_object(
    'can_decide', me.portal = 'trade' and me.role = 'trade_officer',
    'checks', (select coalesce(jsonb_agg(to_jsonb(c) - 'decided_by' || jsonb_build_object(
        'app_code', a.code, 'borrower', a.citizen_name, 'purpose', _purpose_label(coalesce(a.purpose, 'household')),
        'amount', a.amount, 'term_months', a.term_months, 'installment', coalesce(a.monthly_installment, c.share),
        'guarantors_n', greatest(jsonb_array_length(coalesce(a.guarantee->'guarantors', '[]'::jsonb)), 1),
        'bank_name', (select name from orgs where id = c.bank_id), 'app_stage', a.stage, 'app_status', a.status,
        'reason_labels', (select coalesce(jsonb_agg(r.label order by r.sort), '[]'::jsonb) from rejection_reasons r where r.code = any(c.reasons)))
      order by (c.status = 'pending') desc, c.created_at desc), '[]'::jsonb)
      from employer_checks c join applications a on a.id = c.application_id where c.org_id = v_org),
    'reasons', (select coalesce(jsonb_agg(jsonb_build_object('code', code, 'label', label) order by sort), '[]'::jsonb) from rejection_reasons where ctx = 'trade'),
    'stats', jsonb_build_object(
      'pending', (select count(*) from employer_checks where org_id = v_org and status = 'pending'),
      'approved', (select count(*) from employer_checks where org_id = v_org and status = 'approved'),
      'rejected', (select count(*) from employer_checks where org_id = v_org and status = 'rejected'),
      'avg_hours', (select round(avg(extract(epoch from decided_at - created_at) / 3600)::numeric, 1) from employer_checks where org_id = v_org and decided_at is not null),
      'by_reason', (select coalesce(jsonb_agg(jsonb_build_object('label', r.label, 'n', x.n) order by x.n desc), '[]'::jsonb)
        from (select unnest(reasons) code, count(*) n from employer_checks where org_id = v_org and status = 'rejected' group by 1) x join rejection_reasons r on r.code = x.code),
      'by_dept', (select coalesce(jsonb_agg(jsonb_build_object('dept', d, 'n', n, 'ok', ok, 'bad', bad) order by n desc), '[]'::jsonb)
        from (select coalesce(dept, '—') d, count(*) n, count(*) filter (where status = 'approved') ok, count(*) filter (where status = 'rejected') bad
              from employer_checks where org_id = v_org and status <> 'cancelled' group by 1) q)));
end $f$;

-- قرار الوزارة: الموظف يسجّل ما في سجل الكفيل، والنظام يحدد هل تصح الموافقة
create or replace function public.trade_decide(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; c employer_checks; a applications; v_emp text := nullif(p->>'employment', ''); v_net bigint; v_og boolean; v_adv boolean;
  fails text[] := '{}'; v_dec text := p->>'decision'; v_note text := nullif(left(trim(coalesce(p->>'note', '')), 600), ''); lbl text;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal <> 'trade' or me.role <> 'trade_officer' then raise exception 'القرار من صلاحية مدقق رواتب الكفلاء في وزارة التجارة'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  select * into c from employer_checks where id = p_id for update;
  if c.id is null or c.org_id <> me.org_id then raise exception 'الطلب غير موجود'; end if;
  if c.status <> 'pending' then raise exception 'صدر القرار على هذا الطلب سابقاً'; end if;
  select * into a from applications where id = c.application_id;
  if v_dec not in ('approve', 'reject') then raise exception 'اختر القرار'; end if;
  if v_emp is null or v_emp not in ('permanent', 'contract', 'daily', 'retired', 'not_found') then raise exception 'اختر حالة الكفيل الوظيفية من السجل'; end if;
  if coalesce((p->>'confirm')::boolean, false) is not true then raise exception 'أكّد أن البيانات منقولة من سجل الموظف'; end if;
  if v_emp <> 'not_found' then
    v_net := nullif(regexp_replace(coalesce(p->>'net_salary', ''), '\D', '', 'g'), '')::bigint;
    if v_net is null or v_net < 100000 then raise exception 'اكتب الراتب الصافي من سجل الرواتب'; end if;
    if p->>'other_guarantee' is null or p->>'has_advance' is null then raise exception 'أجب: هل الكفيل ضامن لقرض آخر؟ وهل عليه سلفة؟'; end if;
    v_og := (p->>'other_guarantee')::boolean; v_adv := (p->>'has_advance')::boolean;
  end if;
  if v_emp = 'not_found' then fails := array_append(fails, 'emp_not_found');
  elsif v_emp = 'retired' then fails := array_append(fails, 'emp_retired');
  elsif v_emp in ('contract', 'daily') then fails := array_append(fails, 'emp_not_permanent'); end if;
  if v_og then fails := array_append(fails, 'emp_other_guarantee'); end if;
  if v_adv then fails := array_append(fails, 'emp_advance'); end if;
  if v_net is not null and v_net < c.required_net then fails := array_append(fails, 'emp_salary_low'); end if;

  if v_dec = 'approve' then
    if array_length(fails, 1) > 0 then
      raise exception 'لا تصح الموافقة: %', (select string_agg(label, '، ' order by sort) from rejection_reasons where code = any(fails)); end if;
  else
    if coalesce(array_length(fails, 1), 0) = 0 then
      if v_note is null or length(v_note) < 10 then raise exception 'الراتب حر ويطابق الشروط — إن كان للرفض سبب آخر فاكتبه في الملاحظة'; end if;
      fails := array['emp_other'];
    end if;
  end if;

  update employer_checks set status = case when v_dec = 'approve' then 'approved' else 'rejected' end,
    employment = v_emp, net_salary = v_net, other_guarantee = v_og, has_advance = v_adv,
    advance_monthly = case when v_adv then nullif(regexp_replace(coalesce(p->>'advance_monthly', ''), '\D', '', 'g'), '')::bigint end,
    reasons = case when v_dec = 'approve' then null else fails end, note = v_note,
    decided_by = me.id, decided_by_name = me.full_name, decided_by_code = me.staff_code, decided_by_title = _role_title(me.role),
    decided_at = now(), updated_at = now()
  where id = c.id returning * into c;
  lbl := (select string_agg(label, '، ' order by sort) from rejection_reasons where code = any(c.reasons));
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, case when c.status = 'approved' then 'تأييد وزارة التجارة: راتب الكفيل ' || c.guarantor_name || ' حر ويطابق شروط القرض (' || c.code || ')'
      else 'رفض وزارة التجارة كفالة ' || c.guarantor_name || ' (' || c.code || '): ' || lbl end,
    coalesce(c.dept || ' · ', '') || coalesce('الصافي ' || to_char(c.net_salary, 'FM999,999,999') || ' د.ع · ', '') || coalesce(v_note, ''),
    me.id, me.full_name, me.role);
  perform _notify(c.bank_id, 'bank', 'employer_check',
    case when c.status = 'approved' then 'أيّدت وزارة التجارة راتب الكفيل — ' || a.code else 'رفضت وزارة التجارة الكفيل — ' || a.code end,
    case when c.status = 'approved' then c.guarantor_name || ': راتبه حر ويغطي حصته من القسط.'
      else c.guarantor_name || ': ' || lbl || '. أعد الطلب للمقترض لاستبدال الكفيل أو تقديم ضمان آخر.' end, a.id);
  return c;
end $f$;

-- ───────── 5) المصرف: مفاتحة الوزارة يدوياً، وإعادة الطلب للمقترض لاستبدال الضمان، واستلام الذهب ─────────
create or replace function public._bank_guarantee_actor(a applications) returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if a.id is null or me is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_cs', 'bank_initiatives', 'bank_branch_mgr') then raise exception 'الإجراء من خدمة الزبائن أو مدير الفرع أو إداري قسم المبادرات'; end if;
  if me.branch_id is not null and a.branch_id is not null and me.branch_id <> a.branch_id then raise exception 'الطلب في فرع آخر'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.status not in ('active', 'returned') or a.stage < 6 or a.stage > 19 then raise exception 'إجراءات الضمان بين الاستقبال (6) والضمان النهائي (19)'; end if;
  return me;
end $f$;

-- موظف المصرف يعلّم الكفيل موظفاً في وزارة التجارة (إن لم يحدده المقترض) فتصل الوزارةَ مفاتحة آلية
create or replace function public.employer_check_send(p_app uuid, p_g int, p_dept text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; me profiles; g jsonb; v_dept text := regexp_replace(trim(coalesce(p_dept, '')), '\s+', ' ', 'g');
begin
  select * into a from applications where id = p_app for update;
  me := _bank_guarantee_actor(a);
  if a.guarantee_type not in ('single_salary', 'multi_salary') then raise exception 'ضمان هذا الطلب ليس كفالة راتب'; end if;
  g := a.guarantee->'guarantors'->p_g;
  if g is null then raise exception 'الكفيل غير موجود'; end if;
  if length(v_dept) < 3 then raise exception 'اكتب دائرة الكفيل في وزارة التجارة'; end if;
  if exists (select 1 from employer_checks where application_id = a.id and guarantor_phone = g->>'phone' and status in ('pending', 'approved')) then
    raise exception 'توجد مفاتحة قائمة لهذا الكفيل'; end if;
  update applications set guarantee = jsonb_set(guarantee, array['guarantors', p_g::text], g || jsonb_build_object('ministry', 'trade', 'dept', v_dept)), updated_at = now()
  where id = a.id;
  perform _ev(a.id, a.stage, 'تحديد جهة عمل الكفيل ' || (g->>'name') || ': وزارة التجارة — ' || v_dept, 'تُرسل مفاتحة تأييد الراتب إلى الوزارة آلياً');
  return (select to_jsonb(c) from employer_checks c where application_id = a.id and guarantor_phone = g->>'phone' order by created_at desc limit 1);
end $f$;

-- إعادة الطلب إلى المقترض لاستبدال الضمان (كفيل آخر، أو ذهب، أو عقار) — يرجع بعد إعادة الإرسال إلى المرحلة نفسها
create or replace function public.guarantee_return(p_app uuid, p_note text default null) returns applications
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; me profiles; v_note text := nullif(left(trim(coalesce(p_note, '')), 500), ''); v_why text; v_from int; v_txt text;
begin
  select * into a from applications where id = p_app for update;
  me := _bank_guarantee_actor(a);
  if a.program is distinct from 'solar' then raise exception 'هذا الإجراء لطلبات منظومات الطاقة الشمسية'; end if;
  select string_agg('★ رفضت وزارة التجارة كفالة ' || c.guarantor_name || ': ' ||
      (select string_agg(r.label, '، ' order by r.sort) from rejection_reasons r where r.code = any(c.reasons)), E'\n' order by c.g_index)
    into v_why
  from employer_checks c where c.application_id = a.id and c.status = 'rejected'
    and exists (select 1 from jsonb_array_elements(coalesce(a.guarantee->'guarantors', '[]'::jsonb)) x where x->>'phone' = c.guarantor_phone);
  v_why := concat_ws(E'\n', v_why, (select string_agg('★ رفض المصرف الموطَّن راتب الكفيل ' || s.guarantor_name || ': ' || coalesce((select label from rejection_reasons where code = s.reject_reason), ''), E'\n')
    from salary_referrals s where s.application_id = a.id and s.status = 'rejected'
      and exists (select 1 from jsonb_array_elements(coalesce(a.guarantee->'guarantors', '[]'::jsonb)) x where x->>'name' = s.guarantor_name)));
  v_why := nullif(v_why, '');
  if v_why is null and (v_note is null or length(v_note) < 10) then raise exception 'اكتب للمقترض سبب استبدال الضمان'; end if;
  v_txt := concat_ws(E'\n', v_why, 'ملاحظة: ' || v_note);
  -- ما بدأ على الضمان القديم يُلغى (الاستقطاع المفعَّل لا يُلغى من هنا)
  update salary_referrals set status = 'cancelled', note = 'أُعيد الطلب للمقترض لاستبدال الضمان', updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role)
  where application_id = a.id and status in ('pending', 'confirmed');
  update employer_checks set status = 'cancelled', cancel_note = 'أُعيد الطلب للمقترض لاستبدال الضمان', updated_at = now()
  where application_id = a.id and status = 'pending';
  perform _ev(a.id, a.stage, 'إعادة الطلب للمقترض لاستبدال الضمان (كفيل آخر أو ذهب أو عقار)', v_txt);
  v_from := greatest(a.stage, 6);
  update applications set stage = 4, status = 'returned', priority = 'urgent', returned_from = v_from, return_kind = 'guarantee',
    return_note = v_txt, returned_at = now(),
    returned_by_title = _role_title(me.role) || coalesce(' — ' || (select name from branches where id = me.branch_id), ''),
    intake_missing = jsonb_build_array(_ci('guarantee_replace', 'استبدال الكفيل أو تقديم ضمان آخر', 'الضمان', false, '4')),
    bank_unit = 'المقترض', updated_at = now()
  where id = a.id returning * into a;
  return a;
end $f$;

-- الفرع يستلم الذهب ويزنه ويقيّمه (شرط لإنجاز المرحلتين 9 و19 في ضمان الذهب)
create or replace function public.gold_custody(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; me profiles; v_gr numeric := nullif(p->>'grams', '')::numeric; v_kt int := nullif(p->>'karat', '')::int;
  v_val bigint := nullif(regexp_replace(coalesce(p->>'value', ''), '\D', '', 'g'), '')::bigint; v_no text := trim(coalesce(p->>'receipt_no', ''));
begin
  select * into a from applications where id = p_app for update;
  me := _bank_guarantee_actor(a);
  if a.guarantee_type <> 'gold' then raise exception 'ضمان هذا الطلب ليس رهن ذهب'; end if;
  if length(v_no) < 3 then raise exception 'اكتب رقم وصل استلام الذهب'; end if;
  if v_gr is null or v_gr < 1 then raise exception 'اكتب الوزن الفعلي بالغرام'; end if;
  if v_kt is null or v_kt not in (18, 21, 22, 24) then raise exception 'العيار 18 أو 21 أو 22 أو 24'; end if;
  if v_val is null or v_val <= 0 then raise exception 'اكتب القيمة المقيَّمة'; end if;
  if a.amount > v_val * _setting('gold_ltv') / 100 then
    raise exception 'القيمة المقيَّمة لا تغطي التمويل (الحد % بالمئة من القيمة) — أعد الطلب للمقترض لاستكمال الضمان', _setting('gold_ltv'); end if;
  update applications set guarantee = guarantee || jsonb_build_object('custody', jsonb_build_object('receipt_no', v_no, 'grams', v_gr, 'karat', v_kt, 'value', v_val,
      'note', nullif(trim(coalesce(p->>'note', '')), ''), 'at', now(), 'by', _role_title(me.role), 'by_code', me.staff_code)), updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'استلام الذهب المرهون ووزنه وتقييمه في الفرع — وصل ' || v_no,
    v_gr || ' غرام عيار ' || v_kt || ' · القيمة المقيَّمة ' || to_char(v_val, 'FM999,999,999') || ' د.ع');
  return a;
end $f$;

-- ───────── 6) المقترض: اختيار نوع الضمان، وحالة كفلائه لدى الوزارة ─────────
create or replace function public._guarantee_base(a applications) returns text language sql stable set search_path to 'public' as $f$
  select case when a.price <= _setting('guarantee_t1') then 'single_salary' when a.price <= _setting('guarantee_t2') then 'multi_salary' else 'mortgage' end $f$;

create or replace function public.set_guarantee_kind(p_app uuid, p_kind text) returns applications
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; b text; ok text[];
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a.id is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'نوع الضمان في المشروع البيطري تحدده المبادرة'; end if;
  if a.status not in ('active', 'returned') or a.stage not in (4, 5) then raise exception 'نوع الضمان يُختار في خطوة الضمان'; end if;
  b := _guarantee_base(a);
  ok := case b when 'single_salary' then array['single_salary', 'multi_salary', 'gold', 'mortgage'] when 'multi_salary' then array['multi_salary', 'gold', 'mortgage'] else array['mortgage', 'gold'] end;
  if p_kind = 'salary' then p_kind := case when b = 'mortgage' then 'x' else b end; end if;
  if not (p_kind = any(ok)) then raise exception 'هذا النوع من الضمان لا يكفي لمبلغ تمويلك'; end if;
  if p_kind is distinct from a.guarantee_type then
    update applications set guarantee_type = p_kind, guarantee = null, property_id = null, ownership = null, stage = 4,
      bank_unit = 'المواطن', updated_at = now() where id = a.id returning * into a;
    perform _ev(a.id, 4, 'تغيير نوع الضمان إلى: ' || case p_kind when 'gold' then 'رهن ذهب' when 'mortgage' then 'رهن عقار' when 'multi_salary' then 'رواتب عدة موظفين' else 'راتب موظف' end, null);
  end if;
  return a;
end $f$;

create or replace function public.guarantee_status(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a.id is null or me is null or not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin', 'cbi', 'integrity', 'audit')) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('base', _guarantee_base(a), 'kind', a.guarantee_type, 'return_kind', a.return_kind,
    'gold_gram_21', _setting('gold_gram_21'), 'gold_ltv', _setting('gold_ltv'),
    'checks', (select coalesce(jsonb_agg(jsonb_build_object('code', c.code, 'g_index', c.g_index, 'name', c.guarantor_name, 'phone', c.guarantor_phone, 'dept', c.dept, 'status', c.status,
        'decided_at', c.decided_at, 'created_at', c.created_at, 'note', case when c.status = 'rejected' then c.note end,
        'reasons', (select coalesce(jsonb_agg(r.label order by r.sort), '[]'::jsonb) from rejection_reasons r where r.code = any(c.reasons))) order by c.created_at), '[]'::jsonb)
      from employer_checks c where c.application_id = a.id and c.status <> 'cancelled'));
end $f$;

-- ───────── 7) المقترض: رهن الذهب، وجهة عمل الكفيل في خطوة الضمان (تعديل _citizen_step_solar دون المساس بباقيه) ─────────
do $$
declare d text;
  o0 text := 'declare me profiles; a applications;';
  n0 text := 'declare v_gr numeric; v_kt int; v_gv bigint; me profiles; a applications;';
  o1 text := E'    if a.guarantee_type in (''single_salary'', ''multi_salary'') then\n      n := jsonb_array_length';
  n1 text := E'    if a.guarantee_type = ''gold'' then
      -- الجلسة 31: رهن الذهب — قيمة تقديرية من الوزن والعيار، ويستلمه الفرع ويزنه ويقيّمه لاحقاً
      v_gr := nullif(p_data->>''grams'', '''')::numeric; v_kt := coalesce(nullif(p_data->>''karat'', '''')::int, 21);
      if v_gr is null or v_gr < 1 then raise exception ''اكتب وزن الذهب بالغرام''; end if;
      if v_kt not in (18, 21, 22, 24) then raise exception ''العيار 18 أو 21 أو 22 أو 24''; end if;
      v_gv := round(v_gr * _setting(''gold_gram_21'') * v_kt / 21);
      if a.amount > v_gv * _setting(''gold_ltv'') / 100 then
        raise exception ''قيمة ذهبك التقديرية % د.ع لا تكفي — يلزم ذهب بقيمة % د.ع على الأقل'', to_char(v_gv, ''FM999,999,999''), to_char(ceil(a.amount * 100 / _setting(''gold_ltv'')), ''FM999,999,999''); end if;
      update applications set property_id = null, guarantee = jsonb_build_object(''type'', ''gold'', ''grams'', v_gr, ''karat'', v_kt, ''value'', v_gv,
        ''gram_price'', _setting(''gold_gram_21''), ''ltv'', round(a.amount * 100.0 / v_gv, 1), ''items'', nullif(left(trim(coalesce(p_data->>''items'', '''')), 200), '''')) where id = a.id;
      act := ''تأكيد الضمان: رهن ذهب''; note := v_gr || '' غرام عيار '' || v_kt || '' · قيمة تقديرية '' || to_char(v_gv, ''FM999,999,999'') || '' د.ع — يُسلَّم للفرع ويُوزن ويُقيَّم'';
    elsif a.guarantee_type in (''single_salary'', ''multi_salary'') then
      n := jsonb_array_length';
  o2 text := 'if coalesce(g->>''employer'', '''') = '''' then raise exception ''اكتب جهة عمل كل كفيل''; end if;';
  n2 text := 'if coalesce(g->>''employer'', '''') = '''' then raise exception ''اكتب جهة عمل كل كفيل''; end if;
        if g->>''ministry'' = ''trade'' and length(trim(coalesce(g->>''dept'', ''''))) < 3 then raise exception ''اختر دائرة الكفيل % في وزارة التجارة'', g->>''name''; end if;
        if exists (select 1 from employer_checks c where c.application_id = a.id and c.guarantor_phone = ph and c.status = ''rejected'') then
          raise exception ''رفضت وزارة التجارة كفالة % لهذا الطلب — اختر كفيلاً آخر أو ضماناً آخر (ذهب أو عقار)'', g->>''name''; end if;';
  o3 text := '''relation'', g->>''relation'', ''national_id''';
  n3 text := '''relation'', g->>''relation'', ''ministry'', case when g->>''ministry'' = ''trade'' then ''trade'' end, ''dept'', nullif(trim(coalesce(g->>''dept'', '''')), ''''), ''national_id''';
begin
  d := pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure);
  if position('employer_checks' in d) = 0 then
    if position(o0 in d) = 0 or position(o1 in d) = 0 or position(o2 in d) = 0 or position(o3 in d) = 0 then
      raise exception 'الجلسة 31: لم يُعثر على مواضع التعديل في _citizen_step_solar'; end if;
    d := replace(replace(replace(replace(d, o0, n0), o1, n1), o2, n2), o3, n3);
    execute d;
  end if;
end $$;

-- قائمة التدقيق في الاستقبال: تسمية بند الضمان لرهن الذهب
do $$
declare d text; o text := 'case when a.guarantee_type = ''mortgage'' then ''بيانات العقار المرهون'' else';
  n text := 'case when a.guarantee_type = ''mortgage'' then ''بيانات العقار المرهون'' when a.guarantee_type = ''gold'' then ''بيانات الذهب المرهون (الوزن والعيار)'' else';
begin
  d := pg_get_functiondef('public._intake_items(applications)'::regprocedure);
  if position('''gold''' in d) = 0 and position(o in d) > 0 then execute replace(d, o, n); end if;
end $$;

-- ───────── 8) حراسة الانتقال والعودة بعد استبدال الضمان ─────────
-- (أ) بعد إعادة الإرسال: قرار المستخدم (الجلسة 31) — يعود الطلب دائماً إلى الموافقة المبدئية (8) ليوافق مدير الفرع على الضمان الجديد.
--     إن أُعيد قبل المرحلة 8 (من 6 أو 7) يرجع إلى المرحلة نفسها. ولا يُعاد الاستقبال وفتح الحساب.
create or replace function public._resume_after_guarantee() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  if old.stage <= 5 and new.stage >= 6 and new.return_kind = 'guarantee' then
    if least(coalesce(new.returned_from, 6), 8) > new.stage then
      new.stage := least(new.returned_from, 8);   -- resume_to_initial_approval
      new.bank_unit := (select owner_label from stages where n = new.stage);
      new.returned_from := new.stage;
      new.initial_approved_at := null;             -- الموافقة المبدئية السابقة كانت على الضمان القديم
    end if;
    new.return_kind := null;
    insert into application_events(application_id, stage, action, note, actor_name, actor_role)
    values (new.id, new.stage, 'عاد الطلب إلى المصرف بعد استبدال الضمان — إلى المرحلة ' || new.stage || case when new.stage = 8 then ' (موافقة مدير الفرع على الضمان الجديد)' else '' end,
      'الضمان الجديد: ' || case new.guarantee_type when 'gold' then 'رهن ذهب' when 'mortgage' then 'رهن عقار' else coalesce(jsonb_array_length(new.guarantee->'guarantors'), 0) || ' كفيل' end,
      'النظام', 'system');
  end if;
  return new;
end $f$;
drop trigger if exists trg_a_resume_guarantee on public.applications;
create trigger trg_a_resume_guarantee before update of stage on public.applications for each row execute function public._resume_after_guarantee();

-- (ب) لا يُنجز الضمان الأولي (9) دون تأييد وزارة التجارة لكل كفيل من موظفيها، ولا يُنجز ضمان الذهب دون استلامه
create or replace function public._guard_guarantee() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare miss text;
begin
  if new.stage > old.stage and old.stage in (9, 19) and new.program = 'solar' then
    if new.guarantee_type in ('single_salary', 'multi_salary') and old.stage = 9 then
      select string_agg(x->>'name', '، ') into miss from jsonb_array_elements(coalesce(new.guarantee->'guarantors', '[]'::jsonb)) x
      where x->>'ministry' = 'trade' and not exists (select 1 from employer_checks c where c.application_id = new.id and c.guarantor_phone = x->>'phone' and c.status = 'approved');
      if miss is not null then
        raise exception 'الضمان الأولي: بانتظار تأييد وزارة التجارة لراتب الكفيل (%) — إن رفضت الوزارة أعد الطلب للمقترض لاستبدال الضمان', miss; end if;
    end if;
    if new.guarantee_type = 'gold' and new.guarantee->'custody' is null then
      raise exception 'رهن الذهب: سجّل استلام الذهب ووزنه وتقييمه في الفرع أولاً'; end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_guard_guarantee on public.applications;
create trigger trg_guard_guarantee before update of stage on public.applications for each row execute function public._guard_guarantee();

-- ───────── 9) الصلاحيات ─────────
revoke all on function public._emp_sync(uuid), public._trade_reader(), public._bank_guarantee_actor(applications) from public, anon, authenticated;
revoke all on function public.trade_inbox(), public.trade_decide(uuid, jsonb), public.employer_check_send(uuid, integer, text), public.guarantee_return(uuid, text),
  public.gold_custody(uuid, jsonb), public.set_guarantee_kind(uuid, text), public.guarantee_status(uuid) from public, anon;
grant execute on function public.trade_inbox(), public.trade_decide(uuid, jsonb), public.employer_check_send(uuid, integer, text), public.guarantee_return(uuid, text),
  public.gold_custody(uuid, jsonb), public.set_guarantee_kind(uuid, text), public.guarantee_status(uuid) to authenticated;

-- ───────── 10) الحساب التجريبي وطلب تجريبي ─────────
do $$
begin
  if not exists (select 1 from public.profiles where username = 'trade1') then
    perform public._mk_user('trade1', 'Mot@2026tr', 'أ. رياض حسن الجبوري', 'trade_officer', 'trade', 'mot', null, null);
  end if;
  update public.profiles set manage_scope = 'org', position_title = coalesce(position_title, 'مدقق رواتب الكفلاء — دائرة الموارد البشرية') where username = 'trade1';
end $$;

-- طلب citizen1 (في الاستقبال، بلا بيانات كفيل) يصبح بكفيل موظف في وزارة التجارة — فيصل الوزارةَ طلب تأييد للعرض
update public.applications set guarantee = jsonb_build_object('type', 'single_salary', 'guarantors', jsonb_build_array(jsonb_build_object(
    'name', 'حيدر عبد الكريم ناصر', 'phone', '07709876543', 'employer', 'وزارة التجارة — الشركة العامة لتجارة المواد الغذائية',
    'ministry', 'trade', 'dept', 'الشركة العامة لتجارة المواد الغذائية', 'salary', 1150000, 'relation', 'زميل عمل',
    'consent', true, 'consent_at', now(), 'consent_via', 'otp', 'id_source', 'manual')),
  'total_salary', 1150000, 'required', ceil(coalesce(monthly_installment, 140559) * 1.25))
where code = 'ALW-2026-00101' and guarantee is null and guarantee_type = 'single_salary'
  and citizen_id = (select id from public.profiles where username = 'citizen1');

-- ═══════════════════════════════════════════════════════════════════════
-- الجلسة 31 (تكملة بقرار المستخدم): تقليل الوقت ورفع العناء عن المقترض
--  (1) إلغاء سقوط الموافقة المبدئية بمرور 90 يوماً: لا يُرفض طلب المقترض بسبب تأخير لم يتسبب فيه
--      (المقترض يقدّم ضمانه في المرحلة 4 قبل وصول الطلب للمصرف — فكل تأخير بعدها من المصرف أو الجهات).
--  (2) سقف زمني على المصرف = مجموع المدد المسموحة للمراحل 6–19، وتصعيد آلي للتأخير:
--      تجاوز المدة ← مدير الفرع · ضعفها ← الإدارة العليا للمصرف وإشعار المقترض · ثلاثة أضعافها ← هيئة النزاهة والبنك المركزي.
--  (3) المفاتحات معاً لحظة إرسال الطلب: الرهن العقاري للتسجيل العقاري، ومصرف راتب الكفيل (إن ذكر المقترض مصرفه وحسابه)،
--      مع تأييد وزارة التجارة — بدل انتظار المرحلة 9. ويستطيع المصرف المفاتحة من المرحلة 6.
-- ═══════════════════════════════════════════════════════════════════════

-- (1) إلغاء شرط المهلة من advance_application
do $$
declare d text; m1 text := 'lim := _setting(''initial_validity_days'')::int;'; m2 text := 'ارفض الطلب مسبباً'', lim; end if;'; p1 int; p2 int;
begin
  d := pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure);
  p1 := position(m1 in d); p2 := position(m2 in d);
  if p1 > 0 and p2 > p1 then
    d := substr(d, 1, p1 - 1) || '-- الجلسة 31: أُلغي سقوط الموافقة المبدئية بمرور المدة — التأخير يُحاسَب عليه الموظف لا المقترض' || substr(d, p2 + length(m2));
    execute d;
  end if;
end $$;
update public.settings set label = 'ملغى (الجلسة 31) — لا تسقط الموافقة المبدئية بمرور المدة؛ التأخير يُحاسب عليه الموظف' where key = 'initial_validity_days';

-- (2) ساعة المصرف والتصعيد الآلي
insert into public.settings(key, value, label, circular_no)
select 'bank_sla_budget_days', coalesce(sum(sla_days), 38), 'سقف المصرف: مجموع أيام الدوام المسموحة للمراحل 6–19 (من الاستقبال حتى الضمان النهائي)', 'الجلسة 31'
from public.stages where n between 6 and 19
on conflict (key) do nothing;

create table if not exists public.sla_escalations (
  stage_log_id bigint not null, level int not null, application_id uuid not null, stage int not null,
  created_at timestamptz not null default now(), primary key (stage_log_id, level));
alter table public.sla_escalations enable row level security;
revoke all on public.sla_escalations from anon, authenticated;

create or replace function public.app_clock(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; a applications; v_used numeric; v_budget numeric; cur stage_log; v_dur numeric; v_sla numeric;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a.id is null or me is null or not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin', 'cbi', 'integrity', 'audit', 'planning', 'finance')) then raise exception 'غير مخوّل'; end if;
  v_budget := coalesce(_setting('bank_sla_budget_days'), (select sum(sla_days) from stages where n between 6 and 19));
  select coalesce(sum(_wd(entered_at, coalesce(finished_at, now()))), 0) into v_used from stage_log where application_id = a.id and stage between 6 and 19;
  select * into cur from stage_log where application_id = a.id and stage = a.stage and finished_at is null order by entered_at desc limit 1;
  v_sla := (select sla_days from stages where n = a.stage);
  v_dur := case when cur.id is not null then _wd(cur.entered_at, now()) end;
  return jsonb_build_object('budget', v_budget, 'used', round(v_used, 1), 'left', round(v_budget - v_used, 1), 'in_window', a.stage between 6 and 19,
    'stage', a.stage, 'stage_name', (select name from stages where n = a.stage), 'owner', (select owner_label from stages where n = a.stage),
    'stage_days', round(v_dur, 1), 'stage_sla', v_sla,
    'level', case when v_dur is null or coalesce(v_sla, 0) <= 0 then 0 when v_dur > v_sla * 3 then 3 when v_dur > v_sla * 2 then 2 when v_dur > v_sla then 1 else 0 end);
end $f$;
revoke all on function public.app_clock(uuid) from public, anon;
grant execute on function public.app_clock(uuid) to authenticated;

-- فحص دوري: كل مرحلة مفتوحة تجاوزت مدتها تُصعَّد مرة واحدة لكل مستوى
create or replace function public._sla_scan() returns int
language plpgsql security definer set search_path to 'public' as $f$
declare r record; lv int; made int := 0; who text; t text; b text;
begin
  for r in
    select l.id lid, l.application_id, l.stage, l.entered_at, s.sla_days sla, s.name sname, s.owner_role, s.owner_label, a.code, a.bank_id, a.branch_id, a.citizen_id, a.supplier_id,
           _wd(l.entered_at, now()) dur
    from stage_log l join applications a on a.id = l.application_id join stages s on s.n = l.stage
    where l.finished_at is null and a.status in ('active', 'returned') and l.stage >= 6 and s.owner_role <> 'citizen' and coalesce(s.sla_days, 0) > 0
      and _wd(l.entered_at, now()) > s.sla_days
  loop
    for lv in 1 .. (case when r.dur > r.sla * 3 then 3 when r.dur > r.sla * 2 then 2 else 1 end) loop
      continue when exists (select 1 from sla_escalations where stage_log_id = r.lid and level = lv);
      insert into sla_escalations(stage_log_id, level, application_id, stage) values (r.lid, lv, r.application_id, r.stage);
      who := (select string_agg(full_name, '، ') from profiles p where p.role = r.owner_role and p.org_id = r.bank_id and (r.branch_id is null or p.branch_id is null or p.branch_id = r.branch_id) and not coalesce(p.disabled, false));
      t := 'تأخير في الطلب ' || r.code || ' — «' || r.sname || '»';
      b := 'مضى ' || round(r.dur, 1) || ' يوم دوام والمسموح ' || r.sla || ' · المسؤول: ' || r.owner_label || coalesce(' (' || who || ')', '');
      if lv = 1 then
        if r.owner_role like 'bank\_%' then
          insert into notifications(user_id, kind, title, body, ref_id)
          select p.id, 'sla_late', t, b || ' — تصعيد إلى مدير الفرع', r.application_id from profiles p
          where p.org_id = r.bank_id and p.role = 'bank_branch_mgr' and (r.branch_id is null or p.branch_id is null or p.branch_id = r.branch_id) and not coalesce(p.disabled, false);
        else
          perform _notify(coalesce(case when r.owner_role like 'supplier%' then r.supplier_id end, r.bank_id), null, 'sla_late', t, b, r.application_id);
        end if;
      elsif lv = 2 then
        insert into notifications(user_id, kind, title, body, ref_id)
        select p.id, 'sla_late', t, b || ' — تجاوز ضعف المدة: تصعيد إلى الإدارة العليا', r.application_id from profiles p
        where p.org_id = r.bank_id and p.role = 'bank_md' and not coalesce(p.disabled, false);
        if r.citizen_id is not null then
          insert into notifications(user_id, kind, title, body, ref_id) values (r.citizen_id, 'sla_late', 'طلبك متأخر لدى المصرف — صُعِّد إلى الإدارة العليا',
            'تأخرت مرحلة «' || r.sname || '» عن مدتها المسموحة. لا شيء مطلوب منك، ولن يُرفض طلبك بسبب هذا التأخير — التأخير يُسجَّل على الموظف المسؤول.', r.application_id);
        end if;
      else
        insert into integrity_alerts(type, severity, title, details, application_id, entity)
        values ('sla', 'high', t || ' (ثلاثة أضعاف المدة ولم يُنجز)', b, r.application_id, (select name from orgs where id = r.bank_id));
      end if;
      insert into application_events(application_id, stage, action, note, actor_name, actor_role)
      values (r.application_id, r.stage, 'تصعيد آلي للتأخير — المستوى ' || lv || ' (' || case lv when 1 then 'مدير الفرع' when 2 then 'الإدارة العليا للمصرف' else 'هيئة النزاهة والبنك المركزي' end || ')', b, 'النظام', 'system');
      made := made + 1;
    end loop;
  end loop;
  return made;
end $f$;
revoke all on function public._sla_scan() from public, anon, authenticated;

-- جدولة الفحص كل 30 دقيقة (pg_cron). إن لم يتوفر يكتفي النظام بالفحص عند فتح الطلبات.
do $$ begin
  create extension if not exists pg_cron;
  if exists (select 1 from cron.job where jobname = 'alwah_sla_scan') then perform cron.unschedule('alwah_sla_scan'); end if;
  perform cron.schedule('alwah_sla_scan', '*/30 * * * *', 'select public._sla_scan()');
exception when others then raise notice 'pg_cron غير متاح: %', sqlerrm;
end $$;

-- (3) المفاتحات معاً لحظة الإرسال
alter table public.mortgage_referrals drop constraint if exists mortgage_referrals_status_check;
alter table public.mortgage_referrals add constraint mortgage_referrals_status_check check (status = any (array['pending','clear','encumbered','matched','annotated','released','rejected','cancelled']));

-- المصرف يستطيع مفاتحة مصرف راتب الكفيل من المرحلة 6 (لا ينتظر 9)
do $$
declare d text; o text := 'a.stage < 9 or a.stage > 19 then raise exception ''المفاتحة بين المرحلة 9 (الضمان الأولي) والمرحلة 19 (الضمان النهائي)''';
  n text := 'a.stage < 6 or a.stage > 19 then raise exception ''المفاتحة بين الاستقبال (6) والضمان النهائي (19)''';
begin
  d := pg_get_functiondef('public.refer_salary(uuid,jsonb)'::regprocedure);
  if position(o in d) > 0 then execute replace(d, o, n); end if;
end $$;

create or replace function public._auto_referrals(p_app uuid) returns int
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; g jsonb; i int := -1; sb orgs; seq int; v_inst bigint; made int := 0; sr salary_referrals;
begin
  select * into a from applications where id = p_app;
  if a.id is null or a.program <> 'solar' or a.stage < 6 then return 0; end if;
  -- ما بقي من الضمان القديم يُلغى
  update mortgage_referrals set status = 'cancelled', note = coalesce(note || ' · ', '') || 'أُلغيت: تغيّر الضمان', updated_at = now()
  where application_id = a.id and status = 'pending' and (a.guarantee_type <> 'mortgage' or property_id is distinct from a.property_id);
  if a.guarantee_type = 'mortgage' and a.property_id is not null
     and not exists (select 1 from mortgage_referrals where application_id = a.id and status in ('pending', 'clear', 'matched', 'annotated')) then
    insert into mortgage_referrals(application_id, property_id, bank_id, debt_amount, note)
    values (a.id, a.property_id, a.bank_id, a.amount, 'إحالة آلية لحظة إرسال الطلب — للتحقق من الخلو ومطابقة السند');
    insert into application_events(application_id, stage, action, note, actor_name, actor_role)
    values (a.id, a.stage, 'إحالة الرهن إلى التسجيل العقاري آلياً لحظة إرسال الطلب', 'تعمل بالتوازي مع الاستقبال — لا تنتظر المرحلة 9', 'النظام — إحالة آلية', 'system');
    made := made + 1;
  end if;
  if a.guarantee_type in ('single_salary', 'multi_salary') then
    v_inst := coalesce(a.monthly_installment, _installment(a.amount, _setting('cbi_rate') + _setting('margin_max'), coalesce(a.term_months, 60)));
    for g in select * from jsonb_array_elements(coalesce(a.guarantee->'guarantors', '[]'::jsonb)) loop
      i := i + 1;
      continue when nullif(g->>'salary_bank_id', '') is null or length(coalesce(g->>'salary_account', '')) < 6;
      continue when exists (select 1 from salary_referrals where application_id = a.id and g_index = i and status in ('pending', 'confirmed', 'activated'));
      select * into sb from orgs where id = (g->>'salary_bank_id')::uuid and type = 'bank';
      continue when sb.id is null;
      perform pg_advisory_xact_lock(hashtext('salary_referrals_code'));
      select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from salary_referrals where split_part(code, '-', 2) = to_char(now(), 'YYYY');
      insert into salary_referrals(code, application_id, bank_id, salary_bank_id, g_index, guarantor_name, guarantor_phone, employer, declared_salary,
        salary_account, installment, term_months, dd_mode, note, created_by_title)
      values ('DD-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 5, '0'), a.id, a.bank_id, sb.id, i, g->>'name', g->>'phone', g->>'employer', nullif(g->>'salary', '')::bigint,
        g->>'salary_account', v_inst, a.term_months, 'on_default', 'مفاتحة آلية لحظة إرسال الطلب', 'النظام — إحالة آلية')
      returning * into sr;
      insert into application_events(application_id, stage, action, note, actor_name, actor_role)
      values (a.id, a.stage, 'مفاتحة ' || sb.name || ' آلياً (مصرف راتب الكفيل ' || (g->>'name') || ') لتفعيل الاستقطاع — ' || sr.code,
        'لحظة إرسال الطلب — بالتوازي مع الاستقبال', 'النظام — إحالة آلية', 'system');
      made := made + 1;
    end loop;
  end if;
  return made;
end $f$;
revoke all on function public._auto_referrals(uuid) from public, anon, authenticated;

-- تُستدعى مع مفاتحة وزارة التجارة في المحفّز نفسه
create or replace function public._emp_on_app() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.program = 'solar' and new.stage >= 6 and (old.stage <= 5 or new.guarantee is distinct from old.guarantee or new.guarantee_type is distinct from old.guarantee_type) then
    perform _emp_sync(new.id);
    if old.stage <= 5 then perform _auto_referrals(new.id); end if;   -- auto_referrals_on_submit
  end if;
  return null;
end $f$;

-- مصرف راتب الكفيل وحسابه (اختياريان) يحفظهما المقترض مع الكفيل لتُرسل المفاتحة فوراً
do $$
declare d text;
  o text := '''ministry'', case when g->>''ministry'' = ''trade'' then ''trade'' end,';
  n text := '''ministry'', case when g->>''ministry'' = ''trade'' then ''trade'' end, ''salary_bank_id'', nullif(g->>''salary_bank_id'', ''''), ''salary_account'', nullif(regexp_replace(coalesce(g->>''salary_account'', ''''), ''\s'', '''', ''g''), ''''),';
begin
  d := pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure);
  if position('salary_bank_id' in d) = 0 and position(o in d) > 0 then execute replace(d, o, n); end if;
end $$;
