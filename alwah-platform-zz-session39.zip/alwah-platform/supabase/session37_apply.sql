-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 37: بوابة شركات التدقيق الهندسي (/auditor)
--  جهة هندسية مستقلة عن المصرف والمورد تفحص ما مُوّل في موقعه، بنداً بنداً:
--   • أمر كشف الاستلام يُنشأ آلياً عند وصول الطلب إلى المرحلة 32، ويُسند لشركة معتمدة تغطي المحافظة.
--   • الكشف الرقابي بالعيّنة يطلبه البنك المركزي لأي مشروع منفَّذ.
--   • مدير الشركة (auditor_admin) يوزّع البنود على مهندسيه حسب التخصص؛ كل مهندس (auditor_engineer)
--     يثبّت زيارته بالـGPS ثم يحكم على بنوده فقط: مطابق / غير مطابق (سبب + صورة) / أخرى (نوع + ملاحظة).
--   • النتيجة تُحتسب آلياً، ويعتمدها المدير ببصمة SHA-256، فتصل المصرف والمورد والبنك المركزي والمقترض
--     ودائرة البيطرة، وهيئة النزاهة عند «غير مطابق»، وتظهر نقطة الزيارة ونتيجتها على خريطة البنك المركزي.
--   • المرحلة 32 لا تُنجز قبل تقرير «مطابق» أو «مطابق بملاحظات» (الإعداد eng_required).
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة والدوران ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance','trade','eng_audit']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance','trade','auditor']));

do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''trade_signer'' then ''MS''',
   'when ''trade_signer'' then ''MS'' when ''auditor_admin'' then ''EA'' when ''auditor_engineer'' then ''EN'''],
  ['public._role_title(text)', 'when ''trade_signer'' then ''صاحب الصلاحية (المدير العام) — وزارة التجارة''',
   'when ''trade_signer'' then ''صاحب الصلاحية (المدير العام) — وزارة التجارة'' when ''auditor_admin'' then ''مدير شركة التدقيق الهندسي'' when ''auditor_engineer'' then ''مهندس فاحص — شركة التدقيق الهندسي'''],
  ['public._portal_of_role(text)', '''trade_admin'', ''trade_signer'') then ''trade''',
   '''trade_admin'', ''trade_signer'') then ''trade'' when r in (''auditor_admin'', ''auditor_engineer'') then ''auditor'''],
  ['public._org_type_of_portal(text)', 'when ''trade'' then ''trade''',
   'when ''trade'' then ''trade'' when ''auditor'' then ''eng_audit'''],
  ['public._org_roles(text)', '''trade_signer'', ''trade_officer'']',
   '''trade_signer'', ''trade_officer''] when ''eng_audit'' then array[''auditor_engineer'', ''auditor_admin'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('auditor' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'الجلسة 37: لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
end $$;

-- صور الفحص ضمن مستندات الطلب
alter table public.app_documents drop constraint if exists app_documents_kind_check;
alter table public.app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site','mortgage_letter','annotation_mark','dd_letter','dd_auth','kyc_face','contract_signed','feasibility','expert_report','install_panels','install_inverter','install_video','eng_photo']));

-- ملخص التدقيق على الطلب نفسه (تقرؤه خريطة البنك المركزي ولوحات الجهات مباشرة)
alter table public.applications add column if not exists audit_status text;      -- pending | conforming | conditional | non_conforming
alter table public.applications add column if not exists audit_geo jsonb;        -- نقطة زيارة المدقق {lat,lng,acc,at,by}
alter table public.applications add column if not exists audit_at timestamptz;
alter table public.applications add column if not exists audit_org text;
alter table public.applications add column if not exists audit_summary jsonb;    -- {pass,fail,other,total,code,engineers}

insert into public.settings(key, value, label, circular_no) values
  ('eng_gps_accuracy_m', 100, 'أقصى هامش لدقة موقع زيارة المدقق الهندسي (متر)', 'ألواح'),
  ('eng_max_distance_m', 300, 'أقصى بعد بين زيارة المدقق وموقع المشروع المرجعي (متر)', 'ألواح'),
  ('eng_sla_days', 3, 'مهلة شركة التدقيق لإنجاز الكشف (يوم)', 'ألواح'),
  ('eng_required', 1, 'إلزام تقرير شركة التدقيق الهندسي قبل إنجاز المرحلة 32 (1 مفعّل، 0 متوقف)', 'ألواح')
on conflict (key) do nothing;

-- ───────── 2) الجداول ─────────
create table if not exists public.eng_staff (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  specialties text[] not null default '{}',
  license_no text,
  updated_at timestamptz not null default now()
);

create table if not exists public.eng_inspections (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  application_id uuid not null references public.applications(id) on delete cascade,
  org_id uuid references public.orgs(id),
  purpose text not null default 'acceptance' check (purpose in ('acceptance', 'sample')),
  program text not null default 'solar',
  round int not null default 1,
  status text not null default 'new' check (status in ('new', 'assigned', 'in_progress', 'review', 'done', 'cancelled')),
  result text check (result in ('conforming', 'conditional', 'non_conforming')),
  ordered_by_title text,
  order_note text,
  ref_geo jsonb,                 -- الموقع المرجعي: install | site | first_visit
  due_at timestamptz,
  first_visit_at timestamptz,
  review_at timestamptz,
  decided_at timestamptz,
  decided_by uuid,
  decided_by_name text,
  decided_by_code text,
  decision_note text,
  seal text,
  summary jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists eng_inspections_app on public.eng_inspections(application_id, created_at desc);
create index if not exists eng_inspections_org on public.eng_inspections(org_id, status);
create unique index if not exists eng_inspections_one_open on public.eng_inspections(application_id) where status not in ('done', 'cancelled');

create table if not exists public.eng_items (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid not null references public.eng_inspections(id) on delete cascade,
  n int not null,
  label text not null,
  detail text,
  spec text not null check (spec in ('pv', 'electrical', 'civil', 'medical', 'production')),
  assignee uuid references public.profiles(id),
  assigned_at timestamptz,
  result text check (result in ('pass', 'fail', 'other')),
  other_kind text,
  reason text,
  note text,
  photo_id uuid,
  gps jsonb,
  dist_m numeric,
  checked_at timestamptz,
  checked_by uuid,
  checked_by_name text,
  checked_by_code text,
  returned_note text,
  returns int not null default 0
);
create index if not exists eng_items_insp on public.eng_items(inspection_id, n);
create index if not exists eng_items_assignee on public.eng_items(assignee) where result is null;

create table if not exists public.eng_visits (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid not null references public.eng_inspections(id) on delete cascade,
  engineer_id uuid references public.profiles(id),
  engineer_name text,
  engineer_code text,
  lat numeric not null,
  lng numeric not null,
  acc numeric,
  dist_m numeric,
  ref text,
  at timestamptz not null default now()
);
create index if not exists eng_visits_insp on public.eng_visits(inspection_id, at);

create table if not exists public.eng_log (
  id bigserial primary key,
  inspection_id uuid not null references public.eng_inspections(id) on delete cascade,
  at timestamptz not null default now(),
  actor_name text,
  actor_code text,
  action text not null,
  note text
);
create index if not exists eng_log_insp on public.eng_log(inspection_id, at);

-- ───────── 3) الصلاحيات على الجداول (الكتابة عبر الدوال فقط) ─────────
alter table public.eng_staff enable row level security;
alter table public.eng_inspections enable row level security;
alter table public.eng_items enable row level security;
alter table public.eng_visits enable row level security;
alter table public.eng_log enable row level security;

create or replace function public._eng_can_see(p_org uuid, p_app uuid) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select case
    when my_portal() = 'auditor' then p_org = my_org()
    when my_portal() in ('cbi', 'integrity', 'audit', 'admin') then true
    when my_portal() = 'bank' then exists (select 1 from applications where id = p_app and bank_id = my_org())
    when my_portal() = 'supplier' then exists (select 1 from applications where id = p_app and supplier_id = my_org())
    when my_portal() = 'vetdept' then exists (select 1 from applications where id = p_app and program = 'vet')
    when my_portal() = 'citizen' then exists (select 1 from applications where id = p_app and citizen_id = auth.uid())
    else false end $f$;

drop policy if exists read_eng_insp on public.eng_inspections;
create policy read_eng_insp on public.eng_inspections for select using (_eng_can_see(org_id, application_id));
drop policy if exists read_eng_items on public.eng_items;
create policy read_eng_items on public.eng_items for select using (exists (select 1 from eng_inspections i where i.id = inspection_id and _eng_can_see(i.org_id, i.application_id)));
drop policy if exists read_eng_visits on public.eng_visits;
create policy read_eng_visits on public.eng_visits for select using (exists (select 1 from eng_inspections i where i.id = inspection_id and _eng_can_see(i.org_id, i.application_id)));
drop policy if exists read_eng_log on public.eng_log;
create policy read_eng_log on public.eng_log for select using (exists (select 1 from eng_inspections i where i.id = inspection_id and my_portal() = 'auditor' and i.org_id = my_org()));
drop policy if exists read_eng_staff on public.eng_staff;
create policy read_eng_staff on public.eng_staff for select using (exists (select 1 from profiles p where p.id = profile_id and p.org_id = my_org()) or my_portal() = 'admin');
revoke insert, update, delete on public.eng_staff, public.eng_inspections, public.eng_items, public.eng_visits, public.eng_log from anon, authenticated;
grant select on public.eng_staff, public.eng_inspections, public.eng_items, public.eng_visits, public.eng_log to authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'eng_inspections') then
      alter publication supabase_realtime add table public.eng_inspections; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'eng_items') then
      alter publication supabase_realtime add table public.eng_items; end if;
  end if;
end $$;

-- ───────── 4) أدوات ─────────
create or replace function public._eng_spec_label(s text) returns text language sql immutable as $f$
  select case s when 'pv' then 'طاقة شمسية وخزن' when 'electrical' then 'هندسة كهربائية' when 'civil' then 'هندسة مدنية وإنشائية'
    when 'medical' then 'أجهزة طبية ومختبرية بيطرية' when 'production' then 'خطوط إنتاج ومعامل' else s end $f$;
create or replace function public._eng_result_label(r text) returns text language sql immutable as $f$
  select case r when 'conforming' then 'مطابق' when 'conditional' then 'مطابق بملاحظات' when 'non_conforming' then 'غير مطابق' else 'بانتظار الكشف' end $f$;
create or replace function public._eng_status_label(s text) returns text language sql immutable as $f$
  select case s when 'new' then 'جديد — بانتظار التوزيع' when 'assigned' then 'موزّع — بانتظار الزيارة' when 'in_progress' then 'قيد الفحص في الموقع'
    when 'review' then 'بانتظار اعتماد المدير' when 'done' then 'منجز' when 'cancelled' then 'ملغى' else s end $f$;

-- الموظف الحالي في شركة التدقيق
create or replace function public._eng_me() returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'auditor' or me.role not in ('auditor_admin', 'auditor_engineer') then raise exception 'هذه الصلاحية لشركات التدقيق الهندسي فقط'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  return me;
end $f$;

create or replace function public._eng_log(p_insp uuid, p_action text, p_note text) returns void
language sql security definer set search_path to 'public' as $f$
  insert into eng_log(inspection_id, actor_name, actor_code, action, note)
  select p_insp, coalesce((select full_name from profiles where id = auth.uid()), 'النظام'), (select staff_code from profiles where id = auth.uid()), p_action, p_note $f$;

-- إشعار مستخدمين بأدوار معيّنة في جهة (وإن لم يوجد أحد: إشعار عام للجهة)
create or replace function public._eng_notify_roles(p_org uuid, p_portal text, p_roles text[], p_kind text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  if p_org is null then return; end if;
  insert into notifications(user_id, org_id, portal, kind, title, body, ref_id)
  select id, null, null, p_kind, p_title, p_body, p_ref from profiles where org_id = p_org and role = any(p_roles) and not coalesce(disabled, false);
  if not found then perform _notify(p_org, p_portal, p_kind, p_title, p_body, p_ref); end if;
end $f$;

-- اختيار الشركة: المعتمدة التي تغطي المحافظة (meta.governorates فارغة = كل المحافظات) والأقل انشغالاً
create or replace function public._eng_pick_org(p_gov text) returns uuid
language sql stable security definer set search_path to 'public' as $f$
  select o.id from orgs o
  where o.type = 'eng_audit' and coalesce((o.meta->>'suspended')::boolean, false) is false
    and (jsonb_array_length(coalesce(o.meta->'governorates', '[]')) = 0 or (o.meta->'governorates') ? p_gov)
  order by (select count(*) from eng_inspections i where i.org_id = o.id and i.status not in ('done', 'cancelled')), o.created_at
  limit 1 $f$;

-- إنشاء أمر كشف مع بنوده
create or replace function public._eng_create(p_app uuid, p_purpose text, p_note text, p_by text) returns eng_inspections
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare a applications; v_org uuid; ins eng_inspections; c jsonb; v_n int := 0; spec text; vp vet_projects; comps jsonb; it jsonb; ref jsonb; v_round int; v_code text;
begin
  select * into a from applications where id = p_app;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if exists (select 1 from eng_inspections where application_id = a.id and status not in ('done', 'cancelled')) then
    raise exception 'لهذا الطلب أمر كشف مفتوح لدى شركة التدقيق'; end if;
  v_org := _eng_pick_org(a.governorate);
  if v_org is null then raise exception 'لا توجد شركة تدقيق هندسي معتمدة تغطي محافظة %', a.governorate; end if;
  ref := case when a.install_geo is not null then jsonb_build_object('lat', a.install_geo->'lat', 'lng', a.install_geo->'lng', 'src', 'install')
              when a.site_geo is not null then jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng', 'src', 'site') end;
  select coalesce(max(round), 0) + 1 into v_round from eng_inspections where application_id = a.id and purpose = p_purpose;
  perform pg_advisory_xact_lock(hashtext('eng_code'));
  select 'EI-' || to_char(now(), 'YYYY') || '-' || lpad((coalesce(max(substring(code from 9)::int), 0) + 1)::text, 5, '0') into v_code
  from eng_inspections where code like 'EI-' || to_char(now(), 'YYYY') || '-%';
  insert into eng_inspections(code, application_id, org_id, purpose, program, round, ordered_by_title, order_note, ref_geo, due_at)
  values (v_code, a.id, v_org, p_purpose, coalesce(a.program, 'solar'), v_round, p_by, nullif(trim(p_note), ''), ref, now() + make_interval(days => coalesce(_setting('eng_sla_days'), 3)::int))
  returning * into ins;

  if a.program = 'vet' then
    select * into vp from vet_projects where application_id = a.id;
    spec := case when vp.project_type in ('pharma', 'supplies') then 'production' else 'medical' end;
    for it in select * from jsonb_array_elements(coalesce(vp.items, '[]')) loop
      v_n := v_n + 1;
      insert into eng_items(inspection_id, n, label, detail, spec) values (ins.id, v_n, coalesce(it->>'name', 'جهاز'),
        'الكمية ' || coalesce(it->>'qty', '1') || coalesce(' · السعر في العرض ' || to_char((it->>'price')::numeric, 'FM999,999,999,999') || ' د.ع', ''), spec);
    end loop;
    insert into eng_items(inspection_id, n, label, detail, spec) values
      (ins.id, v_n + 1, 'مطابقة الكميات والموديلات والأرقام التسلسلية مع عرض السعر', 'عرض السعر رقم ' || coalesce(vp.quote_no, '—') || ' — لا جهاز مستعمل أو بديل أقل', spec),
      (ins.id, v_n + 2, 'التوصيلات الكهربائية والتأريض وملاءمة القدرة للأجهزة', 'القواطع، مقاطع الأسلاك، مأخذ أرضي لكل جهاز', 'electrical'),
      (ins.id, v_n + 3, 'ملاءمة الموقع والبناية للنشاط', coalesce(vp.site_address, '') || coalesce(' · المساحة ' || vp.site_area || ' م²', '') || ' — التهوية والأرضيات والفصل بين الأقسام', 'civil'),
      (ins.id, v_n + 4, 'التشغيل التجريبي وسلامة الاستخدام', 'تشغيل كل جهاز أمام المهندس، ودليل التشغيل والضمان', spec);
  else
    select components into comps from supplier_offers where id = a.offer_id;
    for c in select * from jsonb_array_elements(coalesce(comps, '[]')) loop
      v_n := v_n + 1;
      spec := case when (c->>'item') ~ 'ألواح|لوح' then 'pv' when (c->>'item') ~ 'بطار' then 'pv' else 'electrical' end;
      insert into eng_items(inspection_id, n, label, detail, spec) values (ins.id, v_n, coalesce(c->>'item', 'مكوّن'),
        trim(coalesce(c->>'brand', '') || ' ' || coalesce(c->>'model', '')) || ' × ' || coalesce(c->>'qty', '1'), spec);
    end loop;
    insert into eng_items(inspection_id, n, label, detail, spec) values
      (ins.id, v_n + 1, 'الهيكل الحديدي والتثبيت', 'المتانة والتغليف (الجلفنة) وزاوية الميلان واتجاه الألواح نحو الجنوب، وسلامة السطح', 'civil'),
      (ins.id, v_n + 2, 'التمديدات والأسلاك والقواطع', 'مقاطع الأسلاك المستمرة والمتناوبة، القواطع والفيوزات، التأريض ومانعة الصواعق', 'electrical'),
      (ins.id, v_n + 3, 'الأرقام التسلسلية مطابقة لمحضر التركيب', 'العاكس والبطاريات وعيّنة من الألواح', 'electrical'),
      (ins.id, v_n + 4, 'اختبار الأداء: الإنتاج الفعلي', 'قراءة الإنتاج على شاشة العاكس مقابل القدرة المتعاقد عليها ' || coalesce(a.kw::text, '—') || ' kW', 'pv');
  end if;

  update applications set audit_status = 'pending', audit_org = (select name from orgs where id = v_org), updated_at = now() where id = a.id;
  perform _eng_log(ins.id, 'إنشاء أمر الكشف', case p_purpose when 'sample' then 'كشف رقابي بالعيّنة' else 'كشف الاستلام — المرحلة 32' end
    || case when v_round > 1 then ' · الجولة ' || v_round else '' end || coalesce(' · ' || nullif(trim(p_note), ''), ''));
  perform _eng_notify_roles(v_org, 'auditor', array['auditor_admin'], 'eng_order',
    'أمر كشف جديد ' || v_code || ' — ' || a.code,
    case when a.program = 'vet' then 'فحص مشتريات مشروع بيطري' else 'فحص منظومة شمسية ' || coalesce(a.kw::text, '') || ' kW' end || ' · ' || coalesce(a.governorate, '')
      || case p_purpose when 'sample' then ' · كشف رقابي من ' || coalesce(p_by, 'البنك المركزي') else '' end || ' — وزّع البنود على مهندسيك', ins.id);
  return ins;
end $f$;

-- ───────── 5) الربط بمسار الطلب ─────────
-- وصول الطلب إلى المرحلة 32 ← أمر كشف الاستلام آلياً
create or replace function public._eng_on_stage() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.stage = 32 and old.stage is distinct from 32 and new.status = 'active'
     and not exists (select 1 from eng_inspections where application_id = new.id and status not in ('done', 'cancelled'))
     and exists (select 1 from orgs where type = 'eng_audit') then
    begin
      perform _eng_create(new.id, 'acceptance', null, 'آلياً — وصول الطلب إلى الكشف والاستلام (المرحلة 32)');
    exception when others then
      insert into integrity_alerts(type, severity, title, details, application_id, entity)
      values ('eng_unassigned', 'medium', 'تعذّر إسناد كشف هندسي', new.code || ': ' || sqlerrm, new.id, coalesce(new.governorate, ''));
    end;
  end if;
  -- إلغاء الطلب أو رفضه يُلغي الأوامر المفتوحة
  if new.status in ('cancelled', 'rejected') and old.status is distinct from new.status then
    update eng_inspections set status = 'cancelled', updated_at = now() where application_id = new.id and status not in ('done', 'cancelled');
  end if;
  return new;
end $f$;
drop trigger if exists trg_eng_on_stage on public.applications;
create trigger trg_eng_on_stage after update of stage, status on public.applications for each row execute function public._eng_on_stage();

-- لا تُنجز المرحلة 32 قبل تقرير شركة التدقيق (مطابق أو مطابق بملاحظات) — إن وُجد أمر استلام
create or replace function public._guard_eng() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare v_last eng_inspections;
begin
  if old.stage = 32 and new.stage > 32 and coalesce(_setting('eng_required'), 1) = 1 then
    select * into v_last from eng_inspections where application_id = new.id and purpose = 'acceptance' and status <> 'cancelled' order by created_at desc limit 1;
    if v_last.id is not null then
      if v_last.status <> 'done' then raise exception 'بانتظار تقرير شركة التدقيق الهندسي (أمر %: %) — لا تُنجز المرحلة قبل صدوره', v_last.code, _eng_status_label(v_last.status); end if;
      if v_last.result = 'non_conforming' then raise exception 'تقرير التدقيق الهندسي % «غير مطابق» — يصلح المورد البنود ثم يُطلب إعادة الكشف', v_last.code; end if;
    end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_guard_eng on public.applications;
create trigger trg_guard_eng before update of stage on public.applications for each row execute function public._guard_eng();

-- إشعار المقترض برسالة نصية بنتيجة الكشف
do $$
declare d text;
begin
  d := pg_get_functiondef('public._sms_from_notification()'::regprocedure);
  if position('eng_result' in d) = 0 then
    if position('''installment_late'')' in d) = 0 then raise exception 'الجلسة 37: لم يُعثر على موضع الإضافة في _sms_from_notification'; end if;
    execute replace(d, '''installment_late'')', '''installment_late'', ''eng_result'')');
  end if;
end $$;

-- ───────── 6) بوابة الشركة: الصندوق ─────────
create or replace function public._eng_row(i eng_inspections, me profiles) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object(
    'id', i.id, 'code', i.code, 'purpose', i.purpose, 'program', i.program, 'round', i.round, 'status', i.status, 'status_label', _eng_status_label(i.status),
    'result', i.result, 'result_label', _eng_result_label(i.result), 'created_at', i.created_at, 'due_at', i.due_at, 'decided_at', i.decided_at,
    'late', i.status not in ('done', 'cancelled') and i.due_at < now(),
    'app', jsonb_build_object('id', a.id, 'code', a.code, 'governorate', a.governorate, 'city', a.city, 'kw', a.kw, 'purpose', a.purpose, 'stage', a.stage,
      'vet_type', vp.project_type, 'vet_title', vp.title, 'supplier', (select name from orgs where id = a.supplier_id), 'bank', (select name from orgs where id = a.bank_id)),
    'total', (select count(*) from eng_items where inspection_id = i.id),
    'assigned', (select count(*) from eng_items where inspection_id = i.id and assignee is not null),
    'checked', (select count(*) from eng_items where inspection_id = i.id and result is not null),
    'fail', (select count(*) from eng_items where inspection_id = i.id and result = 'fail'),
    'other', (select count(*) from eng_items where inspection_id = i.id and result = 'other'),
    'mine', (select count(*) from eng_items where inspection_id = i.id and assignee = me.id),
    'mine_left', (select count(*) from eng_items where inspection_id = i.id and assignee = me.id and result is null),
    'visits', (select count(*) from eng_visits where inspection_id = i.id),
    'my_visit', exists (select 1 from eng_visits where inspection_id = i.id and engineer_id = me.id))
  from applications a left join vet_projects vp on vp.application_id = a.id where a.id = i.application_id $f$;

create or replace function public.eng_inbox() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles := _eng_me(); mgr boolean := me.role = 'auditor_admin';
begin
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'role', me.role, 'manager', mgr, 'name', me.full_name, 'code', me.staff_code,
      'specialties', coalesce((select specialties from eng_staff where profile_id = me.id), '{}')),
    'org', (select jsonb_build_object('id', id, 'name', name, 'governorates', coalesce(meta->'governorates', '[]')) from orgs where id = me.org_id),
    'orders', coalesce((select jsonb_agg(_eng_row(i, me) order by (i.status = 'done'), i.due_at) from eng_inspections i
      where i.org_id = me.org_id and i.status <> 'cancelled' and (i.status <> 'done' or i.decided_at > now() - interval '60 days')
        and (mgr or exists (select 1 from eng_items x where x.inspection_id = i.id and x.assignee = me.id))), '[]'),
    'team', case when mgr then coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'username', p.username, 'role', p.role, 'code', p.staff_code,
        'disabled', coalesce(p.disabled, false), 'specialties', coalesce(s.specialties, '{}'), 'license_no', s.license_no,
        'open', (select count(*) from eng_items x join eng_inspections i on i.id = x.inspection_id where x.assignee = p.id and x.result is null and i.status not in ('done', 'cancelled')),
        'done', (select count(*) from eng_items x where x.checked_by = p.id)) order by p.role, p.full_name)
      from profiles p left join eng_staff s on s.profile_id = p.id where p.org_id = me.org_id and p.portal = 'auditor'), '[]') end,
    'specs', (select jsonb_agg(jsonb_build_object('k', k, 'label', _eng_spec_label(k))) from unnest(array['pv', 'electrical', 'civil', 'medical', 'production']) k),
    'settings', jsonb_build_object('acc', coalesce(_setting('eng_gps_accuracy_m'), 100), 'dist', coalesce(_setting('eng_max_distance_m'), 300)));
end $f$;

-- ملف الأمر كاملاً
create or replace function public.eng_inspection(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles := _eng_me(); i eng_inspections; a applications; vp vet_projects; cz profiles; mgr boolean := me.role = 'auditor_admin';
begin
  select * into i from eng_inspections where id = p_id;
  if i is null or i.org_id is distinct from me.org_id then raise exception 'الأمر لا يخص شركتك'; end if;
  if not mgr and not exists (select 1 from eng_items where inspection_id = i.id and assignee = me.id) then raise exception 'لا بنود مسندة إليك في هذا الأمر'; end if;
  select * into a from applications where id = i.application_id;
  select * into vp from vet_projects where application_id = a.id;
  select * into cz from profiles where id = a.citizen_id;
  return _eng_row(i, me) || jsonb_build_object(
    'order_note', i.order_note, 'ordered_by', i.ordered_by_title, 'ref_geo', i.ref_geo, 'seal', i.seal, 'decision_note', i.decision_note,
    'decided_by', i.decided_by_name, 'decided_code', i.decided_by_code, 'summary', i.summary, 'first_visit_at', i.first_visit_at,
    'site', jsonb_build_object('borrower', a.citizen_name, 'phone', coalesce(cz.phone, ''), 'address', coalesce(vp.site_address, a.city), 'governorate', a.governorate,
      'site_geo', a.site_geo, 'install_geo', a.install_geo, 'approx', case when a.lat is not null then jsonb_build_object('lat', a.lat, 'lng', a.lng) end,
      'kw', a.kw, 'vet_title', vp.title, 'vet_type', vp.project_type, 'quote_no', vp.quote_no, 'supplier', (select name from orgs where id = a.supplier_id),
      'bank', (select name from orgs where id = a.bank_id), 'milestones', vp.milestones),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'n', x.n, 'label', x.label, 'detail', x.detail, 'spec', x.spec, 'spec_label', _eng_spec_label(x.spec),
        'assignee', x.assignee, 'assignee_name', (select full_name from profiles where id = x.assignee), 'mine', x.assignee = me.id,
        'result', x.result, 'other_kind', x.other_kind, 'reason', x.reason, 'note', x.note, 'photo_id', x.photo_id, 'dist_m', x.dist_m,
        'checked_at', x.checked_at, 'checked_by', x.checked_by_name, 'checked_code', x.checked_by_code, 'returned_note', x.returned_note, 'returns', x.returns) order by x.n)
      from eng_items x where x.inspection_id = i.id), '[]'),
    'visit_list', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'name', v.engineer_name, 'code', v.engineer_code, 'lat', v.lat, 'lng', v.lng, 'acc', v.acc,
        'dist_m', v.dist_m, 'ref', v.ref, 'at', v.at, 'mine', v.engineer_id = me.id) order by v.at) from eng_visits v where v.inspection_id = i.id), '[]'),
    'log', case when mgr then coalesce((select jsonb_agg(jsonb_build_object('at', l.at, 'by', l.actor_name, 'code', l.actor_code, 'action', l.action, 'note', l.note) order by l.at desc)
      from eng_log l where l.inspection_id = i.id), '[]') end,
    'engineers', case when mgr then coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'specialties', coalesce(s.specialties, '{}'),
        'open', (select count(*) from eng_items x join eng_inspections ii on ii.id = x.inspection_id where x.assignee = p.id and x.result is null and ii.status not in ('done', 'cancelled')))
        order by p.full_name) from profiles p left join eng_staff s on s.profile_id = p.id where p.org_id = me.org_id and p.portal = 'auditor' and not coalesce(p.disabled, false)), '[]') end,
    'can', jsonb_build_object('assign', mgr and i.status in ('new', 'assigned', 'in_progress'),
      'visit', i.status in ('assigned', 'in_progress') and exists (select 1 from eng_items where inspection_id = i.id and assignee = me.id),
      'finalize', mgr and i.status = 'review'));
end $f$;

-- ───────── 7) الإسناد (يدوي أو آلي حسب التخصص) ─────────
create or replace function public.eng_assign(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _eng_me(); i eng_inspections; x eng_items; uid uuid; k text; pr profiles; sp text[]; missing text[] := '{}'; who uuid[] := '{}'; v_n int := 0;
begin
  if me.role <> 'auditor_admin' then raise exception 'توزيع البنود لمدير الشركة فقط'; end if;
  select * into i from eng_inspections where id = p_id for update;
  if i is null or i.org_id is distinct from me.org_id then raise exception 'الأمر لا يخص شركتك'; end if;
  if i.status not in ('new', 'assigned', 'in_progress') then raise exception 'لا يمكن التوزيع والأمر «%»', _eng_status_label(i.status); end if;

  if coalesce((p->>'auto')::boolean, false) then
    for x in select * from eng_items where inspection_id = i.id and result is null and (assignee is null or coalesce((p->>'reassign')::boolean, false)) order by n loop
      -- من في الشركة يحمل التخصص: صاحب التخصص الأساسي، ثم من له بنود في الأمر نفسه، ثم الأقل انشغالاً
      select p2.id into uid from profiles p2 join eng_staff s on s.profile_id = p2.id
      where p2.org_id = me.org_id and p2.portal = 'auditor' and not coalesce(p2.disabled, false) and x.spec = any(s.specialties)
      order by (s.specialties[1] = x.spec) desc,          -- تخصصه الأساسي أولاً
               (p2.role = 'auditor_admin'),                  -- المدير آخر الخيارات
               (exists (select 1 from eng_items y where y.inspection_id = i.id and y.assignee = p2.id)) desc,   -- زيارة واحدة قدر الإمكان
               (select count(*) from eng_items y join eng_inspections ii on ii.id = y.inspection_id where y.assignee = p2.id and y.result is null and ii.status not in ('done', 'cancelled')),
               p2.full_name
      limit 1;
      if uid is null then missing := array_append(missing, _eng_spec_label(x.spec)); continue; end if;
      update eng_items set assignee = uid, assigned_at = now() where id = x.id;
      who := array_append(who, uid); v_n := v_n + 1;
    end loop;
  else
    for k in select jsonb_object_keys(coalesce(p->'items', '{}')) loop
      select * into x from eng_items where id = k::uuid and inspection_id = i.id;
      if x.id is null then raise exception 'بند غير معروف'; end if;
      if x.result is not null then raise exception 'البند % مفحوص — أعده أولاً لتغيير المهندس', x.n; end if;
      uid := nullif(p->'items'->>k, '')::uuid;
      if uid is not null then
        select * into pr from profiles where id = uid;
        if pr.org_id is distinct from me.org_id or pr.portal <> 'auditor' or coalesce(pr.disabled, false) then raise exception 'المهندس ليس من شركتك أو موقوف'; end if;
        select specialties into sp from eng_staff where profile_id = uid;
        if not (x.spec = any(coalesce(sp, '{}'))) then raise exception 'البند % (%) خارج تخصص %', x.n, _eng_spec_label(x.spec), pr.full_name; end if;
        who := array_append(who, uid);
      end if;
      update eng_items set assignee = uid, assigned_at = case when uid is null then null else now() end where id = x.id;
      v_n := v_n + 1;
    end loop;
  end if;

  if exists (select 1 from eng_items where inspection_id = i.id and assignee is not null) and i.status = 'new' then
    update eng_inspections set status = 'assigned', updated_at = now() where id = i.id;
  end if;
  update eng_inspections set updated_at = now() where id = i.id;
  perform _eng_log(i.id, case when coalesce((p->>'auto')::boolean, false) then 'توزيع آلي حسب التخصص' else 'توزيع البنود' end,
    v_n || ' بند' || case when cardinality(missing) > 0 then ' · لا مهندس بتخصص: ' || array_to_string(array(select distinct unnest(missing)), '، ') else '' end);
  insert into notifications(user_id, kind, title, body, ref_id)
  select distinct u, 'eng_task', 'بنود فحص جديدة لك — ' || i.code,
    (select count(*) from eng_items where inspection_id = i.id and assignee = u) || ' بند · ' || (select a.code || ' · ' || coalesce(a.governorate, '') from applications a where a.id = i.application_id)
      || ' — ثبّت زيارتك بالـGPS في الموقع ثم احكم على بنودك', i.id
  from unnest(who) u where u <> me.id;
  return jsonb_build_object('assigned', v_n, 'missing', to_jsonb(array(select distinct unnest(missing))),
    'left', (select count(*) from eng_items where inspection_id = i.id and assignee is null));
end $f$;

-- تخصصات المهندس ورقمه النقابي (مدير الشركة)
create or replace function public.eng_staff_set(p_user uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _eng_me(); pr profiles; sp text[];
begin
  if me.role <> 'auditor_admin' then raise exception 'تحديد التخصصات لمدير الشركة فقط'; end if;
  select * into pr from profiles where id = p_user;
  if pr is null or pr.org_id is distinct from me.org_id or pr.portal <> 'auditor' then raise exception 'الموظف ليس من شركتك'; end if;
  -- الترتيب محفوظ: التخصص الأول هو الأساسي في التوزيع الآلي
  sp := array(select x from (select x, min(o) o from jsonb_array_elements_text(coalesce(p->'specialties', '[]')) with ordinality t(x, o)
                             where x in ('pv', 'electrical', 'civil', 'medical', 'production') group by x) q order by o);
  if pr.role = 'auditor_engineer' and cardinality(sp) = 0 then raise exception 'اختر تخصصاً واحداً على الأقل للمهندس'; end if;
  insert into eng_staff(profile_id, specialties, license_no, updated_at) values (pr.id, sp, nullif(trim(p->>'license_no'), ''), now())
  on conflict (profile_id) do update set specialties = excluded.specialties, license_no = excluded.license_no, updated_at = now();
  return jsonb_build_object('ok', true, 'specialties', to_jsonb(sp));
end $f$;

-- ───────── 8) الزيارة بالـGPS ─────────
create or replace function public.eng_checkin(p_id uuid, p_gps jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _eng_me(); i eng_inspections; a applications; lat float8; lng float8; acc float8; d float8; mx numeric := coalesce(_setting('eng_max_distance_m'), 300);
  v eng_visits; ref text; g jsonb;
begin
  select * into i from eng_inspections where id = p_id for update;
  if i is null or i.org_id is distinct from me.org_id then raise exception 'الأمر لا يخص شركتك'; end if;
  if i.status not in ('assigned', 'in_progress') then raise exception 'لا زيارة والأمر «%»', _eng_status_label(i.status); end if;
  if not exists (select 1 from eng_items where inspection_id = i.id and assignee = me.id) then raise exception 'لا بنود مسندة إليك في هذا الأمر'; end if;
  lat := nullif(p_gps->>'lat', '')::float8; lng := nullif(p_gps->>'lng', '')::float8; acc := nullif(p_gps->>'acc', '')::float8;
  if lat is null or lng is null then raise exception 'فعّل الموقع (GPS) — الزيارة تُثبَّت بموقعها'; end if;
  if not _geo_in_iraq(lat, lng) then raise exception 'الموقع خارج العراق — أعد تحديد الموقع'; end if;
  if acc is null or acc > coalesce(_setting('eng_gps_accuracy_m'), 100) then
    raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م) — اخرج إلى مكان مكشوف وأعد المحاولة', round(coalesce(acc, 0)), coalesce(_setting('eng_gps_accuracy_m'), 100); end if;
  if i.ref_geo is not null then
    d := _geo_dist_m(lat, lng, (i.ref_geo->>'lat')::float8, (i.ref_geo->>'lng')::float8); ref := i.ref_geo->>'src';
    if d > mx then raise exception 'أنت على بعد % م من موقع المشروع (الحد % م) — ثبّت الزيارة وأنت في الموقع نفسه', round(d), mx; end if;
  else
    -- لا موقع مرجعي سابق: أول زيارة تصبح المرجع، ويُكتب ذلك في التقرير
    update eng_inspections set ref_geo = jsonb_build_object('lat', round(lat::numeric, 6), 'lng', round(lng::numeric, 6), 'src', 'first_visit') where id = i.id;
    ref := 'first_visit'; d := null;
  end if;
  insert into eng_visits(inspection_id, engineer_id, engineer_name, engineer_code, lat, lng, acc, dist_m, ref)
  values (i.id, me.id, me.full_name, me.staff_code, round(lat::numeric, 6), round(lng::numeric, 6), round(acc::numeric, 1), round(d::numeric), ref) returning * into v;
  update eng_inspections set status = 'in_progress', first_visit_at = coalesce(first_visit_at, now()), updated_at = now() where id = i.id;
  g := jsonb_build_object('lat', v.lat, 'lng', v.lng, 'acc', v.acc, 'at', v.at, 'by', me.full_name, 'code', i.code);
  update applications set audit_geo = g, updated_at = now() where id = i.application_id;
  perform _eng_log(i.id, 'تثبيت الزيارة بالـGPS', 'دقة ±' || round(acc) || ' م' || case when d is not null then ' · يبعد ' || round(d) || ' م عن ' ||
    case ref when 'install' then 'موقع التركيب' when 'site' then 'عنوان المقترض' else 'نقطة الزيارة الأولى' end else ' · أول زيارة — صارت الموقع المرجعي' end);
  perform _ev(i.application_id, (select stage from applications where id = i.application_id), 'زيارة المدقق الهندسي للموقع (' || i.code || ')',
    me.full_name || ' · ' || coalesce(me.staff_code, '') || ' · دقة ±' || round(acc) || ' م' || coalesce(' · ' || round(d) || ' م عن الموقع المرجعي', ''));
  return jsonb_build_object('id', v.id, 'dist_m', v.dist_m, 'ref', ref, 'acc', v.acc);
end $f$;

-- ───────── 9) الحكم على البند ─────────
create or replace function public.eng_item_set(p_item uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles := _eng_me(); x eng_items; i eng_inspections; v eng_visits; lat float8; lng float8; d float8; mx numeric := coalesce(_setting('eng_max_distance_m'), 300);
  r text := p->>'result'; ph text := p->>'photo'; did uuid; left_n int;
begin
  select * into x from eng_items where id = p_item for update;
  select * into i from eng_inspections where id = x.inspection_id for update;
  if x.id is null or i.org_id is distinct from me.org_id then raise exception 'البند لا يخص شركتك'; end if;
  if x.assignee is distinct from me.id then raise exception 'هذا البند مسند لمهندس آخر — تحكم على بنودك فقط'; end if;
  if i.status not in ('assigned', 'in_progress') then raise exception 'لا يمكن الحكم والأمر «%»', _eng_status_label(i.status); end if;
  select * into v from eng_visits where inspection_id = i.id and engineer_id = me.id order by at desc limit 1;
  if v.id is null then raise exception 'ثبّت زيارتك بالـGPS في الموقع أولاً'; end if;
  if r not in ('pass', 'fail', 'other') then raise exception 'اختر الحكم: مطابق أو غير مطابق أو أخرى'; end if;
  lat := nullif(p->'gps'->>'lat', '')::float8; lng := nullif(p->'gps'->>'lng', '')::float8;
  if lat is null or lng is null then raise exception 'فعّل الموقع (GPS) — كل حكم يُحفظ بموقع لحظته'; end if;
  d := _geo_dist_m(lat, lng, v.lat::float8, v.lng::float8);
  if d > mx then raise exception 'أنت على بعد % م من نقطة زيارتك — احكم على البند وأنت في الموقع', round(d); end if;
  if r = 'fail' and length(trim(coalesce(p->>'reason', ''))) < 3 then raise exception 'اكتب سبب عدم المطابقة'; end if;
  if r = 'other' and (coalesce(p->>'other_kind', '') = '' or length(trim(coalesce(p->>'note', ''))) < 3) then raise exception 'اختر نوع الحالة واكتب ملاحظة'; end if;
  if ph is not null then
    if coalesce((p->>'photo_live')::boolean, false) is not true then raise exception 'تُلتقط الصورة بكاميرا الهاتف مباشرة — لا يُقبل ملف من المعرض'; end if;
    if substring(ph from '^data:(image/jpeg);base64,') is null then raise exception 'الصورة تُلتقط بكاميرا الهاتف (JPEG)'; end if;
    if length(ph) > 4000000 then raise exception 'حجم الصورة كبير — الحد 3 ميغابايت'; end if;
    insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
    values (i.application_id, 'eng_photo', 'camera', 'image/jpeg', ph, length(ph), encode(extensions.digest(ph, 'sha256'), 'hex'),
      jsonb_build_object('inspection', i.code, 'item', x.n, 'label', x.label, 'gps', p->'gps', 'dist_m', round(d::numeric), 'by', me.full_name, 'by_code', me.staff_code, 'server_at', now()),
      me.id, _role_title(me.role)) returning id into did;
  end if;
  if r = 'fail' and coalesce(did, x.photo_id) is null then raise exception 'صوّر البند غير المطابق — الصورة دليل إلزامي'; end if;
  update eng_items set result = r, other_kind = case when r = 'other' then p->>'other_kind' end, reason = case when r = 'fail' then trim(p->>'reason') end,
    note = nullif(trim(coalesce(p->>'note', '')), ''), photo_id = coalesce(did, photo_id),
    gps = jsonb_build_object('lat', round(lat::numeric, 6), 'lng', round(lng::numeric, 6), 'acc', p->'gps'->'acc'), dist_m = round(d::numeric),
    checked_at = now(), checked_by = me.id, checked_by_name = me.full_name, checked_by_code = me.staff_code, returned_note = null
  where id = x.id;
  perform _eng_log(i.id, 'البند ' || x.n || ': ' || case r when 'pass' then 'مطابق' when 'fail' then 'غير مطابق' else 'أخرى — ' || (p->>'other_kind') end,
    x.label || coalesce(' · ' || nullif(trim(coalesce(p->>'reason', p->>'note', '')), ''), ''));
  select count(*) into left_n from eng_items where inspection_id = i.id and result is null;
  if left_n = 0 then
    update eng_inspections set status = 'review', review_at = now(), updated_at = now() where id = i.id;
    perform _eng_log(i.id, 'اكتمل فحص كل البنود', 'بانتظار اعتماد مدير الشركة');
    perform _eng_notify_roles(i.org_id, 'auditor', array['auditor_admin'], 'eng_review', 'اكتمل فحص ' || i.code || ' — بانتظار اعتمادك',
      (select count(*) from eng_items where inspection_id = i.id and result = 'fail') || ' غير مطابق · ' ||
      (select count(*) from eng_items where inspection_id = i.id and result = 'other') || ' أخرى · ' ||
      (select count(*) from eng_items where inspection_id = i.id and result = 'pass') || ' مطابق', i.id);
  else
    update eng_inspections set updated_at = now() where id = i.id;
  end if;
  return jsonb_build_object('ok', true, 'left', left_n, 'mine_left', (select count(*) from eng_items where inspection_id = i.id and assignee = me.id and result is null), 'dist_m', round(d));
end $f$;

-- صورة البند (لمن يحق له رؤية التقرير)
create or replace function public.eng_photo(p_doc uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare d app_documents; i eng_inspections;
begin
  select * into d from app_documents where id = p_doc and kind = 'eng_photo';
  if d.id is null then raise exception 'الصورة غير موجودة'; end if;
  select * into i from eng_inspections where application_id = d.application_id and code = d.meta->>'inspection';
  if i.id is null or not _eng_can_see(i.org_id, i.application_id) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('data', d.data, 'meta', d.meta, 'sha256', d.sha256, 'at', d.created_at);
end $f$;

-- ───────── 10) الاعتماد النهائي أو إعادة بند ─────────
create or replace function public.eng_finalize(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles := _eng_me(); i eng_inspections; a applications; x eng_items; res text; sm jsonb; v_seal text; lbl text; ttl text; body text; sent text[] := '{}';
begin
  if me.role <> 'auditor_admin' then raise exception 'اعتماد التقرير لمدير الشركة فقط'; end if;
  select * into i from eng_inspections where id = p_id for update;
  if i is null or i.org_id is distinct from me.org_id then raise exception 'الأمر لا يخص شركتك'; end if;
  select * into a from applications where id = i.application_id;

  if p->>'action' = 'return' then
    if i.status not in ('review', 'in_progress') then raise exception 'لا يمكن الإعادة والأمر «%»', _eng_status_label(i.status); end if;
    if length(trim(coalesce(p->>'note', ''))) < 3 then raise exception 'اكتب سبب إعادة البند'; end if;
    select * into x from eng_items where id = (p->>'item')::uuid and inspection_id = i.id for update;
    if x.id is null then raise exception 'اختر البند'; end if;
    update eng_items set result = null, other_kind = null, reason = null, checked_at = null, returned_note = trim(p->>'note'), returns = returns + 1 where id = x.id;
    update eng_inspections set status = 'in_progress', updated_at = now() where id = i.id;
    perform _eng_log(i.id, 'إعادة البند ' || x.n || ' للمهندس', trim(p->>'note'));
    if x.assignee is not null then
      insert into notifications(user_id, kind, title, body, ref_id) values (x.assignee, 'eng_task', 'أُعيد إليك البند ' || x.n || ' — ' || i.code, x.label || ' · السبب: ' || trim(p->>'note'), i.id);
    end if;
    return jsonb_build_object('ok', true, 'action', 'return');
  end if;

  if p->>'action' <> 'approve' then raise exception 'إجراء غير معروف'; end if;
  if i.status <> 'review' then raise exception 'يُعتمد التقرير بعد فحص كل البنود'; end if;
  if trim(coalesce(p->>'confirm', '')) <> 'أعتمد التقرير' then raise exception 'اكتب «أعتمد التقرير» للتأكيد'; end if;
  res := case when exists (select 1 from eng_items where inspection_id = i.id and result = 'fail') then 'non_conforming'
              when exists (select 1 from eng_items where inspection_id = i.id and result = 'other') then 'conditional' else 'conforming' end;
  lbl := _eng_result_label(res);
  sm := jsonb_build_object('pass', (select count(*) from eng_items where inspection_id = i.id and result = 'pass'),
    'fail', (select count(*) from eng_items where inspection_id = i.id and result = 'fail'),
    'other', (select count(*) from eng_items where inspection_id = i.id and result = 'other'),
    'total', (select count(*) from eng_items where inspection_id = i.id), 'code', i.code, 'purpose', i.purpose,
    'company', (select name from orgs where id = i.org_id),
    'engineers', (select coalesce(jsonb_agg(distinct checked_by_name), '[]') from eng_items where inspection_id = i.id),
    'failed', (select coalesce(jsonb_agg(jsonb_build_object('n', n, 'label', label, 'reason', reason) order by n), '[]') from eng_items where inspection_id = i.id and result = 'fail'),
    'visit_at', i.first_visit_at);
  v_seal := encode(extensions.digest(convert_to(jsonb_build_object('inspection', i.code, 'app', a.code, 'result', res,
    'items', (select jsonb_agg(jsonb_build_object('n', n, 'r', result, 'k', other_kind, 'reason', reason, 'note', note, 'by', checked_by_code, 'at', checked_at, 'gps', gps) order by n) from eng_items where inspection_id = i.id),
    'visits', (select jsonb_agg(jsonb_build_object('by', engineer_code, 'lat', lat, 'lng', lng, 'at', at) order by at) from eng_visits where inspection_id = i.id),
    'by', me.staff_code, 'at', now())::text, 'UTF8'), 'sha256'), 'hex');
  update eng_inspections set status = 'done', result = res, decided_at = now(), decided_by = me.id, decided_by_name = me.full_name, decided_by_code = me.staff_code,
    decision_note = nullif(trim(coalesce(p->>'note', '')), ''), seal = v_seal, summary = sm, updated_at = now() where id = i.id;
  update applications set audit_status = res, audit_at = now(), audit_summary = sm, audit_org = sm->>'company',
    inspection_result = case when i.purpose = 'acceptance' and res <> 'non_conforming' then lbl || ' — ' || i.code else inspection_result end, updated_at = now()
  where id = a.id;
  perform _eng_log(i.id, 'اعتماد التقرير: ' || lbl, 'البصمة ' || left(v_seal, 16) || '…' || coalesce(' · ' || nullif(trim(coalesce(p->>'note', '')), ''), ''));
  perform _ev(a.id, a.stage, 'تقرير التدقيق الهندسي ' || i.code || ': ' || lbl,
    (sm->>'pass') || ' مطابق · ' || (sm->>'fail') || ' غير مطابق · ' || (sm->>'other') || ' أخرى · ' || (sm->>'company') || ' · بصمة ' || left(v_seal, 16));

  ttl := 'نتيجة التدقيق الهندسي ' || a.code || ': ' || lbl;
  body := (sm->>'company') || ' · ' || i.code || ' · ' || (sm->>'pass') || '/' || (sm->>'total') || ' بند مطابق'
    || case when res = 'non_conforming' then ' — البنود غير المطابقة: ' || (select string_agg(n || '. ' || label, '، ' order by n) from eng_items where inspection_id = i.id and result = 'fail') else '' end;
  -- المصرف: لجنة الكشف ومدير الفرع
  perform _eng_notify_roles(a.bank_id, 'bank', array['bank_inspection', 'bank_branch_mgr'], 'eng_result', ttl, body, a.id); sent := array_append(sent, 'المصرف');
  -- المورد
  if a.supplier_id is not null then
    perform _eng_notify_roles(a.supplier_id, 'supplier', array['supplier_admin'], 'eng_result', ttl,
      body || case when res = 'non_conforming' and i.purpose = 'acceptance' then ' — أصلح البنود ثم اطلب إعادة الكشف من ملف الطلب' else '' end, a.id);
    sent := array_append(sent, 'المورد');
  end if;
  -- البنك المركزي
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'eng_result', ttl, body, a.id); sent := array_append(sent, 'البنك المركزي');
  -- دائرة البيطرة للمشاريع البيطرية
  if a.program = 'vet' then perform _notify((select id from orgs where type = 'vetdept' order by created_at limit 1), 'vetdept', 'eng_result', ttl, body, a.id); sent := array_append(sent, 'دائرة البيطرة'); end if;
  -- المقترض (ورسالة نصية)
  if a.citizen_id is not null then
    insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, 'eng_result',
      'نتيجة الكشف الهندسي على مشروعك: ' || lbl,
      case res when 'conforming' then 'مشروعك مطابق للمواصفات.' when 'conditional' then 'مشروعك مطابق مع ملاحظات يراجعها المصرف.' else 'وُجدت بنود غير مطابقة — سيصلحها المورد ويُعاد الكشف.' end, a.id);
    sent := array_append(sent, 'المقترض');
  end if;
  -- هيئة النزاهة عند عدم المطابقة
  if res = 'non_conforming' then
    insert into integrity_alerts(type, severity, title, details, application_id, entity)
    values ('eng_non_conforming', 'high', 'تقرير تدقيق هندسي «غير مطابق»', a.code || ' · ' || i.code || ' · ' || body, a.id, coalesce((select name from orgs where id = a.supplier_id), ''));
    sent := array_append(sent, 'هيئة النزاهة');
  end if;
  return jsonb_build_object('ok', true, 'result', res, 'label', lbl, 'seal', v_seal, 'summary', sm, 'sent', to_jsonb(sent), 'code', i.code, 'app', a.code);
end $f$;

-- ───────── 11) للجهات الأخرى: التقرير، الكشف الرقابي، إعادة الكشف ─────────
create or replace function public.eng_app_report(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; me profiles; full_ boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or not _eng_can_see(null, a.id) then return null; end if;
  full_ := me.portal <> 'citizen';
  return jsonb_build_object(
    'can_sample', me.portal in ('cbi', 'admin') and a.stage >= 32 and a.status in ('active', 'completed')
      and not exists (select 1 from eng_inspections where application_id = a.id and status not in ('done', 'cancelled')) and exists (select 1 from orgs where type = 'eng_audit'),
    'can_reinspect', a.stage = 32 and a.status = 'active'
      and ((me.portal = 'supplier' and me.role = 'supplier_admin' and a.supplier_id = me.org_id) or (me.portal = 'bank' and me.role in ('bank_inspection', 'bank_branch_mgr') and a.bank_id = me.org_id))
      and (select result from eng_inspections where application_id = a.id and purpose = 'acceptance' and status <> 'cancelled' order by created_at desc limit 1) = 'non_conforming',
    'list', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'code', i.code, 'purpose', i.purpose, 'round', i.round, 'status', i.status, 'status_label', _eng_status_label(i.status),
        'result', i.result, 'result_label', _eng_result_label(i.result), 'company', (select name from orgs where id = i.org_id), 'created_at', i.created_at, 'due_at', i.due_at,
        'decided_at', i.decided_at, 'decided_by', i.decided_by_name, 'seal', i.seal, 'note', i.decision_note, 'order_note', i.order_note, 'ordered_by', i.ordered_by_title,
        'items', case when full_ then (select coalesce(jsonb_agg(jsonb_build_object('n', x.n, 'label', x.label, 'detail', x.detail, 'spec', _eng_spec_label(x.spec), 'result', x.result,
            'other_kind', x.other_kind, 'reason', x.reason, 'note', x.note, 'photo_id', x.photo_id, 'by', x.checked_by_name, 'code', x.checked_by_code, 'at', x.checked_at, 'dist_m', x.dist_m) order by x.n), '[]')
          from eng_items x where x.inspection_id = i.id and (i.status = 'done' or me.portal in ('cbi', 'integrity', 'audit', 'admin'))) end,
        'visits', case when full_ then (select coalesce(jsonb_agg(jsonb_build_object('name', v.engineer_name, 'code', v.engineer_code, 'lat', v.lat, 'lng', v.lng, 'acc', v.acc, 'dist_m', v.dist_m, 'ref', v.ref, 'at', v.at) order by v.at), '[]')
          from eng_visits v where v.inspection_id = i.id) end,
        'progress', jsonb_build_object('total', (select count(*) from eng_items where inspection_id = i.id), 'checked', (select count(*) from eng_items where inspection_id = i.id and result is not null)))
      order by i.created_at desc) from eng_inspections i where i.application_id = a.id and i.status <> 'cancelled'), '[]'));
end $f$;

create or replace function public.eng_order_sample(p_app uuid, p_note text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; ins eng_inspections;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or not (me.portal = 'cbi' or _is_admin()) then raise exception 'الكشف الرقابي يطلبه البنك المركزي أو مشغّل النظام'; end if;
  if length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب سبب الكشف الرقابي'; end if;
  select * into a from applications where id = p_app;
  if a is null or a.stage < 32 or a.status not in ('active', 'completed') then raise exception 'الكشف الرقابي للمشاريع التي وصلت التركيب أو اكتملت'; end if;
  ins := _eng_create(a.id, 'sample', p_note, _role_title(me.role) || ' — ' || me.full_name);
  perform _ev(a.id, a.stage, 'طلب كشف رقابي بالعيّنة من شركة التدقيق الهندسي (' || ins.code || ')', trim(p_note));
  return jsonb_build_object('ok', true, 'code', ins.code, 'company', (select name from orgs where id = ins.org_id), 'due_at', ins.due_at);
end $f$;

create or replace function public.eng_reinspect(p_app uuid, p_note text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; a applications; v_last eng_inspections; ins eng_inspections;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null or coalesce(me.disabled, false) or not ((me.portal = 'supplier' and me.role = 'supplier_admin' and a.supplier_id = me.org_id)
     or (me.portal = 'bank' and me.role in ('bank_inspection', 'bank_branch_mgr') and a.bank_id = me.org_id)) then raise exception 'غير مخوّل'; end if;
  if a.stage <> 32 or a.status <> 'active' then raise exception 'إعادة الكشف في مرحلة الكشف والاستلام (32)'; end if;
  select * into v_last from eng_inspections where application_id = a.id and purpose = 'acceptance' and status <> 'cancelled' order by created_at desc limit 1;
  if v_last.result is distinct from 'non_conforming' then raise exception 'إعادة الكشف بعد تقرير «غير مطابق» فقط'; end if;
  if length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب ما أُصلح'; end if;
  ins := _eng_create(a.id, 'acceptance', 'إعادة كشف بعد الإصلاح: ' || trim(p_note), _role_title(me.role) || ' — ' || (select name from orgs where id = me.org_id));
  perform _ev(a.id, 32, 'طلب إعادة الكشف الهندسي بعد الإصلاح (' || ins.code || ')', trim(p_note));
  return jsonb_build_object('ok', true, 'code', ins.code, 'company', (select name from orgs where id = ins.org_id));
end $f$;

-- ───────── 12) الصلاحيات على الدوال ─────────
revoke all on function public._eng_me(), public._eng_log(uuid, text, text), public._eng_notify_roles(uuid, text, text[], text, text, text, uuid),
  public._eng_pick_org(text), public._eng_create(uuid, text, text, text), public._eng_row(eng_inspections, profiles) from public, anon, authenticated;
revoke all on function public.eng_inbox(), public.eng_inspection(uuid), public.eng_assign(uuid, jsonb), public.eng_staff_set(uuid, jsonb), public.eng_checkin(uuid, jsonb),
  public.eng_item_set(uuid, jsonb), public.eng_photo(uuid), public.eng_finalize(uuid, jsonb), public.eng_app_report(uuid), public.eng_order_sample(uuid, text), public.eng_reinspect(uuid, text) from public, anon;
grant execute on function public.eng_inbox(), public.eng_inspection(uuid), public.eng_assign(uuid, jsonb), public.eng_staff_set(uuid, jsonb), public.eng_checkin(uuid, jsonb),
  public.eng_item_set(uuid, jsonb), public.eng_photo(uuid), public.eng_finalize(uuid, jsonb), public.eng_app_report(uuid), public.eng_order_sample(uuid, text), public.eng_reinspect(uuid, text) to authenticated;
grant execute on function public._eng_can_see(uuid, uuid) to authenticated;

-- ───────── 13) بيانات العرض: شركتان، فريق بتخصصات، أوامر للتجربة ونتائج على الخريطة ─────────
insert into public.orgs(code, type, name, meta)
select 'eaq', 'eng_audit', 'الدقة للتدقيق والفحص الهندسي', '{"governorates": [], "license": "CBI-EA-2026-014"}'::jsonb
where not exists (select 1 from public.orgs where code = 'eaq');
insert into public.orgs(code, type, name, meta)
select 'emr', 'eng_audit', 'المعيار للاستشارات الهندسية', '{"governorates": ["البصرة", "ميسان", "ذي قار"], "license": "CBI-EA-2026-021"}'::jsonb
where not exists (select 1 from public.orgs where code = 'emr');

do $$
declare r text[]; rows text[][] := array[
  ['eng.admin', 'Eng@2026ad', 'م. أسعد كامل الجبوري',   'auditor_admin',    'eaq', 'pv,electrical',      'IEU-11873'],
  ['eng.elec',  'Eng@2026el', 'م. رسل حيدر الموسوي',    'auditor_engineer', 'eaq', 'electrical',         'IEU-20451'],
  ['eng.civil', 'Eng@2026cv', 'م. علي جبار الخفاجي',    'auditor_engineer', 'eaq', 'civil',              'IEU-17206'],
  ['eng.pv',    'Eng@2026pv', 'م. نور الهدى عباس',      'auditor_engineer', 'eaq', 'pv,electrical',      'IEU-23318'],
  ['eng.vet',   'Eng@2026vt', 'م. زهراء ستار الكعبي',   'auditor_engineer', 'eaq', 'medical,production', 'IEU-24790'],
  ['emr.admin', 'Emr@2026ad', 'م. حسين ناصر البصري',    'auditor_admin',    'emr', 'pv,electrical,civil', 'IEU-09922'],
  ['emr.eng',   'Emr@2026en', 'م. مريم فؤاد العيداني',  'auditor_engineer', 'emr', 'electrical,pv,civil', 'IEU-21540']];
  i int; uid uuid;
begin
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'auditor', rows[i][5], null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    update public.profiles set manage_scope = case when rows[i][4] = 'auditor_admin' then 'org' else manage_scope end,
      managed_by = case when rows[i][4] = 'auditor_engineer' then coalesce(managed_by, (select id from public.profiles where username = case rows[i][5] when 'eaq' then 'eng.admin' else 'emr.admin' end)) else managed_by end
    where id = uid;
    insert into public.eng_staff(profile_id, specialties, license_no) values (uid, string_to_array(rows[i][6], ','), rows[i][7]) on conflict (profile_id) do nothing;
  end loop;
end $$;

-- أوامر العرض (مرة واحدة): كشفان رقابيان مفتوحان للتجربة، وكشفان منجزان يظهران على الخريطة
do $$
declare a1 uuid; a2 uuid; a3 uuid; a4 uuid; o1 uuid; o2 uuid; ins eng_inspections; x record; e_vet uuid; e_elec uuid; e_civil uuid; e_pv uuid; e_emr uuid;
begin
  if exists (select 1 from public.eng_inspections) then return; end if;
  select id into o1 from orgs where code = 'eaq'; select id into o2 from orgs where code = 'emr';
  select id into a1 from applications where code = 'ALW-2026-00013';   -- النجف، 10 kW، مكتمل
  select id into a2 from applications where code = 'VET-2026-00001';   -- النجف، عيادة بيطرية، مكتمل
  select id into a3 from applications where code = 'ALW-2026-00010';   -- بغداد، 5 kW، مكتمل
  select id into a4 from applications where code = 'ALW-2026-00012';   -- البصرة، 8 kW، مكتمل
  select id into e_vet from profiles where username = 'eng.vet'; select id into e_elec from profiles where username = 'eng.elec';
  select id into e_civil from profiles where username = 'eng.civil'; select id into e_pv from profiles where username = 'eng.pv'; select id into e_emr from profiles where username = 'emr.eng';

  -- (1) جديد لدى «الدقة» — ليجرّب المدير التوزيع
  if a1 is not null then
    update orgs set meta = meta || '{"suspended": true}' where id = o2;
    perform _eng_create(a1, 'sample', 'عيّنة رقابية شهرية — منظومات النجف', 'موظف البنك المركزي — دائرة الائتمان');
    update orgs set meta = meta - 'suspended' where id = o2;
  end if;
  -- (2) موزّع على المهندسين لدى «الدقة» — ليجرّب المهندس الزيارة والحكم
  if a2 is not null then
    update orgs set meta = meta || '{"suspended": true}' where id = o2;
    ins := _eng_create(a2, 'sample', 'التحقق من مشتريات المبادرة البيطرية — عيّنة', 'موظف البنك المركزي — دائرة الائتمان');
    update orgs set meta = meta - 'suspended' where id = o2;
    update eng_items set assignee = case spec when 'medical' then e_vet when 'production' then e_vet when 'electrical' then e_elec when 'civil' then e_civil else e_pv end, assigned_at = now()
    where inspection_id = ins.id;
    update eng_inspections set status = 'assigned' where id = ins.id;
    insert into eng_log(inspection_id, actor_name, action, note) values (ins.id, 'م. أسعد كامل الجبوري', 'توزيع آلي حسب التخصص', 'كل البنود');
  end if;
  -- (3) منجز «مطابق» — بغداد
  if a3 is not null then
    update orgs set meta = meta || '{"suspended": true}' where id = o2;
    ins := _eng_create(a3, 'sample', 'عيّنة رقابية — منظومات بغداد', 'موظف البنك المركزي — دائرة الائتمان');
    update orgs set meta = meta - 'suspended' where id = o2;
    update eng_items set assignee = case spec when 'civil' then e_civil when 'electrical' then e_elec else e_pv end, result = 'pass',
      checked_at = now() - interval '3 days', checked_by = case spec when 'civil' then e_civil when 'electrical' then e_elec else e_pv end,
      checked_by_name = case spec when 'civil' then 'م. علي جبار الخفاجي' when 'electrical' then 'م. رسل حيدر الموسوي' else 'م. نور الهدى عباس' end,
      gps = '{"lat": 33.34012, "lng": 44.40031, "acc": 9}', dist_m = 4 where inspection_id = ins.id;
    insert into eng_visits(inspection_id, engineer_id, engineer_name, lat, lng, acc, ref, at) values
      (ins.id, e_pv, 'م. نور الهدى عباس', 33.340112, 44.400287, 8.5, 'first_visit', now() - interval '3 days'),
      (ins.id, e_civil, 'م. علي جبار الخفاجي', 33.340156, 44.400341, 11.2, 'first_visit', now() - interval '3 days');
    update eng_inspections set status = 'done', result = 'conforming', first_visit_at = now() - interval '3 days', decided_at = now() - interval '2 days',
      decided_by_name = 'م. أسعد كامل الجبوري', ref_geo = '{"lat": 33.340112, "lng": 44.400287, "src": "first_visit"}',
      seal = encode(extensions.digest(ins.code || 'conforming', 'sha256'), 'hex'),
      summary = jsonb_build_object('pass', (select count(*) from eng_items where inspection_id = ins.id), 'fail', 0, 'other', 0, 'total', (select count(*) from eng_items where inspection_id = ins.id),
        'code', ins.code, 'company', 'الدقة للتدقيق والفحص الهندسي', 'engineers', '["م. نور الهدى عباس","م. علي جبار الخفاجي","م. رسل حيدر الموسوي"]'::jsonb, 'failed', '[]'::jsonb)
    where id = ins.id returning * into ins;
    update applications set audit_status = 'conforming', audit_at = ins.decided_at, audit_summary = ins.summary, audit_org = 'الدقة للتدقيق والفحص الهندسي',
      audit_geo = jsonb_build_object('lat', 33.340112, 'lng', 44.400287, 'acc', 8.5, 'at', ins.first_visit_at, 'by', 'م. نور الهدى عباس', 'code', ins.code) where id = a3;
  end if;
  -- (4) منجز «غير مطابق» — البصرة لدى «المعيار»
  if a4 is not null then
    update orgs set meta = meta || '{"suspended": true}' where id = o1;
    ins := _eng_create(a4, 'sample', 'عيّنة رقابية — منظومات البصرة', 'موظف البنك المركزي — دائرة الائتمان');
    update orgs set meta = meta - 'suspended' where id = o1;
    update eng_items set assignee = e_emr, result = case when label = 'بطاريات ليثيوم' then 'fail' else 'pass' end,
      reason = case when label = 'بطاريات ليثيوم' then 'ركّبت بطاريتان بدل ثلاث المذكورة في العرض، والسعة الفعلية 10.2 kWh بدل 15.4' end,
      checked_at = now() - interval '1 day', checked_by = e_emr, checked_by_name = 'م. مريم فؤاد العيداني', gps = '{"lat": 30.51018, "lng": 47.78022, "acc": 12}', dist_m = 6
    where inspection_id = ins.id;
    insert into eng_visits(inspection_id, engineer_id, engineer_name, lat, lng, acc, ref, at) values
      (ins.id, e_emr, 'م. مريم فؤاد العيداني', 30.510144, 47.780193, 10.4, 'first_visit', now() - interval '1 day');
    update eng_inspections set status = 'done', result = 'non_conforming', first_visit_at = now() - interval '1 day', decided_at = now() - interval '20 hours',
      decided_by_name = 'م. حسين ناصر البصري', ref_geo = '{"lat": 30.510144, "lng": 47.780193, "src": "first_visit"}',
      seal = encode(extensions.digest(ins.code || 'non_conforming', 'sha256'), 'hex'),
      summary = jsonb_build_object('pass', (select count(*) from eng_items where inspection_id = ins.id and result = 'pass'), 'fail', 1, 'other', 0,
        'total', (select count(*) from eng_items where inspection_id = ins.id), 'code', ins.code, 'company', 'المعيار للاستشارات الهندسية',
        'engineers', '["م. مريم فؤاد العيداني"]'::jsonb, 'failed', jsonb_build_array(jsonb_build_object('label', 'بطاريات ليثيوم', 'reason', 'بطاريتان بدل ثلاث')))
    where id = ins.id returning * into ins;
    update applications set audit_status = 'non_conforming', audit_at = ins.decided_at, audit_summary = ins.summary, audit_org = 'المعيار للاستشارات الهندسية',
      audit_geo = jsonb_build_object('lat', 30.510144, 'lng', 47.780193, 'acc', 10.4, 'at', ins.first_visit_at, 'by', 'م. مريم فؤاد العيداني', 'code', ins.code) where id = a4;
    insert into integrity_alerts(type, severity, title, details, application_id, entity)
    values ('eng_non_conforming', 'high', 'تقرير تدقيق هندسي «غير مطابق»', 'ALW-2026-00012 · ' || ins.code || ' · بطاريتان بدل ثلاث', a4, 'أكد للطاقة المتجددة');
  end if;
  delete from notifications where kind = 'eng_order' and ref_id in (select id from eng_inspections where status = 'done');
end $$;
