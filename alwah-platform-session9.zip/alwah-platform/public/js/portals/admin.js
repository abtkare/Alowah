// لوحة مشغّل النظام (السوبر أدمن) — قراءة شاملة، وإدارة المستخدمين والمصارف والعروض وإعدادات المنصة، وسجل إداري لكل تغيير
import {
  esc, num, iqd, mln, dt, ago, badge, statusBadge, kpi, tabs, appsTable, openApp, rpc, toast, cleanErr, modal,
  PORTALS, ROLE_LABELS, PAY_LABEL, STATUS, isVet, enrichVet
} from '../core.js';

const D = {};            // بيانات اللوحة
let X;                   // سياق البوابة
const PLATFORM_KEYS = ['platform_fee', 'inspection_fee', 'alloc_warn', 'dev_mode'];
const ORG_TYPE = { bank: 'bank', cbi: 'cbi', registry: 'registry', supplier: 'supplier', integrity: 'integrity', syndicate: 'syndicate', vetdept: 'vetdept', admin: 'platform' };
const portalOf = r => r.startsWith('bank_') ? 'bank' : { cbi_admin: 'cbi', registry_officer: 'registry', supplier_admin: 'supplier', integrity_viewer: 'integrity', syndicate_officer: 'syndicate', vetdept_officer: 'vetdept', platform_admin: 'admin' }[r];
const STAFF_ROLES = Object.keys(ROLE_LABELS).filter(r => r !== 'citizen');

export const shouldRefresh = ctx => ['over', 'apps', 'audit'].includes(ctx.adTab) && !document.querySelector('.mdl-bg');

export async function render(ctx) {
  X = ctx;
  await load();
  const { root } = ctx;
  const live = D.apps.filter(a => ['active', 'returned'].includes(a.status));
  root.innerHTML = `
    <div class="page-head"><div><h1>لوحة مشغّل النظام</h1><p>الإدارة العامة لمنصة ألواح: كل الطلبات والمدفوعات، المستخدمون وصلاحياتهم، المصارف وعمولاتها ومورّدوها المعتمدون، العروض، وإعدادات المنصة.</p></div></div>
    <div class="notice dark">🛡️ صلاحيتك إدارية تشغيلية: لا تنجز مراحل الطلبات بدل الجهات، ولا تعدّل ضوابط السياسة (من صلاحية البنك المركزي). كل تغيير تجريه يُسجَّل باسمك في السجل الإداري.</div>
    <div class="grid g4 mb">
      ${kpi('الطلبات', `<span class="num">${D.apps.length}</span>`, `${live.length} قيد المعالجة · ${D.apps.filter(a => a.status === 'completed').length} مكتمل`, true)}
      ${kpi('التمويل المنفّذ', mln(D.apps.filter(a => a.status === 'completed').reduce((s, a) => s + Number(a.amount || 0), 0)), `وقيد المعالجة ${mln(live.reduce((s, a) => s + Number(a.amount || 0), 0))}`)}
      ${kpi('المدفوعات الإلكترونية', mln(D.pays.reduce((s, p) => s + Number(p.amount || 0), 0)), `${D.pays.length} عملية · عمولة المنصة ${iqd(D.platformFees)}`)}
      ${kpi('المستخدمون', `<span class="num">${D.users.length}</span>`, `${D.users.filter(u => u.portal === 'citizen').length} مواطن · ${D.users.filter(u => u.disabled).length} موقوف`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const defs = [{ key: 'over', label: 'نظرة عامة', count: D.stuck.length }, { key: 'apps', label: 'كل الطلبات' }, { key: 'users', label: 'المستخدمون' },
    { key: 'banks', label: 'المصارف والعمولات' }, { key: 'offers', label: 'العروض والموردون' }, { key: 'settings', label: 'الإعدادات' },
    { key: 'audit', label: 'السجل الإداري' }, { key: 'health', label: 'صحة النظام' }];
  ctx.adTab = ctx.adTab || 'over';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.adTab = k; show(); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.adTab));
  show();
}

async function load() {
  const { sb } = X;
  const [apps, users, pays, terms, branches, settings, offers, tiers, audit] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    rpc(sb, 'admin_users').catch(e => { toast(cleanErr(e), 'bad'); return []; }),
    sb.from('payments').select('*').order('paid_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_terms').select('*').then(r => r.data || []),
    sb.from('branches').select('*').order('code').then(r => r.data || []),
    sb.from('settings').select('*').order('key').then(r => r.data || []),
    sb.from('supplier_offers').select('*').order('price').then(r => r.data || []),
    sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
    sb.from('admin_audit').select('*').order('id', { ascending: false }).limit(300).then(r => r.data || []),
  ]);
  await enrichVet(sb, apps).catch(() => {});
  Object.assign(D, { apps, users, pays, terms, branches, settings, offers, tiers, audit });
  X.branches = branches;
  D.platformFees = pays.reduce((s, p) => s + (p.items || []).filter(i => i.key === 'platform_fee').reduce((t, i) => t + Number(i.amount || 0), 0), 0);
  // متأخرة: طلب قيد المعالجة مكث في مرحلته أكثر من ضعف المدة المسموحة (أيام تقويمية تقريبية)
  D.stuck = apps.filter(a => ['active', 'returned'].includes(a.status) && a.stage > 5).map(a => {
    const st = X.stages.find(s => s.n === a.stage), d = (Date.now() - new Date(a.updated_at)) / 864e5;
    return { a, st, d, over: st?.sla_days > 0 && d > st.sla_days * 2 };
  }).filter(x => x.over).sort((x, y) => y.d - x.d);
}

const org = id => X.orgs.find(o => o.id === id);
const orgName = id => org(id)?.name || '—';
const brName = id => D.branches.find(b => b.id === id)?.name || '';

function show() {
  const body = X.root.querySelector('#body');
  ({ over: pageOver, apps: pageApps, users: pageUsers, banks: pageBanks, offers: pageOffers, settings: pageSettings, audit: pageAudit, health: pageHealth }[X.adTab] || pageOver)(body);
}

// شريط أفقي بسيط لتوزيع الأعداد
const bars = (rows, fmt = v => `<span class="num">${num(v)}</span>`) => {
  const max = Math.max(1, ...rows.map(r => r[1]));
  return `<div class="adm-bars">${rows.map(([l, v, c]) => `<div class="r"><span>${esc(l)}</span><span class="b"><i style="width:${(v / max * 100).toFixed(1)}%;${c ? `background:${esc(c)}` : ''}"></i></span><b>${fmt(v)}</b></div>`).join('')}</div>`;
};

// ───────── نظرة عامة ─────────
function pageOver(body) {
  const live = D.apps.filter(a => ['active', 'returned'].includes(a.status));
  const phases = [];
  X.stages.forEach(s => { if (!phases.some(p => p[0] === s.phase)) phases.push([s.phase, 0]); });
  live.forEach(a => { const ph = X.stages.find(s => s.n === a.stage)?.phase; const r = phases.find(p => p[0] === ph); if (r) r[1]++; });
  const banks = X.orgs.filter(o => o.type === 'bank').map(b => [b.name, D.apps.filter(a => (a.bank_id || a.bank_choice?.bank_id) === b.id && a.status !== 'cancelled').length, b.meta?.color]);
  const st = Object.keys(STATUS).map(k => [STATUS[k][0], D.apps.filter(a => a.status === k).length]).filter(r => r[1]);
  const gov = {}; D.apps.forEach(a => { if (a.governorate) gov[a.governorate] = (gov[a.governorate] || 0) + 1; });
  const drafts = D.apps.filter(a => ['active', 'returned'].includes(a.status) && a.stage <= 5);
  const staleDrafts = drafts.filter(a => (Date.now() - new Date(a.updated_at)) / 864e5 > 14);
  body.innerHTML = `
    <div class="grid g2 mb">
      <div class="card"><h3>الطلبات قيد المعالجة حسب الجهة</h3>${bars(phases.filter(p => p[1] || p[0] !== 'المواطن'))}</div>
      <div class="card"><h3>الطلبات حسب المصرف</h3>${bars(banks)}</div>
      <div class="card"><h3>الطلبات حسب الحالة</h3>${bars(st)}</div>
      <div class="card"><h3>أكثر المحافظات طلباً</h3>${bars(Object.entries(gov).sort((a, b) => b[1] - a[1]).slice(0, 6))}</div>
    </div>
    <div class="card mb"><h3>طلبات متأخرة عن مدتها<span class="sp"></span><span class="badge ${D.stuck.length ? 'bad' : 'ok'}">${D.stuck.length ? `<b class="num">${D.stuck.length}</b> طلب` : 'لا تأخير'}</span></h3>
      <p class="small muted" style="margin-top:0">طلب مكث في مرحلته أكثر من ضعف المدة المسموحة لها. تواصل مع الجهة الماسكة — لا تنجز المرحلة بدلها.</p>
      ${D.stuck.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الطلب</th><th>المرحلة</th><th>لدى</th><th>المصرف</th><th>مكث</th><th>المسموح</th></tr></thead><tbody>
        ${D.stuck.slice(0, 20).map(x => `<tr class="click" data-app="${x.a.id}"><td><b class="num">${esc(x.a.code)}</b><div class="small muted">${esc(x.a.citizen_name)}</div></td><td><span class="num">${x.a.stage}</span>. ${esc(x.st?.name)}</td><td class="small">${esc(x.st?.owner_label)}</td><td class="small">${esc(orgName(x.a.bank_id))}</td><td><b class="num" style="color:var(--bad)">${Math.round(x.d)}</b> يوم</td><td class="num small">${num(x.st?.sla_days)}</td></tr>`).join('')}</tbody></table></div>` : ''}</div>
    <div class="grid g2">
      <div class="card"><h3>مسودات المواطنين</h3><dl class="kv"><dt>مسودات لم تُرسل</dt><dd><b class="num">${drafts.length}</b></dd><dt>متروكة أكثر من 14 يوماً</dt><dd><b class="num">${staleDrafts.length}</b></dd></dl>
        <p class="small muted" style="margin:8px 0 0">يمكنك إلغاء المسودة المتروكة من «كل الطلبات» بسبب مكتوب. بعد الإرسال للمصرف يقرر المصرف وحده.</p></div>
      <div class="card"><h3>آخر المدفوعات</h3>${D.pays.slice(0, 6).map(p => { const a = D.apps.find(x => x.id === p.application_id);
        return `<div class="row small" style="padding:6px 0;border-bottom:1px solid var(--line)"><span class="num">${esc(a?.code || '')}</span><span class="muted">${esc(PAY_LABEL[p.method] || p.method)}</span><span class="sp"></span><b>${iqd(p.amount)}</b><span class="muted">${ago(p.paid_at)}</span></div>`; }).join('') || '<p class="muted">لا مدفوعات.</p>'}</div>
    </div>`;
  body.querySelectorAll('[data-app]').forEach(tr => tr.onclick = () => openAdminApp(D.apps.find(a => a.id === tr.dataset.app)));
}

// ───────── كل الطلبات ─────────
function openAdminApp(a) {
  if (!a) return;
  const acts = [{ label: 'تسجيل ملاحظة إدارية', kind: '', needNote: true, done: 'سُجّلت الملاحظة في سجل الطلب', run: note => rpc(X.sb, 'admin_app_action', { p_app: a.id, p_action: 'note', p_note: note }) }];
  if (a.stage <= 5 && ['active', 'returned'].includes(a.status)) acts.push({ label: 'إلغاء المسودة المتروكة', kind: 'bad', needNote: true, done: 'أُلغيت المسودة', run: note => rpc(X.sb, 'admin_app_action', { p_app: a.id, p_action: 'cancel', p_note: note }) });
  const pay = D.pays.find(p => p.application_id === a.id);
  openApp(X, a, { actions: acts, extra: `<div class="card mb"><h3>بيانات تشغيلية</h3><dl class="kv"><dt>البرنامج</dt><dd>${isVet(a) ? 'مشروع بيطري' : 'منظومة شمسية'}</dd>
    <dt>المصرف المختار</dt><dd>${esc(orgName(a.bank_id || a.bank_choice?.bank_id))}${a.bank_choice?.commission_pct != null ? ` · عمولة <span class="num">${a.bank_choice.commission_pct}%</span>` : ''}</dd>
    <dt>رقم حساب المقترض</dt><dd>${a.bank_account ? `<b class="num">${esc(a.bank_account)}</b> · ${dt(a.account_opened_at)}` : '<span class="muted">لم يُفتح بعد</span>'}</dd>
    <dt>الدفع الإلكتروني</dt><dd>${pay ? `${iqd(pay.amount)} · <span class="num">${esc(pay.ref)}</span>` : '<span class="muted">لم يُدفع</span>'}</dd><dt>آخر تحديث</dt><dd>${dt(a.updated_at)}</dd></dl></div>` });
}

function pageApps(body) {
  const f = X.adAppsF = X.adAppsF || { q: '', st: '', bank: '', prog: '' };
  body.innerHTML = `<div class="adm-filters">
      <input class="input" data-q placeholder="بحث برقم الطلب أو الاسم" value="${esc(f.q)}">
      <select class="input" data-st><option value="">كل الحالات</option>${Object.entries(STATUS).map(([k, v]) => `<option value="${k}" ${f.st === k ? 'selected' : ''}>${esc(v[0])}</option>`).join('')}<option value="draft" ${f.st === 'draft' ? 'selected' : ''}>مسودة لم تُرسل</option></select>
      <select class="input" data-bank><option value="">كل المصارف</option>${X.orgs.filter(o => o.type === 'bank').map(b => `<option value="${b.id}" ${f.bank === b.id ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select>
      <select class="input" data-prog><option value="">كل البرامج</option><option value="solar" ${f.prog === 'solar' ? 'selected' : ''}>منظومات شمسية</option><option value="vet" ${f.prog === 'vet' ? 'selected' : ''}>مشاريع بيطرية</option></select>
      <span class="sp"></span><span class="small muted" data-n></span></div><div class="card flush" data-t></div>`;
  const paint = () => {
    const q = f.q.trim().toLowerCase();
    const list = D.apps.filter(a => (!q || (a.code || '').toLowerCase().includes(q) || (a.citizen_name || '').includes(f.q.trim()))
      && (!f.st || (f.st === 'draft' ? a.stage <= 5 && ['active', 'returned'].includes(a.status) : a.status === f.st))
      && (!f.bank || (a.bank_id || a.bank_choice?.bank_id) === f.bank) && (!f.prog || (a.program || 'solar') === f.prog));
    body.querySelector('[data-n]').innerHTML = `<span class="num">${list.length}</span> طلب`;
    body.querySelector('[data-t]').innerHTML = appsTable(list.slice(0, 300), X, { onOpen: openAdminApp, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'stage', 'status', 'updated'] });
  };
  body.querySelector('[data-q]').oninput = e => { f.q = e.target.value; paint(); };
  [['st', 'st'], ['bank', 'bank'], ['prog', 'prog']].forEach(([k, a]) => body.querySelector(`[data-${a}]`).onchange = e => { f[k] = e.target.value; paint(); });
  paint();
}

// ───────── المستخدمون ─────────
function pageUsers(body) {
  const f = X.adUsersF = X.adUsersF || { q: '', portal: '', st: '' };
  body.innerHTML = `<div class="adm-filters">
      <input class="input" data-q placeholder="بحث بالاسم أو اسم الدخول أو الرمز" value="${esc(f.q)}">
      <select class="input" data-portal><option value="">كل الجهات</option>${Object.entries(PORTALS).map(([k, v]) => `<option value="${k}" ${f.portal === k ? 'selected' : ''}>${esc(v.short)}</option>`).join('')}</select>
      <select class="input" data-st><option value="">الكل</option><option value="on" ${f.st === 'on' ? 'selected' : ''}>فعّال</option><option value="off" ${f.st === 'off' ? 'selected' : ''}>موقوف</option></select>
      <span class="sp"></span><button class="btn cyan sm" data-new>＋ إضافة موظف</button></div>
    <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الاسم</th><th>الدور والجهة</th><th>الرمز الوظيفي</th><th>آخر دخول</th><th>الحالة</th><th></th></tr></thead><tbody data-t></tbody></table></div></div>
    <p class="small muted">المواطنون يسجّلون بأنفسهم من بوابة المواطن. لا تُعرض كلمات المرور لأحد — تُعاد تعيينها فقط.</p>`;
  const paint = () => {
    const q = f.q.trim().toLowerCase();
    const list = D.users.filter(u => (!q || [u.full_name, u.username, u.staff_code, u.phone].some(x => String(x || '').toLowerCase().includes(q)))
      && (!f.portal || u.portal === f.portal) && (!f.st || (f.st === 'off') === !!u.disabled));
    body.querySelector('[data-t]').innerHTML = list.slice(0, 400).map(u => `<tr>
      <td><b>${esc(u.full_name)}</b><div class="small muted num">${esc(u.username)}${u.phone && u.phone !== u.username ? ` · ${esc(u.phone)}` : ''}</div></td>
      <td class="small">${esc(ROLE_LABELS[u.role] || u.role)}<div class="muted">${esc(u.portal === 'citizen' ? (u.kyc_status === 'verified' ? 'هوية موثّقة بالسيلفي' : 'لم يوثّق هويته بعد') : orgName(u.org_id))}${u.branch_id ? ` — ${esc(brName(u.branch_id))}` : ''}</div></td>
      <td class="num small">${esc(u.staff_code || '—')}</td><td class="small muted">${u.last_sign_in_at ? ago(u.last_sign_in_at) : 'لم يدخل بعد'}</td>
      <td>${u.disabled ? badge(['موقوف', 'bad']) : badge(['فعّال', 'ok'])}</td>
      <td><div class="row" style="gap:6px">${u.portal !== 'citizen' ? `<button class="btn ghost sm" data-ed="${u.id}">تعديل</button>` : ''}<button class="btn ghost sm" data-pw="${u.id}">كلمة المرور</button>
        ${u.id === X.profile.id ? '' : `<button class="btn sm ${u.disabled ? 'ok' : 'bad'}" data-dis="${u.id}">${u.disabled ? 'تفعيل' : 'إيقاف'}</button>`}</div></td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا نتائج.</td></tr>';
    body.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => userForm(D.users.find(u => u.id === b.dataset.ed)));
    body.querySelectorAll('[data-pw]').forEach(b => b.onclick = () => resetPw(D.users.find(u => u.id === b.dataset.pw)));
    body.querySelectorAll('[data-dis]').forEach(b => b.onclick = () => toggleUser(D.users.find(u => u.id === b.dataset.dis)));
  };
  body.querySelector('[data-q]').oninput = e => { f.q = e.target.value; paint(); };
  body.querySelector('[data-portal]').onchange = e => { f.portal = e.target.value; paint(); };
  body.querySelector('[data-st]').onchange = e => { f.st = e.target.value; paint(); };
  body.querySelector('[data-new]').onclick = () => userForm(null);
  paint();
}

const genPw = () => { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz'; let s = ''; for (let i = 0; i < 6; i++) s += c[Math.floor(Math.random() * c.length)]; return s + '@' + (1000 + Math.floor(Math.random() * 9000)); };
const reload = async () => { await load(); show(); };

function userForm(u) {
  const isNew = !u;
  const m = modal(`<h3>${isNew ? 'إضافة موظف جديد' : `تعديل ${esc(u.full_name)}`}</h3>
    <div class="grid g2" style="gap:12px">
      ${isNew ? `<div class="field"><label>اسم الدخول (إنجليزي)</label><input class="input" data-k="username" dir="ltr" placeholder="مثال: snb.cs3"></div>` : ''}
      <div class="field"><label>الاسم والمسمى الوظيفي</label><input class="input" data-k="full_name" value="${esc(u?.full_name || '')}"></div>
      <div class="field"><label>الدور</label><select class="input" data-k="role">${STAFF_ROLES.map(r => `<option value="${r}" ${u?.role === r ? 'selected' : ''}>${esc(ROLE_LABELS[r])}</option>`).join('')}</select></div>
      <div class="field"><label>الجهة</label><select class="input" data-k="org_id"></select></div>
      <div class="field" data-brw><label>الفرع (للمصرف — فارغ = الإدارة العامة)</label><select class="input" data-k="branch_id"></select></div>
      <div class="field"><label>الهاتف (اختياري)</label><input class="input" data-k="phone" dir="ltr" inputmode="tel" value="${esc(u?.phone || '')}" placeholder="07XXXXXXXXX"></div>
      ${isNew ? `<div class="field"><label>كلمة المرور الأولى</label><div class="row" style="gap:6px"><input class="input" data-k="password" dir="ltr" value="${genPw()}"><button type="button" class="btn ghost sm" data-gen>توليد</button></div></div>` : ''}
    </div>
    <p class="small muted">أعطِ الموظف كلمة المرور الأولى بقناة آمنة. يظهر له منصبه ورمزه الوظيفي تلقائياً في كل إجراء يوقّعه.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>${isNew ? 'إنشاء الحساب' : 'حفظ'}</button></div>`, { wide: true });
  const $ = k => m.el.querySelector(`[data-k=${k}]`);
  const fillOrgs = () => {
    const p = portalOf($('role').value), t = ORG_TYPE[p];
    const os = X.orgs.filter(o => o.type === t);
    $('org_id').innerHTML = os.map(o => `<option value="${o.id}" ${o.id === u?.org_id ? 'selected' : ''}>${esc(o.name)}</option>`).join('');
    fillBr();
  };
  const fillBr = () => {
    const bank = portalOf($('role').value) === 'bank';
    m.el.querySelector('[data-brw]').hidden = !bank;
    $('branch_id').innerHTML = '<option value="">الإدارة العامة / بلا فرع</option>' + (bank ? D.branches.filter(b => b.bank_id === $('org_id').value).map(b => `<option value="${b.id}" ${b.id === u?.branch_id ? 'selected' : ''}>${esc(b.name)}</option>`).join('') : '');
  };
  $('role').onchange = fillOrgs; $('org_id').onchange = fillBr; fillOrgs();
  const g = m.el.querySelector('[data-gen]'); if (g) g.onclick = () => { $('password').value = genPw(); };
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const d = {}; m.el.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    if (portalOf(d.role) !== 'bank') d.branch_id = '';
    e.target.disabled = true;
    try {
      if (isNew) {
        const pw = d.password;
        await rpc(X.sb, 'admin_create_user', { p: d }); m.close(); await reload();
        credsCard(d.username, pw, portalOf(d.role));
      } else { await rpc(X.sb, 'admin_update_user', { p_user: u.id, p: d }); m.close(); toast('حُفظت التغييرات', 'ok'); await reload(); }
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// بيانات الدخول: الرابط واسم المستخدم وكلمة المرور كلٌّ في مربع نسخ منفرد
function credsCard(user, pw, portal) {
  const link = `${location.origin}/${portal}`;
  const box = (l, v) => `<div class="field"><label>${l}</label><div class="row" style="gap:6px"><input class="input" dir="ltr" readonly value="${esc(v)}"><button type="button" class="btn ghost sm" data-copy="${esc(v)}">نسخ</button></div></div>`;
  const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h3>أُنشئ الحساب</h3></div>${box('الرابط', link)}${box('اسم المستخدم', user)}${box('كلمة المرور', pw)}
    <p class="small muted">هذه آخر مرة تظهر فيها كلمة المرور — انسخها الآن.</p><div class="row"><span class="sp"></span><button class="btn cyan" data-x>تم</button></div>`);
  m.el.querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); toast('نُسخ', 'ok'); } catch { b.previousElementSibling.select(); } });
  m.el.querySelector('[data-x]').onclick = m.close;
}

function resetPw(u) {
  const pw = genPw();
  const m = modal(`<h3>إعادة تعيين كلمة مرور ${esc(u.full_name)}</h3><p class="muted small">تُلغى كلمة المرور الحالية فوراً. ${u.portal === 'citizen' ? 'المواطن يستطيع أيضاً استعادتها بنفسه برمز يصل هاتفه.' : ''}</p>
    <div class="field"><label>كلمة المرور الجديدة</label><input class="input" data-pw dir="ltr" value="${pw}"></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>تعيين</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const v = m.el.querySelector('[data-pw]').value.trim(); e.target.disabled = true;
    try { await rpc(X.sb, 'admin_set_password', { p_user: u.id, p_new: v }); m.close(); credsCard(u.username, v, u.portal); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

function toggleUser(u) {
  const off = !u.disabled;
  const m = modal(`<h3>${off ? 'إيقاف' : 'تفعيل'} حساب ${esc(u.full_name)}</h3><p class="muted">${off ? 'يُمنع من الدخول فوراً وتُغلق جلساته المفتوحة. إجراءاته السابقة تبقى في السجلات كما هي.' : 'يعود قادراً على الدخول بكلمة مروره.'}</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn ${off ? 'bad' : 'ok'}" data-s>${off ? 'إيقاف الحساب' : 'تفعيل الحساب'}</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    e.target.disabled = true;
    try { await rpc(X.sb, 'admin_set_disabled', { p_user: u.id, p_disabled: off }); m.close(); toast(off ? 'أُوقف الحساب' : 'فُعّل الحساب', 'ok'); await reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── المصارف: الشروط والعمولة والموردون المعتمدون ─────────
function pageBanks(body) {
  const sups = X.orgs.filter(o => o.type === 'supplier');
  const banks = X.orgs.filter(o => o.type === 'bank');
  body.innerHTML = `<div class="notice"><span>ℹ</span><span>تظهر هذه الشروط للمواطن عند اختيار المصرف، ويُحسب منها القسط والعمولة. <b>الموردون المعتمدون</b>: إن لم تحدد أحداً يتعامل المصرف مع كل الموردين؛ وإن حددت، لا يرى المواطن لدى هذا المصرف إلا منظوماتهم. عوائد المصرف لا تتجاوز سقف السياسة (<span class="num">${num(D.settings.find(s => s.key === 'margin_max')?.value)}%</span>).</span></div>
    <div class="adm-bank">${banks.map(b => { const t = D.terms.find(x => x.bank_id === b.id) || {}, apps = D.apps.filter(a => (a.bank_id || a.bank_choice?.bank_id) === b.id && a.status !== 'cancelled');
      const staff = D.users.filter(u => u.org_id === b.id), sel = t.suppliers || [];
      return `<form class="card" data-bank="${b.id}" novalidate>
        <h3><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i> ${esc(b.name)}<span class="sp"></span>
          <label class="check" style="margin:0"><input type="checkbox" name="accepting" ${b.meta?.accepting !== false ? 'checked' : ''}> يستقبل طلبات عبر المنصة</label></h3>
        <div class="grid g3" style="gap:12px">
          <div class="field"><label>عمولة المصرف %</label><input class="input" name="commission_pct" inputmode="decimal" dir="ltr" value="${esc(t.commission_pct ?? '')}"></div>
          <div class="field"><label>${b.is_islamic ? 'نسبة الربح السنوية %' : 'العوائد السنوية %'}</label><input class="input" name="margin" inputmode="decimal" dir="ltr" value="${esc(t.margin ?? '')}"></div>
          <div class="field"><label>رسم دراسة الملف (د.ع)</label><input class="input" name="file_fee" inputmode="numeric" dir="ltr" value="${esc(t.file_fee ?? '')}"></div>
          <div class="field"><label>أقصى مدة (شهر)</label><input class="input" name="max_term_months" inputmode="numeric" dir="ltr" value="${esc(t.max_term_months ?? '')}"></div>
          <div class="field"><label>مدة الدراسة (أيام عمل)</label><input class="input" name="processing_days" inputmode="numeric" dir="ltr" value="${esc(t.processing_days ?? '')}"></div>
          <div class="field"><label>سقف موافقة الفرع (د.ع)</label><input class="input" name="single_approval_cap" inputmode="numeric" dir="ltr" value="${esc(t.single_approval_cap ?? '')}"></div>
        </div>
        <div class="field"><label>الموردون المعتمدون لدى المصرف ${sel.length ? '' : '<span class="badge muted">كل الموردين</span>'}</label>
          <div class="adm-sup">${sups.map(s => `<label class="${sel.includes(s.id) ? 'on' : ''}"><input type="checkbox" name="sup" value="${s.id}" ${sel.includes(s.id) ? 'checked' : ''}>${esc(s.name)}${s.meta?.kind === 'vet' ? ' <span class="badge info">بيطري</span>' : ''}</label>`).join('')}</div></div>
        <div class="row small muted" style="flex-wrap:wrap;gap:12px"><span>الطلبات: <b class="num">${apps.length}</b></span><span>قيد المعالجة: <b class="num">${apps.filter(a => ['active', 'returned'].includes(a.status)).length}</b></span><span>مكتملة: <b class="num">${apps.filter(a => a.status === 'completed').length}</b></span>
          <span>الفروع: <b class="num">${D.branches.filter(x => x.bank_id === b.id).length}</b></span><span>الموظفون: <b class="num">${staff.length}</b></span><span class="sp"></span><button class="btn cyan sm">حفظ شروط المصرف</button></div>
      </form>`; }).join('')}</div>`;
  body.querySelectorAll('.adm-sup input').forEach(i => i.onchange = () => i.closest('label').classList.toggle('on', i.checked));
  body.querySelectorAll('[data-bank]').forEach(f => f.onsubmit = async e => {
    e.preventDefault();
    const n = k => { const v = String(f[k].value).trim().replace(/,/g, ''); return v === '' ? null : Number(v); };
    const p = { accepting: f.accepting.checked, suppliers: [...f.querySelectorAll('[name=sup]:checked')].map(i => i.value) };
    ['commission_pct', 'margin', 'file_fee', 'max_term_months', 'processing_days', 'single_approval_cap'].forEach(k => { const v = n(k); if (v != null && !Number.isNaN(v)) p[k] = v; });
    const b = f.querySelector('button'); b.disabled = true;
    try {
      await rpc(X.sb, 'admin_set_bank', { p_bank: f.dataset.bank, p });
      const o = X.orgs.find(x => x.id === f.dataset.bank); if (o) o.meta = { ...(o.meta || {}), accepting: p.accepting };
      toast('حُفظت شروط المصرف', 'ok'); await reload();
    } catch (er) { toast(cleanErr(er), 'bad'); b.disabled = false; }
  });
}

// ───────── العروض والموردون ─────────
function pageOffers(body) {
  const f = X.adOffF = X.adOffF || { sup: '' };
  const sups = X.orgs.filter(o => o.type === 'supplier');
  body.innerHTML = `<div class="adm-filters"><select class="input" data-sup><option value="">كل الموردين</option>${sups.map(s => `<option value="${s.id}" ${f.sup === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>
    <span class="sp"></span><span class="small muted">الموقوف لا يظهر في الكتالوج ولا يمكن بدء طلب عليه — الطلبات القائمة لا تتأثر.</span></div>
    <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>العرض</th><th>المورد</th><th>القدرة</th><th>السعر</th><th>الطلبات</th><th>الحالة</th><th></th></tr></thead><tbody>
    ${D.offers.filter(o => !f.sup || o.supplier_id === f.sup).map(o => { const t = D.tiers.find(x => x.id === o.tier_id), n = D.apps.filter(a => a.offer_id === o.id).length;
      return `<tr><td><div class="row" style="gap:8px">${o.image_url ? `<img src="${esc(o.image_url)}" alt="" style="width:46px;height:34px;object-fit:cover;border-radius:6px">` : ''}<b class="small">${esc(o.title)}</b></div></td>
      <td class="small">${esc(orgName(o.supplier_id))}</td><td class="num">${t ? `${num(t.kw)} kW` : '—'}</td><td>${iqd(o.price)}${t && o.price > t.price_cap ? ' <span class="badge bad">فوق سقف الفئة</span>' : ''}</td><td class="num">${n}</td>
      <td>${o.status === 'published' ? badge(['منشور', 'ok']) : badge([o.status === 'suspended' ? 'موقوف' : o.status, 'muted'])}</td>
      <td><button class="btn sm ${o.status === 'published' ? 'bad' : 'ok'}" data-off="${o.id}" data-to="${o.status === 'published' ? 'suspended' : 'published'}">${o.status === 'published' ? 'إيقاف' : 'نشر'}</button></td></tr>`; }).join('') || '<tr><td colspan="7" class="empty">لا عروض.</td></tr>'}</tbody></table></div></div>`;
  body.querySelector('[data-sup]').onchange = e => { f.sup = e.target.value; pageOffers(body); };
  body.querySelectorAll('[data-off]').forEach(b => b.onclick = async () => {
    b.disabled = true;
    try { await rpc(X.sb, 'admin_set_offer_status', { p_offer: b.dataset.off, p_status: b.dataset.to }); toast(b.dataset.to === 'published' ? 'نُشر العرض' : 'أُوقف العرض', 'ok'); await reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); b.disabled = false; }
  });
}

// ───────── الإعدادات ─────────
function pageSettings(body) {
  const mine = D.settings.filter(s => PLATFORM_KEYS.includes(s.key)), policy = D.settings.filter(s => !PLATFORM_KEYS.includes(s.key));
  body.innerHTML = `<div class="grid g-side">
    <div class="card"><h3>إعدادات المنصة</h3>
      ${mine.map(s => s.key === 'dev_mode' ? `<div class="field"><label>${esc(s.label)}</label><div class="row"><span class="badge ${Number(s.value) ? 'warn' : 'ok'}">${Number(s.value) ? 'مفعّل — رمز التحقق ثابت 1234' : 'متوقف — رموز حقيقية'}</span><span class="sp"></span><button class="btn sm ${Number(s.value) ? 'ok' : 'warn'}" data-dev="${Number(s.value) ? 0 : 1}">${Number(s.value) ? 'إيقاف وضع المطور' : 'تفعيل وضع المطور'}</button></div>
          <small class="muted">قبل الإطلاق الفعلي يجب إيقافه وربط مزوّد الرسائل النصية.</small></div>`
        : `<form class="field" data-set="${s.key}"><label>${esc(s.label)}</label><div class="row" style="gap:6px"><input class="input" name="v" inputmode="numeric" dir="ltr" value="${esc(s.value)}"><button class="btn sm">حفظ</button></div></form>`).join('')}
    </div>
    <div class="card"><h3>ضوابط السياسة<span class="sp"></span><span class="badge muted">يعدّلها البنك المركزي</span></h3>
      <div class="tbl-wrap"><table class="tbl"><tbody>${policy.map(s => `<tr><td class="small">${esc(s.label)}${s.circular_no ? `<div class="muted">${esc(s.circular_no)}</div>` : ''}</td><td class="num"><b>${num(s.value)}</b></td></tr>`).join('')}</tbody></table></div></div>
  </div>`;
  body.querySelectorAll('[data-set]').forEach(f => f.onsubmit = async e => {
    e.preventDefault(); const v = Number(String(f.v.value).replace(/,/g, ''));
    if (Number.isNaN(v)) return toast('قيمة غير صحيحة', 'bad');
    try { await rpc(X.sb, 'admin_set_setting', { p_key: f.dataset.set, p_value: v }); toast('حُفظ الإعداد', 'ok'); await reload(); } catch (er) { toast(cleanErr(er), 'bad'); }
  });
  const dv = body.querySelector('[data-dev]');
  if (dv) dv.onclick = async () => {
    try { await rpc(X.sb, 'admin_set_setting', { p_key: 'dev_mode', p_value: Number(dv.dataset.dev) }); toast('حُفظ — يسري على الشاشات بعد إعادة تحميلها', 'ok'); await reload(); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
}

// ───────── السجل الإداري ─────────
function pageAudit(body) {
  body.innerHTML = `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الوقت</th><th>المنفّذ</th><th>الإجراء</th><th>على</th><th>التفاصيل</th></tr></thead><tbody>
    ${D.audit.map(a => `<tr><td class="small muted">${dt(a.created_at)}</td><td class="small">${esc(a.actor_name || '')}</td><td><b class="small">${esc(a.action)}</b></td><td class="small num">${esc(a.target || '')}</td>
      <td class="small muted" style="max-width:340px;word-break:break-word">${a.details ? esc(Object.entries(a.details).map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · ')) : ''}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">لا إجراءات إدارية بعد.</td></tr>'}
    </tbody></table></div></div>`;
}

// ───────── صحة النظام ─────────
async function pageHealth(body) {
  const cfg = window.ALWAH_CONFIG || {};
  const dev = Number(D.settings.find(s => s.key === 'dev_mode')?.value);
  body.innerHTML = `<div class="grid g2"><div class="card"><h3>الخدمات</h3><ul class="adm-health">
      <li><span data-h="web">…</span><span>خادم المنصة (Render)</span></li>
      <li><span data-h="db">…</span><span>قاعدة البيانات (Supabase)</span></li>
      <li><span data-h="ocr">…</span><span>خدمة قراءة البطاقة الوطنية</span></li>
      <li><span>${dev ? badge(['تنبيه', 'warn']) : badge(['سليم', 'ok'])}</span><span>${dev ? 'وضع المطور مفعّل (رمز التحقق 1234)' : 'رموز التحقق حقيقية'}</span></li></ul>
      <div class="row mt"><a class="btn ghost sm" href="/migrate" target="_blank" rel="noopener">حالة تحديث قاعدة البيانات</a></div></div>
    <div class="card"><h3>البيانات</h3><dl class="kv">
      <dt>الطلبات</dt><dd class="num">${num(D.apps.length)}</dd><dt>المستخدمون</dt><dd class="num">${num(D.users.length)}</dd><dt>المدفوعات</dt><dd class="num">${num(D.pays.length)}</dd>
      <dt>العروض المنشورة</dt><dd class="num">${num(D.offers.filter(o => o.status === 'published').length)}</dd><dt>الفروع</dt><dd class="num">${num(D.branches.length)}</dd>
      <dt>حسابات لم تدخل أبداً</dt><dd class="num">${num(D.users.filter(u => !u.last_sign_in_at && u.portal !== 'citizen').length)}</dd></dl></div></div>`;
  const set = (k, ok, t) => { const e = body.querySelector(`[data-h=${k}]`); if (e) e.innerHTML = badge([t || (ok ? 'يعمل' : 'لا يستجيب'), ok ? 'ok' : 'bad']); };
  const timed = (u, ms = 8000) => { const c = new AbortController(); const t = setTimeout(() => c.abort(), ms); return fetch(u, { signal: c.signal, cache: 'no-store' }).finally(() => clearTimeout(t)); };
  timed('/healthz').then(r => set('web', r.ok)).catch(() => set('web', false));
  X.sb.from('settings').select('key', { head: true, count: 'exact' }).then(r => set('db', !r.error)).catch(() => set('db', false));
  const ocr = (cfg.ocr || '').replace(/\/+$/, '');
  if (!ocr) set('ocr', false, 'غير مربوطة');
  else { const c = new AbortController(), t = setTimeout(() => c.abort(), 10000); fetch(ocr + '/', { mode: 'no-cors', signal: c.signal, cache: 'no-store' }).then(() => set('ocr', true)).catch(() => set('ocr', false)).finally(() => clearTimeout(t)); }
}
