-- ألواح — الجلسة 9: ربط بوابة المواطن بالمصرف المختار، رقم الحساب عند فتحه، ولوحة مشغّل النظام (السوبر أدمن)
-- معاملة واحدة، يُعاد تشغيلها بأمان.
begin;

-- ═══ 1) دور مشغّل النظام ═══
create or replace function public._role_abbr(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'platform_admin' then 'SA' else 'XX' end $$;
create or replace function public._role_title(r text) returns text language sql immutable as $$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $$;

-- ═══ 2) أعمدة وجداول جديدة ═══
alter table public.profiles add column if not exists disabled boolean not null default false;
alter table public.applications add column if not exists bank_account text;
alter table public.applications add column if not exists account_opened_at timestamptz;
-- الموردون المعتمدون لدى كل مصرف: فارغ = كل الموردين
alter table public.bank_terms add column if not exists suppliers uuid[];

create or replace function public._is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'platform_admin' and portal = 'admin' and not coalesce(disabled, false))
$$;

create table if not exists public.admin_audit (
  id bigserial primary key, actor_id uuid, actor_name text, action text not null, target text, details jsonb, created_at timestamptz not null default now()
);
alter table public.admin_audit enable row level security;
drop policy if exists read_admin_audit on public.admin_audit;
create policy read_admin_audit on public.admin_audit for select using (my_portal() = 'admin');

create or replace function public._audit(p_action text, p_target text, p_details jsonb default null) returns void
language sql security definer set search_path = public as $$
  insert into admin_audit(actor_id, actor_name, action, target, details)
  values (auth.uid(), (select full_name from profiles where id = auth.uid()), p_action, p_target, p_details)
$$;

-- ═══ 3) قراءة شاملة لمشغّل النظام على كل الجداول (سياسة إضافية لا تمس صلاحيات الجهات) ═══
do $$ declare t text;
begin
  for t in select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
           where n.nspname = 'public' and c.relkind = 'r' and c.relname <> 'admin_audit' loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists admin_read_all on public.%I', t);
    execute format('create policy admin_read_all on public.%I for select using (my_portal() = ''admin'')', t);
  end loop;
end $$;

-- ═══ 4) رقم الحساب المصرفي للمقترض: يُولَّد عند إنجاز المرحلة 7 (فتح الحساب والامتثال) ═══
create sequence if not exists public.bank_account_seq start 100001;
create or replace function public._open_account() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.stage > 7 and old.stage <= 7 and new.bank_id is not null and new.bank_account is null then
    new.bank_account := coalesce((select code from branches where id = new.branch_id), upper((select code from orgs where id = new.bank_id))) || '-' || lpad(nextval('bank_account_seq')::text, 8, '0');
    new.account_opened_at := now();
  end if;
  return new;
end $$;
drop trigger if exists trg_open_account on public.applications;
create trigger trg_open_account before update of stage on public.applications for each row execute function public._open_account();
-- الطلبات التي تجاوزت المرحلة 7 قبل هذا التحديث
update public.applications a set
  bank_account = coalesce((select b.code from branches b where b.id = a.branch_id), upper(o.code)) || '-' || lpad(nextval('bank_account_seq')::text, 8, '0'),
  account_opened_at = coalesce((select max(l.finished_at) from stage_log l where l.application_id = a.id and l.stage = 7), a.updated_at)
from orgs o where o.id = a.bank_id and a.stage > 7 and a.bank_account is null;

-- ═══ 5) المصرف يعمل مع موردين معتمدين: فحص نهائي عند حفظ الطلب قبل الإرسال ═══
create or replace function public._bank_accepts_supplier(p_bank uuid, p_supplier uuid) returns boolean language sql stable security definer set search_path = public as $$
  select p_bank is null or p_supplier is null or coalesce((select coalesce(cardinality(suppliers), 0) = 0 or p_supplier = any(suppliers) from bank_terms where bank_id = p_bank), true)
$$;
create or replace function public._check_bank_supplier() returns trigger language plpgsql security definer set search_path = public as $$
declare a applications; b uuid;
begin
  select * into a from applications where id = new.id;
  if a is null or a.stage > 6 or a.status not in ('active', 'returned') then return null; end if;
  b := coalesce((a.bank_choice->>'bank_id')::uuid, a.bank_id);
  if not _bank_accepts_supplier(b, a.supplier_id) then
    raise exception '% لا يتعامل حالياً مع المورد % — اختر منظومة من مورد معتمد لديه أو مصرفاً آخر',
      (select name from orgs where id = b), (select name from orgs where id = a.supplier_id);
  end if;
  return null;
end $$;
drop trigger if exists trg_check_bank_supplier on public.applications;
create constraint trigger trg_check_bank_supplier after insert or update of bank_choice, bank_id, supplier_id on public.applications
  deferrable initially deferred for each row execute function public._check_bank_supplier();

-- ═══ 6) بدء الطلب من المصرف المختار: المصرف أولاً ثم منظومة من مورد معتمد لديه ═══
create or replace function public.start_application_bank(p_offer uuid, p_bank uuid, p_term int, p_governorate text, p_city text default null,
  p_lat numeric default null, p_lng numeric default null) returns public.applications
language plpgsql security definer set search_path = public as $$
declare a applications; bt bank_terms; o supplier_offers; v_term int;
begin
  select * into bt from bank_terms where bank_id = p_bank;
  if bt is null then raise exception 'اختر مصرفاً من القائمة'; end if;
  if exists (select 1 from orgs where id = p_bank and coalesce((meta->>'accepting')::boolean, true) = false) then raise exception 'هذا المصرف لا يستقبل طلبات عبر المنصة حالياً'; end if;
  select * into o from supplier_offers where id = p_offer and status = 'published';
  if o is null then raise exception 'العرض غير متاح'; end if;
  if not _bank_accepts_supplier(p_bank, o.supplier_id) then raise exception 'المصرف المختار لا يتعامل مع مورد هذه المنظومة'; end if;
  v_term := coalesce(p_term, 60);
  if v_term < 12 or v_term > least(bt.max_term_months, _setting('term_max_months')::int) then
    raise exception 'مدة السداد بين 12 و% شهراً لدى هذا المصرف', least(bt.max_term_months, _setting('term_max_months')::int); end if;
  a := start_application(p_offer, p_governorate, p_city, p_lat, p_lng);
  update applications set bank_choice = jsonb_build_object('bank_id', bt.bank_id, 'term_months', v_term, 'commission_pct', bt.commission_pct, 'at', now()),
    term_months = v_term where id = a.id returning * into a;
  perform _ev(a.id, 1, 'اختيار المصرف ومدة السداد عند بدء الطلب', (select name from orgs where id = bt.bank_id) || ' · ' || v_term || ' شهراً · عمولة ' || bt.commission_pct::float8 || '%');
  return a;
end $$;

-- ═══ 7) دوال مشغّل النظام ═══
create or replace function public._portal_of_role(r text) returns text language sql immutable as $$
  select case when r like 'bank\_%' then 'bank' when r = 'cbi_admin' then 'cbi' when r = 'registry_officer' then 'registry'
    when r = 'supplier_admin' then 'supplier' when r = 'integrity_viewer' then 'integrity' when r = 'syndicate_officer' then 'syndicate'
    when r = 'vetdept_officer' then 'vetdept' when r = 'platform_admin' then 'admin' when r = 'citizen' then 'citizen' end $$;
create or replace function public._org_type_of_portal(p text) returns text language sql immutable as $$
  select case p when 'bank' then 'bank' when 'cbi' then 'cbi' when 'registry' then 'registry' when 'supplier' then 'supplier'
    when 'integrity' then 'integrity' when 'syndicate' then 'syndicate' when 'vetdept' then 'vetdept' when 'admin' then 'platform' end $$;

-- قائمة المستخدمين مع آخر دخول وحالة الحساب
create or replace function public.admin_users() returns table (id uuid, username text, full_name text, role text, portal text, org_id uuid, branch_id uuid,
  phone text, staff_code text, position_title text, disabled boolean, created_at timestamptz, last_sign_in_at timestamptz, national_id text, kyc_status text)
language plpgsql stable security definer set search_path = public, auth as $$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return query select p.id, p.username, p.full_name, p.role, p.portal, p.org_id, p.branch_id, p.phone, p.staff_code, p.position_title,
    coalesce(p.disabled, false), p.created_at, u.last_sign_in_at, p.national_id, p.kyc_status
  from profiles p left join auth.users u on u.id = p.id order by p.portal, p.username;
end $$;

create or replace function public.admin_create_user(p jsonb) returns public.profiles
language plpgsql security definer set search_path = public, auth, extensions as $$
declare v_user text := lower(trim(coalesce(p->>'username', ''))); v_role text := p->>'role'; v_portal text; v_org orgs; v_br branches; uid uuid; pr profiles;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم مستخدم مسبقاً'; end if;
  if length(coalesce(p->>'password', '')) < 8 then raise exception 'كلمة المرور 8 أحرف على الأقل'; end if;
  if length(trim(coalesce(p->>'full_name', ''))) < 3 then raise exception 'اكتب الاسم أو المسمى الوظيفي'; end if;
  v_portal := _portal_of_role(v_role);
  if v_portal is null or v_portal = 'citizen' then raise exception 'اختر دوراً وظيفياً صحيحاً (المواطن يسجّل بنفسه من بوابة المواطن)'; end if;
  select * into v_org from orgs where id = nullif(p->>'org_id', '')::uuid;
  if v_org is null or v_org.type <> _org_type_of_portal(v_portal) then raise exception 'اختر الجهة المناسبة لهذا الدور'; end if;
  if nullif(p->>'branch_id', '') is not null then
    select * into v_br from branches where id = (p->>'branch_id')::uuid;
    if v_br is null or v_br.bank_id <> v_org.id then raise exception 'الفرع لا يتبع هذا المصرف'; end if;
  end if;
  uid := _mk_user(v_user, p->>'password', trim(p->>'full_name'), v_role, v_portal, v_org.code, nullif(_norm_phone(p->>'phone'), ''), null);
  update profiles set branch_id = v_br.id where id = uid returning * into pr;
  perform _audit('إنشاء مستخدم', v_user, jsonb_build_object('role', v_role, 'org', v_org.name, 'branch', v_br.name));
  return pr;
end $$;

create or replace function public.admin_update_user(p_user uuid, p jsonb) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare pr profiles; v_role text; v_portal text; v_org orgs; v_br uuid;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into pr from profiles where id = p_user;
  if pr is null then raise exception 'المستخدم غير موجود'; end if;
  if pr.portal = 'citizen' and (p ? 'role' or p ? 'org_id') then raise exception 'لا يُغيَّر دور المواطن'; end if;
  v_role := coalesce(nullif(p->>'role', ''), pr.role);
  v_portal := _portal_of_role(v_role);
  if pr.portal <> 'citizen' and (v_portal is null or v_portal = 'citizen') then raise exception 'دور غير صحيح'; end if;
  if pr.id = auth.uid() and v_role <> 'platform_admin' then raise exception 'لا يمكنك سحب صلاحية مشغّل النظام من حسابك'; end if;
  select * into v_org from orgs where id = coalesce(nullif(p->>'org_id', '')::uuid, pr.org_id);
  if pr.portal <> 'citizen' and (v_org is null or v_org.type <> _org_type_of_portal(v_portal)) then raise exception 'الجهة لا تناسب هذا الدور'; end if;
  v_br := case when p ? 'branch_id' then nullif(p->>'branch_id', '')::uuid else pr.branch_id end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = v_org.id) then v_br := null; end if;
  update profiles set full_name = coalesce(nullif(trim(p->>'full_name'), ''), full_name), role = v_role, portal = coalesce(v_portal, portal),
    org_id = case when portal = 'citizen' then org_id else v_org.id end, branch_id = v_br,
    phone = case when p ? 'phone' then nullif(_norm_phone(p->>'phone'), '') else phone end, updated_at = now()
  where id = p_user returning * into pr;
  perform _audit('تعديل مستخدم', pr.username, p - 'password');
  return pr;
end $$;

create or replace function public.admin_set_password(p_user uuid, p_new text) returns boolean
language plpgsql security definer set search_path = public, auth, extensions as $$
declare un text;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if length(coalesce(p_new, '')) < 8 or p_new !~ '[0-9]' or p_new !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  select username into un from profiles where id = p_user;
  if un is null then raise exception 'المستخدم غير موجود'; end if;
  update auth.users set encrypted_password = crypt(p_new, gen_salt('bf')), updated_at = now() where id = p_user;
  perform _audit('إعادة تعيين كلمة المرور', un, null);
  return true;
end $$;

create or replace function public.admin_set_disabled(p_user uuid, p_disabled boolean) returns boolean
language plpgsql security definer set search_path = public, auth as $$
declare un text;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if p_user = auth.uid() then raise exception 'لا يمكنك إيقاف حسابك'; end if;
  update profiles set disabled = p_disabled, updated_at = now() where id = p_user returning username into un;
  if un is null then raise exception 'المستخدم غير موجود'; end if;
  update auth.users set banned_until = case when p_disabled then 'infinity'::timestamptz else null end where id = p_user;
  if p_disabled then begin delete from auth.sessions where user_id = p_user; exception when others then null; end; end if;
  perform _audit(case when p_disabled then 'إيقاف حساب' else 'تفعيل حساب' end, un, null);
  return true;
end $$;

create or replace function public.admin_set_bank(p_bank uuid, p jsonb) returns public.bank_terms
language plpgsql security definer set search_path = public as $$
declare bt bank_terms; v_sup uuid[];
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into bt from bank_terms where bank_id = p_bank;
  if bt is null then raise exception 'المصرف غير موجود'; end if;
  if p ? 'margin' and ((p->>'margin')::numeric < 0 or (p->>'margin')::numeric > _setting('margin_max')) then raise exception 'عوائد المصرف بين 0 و% بالمئة حسب سياسة التمويل', _setting('margin_max'); end if;
  if p ? 'commission_pct' and ((p->>'commission_pct')::numeric < 0 or (p->>'commission_pct')::numeric > 5) then raise exception 'عمولة المصرف بين 0 و5 بالمئة'; end if;
  if p ? 'max_term_months' and ((p->>'max_term_months')::int < 12 or (p->>'max_term_months')::int > 120) then raise exception 'أقصى مدة بين 12 و120 شهراً'; end if;
  if p ? 'file_fee' and (p->>'file_fee')::bigint < 0 then raise exception 'رسم الملف غير صحيح'; end if;
  if p ? 'suppliers' then
    select coalesce(array_agg(x::uuid), '{}') into v_sup from jsonb_array_elements_text(coalesce(p->'suppliers', '[]'::jsonb)) x;
    if exists (select 1 from unnest(v_sup) s where not exists (select 1 from orgs where id = s and type = 'supplier')) then raise exception 'مورد غير معروف'; end if;
  end if;
  update bank_terms set margin = coalesce((p->>'margin')::numeric, margin), commission_pct = coalesce((p->>'commission_pct')::numeric, commission_pct),
    file_fee = coalesce((p->>'file_fee')::bigint, file_fee), max_term_months = coalesce((p->>'max_term_months')::int, max_term_months),
    processing_days = coalesce((p->>'processing_days')::int, processing_days), single_approval_cap = coalesce((p->>'single_approval_cap')::bigint, single_approval_cap),
    suppliers = case when p ? 'suppliers' then nullif(v_sup, '{}') else suppliers end
  where bank_id = p_bank returning * into bt;
  if p ? 'accepting' then update orgs set meta = coalesce(meta, '{}') || jsonb_build_object('accepting', (p->>'accepting')::boolean) where id = p_bank; end if;
  perform _audit('تعديل شروط مصرف', (select name from orgs where id = p_bank), p);
  return bt;
end $$;

create or replace function public.admin_set_offer_status(p_offer uuid, p_status text) returns public.supplier_offers
language plpgsql security definer set search_path = public as $$
declare o supplier_offers;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if p_status not in ('published', 'suspended') then raise exception 'حالة غير معروفة'; end if;
  update supplier_offers set status = p_status where id = p_offer returning * into o;
  if o is null then raise exception 'العرض غير موجود'; end if;
  perform _audit(case p_status when 'published' then 'نشر عرض' else 'إيقاف عرض' end, o.title, null);
  return o;
end $$;

-- إعدادات المنصة فقط؛ ضوابط السياسة (الضمانات والعوائد والمدد والمبادرة البيطرية) يعدّلها البنك المركزي
create or replace function public.admin_set_setting(p_key text, p_value numeric) returns public.settings
language plpgsql security definer set search_path = public as $$
declare s settings; old numeric;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if p_key not in ('platform_fee', 'inspection_fee', 'dev_mode', 'alloc_warn') then raise exception 'هذا الضابط من صلاحية البنك المركزي حسب سياسة التمويل'; end if;
  if p_value < 0 or (p_key = 'dev_mode' and p_value not in (0, 1)) or (p_key = 'alloc_warn' and p_value > 100) then raise exception 'قيمة غير صحيحة'; end if;
  select value into old from settings where key = p_key;
  update settings set value = p_value where key = p_key returning * into s;
  perform _audit('تعديل إعداد', p_key, jsonb_build_object('from', old, 'to', p_value));
  return s;
end $$;

-- إجراءات مشغّل النظام على الطلب: ملاحظة إدارية، أو إلغاء مسودة متروكة لم تُرسل للمصرف
create or replace function public.admin_app_action(p_app uuid, p_action text, p_note text) returns public.applications
language plpgsql security definer set search_path = public as $$
declare a applications;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب أو الملاحظة'; end if;
  select * into a from applications where id = p_app for update;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if p_action = 'note' then
    perform _ev(a.id, a.stage, 'ملاحظة مشغّل النظام', p_note);
  elsif p_action = 'cancel' then
    if a.stage > 5 or a.status not in ('active', 'returned') then raise exception 'يُلغى من هنا فقط الطلب الذي لم يُرسل للمصرف — بعد الإرسال يقرر المصرف'; end if;
    update applications set status = 'cancelled', updated_at = now() where id = a.id returning * into a;
    perform _ev(a.id, a.stage, 'إلغاء المسودة من مشغّل النظام', p_note);
  else raise exception 'إجراء غير معروف'; end if;
  perform _audit(case p_action when 'note' then 'ملاحظة على طلب' else 'إلغاء مسودة' end, a.code, jsonb_build_object('note', p_note));
  return a;
end $$;

-- ═══ 8) حساب مشغّل النظام (يُنشأ مرة واحدة) ═══
insert into public.orgs(code, type, name, meta) values ('platform', 'platform', 'ألواح — مشغّل المنصة', '{}') on conflict (code) do nothing;
do $$ begin
  if not exists (select 1 from profiles where username = 'superadmin') then
    perform _mk_user('superadmin', 'Alw@2026Sa', 'مشغّل النظام — الإدارة العامة', 'platform_admin', 'admin', 'platform', null, null);
  end if;
end $$;

-- ═══ 9) الصلاحيات ═══
revoke all on function public._audit(text, text, jsonb), public._open_account(), public._check_bank_supplier() from public, anon, authenticated;
revoke all on function public.admin_users(), public.admin_create_user(jsonb), public.admin_update_user(uuid, jsonb), public.admin_set_password(uuid, text),
  public.admin_set_disabled(uuid, boolean), public.admin_set_bank(uuid, jsonb), public.admin_set_offer_status(uuid, text), public.admin_set_setting(text, numeric),
  public.admin_app_action(uuid, text, text), public.start_application_bank(uuid, uuid, int, text, text, numeric, numeric) from public, anon;
grant execute on function public.admin_users(), public.admin_create_user(jsonb), public.admin_update_user(uuid, jsonb), public.admin_set_password(uuid, text),
  public.admin_set_disabled(uuid, boolean), public.admin_set_bank(uuid, jsonb), public.admin_set_offer_status(uuid, text), public.admin_set_setting(text, numeric),
  public.admin_app_action(uuid, text, text), public.start_application_bank(uuid, uuid, int, text, text, numeric, numeric), public._is_admin(),
  public._bank_accepts_supplier(uuid, uuid) to authenticated;

commit;
