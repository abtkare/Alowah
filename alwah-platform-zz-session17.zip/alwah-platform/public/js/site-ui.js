// الجلسة 17: عنوان المنظومة بالـGPS ونوع الموقع (سكن / مشروع: صناعي، تجاري، زراعي، بيطري، أخرى) — بوابة المقترض
import { esc, badge, rpc, toast, cleanErr, PROJECT_KINDS, SITE_TYPE, purposeText, mapsLink } from './core.js';
import { gpsDialog } from './geo.js';

// منتقي الموقع: يرسم الحقول في box ويعيد كائناً فيه state() و valid()
export function sitePicker(box, init = {}, { accMax = 100, onChange } = {}) {
  const st = {
    site_type: init.site_type || (init.purpose && init.purpose !== 'household' ? 'project' : init.purpose === 'household' ? 'residential' : ''),
    purpose: init.purpose && init.purpose !== 'household' ? init.purpose : '', purpose_other: init.purpose_other || '',
    lat: init.site_geo?.lat ?? null, lng: init.site_geo?.lng ?? null, acc: init.site_geo?.acc ?? null, address: init.site_geo?.address || '',
  };
  const valid = () => !!st.site_type && st.lat != null && st.acc != null && st.acc <= accMax
    && (st.site_type === 'residential' || (st.purpose && (st.purpose !== 'other' || st.purpose_other.trim().length >= 3)));
  const draw = () => {
    box.innerHTML = `<div class="site-pick">
      <label class="lbl">نوع الموقع ★</label>
      <div class="seg">${Object.entries(SITE_TYPE).map(([k, t]) => `<label class="${st.site_type === k ? 'on' : ''}"><input type="radio" name="stype" value="${k}" ${st.site_type === k ? 'checked' : ''}>${k === 'residential' ? '🏠' : '🏭'} ${esc(t)}</label>`).join('')}</div>
      ${st.site_type === 'project' ? `<label class="lbl mt">نوع المشروع ★</label>
        <div class="chips">${PROJECT_KINDS.map(([k, t]) => `<label class="chip ${st.purpose === k ? 'on' : ''}"><input type="radio" name="pkind" value="${k}" ${st.purpose === k ? 'checked' : ''}>${esc(t)}</label>`).join('')}</div>
        ${st.purpose === 'other' ? `<div class="field mt"><label>اكتب نوع المشروع ★</label><input class="input" data-other maxlength="60" value="${esc(st.purpose_other)}" placeholder="مثال: مستوصف أهلي، مدرسة، محطة غسل سيارات"></div>` : ''}
        <p class="small muted" style="margin:6px 0 0">طلبات المشاريع تتطلب عرض المورد المقدَّم ودراسة جدوى يدرسها خبير معتمد.</p>` : ''}
      <label class="lbl mt">عنوان المنظومة بالـGPS ★</label>
      <div class="gps-box ${st.lat != null ? (st.acc <= accMax ? 'ok' : 'bad') : ''}">
        ${st.lat != null ? `<div>📍 <b>تم تحديد الموقع</b> — دقة ±<b class="num">${Math.round(st.acc)}</b> م ${st.acc <= accMax ? badge(['مقبول', 'ok']) : badge([`أضعف من ±${accMax} م`, 'bad'])} · <a href="${mapsLink(st)}" target="_blank" rel="noopener">عرض على الخريطة</a></div>`
          : '<div class="small">حدّد الموقع وأنت في مكان تركيب المنظومة نفسه (البيت أو المشروع). سيصل فني المورد إلى هذا الموقع بالضبط، ولا يُقبل التركيب في مكان آخر.</div>'}
        <button type="button" class="btn ${st.lat != null ? 'ghost' : 'cyan'} sm mt" data-gps>📍 ${st.lat != null ? 'إعادة تحديد الموقع' : 'حدّد موقع المنظومة الآن'}</button>
      </div>
      <div class="field mt"><label>أقرب نقطة دالة (اختياري)</label><input class="input" data-addr maxlength="160" value="${esc(st.address)}" placeholder="مثال: قرب جامع الرحمن — زقاق 12"></div>
    </div>`;
    box.querySelectorAll('input[name=stype]').forEach(r => r.onchange = () => { st.site_type = r.value; if (r.value === 'residential') st.purpose = ''; draw(); onChange && onChange(st); });
    box.querySelectorAll('input[name=pkind]').forEach(r => r.onchange = () => { st.purpose = r.value; draw(); onChange && onChange(st); });
    const o = box.querySelector('[data-other]'); if (o) o.oninput = () => { st.purpose_other = o.value; onChange && onChange(st); };
    box.querySelector('[data-addr]').oninput = e => { st.address = e.target.value; };
    box.querySelector('[data-gps]').onclick = async () => {
      const g = await gpsDialog({ title: 'تحديد موقع المنظومة', hint: `قف في مكان تركيب المنظومة وفي مكان مكشوف (السطح أو الساحة). الدقة المطلوبة ±${accMax} م أو أفضل.`, want: Math.min(25, accMax) });
      if (!g) return;
      Object.assign(st, { lat: g.lat, lng: g.lng, acc: g.acc }); draw(); onChange && onChange(st);
    };
  };
  draw();
  return { state: () => ({ ...st }), valid };
}

export const sitePayload = st => ({ site_type: st.site_type, purpose: st.site_type === 'project' ? st.purpose : 'household', purpose_other: st.purpose === 'other' ? st.purpose_other.trim() : null,
  lat: st.lat, lng: st.lng, acc: st.acc, address: (st.address || '').trim() || null });

// لوحة عنوان المنظومة داخل معالج الطلب (المراحل 1–5)
export function sitePanel(box, app, { sb, accMax = 100, locked = false, onSaved } = {}) {
  if (!box) return;
  const saved = !!(app.site_geo && app.site_type);
  const summary = () => {
    box.innerHTML = `<div class="card wiz-body mb site-sum"><div class="row" style="flex-wrap:wrap;gap:8px"><b>📍 عنوان المنظومة:</b> ${esc(SITE_TYPE[app.site_type] || '')} — ${esc(purposeText(app))}
      <span class="small muted">· دقة ±<span class="num">${Math.round(app.site_geo.acc)}</span> م · <a href="${mapsLink(app.site_geo)}" target="_blank" rel="noopener">على الخريطة</a></span>
      <span class="sp"></span>${app.stage <= 5 ? '<button type="button" class="btn ghost sm" data-edit>تعديل</button>' : ''}</div></div>`;
    const e = box.querySelector('[data-edit]'); if (e) e.onclick = form;
  };
  const form = () => {
    box.innerHTML = `<div class="card wiz-body mb"><h2>عنوان المنظومة ونوع الموقع</h2>
      ${saved ? '' : '<div class="notice warn"><span>★</span><span><b>مطلوب أولاً:</b> حدّد عنوان المنظومة بالـGPS ونوع الموقع — لا تكتمل الخطوة الأولى ولا يُرسل الطلب قبله.</span></div>'}
      ${locked ? '<p class="small muted">لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير — يمكنك تحديث الموقع فقط.</p>' : ''}
      <div data-pick></div>
      <div class="row mt">${saved ? '<button type="button" class="btn ghost" data-cancel>تراجع</button>' : ''}<span class="sp"></span><button type="button" class="btn cyan" data-save disabled>حفظ عنوان المنظومة</button></div></div>`;
    const sv = box.querySelector('[data-save]');
    const pk = sitePicker(box.querySelector('[data-pick]'), app, { accMax, onChange: () => { sv.disabled = !pk.valid(); } });
    sv.disabled = !pk.valid();
    const c = box.querySelector('[data-cancel]'); if (c) c.onclick = summary;
    sv.onclick = async () => {
      sv.disabled = true;
      try { const a = await rpc(sb, 'set_app_site', { p_app: app.id, p: sitePayload(pk.state()) }); Object.assign(app, a); toast('حُفظ عنوان المنظومة', 'ok'); onSaved ? onSaved(a) : summary(); }
      catch (e) { toast(cleanErr(e), 'bad'); sv.disabled = !pk.valid(); }
    };
  };
  saved ? summary() : form();
}
