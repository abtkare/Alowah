// لوحة هيئة النزاهة — قراءة كاملة وتنبيهات، بلا أي إجراء تعديلي
import { esc, kpi, appsTable, openApp, ago, tabs } from '../core.js';
import { perfView } from '../perf.js';
import { lettersView } from '../letters.js';
import { analyticsView } from '../cbi-extra.js';

const SEV = { high: ['عالية', '!'], medium: ['متوسطة', '◆'], low: ['منخفضة', 'i'] };

export async function render(ctx) {
  const { sb, root } = ctx;
  const [alerts, apps] = await Promise.all([
    sb.from('integrity_alerts').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
  ]);
  root.innerHTML = `
    <div class="page-head"><div><h1>هيئة النزاهة</h1><p>قراءة كاملة وتنبيهات آلية. الحجز والتجميد أمر قضائي ينفذه المصرف، لا زر في النظام.</p></div></div>
    <div class="notice dark">🛡️ صلاحية هذا الحساب قراءة وتصدير فقط — لا تعديل ولا إيقاف ولا تجميد. الحساب أضافه البنك المركزي، والمخاطبات الرسمية معه سرية بين الجهتين.</div>
    <div class="grid g4 mb">
      ${kpi('تنبيهات عالية الخطورة', `<span class="num">${alerts.filter(a => a.severity === 'high').length}</span>`, '', true)}
      ${kpi('إجمالي التنبيهات', `<span class="num">${alerts.length}</span>`)}
      ${kpi('الطلبات تحت الرقابة', `<span class="num">${apps.length}</span>`)}
      ${kpi('طلبات مرفوضة أو معادة', `<span class="num">${apps.filter(a => ['rejected', 'returned'].includes(a.status)).length}</span>`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'alerts', label: 'التنبيهات الآلية', count: alerts.filter(a => a.severity === 'high').length }, { key: 'perf', label: 'التأخير والتسيب الوظيفي' }, { key: 'stats', label: 'التحليل ونسب النمو' }, { key: 'letters', label: '🔒 المخاطبات مع البنك المركزي' }, { key: 'apps', label: 'كل الطلبات وسجلاتها' }];
  ctx.nzTab = ctx.nzTab || 'alerts';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.nzTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.nzTab));
  const open = a => openApp(ctx, a, {});

  function show(k) {
    if (k === 'alerts') {
      body.innerHTML = alerts.map((a, i) => `<div class="alert ${a.severity}"><div class="ic">${SEV[a.severity][1]}</div><div style="flex:1"><div class="row"><h4>${esc(a.title)}</h4><span class="sp"></span><span class="muted small">${ago(a.created_at)}</span></div>
        <p>${esc(a.details)}</p><p class="small">الجهة: <b>${esc(a.entity || '—')}</b> · الخطورة: ${SEV[a.severity][0]}${a.application_id ? ` · <a href="#" data-app="${a.application_id}">فتح ملف الطلب</a>` : ''}</p></div></div>`).join('') || '<div class="card empty">لا تنبيهات.</div>';
      body.querySelectorAll('[data-app]').forEach(x => x.onclick = e => { e.preventDefault(); const a = apps.find(p => p.id === x.dataset.app); a && open(a); });
    }
    if (k === 'perf') perfView(ctx, body, { mode: 'oversight' });
    if (k === 'stats') return analyticsView(ctx, body);
    if (k === 'letters') return lettersView(ctx, body);
    if (k === 'apps') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'supplier', 'stage', 'status'] })}</div>`;
  }
  show(ctx.nzTab);
}

export const shouldRefresh = ctx => !['perf', 'stats', 'letters'].includes(ctx.nzTab);
