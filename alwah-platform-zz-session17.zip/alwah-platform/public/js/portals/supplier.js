// بوابة المورد — العروض والطلبات والتركيب وتوثيق التشغيل
import { esc, iqd, mln, num, kpi, appsTable, openApp, stageActions, tabs, enrichVet, isVet, rpc, toast, cleanErr, modal, badge } from '../core.js';
import { assignAllows } from '../team.js';

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  const [apps, offers, tiers] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('supplier_offers').select('*').eq('supplier_id', org.id).then(r => r.data || []),
    sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
  ]);
  await enrichVet(sb, apps);
  const meta = org.meta || {};
  const vetSup = meta.kind === 'vet';
  const rules = await sb.rpc('my_assignment_rules').then(r => r.data || []).catch(() => []);
  const inbox = apps.filter(a => a.stage === 31 && a.status === 'active' && assignAllows(rules, a, profile));
  const done = apps.filter(a => a.status === 'completed');

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}</h1><p>${meta.legacy ? '<span class="badge ok">معتمد — تعامل سابق</span> ' : '<span class="badge info">معتمد</span> '}مؤشراتك تحسبها المنصة ولا تُدخلها الشركة.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('بانتظار التركيب أو التوثيق', `<span class="num">${inbox.length}</span>`, 'طلبات في صندوقك', true)}
      ${kpi('تركيبات منجزة', `<span class="num">${num((meta.installs || 0) + done.length)}</span>`, 'منها على المنصة ' + done.length)}
      ${kpi('نسبة المطابقة في التدقيق', `<span class="num">${meta.match_rate || 0}%</span>`)}
      ${kpi('متوسط مدة التنفيذ', `<span class="num">${meta.avg_days || 0}</span> أيام`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const isAdm = profile.role === 'supplier_admin';
  const defs = [{ key: 'inbox', label: 'أوامر الشراء: التركيب والتوثيق', count: inbox.length }, { key: 'all', label: 'كل طلباتي' }, ...(vetSup || !isAdm ? [] : [{ key: 'offers', label: 'عروضي في الكتالوج' }]), ...(isAdm ? [{ key: 'team', label: 'الفريق الفني' }] : [])];
  ctx.supTab = defs.find(d => d.key === ctx.supTab) ? ctx.supTab : 'inbox';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.supTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.supTab));
  ctx.hide = ['guarantee'];
  // الجلسة 17: الفني يوثّق التركيب في الموقع، ومدير حساب المورد وحده يعتمد المحضر
  const open = a => openApp(ctx, a, { actions: isAdm && a.stage === 31 && a.status === 'active' ? stageActions(ctx, a).slice(0, 2) : [] });

  function show(k) {
    if (k === 'inbox') body.innerHTML = vetSup ? `<div class="notice">⚕ مورد معتمد في مبادرة الطب البيطري: يصلك الطلب بعد أمر الشراء من المصرف. افتح الطلب ووثّق بالترتيب: <b>التوريد</b> ← <b>التركيب</b> ← <b>التشغيل التجريبي</b>. كل توثيق يفتح دفعتك لدى أمين الصندوق، والدفعة الأخيرة بعد إجازة دائرة البيطرة. ثم اعتمد المحضر.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'stage', 'updated'] })}</div>` : `<div class="notice">📍 تصلك المعاملة بعد صدور أمر الشراء من المصرف. افتحها وأنت في موقع المقترض: <b>ثبّت موقع التركيب بالـGPS</b> ← <b>صورة الألواح</b> ← <b>صورة العاكس والبطاريات</b> ← <b>فيديو التشغيل</b>. كل دليل يُختم بالموقع والوقت والرمز الوظيفي، ولا يُقبل من المعرض، ولا يُعتمد المحضر قبل اكتمالها${isAdm ? '' : ' — ثم يعتمده مدير حساب المورد'}. بعدها تكشف لجنة المصرف على التركيب وتستلمه، ثم يُصرف مبلغك.</div><div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'stage', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'bank', 'stage', 'status'] })}</div>`;
    if (k === 'team') return teamTab();
    if (k === 'offers' && vetSup) return;
    if (k === 'offers') body.innerHTML = `<div class="grid g3">${offers.map(o => {
      const t = tiers.find(x => x.id === o.tier_id);
      return `<div class="card offer"><div class="row"><b style="font-size:18px"><span class="num">${num(t?.kw)}</span> kW</b><span class="sp"></span><span class="badge ok">منشور · نسخة ${o.version}</span></div>
        <div class="price">${iqd(o.price)}</div><div class="small muted">سقف البرنامج لهذه القدرة: ${iqd(t?.price_cap)}</div>
        <ul class="small" style="margin:6px 0;padding-inline-start:18px">${(o.components || []).map(c => `<li>${esc(c.item)}: ${esc(c.brand)} ${esc(c.model)} × <span class="num">${c.qty}</span></li>`).join('')}</ul>
        <div class="small muted">${esc(o.warranty)}</div></div>`;
    }).join('')}</div>`;
  }
  // الجلسة 17: مدير حساب المورد يضيف فنيي التركيب ويوقفهم
  async function teamTab() {
    body.innerHTML = '<div class="card"><div class="spin"></div></div>';
    let list = [];
    try { list = await rpc(sb, 'supplier_team', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
    body.innerHTML = `<div class="notice">فنيو التركيب يدخلون من <b>بوابة المورد</b> بحساباتهم، ويوثّقون التركيب في موقع المقترض. لا يعتمدون المحضر ولا يرون العروض. أول دخول يطلب تغيير كلمة المرور المؤقتة.</div>
      <div class="card flush"><h3>الفريق <span class="sp"></span><button class="btn cyan sm" data-add>إضافة فني</button></h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الرمز الوظيفي</th><th>الدور</th><th>الحالة</th><th></th></tr></thead><tbody>
      ${list.map(u => `<tr><td>${esc(u.full_name)}</td><td class="num" dir="ltr">${esc(u.username)}</td><td class="num">${esc(u.staff_code || '')}</td><td class="small">${esc(u.title)}</td>
        <td>${u.disabled ? badge(['موقوف', 'bad']) : u.must_change_password ? badge(['بانتظار أول دخول', 'warn']) : badge(['فعّال', 'ok'])}</td>
        <td>${u.role === 'supplier_tech' ? `<button class="btn sm ${u.disabled ? 'ok' : 'ghost'}" data-dis="${u.id}" data-v="${u.disabled ? '0' : '1'}">${u.disabled ? 'تفعيل' : 'إيقاف'}</button>` : ''}</td></tr>`).join('')}
      </tbody></table></div></div>`;
    body.querySelectorAll('[data-dis]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      try { await rpc(sb, 'supplier_set_tech', { p_user: b.dataset.dis, p_disabled: b.dataset.v === '1' }); toast('حُدّث الحساب', 'ok'); teamTab(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    });
    body.querySelector('[data-add]').onclick = () => {
      const m = modal(`<h3>إضافة فني تركيب</h3>
        <div class="field"><label>الاسم الكامل</label><input class="input" data-k="full_name"></div>
        <div class="field"><label>اسم المستخدم (حروف إنجليزية صغيرة)</label><input class="input" data-k="username" dir="ltr" placeholder="tech.ali"></div>
        <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" dir="ltr" inputmode="tel" placeholder="07xxxxxxxxx"></div>
        <div class="field"><label>كلمة مرور مؤقتة</label><input class="input" data-k="password" dir="ltr" placeholder="8 أحرف وأرقام على الأقل"></div>
        <div class="row"><span class="sp"></span><button class="btn cyan" data-go>إنشاء الحساب</button></div>`);
      m.el.querySelector('[data-go]').onclick = async e => {
        const d = {}; m.el.querySelectorAll('[data-k]').forEach(x => d[x.dataset.k] = x.value.trim());
        e.target.disabled = true;
        try { const r = await rpc(sb, 'supplier_add_tech', { p: d }); m.close(); toast(`أُنشئ الحساب ${r.username} (${r.staff_code})`, 'ok'); teamTab(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    };
  }
  show(ctx.supTab);
}
