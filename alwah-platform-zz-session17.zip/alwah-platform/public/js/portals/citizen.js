// بوابة المقترض — طلبي، كتالوج المنظومات، تفاصيل المنظومة وتقييماتها، معالج طلب التمويل (المراحل 1–5)، الملف الشخصي
import { cameraCapture, docThumb } from '../capture.js';
import {
  esc, num, iqd, dt, ago, badge, statusBadge, stageBar, stageList, eventsList, GUARANTEE, ADVANCE_LABEL, rpc, toast, cleanErr,
  GOVS, govOptions, installment, maskPhone, maskId, stars, modal, askOtp, serverOtp, normPhone, validPhone, digits, el, PAY_METHODS, PAY_LABEL, VET_TYPES, isVet
} from '../core.js';
import { initVet, vetBanner, pageVetStart, homeDraftVet, vetTrackCard, pageApplyVet } from './vet.js';
import { PURPOSE, PURPOSE_HINT, viewDoc, purposeText, SITE_TYPE } from '../core.js';
import { sitePicker, sitePayload, sitePanel } from '../site-ui.js';
import { loadIntake, checklistHtml, studiesHtml, refsHtml, pickFile } from '../intake-ui.js';

const S = { ref: null };   // بيانات مرجعية تُحمَّل مرة واحدة
let C;                     // سياق البوابة

const route = () => { const [r, id] = location.hash.slice(1).split('/'); return { r: r || 'home', id }; };
// التحديث اللحظي يعيد رسم «طلبي» فقط، فلا تضيع مدخلات النماذج
export const shouldRefresh = () => route().r === 'home' || (route().r === 'apply' && !!C?.czVetWait);
// المصرف يعمل مع موردين معتمدين لديه (القائمة الفارغة = كل الموردين)
const accepts = (b, supplierId) => !b?.terms?.suppliers?.length || b.terms.suppliers.includes(supplierId);

export async function render(ctx) {
  C = ctx;
  if (!ctx.czInit) { ctx.czInit = true; window.addEventListener('hashchange', () => { window.scrollTo(0, 0); go(); }); }
  initVet({ S, C: () => C, load, saveStep, pageApply, step1, step4, cancelApp, accepts });
  await load();
  await go();
}

// ───────── البيانات ─────────
async function load(force) {
  const { sb } = C;
  if (!S.ref || force) {
    const [tiers, offers, terms, settings] = await Promise.all([
      sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
      sb.from('supplier_offers').select('*').eq('status', 'published').order('price').then(r => r.data || []),
      sb.from('bank_terms').select('*').then(r => r.data || []),
      sb.from('settings').select('*').then(r => r.data || []),
    ]);
    S.ref = { tiers, offers, terms, set: Object.fromEntries(settings.map(s => [s.key, Number(s.value)])) };
  }
  const [apps, reviews, me] = await Promise.all([
    sb.from('applications').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('offer_reviews').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('profiles').select('*').eq('id', C.profile.id).maybeSingle().then(r => r.data),
  ]);
  if (me) C.profile = me;
  S.apps = apps; S.reviews = reviews;
  const set = S.ref.set;
  const banks = C.orgs.filter(o => o.type === 'bank').map(b => ({ ...b, terms: S.ref.terms.find(t => t.bank_id === b.id), open: b.meta?.accepting !== false }));
  S.banks = banks;
  const bestRate = Math.min(...banks.filter(b => b.open && b.terms).map(b => b.terms.margin)) + set.cbi_rate;
  S.offers = S.ref.offers.map(o => {
    const tier = S.ref.tiers.find(t => t.id === o.tier_id), sup = C.orgs.find(x => x.id === o.supplier_id);
    const rs = reviews.filter(r => r.offer_id === o.id);
    const avg = k => rs.length ? rs.reduce((s, r) => s + (r[k] || 0), 0) / rs.length : 0;
    const dist = [5, 4, 3, 2, 1].map(n => rs.filter(r => r.rating === n).length);
    return { ...o, tier, kw: Number(tier?.kw), sup, rs, rating: avg('rating'), q: avg('quality'), ins: avg('install'), srv: avg('service'), dist,
      from: installment(o.price, bestRate, Math.min(84, set.term_max_months || 84)), panels: o.components?.find(c => c.item === 'ألواح')?.qty };
  });
  // شارات: الأقل سعراً والأعلى تقييماً في كل فئة
  S.ref.tiers.forEach(t => {
    const os = S.offers.filter(o => o.tier_id === t.id); if (!os.length) return;
    os.reduce((a, b) => a.price <= b.price ? a : b).cheap = true;
    os.reduce((a, b) => a.rating >= b.rating ? a : b).top = true;
  });
  S.active = apps.find(a => ['active', 'returned'].includes(a.status));
}
const offerById = id => S.offers.find(o => o.id === id);
const guaranteeFor = price => price <= S.ref.set.guarantee_t1 ? 'single_salary' : price <= S.ref.set.guarantee_t2 ? 'multi_salary' : 'mortgage';
const G_HINT = { single_salary: 'كفيل واحد موظف', multi_salary: 'كفيلان موظفان', mortgage: 'رهن عقار' };

// ───────── الهيكل والتنقل ─────────
async function go() {
  const { r, id } = route();
  const { root } = C;
  if (!root.querySelector('.cz-shell')) {
    root.innerHTML = `<div class="cz-shell"><nav class="cz-nav" aria-label="أقسام بوابة المقترض">
      <a href="#home" data-n="home"><i>☀</i><span>طلبي</span></a>
      <a href="#catalog" data-n="catalog"><i>▦</i><span>كتالوج المنظومات</span></a>
      <a href="#vet" data-n="vet"><i>⚕</i><span>التمويل البيطري</span></a>
      <a href="#profile" data-n="profile"><i>☺</i><span>ملفي</span></a></nav><div id="cz"></div></div>`;
  }
  const navKey = { offer: 'catalog', apply: 'home', start: 'home' }[r] || r;
  root.querySelectorAll('.cz-nav a').forEach(a => a.classList.toggle('on', a.dataset.n === navKey));
  const body = root.querySelector('#cz');
  try {
    if (r === 'catalog') pageCatalog(body);
    else if (r === 'offer') pageOffer(body, id);
    else if (r === 'apply') await pageApply(body);
    else if (r === 'start') pageStart(body);
    else if (r === 'profile') pageProfile(body);
    else if (r === 'vet') await pageVetStart(body);
    else await pageHome(body);
  } catch (e) { console.error(e); body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}
const refreshAll = async () => { await load(); await go(); };

// ───────── الرئيسية: طلبي ─────────
// مراحل المعاملة بلغة المقترض: كل مجموعة من مراحل الإجراء الداخلية تظهر له كمحطة واحدة
const JOURNEY = [
  [6, 6, 'استلام طلبك في الفرع', 'تدقيق المستمسكات والاستعلام الائتماني'],
  [7, 7, 'فتح حسابك في المصرف', 'الامتثال وفتح الحساب باسمك'],
  [8, 11, 'الموافقة المبدئية وإضبارتك', 'موافقة مدير الفرع، الضمان الأولي، إيداع العمولات، لجنة الفرع'],
  [12, 16, 'الكشف الموقعي والدراسة الائتمانية', 'قسم المبادرات يدقق ملفك ويكشف على موقع التركيب'],
  [17, 19, 'القرار والضمان النهائي', 'الرأي القانوني، موافقة الإدارة العليا، استكمال الضمان'],
  [20, 24, 'تمويل المصرف لطلبك', 'السلفة التجميعية وتعزيزها من ائتمان المصرف'],
  [25, 29, 'توقيع عقدك', 'عقد التمويل والكمبيالة وطلب التنفيذ'],
  [30, 32, 'التوريد والتركيب', 'أمر الشراء من المورد، التركيب، الكشف على التركيب'],
  [33, 37, 'التنفيذ وجدول الأقساط', 'جدول الأقساط، الصرف للمورد، إغلاق الملف'],
];
// ما المطلوب من المقترض في كل مرحلة (غير المذكور: لا شيء — المعاملة لدى الجهة المعنية)
const TODO = {
  6: 'لا شيء مطلوب منك الآن. قد يتصل بك موظف خدمة الزبائن للتأكد من بياناتك — أبقِ هاتفك متاحاً.',
  7: 'يفتح لك المصرف حساباً باسمك. قد يتصل بك موظف الامتثال لاستكمال بيانات فتح الحساب.',
  9: 'إجراءات الضمان الأولية: يفاتح المصرف المصرفَ الموطَّن لراتب كل كفيل لتفعيل الاستقطاع المباشر، أو التسجيل العقاري للرهن. قد يُطلب من الكفلاء توقيع نموذج تخويل الاستقطاع لدى مصرفهم.',
  10: 'يودع المصرف العمولة والرسوم التي دفعتها إلكترونياً في إضبارتك — لا تدفع شيئاً آخر.',
  14: 'ستزور لجنة الكشف الموقعي مكان التركيب — تأكد من وجود من يستقبلها.',
  19: 'استكمال الضمان النهائي: قد يُطلب منك أو من الكفلاء أو المالك مراجعة الفرع.',
  25: 'يرسل لك المصرف عقد التمويل والكمبيالة لتوقّعهما إلكترونياً من هاتفك هنا في «بوابة المقترض» — وإن تعذّر ذلك راجع فرعك مع بطاقتك الوطنية الموحدة. تُستوفى هنا عمولة البنك المركزي لمرة واحدة.',
  31: 'سيتصل بك المورد لتحديد موعد التوريد والتركيب — كن حاضراً في الموقع.',
  32: 'ستكشف لجنة المصرف على المنظومة المركّبة ومطابقتها.',
  34: 'راجع فرعك لاستلام جدول أقساطك والتوقيع على الاستلام.',
};
async function pageHome(body) {
  const app = S.active || S.apps.find(a => a.status !== 'cancelled');
  const first = C.profile.full_name.split(' ')[0];
  if (!app || app.status === 'cancelled') return homeEmpty(body, first);
  if (['active', 'returned'].includes(app.status) && app.stage <= 5) return isVet(app) ? homeDraftVet(body, app, first) : homeDraft(body, app, first);
  const { sb, stages } = C;
  const cur = stages.find(s => s.n === app.stage);
  const days = Math.max(0, Math.round((Date.now() - new Date(app.updated_at)) / 864e5));
  const [events, branch, pays] = await Promise.all([
    sb.from('application_events').select('*').eq('application_id', app.id).order('id').then(r => r.data || []),
    app.branch_id ? sb.from('branches').select('*').eq('id', app.branch_id).maybeSingle().then(r => r.data) : null,
    sb.from('payments').select('*').eq('application_id', app.id).eq('status', 'paid').then(r => r.data || []),
  ]);
  const o = offerById(app.offer_id), bank = C.orgs.find(x => x.id === app.bank_id);
  const lastNote = events.slice().reverse().find(e => e.note && ['إعادة للاستكمال', 'رفض مسبب'].includes(e.action));
  const canReview = !isVet(app) && (app.status === 'completed' || app.stage >= 32) && !S.reviews.some(r => r.application_id === app.id);
  const vetCard = isVet(app) ? await vetTrackCard(app) : '';
  const done = app.status === 'completed', live = ['active', 'returned'].includes(app.status);
  const J = isVet(app) ? JOURNEY.map(j => j[0] === 30 ? [30, 32, 'توريد الأجهزة وتركيبها وتشغيلها', 'دفعات المورد على التوريد والتركيب، وإجازة دائرة البيطرة'] : j) : JOURNEY;
  // المدة المتبقية التقديرية: مجموع المدد المسموحة للمراحل الباقية (أيام عمل ≈ ×1.4 أيام تقويمية)
  const left = n => stages.filter(s => s.n >= app.stage && s.n <= n).reduce((t, s) => t + Number(s.sla_days || 0), 0);
  const eta = n => { const d = new Date(Date.now() + left(n) * 1.4 * 864e5); return d.toLocaleDateString('ar-IQ-u-nu-latn', { day: 'numeric', month: 'long' }); };
  const pay = pays.find(x => x.bank_id === app.bank_id) || pays[0];
  const todo = app.status === 'returned' ? `أُعيد طلبك للاستكمال لدى ${esc(cur?.owner_label || 'المصرف')}: ${esc(lastNote?.note || '')} — تواصل مع فرعك${branch?.complaint_phone ? ` على <a class="num" href="tel:${esc(branch.complaint_phone)}">${esc(branch.complaint_phone)}</a>` : ''}.`
    : esc(TODO[app.stage] || `لا شيء مطلوب منك الآن — المعاملة لدى ${cur?.owner_label || 'المصرف'}.`);
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>تابع طلب تمويل ${isVet(app) ? 'مشروعك البيطري' : 'منظومتك'} مرحلة بمرحلة، ومن يمسكه الآن، وما المطلوب منك.</p></div></div>
    ${app.status === 'rejected' ? `<div class="notice" style="background:var(--bad-bg);color:var(--bad)"><b>رُفض الطلب:</b> ${esc(lastNote?.note || '')}</div>` : ''}
    ${canReview ? `<div class="card mb rate-cta"><div><h3>رُكّبت منظومتك — كيف كانت التجربة؟</h3><p class="muted small">تقييمك يظهر للمواطنين في الكتالوج ويساعدهم على الاختيار.</p></div><span class="sp"></span><button class="btn warn" data-rate>قيّم المنظومة</button></div>` : ''}
    <div class="card mb hero-track">
      <div class="row"><div><div class="small" style="color:#9FB4D6">رقم الطلب</div><h2 class="num" style="font-size:26px">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}</div>
      ${stageBar(app, stages.length)}
      <div class="row mt"><div><div class="small" style="color:#9FB4D6">المرحلة الحالية</div><b style="font-size:18px">${done ? 'اكتملت المعاملة' : `${app.stage}. ${esc(cur?.name)}`}</b></div><span class="sp"></span>
      <div><div class="small" style="color:#9FB4D6">الطلب الآن لدى</div><b style="color:var(--cyan)">${esc(done ? 'مكتمل' : cur?.owner_label)}</b></div>
      <div><div class="small" style="color:#9FB4D6">منذ</div><b><span class="num">${days}</span> يوم</b></div></div>
    </div>
    ${live ? `<div class="notice ${app.status === 'returned' ? 'warn' : 'dark'} mb"><span>☞</span><span><b>المطلوب منك الآن:</b> ${todo}</span></div>` : ''}
    ${app.stage >= 25 ? '<div data-esign-box></div>' : ''}
    ${!isVet(app) && app.purpose && app.purpose !== 'household' ? '<div data-xbox></div>' : ''}
    <div class="grid g-side">
      <div class="card"><h3>مسار معاملتك${live && app.stage < 31 ? `<span class="sp"></span><span class="small muted">التركيب المتوقع نحو <b>${eta(31)}</b></span>` : ''}</h3>
        <ol class="journey">${J.map(([a, z, t, d]) => { const st = done || app.stage > z ? 'done' : app.stage >= a ? (app.status === 'rejected' ? 'bad' : app.status === 'returned' ? 'ret' : 'cur') : '';
          const extra = a === 7 && app.bank_account ? `<em>رقم حسابك: <b class="num">${esc(app.bank_account)}</b></em>` : '';
          return `<li class="${st}"><span class="n">${st === 'done' ? '✓' : st === 'bad' ? '✕' : J.findIndex(x => x[0] === a) + 1}</span><div><b>${t}</b><small>${st === 'cur' || st === 'ret' ? `الآن: ${esc(cur?.name)} — لدى ${esc(cur?.owner_label)}` : d}</small>${extra}</div></li>`; }).join('')}</ol>
        <details class="mt"><summary class="small">كل مراحل الإجراء التفصيلية (<span class="num">${stages.length}</span>)</summary>${stageList(app, stages)}</details>
      </div>
      <div>
        <div class="card mb"><h3>حسابك في المصرف</h3>${app.bank_account ? `<dl class="kv"><dt>المصرف</dt><dd>${esc(bank?.name || '—')}</dd>${branch ? `<dt>الفرع</dt><dd>${esc(branch.name)}</dd>` : ''}<dt>رقم الحساب</dt><dd><b class="num">${esc(app.bank_account)}</b></dd><dt>فُتح في</dt><dd>${dt(app.account_opened_at)}</dd>${branch?.complaint_phone ? `<dt>رقم الشكاوى</dt><dd><a class="num" href="tel:${esc(branch.complaint_phone)}">${esc(branch.complaint_phone)}</a></dd>` : ''}</dl>`
          : `<p class="muted" style="margin:0">${app.status === 'rejected' ? 'لم يُفتح حساب.' : `يفتح لك ${esc(bank?.name || 'المصرف')} حساباً باسمك في مرحلة «الامتثال وفتح الحساب» بعد تدقيق مستمسكاتك، ويظهر رقمه هنا.`}</p>`}</div>
        ${pay ? `<div class="card mb"><h3>العمولة والرسوم المدفوعة</h3><dl class="kv">${(pay.items || []).map(i => `<dt>${esc(i.label)}</dt><dd>${iqd(i.amount)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(pay.amount)}</b></dd></dl>
          <div class="row small mt"><span class="muted">رقم العملية <b class="num">${esc(pay.ref)}</b></span><span class="sp"></span><button class="linkbtn" data-rcpt>الإيصال</button></div></div>` : ''}
        ${vetCard || `<div class="card mb">${o ? `<img class="mini-img" src="${esc(o.image_url)}" alt="" loading="lazy">` : ''}<h3>منظومتي</h3><dl class="kv"><dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd><dt>المورد</dt><dd>${esc(C.orgs.find(x => x.id === app.supplier_id)?.name)}</dd>
          <dt>السعر</dt><dd>${iqd(app.price)}</dd>${app.cbi_fee ? `<dt>عمولة المركزي</dt><dd>${iqd(app.cbi_fee)} <span class="muted small">لمرة واحدة</span></dd>` : ''}<dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])}</dd>
          <dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً</dd></dl>
          ${o ? `<a class="btn ghost sm mt" href="#offer/${o.id}">تفاصيل المنظومة</a>` : ''}</div>`}
      </div>
    </div>
    <div class="card mt"><h3>كل ما حدث على طلبي</h3>${eventsList(events)}</div>
    ${pastApps(app.id)}`;
  const eb = body.querySelector('[data-esign-box]'); if (eb) import('../esign-ui.js').then(m => m.mountEsignBorrower(sb, app, eb));
  // الجلسة 16: حالة دراسة الجدوى لدى الخبير المعتمد (دون اسم الخبير)
  const xb = body.querySelector('[data-xbox]');
  if (xb) loadIntake(sb, app).then(d => { if (!d) return;
    const fz = d.docs.filter(x => x.kind === 'feasibility');
    xb.innerHTML = `<div class="card mb"><h3>دراسة الجدوى <span class="sp"></span>${badge([`الغرض: ${PURPOSE[app.purpose]}`, 'info'])}${app.feasibility_rejections ? ' ' + badge(['مرفوض سابقاً بسبب دراسة الجدوى', 'bad']) : ''}</h3>
      <p class="small muted" style="margin:0 0 8px">${esc(({ none: 'وصلت دراستك إلى موظف الاستقبال — ستُحال إلى خبير معتمد', pending: 'أُحيلت دراستك إلى خبير معتمد — بانتظار استلامه', received: 'دراستك قيد الدراسة لدى الخبير المعتمد', conforming: 'قرار الخبير: مطابق ✓', non_conforming: 'قرار الخبير: غير مطابق', stale: 'وصلت دراستك المحدّثة — بانتظار إحالتها للخبير', no_study: 'لم تُرفق دراسة الجدوى' })[d.ck?.expert?.state] || '')} — يدرسها خبير معتمد مختص من خارج المصرف.</p>${fz.length ? studiesHtml(fz, d.refs) : ''}${refsHtml(d.refs, { named: false })}</div>`;
    xb.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.doc)); });
  const rb = body.querySelector('[data-rate]'); if (rb) rb.onclick = () => rateDialog(app);
  const rc = body.querySelector('[data-rcpt]'); if (rc) rc.onclick = () => receipt(app, pay);
}

function homeEmpty(body, first) {
  const top = S.offers.slice().sort((a, b) => b.rating - a.rating).slice(0, 3);
  const p = C.profile, dataOk = profileReady(p);
  const steps = [
    ['إنشاء الحساب', 'تم', true],
    ['بياناتك من البطاقة الوطنية', p.national_id ? 'مقروءة من البطاقة' : 'تُكمل في الخطوة الأولى', !!p.national_id],
    ['العنوان والعمل والدخل', dataOk ? 'مكتملة' : 'مطلوبة قبل البدء', dataOk],
    ['اختيار المصرف ثم المنظومة', 'المنظومات المعتمدة لدى المصرف فقط', false],
    ['دفع عمولة المصرف والرسوم', 'إلكترونياً قبل الإرسال', false],
    ['فتح حسابك في المصرف', 'يفتحه المصرف بعد استلام طلبك', false],
    ['متابعة معاملتك مرحلة بمرحلة', 'حتى تركيب المنظومة وجدول الأقساط', false]];
  body.innerHTML = `
    <section class="cz-hero">
      <div><span class="pill">ألواح · مستقبل التمويل في العراق</span><h1>أهلاً ${esc(first)} — تمويلك يبدأ من هاتفك، لا من طابور المصرف</h1>
        <p>اختر مصرفك وقارن عمولته، ثم اختر منظومتك من الموردين المعتمدين لديه، وادفع العمولة إلكترونياً، وتابع طلبك لحظة بلحظة — كل خطوة محفوظة لا تُعدَّل.</p>
        <div class="row"><a class="btn cyan" href="#start">ابدأ طلب تمويل منظومة شمسية</a><a class="btn btn-dark" href="#vet">تمويل مشروع بيطري</a><button class="btn ghost-l" data-help>ساعدني أختار القدرة</button></div></div>
      <ol class="how">${['أكمل بياناتك', 'اختر المصرف', 'اختر المنظومة المعتمدة لديه', 'ادفع العمولة ووقّع', 'تابع طلبك بعد فتح حسابك'].map((s, i) => `<li><i>${i + 1}</i>${s}</li>`).join('')}</ol>
    </section>
    <div class="card mb"><h3>رحلتك في ألواح<span class="sp"></span>${dataOk ? '' : '<a class="btn cyan sm" href="#start">أكمل بياناتك</a>'}</h3>
      <ol class="journey">${steps.map(([t, d, ok], i) => `<li class="${ok ? 'done' : i === steps.findIndex(x => !x[2]) ? 'cur' : ''}"><span class="n">${ok ? '✓' : i + 1}</span><div><b>${t}</b><small>${d}</small></div></li>`).join('')}</ol></div>
    ${vetBanner()}
    <div class="row" style="margin:6px 0 12px"><h2 style="font-size:19px">الأعلى تقييماً من المواطنين</h2><span class="sp"></span><a href="#catalog" class="small">كل المنظومات ←</a></div>
    <div class="offers">${top.map(offerCard).join('')}</div>
    ${pastApps()}`;
  body.querySelector('[data-help]').onclick = helpChoose;
  wireCards(body);
}
const profileReady = p => !!(p.governorate && p.employer && Number(p.monthly_salary) > 0);

function homeDraft(body, app, first) {
  const o = offerById(app.offer_id);
  const ret = app.returned_from === 6, rej = ret && app.feasibility_rejections > 0 && (app.intake_missing || []).some(i => i.key === 'feasibility_update');
  const steps = ['التحقق من الهوية', 'رقم «أور»', 'المصرف والمنظومة', 'الضمان والكفلاء', 'الدفع والتوقيع'];
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>${ret ? 'أُعيد طلبك إليك — أكمل المطلوب وأعد إرساله بنفس رقمه.' : 'طلبك محفوظ — أكمل الخطوات المتبقية وأرسله للمصرف.'}</p></div></div>
    ${ret ? `<div class="notice warn mb"><span>⚠</span><span><b>${rej ? 'رُفض طلبك بسبب دراسة الجدوى' : 'أعاد المصرف طلبك لإكمال النواقص'}</b> — ${esc(app.returned_by_title || '')} · ${dt(app.returned_at)}
      <div style="white-space:pre-line;margin-top:4px">${esc(app.return_note || '')}</div>
      <div class="small mt">${rej ? 'المطلوب: إعداد دراسة جدوى حقيقية بأرقام واقعية ورفعها في خطوة «المصرف والمنظومة»، ثم إعادة إرسال الطلب. يبقى رقم طلبك وبياناته، وتُحفظ دراستك السابقة مع الحديثة.' : 'أكمل البنود المطلوبة ثم أعد إرسال الطلب من الخطوة 5 — يبقى رقم طلبك وبياناته كما هي.'}</div></span></div>` : ''}
    <div class="card mb draft">
      ${o ? `<img src="${esc(o.image_url)}" alt="" class="draft-img">` : ''}
      <div class="draft-b">
        <div class="row">${ret ? '<span class="badge warn"><i class="dot"></i>مُعاد للاستكمال</span>' : '<span class="badge info"><i class="dot"></i>مسودة</span>'}${app.feasibility_rejections ? badge(['مرفوض سابقاً بسبب دراسة الجدوى', 'bad']) : ''}<b class="num">${esc(app.code)}</b><span class="sp"></span><span class="small muted">بدأ ${ago(app.created_at)}</span></div>
        <h2 style="font-size:21px;margin:8px 0 2px">${esc(o?.title || '')}</h2>
        <div class="muted">${iqd(app.price)} · الضمان: ${esc(GUARANTEE[app.guarantee_type])}</div>
        <div class="prog"><i style="width:${(app.stage - 1) * 20}%"></i></div>
        <div class="small muted">أنجزت <b class="num">${app.stage - 1}</b> من 5 خطوات — التالية: <b style="color:var(--text)">${esc(steps[app.stage - 1])}</b></div>
        <div class="row mt"><a class="btn cyan" href="#apply">${ret ? 'أكمل النواقص وأعد الإرسال' : 'أكمل طلبك'}</a><button class="btn ghost" data-cancel>إلغاء الطلب</button></div>
      </div>
    </div>
    ${pastApps(app.id)}`;
  body.querySelector('[data-cancel]').onclick = () => cancelApp(app);
}

function pastApps(exceptId) {
  const list = S.apps.filter(a => a.id !== exceptId);
  if (!list.length) return '';
  return `<div class="card mt"><h3>طلباتي السابقة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المبلغ</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>
    ${list.map(a => `<tr><td><b class="num">${esc(a.code)}</b></td><td>${isVet(a) ? 'مشروع بيطري' : `<span class="num">${num(a.kw)}</span> kW`}</td><td>${iqd(a.amount)}</td><td>${statusBadge(a.status)}</td><td class="small muted">${dt(a.created_at)}</td></tr>`).join('')}</tbody></table></div></div>`;
}

async function cancelApp(app) {
  const m = modal(`<h3>إلغاء الطلب ${esc(app.code)}</h3><p class="muted">يمكنك تقديم طلب جديد بعد الإلغاء. هذا الإجراء يُسجَّل في سجل التدقيق.</p>
    <div class="field"><label>سبب الإلغاء (اختياري)</label><select class="input" data-r><option>أريد اختيار منظومة أخرى</option><option>غيّرت رأيي</option><option>لا أملك ضماناً مناسباً</option><option>سبب آخر</option></select></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-no>تراجع</button><button class="btn bad" data-yes>إلغاء الطلب</button></div>`);
  m.el.querySelector('[data-no]').onclick = m.close;
  m.el.querySelector('[data-yes]').onclick = async () => {
    try { await rpc(C.sb, 'cancel_my_application', { p_app: app.id, p_reason: m.el.querySelector('[data-r]').value }); m.close(); toast('أُلغي الطلب', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الكتالوج ─────────
function offerCard(o) {
  const g = guaranteeFor(o.price);
  return `<article class="ocard" data-id="${o.id}">
    <div class="media" data-play="${o.id}" role="button" tabindex="0" aria-label="تشغيل فيديو شرح المنظومة">
      <img src="${esc(o.image_url)}" alt="منظومة ${num(o.kw)} kW من ${esc(o.sup?.name)}" loading="lazy">
      <span class="play"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></span>
      <span class="dur">فيديو 0:40</span>
      <div class="flags">${o.cheap ? '<span class="badge ok">الأقل سعراً</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
    </div>
    <div class="ob">
      <div class="row" style="gap:6px"><span class="kw num">${num(o.kw)} kW</span><span class="muted small">${esc(o.sup?.name)}</span></div>
      <div class="row" style="gap:6px">${stars(o.rating)}<b class="num small">${o.rating.toFixed(1)}</b><span class="muted small">(<span class="num">${o.rs.length}</span> تقييم)</span></div>
      <div class="price">${iqd(o.price)}</div>
      <div class="small muted">قسط يبدأ من <b style="color:var(--text)">${iqd(o.from)}</b> شهرياً</div>
      <div class="chips"><span><b class="num">${num(o.panels)}</b> لوح</span><span>بطاريات <b class="num">${num(o.battery_kwh)}</b> kWh</span><span>~<b class="num">${num(o.tier?.daily_kwh)}</b> kWh/يوم</span></div>
      <div class="small">الضمان المطلوب: <b>${G_HINT[g]}</b></div>
      <div class="row mt" style="gap:8px"><a class="btn ghost sm" href="#offer/${o.id}">التفاصيل والتقييمات</a><span class="sp"></span><button class="btn cyan sm" data-apply="${o.id}">اطلب التمويل</button></div>
    </div></article>`;
}
function wireCards(root) {
  root.querySelectorAll('[data-play]').forEach(m => { m.onclick = () => playVideo(offerById(m.dataset.play)); m.onkeydown = e => { if (e.key === 'Enter') m.click(); }; });
  root.querySelectorAll('[data-apply]').forEach(b => b.onclick = () => startFlow(offerById(b.dataset.apply)));
}
function playVideo(o) {
  const m = modal(`<div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls autoplay playsinline preload="metadata"></video></div>
    <div class="row mt"><div><b>${esc(o.title)}</b><div class="small muted">فيديو شرح المنظومة · أقل من دقيقة</div></div><span class="sp"></span><a class="btn ghost sm" href="#offer/${o.id}" data-x>التفاصيل</a><button class="btn cyan sm" data-a>اطلب التمويل</button></div>`, { wide: true });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-a]').onclick = () => { m.close(); startFlow(o); };
}

function pageCatalog(body) {
  C.czCat = C.czCat || { kw: 'all', sort: 'price' };
  const st = C.czCat;
  body.innerHTML = `
    <div class="page-head"><div><h1>كتالوج المنظومات</h1><p>كل عرض بصورته وفيديو شرح قصير وتقييمات المواطنين الذين ركّبوه فعلاً.</p></div><span class="sp"></span><button class="btn ghost" data-help>ساعدني أختار القدرة</button></div>
    <div class="filters">
      <div class="seg sm">${[['all', 'الكل'], ...S.ref.tiers.map(t => [String(Number(t.kw)), `${num(t.kw)} kW`])].map(([k, l]) => `<button class="${st.kw === k ? 'on' : ''}" data-kw="${k}">${l}</button>`).join('')}</div>
      <span class="sp"></span>
      <label class="small muted" for="srt">الترتيب</label>
      <select class="input sm" id="srt"><option value="price">الأقل سعراً</option><option value="rating">الأعلى تقييماً</option><option value="speed">الأسرع تركيباً</option><option value="reviews">الأكثر تقييماً</option></select>
    </div>
    <div data-tier></div>
    <div class="offers" data-list></div>
    <p class="small muted mt">الأسعار تشمل النقل والتركيب والهيكل. القسط التقديري بأقل هامش متاح ولأطول مدة؛ القسط النهائي يحدده المصرف الذي تختاره. التقييمات في نسخة العرض تجريبية.</p>`;
  const sel = body.querySelector('#srt'); sel.value = st.sort;
  sel.onchange = () => { st.sort = sel.value; paint(); };
  body.querySelectorAll('[data-kw]').forEach(b => b.onclick = () => { st.kw = b.dataset.kw; body.querySelectorAll('[data-kw]').forEach(x => x.classList.toggle('on', x === b)); paint(); });
  body.querySelector('[data-help]').onclick = helpChoose;
  paint();
  function paint() {
    let list = S.offers.filter(o => st.kw === 'all' || String(o.kw) === st.kw);
    const key = { price: (a, b) => a.price - b.price, rating: (a, b) => b.rating - a.rating, speed: (a, b) => (a.sup?.meta?.avg_days || 99) - (b.sup?.meta?.avg_days || 99), reviews: (a, b) => b.rs.length - a.rs.length }[st.sort];
    list.sort((a, b) => key(a, b) || a.kw - b.kw);
    const t = st.kw !== 'all' && S.ref.tiers.find(x => String(Number(x.kw)) === st.kw);
    body.querySelector('[data-tier]').innerHTML = t ? `<div class="notice dark tier-note"><b class="num">${num(t.kw)} kW</b> — إنتاج يومي ~<b class="num">${num(t.daily_kwh)}</b> kWh · تشغّل: ${esc(t.loads)} · سقف السعر ${iqd(t.price_cap)} · الضمان: <b>${G_HINT[guaranteeFor(t.price_cap)]}</b> أو حسب السعر</div>` : '';
    const L = body.querySelector('[data-list]'); L.innerHTML = list.map(offerCard).join('') || '<div class="card empty">لا عروض</div>';
    wireCards(L);
  }
}

function helpChoose() {
  const items = [['ac', 'مكيف 1.5 طن', 9.6, 0], ['cooler', 'مبردة هواء', 2.5, 1], ['fridge', 'ثلاجة', 1.6, 1], ['freezer', 'مجمدة', 1.4, 0], ['washer', 'غسالة', 0.8, 1], ['pump', 'مضخة ماء', 1.5, 0]];
  const m = modal(`<h3>ما الأجهزة التي تريد تشغيلها؟</h3><p class="muted small">نحسب الاستهلاك اليومي ونقترح أصغر قدرة تكفيه (الإنارة والتلفاز والشحن محسوبة دائماً).</p>
    <div class="counters">${items.map(([k, l, , d]) => `<div class="ctr"><span>${l}</span><span class="sp"></span><button type="button" data-d="${k}">−</button><b class="num" data-v="${k}">${d}</b><button type="button" data-i="${k}">+</button></div>`).join('')}</div>
    <div class="card mt" style="background:var(--surface-2);box-shadow:none" data-res></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>اعرض المنظومات المناسبة</button></div>`);
  const v = Object.fromEntries(items.map(i => [i[0], i[3]]));
  let pick;
  const calc = () => {
    const need = 2.5 + items.reduce((s, [k, , kwh]) => s + v[k] * kwh, 0);
    pick = S.ref.tiers.find(t => Number(t.daily_kwh) >= need * 1.1) || S.ref.tiers[S.ref.tiers.length - 1];
    m.el.querySelector('[data-res]').innerHTML = `استهلاكك اليومي التقديري <b class="num">${need.toFixed(1)}</b> kWh — القدرة المقترحة: <b class="num" style="color:var(--indigo);font-size:20px">${num(pick.kw)} kW</b> (إنتاج ~<span class="num">${num(pick.daily_kwh)}</span> kWh)`;
  };
  m.el.querySelectorAll('[data-i],[data-d]').forEach(b => b.onclick = () => { const k = b.dataset.i || b.dataset.d; v[k] = Math.max(0, Math.min(6, v[k] + (b.dataset.i ? 1 : -1))); m.el.querySelector(`[data-v="${k}"]`).textContent = v[k]; calc(); });
  calc();
  m.el.querySelector('[data-go]').onclick = () => { C.czCat = { ...(C.czCat || { sort: 'price' }), kw: String(Number(pick.kw)) }; m.close(); if (route().r === 'catalog') go(); else location.hash = '#catalog'; };
}

// ───────── تفاصيل المنظومة ─────────
function pageOffer(body, id) {
  const o = offerById(id);
  if (!o) { body.innerHTML = '<div class="card empty">العرض غير موجود. <a href="#catalog">العودة للكتالوج</a></div>'; return; }
  const set = S.ref.set, g = guaranteeFor(o.price), meta = o.sup?.meta || {};
  const siblings = S.offers.filter(x => x.tier_id === o.tier_id).sort((a, b) => a.price - b.price);
  body.innerHTML = `
    <a href="#catalog" class="back">→ العودة للكتالوج</a>
    <div class="od">
      <div class="od-media card flush">
        <div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls playsinline preload="none"></video></div>
        <div class="od-thumbs"><span>فيديو شرح المنظومة · <span class="num">0:40</span></span><span class="sp"></span><a href="${esc(o.image_url)}" target="_blank" rel="noopener" class="small">فتح الصورة</a></div>
      </div>
      <div class="od-sum card">
        <div class="row"><span class="kw num">${num(o.kw)} kW</span>${o.cheap ? '<span class="badge ok">الأقل سعراً في فئته</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
        <h1 style="font-size:24px;margin:8px 0 2px">منظومة هجينة <span class="num">${num(o.kw)} kW</span></h1>
        <div class="muted">${esc(o.sup?.name)}</div>
        <a href="#rv" class="row" style="gap:6px;margin-top:6px;color:inherit">${stars(o.rating, 18)}<b class="num">${o.rating.toFixed(1)}</b><span class="muted small">من <span class="num">${o.rs.length}</span> مواطن ركّبها</span></a>
        <div class="price big">${iqd(o.price)}</div>
        <div class="small muted">يشمل النقل والتركيب والهيكل المجلفن · سقف الفئة ${iqd(o.tier?.price_cap)}</div>
        <dl class="kv mt"><dt>الإنتاج اليومي</dt><dd>~<span class="num">${num(o.tier?.daily_kwh)}</span> kWh</dd><dt>تشغّل</dt><dd>${esc(o.tier?.loads)}</dd>
          <dt>البطاريات</dt><dd><span class="num">${num(o.battery_kwh)}</span> kWh</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[g]}</dd></dl>
        <div class="row mt"><button class="btn cyan" data-apply="${o.id}" style="flex:1">اطلب تمويل هذه المنظومة</button></div>
      </div>
    </div>
    <div class="grid g-side mt">
      <div>
        <div class="card mb"><h3>المكونات</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المكوّن</th><th>العلامة</th><th>الطراز</th><th>العدد</th></tr></thead><tbody>
          ${(o.components || []).map(c => `<tr><td>${esc(c.item)}</td><td><span class="num">${esc(c.brand)}</span></td><td><span class="num">${esc(c.model)}</span></td><td class="num">${num(c.qty)}</td></tr>`).join('')}</tbody></table></div>
          <p class="small muted" style="margin:10px 0 0">${esc(o.description || '')}</p></div>
        <div class="card mb"><h3>الضمان والصيانة</h3><ul class="ticks">${(o.warranty || '').split('،').map(w => `<li>${esc(w.trim())}</li>`).join('')}</ul></div>
        <div class="card mb" id="calc"></div>
        <div class="card" id="rv"></div>
      </div>
      <div>
        <div class="card mb"><h3>عن المورد</h3><b>${esc(o.sup?.name)}</b>
          <div class="grid g2 mt" style="gap:10px">
            <div class="stat"><b class="num">${num(meta.installs)}</b><span>منظومة مركّبة</span></div>
            <div class="stat"><b class="num">${num(meta.avg_days)}</b><span>يوماً متوسط التركيب</span></div>
            <div class="stat"><b class="num">${num(meta.match_rate)}%</b><span>مطابقة التدقيق الهندسي</span></div>
            <div class="stat"><b>${meta.legacy ? 'مسجّل' : 'جديد'}</b><span>${meta.legacy ? 'منذ المرحلة الأولى' : 'في المبادرة'}</span></div>
          </div></div>
        <div class="card"><h3>عروض أخرى بنفس القدرة</h3>
          ${siblings.map(s => `<a class="sib ${s.id === o.id ? 'on' : ''}" href="#offer/${s.id}"><img src="${esc(s.image_url)}" alt=""><div><b>${esc(s.sup?.name)}</b><div class="small">${stars(s.rating, 12)} <span class="num">${s.rating.toFixed(1)}</span></div></div><span class="sp"></span><b class="small">${iqd(s.price)}</b></a>`).join('')}
        </div>
      </div>
    </div>`;
  body.querySelector('[data-apply]').onclick = () => startFlow(o);
  // حاسبة القسط
  const calc = body.querySelector('#calc'); let term = 60;
  const drawCalc = () => {
    calc.innerHTML = `<h3>احسب قسطك<span class="sp"></span><span class="small muted">مدة السداد <b class="num">${term}</b> شهراً</span></h3>
      <input type="range" min="12" max="${set.term_max_months || 84}" step="6" value="${term}" class="range" aria-label="مدة السداد">
      <div class="banks">${S.banks.map(b => { if (!b.terms) return ''; const rate = set.cbi_rate + Number(b.terms.margin); const ins = installment(o.price, rate, Math.min(term, b.terms.max_term_months));
        return `<div class="bk ${b.open ? '' : 'off'}"><i style="background:${esc(b.meta?.color || '#4356A3')}"></i><div><b>${esc(b.name)}</b><div class="small muted">${b.is_islamic ? 'مرابحة' : 'تجاري'} · <span class="num">${rate.toFixed(2)}%</span> سنوياً</div></div><span class="sp"></span><div style="text-align:left">${b.open ? `<b>${iqd(ins)}</b><div class="small muted">شهرياً</div>` : '<span class="small muted">لا يستقبل طلبات حالياً</span>'}</div></div>`; }).join('')}</div>
      <p class="small muted" style="margin:8px 0 0">النسبة = عوائد المصرف السنوية المتناقصة (بحد أعلى <span class="num">${set.margin_max}%</span>). تُضاف عمولة البنك المركزي لمرة واحدة <span class="num">${set.cbi_fee_small}%</span> (حتى 20 مليون) ولا تُسترجع، حسب سياسة التمويل.</p>`;
    calc.querySelector('.range').oninput = e => { term = Number(e.target.value); drawCalc(); calc.querySelector('.range').focus(); };
  };
  drawCalc();
  drawReviews(body.querySelector('#rv'), o);
}

function drawReviews(box, o, filter = 0, all = false) {
  const n = o.rs.length, list = o.rs.filter(r => !filter || r.rating === filter), shown = all ? list : list.slice(0, 5);
  box.innerHTML = `<h3>تقييمات المواطنين<span class="sp"></span><span class="badge muted">من ركّبوا المنظومة فقط</span></h3>
    <div class="rv-top">
      <div class="rv-avg"><b class="num">${o.rating.toFixed(1)}</b>${stars(o.rating, 18)}<span class="small muted"><span class="num">${n}</span> تقييم</span></div>
      <div class="rv-dist">${[5, 4, 3, 2, 1].map((s, i) => `<button class="rv-row ${filter === s ? 'on' : ''}" data-f="${s}"><span class="num">${s}</span>★<span class="bar"><i style="width:${n ? o.dist[i] / n * 100 : 0}%"></i></span><span class="num small muted">${o.dist[i]}</span></button>`).join('')}</div>
      <div class="rv-sub">${[['جودة المنظومة', o.q], ['التركيب', o.ins], ['خدمة المورد', o.srv]].map(([l, v]) => `<div><span class="small">${l}</span><span class="bar"><i style="width:${v / 5 * 100}%"></i></span><b class="num small">${v.toFixed(1)}</b></div>`).join('')}</div>
    </div>
    ${filter ? `<div class="small mb">تعرض تقييمات <b class="num">${filter}</b> نجوم فقط — <button class="linkbtn" data-f="0">عرض الكل</button></div>` : ''}
    <ul class="rv-list">${shown.map(r => `<li><div class="row" style="gap:8px"><span class="av sm">${esc(r.author_name.trim()[0])}</span><div><b>${esc(shortName(r.author_name))}</b><div class="small muted">${esc(r.governorate || '')} · ${ago(r.created_at)}</div></div><span class="sp"></span>${stars(r.rating, 14)}</div>
      ${r.comment ? `<p>${esc(r.comment)}</p>` : ''}${r.verified ? '<span class="badge ok sm">تركيب موثّق عبر المنصة</span>' : ''}</li>`).join('') || '<li class="muted">لا تقييمات بهذا العدد من النجوم.</li>'}</ul>
    ${!all && list.length > 5 ? `<button class="btn ghost block" data-all>عرض كل التقييمات (<span class="num">${list.length}</span>)</button>` : ''}`;
  box.querySelectorAll('[data-f]').forEach(b => b.onclick = () => drawReviews(box, o, Number(b.dataset.f) === filter ? 0 : Number(b.dataset.f)));
  const a = box.querySelector('[data-all]'); if (a) a.onclick = () => drawReviews(box, o, filter, true);
}
const shortName = n => { const p = n.trim().split(/\s+/); return p.length > 1 ? `${p[0]} ${p[1][0]}.` : p[0]; };

// ───────── بدء الطلب: بياناتك ← المصرف ← المنظومة المعتمدة لديه ← موقع التركيب ─────────
function startFlow(o) {
  if (S.active) {
    if (S.active.stage <= 5) {
      const m = modal(`<h3>لديك طلب لم يكتمل</h3><p class="muted">طلبك <b class="num">${esc(S.active.code)}</b> محفوظ. يمكنك تغيير المصرف أو المنظومة من خطوة «المصرف والمنظومة» داخل الطلب نفسه.</p>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إغلاق</button><button class="btn cyan" data-go>متابعة طلبي</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close; m.el.querySelector('[data-go]').onclick = () => { m.close(); location.hash = '#apply'; };
    } else toast('لديك طلب قائم لدى المصرف — تابعه من «طلبي»', 'bad');
    return;
  }
  C.czStart = { ...(C.czStart || {}), offer: o?.id || C.czStart?.offer || null };
  if (route().r === 'start') go(); else location.hash = '#start';
}

const START = [['بياناتك', 'العنوان والعمل'], ['المصرف', 'العمولة والمدة'], ['المنظومة', 'المعتمدة لدى المصرف'], ['البدء', 'موقع التركيب']];
function pageStart(body) {
  if (S.active) { location.hash = S.active.stage <= 5 ? '#apply' : '#home'; return; }
  const st = C.czStart = C.czStart || {};
  const set = S.ref.set, p = C.profile;
  st.term = Math.min(st.term || 60, set.term_max_months || 60);
  const banks = S.banks.filter(b => b.terms);
  if (st.step == null) st.step = profileReady(p) ? 1 : 0;
  if (st.step >= 2 && !banks.some(b => b.id === st.bank && b.open)) st.step = 1;
  if (st.step >= 3 && !st.offer) st.step = 2;
  const offerOk = (b, o) => o && accepts(b, o.supplier_id);
  body.innerHTML = `
    <div class="page-head"><div><h1>طلب تمويل منظومة شمسية</h1><p>بياناتك أولاً، ثم المصرف، ثم منظومة من الموردين المعتمدين لدى المصرف. يُحسب القسط والعمولة حسب المصرف الذي تختاره.</p></div><span class="sp"></span><a href="#home" class="btn ghost sm">رجوع</a></div>
    <ol class="wiz w4">${START.map(([t, sub], i) => `<li class="${i < st.step ? 'done go' : ''} ${i === st.step ? 'cur' : ''}" data-s="${i}"><i>${i < st.step ? '✓' : i + 1}</i><div><b>${t}</b><small>${sub}</small></div></li>`).join('')}</ol>
    <div class="card wiz-body" id="sb"></div>`;
  body.querySelectorAll('.wiz li.go').forEach(li => li.onclick = () => { st.step = Number(li.dataset.s); pageStart(body); });
  const sb = body.querySelector('#sb');
  const next = n => { st.step = n; pageStart(body); window.scrollTo(0, 0); };
  [startData, startBank, startOffer, startGo][st.step]();

  // أ) بيانات المقترض: من البطاقة الوطنية + العنوان والعمل والدخل
  function startData() {
    sb.innerHTML = `<h2>بياناتك</h2><p class="muted">بياناتك الشخصية مقروءة من بطاقتك الوطنية. أكمل العنوان والعمل والدخل — يحتاجها المصرف لدراسة طلبك ويُحسب منها مدى تحمّلك للقسط.</p>
      <div class="review"><dl class="kv"><dt>الاسم</dt><dd>${esc(p.full_name)}</dd><dt>رقم البطاقة</dt><dd><span class="num">${esc(maskId(p.national_id))}</span>${p.id_source === 'ocr' ? ' ' + badge(['مقروء من البطاقة', 'ok']) : ''}</dd><dt>الهاتف</dt><dd><span class="num">${esc(p.phone || '—')}</span></dd></dl></div>
      <form data-f novalidate><div class="grid g2" style="gap:12px">
        <div class="field"><label>المحافظة *</label><select class="input" name="governorate">${govOptions(p.governorate || '')}</select></div>
        <div class="field"><label>المدينة / القضاء</label><input class="input" name="city" value="${esc(p.city || '')}"></div>
        <div class="field" style="grid-column:1/-1"><label>العنوان التفصيلي</label><input class="input" name="address" value="${esc(p.address || '')}" placeholder="المحلة، الزقاق، الدار"></div>
        <div class="field"><label>جهة العمل *</label><input class="input" name="employer" value="${esc(p.employer || '')}" placeholder="دائرة حكومية، شركة، عمل حر"></div>
        <div class="field"><label>الدخل الشهري (د.ع) *</label><input class="input" name="monthly_salary" inputmode="numeric" dir="ltr" value="${esc(p.monthly_salary || '')}"></div>
      </div><div class="row mt"><span class="sp"></span><button class="btn cyan">حفظ والمتابعة لاختيار المصرف ←</button></div></form>`;
    sb.querySelector('[data-f]').onsubmit = async e => {
      e.preventDefault(); const f = e.target, d = {};
      ['governorate', 'city', 'address', 'employer', 'monthly_salary'].forEach(k => d[k] = (f[k].value || '').trim());
      d.monthly_salary = digits(d.monthly_salary);
      if (!d.governorate) return toast('اختر المحافظة', 'bad');
      if (d.employer.length < 2) return toast('اكتب جهة العمل', 'bad');
      if (!(Number(d.monthly_salary) > 0)) return toast('اكتب الدخل الشهري', 'bad');
      const b = f.querySelector('button'); b.disabled = true;
      try { C.profile = await rpc(C.sb, 'update_my_profile', { p: d }); toast('حُفظت بياناتك', 'ok'); next(1); }
      catch (er) { toast(cleanErr(er), 'bad'); b.disabled = false; }
    };
  }

  // ب) المصرف: العمولة والرسوم والنسبة والمدة، وعدد المنظومات المعتمدة لديه
  function startBank() {
    const o = offerById(st.offer), ref = o?.price || S.offers.reduce((m, x) => Math.min(m, x.price), Infinity);
    const draw = () => {
      sb.innerHTML = `<h2>اختر المصرف</h2><p class="muted">لكل مصرف عمولته ورسومه ونسبته والموردون المعتمدون لديه. ${o ? `الأرقام محسوبة لمنظومتك المختارة (${iqd(o.price)}).` : `الأرقام تقديرية لأقل منظومة سعراً (${iqd(ref)}) — تُحسب بدقة بعد اختيار المنظومة.`}</p>
        <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${st.term}</span> شهراً (<span class="num">${(st.term / 12).toFixed(1)}</span> سنة)</b></div>
        <input type="range" class="range" min="12" max="${set.term_max_months}" step="6" value="${st.term}" aria-label="مدة السداد">
        <div class="bcards">${banks.map(b => { const k = bankCalc(ref, b, st.term), n = S.offers.filter(x => accepts(b, x.supplier_id)).length, okO = !o || offerOk(b, o), en = b.open && okO && n > 0;
          return `<label class="bcard ${b.id === st.bank ? 'on' : ''} ${en ? '' : 'off'}"><input type="radio" name="bk" value="${b.id}" ${b.id === st.bank ? 'checked' : ''} ${en ? '' : 'disabled'}>
          <div class="row"><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i><b>${esc(b.name)}</b><span class="sp"></span>${b.is_islamic ? '<span class="badge info">مرابحة</span>' : ''}</div>
          ${!b.open ? '<div class="small muted mt">لا يستقبل طلبات عبر المنصة حالياً</div>' : !okO ? '<div class="small mt" style="color:var(--warn)">لا يتعامل مع مورد منظومتك المختارة</div>' : `<div class="bk-i">${iqd(k.ins)}<small>شهرياً</small></div>
          <dl class="kv small"><dt>عمولة المصرف</dt><dd><b class="cm">${iqd(k.comm)}</b> <span class="num">(${commPct(b)}%)</span></dd><dt>رسوم الملف</dt><dd>${iqd(b.terms.file_fee)}</dd>
          <dt>${b.is_islamic ? 'نسبة الربح' : 'النسبة السنوية'}</dt><dd class="num">${k.rate.toFixed(2)}%</dd><dt>أقصى مدة</dt><dd><span class="num">${b.terms.max_term_months}</span> شهراً</dd>
          <dt>مدة الدراسة</dt><dd><span class="num">${b.terms.processing_days}</span> أيام عمل</dd><dt>منظومات معتمدة</dt><dd><span class="num">${n}</span>${b.terms.suppliers?.length ? ' (موردون محددون)' : ' (كل الموردين)'}</dd></dl>`}</label>`; }).join('')}</div>
        <div class="row mt"><button class="btn ghost" data-back>→ بياناتك</button><span class="sp"></span><button class="btn cyan" data-ok ${banks.some(b => b.id === st.bank && b.open) ? '' : 'disabled'}>${o ? 'المتابعة للتأكيد ←' : 'عرض المنظومات المعتمدة لدى المصرف ←'}</button></div>`;
      sb.querySelector('.range').oninput = e => { st.term = Number(e.target.value); draw(); sb.querySelector('.range').focus(); };
      sb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { st.bank = r.value; draw(); });
      sb.querySelector('[data-back]').onclick = () => next(0);
      sb.querySelector('[data-ok]').onclick = () => { const b = banks.find(x => x.id === st.bank); st.term = Math.min(st.term, b.terms.max_term_months); next(o && offerOk(b, o) ? 3 : 2); };
    };
    draw();
  }

  // ج) المنظومة: فقط عروض الموردين المعتمدين لدى المصرف المختار، بقسطها وعمولتها لديه
  function startOffer() {
    const b = banks.find(x => x.id === st.bank), list = S.offers.filter(x => accepts(b, x.supplier_id));
    sb.innerHTML = `<h2>اختر المنظومة</h2><p class="muted">المنظومات المعروضة من الموردين المعتمدين لدى <b>${esc(b.name)}</b>، بقسطها وعمولتها لدى هذا المصرف لمدة <span class="num">${st.term}</span> شهراً.</p>
      <div class="pick-list">${S.ref.tiers.map(t => { const os = list.filter(x => x.tier_id === t.id); if (!os.length) return '';
        return `<div class="pl-h"><b class="num">${num(t.kw)} kW</b> <span class="small muted">— ${esc(t.loads)}</span></div>${os.map(x => { const k = bankCalc(x.price, b, st.term);
          return `<label class="pl ${x.id === st.offer ? 'on' : ''}"><input type="radio" name="of" value="${x.id}" ${x.id === st.offer ? 'checked' : ''}><img src="${esc(x.image_url)}" alt=""><div><b>${esc(x.sup?.name)}</b><div class="small">${stars(x.rating, 12)} <span class="num">${x.rating.toFixed(1)}</span> · ${G_HINT[guaranteeFor(x.price)]}</div><div class="small muted">قسط ${iqd(k.ins)} · عمولة ${iqd(k.comm)}</div></div><span class="sp"></span><b class="small">${iqd(x.price)}</b></label>`; }).join('')}`; }).join('') || '<div class="empty">لا منظومات معتمدة لدى هذا المصرف حالياً — اختر مصرفاً آخر.</div>'}</div>
      <div class="row mt"><button class="btn ghost" data-back>→ المصرف</button><span class="sp"></span><button class="btn cyan" data-ok ${list.some(x => x.id === st.offer) ? '' : 'disabled'}>المتابعة ←</button></div>`;
    sb.querySelectorAll('input[name=of]').forEach(r => r.onchange = () => { st.offer = r.value; sb.querySelectorAll('.pl').forEach(l => l.classList.toggle('on', l.querySelector('input').checked)); sb.querySelector('[data-ok]').disabled = false; });
    sb.querySelector('[data-back]').onclick = () => next(1);
    sb.querySelector('[data-ok]').onclick = () => next(3);
  }

  // د) الملخص وموقع التركيب ثم بدء الطلب
  function startGo() {
    const b = banks.find(x => x.id === st.bank), o = offerById(st.offer), k = bankCalc(o.price, b, st.term), f = feeItems(o.price, b), tot = f.reduce((t, x) => t + x[1], 0);
    sb.innerHTML = `<h2>تأكيد وبدء الطلب</h2>
      <div class="pick big"><img src="${esc(o.image_url)}" alt=""><div><b style="font-size:18px">${esc(o.title)}</b><div class="small muted">${esc(o.sup?.name)} · <a href="#offer/${o.id}">التفاصيل</a></div><div class="price">${iqd(o.price)}</div></div></div>
      <div class="review"><h3>ما يحسبه النظام لدى ${esc(b.name)}</h3><dl class="kv">
        <dt>مبلغ التمويل</dt><dd>${iqd(o.price)}</dd><dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(k.ins)} × <span class="num">${k.t}</span> شهراً</dd>
        ${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${commPct(b)}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}
        <dt><b>المدفوع قبل إرسال الطلب</b></dt><dd><b>${iqd(tot)}</b></dd><dt>الضمان المطلوب</dt><dd>${G_HINT[guaranteeFor(o.price)]}</dd></dl>
        <p class="small muted" style="margin:6px 0 0">تدفع العمولة والرسوم إلكترونياً في آخر خطوة قبل إرسال الطلب. عمولة البنك المركزي لمرة واحدة تُستوفى لاحقاً في الفرع.</p></div>
      <div class="grid g2 mt" style="gap:12px">
        <div class="field"><label>محافظة موقع التركيب</label><select class="input" data-gv>${govOptions(st.gov || p.governorate || '')}</select></div>
        <div class="field"><label>المدينة / الحي</label><input class="input" data-ct value="${esc(st.city || p.city || '')}" placeholder="مثال: الكرادة"></div></div>
      <div class="card mt" style="box-shadow:none"><h3 style="margin-top:0">عنوان المنظومة ونوع الموقع</h3><div data-site></div></div>
      <p class="small muted">بعد البدء تكمل خمس خطوات قصيرة: التحقق بالسيلفي، رقم «أور»، تأكيد المصرف والمنظومة، الضمان، ثم الدفع والتوقيع. يُحفظ تقدمك تلقائياً.</p>
      <div class="row mt"><button class="btn ghost" data-back>→ تغيير المنظومة</button><span class="sp"></span><button class="btn cyan" data-go disabled>ابدأ الطلب</button></div>`;
    sb.querySelector('[data-back]').onclick = () => next(2);
    // الجلسة 17: عنوان المنظومة بالـGPS ونوع الموقع شرط لبدء الطلب
    const go = sb.querySelector('[data-go]');
    const pk = sitePicker(sb.querySelector('[data-site]'), st.site || {}, { accMax: set.site_gps_accuracy_m || 100, onChange: x => { st.site = { site_type: x.site_type, purpose: x.site_type === 'project' ? x.purpose : 'household', purpose_other: x.purpose_other, site_geo: x.lat != null ? { lat: x.lat, lng: x.lng, acc: x.acc, address: x.address } : null }; go.disabled = !pk.valid(); } });
    go.disabled = !pk.valid();
    go.onclick = async e => {
      const gov = sb.querySelector('[data-gv]').value; if (!gov) return toast('اختر محافظة موقع التركيب', 'bad');
      if (!pk.valid()) return toast('حدّد عنوان المنظومة بالـGPS ونوع الموقع', 'bad');
      const x = pk.state();
      e.target.disabled = true;
      try {
        const a = await rpc(C.sb, 'start_application_bank', { p_offer: o.id, p_bank: b.id, p_term: k.t, p_governorate: gov, p_city: sb.querySelector('[data-ct]').value.trim() || null,
          p_lat: x.lat, p_lng: x.lng });
        try { await rpc(C.sb, 'set_app_site', { p_app: a.id, p: sitePayload(x) }); }
        catch (er) { toast(`بدأ الطلب، لكن تعذّر حفظ العنوان: ${cleanErr(er)} — أعد تحديده من صفحة الطلب`, 'bad'); }
        C.czStart = null; await load(); C.czStep = null; location.hash = '#apply';
        toast('بدأ طلبك — الخطوة الأولى: التحقق من الهوية', 'ok');
      } catch (err) { toast(cleanErr(err), 'bad'); e.target.disabled = false; }
    };
  }
}

// ───────── معالج الطلب: المراحل 1–5 ─────────
const STEPS = [['الهوية', 'التحقق بالسيلفي'], ['«أور»', 'ربط الرقم'], ['المصرف والمنظومة', 'العمولة والقسط'], ['الضمان', 'الكفلاء أو العقار'], ['الدفع والإرسال', 'العمولة والتوقيع']];
async function pageApply(body) {
  const app = S.active;
  if (!app || app.stage > 5) { location.hash = app ? '#home' : '#catalog'; return; }
  C.czVetWait = false;
  if (isVet(app)) return pageApplyVet(body, app);
  const step = Math.min(C.czStep || app.stage, app.stage);
  body.innerHTML = `
    <div class="page-head"><div><h1>طلب تمويل <span class="num">${esc(app.code)}</span></h1><p>${esc(offerById(app.offer_id)?.title || '')} · ${iqd(app.amount)}</p></div><span class="sp"></span><a href="#home" class="btn ghost sm">حفظ والعودة لاحقاً</a></div>
    <ol class="wiz">${STEPS.map(([t, s], i) => { const n = i + 1, done = n < app.stage, cur = n === step;
      return `<li class="${done ? 'done' : ''} ${cur ? 'cur' : ''} ${n <= app.stage ? 'go' : ''}" data-s="${n}"><i>${done ? '✓' : n}</i><div><b>${t}</b><small>${s}</small></div></li>`; }).join('')}</ol>
    <div id="wsite"></div><div class="card wiz-body" id="wb"></div><div id="wdocs"></div>`;
  body.querySelectorAll('.wiz li.go').forEach(li => li.onclick = () => { C.czStep = Number(li.dataset.s); pageApply(body); });
  const wb = body.querySelector('#wb');
  // الجلسة 17: عنوان المنظومة بالـGPS ونوع الموقع — مطلوب قبل إكمال الخطوة الأولى
  sitePanel(body.querySelector('#wsite'), app, { sb: C.sb, accMax: S.ref?.set?.site_gps_accuracy_m || 100, onSaved: async () => { await load(); pageApply(body); } });
  const done = step < app.stage;
  [step1, step2, step3, step4, step5][step - 1](wb, app, done);
  // الجلسة 16: غرض التمويل والمستندات (عرض المورد، ودراسة الجدوى لغير المنزلي) تحت خطوة المصرف والمنظومة
  if (step === 3) docsPanel(body.querySelector('#wdocs'), app);
}

// ───────── الجلسة 16: غرض التمويل والمستندات ─────────
async function docsPanel(box, app) {
  if (!box) return;
  box.innerHTML = '<div class="card wiz-body mt"><div class="spin"></div></div>';
  let d = await loadIntake(C.sb, app);
  if (!d) { box.innerHTML = ''; return; }
  const paint = () => {
    const p = app.purpose || 'household', needFz = p !== 'household';
    const locked = d.refs.some(r => r.status !== 'cancelled');
    const lastRej = d.refs.filter(r => r.status === 'non_conforming').slice(-1)[0];
    const fz = d.docs.filter(x => x.kind === 'feasibility'), q = d.docs.filter(x => x.kind === 'quote').slice(-1)[0];
    const needUpd = (d.ck?.items || []).some(i => i.key === 'feasibility_update' && !i.ok);
    const star = ok => ok ? badge(['مرفق ✓', 'ok']) : '<span class="badge bad">★ مطلوب</span>';
    box.innerHTML = `<div class="card wiz-body mt"><h2>غرض التمويل والمستندات</h2>
      <p class="muted">حدّد الغرض من المنظومة — يطلب النظام المستندات حسب الغرض، ولا يُرسل الطلب قبل إرفاقها.</p>
      ${lastRej ? `<div class="notice warn"><span>⚠</span><span><b>رُفض طلبك سابقاً بسبب دراسة الجدوى</b> — قرار الخبير المعتمد (${esc(lastRej.specialty_label)}) · ${dt(lastRej.decided_at)}
        <div style="white-space:pre-line;margin-top:4px"><b>القرار:</b> ${esc(lastRej.decision_text || '')}${lastRej.notes ? `\n<b>المطلوب:</b> ${esc(lastRej.notes)}` : ''}</div>
        ${needUpd ? '<div class="small mt"><b>أعدّ دراسة جدوى حقيقية بأرقام واقعية وارفعها هنا</b>، ثم أعد إرسال الطلب من الخطوة 5 — يبقى رقم طلبك وبياناته، وتُحفظ دراستك السابقة مع الحديثة.</div>' : '<div class="small mt" style="color:var(--ok)">✓ رُفعت دراسة محدّثة — أعد إرسال الطلب من الخطوة 5.</div>'}</span></div>` : ''}
      <div class="notice"><span>📍</span><span>الغرض حسب نوع الموقع: <b>${esc(app.site_type ? SITE_TYPE[app.site_type] + ' — ' : '')}${esc(purposeText(app))}</b> — ${esc(PURPOSE_HINT[p] || '')}. يُغيَّر من «عنوان المنظومة» أعلى الصفحة.${locked ? ' لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير.' : ''}</span></div>
      <h3 class="mt">1. عرض المورد المقدَّم ${star(!!q)}</h3>
      <p class="small muted" style="margin:0 0 6px">عرض السعر الرسمي من المورد (بختمه وتوقيعه) للمنظومة التي اخترتها — ملف PDF أو صورة حتى 3 ميغابايت.</p>
      ${q ? studiesHtml([q]) : ''}
      <button type="button" class="btn ${q ? 'ghost' : 'cyan'}" data-up="quote">${q ? 'استبدال عرض المورد' : 'رفع عرض المورد'}</button>
      ${needFz ? `<h3 class="mt">2. دراسة الجدوى ${star(fz.length && !needUpd)}</h3>
        <p class="small muted" style="margin:0 0 6px">دراسة بأرقام واقعية: كلفة المشروع، الإيرادات أو التوفير المتوقع في الوقود والكهرباء، كلف التشغيل، وفترة استرداد التمويل — ملف PDF حتى 5 ميغابايت. يدرسها خبير معتمد مختص من خارج المصرف.</p>
        ${fz.length ? studiesHtml(fz, d.refs) : ''}
        <button type="button" class="btn ${fz.length && !needUpd ? 'ghost' : 'cyan'}" data-up="feasibility">${fz.length ? 'رفع دراسة جدوى محدّثة' : 'رفع دراسة الجدوى'}</button>
        ${fz.length ? '<p class="small muted" style="margin:6px 0 0">رفع دراسة جديدة لا يحذف السابقة — تُحفظ معها وتظهر الجديدة بعلامة «محدّثة».</p>' : ''}` : ''}
    </div>`;
    box.querySelectorAll('[data-doc]').forEach(b => b.onclick = () => viewDoc(C.sb, b.dataset.doc));
    box.querySelectorAll('input[name=pp]').forEach(r => r.onchange = async () => {
      try { const x = await rpc(C.sb, 'set_app_purpose', { p_app: app.id, p_purpose: r.value }); app.purpose = x.purpose; if (S.active?.id === app.id) S.active.purpose = x.purpose; d = await loadIntake(C.sb, app); toast(`غرض التمويل: ${PURPOSE[x.purpose]}`, 'ok'); }
      catch (e) { toast(cleanErr(e), 'bad'); }
      paint();
    });
    box.querySelectorAll('[data-up]').forEach(b => b.onclick = async () => {
      const kind = b.dataset.up, f = await pickFile({ maxMB: kind === 'feasibility' ? 5 : 3 });
      if (!f) return;
      b.disabled = true; b.textContent = 'جارِ الرفع…';
      try { await rpc(C.sb, 'add_document', { p_app: app.id, p_kind: kind, p_data: f.data, p_source: 'file', p_meta: f.meta }); d = await loadIntake(C.sb, app); toast(kind === 'quote' ? 'رُفع عرض المورد' : 'رُفعت دراسة الجدوى', 'ok'); }
      catch (e) { toast(cleanErr(e), 'bad'); }
      paint();
    });
  };
  paint();
}
async function saveStep(app, n, data, msg) {
  await rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: n, p_data: data });
  await load();
  C.czStep = null;
  toast(msg || 'تم الحفظ', 'ok');
  if (S.active?.stage > 5) { location.hash = '#home'; return; }
  pageApply(C.root.querySelector('#cz'));
}
const doneBox = (title, rows, onEdit) => {
  const d = el(`<div><div class="done-box"><span class="ok-ic">✓</span><div><b>${title}</b><dl class="kv mt">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl></div></div>
    <div class="row mt"><button class="btn ghost" data-edit>تعديل هذه الخطوة</button><span class="sp"></span><button class="btn cyan" data-next>الخطوة التالية ←</button></div></div>`);
  d.querySelector('[data-edit]').onclick = onEdit;
  d.querySelector('[data-next]').onclick = () => { C.czStep = null; pageApply(C.root.querySelector('#cz')); };
  return d;
};

// 1) التحقق من الهوية بالسيلفي (eKYC — محاكاة المطابقة)
function step1(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('تم التحقق من هويتك', [['رقم البطاقة', `<span class="num">${maskId(app.kyc?.national_id || C.profile.national_id)}</span>`], ['مطابقة الوجه', `<span class="num">${app.kyc?.match_score ?? '—'}%</span>`], ['فحص الحيوية', badge(['ناجح', 'ok'])]], () => step1(wb, app, done, true))); return; }
  const k = { live: false, score: 0 };
  wb.innerHTML = `<h2>التحقق من الهوية</h2><p class="muted">نطابق وجهك مع صورة بطاقتك الوطنية الموحدة ونتأكد أنك حاضر فعلاً (فحص الحيوية).</p>
    <div class="grid g2">
      <div>
        <div class="field"><label>رقم البطاقة الوطنية</label><input class="input" data-nid inputmode="numeric" maxlength="12" dir="ltr" value="${esc(C.profile.national_id || '')}" ${C.profile.national_id ? 'readonly' : ''}></div>
        ${C.profile.id_source === 'ocr' ? `<div class="idnote ok">✓ صُوّرت بطاقتك الوطنية وقُرئت عند إنشاء الحساب${C.profile.id_mrz_verified ? ' وتحققنا منها بالشريط السفلي' : ''}</div>` : '<p class="small muted">أدخل رقمك الوطني كما في البطاقة الموحدة.</p>'}
      </div>
      <div class="selfie">
        <div class="cam"><video playsinline muted autoplay></video><canvas hidden></canvas><img hidden alt="الصورة الملتقطة"><div class="oval"></div><div class="hint">اضغط «بدء الفحص» وضع وجهك داخل الإطار</div></div>
        <div class="row mt"><button class="btn" data-cam>بدء الفحص بالكاميرا</button><button class="btn ghost" data-sim>محاكاة بدون كاميرا</button></div>
        <div class="kyc-res" hidden></div>
      </div>
    </div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok disabled>${ADVANCE_LABEL[1]}</button></div>`;
  const v = wb.querySelector('video'), cv = wb.querySelector('canvas'), im = wb.querySelector('.cam img'), hint = wb.querySelector('.hint'), res = wb.querySelector('.kyc-res'), ok = wb.querySelector('[data-ok]');
  let stream;
  const stop = () => { stream?.getTracks().forEach(t => t.stop()); stream = null; };
  const sequence = async (withCam) => {
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => b.disabled = true);
    const cam = wb.querySelector('.cam'); cam.classList.add('scan');
    for (const h of ['انظر إلى الكاميرا مباشرة', 'ارمش بعينيك مرتين', 'أدر رأسك قليلاً إلى اليمين', 'ثبّت وجهك… جارِ الالتقاط']) { hint.textContent = h; await new Promise(r => setTimeout(r, 1100)); }
    if (withCam && v.videoWidth) { cv.width = v.videoWidth; cv.height = v.videoHeight; cv.getContext('2d').drawImage(v, 0, 0); im.src = cv.toDataURL('image/jpeg', .7); im.hidden = false; v.hidden = true; }
    stop(); cam.classList.remove('scan'); cam.classList.add('ok');
    hint.textContent = 'تم الالتقاط — جارِ المطابقة مع صورة البطاقة…';
    await new Promise(r => setTimeout(r, 1200));
    k.live = true; k.score = Math.round((92 + Math.random() * 7) * 10) / 10;
    hint.textContent = 'اكتمل الفحص';
    res.hidden = false; res.innerHTML = `<div class="row"><span class="ok-ic">✓</span><div><b>مطابقة الوجه <span class="num">${k.score}%</span></b><div class="small muted">فحص الحيوية ناجح · الحد الأدنى للقبول 80%</div></div></div>`;
    ok.disabled = false;
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => { b.disabled = false; });
    wb.querySelector('[data-cam]').textContent = 'إعادة الفحص';
  };
  wb.querySelector('[data-cam]').onclick = async () => {
    im.hidden = true; v.hidden = false; wb.querySelector('.cam').classList.remove('ok');
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } }); v.srcObject = stream; await v.play().catch(() => {}); sequence(true); }
    catch { toast('تعذّر فتح الكاميرا — استخدم «محاكاة بدون كاميرا»', 'bad'); }
  };
  wb.querySelector('[data-sim]').onclick = () => { im.hidden = true; v.hidden = true; wb.querySelector('.cam').classList.add('sim'); sequence(false); };
  ok.onclick = async () => {
    const nid = digits(wb.querySelector('[data-nid]').value);
    if (!/^\d{12}$/.test(nid)) return toast('رقم البطاقة الوطنية 12 رقماً', 'bad');
    ok.disabled = true;
    try { await saveStep(app, 1, { national_id: nid, liveness: k.live, match_score: k.score, card_side: 'front+back', id_source: C.profile.id_source === 'ocr' ? 'ocr' : 'manual' }, 'تم التحقق من هويتك'); }
    catch (e) { toast(cleanErr(e), 'bad'); ok.disabled = false; }
  };
  window.addEventListener('hashchange', stop, { once: true });
}

// 2) رقم «أور» برمز تحقق
function step2(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('رقم «أور» مربوط بطلبك', [['رقم «أور»', `<span class="num">${esc(app.ur_number)}</span>`], ['التحقق النهائي', 'يتحقق منه موظف خدمة العملاء في المصرف (المرحلة 7)']], () => step2(wb, app, done, true))); return; }
  wb.innerHTML = `<h2>ربط رقم «أور»</h2><p class="muted">رقمك في بوابة «أور» الحكومية يربط طلبك ببياناتك الرسمية. نرسل رمز تحقق إلى هاتفك المسجل في «أور».</p>
    <div class="field" style="max-width:420px"><label>رقم «أور» (10 أرقام)</label><input class="input" data-ur inputmode="numeric" maxlength="10" dir="ltr" placeholder="0000000000" value="${esc(app.ur_number || '')}"></div>
    <div class="notice"><span>ℹ</span><span>تجده في تطبيق «أور» ← الملف الشخصي. في نسخة العرض اكتب أي 10 أرقام.</span></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-ok>إرسال رمز التحقق</button></div>`;
  wb.querySelector('[data-ok]').onclick = async () => {
    const ur = digits(wb.querySelector('[data-ur]').value);
    if (!/^\d{10}$/.test(ur)) return toast('رقم «أور» 10 أرقام', 'bad');
    await askOtp({ title: 'رمز التحقق من «أور»', phone: C.profile.phone, purpose: 'لربط حسابك في «أور» بطلب التمويل', verify: c => saveStep(app, 2, { ur_number: ur, otp: c }, 'تم ربط رقم «أور»') });
  };
}

// ───────── المصرف والعمولة (مشتركة بين المرحلتين 3 و5) ─────────
const commPct = b => Number(b?.terms?.commission_pct ?? 1);
const bankCalc = (amount, b, term) => {
  const rate = S.ref.set.cbi_rate + Number(b.terms.margin), t = Math.min(term, b.terms.max_term_months), ins = installment(amount, rate, t);
  return { rate, t, ins, total: ins * t, profit: ins * t - amount, comm: Math.round(amount * commPct(b) / 100) };
};
const feeItems = (amount, b) => [['عمولة المصرف', Math.round(amount * commPct(b) / 100), true], ['رسم دراسة الملف', Number(b.terms.file_fee || 0)],
  ['أجور الكشف الموقعي', Number(S.ref.set.inspection_fee || 0)], ['عمولة المنصة', Number(S.ref.set.platform_fee || 0)]];
const chosenBank = app => S.banks.find(b => b.id === (app.bank_choice?.bank_id || app.bank_id));

// 3) المصرف ثم المنظومة المعتمدة لديه: النظام يحسب السعر والقسط وعمولة المصرف حسب نسبته
function step3(wb, app, done, edit) {
  const set = S.ref.set, banks = S.banks.filter(b => b.terms);
  if (done && !edit && app.bank_choice) {
    const o = offerById(app.offer_id), b = chosenBank(app), c = b && bankCalc(app.amount, b, app.bank_choice.term_months || 60);
    wb.innerHTML = ''; wb.appendChild(doneBox('المصرف والمنظومة مثبّتان', [['المصرف', esc(b?.name || '—')], ['المنظومة', esc(o?.title)], ['السعر', iqd(app.price)],
      ['عمولة المصرف', c ? `${iqd(c.comm)} <span class="muted small">(${commPct(b)}% — تُدفع قبل الإرسال)</span>` : '—'], ['القسط الشهري', c ? `${iqd(c.ins)} × <span class="num">${c.t}</span> شهراً` : '—'],
      ['الضمان المطلوب', esc(GUARANTEE[app.guarantee_type])]], () => step3(wb, app, done, true))); return;
  }
  let of = app.offer_id, term = Math.min(app.bank_choice?.term_months || app.term_months || 60, set.term_max_months);
  let sel = app.bank_choice?.bank_id || banks.find(b => b.open && accepts(b, offerById(of)?.supplier_id))?.id;
  const paint = () => {
    const sb_ = banks.find(b => b.id === sel), list = sb_ ? S.offers.filter(x => accepts(sb_, x.supplier_id)) : [];
    const o = offerById(of), okO = !!(sb_ && o && accepts(sb_, o.supplier_id)), amt = o?.price || app.amount, g = guaranteeFor(amt), c = okO && bankCalc(amt, sb_, term);
    wb.innerHTML = `<h2>المصرف والمنظومة</h2><p class="muted">اختر المصرف أولاً، ثم منظومة من الموردين المعتمدين لديه — يحسب النظام القسط وعمولة المصرف حسب النسبة التي حددها المصرف.</p>
      <h3>1. المصرف ومدة السداد</h3>
      <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${term}</span> شهراً (<span class="num">${(term / 12).toFixed(1)}</span> سنة)</b></div>
      <input type="range" class="range" min="12" max="${set.term_max_months}" step="6" value="${term}" aria-label="مدة السداد">
      <div class="bcards">${banks.map(b => { const k = bankCalc(amt, b, term); return `<label class="bcard ${b.id === sel ? 'on' : ''} ${b.open ? '' : 'off'}">
        <input type="radio" name="bk" value="${b.id}" ${b.id === sel ? 'checked' : ''} ${b.open ? '' : 'disabled'}>
        <div class="row"><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i><b>${esc(b.name)}</b><span class="sp"></span>${b.is_islamic ? '<span class="badge info">مرابحة</span>' : ''}</div>
        ${b.open ? `<dl class="kv small"><dt>عمولة المصرف</dt><dd><b class="cm">${iqd(k.comm)}</b> <span class="num">(${commPct(b)}%)</span></dd><dt>${b.is_islamic ? 'نسبة الربح' : 'النسبة السنوية'}</dt><dd class="num">${k.rate.toFixed(2)}%</dd><dt>رسوم الملف</dt><dd>${iqd(b.terms.file_fee)}</dd><dt>مدة الدراسة</dt><dd><span class="num">${b.terms.processing_days}</span> أيام عمل</dd></dl>
        ${o && !accepts(b, o.supplier_id) ? '<div class="small" style="color:var(--warn)">لا يتعامل مع مورد منظومتك الحالية</div>' : ''}` : '<div class="small muted mt">لا يستقبل طلبات عبر المنصة حالياً</div>'}
      </label>`; }).join('')}</div>
      <h3 class="mt">2. المنظومة ${sb_ ? `<span class="small muted">— المعتمدة لدى ${esc(sb_.name)}</span>` : ''}</h3>
      ${o && sb_ && !okO ? `<div class="notice warn">${esc(sb_.name)} لا يتعامل مع مورد منظومتك الحالية (${esc(o.sup?.name)}) — اختر منظومة من القائمة أو مصرفاً آخر.</div>` : ''}
      <div class="pick-list">${S.ref.tiers.map(t => { const os = list.filter(x => x.tier_id === t.id); if (!os.length) return '';
        return `<div class="pl-h"><b class="num">${num(t.kw)} kW</b> <span class="small muted">— ${esc(t.loads)}</span></div>${os.map(x => { const k = bankCalc(x.price, sb_, term);
          return `<label class="pl ${x.id === of ? 'on' : ''}"><input type="radio" name="of" value="${x.id}" ${x.id === of ? 'checked' : ''}><img src="${esc(x.image_url)}" alt=""><div><b>${esc(x.sup?.name)}</b><div class="small">${stars(x.rating, 12)} <span class="num">${x.rating.toFixed(1)}</span> · ${G_HINT[guaranteeFor(x.price)]}</div><div class="small muted">قسط ${iqd(k.ins)} · عمولة ${iqd(k.comm)}</div></div><span class="sp"></span><b class="small">${iqd(x.price)}</b></label>`; }).join('')}`; }).join('') || '<div class="empty">اختر مصرفاً لعرض منظوماته المعتمدة.</div>'}</div>
      ${c ? `<div class="review"><h3>ما يحسبه النظام</h3><dl class="kv"><dt>سعر المنظومة (مبلغ التمويل)</dt><dd>${iqd(amt)}</dd>
        <dt>عمولة ${esc(sb_.name)} (<span class="num">${commPct(sb_)}%</span>)</dt><dd><b class="cm">${iqd(c.comm)}</b> <span class="muted small">واجبة الدفع قبل إرسال الطلب</span></dd>
        <dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(c.ins)} × <span class="num">${c.t}</span> شهراً</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[g]}${g !== app.guarantee_type ? ' <span class="badge warn">تغيّر — ستعيد خطوة الضمان</span>' : ''}</dd></dl></div>` : ''}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok ${c ? '' : 'disabled'}>تثبيت المصرف والمنظومة</button></div>`;
    wb.querySelector('.range').oninput = e => { term = Number(e.target.value); paint(); wb.querySelector('.range').focus(); };
    wb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { sel = r.value; paint(); });
    wb.querySelectorAll('input[name=of]').forEach(r => r.onchange = () => { of = r.value; paint(); });
    wb.querySelector('[data-ok]').onclick = async e => {
      e.target.disabled = true;
      try { await saveStep(app, 3, { ...(of !== app.offer_id ? { offer_id: of } : {}), bank_id: sel, term_months: c.t }, 'تم تثبيت المصرف والمنظومة'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  paint();
}

// 4) الضمان: كفلاء بموافقة OTP أو رهن عقار
function step4(wb, app, done, edit) {
  const vet = isVet(app);
  // المشروع البيطري: حدود ضمان المبادرة، والقسط الفعلي بعد السماح
  const set = vet ? { ...S.ref.set, guarantee_t1: S.ref.set.vet_guarantee_t1, guarantee_t2: S.ref.set.vet_guarantee_t2 } : S.ref.set, gt = app.guarantee_type;
  const est = vet ? Number(app.monthly_installment || 0) : installment(app.amount, set.cbi_rate + set.margin_max, 60), need = Math.ceil(est * set.salary_safety);
  if (done && !edit) {
    const g = app.guarantee || {};
    const rows = gt === 'mortgage' ? [['نوع الضمان', 'رهن عقار'], ['السند', `<span class="num">${esc(g.deed_no)}</span>`], ['القيمة المرجعية', iqd(g.ref_value)], ['نسبة التمويل للقيمة', `<span class="num">${g.ltv}%</span>`]]
      : [['نوع الضمان', esc(GUARANTEE[gt])], ...(g.guarantors || []).map((x, i) => [`الكفيل ${i + 1}`, `${esc(x.name)} · ${esc(x.employer)} · ${badge(['وافق برمز التحقق', 'ok'])}`]), ['مجموع الرواتب', iqd(g.total_salary)]];
    wb.innerHTML = ''; wb.appendChild(doneBox('الضمان مؤكد', rows, () => step4(wb, app, done, true))); return;
  }
  const rules = `<div class="rules">${[['single_salary', `حتى ${num(set.guarantee_t1 / 1e6)} مليون`, 'كفيل واحد موظف'], ['multi_salary', `حتى ${num(set.guarantee_t2 / 1e6)} مليون`, 'كفيلان موظفان'], ['mortgage', `أكثر من ${num(set.guarantee_t2 / 1e6)} مليون`, 'رهن عقار']].map(([k, a, b]) => `<div class="${k === gt ? 'on' : ''}"><small>${a}</small><b>${b}</b></div>`).join('')}</div>`;
  if (gt === 'mortgage') return step4Mortgage(wb, app, rules);
  const min = gt === 'single_salary' ? 1 : 2;
  const list = (app.guarantee?.guarantors || []).map(g => ({ ...g, otp: null }));
  while (list.length < min) list.push({ name: '', phone: '', employer: '', salary: '', relation: 'قريب', otp: null });
  wb.innerHTML = `<h2>الضمان وموافقة الكفلاء</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب <b>${G_HINT[gt]}</b>. كل كفيل يوافق برمز تحقق يصله على هاتفه.</p>${rules}
    <div data-gs></div>
    <div class="cover"><div class="row"><span class="small">مجموع رواتب الكفلاء مقابل المطلوب (${vet ? 'القسط' : 'القسط التقديري'} ${iqd(est)} × <span class="num">${set.salary_safety}</span>)</span><span class="sp"></span><b data-sum></b></div><div class="bar"><i data-bar></i></div></div>
    <div class="row mt"><button class="btn ghost" data-add>＋ إضافة كفيل</button><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const gs = wb.querySelector('[data-gs]');
  const paint = () => {
    gs.innerHTML = list.map((g, i) => `<fieldset class="gcard ${g.otp ? 'ok' : ''}" data-i="${i}"><legend>الكفيل ${i + 1} ${g.otp ? badge(['وافق', 'ok']) : badge(['بانتظار الموافقة', 'warn'])}</legend>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>الاسم الثلاثي</label><input class="input" data-k="name" value="${esc(g.name)}"></div>
        <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(g.phone)}"></div>
        <div class="field"><label>جهة العمل (دائرة حكومية أو شركة)</label><input class="input" data-k="employer" value="${esc(g.employer)}"></div>
        <div class="field"><label>الراتب الشهري (د.ع)</label><input class="input" data-k="salary" inputmode="numeric" dir="ltr" value="${esc(g.salary)}"></div>
        <div class="field"><label>صلة القرابة</label><select class="input" data-k="relation">${['قريب', 'زميل عمل', 'صديق', 'جار'].map(r => `<option ${r === g.relation ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
        <div class="field" style="justify-content:flex-end"><div class="row">${g.otp ? '<span class="ok-ic sm">✓</span><span class="small">وافق الكفيل على الكفالة</span>' : `<button type="button" class="btn sm" data-consent="${i}">إرسال رمز الموافقة للكفيل</button>`}${list.length > min ? `<span class="sp"></span><button type="button" class="linkbtn" data-rm="${i}">حذف</button>` : ''}</div></div>
      </div></fieldset>`).join('');
    gs.querySelectorAll('[data-k]').forEach(inp => inp.oninput = inp.onchange = () => {
      const i = Number(inp.closest('[data-i]').dataset.i), k = inp.dataset.k;
      const old = list[i][k]; list[i][k] = inp.value;
      if (k === 'phone' && list[i].otp && normPhone(old) !== normPhone(inp.value)) { list[i].otp = null; paint(); }
      sum();
    });
    gs.querySelectorAll('[data-consent]').forEach(b => b.onclick = async () => {
      const g = list[Number(b.dataset.consent)];
      const ph = normPhone(g.phone);
      if (g.name.trim().split(/\s+/).length < 3) return toast('اكتب الاسم الثلاثي للكفيل', 'bad');
      if (!validPhone(ph)) return toast('رقم هاتف الكفيل غير صحيح', 'bad');
      if (ph === C.profile.phone) return toast('لا يكفل المتقدم نفسه', 'bad');
      if (list.some(x => x !== g && normPhone(x.phone) === ph)) return toast('رقم هاتف مكرر بين الكفلاء', 'bad');
      const c = await askOtp({ title: `موافقة الكفيل ${g.name.split(' ')[0]}`, phone: ph, purpose: `يوافق على كفالة ${C.profile.full_name} في تمويل ${num(app.amount)} د.ع`, verify: serverOtp(C.sb, ph, 'guarantor') });
      if (c) { g.phone = ph; g.otp = c; paint(); toast('سُجّلت موافقة الكفيل', 'ok'); }
    });
    gs.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { list.splice(Number(b.dataset.rm), 1); paint(); });
    wb.querySelector('[data-add]').hidden = list.length >= 3;
    sum();
  };
  const sum = () => {
    const t = list.reduce((s, g) => s + (Number(digits(g.salary)) || 0), 0);
    wb.querySelector('[data-sum]').innerHTML = `${iqd(t)} / ${iqd(need)}`;
    const b = wb.querySelector('[data-bar]'); b.style.width = Math.min(100, t / need * 100) + '%'; b.style.background = t >= need ? 'var(--ok)' : 'var(--sun)';
  };
  wb.querySelector('[data-add]').onclick = () => { list.push({ name: '', phone: '', employer: '', salary: '', relation: 'زميل عمل', otp: null }); paint(); };
  wb.querySelector('[data-ok]').onclick = async e => {
    if (list.some(g => !g.otp)) return toast('يلزم أن يوافق كل كفيل برمز التحقق', 'bad');
    e.target.disabled = true;
    try { await saveStep(app, 4, { guarantors: list.map(g => ({ name: g.name.trim(), phone: normPhone(g.phone), employer: g.employer.trim(), salary: Number(digits(g.salary)), relation: g.relation, otp: g.otp })) }, 'تم تأكيد الضمان'); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  paint();
}
// قراءة السند العقاري آلياً عبر خدمة القراءة إن كانت تدعمه (وإلا يُكمل المقترض يدوياً)
async function readDeed(dataUrl) {
  const base = ((window.ALWAH_CONFIG || {}).ocr || '').replace(/\/+$/, ''); if (!base) return null;
  const blob = await (await fetch(dataUrl)).blob(), body = new FormData(); body.append('front', blob, 'deed.jpg');
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 25000);
  try {
    const r = await fetch(base + '/api/v1/documents/property-deed', { method: 'POST', body, signal: ctl.signal });
    if (!r.ok) return null;
    const d = await r.json(), f = d.fields || {}, v = k => String((f[k] && typeof f[k] === 'object' ? f[k].value : f[k]) || '').trim();
    const out = { deed_no: v('deed_no') || v('deed_number'), owner_name: v('owner_name'), owner_national_id: v('owner_national_id').replace(/\D/g, ''),
      district: v('district') || v('muqataa'), land_area: v('land_area').replace(/[^\d.]/g, ''), governorate: v('governorate'), use_type: v('use_type') };
    return out.deed_no || out.owner_name ? out : null;
  } catch { return null; } finally { clearTimeout(t); }
}
const nameKey = n => String(n || '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim().split(' ').slice(0, 3).join(' ');

function step4Mortgage(wb, app, rules) {
  const set = S.ref.set, g = app.guarantee || {}, own0 = app.ownership || {};
  const st = { owner: own0.is_owner === false ? 'other' : own0.is_owner ? 'self' : '', deed: null, poa: null, oid: null, otp: null, read: null };
  wb.innerHTML = `<h2>الضمان: رهن عقار</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب رهن عقار. يحيله المصرف إلكترونياً إلى دائرة التسجيل العقاري للتحقق من خلوه ومطابقة السند، ثم يُؤشَّر الرهن بعد موافقة إدارة المصرف.</p>${rules}
    <div class="card soft mb"><h3>1. صوّر سند العقار</h3><p class="small muted" style="margin-top:0">بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف. نحاول قراءة السند ومطابقته مع بياناتك تلقائياً.</p>
      <div class="doc-row" data-deedbox>${docThumb(null, 'سند العقار')}</div><button type="button" class="btn cyan sm" data-shoot="deed">📷 تصوير السند</button>
      <div class="idbusy" data-deedbusy hidden><i></i><span>جارِ قراءة السند ومطابقته…</span></div><div data-deedres></div></div>
    <div class="card soft mb"><h3>2. علاقتك بالعقار</h3>
      <div class="seg" style="margin-bottom:10px"><button type="button" data-own="self">أنا المالك</button><button type="button" data-own="other">المالك شخص آخر</button></div>
      <div data-other hidden>
        <p class="small muted" style="margin-top:0">يلزم <b>وكالة من مالك العقار بالرهن</b> مصوّرة بالكاميرا، مع بيانات المالك ورقم هاتفه. نرسل للمالك رمز تحقق يُدخله هنا موافقةً على الرهن.</p>
        <div class="grid g2" style="gap:12px">
          <div class="field"><label>صلتك بالمالك</label><select class="input" data-o="relation">${['وكيل عن المالك', 'أب أو أم', 'زوج أو زوجة', 'أخ أو أخت', 'ابن أو ابنة', 'قريب آخر', 'شريك'].map(r => `<option ${r === own0.relation ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
          <div class="field"><label>اسم المالك الثلاثي كما في السند</label><input class="input" data-o="owner_name" value="${esc(own0.is_owner === false ? own0.owner_name || '' : '')}"></div>
          <div class="field"><label>الرقم الوطني للمالك (12 رقماً)</label><input class="input" data-o="owner_national_id" inputmode="numeric" dir="ltr" maxlength="12" value="${esc(own0.is_owner === false ? own0.owner_national_id || '' : '')}"></div>
          <div class="field"><label>رقم هاتف المالك</label><input class="input" data-o="owner_phone" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(own0.owner_phone || '')}"></div>
        </div>
        <div class="doc-row" data-poabox>${docThumb(null, 'وكالة المالك بالرهن')}</div>
        <div class="row" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn sm" data-shoot="poa">📷 تصوير الوكالة</button><button type="button" class="btn ghost sm" data-shoot="owner_id_front">📷 بطاقة المالك (اختياري)</button></div>
        <div class="row mt" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn cyan sm" data-consent>إرسال رمز الموافقة لهاتف المالك</button><span class="small" data-consented></span></div>
      </div></div>
    <div class="card soft mb"><h3>3. بيانات العقار</h3>
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>رقم السند العقاري (القطعة/المقاطعة) كما في الصورة</label><input class="input" data-k="deed_no" value="${esc(g.deed_no || own0.deed_no || '')}" placeholder="مثال: 1452/87 الكرادة"></div>
      <div class="field"><label>المحافظة</label><select class="input" data-k="governorate">${govOptions(app.governorate)}</select></div>
      <div class="field"><label>المنطقة أو المقاطعة</label><input class="input" data-k="district" value=""></div>
      <div class="field"><label>نوع الاستعمال</label><select class="input" data-k="use_type"><option>سكني</option><option>تجاري</option><option>زراعي</option></select></div>
      <div class="field"><label>مساحة الأرض (م²)</label><input class="input" data-k="land_area" inputmode="numeric" dir="ltr"></div>
      <div class="field"><label>القيمة التقديرية (د.ع)</label><input class="input" data-k="estimated_value" inputmode="numeric" dir="ltr" value="${esc(g.ref_value || '')}"></div>
    </div>
    <div class="cover"><div class="row"><span class="small">نسبة التمويل إلى قيمة العقار (الحد الأعلى <span class="num">${set.ltv_max}%</span>)</span><span class="sp"></span><b data-ltv>—</b></div><div class="bar"><i data-bar></i></div></div></div>
    <p class="small muted">تُطابق المنصة اسم المالك ورقمه الوطني مع السجل العقاري إن كان السند مسجلاً، وإلا تطابقها دائرة التسجيل العقاري مع صورة السند.</p>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const val = () => Number(digits(wb.querySelector('[data-k=estimated_value]').value));
  const upd = () => { const v = val(), r = v ? app.amount / v * 100 : 0, b = wb.querySelector('[data-bar]');
    wb.querySelector('[data-ltv]').innerHTML = v ? `<span class="num">${r.toFixed(1)}%</span>` : '—'; b.style.width = Math.min(100, r / set.ltv_max * 100) + '%'; b.style.background = r <= set.ltv_max ? 'var(--ok)' : 'var(--bad)'; };
  wb.querySelector('[data-k=estimated_value]').oninput = upd; upd();
  const paintOwn = () => {
    wb.querySelectorAll('[data-own]').forEach(b => b.classList.toggle('on', b.dataset.own === st.owner));
    wb.querySelector('[data-other]').hidden = st.owner !== 'other';
    wb.querySelector('[data-consented]').innerHTML = st.otp ? '<span class="ok-ic sm">✓</span> وافق المالك على الرهن' : '';
  };
  wb.querySelectorAll('[data-own]').forEach(b => b.onclick = () => { st.owner = b.dataset.own; paintOwn(); });
  paintOwn();
  const setK = (k, v) => { const i = wb.querySelector(`[data-k=${k}]`); if (!i || !v) return; if (i.tagName === 'SELECT') { const o = [...i.options].find(x => x.text === v || x.value === v); if (o) i.value = o.value; } else i.value = v; };
  const setO = (k, v) => { const i = wb.querySelector(`[data-o=${k}]`); if (i && v) i.value = v; };
  // بعد تصوير السند: قراءة آلية ثم مطابقة اسم المالك مع اسم المقترض
  const afterDeed = async shot => {
    const busy = wb.querySelector('[data-deedbusy]'), res = wb.querySelector('[data-deedres]');
    busy.hidden = false; res.innerHTML = '';
    const r = await readDeed(shot.data); busy.hidden = true; st.read = r;
    if (!r) { res.innerHTML = '<div class="notice warn" style="margin:10px 0 0">تعذرت قراءة السند تلقائياً — حدّد علاقتك بالعقار واكتب رقم السند كما في الصورة.</div>'; return; }
    ['deed_no', 'district', 'land_area', 'use_type', 'governorate'].forEach(k => setK(k, r[k]));
    const mine = r.owner_name && nameKey(r.owner_name) === nameKey(C.profile.full_name) && (!r.owner_national_id || r.owner_national_id === C.profile.national_id);
    if (mine) { st.owner = 'self'; res.innerHTML = `<div class="idnote ok" style="margin:10px 0 0">✓ قرأنا السند <b class="num">${esc(r.deed_no)}</b> — العقار مسجل باسمك</div>`; }
    else {
      st.owner = 'other'; setO('owner_name', r.owner_name); setO('owner_national_id', r.owner_national_id);
      res.innerHTML = `<div class="notice warn" style="margin:10px 0 0">قرأنا السند <b class="num">${esc(r.deed_no || '')}</b>${r.owner_name ? ` باسم <b>${esc(r.owner_name)}</b>` : ''} — لا يطابق اسمك. صوّر وكالة المالك بالرهن وأكمل بياناته وموافقته.</div>`;
    }
    paintOwn();
  };
  const LBL = { deed: 'سند العقار', poa: 'وكالة المالك بالرهن', owner_id_front: 'البطاقة الوطنية للمالك' };
  wb.querySelectorAll('[data-shoot]').forEach(b => b.onclick = async () => {
    const kind = b.dataset.shoot;
    const shot = await cameraCapture({ title: kind === 'deed' ? 'صوّر سند العقار' : kind === 'poa' ? 'صوّر وكالة المالك بالرهن (الصفحة كاملة)' : 'صوّر وجه البطاقة الوطنية لمالك العقار', ratio: kind === 'owner_id_front' ? 1.586 : 0.72 });
    if (!shot) return;
    b.disabled = true;
    try {
      await rpc(C.sb, 'add_document', { p_app: app.id, p_kind: kind, p_data: shot.data, p_source: 'camera', p_meta: shot.meta });
      st[{ deed: 'deed', poa: 'poa', owner_id_front: 'oid' }[kind]] = shot;
      const box = wb.querySelector(kind === 'deed' ? '[data-deedbox]' : '[data-poabox]');
      if (kind === 'owner_id_front') box.insertAdjacentHTML('beforeend', docThumb({ ...shot, source: 'camera' }, LBL[kind]));
      else box.innerHTML = docThumb({ ...shot, source: 'camera' }, LBL[kind]) + (kind === 'poa' && st.oid ? docThumb({ ...st.oid, source: 'camera' }, LBL.owner_id_front) : '');
      toast('حُفظت الصورة مع طلبك', 'ok');
      if (kind === 'deed') afterDeed(shot);
    } catch (e) { toast(cleanErr(e), 'bad'); }
    b.disabled = false;
  });
  const ownerData = () => { const d = {}; wb.querySelectorAll('[data-o]').forEach(i => d[i.dataset.o] = i.value.trim()); d.owner_national_id = digits(d.owner_national_id); d.owner_phone = normPhone(d.owner_phone); return d; };
  wb.querySelector('[data-consent]').onclick = async () => {
    const d = ownerData();
    if (!st.poa) return toast('صوّر وكالة المالك بالرهن أولاً', 'bad');
    if (d.owner_name.split(/\s+/).length < 3) return toast('اكتب اسم المالك الثلاثي', 'bad');
    if (!/^\d{12}$/.test(d.owner_national_id)) return toast('الرقم الوطني للمالك 12 رقماً', 'bad');
    if (!validPhone(d.owner_phone)) return toast('رقم هاتف المالك غير صحيح', 'bad');
    if (d.owner_phone === C.profile.phone) return toast('هذا رقم هاتفك — اكتب رقم هاتف المالك', 'bad');
    const c = await askOtp({ title: 'موافقة مالك العقار', phone: d.owner_phone, purpose: `يوافق على رهن عقاره ضماناً لتمويل ${C.profile.full_name} بمبلغ ${num(app.amount)} د.ع`, verify: serverOtp(C.sb, d.owner_phone, 'owner') });
    if (c) { st.otp = c; paintOwn(); }
  };
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = {}; wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    d.estimated_value = String(val()); d.land_area = digits(d.land_area);
    if (!st.deed && !app.ownership) return toast('صوّر سند العقار بكاميرا الهاتف أولاً', 'bad');
    if (!st.owner) return toast('حدّد علاقتك بالعقار: أنت المالك أم شخص آخر؟', 'bad');
    if (!d.deed_no) return toast('اكتب رقم السند العقاري', 'bad');
    const od = st.owner === 'other' ? ownerData() : {};
    if (st.owner === 'other' && !st.poa && !(app.ownership && app.ownership.is_owner === false)) return toast('صوّر وكالة المالك بالرهن', 'bad');
    if (st.owner === 'other' && !st.otp) return toast('يلزم موافقة مالك العقار برمز التحقق', 'bad');
    e.target.disabled = true;
    try {
      await rpc(C.sb, 'set_property_ownership', { p_app: app.id, p_data: { is_owner: st.owner === 'self', deed_no: d.deed_no, ...od, owner_otp: st.otp, auto_read: !!st.read } });
      await saveStep(app, 4, d, 'تم تأكيد ضمان الرهن');
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 5) دفع عمولة المصرف والرسوم ثم التوقيع الإلكتروني وإرسال الطلب
function step5(wb, app) {
  const o = offerById(app.offer_id), bk = chosenBank(app);
  if (!bk || !bk.terms) {
    wb.innerHTML = `<h2>الدفع والإرسال</h2><div class="notice warn">لم يُختر المصرف بعد — اختره مع المنظومة لنحسب العمولة.</div><div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>اختيار المصرف</button></div>`;
    wb.querySelector('[data-go]').onclick = () => { C.czStep = 3; pageApply(C.root.querySelector('#cz')); }; return;
  }
  const c = bankCalc(app.amount, bk, app.bank_choice?.term_months || 60), f = feeItems(app.amount, bk), tot = f.reduce((t, x) => t + x[1], 0);
  let paid = [], method = 'zaincash', ck = null;
  C.sb.from('payments').select('*').eq('application_id', app.id).then(r => { paid = r.data || []; paint(); });
  // الجلسة 16: قائمة التدقيق — كل نقص بنجمة حمراء، ولا يُرسل الطلب ناقصاً
  rpc(C.sb, 'intake_checklist', { p_app: app.id }).then(x => { ck = x; paint(); }).catch(() => {});
  const blockers = () => (ck?.items || []).filter(i => !i.ok && !['payment', 'signed'].includes(i.key));
  const ckBlock = () => !ck?.applies ? '' : `<div class="review"><h3>قائمة التدقيق قبل الإرسال ${blockers().length ? `<span class="badge bad">★ ${blockers().length} نواقص</span>` : badge(['مكتملة', 'ok'])}</h3>
    ${app.returned_from === 6 && app.return_note ? `<div class="notice warn" style="margin:0 0 8px"><span>⚠</span><span><b>${app.feasibility_rejections && (app.intake_missing || []).some(i => i.key === 'feasibility_update') ? 'رُفض طلبك بسبب دراسة الجدوى' : 'أعاد المصرف طلبك لإكمال النواقص'}</b><div style="white-space:pre-line">${esc(app.return_note)}</div></span></div>` : ''}
    ${checklistHtml(ck, { borrower: true, skip: ['payment', 'signed'] })}
    ${blockers().length ? '<p class="small" style="color:var(--bad);margin:6px 0 0">أكمل البنود ذات النجمة الحمراء ★ — لا يقبل المصرف الطلب ناقص البيانات.</p>' : ''}</div>`;
  const paint = () => {
    const p = paid.find(x => x.bank_id === bk.id && x.status === 'paid');
    wb.innerHTML = `<h2>دفع العمولة وإرسال الطلب</h2><p class="muted">يُرسل طلبك إلى ${esc(bk.name)} بعد دفع عمولة المصرف والرسوم، ثم توقيعك الإلكتروني برمز التحقق.</p>
      ${ckBlock()}
      <div class="review"><h3>ملخص طلبك</h3><dl class="kv">
        <dt>المنظومة</dt><dd>${esc(o?.title)}</dd><dt>غرض التمويل</dt><dd>${esc(PURPOSE[app.purpose] || 'منزلي')}</dd><dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])} ${badge(['مؤكد', 'ok'])}</dd>
        <dt>المصرف</dt><dd>${esc(bk.name)} <button type="button" class="linkbtn small" data-chg>تغيير</button></dd><dt>المدة</dt><dd><span class="num">${c.t}</span> شهراً</dd>
        <dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(c.ins)}</dd><dt>أول قسط</dt><dd>بعد شهر من صرف المبلغ للمورد</dd></dl></div>
      <div class="review pay ${p ? 'done' : ''}"><h3>1. العمولة والرسوم ${p ? '<span class="badge ok">مدفوعة</span>' : ''}</h3>
        <dl class="kv">${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${commPct(bk)}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(tot)}</b></dd></dl>
        ${p ? `<p class="small muted" style="margin:6px 0 0">رقم العملية <b class="num">${esc(p.ref)}</b> · ${esc(PAY_LABEL[p.method] || p.method)} · ${dt(p.paid_at)} · <button type="button" class="linkbtn" data-rcpt>عرض الإيصال</button></p>` : `
        <div class="small" style="margin-top:8px"><b>اختر طريقة الدفع</b></div>
        <div class="paygrid">${PAY_METHODS.map(([k, t, col]) => `<button type="button" data-m="${k}" class="${k === method ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>
        <div class="row mt"><span class="small muted">عمولة البنك المركزي (لمرة واحدة) تُستوفى لاحقاً في الفرع مع فتح الإضبارة.</span><span class="sp"></span><button type="button" class="btn warn" data-pay>ادفع ${iqd(tot)}</button></div>`}</div>
      <div class="review"><h3>2. الإقرار والتوقيع الإلكتروني</h3>
        <label class="check"><input type="checkbox" data-ack> أقرّ بصحة البيانات، وأفوّض المصرف بالاستعلام عن الضمان، وأوافق على استقطاع القسط الشهري.</label>
        <p class="small muted" style="margin:6px 0 0">${p ? 'العمولة مدفوعة — اضغط الزر أدناه ووقّع برمز التحقق.' : 'ضع علامة الإقرار ثم اضغط الزر أدناه: ندفع العمولة بالطريقة التي اخترتها، ثم توقّع برمز التحقق ويُرسل الطلب.'}</p></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${p ? 'التوقيع وإرسال طلب التمويل' : `ادفع ${iqd(tot)} ووقّع وأرسل الطلب`}</button></div>`;
    wb.querySelector('[data-chg]').onclick = () => { C.czStep = 3; pageApply(C.root.querySelector('#cz')); };
    wb.querySelectorAll('[data-fix]').forEach(b => b.onclick = () => { if (b.dataset.fix === 'profile') { location.hash = '#profile'; return; } C.czStep = Number(b.dataset.fix); pageApply(C.root.querySelector('#cz')); });
    const rc = wb.querySelector('[data-rcpt]'); if (rc) rc.onclick = () => receipt(app, p);
    wb.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; wb.querySelectorAll('[data-m]').forEach(x => x.classList.toggle('on', x === b)); });
    const doPay = async () => {
      const code = await askOtp({ title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: C.profile.phone, purpose: `دفع ${num(tot)} د.ع (عمولة ${bk.name} والرسوم)`,
        verify: async c2 => { const x = await rpc(C.sb, 'pay_application_fees', { p_app: app.id, p_bank: bk.id, p_method: method, p_otp: c2 }); paid = paid.filter(y => y.id !== x.id).concat(x); } });
      return !!code;
    };
    const pb = wb.querySelector('[data-pay]');
    if (pb) pb.onclick = async () => { const ack = wb.querySelector('[data-ack]')?.checked; if (await doPay()) { toast('تم الدفع — وقّع الآن لإرسال الطلب', 'ok'); paint(); if (ack) wb.querySelector('[data-ack]').checked = true; } };
    wb.querySelector('[data-ok]').onclick = async () => {
      if (blockers().length) return toast(`أكمل النواقص أولاً: ${blockers().map(i => i.label).join('، ')}`, 'bad');
      if (!wb.querySelector('[data-ack]')?.checked) return toast('ضع علامة ✓ على الإقرار أولاً', 'bad');
      if (!paid.find(x => x.bank_id === bk.id && x.status === 'paid')) {
        if (!(await doPay())) return;
        toast('تم الدفع — بقي التوقيع', 'ok'); paint(); wb.querySelector('[data-ack]').checked = true;
      }
      const code = await askOtp({ title: 'التوقيع الإلكتروني', phone: C.profile.phone, purpose: `توقيع طلب تمويل ${num(app.amount)} د.ع لدى ${bk.name}`,
        verify: c2 => rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: 5, p_data: { bank_id: bk.id, term_months: c.t, otp: c2 } }) });
      if (!code) return;
      await load(); C.czStep = null;
      const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h2>أُرسل طلبك إلى ${esc(bk.name)}</h2>
        <p class="muted">رقم الطلب <b class="num">${esc(app.code)}</b> — الآن لدى <b>خدمة الزبائن في الفرع</b> لتدقيق المستمسكات والاستعلام الائتماني، ثم يفتح لك المصرف حساباً باسمك. ستتابع كل مرحلة لحظة بلحظة من «طلبي».</p>
        <a class="btn cyan" href="#home" data-x>متابعة طلبي</a></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      location.hash = '#home';
    };
  };
  paint();
}

// إيصال الدفع الإلكتروني للعمولة والرسوم
function receipt(app, p) {
  const bank = C.orgs.find(o => o.id === p.bank_id);
  const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h3 style="margin:4px 0">إيصال دفع إلكتروني</h3><p class="muted small" style="margin:0">ألواح · ${esc(bank?.name || '')}</p></div>
    <dl class="kv mt"><dt>رقم العملية</dt><dd><b class="num">${esc(p.ref)}</b></dd><dt>رقم الطلب</dt><dd><span class="num">${esc(app.code)}</span></dd><dt>المقترض</dt><dd>${esc(C.profile.full_name)}</dd>
      ${(p.items || []).map(i => `<dt>${esc(i.label)}</dt><dd>${iqd(i.amount)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(p.amount)}</b></dd>
      <dt>طريقة الدفع</dt><dd>${esc(PAY_LABEL[p.method] || p.method)}</dd><dt>التاريخ</dt><dd>${dt(p.paid_at)}</dd></dl>
    <p class="small muted">يودع المصرف هذه المبالغ في إضبارتك (المرحلة 10). عمولة البنك المركزي لمرة واحدة تُستوفى في الفرع.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-pr>طباعة</button><button class="btn cyan" data-x>إغلاق</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-pr]').onclick = () => window.print();
}

// ───────── التقييم بعد التركيب ─────────
function rateDialog(app) {
  const v = { rating: 0, quality: 0, install: 0, service: 0 };
  const row = (k, l) => `<div class="rate-row"><span>${l}</span><span class="sp"></span><span class="rate" data-r="${k}">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-n="${n}" aria-label="${n}">★</button>`).join('')}</span></div>`;
  const m = modal(`<h3>قيّم منظومتك</h3><p class="muted small">يظهر تقييمك باسمك المختصر ومحافظتك.</p>
    ${row('rating', '<b>التقييم العام</b>')}${row('quality', 'جودة المنظومة')}${row('install', 'التركيب')}${row('service', 'خدمة المورد')}
    <div class="field mt"><label>تعليقك (اختياري)</label><textarea class="input" rows="3" data-c maxlength="400" placeholder="كيف الأداء؟ هل كفت البطاريات الليل؟"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-s>نشر التقييم</button></div>`);
  m.el.querySelectorAll('[data-r]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => {
    v[g.dataset.r] = Number(b.dataset.n); g.querySelectorAll('button').forEach(x => x.classList.toggle('on', Number(x.dataset.n) <= v[g.dataset.r]));
  }));
  m.el.querySelector('[data-s]').onclick = async () => {
    if (!v.rating) return toast('اختر التقييم العام', 'bad');
    try { await rpc(C.sb, 'submit_review', { p_app: app.id, p_rating: v.rating, p_quality: v.quality || v.rating, p_install: v.install || v.rating, p_service: v.service || v.rating, p_comment: m.el.querySelector('[data-c]').value }); m.close(); toast('شكراً — نُشر تقييمك', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الملف الشخصي للمقترض ─────────
function pageProfile(body) {
  const p = C.profile, set = S.ref.set;
  const fin = S.apps.find(a => a.bank_id && a.monthly_installment && !['cancelled', 'rejected'].includes(a.status));
  const age = p.birth_date ? Math.floor((Date.now() - new Date(p.birth_date)) / (365.25 * 864e5)) : null;
  const myReviews = S.reviews.filter(r => r.citizen_id === p.id);
  body.innerHTML = `
    <div class="prof-head card">
      <div class="av xl">${esc(p.full_name.trim()[0])}</div>
      <div><h1 style="font-size:22px">${esc(p.full_name)}</h1>
        <div class="row" style="gap:8px;margin-top:4px">${p.kyc_status === 'verified' ? badge(['هوية موثّقة بالسيلفي', 'ok']) : badge(['الهوية غير موثّقة بعد', 'warn'])}<span class="small" style="color:#9FB4D6">عضو منذ ${dt(p.created_at).split('،')[0]}</span></div></div>
      <span class="sp"></span>
      <div class="prof-kpis"><div><b class="num">${S.apps.length}</b><span>طلب</span></div><div><b>${fin ? iqd(fin.monthly_installment) : '—'}</b><span>القسط الشهري</span></div><div><b class="num">${myReviews.length}</b><span>تقييم</span></div></div>
    </div>
    <div class="grid g2 mt">
      <div class="card"><h3>البيانات الشخصية<span class="sp"></span><span class="badge muted">من البطاقة الوطنية</span></h3>
        <dl class="kv"><dt>الاسم</dt><dd>${esc(p.full_name)}</dd><dt>رقم البطاقة</dt><dd><span class="num">${esc(maskId(p.national_id))}</span></dd>
          <dt>تاريخ الميلاد</dt><dd>${p.birth_date ? `<span class="num">${esc(p.birth_date)}</span> (<span class="num">${age}</span> سنة)` : '—'}</dd>
          <dt>رقم الهاتف</dt><dd><span class="num">${esc(p.phone || '—')}</span> <button class="linkbtn" data-phone>تغيير</button></dd>
          <dt>اسم الدخول</dt><dd><span class="num">${esc(p.username)}</span></dd>
          <dt>التحقق</dt><dd>${p.kyc_at ? `${dt(p.kyc_at)}` : 'يتم في أول خطوة من طلب التمويل'}</dd></dl>
        <p class="small muted" style="margin:10px 0 0">الاسم ورقم البطاقة لا يُعدَّلان بعد التحقق من الهوية.</p></div>
      <form class="card" data-f="contact" novalidate><h3>العنوان والتواصل</h3>
        <div class="grid g2" style="gap:10px">
          <div class="field"><label>المحافظة</label><select class="input" name="governorate">${govOptions(p.governorate || '')}</select></div>
          <div class="field"><label>المدينة / القضاء</label><input class="input" name="city" value="${esc(p.city || '')}"></div>
        </div>
        <div class="field"><label>العنوان التفصيلي</label><input class="input" name="address" value="${esc(p.address || '')}" placeholder="المحلة، الزقاق، الدار"></div>
        <div class="field"><label>البريد الإلكتروني (اختياري)</label><input class="input" name="email" type="email" dir="ltr" value="${esc(p.email || '')}"></div>
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="work" novalidate><h3>العمل والدخل</h3>
        <div class="field"><label>جهة العمل</label><input class="input" name="employer" value="${esc(p.employer || '')}" placeholder="دائرة حكومية، شركة، عمل حر"></div>
        <div class="field"><label>الدخل الشهري (د.ع)</label><input class="input" name="monthly_salary" inputmode="numeric" dir="ltr" value="${esc(p.monthly_salary || '')}"></div>
        ${fin && p.monthly_salary ? `<div class="cover"><div class="row"><span class="small">القسط من دخلك</span><span class="sp"></span><b class="num">${(fin.monthly_installment / p.monthly_salary * 100).toFixed(1)}%</b></div><div class="bar"><i style="width:${Math.min(100, fin.monthly_installment / p.monthly_salary * 100)}%;background:${fin.monthly_installment / p.monthly_salary < .35 ? 'var(--ok)' : 'var(--sun)'}"></i></div></div>` : ''}
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="pw" novalidate><h3>الأمان — تغيير كلمة المرور</h3>
        <div class="field"><label>كلمة المرور الحالية</label><input class="input" name="old" type="password" dir="ltr" autocomplete="current-password"></div>
        <div class="field"><label>كلمة المرور الجديدة</label><input class="input" name="nw" type="password" dir="ltr" autocomplete="new-password"><small class="muted">8 أحرف على الأقل، حروف إنجليزية وأرقام</small></div>
        <div class="row"><span class="sp"></span><button class="btn">تغيير كلمة المرور</button></div></form>
    </div>
    <div class="card mt" id="sched"></div>
    <div class="card mt"><h3>طلباتي</h3>${S.apps.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المصرف</th><th>المبلغ</th><th>المرحلة</th><th>الحالة</th></tr></thead><tbody>
      ${S.apps.map(a => `<tr class="click" data-go="${a.id}"><td><b class="num">${esc(a.code)}</b></td><td>${isVet(a) ? 'مشروع بيطري' : `<span class="num">${num(a.kw)}</span> kW`}</td><td>${esc(C.orgs.find(x => x.id === a.bank_id)?.name || '—')}</td><td>${iqd(a.amount)}</td><td><span class="num">${a.stage}</span> / ${C.stages.length}</td><td>${statusBadge(a.status)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">لا طلبات بعد. <a href="#catalog">ابدأ من الكتالوج</a></p>'}</div>
    ${myReviews.length ? `<div class="card mt"><h3>تقييماتي</h3><ul class="rv-list">${myReviews.map(r => `<li><div class="row">${stars(r.rating)}<span class="small muted">${ago(r.created_at)}</span></div>${r.comment ? `<p>${esc(r.comment)}</p>` : ''}</li>`).join('')}</ul></div>` : ''}
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-out>تسجيل الخروج</button></div>`;
  // جدول الأقساط
  const sc = body.querySelector('#sched');
  if (!fin) sc.innerHTML = `<h3>جدول الأقساط</h3><p class="muted">يظهر جدول أقساطك بعد اختيار المصرف وتوقيع الطلب.</p>`;
  else {
    const rate = set.cbi_rate + Number(fin.margin || 0), r = rate / 1200, n = fin.term_months, ins = fin.monthly_installment;
    const start = fin.status === 'completed' ? new Date(fin.updated_at) : null;
    const paid = start ? Math.max(0, Math.floor((Date.now() - start) / (30.44 * 864e5))) : 0;
    let bal = fin.amount; const rows = [];
    for (let i = 1; i <= n; i++) { const it = Math.round(bal * r), pr = Math.min(bal, ins - it); bal = Math.max(0, bal - pr); rows.push({ i, it, pr, bal, due: start ? new Date(start.getFullYear(), start.getMonth() + i, start.getDate()) : null }); }
    const all = C.czAllRows;
    sc.innerHTML = `<h3>جدول الأقساط<span class="sp"></span><span class="small muted">${esc(C.orgs.find(x => x.id === fin.bank_id)?.name)} · <span class="num">${rate.toFixed(2)}%</span></span></h3>
      <div class="grid g4" style="gap:10px;margin-bottom:12px">
        <div class="stat"><b>${iqd(fin.amount)}</b><span>مبلغ التمويل</span></div><div class="stat"><b>${iqd(ins)}</b><span>القسط الشهري</span></div>
        <div class="stat"><b>${iqd(ins * n)}</b><span>إجمالي السداد</span></div><div class="stat"><b><span class="num">${paid}</span> / <span class="num">${n}</span></b><span>أقساط مسددة</span></div></div>
      ${start ? '' : '<div class="notice"><span>ℹ</span><span>يبدأ أول قسط بعد صرف المبلغ للمورد وتسليمك جدول الأقساط (بعد مدة السماح إن وُجدت). التواريخ تظهر عند الصرف.</span></div>'}
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>الاستحقاق</th><th>القسط</th><th>أصل</th><th>${fin.margin ? 'فائدة/ربح' : 'فائدة'}</th><th>المتبقي</th><th>الحالة</th></tr></thead><tbody>
      ${rows.slice(0, all ? n : 12).map(x => `<tr><td class="num">${x.i}</td><td class="small">${x.due ? x.due.toLocaleDateString('ar-IQ-u-nu-latn', { year: 'numeric', month: 'short' }) : `الشهر <span class="num">${x.i}</span>`}</td><td>${iqd(ins)}</td><td>${iqd(x.pr)}</td><td>${iqd(x.it)}</td><td>${iqd(x.bal)}</td><td>${x.i <= paid ? badge(['مسدد', 'ok']) : x.i === paid + 1 && start ? badge(['القادم', 'warn']) : badge(['مجدول', 'muted'])}</td></tr>`).join('')}</tbody></table></div>
      ${n > 12 ? `<button class="btn ghost block mt" data-rows>${all ? 'عرض أول 12 قسطاً' : `عرض كل الأقساط (<span class="num">${n}</span>)`}</button>` : ''}`;
    const rb = sc.querySelector('[data-rows]'); if (rb) rb.onclick = () => { C.czAllRows = !C.czAllRows; pageProfile(body); };
  }
  body.querySelectorAll('[data-go]').forEach(tr => tr.onclick = () => { location.hash = '#home'; });
  const save = async (f, keys) => {
    const d = {}; keys.forEach(k => d[k] = (f[k].value || '').trim());
    if ('monthly_salary' in d) d.monthly_salary = digits(d.monthly_salary);
    const b = f.querySelector('button'); b.disabled = true;
    try { C.profile = await rpc(C.sb, 'update_my_profile', { p: d }); toast('حُفظت التغييرات', 'ok'); pageProfile(body); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  };
  body.querySelector('[data-f=contact]').onsubmit = e => { e.preventDefault(); save(e.target, ['governorate', 'city', 'address', 'email']); };
  body.querySelector('[data-f=work]').onsubmit = e => { e.preventDefault(); save(e.target, ['employer', 'monthly_salary']); };
  body.querySelector('[data-f=pw]').onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    if (f.nw.value.length < 8 || !/\d/.test(f.nw.value) || !/[A-Za-z]/.test(f.nw.value)) return toast('كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً', 'bad');
    try { await rpc(C.sb, 'change_my_password', { p_old: f.old.value, p_new: f.nw.value }); f.reset(); toast('تم تغيير كلمة المرور', 'ok'); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
  body.querySelector('[data-phone]').onclick = () => {
    const m = modal(`<h3>تغيير رقم الهاتف</h3><p class="muted small">نرسل رمز تحقق إلى الرقم الجديد.${p.self_registered ? ' سيصبح الرقم الجديد اسم دخولك.' : ''}</p>
      <div class="field"><label>الرقم الجديد</label><input class="input" data-ph inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الرمز</button></div>`);
    m.el.querySelector('[data-s]').onclick = async () => {
      const ph = normPhone(m.el.querySelector('[data-ph]').value);
      if (!validPhone(ph)) return toast('رقم الهاتف غير صحيح', 'bad');
      m.close();
      const c = await askOtp({ title: 'تأكيد الرقم الجديد', phone: ph, verify: async code => { C.profile = await rpc(C.sb, 'change_my_phone', { p_new_phone: ph, p_otp: code }); } });
      if (c) { toast('تم تغيير رقم الهاتف', 'ok'); pageProfile(body); }
    };
  };
  body.querySelector('[data-out]').onclick = async () => { await C.sb.auth.signOut(); location.hash = ''; location.reload(); };
}
