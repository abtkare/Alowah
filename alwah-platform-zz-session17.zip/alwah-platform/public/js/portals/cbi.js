// لوحة البنك المركزي — جهة رقابية: الاطلاع والتدقيق والتدخل المسبب عند الحاجة (لا موافقة ولا رفض للإقراض)
import { esc, iqd, mln, pct, num, kpi, appsTable, openApp, dt, tabs, badge, BATCH_STATUS, rpc, toast, cleanErr, modal, enrichVet, isVet, VET_TYPES, MEMBER_STATUS } from '../core.js';
import { perfView } from '../perf.js';
import { mapView, analyticsView, initiativesView, integrityUsersView } from '../cbi-extra.js';
import { lettersView } from '../letters.js';

let leafletReady;
function loadLeaflet() {
  if (leafletReady) return leafletReady;
  leafletReady = new Promise((res, rej) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = rej; document.head.appendChild(s);
  });
  return leafletReady;
}

export async function render(ctx) {
  const { sb, root, orgs } = ctx;
  const [apps, allocs, circ, settings, batches] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').then(r => r.data || []),
    sb.from('circulars').select('*').order('issued_on', { ascending: false }).then(r => r.data || []),
    sb.from('settings').select('*').then(r => r.data || []),
    sb.from('cbi_batches').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
  ]);
  await enrichVet(sb, apps);
  const done = apps.filter(a => a.status === 'completed');
  const live = apps.filter(a => ['active', 'returned'].includes(a.status));
  const pending = batches.filter(b => b.status === 'sent');
  const win = Number(settings.find(x => x.key === 'execution_window_days')?.value || 30);
  const lateExec = live.filter(a => a.cbi_approved_at && a.stage < 35 && Date.now() > Math.max(new Date(a.cbi_approved_at).getTime() + win * 864e5, a.exec_extended_until ? new Date(a.exec_extended_until).getTime() : 0));
  const mw = done.reduce((s, a) => s + Number(a.kw || 0), 0) / 1000;
  const byGov = {};
  apps.forEach(a => { const g = byGov[a.governorate] ||= { n: 0, done: 0, kw: 0, amt: 0 }; g.n++; if (a.status === 'completed') { g.done++; g.kw += Number(a.kw || 0); g.amt += a.amount; } });

  root.innerHTML = `
    <div class="page-head"><div><h1>البنك المركزي العراقي</h1><p>مبادرة تمويل منظومات الطاقة الشمسية — جهة قطاعية رقابية: تراقب وتدقق أداء المصارف واستخدام ائتماناتها، لا توافق ولا ترفض الإقراض، وتتدخل في الحالات التي تستدعي ذلك فقط.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('القدرة المركّبة', mw >= 1 ? `<span class="num">${mw.toLocaleString('en-US', { maximumFractionDigits: 2 })}</span> MW` : `<span class="num">${num(mw * 1000)}</span> kW`, `${done.length} منظومة موثقة ومدققة`, true)}
      ${kpi('إجمالي التمويل المصروف', mln(done.reduce((s, a) => s + a.amount, 0)), 'دينار عراقي')}
      ${kpi('سلف بانتظار كفاية الائتمان', `<span class="num">${pending.length}</span>`, `بمبلغ ${mln(pending.reduce((s, b) => s + b.total, 0))} · ${lateExec.length} طلب تجاوز مهلة التنفيذ`)}
      ${kpi('المصارف المشاركة', `<span class="num">${allocs.length}</span>`, `ائتمانات ${mln(allocs.reduce((s, a) => s + a.allocated, 0))}`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [{ key: 'map', label: 'الخريطة والمحافظات' }, { key: 'stats', label: 'التحليل ونسب النمو' }, { key: 'initiatives', label: 'إعلان المبادرات' }, { key: 'batch', label: 'السلف التجميعية (اطلاع)', count: pending.length }, { key: 'perf', label: 'أداء المصارف' }, { key: 'quota', label: 'ائتمانات المصارف' }, { key: 'circ', label: 'السياسة والإعدادات' }, { key: 'vet', label: 'مبادرة الطب البيطري' }, { key: 'nz', label: 'هيئة النزاهة' }, { key: 'letters', label: '🔒 المخاطبات السرية' }, { key: 'all', label: 'كل الطلبات' }];
  ctx.cbiTab = ctx.cbiTab || 'map';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.cbiTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.cbiTab));
  const open = a => openApp(ctx, a, { actions: [{ label: 'تدخل رقابي (ملاحظة مسببة)', kind: 'warn', needNote: true, done: 'سُجّلت الملاحظة الرقابية في سجل الطلب', run: note => rpc(sb, 'cbi_oversight_note', { p_app: a.id, p_note: note }) }] });

  async function show(k) {
    if (k === 'map') return mapView(ctx, body, apps, loadLeaflet);
    if (k === 'stats') return analyticsView(ctx, body);
    if (k === 'initiatives') return initiativesView(ctx, body);
    if (k === 'nz') return integrityUsersView(ctx, body);
    if (k === 'letters') return lettersView(ctx, body);
    if (k === 'perf') perfView(ctx, body, { mode: 'oversight' });
    if (k === 'batch') {
      const bank = id => orgs.find(o => o.id === id)?.name || '—';
      body.innerHTML = `<div class="notice">البنك المركزي جهة قطاعية رقابية: <b>لا يوافق ولا يرفض</b> طلبات الإقراض ولا يقرر من يُقرض — هذا قرار المصرف وحده. لكل مصرف ائتمان لدى البنك المركزي، وتُعزَّز السلفة التجميعية آلياً منه عند إرسال كتابها إن كان كافياً. دورك هنا الاطلاع والتدقيق، والتدخل في الحالات التي تستدعيه فقط، بسبب مكتوب يُسجَّل باسم منصبك.</div>
        ${lateExec.length ? `<div class="notice warn"><b>${lateExec.length}</b> طلب تجاوز شهراً من تعزيز السلفة دون تنفيذ: ${lateExec.map(a => esc(a.code)).join('، ')}</div>` : ''}
        <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>السلفة</th><th>المصرف</th><th>الطلبات</th><th>المبلغ</th><th>الكتاب</th><th>الحالة</th><th>التواريخ</th><th></th></tr></thead><tbody>
        ${batches.filter(b => b.status !== 'draft').map(b => `<tr><td><b class="num">${esc(b.code)}</b></td><td>${esc(bank(b.bank_id))}</td><td class="num">${b.apps_count}</td><td>${iqd(b.total)}</td><td class="num small">${esc(b.letter_ref || '—')}<div class="muted">${esc(b.signed_by_name || '')}</div></td>
          <td>${badge(BATCH_STATUS[b.status])}</td><td class="small muted">${b.sent_at ? `أُرسلت ${dt(b.sent_at)}` : ''}${b.decided_at ? `<br>${b.status === 'approved' ? 'عُزّزت' : 'القرار'} ${dt(b.decided_at)}` : ''}${(b.oversight_notes || []).map(o => `<br><span style="color:var(--warn)">تدخل رقابي ${dt(o.at)}: ${esc(o.note)}</span>`).join('')}</td>
          <td><div class="row" style="gap:6px"><button class="btn sm ghost" data-apps="${b.id}">الطلبات</button><button class="btn sm warn" data-int="${b.id}">تدخل رقابي</button></div></td></tr>`).join('') || '<tr><td colspan="8" class="empty">لا سلف مرسلة بعد.</td></tr>'}
        </tbody></table></div></div>`;
      body.querySelectorAll('[data-int]').forEach(x => x.onclick = () => intervene(x.dataset.int));
      body.querySelectorAll('[data-apps]').forEach(x => x.onclick = () => {
        const rows = apps.filter(a => a.batch_id === x.dataset.apps);
        const m = modal(`<h3>طلبات السلفة</h3>${appsTable(rows, ctx, { onOpen: a => { m.close(); open(a); }, cols: ['code', 'name', 'gov', 'amount', 'stage', 'status'] })}`, { wide: true });
      });
    }
    if (k === 'quota') body.innerHTML = `<div class="grid g3">${allocs.map(a => {
      const b = orgs.find(o => o.id === a.bank_id); const u = (a.reserved + a.disbursed) / a.allocated * 100;
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      return `<div class="card"><h3>${esc(b?.name)} <span class="sp"></span>${u >= 90 ? '<span class="badge bad">أحمر</span>' : u >= 80 ? '<span class="badge warn">تنبيه</span>' : '<span class="badge ok">سليم</span>'}</h3>
        <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
        <dl class="kv mt"><dt>الائتمان لدى البنك المركزي</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز</dt><dd>${iqd(a.reserved)}</dd><dt>المصروف</dt><dd>${iqd(a.disbursed)}</dd><dt>الاستخدام</dt><dd>${pct(u)}</dd></dl></div>`;
    }).join('')}</div>`;
    if (k === 'circ') body.innerHTML = `<div class="grid g2"><div class="card"><h3>سجل التعاميم</h3>${circ.map(c => `<div class="alert low"><div class="ic">ت</div><div><h4>${esc(c.title)}</h4><p>رقم <b class="num">${esc(c.number)}</b> · صدر ${dt(c.issued_on).split('،')[0]} · يسري من ${dt(c.effective_on).split('،')[0]}</p><p>${esc(c.summary)}</p></div></div>`).join('')}</div>
      <div class="card flush"><h3>القواعد المالية حسب سياسة التمويل</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القاعدة</th><th>القيمة</th><th>المرجع</th></tr></thead><tbody>
      ${settings.filter(s => !s.key.startsWith('vet_')).map(s => `<tr><td>${esc(s.label)}</td><td><b class="num">${num(s.value)}</b></td><td class="num muted">${esc(s.circular_no)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
    if (k === 'vet') await vetTab();
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'stage', 'status'] })}</div>`;
  }
  // مبادرة التعليم والطب البيطري: متابعة المخصص، وتحديث الضوابط حين يصدر التعميم
  async function vetTab() {
    const vapps = apps.filter(isVet), S = Object.fromEntries(settings.map(x => [x.key, Number(x.value)]));
    const mem = (await sb.from('vet_memberships').select('status')).data || [];
    const committed = vapps.filter(a => a.stage >= 6 && !['rejected', 'cancelled'].includes(a.status)).reduce((t, a) => t + Number(a.amount || 0), 0);
    const disbursed = vapps.filter(a => a.status === 'completed' || a.stage >= 36).reduce((t, a) => t + Number(a.amount || 0), 0);
    const total = S.vet_initiative_total || 0, u = total ? committed / total * 100 : 0;
    const byType = Object.keys(VET_TYPES).map(k => [k, vapps.filter(a => a.vet_type === k)]);
    body.innerHTML = `<div class="grid g4 mb">
        ${kpi('المخصص لأعضاء النقابة', mln(total), 'دينار — قيمة مبدئية', true)}
        ${kpi('ملتزم به لدى المصارف', mln(committed), `${pct(u)} من المخصص`)}
        ${kpi('مصروف للموردين', mln(disbursed), 'مشاريع مكتملة الصرف')}
        ${kpi('أعضاء مؤيَّدون', `<span class="num">${mem.filter(m => m.status === 'endorsed').length}</span>`, `${mem.filter(m => m.status === 'pending').length} بانتظار النقابة`)}
      </div>
      <div class="grid g2"><div class="card flush"><h3>حسب نوع المشروع</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المشروع</th><th>الطلبات</th><th>لدى المصارف</th><th>مبلغ القروض</th></tr></thead><tbody>
        ${byType.map(([k, l]) => `<tr><td>${esc(VET_TYPES[k])}</td><td class="num">${l.length}</td><td class="num">${l.filter(a => a.stage >= 6 && a.status !== 'cancelled').length}</td><td>${mln(l.reduce((t, a) => t + Number(a.amount || 0), 0))}</td></tr>`).join('')}</tbody></table></div></div>
      <div class="card flush"><h3>ضوابط المبادرة <span class="sp"></span><span class="badge warn">قيم مبدئية — حدّثها حين يصدر التعميم</span></h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الضابط</th><th>القيمة</th><th>المرجع</th><th></th></tr></thead><tbody>
        ${settings.filter(x => x.key.startsWith('vet_')).map(x => `<tr><td>${esc(x.label)}</td><td><b class="num">${num(x.value)}</b></td><td class="small muted">${esc(x.circular_no || '')}</td><td><button class="btn sm ghost" data-set="${x.key}">تعديل</button></td></tr>`).join('')}</tbody></table></div></div></div>
      <div class="card flush mt"><h3>الطلبات البيطرية</h3>${appsTable(vapps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'stage', 'status'] })}</div>`;
    body.querySelectorAll('[data-set]').forEach(b => b.onclick = () => {
      const x = settings.find(y => y.key === b.dataset.set);
      const m = modal(`<h3>تعديل ضابط في المبادرة</h3><p class="muted small">${esc(x.label)}</p>
        <div class="field"><label>القيمة الجديدة</label><input class="input" data-v inputmode="decimal" dir="ltr" value="${esc(x.value)}"></div>
        <div class="field"><label>رقم التعميم أو المرجع</label><input class="input" data-c value=""></div>
        <p class="small muted">يُسجَّل التعديل لدى هيئة النزاهة، ويسري على الطلبات الجديدة وعلى الدراسات التي لم تُرسل للمصرف بعد.</p>
        <div class="row"><span class="sp"></span><button class="btn cyan" data-s>حفظ</button></div>`);
      m.el.querySelector('[data-s]').onclick = async e => {
        e.target.disabled = true;
        try { await rpc(sb, 'cbi_set_setting', { p_key: x.key, p_value: Number(String(m.el.querySelector('[data-v]').value).replace(/[^0-9.]/g, '')), p_circular: m.el.querySelector('[data-c]').value.trim() || null }); m.close(); toast('حُدّث الضابط', 'ok'); ctx.refresh(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    });
  }
  // التدخل الرقابي: للحالات التي تستدعيه فقط — لا يغيّر قرار المصرف ولا مراحل الطلبات
  async function intervene(id) {
    const m = modal(`<h3>تدخل رقابي على السلفة</h3>
      <p class="small muted">لا يعني موافقة ولا رفضاً، ولا يغيّر مرحلة أي طلب. يُسجَّل في سجل كل طلب في السلفة باسم منصبك ويطّلع عليه المصرف وهيئة النزاهة.</p>
      <div class="field"><textarea class="input" rows="3" placeholder="سبب التدخل وما يُطلب من المصرف (10 أحرف على الأقل)"></textarea></div>
      <div class="row mt"><span class="sp"></span><button class="btn warn" data-go>تسجيل التدخل وإبلاغ المصرف</button></div>`);
    const go = m.el.querySelector('[data-go]');
    go.onclick = async () => {
      go.disabled = true;
      try { await rpc(sb, 'batch_action', { p_batch: id, p_action: 'intervene', p_note: m.el.querySelector('textarea').value.trim() || null }); m.close(); toast('سُجّل التدخل الرقابي وأُبلغ المصرف', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); go.disabled = false; }
    };
  }
  show(ctx.cbiTab);
}

export const shouldRefresh = ctx => !['perf', 'stats', 'letters', 'nz', 'map'].includes(ctx.cbiTab) && !document.querySelector('.mdl-bg');
