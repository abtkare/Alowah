-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 28: وزارة التخطيط — خارطة الطريق ومؤشرات الأداء
-- الوزارة تضع خارطة طريق المبادرة: مراحل زمنية، ولكل مرحلة أهداف بقيم مستهدفة.
-- النظام يقيس كل هدف آلياً من بيانات المعاملات، ويحكم على حالته (متحقق / على المسار / معرّض / متأخر)،
-- ويتوقع ما سيصل إليه بنهاية المرحلة، ويحسب المطلوب شهرياً للّحاق.
-- الوزارة تكتب على خارطتها فقط — لا تكتب على أي معاملة، ولا ترى بيانات شخصية: أرقام مجمّعة فقط.
-- كل تعديل على الخارطة يُسجَّل (من، متى، قبل، بعد، السبب). المرحلة المعتمدة لا تُعدَّل إلا بسبب مكتوب.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة والدور ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning']));

insert into public.orgs(code, type, name)
select 'mop', 'planning', 'وزارة التخطيط'
where not exists (select 1 from public.orgs where type = 'planning');

-- الدور planning_officer يُضاف بجانب دور الديوان في دوال الأدوار (دون المساس بباقي محتواها)
do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''audit_viewer'' then ''FA''', 'when ''audit_viewer'' then ''FA'' when ''planning_officer'' then ''PL'''],
  ['public._role_title(text)', 'when ''audit_viewer'' then ''مراقب مالي — ديوان الرقابة المالية الاتحادي''', 'when ''audit_viewer'' then ''مراقب مالي — ديوان الرقابة المالية الاتحادي'' when ''planning_officer'' then ''مخطط — وزارة التخطيط'''],
  ['public._portal_of_role(text)', 'when r = ''audit_viewer'' then ''audit''', 'when r = ''audit_viewer'' then ''audit'' when r = ''planning_officer'' then ''planning'''],
  ['public._org_type_of_portal(text)', 'when ''audit'' then ''audit''', 'when ''audit'' then ''audit'' when ''planning'' then ''planning'''],
  ['public._org_roles(text)', 'when ''audit'' then array[''audit_viewer'']', 'when ''audit'' then array[''audit_viewer''] when ''planning'' then array[''planning_officer'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('planning' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
end $$;

-- ───────── 2) جداول الخارطة ─────────
create table if not exists public.plan_settings (
  id int primary key default 1 check (id = 1),
  title text not null default 'خارطة طريق مبادرة تمويل منظومات الطاقة الشمسية',
  vision text,
  start_date date not null default date '2026-08-01',     -- بدء المبادرة: منه تُحسب المؤشرات التراكمية
  budget bigint not null default 1000000000000,           -- رصيد المبادرة (دينار)
  yield_kwh_per_kw numeric not null default 1650,         -- إنتاج سنوي لكل كيلوواط مركّب (كيلوواط ساعة)
  co2_t_per_mwh numeric not null default 0.7,             -- انبعاثات متجنَّبة لكل ميغاواط ساعة (طن)
  diesel_l_per_kwh numeric not null default 0.3,          -- وقود مولّدات موفَّر لكل كيلوواط ساعة (لتر)
  jobs_per_project numeric not null default 4,            -- فرص عمل متوقعة لكل مشروع إنتاجي
  updated_at timestamptz default now(), updated_by uuid
);
insert into public.plan_settings(id) values (1) on conflict do nothing;

create table if not exists public.plan_phases (
  id uuid primary key default gen_random_uuid(),
  ord int not null default 1,
  title text not null,
  description text,
  starts date not null,
  ends date not null check (ends > starts),
  status text not null default 'draft' check (status in ('draft', 'approved')),
  approved_at timestamptz, approved_by text,
  created_at timestamptz default now(), updated_at timestamptz default now()
);

create table if not exists public.plan_goals (
  id uuid primary key default gen_random_uuid(),
  phase_id uuid not null references public.plan_phases(id) on delete cascade,
  metric text not null,
  title text,
  target numeric not null,
  baseline numeric,                     -- فارغ = يُحسب آلياً (قيمة المؤشر عند بدء المرحلة)
  mode text not null default 'cumulative' check (mode in ('cumulative', 'phase')),
  scope_gov text, scope_sector text,
  weight numeric not null default 1 check (weight > 0),
  note text, ord int default 0,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create index if not exists plan_goals_phase on public.plan_goals(phase_id);

create table if not exists public.plan_log (
  id bigserial primary key,
  at timestamptz default now(),
  by_id uuid, by_name text, by_code text,
  action text not null, target text, reason text,
  before jsonb, after jsonb
);

alter table public.plan_settings enable row level security;
alter table public.plan_phases enable row level security;
alter table public.plan_goals enable row level security;
alter table public.plan_log enable row level security;
revoke all on public.plan_settings, public.plan_phases, public.plan_goals, public.plan_log from anon, authenticated;

-- ───────── 3) دليل المؤشرات (مصدر واحد للشاشة والحساب) ─────────
-- kind: flow = يتراكم مع الوقت (يُقارن بالوقت المنقضي من المرحلة) · level = نسبة أو مستوى (يُقارن بالمستهدف مباشرة)
-- dir: up = الأعلى أفضل · down = الأقل أفضل
create or replace function public._plan_catalog() returns jsonb language sql immutable as $f$
select '[
 {"key":"amount_disbursed","axis":"finance","label":"المبالغ المصروفة للمستفيدين","unit":"دينار","fmt":"iqd","kind":"flow","dir":"up"},
 {"key":"budget_use_pct","axis":"finance","label":"نسبة صرف رصيد المبادرة","unit":"%","fmt":"pct","kind":"flow","dir":"up"},
 {"key":"loans_completed","axis":"finance","label":"القروض المنجزة (منظومات مشغّلة)","unit":"قرض","fmt":"num","kind":"flow","dir":"up"},
 {"key":"apps_submitted","axis":"finance","label":"طلبات التمويل المقدَّمة","unit":"طلب","fmt":"num","kind":"flow","dir":"up"},
 {"key":"kw_installed","axis":"energy","label":"القدرة المركّبة","unit":"كيلوواط","fmt":"kw","kind":"flow","dir":"up"},
 {"key":"mwh_year","axis":"energy","label":"الكهرباء المولّدة سنوياً (متوقعة)","unit":"ميغاواط ساعة","fmt":"num","kind":"flow","dir":"up"},
 {"key":"co2_t_year","axis":"energy","label":"انبعاثات الكربون المتجنَّبة سنوياً","unit":"طن","fmt":"num","kind":"flow","dir":"up"},
 {"key":"diesel_kl_year","axis":"energy","label":"وقود المولّدات الموفَّر سنوياً","unit":"ألف لتر","fmt":"num","kind":"flow","dir":"up"},
 {"key":"gov_covered","axis":"equity","label":"المحافظات المستفيدة","unit":"محافظة","fmt":"num","kind":"flow","dir":"up"},
 {"key":"share_outside_baghdad_pct","axis":"equity","label":"حصة المحافظات خارج بغداد من المبالغ","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"share_productive_pct","axis":"equity","label":"حصة القطاعات الإنتاجية (زراعي، صناعي، تجاري، بيطري)","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"share_agri_pct","axis":"equity","label":"حصة القطاع الزراعي","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"women_pct","axis":"equity","label":"نسبة النساء من المستفيدين","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"youth_pct","axis":"equity","label":"نسبة الشباب (دون 35 سنة) من المستفيدين","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"jobs_expected","axis":"economy","label":"فرص العمل المتوقعة من المشاريع الإنتاجية","unit":"فرصة","fmt":"num","kind":"flow","dir":"up"},
 {"key":"repay_on_time_pct","axis":"economy","label":"نسبة الأقساط المسددة في موعدها","unit":"%","fmt":"pct","kind":"level","dir":"up"},
 {"key":"default_pct","axis":"economy","label":"نسبة القروض المتعثرة (متأخرة +90 يوماً)","unit":"%","fmt":"pct","kind":"level","dir":"down"},
 {"key":"avg_days_complete","axis":"economy","label":"متوسط مدة إنجاز الطلب","unit":"يوم","fmt":"days","kind":"level","dir":"down"},
 {"key":"sla_pct","axis":"economy","label":"نسبة المراحل المنجزة ضمن مدتها المحددة","unit":"%","fmt":"pct","kind":"level","dir":"up"}
]'::jsonb $f$;

-- ───────── 4) محرك القياس ─────────
-- المعاملات المقدَّمة للمصارف بأرقام مجمّعة (دون أسماء)
create or replace function public._plan_apps(p_gov text default null, p_sector text default null)
returns table(id uuid, governorate text, sector text, amount numeric, kw numeric, status text,
              sub_at timestamptz, done_at timestamptz, disb_at timestamptz, disb_amt numeric, gender text, birth_date date)
language sql stable security definer set search_path to 'public' as $f$
  select x.id, x.governorate, x.sector, x.amount, x.kw, x.status, x.sub_at,
    case when x.status = 'completed' then coalesce((select max(l.entered_at) from stage_log l where l.application_id = x.id and l.stage = 37), x.updated_at) end,
    case when x.status = 'completed' or x.stage > 35 then coalesce((select min(l.entered_at) from stage_log l where l.application_id = x.id and l.stage > 35), x.updated_at) end,
    case when x.program = 'vet' then coalesce((select sum(t.amount) from vet_tranches t where t.application_id = x.id and t.status = 'paid'), 0)
         when x.status = 'completed' or x.stage > 35 then x.amount else 0 end,
    p.gender, p.birth_date
  from (select a.*, coalesce(a.submitted_at, a.created_at) sub_at,
          case when a.program = 'vet' then 'vet_program' when a.purpose is null or a.purpose = 'household' then 'residential' else a.purpose end sector
        from applications a where a.bank_id is not null and a.stage >= 6) x
  left join profiles p on p.id = x.citizen_id
  where (p_gov is null or x.governorate = p_gov) and (p_sector is null or x.sector = p_sector) $f$;

-- قيمة مؤشر واحد في نافذة زمنية [p_from, p_to) — تُرجع {value, n, coverage}
create or replace function public._plan_metric(p_metric text, p_from timestamptz, p_to timestamptz, p_gov text default null, p_sector text default null)
returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare s plan_settings; r jsonb;
begin
  select * into s from plan_settings where id = 1;
  if p_metric = 'amount_disbursed' then
    select jsonb_build_object('value', coalesce(sum(disb_amt), 0), 'n', count(*)) into r from _plan_apps(p_gov, p_sector) where disb_at >= p_from and disb_at < p_to;
  elsif p_metric = 'budget_use_pct' then
    select jsonb_build_object('value', round(coalesce(sum(disb_amt), 0) * 100.0 / nullif(s.budget, 0), 4), 'n', count(*)) into r from _plan_apps(p_gov, p_sector) where disb_at >= p_from and disb_at < p_to;
  elsif p_metric = 'loans_completed' then
    select jsonb_build_object('value', count(*)) into r from _plan_apps(p_gov, p_sector) where done_at >= p_from and done_at < p_to;
  elsif p_metric = 'apps_submitted' then
    select jsonb_build_object('value', count(*)) into r from _plan_apps(p_gov, p_sector) where sub_at >= p_from and sub_at < p_to;
  elsif p_metric in ('kw_installed', 'mwh_year', 'co2_t_year', 'diesel_kl_year') then
    select jsonb_build_object('value', round(case p_metric
        when 'kw_installed' then coalesce(sum(kw), 0)
        when 'mwh_year' then coalesce(sum(kw), 0) * s.yield_kwh_per_kw / 1000
        when 'co2_t_year' then coalesce(sum(kw), 0) * s.yield_kwh_per_kw / 1000 * s.co2_t_per_mwh
        else coalesce(sum(kw), 0) * s.yield_kwh_per_kw * s.diesel_l_per_kwh / 1000 end, 1), 'n', count(*))
      into r from _plan_apps(p_gov, p_sector) where done_at >= p_from and done_at < p_to;
  elsif p_metric = 'gov_covered' then
    select jsonb_build_object('value', count(distinct governorate), 'of', 18) into r from _plan_apps(p_gov, p_sector) where done_at >= p_from and done_at < p_to;
  elsif p_metric in ('share_outside_baghdad_pct', 'share_productive_pct', 'share_agri_pct') then
    select jsonb_build_object('value', round(100.0 * coalesce(sum(disb_amt) filter (where case p_metric
          when 'share_outside_baghdad_pct' then governorate is distinct from 'بغداد'
          when 'share_productive_pct' then sector <> 'residential'
          else sector = 'agricultural' end), 0) / nullif(sum(disb_amt), 0), 1), 'n', count(*))
      into r from _plan_apps(p_gov, p_sector) where disb_at >= p_from and disb_at < p_to and disb_amt > 0;
  elsif p_metric in ('women_pct', 'youth_pct') then
    select jsonb_build_object(
        'value', case p_metric
          when 'women_pct' then round(100.0 * count(*) filter (where lower(gender) in ('female', 'f', 'أنثى', 'انثى')) / nullif(count(*) filter (where gender is not null), 0), 1)
          else round(100.0 * count(*) filter (where birth_date > (sub_at - interval '35 years')::date) / nullif(count(*) filter (where birth_date is not null), 0), 1) end,
        'n', count(*),
        'coverage', round(100.0 * count(*) filter (where (case p_metric when 'women_pct' then gender is not null else birth_date is not null end)) / nullif(count(*), 0), 1))
      into r from _plan_apps(p_gov, p_sector) where sub_at >= p_from and sub_at < p_to;
  elsif p_metric = 'jobs_expected' then
    select jsonb_build_object('value', round(count(*) filter (where sector <> 'residential') * s.jobs_per_project), 'n', count(*)) into r
      from _plan_apps(p_gov, p_sector) where done_at >= p_from and done_at < p_to;
  elsif p_metric = 'repay_on_time_pct' then
    select jsonb_build_object('value', round(100.0 * count(*) filter (where i.paid_at is not null and i.paid_at::date <= i.due_date) / nullif(count(*), 0), 1), 'n', count(*)) into r
      from installments i join _plan_apps(p_gov, p_sector) a on a.id = i.application_id
      where i.due_date >= p_from::date and i.due_date < least(p_to, now())::date;
  elsif p_metric = 'default_pct' then
    select jsonb_build_object('value', round(100.0 * count(*) filter (where q.late) / nullif(count(*), 0), 1), 'n', count(*)) into r from (
      select a.id, bool_or(i.paid_at is null and i.due_date < least(p_to, now())::date - 90) late
      from _plan_apps(p_gov, p_sector) a join installments i on i.application_id = a.id where a.done_at < p_to group by a.id) q;
  elsif p_metric = 'avg_days_complete' then
    select jsonb_build_object('value', round(avg(extract(epoch from done_at - sub_at) / 86400)::numeric, 1), 'n', count(*)) into r
      from _plan_apps(p_gov, p_sector) where done_at >= p_from and done_at < p_to;
  elsif p_metric = 'sla_pct' then
    select jsonb_build_object('value', round(100.0 * count(*) filter (where l.finished_at <= l.entered_at + make_interval(secs => l.sla_days * 86400)) / nullif(count(*), 0), 1), 'n', count(*)) into r
      from stage_log l join _plan_apps(p_gov, p_sector) a on a.id = l.application_id
      where l.finished_at is not null and l.sla_days is not null and l.finished_at >= p_from and l.finished_at < p_to;
  else
    raise exception 'مؤشر غير معروف: %', p_metric;
  end if;
  return coalesce(r, jsonb_build_object('value', null));
end $f$;

-- ───────── 5) الصلاحيات ─────────
create or replace function public._plan_reader() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal not in ('planning', 'admin') then raise exception 'غير مخوّل'; end if;
  return me;
end $f$;

create or replace function public._plan_writer() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal <> 'planning' then raise exception 'الخارطة تضعها وزارة التخطيط فقط'; end if;
  return me;
end $f$;

create or replace function public._plan_log(me profiles, p_action text, p_target text, p_reason text, p_before jsonb, p_after jsonb) returns void
language sql security definer set search_path to 'public' as $f$
  insert into plan_log(by_id, by_name, by_code, action, target, reason, before, after)
  values (me.id, me.full_name, me.staff_code, p_action, p_target, nullif(trim(coalesce(p_reason, '')), ''), p_before, p_after) $f$;

-- ───────── 6) لوحة الوزارة: الخارطة مقاسة آلياً ─────────
create or replace function public.planning_overview() returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare
  me profiles; s plan_settings; cat jsonb := _plan_catalog(); c jsonb;
  ph plan_phases; g plan_goals; goals jsonb; phases jsonb := '[]'; m jsonb;
  v_from timestamptz; v_to timestamptz; v_now timestamptz := now();
  val numeric; base numeric; prog numeric; elapsed numeric; st text; fc numeric; need numeric; months_left numeric;
  cur uuid; score_w numeric; score_s numeric; axis_s jsonb;
  totals jsonb := '{}'; k text;
begin
  me := _plan_reader();
  select * into s from plan_settings where id = 1;

  -- المرحلة الحالية: الجارية الآن، وإلا القادمة، وإلا الأخيرة
  select id into cur from plan_phases where current_date between starts and ends order by ord limit 1;
  if cur is null then select id into cur from plan_phases where starts > current_date order by starts limit 1; end if;
  if cur is null then select id into cur from plan_phases order by ends desc limit 1; end if;

  for ph in select * from plan_phases order by ord, starts loop
    goals := '[]'; score_w := 0; score_s := 0; axis_s := '{}';
    elapsed := greatest(0, least(1, extract(epoch from v_now - ph.starts::timestamptz) / nullif(extract(epoch from (ph.ends + 1)::timestamptz - ph.starts::timestamptz), 0)));
    months_left := greatest(0, extract(epoch from (ph.ends + 1)::timestamptz - v_now) / 86400 / 30.44);
    for g in select * from plan_goals where phase_id = ph.id order by ord, created_at loop
      c := (select e from jsonb_array_elements(cat) e where e->>'key' = g.metric);
      v_from := case when g.mode = 'phase' then ph.starts::timestamptz else s.start_date::timestamptz end;
      v_to := least(v_now, (ph.ends + 1)::timestamptz);
      m := _plan_metric(g.metric, v_from, v_to, g.scope_gov, g.scope_sector);
      val := (m->>'value')::numeric;
      -- خط الأساس: ما أدخلته الوزارة، وإلا قيمة المؤشر عند بدء المرحلة (للمؤشرات التراكمية)، وإلا صفر
      base := g.baseline;
      if base is null and c->>'kind' = 'flow' and g.mode = 'cumulative' and ph.starts > s.start_date then
        base := coalesce((_plan_metric(g.metric, s.start_date::timestamptz, least(v_now, ph.starts::timestamptz), g.scope_gov, g.scope_sector)->>'value')::numeric, 0);
      end if;
      base := coalesce(base, case when c->>'dir' = 'down' then null else 0 end);

      prog := null; st := null; fc := null; need := null;
      if val is null then st := 'nodata';
      -- بيانات الجنس والعمر تُستكمل من قراءة البطاقة الوطنية: لا حكم إن غطّت أقل من نصف المستفيدين
      elsif (m->>'coverage') is not null and (m->>'coverage')::numeric < 50 then st := 'lowdata';
      elsif c->>'dir' = 'down' then
        prog := case when val <= g.target then 1
                     when base is not null and base > g.target then greatest(0, (base - val) / (base - g.target))
                     else greatest(0, g.target / nullif(val, 0)) end;
      else
        prog := case when g.target <= base then 1 else greatest(0, (val - base) / (g.target - base)) end;
      end if;

      if st is null then
        if current_date < ph.starts then st := 'upcoming';
        elsif prog >= 1 then st := 'achieved';
        elsif current_date > ph.ends then st := 'missed';
        elsif c->>'kind' = 'flow' then
          st := case when prog >= elapsed * 0.9 then 'on_track' when prog >= elapsed * 0.6 then 'at_risk' else 'behind' end;
        else
          st := case when prog >= 0.95 then 'on_track' when prog >= 0.75 then 'at_risk' else 'behind' end;
        end if;
        -- التوقع بنهاية المرحلة بالوتيرة الحالية، والمطلوب شهرياً للوصول
        if c->>'kind' = 'flow' and current_date between ph.starts and ph.ends then
          if elapsed > 0.03 then fc := round(base + (val - base) / elapsed, 1); end if;
          if prog < 1 and months_left > 0 then need := round((g.target - val) / greatest(months_left, 0.5), 1); end if;
        end if;
        if st not in ('upcoming') then
          score_w := score_w + g.weight; score_s := score_s + g.weight * least(prog, 1);
          axis_s := jsonb_set(axis_s, array[c->>'axis'], jsonb_build_object(
            'w', coalesce((axis_s->(c->>'axis')->>'w')::numeric, 0) + g.weight,
            's', coalesce((axis_s->(c->>'axis')->>'s')::numeric, 0) + g.weight * least(prog, 1)));
        end if;
      end if;

      goals := goals || jsonb_build_object('id', g.id, 'metric', g.metric, 'title', coalesce(nullif(g.title, ''), c->>'label'),
        'target', g.target, 'baseline', g.baseline, 'base_used', base, 'mode', g.mode, 'scope_gov', g.scope_gov, 'scope_sector', g.scope_sector,
        'weight', g.weight, 'note', g.note, 'ord', g.ord,
        'actual', val, 'n', m->'n', 'coverage', m->'coverage', 'progress', round(prog * 100, 1), 'expected', round(elapsed * 100, 1),
        'status', st, 'forecast', fc, 'need_per_month', need);
    end loop;
    phases := phases || jsonb_build_object('id', ph.id, 'ord', ph.ord, 'title', ph.title, 'description', ph.description,
      'starts', ph.starts, 'ends', ph.ends, 'status', ph.status, 'approved_at', ph.approved_at, 'approved_by', ph.approved_by,
      'elapsed', round(elapsed * 100, 1), 'months_left', round(months_left, 1), 'current', ph.id = cur,
      'score', case when score_w > 0 then round(score_s / score_w * 100, 1) end,
      'axes', (select coalesce(jsonb_object_agg(key, round((value->>'s')::numeric / nullif((value->>'w')::numeric, 0) * 100, 1)), '{}') from jsonb_each(axis_s)),
      'goals', goals);
  end loop;

  -- الأرقام الوطنية الحالية لكل مؤشر (منذ بدء المبادرة)
  for k in select e->>'key' from jsonb_array_elements(cat) e loop
    totals := totals || jsonb_build_object(k, _plan_metric(k, s.start_date::timestamptz, v_now));
  end loop;

  return jsonb_build_object(
    'settings', to_jsonb(s) - 'updated_by', 'catalog', cat, 'phases', phases, 'current', cur, 'totals', totals,
    'can_edit', me.portal = 'planning',
    'by_gov', (select coalesce(jsonb_agg(q order by q.amount desc nulls last, q.apps desc), '[]') from (
        select governorate gov, count(*) apps, count(*) filter (where done_at is not null) completed, sum(disb_amt) amount, sum(kw) filter (where done_at is not null) kw
        from _plan_apps() where governorate is not null group by 1) q),
    'by_sector', (select coalesce(jsonb_agg(q order by q.amount desc nulls last), '[]') from (
        select sector key, count(*) apps, count(*) filter (where done_at is not null) completed, sum(disb_amt) amount, sum(kw) filter (where done_at is not null) kw
        from _plan_apps() group by 1) q),
    'monthly', (select coalesce(jsonb_agg(q order by q.m), '[]') from (
        select to_char(mm, 'YYYY-MM') m,
          (select count(*) from _plan_apps() a where date_trunc('month', a.sub_at) = mm) submitted,
          (select count(*) from _plan_apps() a where date_trunc('month', a.done_at) = mm) completed,
          (select coalesce(sum(disb_amt), 0) from _plan_apps() a where date_trunc('month', a.disb_at) = mm) amount,
          (select coalesce(sum(kw), 0) from _plan_apps() a where date_trunc('month', a.done_at) = mm) kw
        from generate_series(date_trunc('month', s.start_date::timestamptz), date_trunc('month', v_now), interval '1 month') mm) q),
    'log', (select coalesce(jsonb_agg(q order by q.at desc), '[]') from (select id, at, by_name, by_code, action, target, reason, before, after from plan_log order by at desc limit 60) q));
end $f$;

-- ───────── 7) تحرير الخارطة — وزارة التخطيط فقط ─────────
create or replace function public.planning_save_settings(p jsonb, p_reason text default null) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_settings;
begin
  select * into b from plan_settings where id = 1;
  update plan_settings set
    title = coalesce(nullif(trim(p->>'title'), ''), title), vision = coalesce(p->>'vision', vision),
    start_date = coalesce((p->>'start_date')::date, start_date), budget = coalesce((p->>'budget')::bigint, budget),
    yield_kwh_per_kw = coalesce((p->>'yield_kwh_per_kw')::numeric, yield_kwh_per_kw), co2_t_per_mwh = coalesce((p->>'co2_t_per_mwh')::numeric, co2_t_per_mwh),
    diesel_l_per_kwh = coalesce((p->>'diesel_l_per_kwh')::numeric, diesel_l_per_kwh), jobs_per_project = coalesce((p->>'jobs_per_project')::numeric, jobs_per_project),
    updated_at = now(), updated_by = me.id
  where id = 1;
  if (select budget from plan_settings) <= 0 or (select yield_kwh_per_kw from plan_settings) <= 0 then raise exception 'قيم غير صحيحة'; end if;
  perform _plan_log(me, 'تعديل إعدادات الخارطة', 'الإعدادات', p_reason, to_jsonb(b) - 'updated_by', (select to_jsonb(x) - 'updated_by' from plan_settings x where id = 1));
end $f$;

create or replace function public.planning_save_phase(p jsonb, p_reason text default null) returns uuid
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_phases; v_id uuid := nullif(p->>'id', '')::uuid;
begin
  if coalesce(trim(p->>'title'), '') = '' then raise exception 'اكتب اسم المرحلة'; end if;
  if (p->>'starts') is null or (p->>'ends') is null or (p->>'ends')::date <= (p->>'starts')::date then raise exception 'تاريخ نهاية المرحلة يجب أن يكون بعد بدايتها'; end if;
  if v_id is null then
    insert into plan_phases(ord, title, description, starts, ends)
    values (coalesce((p->>'ord')::int, (select coalesce(max(ord), 0) + 1 from plan_phases)), trim(p->>'title'), p->>'description', (p->>'starts')::date, (p->>'ends')::date)
    returning id into v_id;
    perform _plan_log(me, 'إضافة مرحلة', trim(p->>'title'), p_reason, null, (select to_jsonb(x) from plan_phases x where id = v_id));
  else
    select * into b from plan_phases where id = v_id;
    if b is null then raise exception 'المرحلة غير موجودة'; end if;
    if b.status = 'approved' and coalesce(trim(p_reason), '') = '' then raise exception 'المرحلة معتمدة — اكتب سبب التعديل'; end if;
    update plan_phases set ord = coalesce((p->>'ord')::int, ord), title = trim(p->>'title'), description = p->>'description',
      starts = (p->>'starts')::date, ends = (p->>'ends')::date, updated_at = now() where id = v_id;
    perform _plan_log(me, 'تعديل مرحلة', trim(p->>'title'), p_reason, to_jsonb(b), (select to_jsonb(x) from plan_phases x where id = v_id));
  end if;
  return v_id;
end $f$;

create or replace function public.planning_set_phase_status(p_id uuid, p_status text, p_reason text default null) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_phases;
begin
  select * into b from plan_phases where id = p_id;
  if b is null then raise exception 'المرحلة غير موجودة'; end if;
  if p_status not in ('draft', 'approved') then raise exception 'حالة غير صحيحة'; end if;
  if p_status = 'approved' and not exists (select 1 from plan_goals where phase_id = p_id) then raise exception 'أضف هدفاً واحداً على الأقل قبل اعتماد المرحلة'; end if;
  if p_status = 'draft' and b.status = 'approved' and coalesce(trim(p_reason), '') = '' then raise exception 'اكتب سبب إلغاء الاعتماد'; end if;
  update plan_phases set status = p_status,
    approved_at = case when p_status = 'approved' then now() end,
    approved_by = case when p_status = 'approved' then me.full_name end, updated_at = now() where id = p_id;
  perform _plan_log(me, case p_status when 'approved' then 'اعتماد مرحلة' else 'إلغاء اعتماد مرحلة' end, b.title, p_reason, to_jsonb(b), (select to_jsonb(x) from plan_phases x where id = p_id));
end $f$;

create or replace function public.planning_delete_phase(p_id uuid, p_reason text default null) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_phases;
begin
  select * into b from plan_phases where id = p_id;
  if b is null then return; end if;
  if b.status = 'approved' then raise exception 'لا تُحذف مرحلة معتمدة — ألغِ اعتمادها أولاً'; end if;
  perform _plan_log(me, 'حذف مرحلة', b.title, p_reason,
    to_jsonb(b) || jsonb_build_object('goals', (select coalesce(jsonb_agg(to_jsonb(x)), '[]') from plan_goals x where phase_id = p_id)), null);
  delete from plan_phases where id = p_id;
end $f$;

create or replace function public.planning_save_goal(p jsonb, p_reason text default null) returns uuid
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_goals; ph plan_phases; v_id uuid := nullif(p->>'id', '')::uuid; c jsonb;
begin
  select * into ph from plan_phases where id = (p->>'phase_id')::uuid;
  if ph is null then raise exception 'اختر المرحلة'; end if;
  c := (select e from jsonb_array_elements(_plan_catalog()) e where e->>'key' = p->>'metric');
  if c is null then raise exception 'اختر المؤشر'; end if;
  if (p->>'target') is null or (p->>'target')::numeric < 0 then raise exception 'اكتب القيمة المستهدفة'; end if;
  if c->>'unit' = '%' and (p->>'target')::numeric > 100 then raise exception 'النسبة المستهدفة لا تتجاوز 100%%'; end if;
  if ph.status = 'approved' and coalesce(trim(p_reason), '') = '' then raise exception 'المرحلة معتمدة — اكتب سبب التعديل'; end if;
  if nullif(p->>'scope_sector', '') is not null and p->>'scope_sector' not in ('residential', 'agricultural', 'industrial', 'project', 'vet', 'vet_program', 'export', 'other') then raise exception 'قطاع غير معروف'; end if;
  if v_id is null then
    insert into plan_goals(phase_id, metric, title, target, baseline, mode, scope_gov, scope_sector, weight, note, ord)
    values (ph.id, p->>'metric', nullif(trim(p->>'title'), ''), (p->>'target')::numeric, nullif(p->>'baseline', '')::numeric,
      coalesce(nullif(p->>'mode', ''), 'cumulative'), nullif(p->>'scope_gov', ''), nullif(p->>'scope_sector', ''),
      coalesce(nullif(p->>'weight', '')::numeric, 1), nullif(trim(p->>'note'), ''),
      coalesce((p->>'ord')::int, (select coalesce(max(ord), 0) + 1 from plan_goals where phase_id = ph.id)))
    returning id into v_id;
    perform _plan_log(me, 'إضافة هدف', ph.title || ' — ' || coalesce(nullif(trim(p->>'title'), ''), c->>'label'), p_reason, null, (select to_jsonb(x) from plan_goals x where id = v_id));
  else
    select * into b from plan_goals where id = v_id;
    if b is null then raise exception 'الهدف غير موجود'; end if;
    if b.phase_id <> ph.id and (select status from plan_phases where id = b.phase_id) = 'approved' and coalesce(trim(p_reason), '') = '' then raise exception 'اكتب سبب نقل الهدف من مرحلة معتمدة'; end if;
    update plan_goals set phase_id = ph.id, metric = p->>'metric', title = nullif(trim(p->>'title'), ''), target = (p->>'target')::numeric,
      baseline = nullif(p->>'baseline', '')::numeric, mode = coalesce(nullif(p->>'mode', ''), 'cumulative'),
      scope_gov = nullif(p->>'scope_gov', ''), scope_sector = nullif(p->>'scope_sector', ''),
      weight = coalesce(nullif(p->>'weight', '')::numeric, 1), note = nullif(trim(p->>'note'), ''), updated_at = now() where id = v_id;
    perform _plan_log(me, 'تعديل هدف', ph.title || ' — ' || coalesce(nullif(trim(p->>'title'), ''), c->>'label'), p_reason, to_jsonb(b), (select to_jsonb(x) from plan_goals x where id = v_id));
  end if;
  return v_id;
end $f$;

create or replace function public.planning_delete_goal(p_id uuid, p_reason text default null) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles := _plan_writer(); b plan_goals; ph plan_phases;
begin
  select * into b from plan_goals where id = p_id;
  if b is null then return; end if;
  select * into ph from plan_phases where id = b.phase_id;
  if ph.status = 'approved' and coalesce(trim(p_reason), '') = '' then raise exception 'المرحلة معتمدة — اكتب سبب الحذف'; end if;
  perform _plan_log(me, 'حذف هدف', ph.title || ' — ' || coalesce(b.title, b.metric), p_reason, to_jsonb(b), null);
  delete from plan_goals where id = p_id;
end $f$;

revoke all on function public._plan_catalog(), public._plan_apps(text, text), public._plan_metric(text, timestamptz, timestamptz, text, text),
  public._plan_reader(), public._plan_writer(), public._plan_log(profiles, text, text, text, jsonb, jsonb) from public, anon, authenticated;
revoke all on function public.planning_overview(), public.planning_save_settings(jsonb, text), public.planning_save_phase(jsonb, text),
  public.planning_set_phase_status(uuid, text, text), public.planning_delete_phase(uuid, text), public.planning_save_goal(jsonb, text),
  public.planning_delete_goal(uuid, text) from public, anon;
grant execute on function public.planning_overview(), public.planning_save_settings(jsonb, text), public.planning_save_phase(jsonb, text),
  public.planning_set_phase_status(uuid, text, text), public.planning_delete_phase(uuid, text), public.planning_save_goal(jsonb, text),
  public.planning_delete_goal(uuid, text) to authenticated;

-- ───────── 8) شاشة الدخول: احتساب الوزارة ضمن الجهات الحكومية ─────────
do $$
declare d text;
begin
  if to_regprocedure('public.public_brand(text)') is not null then
    d := pg_get_functiondef('public.public_brand(text)'::regprocedure);
    if position('''planning''' in d) = 0 then
      execute replace(d, '''syndicate'',''vetdept'')', '''syndicate'',''vetdept'',''planning'')');
    end if;
  end if;
end $$;

-- ───────── 9) الحساب التجريبي وخارطة تجريبية (تعدّلها الوزارة) ─────────
do $$
begin
  if not exists (select 1 from public.profiles where username = 'planning1') then
    perform public._mk_user('planning1', 'Mop@2026pl', 'د. نور عبد الأمير الحسناوي', 'planning_officer', 'planning', 'mop', null, null);
  end if;
  update public.profiles set manage_scope = 'org' where username = 'planning1' and manage_scope is null;
end $$;

do $$
declare p1 uuid; p2 uuid; p3 uuid;
begin
  if exists (select 1 from public.plan_phases) then return; end if;
  update public.plan_settings set vision = 'كهرباء نظيفة ومستقرة لكل بيت ومشروع منتج في المحافظات الثماني عشرة، بتمويل ميسّر يُسدَّد من وفورات المولّدات.' where id = 1;
  insert into public.plan_phases(ord, title, description, starts, ends, status, approved_at, approved_by) values
    (1, 'المرحلة الأولى — الإطلاق التجريبي', 'تشغيل المنصة مع المصارف الوسيطة الأولى وقياس مدة الإجراء وجودة التركيب في كل المحافظات.', date '2026-08-01', date '2026-12-31', 'approved', now(), 'د. نور عبد الأمير الحسناوي')
    returning id into p1;
  insert into public.plan_phases(ord, title, description, starts, ends, status, approved_at, approved_by) values
    (2, 'المرحلة الثانية — التوسع في المحافظات والقطاعات الإنتاجية', 'رفع حصة الزراعة والصناعة، وضبط التعثر، وتسريع الإجراء.', date '2027-01-01', date '2027-12-31', 'approved', now(), 'د. نور عبد الأمير الحسناوي')
    returning id into p2;
  insert into public.plan_phases(ord, title, description, starts, ends, status) values
    (3, 'المرحلة الثالثة — استكمال رصيد المبادرة', 'صرف كامل رصيد المبادرة وبلوغ القدرة المستهدفة وطنياً.', date '2028-01-01', date '2028-12-31', 'draft')
    returning id into p3;
  insert into public.plan_goals(phase_id, metric, target, baseline, mode, weight, ord) values
    (p1, 'loans_completed', 40, null, 'cumulative', 2, 1),
    (p1, 'kw_installed', 250, null, 'cumulative', 2, 2),
    (p1, 'amount_disbursed', 400000000, null, 'cumulative', 2, 3),
    (p1, 'gov_covered', 18, null, 'cumulative', 1, 4),
    (p1, 'share_outside_baghdad_pct', 70, null, 'cumulative', 1, 5),
    (p1, 'share_productive_pct', 20, null, 'cumulative', 1, 6),
    (p1, 'women_pct', 25, null, 'cumulative', 1, 7),
    (p1, 'avg_days_complete', 45, 90, 'cumulative', 1, 8),
    (p1, 'sla_pct', 85, null, 'cumulative', 1, 9),
    (p1, 'co2_t_year', 280, null, 'cumulative', 1, 10),
    (p2, 'loans_completed', 12000, null, 'cumulative', 2, 1),
    (p2, 'kw_installed', 150000, null, 'cumulative', 2, 2),
    (p2, 'amount_disbursed', 270000000000, null, 'cumulative', 2, 3),
    (p2, 'share_productive_pct', 35, null, 'cumulative', 1, 4),
    (p2, 'share_agri_pct', 20, null, 'cumulative', 1, 5),
    (p2, 'youth_pct', 40, null, 'cumulative', 1, 6),
    (p2, 'repay_on_time_pct', 92, null, 'cumulative', 1, 7),
    (p2, 'default_pct', 3, null, 'cumulative', 1, 8),
    (p2, 'jobs_expected', 8000, null, 'cumulative', 1, 9),
    (p2, 'avg_days_complete', 30, 45, 'cumulative', 1, 10),
    (p3, 'budget_use_pct', 100, null, 'cumulative', 2, 1),
    (p3, 'kw_installed', 500000, null, 'cumulative', 2, 2),
    (p3, 'diesel_kl_year', 240000, null, 'cumulative', 1, 3),
    (p3, 'co2_t_year', 560000, null, 'cumulative', 1, 4);
  insert into public.plan_log(by_name, action, target, reason)
  values ('د. نور عبد الأمير الحسناوي', 'إنشاء الخارطة', 'خارطة طريق المبادرة', 'خارطة تجريبية للعرض — تعدّلها الوزارة');
end $$;
