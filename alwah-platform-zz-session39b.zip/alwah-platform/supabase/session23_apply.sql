-- ═══════════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 23: رسائل SMS حقيقية
--   (أ) رمز تحقق حقيقي يُرسل برسالة نصية إلى الهاتف المعني (المقترض، الكفيل، مالك العقار)
--   (ب) إشعار المقترض برسالة نصية بكل ما يُطلب منه
--   (ج) صندوق صادر تسحب منه خدمة الإرسال في خادم المنصة (server/sms.js)
-- يمكن تشغيله أكثر من مرة دون ضرر. وضع المطور (1234) يبقى يعمل حتى تطفئه الإدارة.
-- ═══════════════════════════════════════════════════════════════════════════
create schema if not exists private;

-- ───────── 1) الجداول (في المخطط الخاص — لا يصلها أي مستخدم) ─────────
create table if not exists private.otp_codes (
  id uuid primary key default gen_random_uuid(),
  phone text not null,
  kind text not null,
  code_hash text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  attempts int not null default 0,
  verified_at timestamptz,
  ticket text unique,
  ticket_expires timestamptz
);
create index if not exists otp_codes_phone on private.otp_codes(phone, created_at desc);

create table if not exists private.sms_outbox (
  id bigserial primary key,
  phone text not null,
  kind text not null check (kind in ('otp', 'notice', 'test', 'link')),
  body text not null,
  code text,
  app_id uuid,
  user_id uuid,
  dedupe text unique,
  status text not null default 'queued' check (status in ('queued', 'sending', 'sent', 'failed', 'expired', 'skipped')),
  attempts int not null default 0,
  not_before timestamptz not null default now(),
  created_at timestamptz not null default now(),
  sent_at timestamptz,
  provider text,
  provider_id text,
  error text
);
create index if not exists sms_outbox_queue on private.sms_outbox(status, not_before);
create index if not exists sms_outbox_day on private.sms_outbox(created_at);

-- الأرقام التي ثبت أن أصحابها يستلمون الرسائل (تحقق برمز حقيقي مرة واحدة على الأقل)
create table if not exists private.sms_phones (
  phone text primary key,
  verified_at timestamptz not null default now()
);

create table if not exists private.sms_config (
  id int primary key default 1 check (id = 1),
  provider text,
  public_url text,
  seen_at timestamptz,
  last_error text,
  last_error_at timestamptz
);
insert into private.sms_config(id) values (1) on conflict do nothing;
revoke all on all tables in schema private from public, anon, authenticated;

insert into settings(key, value, label, circular_no) values
  ('sms_daily_cap', 1000, 'الحد الأعلى لعدد الرسائل النصية في اليوم (حماية من الإساءة والكلفة)', null),
  ('sms_notify', 1, 'إشعار المقترض برسالة نصية بكل ما يُطلب منه (1 مفعّل، 0 متوقف)', null)
on conflict (key) do nothing;

-- ───────── 2) دوال مساعدة ─────────
create or replace function public._sms_live() returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select provider is not null and seen_at > now() - interval '30 days' from private.sms_config where id = 1), false) $f$;

create or replace function public._sms_url() returns text
language sql stable security definer set search_path to 'public' as $f$
  select coalesce(nullif((select public_url from private.sms_config where id = 1), ''), 'https://alwah-platform.onrender.com') $f$;

-- الرسائل غير العاجلة لا تُرسل ليلاً: بين 10 مساءً و8 صباحاً بتوقيت بغداد تؤجَّل إلى 8 صباحاً
create or replace function public._sms_not_before() returns timestamptz
language plpgsql stable as $f$
declare t timestamp := now() at time zone 'Asia/Baghdad'; h int := extract(hour from t);
begin
  if h >= 22 then return ((t::date + 1) + time '08:00') at time zone 'Asia/Baghdad'; end if;
  if h < 8 then return (t::date + time '08:00') at time zone 'Asia/Baghdad'; end if;
  return now();
end $f$;

create or replace function public._sms_mask(p text) returns text language sql immutable as $f$
  select case when length(coalesce(p, '')) >= 7 then left(p, 4) || '••••' || right(p, 3) else p end $f$;

create or replace function public._sms_cap_ok() returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select (select count(*) from private.sms_outbox where created_at >= date_trunc('day', now() at time zone 'Asia/Baghdad') at time zone 'Asia/Baghdad'
          and status in ('queued', 'sending', 'sent')) < coalesce(_setting('sms_daily_cap'), 1000) $f$;

-- إدراج رسالة في الصندوق الصادر (غير عاجلة) مع منع التكرار
create or replace function public._sms_enqueue(p_phone text, p_kind text, p_body text, p_app uuid, p_user uuid, p_dedupe text, p_require_verified boolean default true)
returns void language plpgsql security definer set search_path to 'public' as $f$
declare st text := 'queued'; er text;
begin
  if p_phone is null or p_phone !~ '^07[3-9][0-9]{8}$' then return; end if;
  if p_dedupe is not null and exists (select 1 from private.sms_outbox where dedupe = p_dedupe) then return; end if;
  if not _sms_live() then st := 'skipped'; er := 'خدمة الرسائل غير مربوطة بعد';
  elsif p_kind = 'notice' and coalesce(_setting('sms_notify'), 1) = 0 then st := 'skipped'; er := 'إشعارات المقترضين بالرسائل متوقفة من الإدارة';
  elsif p_require_verified and not exists (select 1 from private.sms_phones where phone = p_phone) then st := 'skipped'; er := 'الرقم لم يُتحقق منه برمز حقيقي بعد';
  elsif not _sms_cap_ok() then st := 'skipped'; er := 'تجاوز الحد اليومي للرسائل'; end if;
  insert into private.sms_outbox(phone, kind, body, app_id, user_id, dedupe, status, error, not_before)
  values (p_phone, p_kind, left(p_body, 480), p_app, p_user, p_dedupe, st, er, case when p_kind = 'notice' then _sms_not_before() else now() end)
  on conflict (dedupe) do nothing;
end $f$;

-- ───────── 3) رمز التحقق الحقيقي ─────────
-- التحقق: رمز وضع المطور 1234 (إن كان مفعّلاً)، أو «تذكرة» تصدر بعد إدخال الرمز الصحيح، مربوطة برقم الهاتف وصالحة ساعة
create or replace function public._otp_ok(p_code text, p_phone text) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select case
    when coalesce((select value from settings where key = 'dev_mode'), 0) = 1 and trim(coalesce(p_code, '')) = '1234' then true
    when coalesce(p_code, '') like 'T%' and p_phone is not null then exists (select 1 from private.otp_codes o where o.ticket = p_code and o.phone = p_phone and o.ticket_expires > now())
    else false end $f$;

-- الصيغة القديمة (دون رقم): تُستخدم لعمليات المقترض على طلبه — التذكرة يجب أن تكون لهاتفه المسجل
create or replace function public._otp_ok(p_code text) returns boolean
language sql stable security definer set search_path to 'public' as $f$
  select case
    when coalesce((select value from settings where key = 'dev_mode'), 0) = 1 and trim(coalesce(p_code, '')) = '1234' then true
    when coalesce(p_code, '') like 'T%' then exists (select 1 from private.otp_codes o join profiles p on p.id = auth.uid() and p.phone = o.phone
                                                      where o.ticket = p_code and o.ticket_expires > now())
    else false end $f$;

-- طلب رمز: يحدد النص من نوع العملية (لا يُقبل نص حر من المتصفح)
create or replace function public.otp_request(p_phone text, p_kind text, p_ref text default null) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare ph text := _norm_phone(p_phone); me profiles; a applications; l app_links; last_at timestamptz; n_hour int; code text; b bytea;
  why text; nm text; amt bigint; dev boolean := coalesce(_setting('dev_mode'), 0) = 1; oid uuid;
begin
  if p_kind not in ('register', 'reset', 'phone_change', 'guarantor', 'owner', 'pay', 'sign', 'ur', 'schedule', 'verify') then raise exception 'نوع رمز التحقق غير معروف'; end if;
  select * into me from profiles where id = auth.uid();

  if p_kind = 'register' then
    if exists (select 1 from profiles where phone = ph or username = ph) then raise exception 'رقم الهاتف مسجل مسبقاً — سجّل الدخول أو استعد كلمة المرور'; end if;
    why := 'لإنشاء حسابك في منصة ألواح';
  elsif p_kind = 'reset' then
    if not exists (select 1 from profiles where phone = ph and portal = 'citizen' and self_registered) then raise exception 'لا يوجد حساب منشأ بهذا الرقم'; end if;
    why := 'لاستعادة كلمة المرور في ألواح';
  elsif p_kind = 'phone_change' then
    if me is null then raise exception 'غير مسجل الدخول'; end if;
    if exists (select 1 from profiles where (phone = ph or username = ph) and id <> me.id) then raise exception 'الرقم مستخدم بحساب آخر'; end if;
    why := 'لتأكيد رقم هاتفك الجديد في ألواح';
  elsif p_kind in ('guarantor', 'owner') then
    -- من رابط الكفيل (دون تسجيل) أو من المقترض صاحب الطلب
    if p_ref is not null and p_ref !~ '^[0-9a-f]{8}-' then
      select * into l from app_links where token = p_ref;
      if l.token is null or _link_state(l) <> 'ok' or l.kind <> 'guarantor' or l.data->>'phone' is distinct from ph then raise exception 'الرابط غير صحيح أو انتهت صلاحيته'; end if;
      select * into a from applications where id = l.application_id;
    else
      if me is null then raise exception 'غير مسجل الدخول'; end if;
      begin oid := p_ref::uuid; exception when others then oid := null; end;
      select * into a from applications where id = oid and citizen_id = me.id;
      if a.id is null then raise exception 'الطلب لا يخصك'; end if;
      if ph = me.phone then raise exception '%', case when p_kind = 'guarantor' then 'لا يكفل المتقدم نفسه' else 'بيانات المالك هي بياناتك — اختر «أنا مالك العقار»' end; end if;
    end if;
    if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
    nm := split_part(a.citizen_name, ' ', 1) || ' ' || split_part(a.citizen_name, ' ', 2);
    amt := coalesce(a.amount, a.price);
    why := case when p_kind = 'guarantor' then 'لموافقتك على كفالة ' || nm || ' في تمويل ' || to_char(amt, 'FM999,999,999,999') || ' د.ع. لا تعطِه لأحد إن لم توافق'
                else 'لموافقتك على رهن عقارك ضماناً لتمويل ' || nm || ' بمبلغ ' || to_char(amt, 'FM999,999,999,999') || ' د.ع. لا تعطِه لأحد إن لم توافق' end;
  else
    -- عمليات المقترض على طلبه: الرمز إلى هاتفه المسجل فقط
    if me is null then raise exception 'غير مسجل الدخول'; end if;
    if ph is distinct from me.phone then raise exception 'يُرسل الرمز إلى هاتفك المسجل فقط'; end if;
    why := case p_kind when 'pay' then 'لتأكيد دفع العمولة والرسوم' when 'sign' then 'للتوقيع الإلكتروني على طلب التمويل'
      when 'ur' then 'لربط رقم «أور» بطلبك' when 'schedule' then 'للتوقيع على استلام جدول أقساطك' else 'لتفعيل إشعارات طلبك برسائل نصية' end;
  end if;

  if not _sms_live() then
    if dev then return jsonb_build_object('sent', false, 'mode', 'dev'); end if;
    raise exception 'خدمة الرسائل النصية غير متاحة الآن — حاول لاحقاً أو تواصل مع إدارة المنصة';
  end if;

  select max(created_at), count(*) filter (where created_at > now() - interval '1 hour') into last_at, n_hour from private.otp_codes where phone = ph;
  if last_at > now() - interval '55 seconds' then
    return jsonb_build_object('sent', false, 'mode', 'sms', 'wait', greatest(5, 60 - extract(epoch from now() - last_at)::int));
  end if;
  if n_hour >= 5 then raise exception 'طُلبت رموز كثيرة لهذا الرقم — حاول بعد ساعة'; end if;
  if not _sms_cap_ok() then raise exception 'تعذّر إرسال الرسالة الآن — حاول لاحقاً'; end if;

  b := gen_random_bytes(2);
  code := lpad(((get_byte(b, 0) * 256 + get_byte(b, 1)) % 10000)::text, 4, '0');
  update private.otp_codes set expires_at = now() where phone = ph and verified_at is null and expires_at > now();
  insert into private.otp_codes(phone, kind, code_hash, expires_at)
  values (ph, p_kind, encode(digest(ph || ':' || code, 'sha256'), 'hex'), now() + interval '10 minutes');
  insert into private.sms_outbox(phone, kind, body, code, app_id, user_id)
  values (ph, 'otp', 'ألواح: رمز التحقق ' || code || ' ' || why || '. صالح 10 دقائق.', code, a.id, me.id);
  return jsonb_build_object('sent', true, 'mode', 'sms', 'wait', 60, 'ttl', 600);
end $f$;

-- إدخال الرمز: لا يرمي خطأ عند الرمز الخاطئ (كي تُحسب المحاولات)، ويعيد تذكرة تُمرَّر للعملية
create or replace function public.otp_check(p_phone text, p_code text) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare ph text := _norm_phone(p_phone); c text := regexp_replace(coalesce(p_code, ''), '[^0-9]', '', 'g'); r private.otp_codes; tk text;
begin
  if coalesce(_setting('dev_mode'), 0) = 1 and c = '1234' then return jsonb_build_object('ok', true, 'ticket', '1234', 'mode', 'dev'); end if;
  select * into r from private.otp_codes where phone = ph and verified_at is null and expires_at > now() order by created_at desc limit 1 for update;
  if r.id is null then return jsonb_build_object('ok', false, 'error', 'انتهت صلاحية الرمز أو لم يُرسل بعد — اضغط «إعادة الإرسال»'); end if;
  if r.attempts >= 5 then return jsonb_build_object('ok', false, 'error', 'أخطأت 5 مرات — اضغط «إعادة الإرسال» لرمز جديد'); end if;
  if r.code_hash is distinct from encode(digest(ph || ':' || c, 'sha256'), 'hex') then
    update private.otp_codes set attempts = attempts + 1 where id = r.id;
    return jsonb_build_object('ok', false, 'error', 'رمز التحقق غير صحيح', 'left', 4 - r.attempts);
  end if;
  tk := 'T' || translate(encode(gen_random_bytes(24), 'base64'), '+/=', '-_');
  update private.otp_codes set verified_at = now(), ticket = tk, ticket_expires = now() + interval '60 minutes' where id = r.id;
  insert into private.sms_phones(phone) values (ph) on conflict (phone) do update set verified_at = now();
  return jsonb_build_object('ok', true, 'ticket', tk, 'mode', 'sms');
end $f$;

create or replace function public.verify_otp(p_phone text, p_code text, p_purpose text default 'generic') returns boolean
language plpgsql security definer set search_path to 'public' as $f$
begin
  if not _otp_ok(p_code, _norm_phone(p_phone)) then raise exception 'رمز التحقق غير صحيح'; end if;
  return true;
end $f$;

create or replace function public.public_config() returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('dev_mode', coalesce(_setting('dev_mode'), 0) = 1,
                            'dev_otp', case when coalesce(_setting('dev_mode'), 0) = 1 then '1234' end,
                            'sms', _sms_live()) $f$;

-- حالة الإشعارات النصية للمقترض نفسه
create or replace function public.my_sms_status() returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('live', _sms_live(), 'notify', coalesce(_setting('sms_notify'), 1) = 1,
    'verified', exists (select 1 from private.sms_phones s join profiles p on p.phone = s.phone where p.id = auth.uid())) $f$;

-- ───────── 4) ربط رمز التحقق برقم الهاتف الصحيح في الدوال القائمة ─────────
do $$
declare d text; f text; pair text[]; ok boolean;
  fixes text[][] := array[
    array['public._citizen_step_solar(uuid,integer,jsonb)', '_otp_ok(g->>''otp'')', '_otp_ok(g->>''otp'', ph)'],
    array['public._vet_step(uuid,integer,jsonb)', '_otp_ok(g->>''otp'')', '_otp_ok(g->>''otp'', ph)'],
    array['public.set_property_ownership(uuid,jsonb)', '_otp_ok(p_data->>''owner_otp'')', '_otp_ok(p_data->>''owner_otp'', oph)'],
    array['public.register_citizen(text,text,text,text,date,text,text)', '_otp_ok(p_otp)', '_otp_ok(p_otp, ph)'],
    array['public.reset_password_otp(text,text,text)', '_otp_ok(p_otp)', '_otp_ok(p_otp, ph)'],
    array['public.change_my_phone(text,text)', '_otp_ok(p_otp)', '_otp_ok(p_otp, ph)'],
    array['public.register_borrower(jsonb)', '_otp_ok(p->>''otp'')', '_otp_ok(p->>''otp'', ph)'],
    array['public.link_guarantor_consent(text,text,boolean)', '_otp_ok(p_otp)', '_otp_ok(p_otp, l.data->>''phone'')']];
begin
  for i in 1 .. array_length(fixes, 1) loop
    if to_regprocedure(fixes[i][1]) is null then continue; end if;
    d := pg_get_functiondef(fixes[i][1]::regprocedure);
    if position(fixes[i][3] in d) > 0 then continue; end if;            -- مطبق مسبقاً
    if position(fixes[i][2] in d) = 0 then raise exception 'الجلسة 23: لم يُعثر على فحص رمز التحقق في %', fixes[i][1]; end if;
    execute replace(d, fixes[i][2], fixes[i][3]);
  end loop;
end $$;

-- لا يُطفأ وضع المطور قبل ربط خدمة الرسائل (وإلا لن يستطيع أحد الدخول أو التسجيل)
do $$
declare d text := pg_get_functiondef('public.admin_set_setting(text,numeric)'::regprocedure);
  o1 text := 'if p_key not in (''platform_fee'', ''inspection_fee'', ''dev_mode'', ''alloc_warn'')';
  n1 text := 'if p_key = ''dev_mode'' and p_value = 0 and not _sms_live() then raise exception ''اربط خدمة الرسائل النصية أولاً — إطفاء وضع المطور دونها يمنع الجميع من التسجيل والدخول''; end if;
  if p_key not in (''platform_fee'', ''inspection_fee'', ''dev_mode'', ''alloc_warn'', ''sms_daily_cap'', ''sms_notify'')';
  o2 text := '(p_key = ''dev_mode'' and p_value not in (0, 1))'; n2 text := '(p_key in (''dev_mode'', ''sms_notify'') and p_value not in (0, 1)) or (p_key = ''sms_daily_cap'' and p_value > 100000)';
begin
  if position('_sms_live' in d) = 0 then
    if position(o1 in d) = 0 or position(o2 in d) = 0 then raise exception 'الجلسة 23: لم يُعثر على نص admin_set_setting'; end if;
    execute replace(replace(d, o1, n1), o2, n2);
  end if;
end $$;

-- ───────── 5) إشعار المقترض برسالة نصية بكل ما يُطلب منه ─────────
-- كل إشعار داخل المنصة يخص المقترض ومن الأنواع أدناه يُرسل أيضاً برسالة نصية إلى هاتفه
create or replace function public._sms_from_notification() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare p profiles; code text;
begin
  if new.user_id is null or new.kind not in ('fix_request', 'returned', 'site_link', 'guarantor_link', 'approved_sign', 'esign', 'schedule', 'installment_due', 'installment_late') then return new; end if;
  select * into p from profiles where id = new.user_id;
  if p.portal is distinct from 'citizen' then return new; end if;
  select a.code into code from applications a where a.id = new.ref_id;
  perform _sms_enqueue(p.phone, 'notice',
    'ألواح' || coalesce(' · طلب ' || code, '') || ': ' || new.title || '. ' || coalesce(new.body || ' ', '') || _sms_url() || '/borrower',
    new.ref_id, p.id, 'n:' || new.id::text);
  return new;
end $f$;
drop trigger if exists trg_sms_notify on notifications;
create trigger trg_sms_notify after insert on notifications for each row execute function _sms_from_notification();

-- أحداث الطلب التي تتطلب شيئاً من المقترض ولم يكن لها إشعار
-- مشغّل مؤجَّل حتى نهاية المعاملة: يقرأ الطلب بحالته النهائية (بعض الإجراءات تعدّل الطلب مرتين)
create or replace function public._borrower_asks() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; br text; t text; b text; k text;
begin
  select * into a from applications where id = new.id;
  if a.id is null or a.citizen_id is null then return null; end if;
  select name into br from branches where id = a.branch_id;
  if a.status = 'returned' and a.stage <= 5 and a.returned_at is not null and a.returned_at > now() - interval '1 hour' then
    -- إرجاع الطلب إلى المقترض لإكمال نواقص (من الاستقبال أو بقرار الخبير)
    if not exists (select 1 from notifications where ref_id = a.id and kind = 'returned' and created_at >= least(a.returned_at, now())) then
      k := 'returned'; t := 'أُعيد طلبك إليك لإكمال نواقص';
      b := coalesce('المطلوب: ' || left(regexp_replace(regexp_replace(trim(replace(nullif(a.return_note, ''), '★', '')), '\s*\n[\s★]*', '، ', 'g'), '\s+', ' ', 'g'), 120) || '. ', '') || 'افتح «طلبي» وأصلحها من هاتفك ثم أعد الإرسال.';
    end if;
  elsif a.status = 'active' and a.stage = 25 and new.stage = 25 then
    if not exists (select 1 from notifications where ref_id = a.id and kind = 'approved_sign') then
      k := 'approved_sign'; t := 'صدرت الموافقة على تمويلك';
      b := 'المطلوب منك: توقيع عقد التمويل والكمبيالة' || coalesce(' في ' || br, '') || '، أو إلكترونياً من «طلبي» حين يصلك رابط التوقيع.';
    end if;
  elsif a.status = 'active' and a.stage = 34 and new.stage = 34 then
    if not exists (select 1 from notifications where ref_id = a.id and kind = 'schedule') then
      k := 'schedule'; t := 'جدول أقساطك جاهز';
      b := case when _bank_opt(a.bank_id, 'opt_phone_schedule') then 'استلمه من هاتفك: افتح «طلبي» واضغط «استلمت جدول أقساطي».'
                else 'راجع ' || coalesce(br, 'فرعك') || ' لاستلامه والتوقيع على الاستلام.' end;
    end if;
  end if;
  if k is not null then
    insert into notifications(user_id, kind, title, body, ref_id) values (a.citizen_id, k, t, b, a.id);
  end if;
  return null;
end $f$;
drop trigger if exists trg_borrower_asks on applications;
create constraint trigger trg_borrower_asks after update of stage, status, returned_at on applications
  deferrable initially deferred for each row execute function _borrower_asks();

-- رابط التوقيع الإلكتروني للعقد
create or replace function public._borrower_esign_ask() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare a applications;
begin
  if new.status <> 'sent' then return new; end if;
  select * into a from applications where id = new.application_id;
  if a.citizen_id is null then return new; end if;
  insert into notifications(user_id, kind, title, body, ref_id)
  values (a.citizen_id, 'esign', 'عقد تمويلك جاهز للتوقيع الإلكتروني',
    'افتح «طلبي» ووقّع من هاتفك' || coalesce(' قبل ' || to_char(new.expires_at at time zone 'Asia/Baghdad', 'YYYY-MM-DD'), '') || '.', a.id);
  return new;
end $f$;
drop trigger if exists trg_borrower_esign on esign_requests;
create trigger trg_borrower_esign after insert on esign_requests for each row execute function _borrower_esign_ask();

-- تذكير الأقساط: قبل الاستحقاق بثلاثة أيام، وبعد التأخر بيوم (مرة واحدة لكل قسط)
create or replace function public._sms_installment_sweep() returns int
language plpgsql security definer set search_path to 'public' as $f$
declare r record; n int := 0; today date := (now() at time zone 'Asia/Baghdad')::date;
begin
  for r in select i.id, i.n, i.amount, i.due_date, a.id app_id, a.citizen_id, (i.due_date < today) late
           from installments i join applications a on a.id = i.application_id
           where i.paid_at is null and a.citizen_id is not null and a.status not in ('cancelled', 'rejected')
             and ((i.due_date between today and today + 3) or (i.due_date between today - 30 and today - 1))
             and not exists (select 1 from notifications x where x.ref_id = a.id and x.kind = case when i.due_date < today then 'installment_late' else 'installment_due' end
                             and x.body like '%رقم ' || i.n || ' %') loop
    insert into notifications(user_id, kind, title, body, ref_id) values (r.citizen_id,
      case when r.late then 'installment_late' else 'installment_due' end,
      case when r.late then 'قسطك متأخر' else 'تذكير بموعد قسطك' end,
      'القسط رقم ' || r.n || ' بمبلغ ' || to_char(r.amount, 'FM999,999,999,999') || ' د.ع ' ||
        case when r.late then 'استحق في ' || to_char(r.due_date, 'YYYY-MM-DD') || ' — سدّده في أقرب وقت.' else 'يستحق في ' || to_char(r.due_date, 'YYYY-MM-DD') || '.' end,
      r.app_id);
    n := n + 1;
  end loop;
  return n;
end $f$;

-- إرسال رابط موافقة الكفيل إليه برسالة من المنصة (بدل الواتساب)
create or replace function public.link_send_sms(p_token text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; l app_links; a applications; nm text;
begin
  select * into me from profiles where id = auth.uid();
  select * into l from app_links where token = p_token;
  select * into a from applications where id = l.application_id;
  if me is null or a.citizen_id is distinct from me.id then raise exception 'الرابط لا يخص طلبك'; end if;
  if l.kind <> 'guarantor' or _link_state(l) <> 'ok' then raise exception 'الرابط غير صالح — أنشئ رابطاً جديداً'; end if;
  if not _sms_live() then raise exception 'خدمة الرسائل النصية غير مربوطة بعد — أرسل الرابط بالواتساب'; end if;
  if exists (select 1 from private.sms_outbox where dedupe = 'link:' || l.token) then raise exception 'أُرسل هذا الرابط برسالة من قبل'; end if;
  if (select count(*) from private.sms_outbox where app_id = a.id and kind = 'link' and created_at > now() - interval '1 day') >= 6 then raise exception 'أُرسلت روابط كثيرة اليوم — حاول غداً'; end if;
  nm := split_part(a.citizen_name, ' ', 1) || ' ' || split_part(a.citizen_name, ' ', 2);
  perform _sms_enqueue(l.data->>'phone', 'link', 'ألواح: يطلب ' || nm || ' موافقتك على كفالته في تمويل ' || to_char(a.amount, 'FM999,999,999,999') ||
    ' د.ع. اقرأ التفاصيل ووافق أو اعتذر: ' || _sms_url() || '/l/' || l.token, a.id, me.id, 'link:' || l.token, false);
  return jsonb_build_object('ok', true, 'status', (select status from private.sms_outbox where dedupe = 'link:' || l.token), 'phone', _sms_mask(l.data->>'phone'));
end $f$;

-- ───────── 6) خدمة الإرسال في الخادم (بالسر المشترك نفسه للتوقيع الإلكتروني) ─────────
create or replace function public.sms_hello(p_secret text, p_provider text, p_public_url text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  update private.sms_config set provider = nullif(p_provider, ''), public_url = coalesce(nullif(p_public_url, ''), public_url), seen_at = now() where id = 1;
  return jsonb_build_object('ok', true, 'live', _sms_live());
end $f$;

create or replace function public.sms_claim(p_secret text, p_limit int default 20) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare out jsonb;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  update private.sms_config set seen_at = now() where id = 1;
  update private.sms_outbox set status = 'expired', error = 'انتهت صلاحية الرمز قبل إرساله' where kind = 'otp' and status in ('queued', 'sending') and created_at < now() - interval '9 minutes';
  update private.sms_outbox set status = 'queued' where status = 'sending' and sent_at is null and not_before < now() - interval '3 minutes';
  with c as (select id from private.sms_outbox where status = 'queued' and not_before <= now()
             order by (kind = 'otp') desc, id limit least(greatest(p_limit, 1), 50) for update skip locked),
       u as (update private.sms_outbox o set status = 'sending', attempts = o.attempts + 1, not_before = now() from c where o.id = c.id returning o.*)
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'phone', phone, 'kind', kind, 'body', body, 'code', code) order by (kind = 'otp') desc, id), '[]')
    into out from u;
  return out;
end $f$;

create or replace function public.sms_mark(p_secret text, p_id bigint, p_ok boolean, p_provider text default null, p_provider_id text default null, p_error text default null) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  if p_ok then
    update private.sms_outbox set status = 'sent', sent_at = now(), provider = p_provider, provider_id = left(p_provider_id, 120), error = null where id = p_id;
  else
    update private.sms_outbox set provider = p_provider, error = left(p_error, 400),
      status = case when kind = 'otp' or attempts >= 3 then 'failed' else 'queued' end,
      not_before = now() + (attempts * interval '2 minutes') where id = p_id;
    update private.sms_config set last_error = left(p_error, 400), last_error_at = now() where id = 1;
  end if;
end $f$;

create or replace function public.sms_sweep(p_secret text) returns int
language plpgsql security definer set search_path to 'public' as $f$
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  delete from private.otp_codes where created_at < now() - interval '30 days';
  return _sms_installment_sweep();
end $f$;

-- ───────── 7) لوحة مشغّل النظام ─────────
create or replace function public.admin_sms_status() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare c private.sms_config; d0 timestamptz := date_trunc('day', now() at time zone 'Asia/Baghdad') at time zone 'Asia/Baghdad';
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into c from private.sms_config where id = 1;
  return jsonb_build_object('live', _sms_live(), 'provider', c.provider, 'seen_at', c.seen_at, 'last_error', c.last_error, 'last_error_at', c.last_error_at,
    'dev_mode', coalesce(_setting('dev_mode'), 0) = 1, 'notify', coalesce(_setting('sms_notify'), 1) = 1, 'cap', coalesce(_setting('sms_daily_cap'), 1000),
    'verified_phones', (select count(*) from private.sms_phones),
    'today', (select coalesce(jsonb_object_agg(status, n), '{}') from (select status, count(*) n from private.sms_outbox where created_at >= d0 group by status) q),
    'items', (select coalesce(jsonb_agg(x order by (x->>'id')::bigint desc), '[]') from (
      select jsonb_build_object('id', id, 'at', created_at, 'sent_at', sent_at, 'phone', _sms_mask(phone), 'kind', kind, 'status', status, 'error', error,
        'body', case when code is not null then replace(body, code, '••••') else body end) x
      from private.sms_outbox order by id desc limit 40) q));
end $f$;

create or replace function public.admin_sms_test(p_phone text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare ph text := _norm_phone(p_phone);
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if not _sms_live() then raise exception 'خدمة الرسائل غير مربوطة بعد — أضف إعدادات المزوّد في Render ثم أعد النشر'; end if;
  insert into private.sms_outbox(phone, kind, body) values (ph, 'test', 'ألواح: رسالة تجربة من لوحة مشغّل النظام — خدمة الرسائل تعمل.');
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 8) الصلاحيات ─────────
revoke execute on function public._otp_ok(text, text), public._sms_live(), public._sms_url(), public._sms_cap_ok(),
  public._sms_enqueue(text, text, text, uuid, uuid, text, boolean), public._sms_installment_sweep() from public, anon, authenticated;
revoke execute on function public.otp_request(text, text, text), public.otp_check(text, text), public.link_send_sms(text), public.my_sms_status(),
  public.sms_hello(text, text, text), public.sms_claim(text, integer), public.sms_mark(text, bigint, boolean, text, text, text), public.sms_sweep(text),
  public.admin_sms_status(), public.admin_sms_test(text) from public;
grant execute on function public.otp_request(text, text, text), public.otp_check(text, text), public.public_config(), public.verify_otp(text, text, text),
  public.sms_hello(text, text, text), public.sms_claim(text, integer), public.sms_mark(text, bigint, boolean, text, text, text), public.sms_sweep(text) to anon, authenticated;
grant execute on function public.link_send_sms(text), public.my_sms_status(), public.admin_sms_status(), public.admin_sms_test(text) to authenticated;
