-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 29
--  (1) شعارات الجهات في الصفحة الرئيسية: فهرس عام خفيف + جلب شعار واحد بمفتاحه (دون تسجيل)
--  (2) وزارة المالية — بوابة /finance ودور finance_officer:
--      ترى الأثر المالي للمبادرة على المال العام بأرقام مجمّعة (دون أسماء المقترضين):
--      الانكشاف على رواتب موظفي الدولة، كلفة دعم الفائدة، أثر الإعفاء الكمركي على سعر الكيلوواط،
--      المبيعات الخاضعة للضريبة، والمصارف والمحافظات والقطاعات.
--      تكتب على شيء واحد فقط: «تعاميم الوزارة» (مسودة ← إصدار ← سحب بسبب)، ويصل التعميم الصادر
--      إشعاراً إلى الجهات المعنية. لا تكتب على أي معاملة، ولا توافق ولا ترفض أي قرض.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) شعارات الصفحة الرئيسية ─────────
-- فهرس بلا صور: أي جهة لها شعار ومتى حُدّث (للتحديث الفوري دون تخزين قديم)
create or replace function public.public_logo_index() returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object(
    'portals', coalesce((select jsonb_object_agg(substr(key, 8), extract(epoch from updated_at)::bigint) from brand_logos where key like 'portal:%'), '{}'::jsonb),
    'banks', coalesce((select jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name, 'islamic', o.is_islamic,
        'v', (select extract(epoch from b.updated_at)::bigint from brand_logos b where b.key = 'org:' || o.id)) order by o.code)
      from orgs o where o.type = 'bank'), '[]'::jsonb)) $f$;

create or replace function public.public_logo(p_key text) returns text
language sql stable security definer set search_path to 'public' as $f$
  select image from brand_logos where key = p_key and (key ~ '^portal:[a-z]+$' or key ~ '^org:[0-9a-f-]{36}$') $f$;

revoke all on function public.public_logo_index(), public.public_logo(text) from public;
grant execute on function public.public_logo_index(), public.public_logo(text) to anon, authenticated;

-- ───────── 2) وزارة المالية: نوع الجهة والبوابة والدور ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance']));

insert into public.orgs(code, type, name)
select 'mof', 'finance', 'وزارة المالية'
where not exists (select 1 from public.orgs where type = 'finance');

-- الدور finance_officer يُضاف بجانب planning_officer في دوال الأدوار (دون المساس بباقي محتواها)
do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''planning_officer'' then ''PL''', 'when ''planning_officer'' then ''PL'' when ''finance_officer'' then ''MF'''],
  ['public._role_title(text)', 'when ''planning_officer'' then ''مخطط — وزارة التخطيط''', 'when ''planning_officer'' then ''مخطط — وزارة التخطيط'' when ''finance_officer'' then ''محلل مالي — وزارة المالية'''],
  ['public._portal_of_role(text)', 'when r = ''planning_officer'' then ''planning''', 'when r = ''planning_officer'' then ''planning'' when r = ''finance_officer'' then ''finance'''],
  ['public._org_type_of_portal(text)', 'when ''planning'' then ''planning''', 'when ''planning'' then ''planning'' when ''finance'' then ''finance'''],
  ['public._org_roles(text)', 'when ''planning'' then array[''planning_officer'']', 'when ''planning'' then array[''planning_officer''] when ''finance'' then array[''finance_officer'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('finance' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
end $$;

-- شاشة الدخول: احتساب الوزارة ضمن الجهات الحكومية
do $$
declare d text;
begin
  d := pg_get_functiondef('public.public_brand(text)'::regprocedure);
  if position('''finance''' in d) = 0 then
    if position('''vetdept'',''planning'')' in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في public_brand'; end if;
    execute replace(d, '''vetdept'',''planning'')', '''vetdept'',''planning'',''finance'')');
  end if;
end $$;

-- ───────── 3) تعاميم وزارة المالية ─────────
create table if not exists public.finance_circulars (
  id uuid primary key default gen_random_uuid(),
  ref_no text unique,                              -- يُعطى عند الإصدار: MOF-2026-001
  kind text not null default 'general' check (kind in ('customs', 'interest', 'salary', 'tax', 'general')),
  title text not null,
  body text not null,
  targets text[] not null default array['bank'],   -- bank | cbi | supplier | audit | planning
  effective_date date,
  status text not null default 'draft' check (status in ('draft', 'issued', 'withdrawn')),
  created_at timestamptz default now(), created_by uuid, created_by_name text,
  issued_at timestamptz, issued_by_name text, issued_by_code text,
  withdrawn_at timestamptz, withdrawn_by_name text, withdraw_reason text
);
create table if not exists public.finance_log (
  id bigserial primary key, at timestamptz default now(),
  by_id uuid, by_name text, by_code text, action text not null, target text, reason text
);
create table if not exists public.finance_settings (
  id int primary key default 1 check (id = 1),
  customs_date date not null default date '2026-10-20',   -- تاريخ قرار تصفير الرسوم الكمركية على الألواح الشمسية
  updated_at timestamptz default now()
);
insert into public.finance_settings(id) values (1) on conflict do nothing;

alter table public.finance_circulars enable row level security;
alter table public.finance_log enable row level security;
alter table public.finance_settings enable row level security;
revoke all on public.finance_circulars, public.finance_log, public.finance_settings from anon, authenticated;

-- ───────── 4) الصلاحيات ─────────
create or replace function public._fin_reader() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal not in ('finance', 'admin') then raise exception 'غير مخوّل'; end if;
  return me;
end $f$;

create or replace function public._fin_writer() returns profiles language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal <> 'finance' then raise exception 'التعاميم تصدرها وزارة المالية فقط'; end if;
  return me;
end $f$;

create or replace function public._fin_log(me profiles, p_action text, p_target text, p_reason text) returns void
language sql security definer set search_path to 'public' as $f$
  insert into finance_log(by_id, by_name, by_code, action, target, reason)
  values (me.id, me.full_name, me.staff_code, p_action, p_target, nullif(trim(coalesce(p_reason, '')), '')) $f$;

-- ───────── 5) لوحة الوزارة ─────────
-- القرض «ممول» = اكتمل أو تجاوز مرحلة إطلاق السيولة (المرحلة 35). الأرقام مجمّعة — لا أسماء ولا أرقام هويات.
create or replace function public.finance_overview() returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; s finance_settings; budget numeric;
begin
  me := _fin_reader();
  select * into s from finance_settings where id = 1;
  budget := coalesce((select p.budget from plan_settings p where p.id = 1), 1000000000000);

  return (
  with a as (
    select x.*, (x.status = 'completed' or x.stage > 35) funded,
      greatest(coalesce(x.monthly_installment, 0) * coalesce(x.term_months, 0) - coalesce(x.amount, 0), 0) profit,
      case when x.program = 'vet' then 'vet_program' when x.purpose is null or x.purpose = 'household' then 'residential' else x.purpose end sector
    from applications x where x.bank_id is not null and x.stage >= 6 and x.status not in ('rejected', 'cancelled')
  ),
  g as (   -- كفلاء الرواتب: جهة العمل من بيانات الضمان
    select a.id app, a.funded, a.monthly_installment inst, coalesce(nullif(trim(e->>'employer'), ''), 'غير مذكورة') employer,
      coalesce(e->>'employer', '') ~ '(وزارة|هيئة|دائرة|مديرية|جامعة|محافظة|مجلس|ديوان|أمانة|شركة عامة|الشركة العامة|مستشفى|الحشد|الشرطة|الجيش)' gov
    from a cross join lateral jsonb_array_elements(case when jsonb_typeof(a.guarantee->'guarantors') = 'array' then a.guarantee->'guarantors' else '[]'::jsonb end) e
    where a.guarantee_type in ('single_salary', 'multi_salary')
  ),
  ppk as (   -- سعر الكيلوواط للمنظومات الشمسية
    select a.created_at, a.price / nullif(a.kw, 0) v from a where a.program is distinct from 'vet' and coalesce(a.kw, 0) > 0 and coalesce(a.price, 0) > 0
  )
  select jsonb_build_object(
    'can_edit', me.portal = 'finance',
    'customs_date', s.customs_date,
    'totals', jsonb_build_object(
      'budget', budget,
      'apps', (select count(*) from a),
      'pipeline_n', (select count(*) from a where not funded), 'pipeline_amt', (select coalesce(sum(amount), 0) from a where not funded),
      'funded_n', (select count(*) from a where funded), 'funded_amt', (select coalesce(sum(amount), 0) from a where funded),
      'monthly_inst', (select coalesce(sum(monthly_installment), 0) from a where funded),
      'profit_funded', (select coalesce(sum(profit), 0) from a where funded),
      'profit_pipeline', (select coalesce(sum(profit), 0) from a where not funded),
      'profit_household', (select coalesce(sum(profit), 0) from a where sector = 'residential'),
      'monthly_household', (select coalesce(sum(monthly_installment), 0) from a where sector = 'residential'),
      'n_household', (select count(*) from a where sector = 'residential'),
      'avg_term', (select round(avg(term_months), 1) from a), 'avg_margin', (select round(avg(margin), 2) from a),
      'kw', (select coalesce(sum(kw), 0) from a where funded),
      'disbursed', (select coalesce(sum(d.gross), 0) from disbursements d),
      'commission', (select coalesce(sum(d.commission), 0) from disbursements d)),
    'salary', jsonb_build_object(
      'loans', (select count(*) from a where guarantee_type in ('single_salary', 'multi_salary')),
      'amount', (select coalesce(sum(amount), 0) from a where guarantee_type in ('single_salary', 'multi_salary')),
      'monthly', (select coalesce(sum(monthly_installment), 0) from a where guarantee_type in ('single_salary', 'multi_salary')),
      'mortgage_loans', (select count(*) from a where guarantee_type = 'mortgage'),
      'mortgage_amount', (select coalesce(sum(amount), 0) from a where guarantee_type = 'mortgage'),
      'guarantors', (select count(*) from g), 'gov_guarantors', (select count(*) from g where gov),
      'gov_loans', (select count(distinct app) from g where gov),
      'gov_monthly', (select coalesce(sum(inst), 0) from (select distinct on (app) app, inst from g where gov) q),
      'employers', (select coalesce(jsonb_agg(q order by q.n desc, q.employer), '[]') from (
          select employer, bool_or(gov) gov, count(*) n, count(distinct app) loans from g group by employer order by count(*) desc limit 25) q)),
    'customs', jsonb_build_object(
      'before', (select jsonb_build_object('avg', round(avg(v)), 'n', count(*)) from ppk where created_at < s.customs_date),
      'after', (select jsonb_build_object('avg', round(avg(v)), 'n', count(*)) from ppk where created_at >= s.customs_date),
      'monthly', (select coalesce(jsonb_agg(q order by q.m), '[]') from (
          select to_char(date_trunc('month', created_at), 'YYYY-MM') m, round(avg(v)) avg, count(*) n from ppk group by 1) q)),
    'by_bank', (select coalesce(jsonb_agg(q order by q.amount desc nulls last), '[]') from (
        select o.id, o.name, o.is_islamic islamic, count(a.id) apps, count(a.id) filter (where a.funded) funded,
          coalesce(sum(a.amount) filter (where a.funded), 0) amount, coalesce(sum(a.amount) filter (where not a.funded), 0) pipeline,
          coalesce(sum(a.profit) filter (where a.funded), 0) profit, round(avg(a.margin), 2) margin
        from orgs o left join a on a.bank_id = o.id where o.type = 'bank' group by o.id, o.name, o.is_islamic) q),
    'by_gov', (select coalesce(jsonb_agg(q order by q.amount desc), '[]') from (
        select governorate gov, count(*) apps, coalesce(sum(amount), 0) amount, coalesce(sum(amount) filter (where funded), 0) funded
        from a where governorate is not null group by 1) q),
    'by_sector', (select coalesce(jsonb_agg(q order by q.amount desc), '[]') from (
        select sector key, count(*) apps, coalesce(sum(amount), 0) amount, coalesce(sum(profit), 0) profit from a group by 1) q),
    'tax', jsonb_build_object(
      'suppliers', (select coalesce(jsonb_agg(q order by q.sales desc), '[]') from (
          select o.name, count(a.id) n, coalesce(sum(a.price), 0) sales from orgs o join a on a.supplier_id = o.id and a.funded
          where o.type = 'supplier' group by o.name) q),
      'bank_profit', (select coalesce(sum(profit), 0) from a where funded),
      'platform_commission', (select coalesce(sum(d.commission), 0) from disbursements d)),
    'circulars', (select coalesce(jsonb_agg(to_jsonb(c) - 'created_by' order by c.status = 'draft' desc, coalesce(c.issued_at, c.created_at) desc), '[]') from finance_circulars c),
    'log', (select coalesce(jsonb_agg(q order by q.at desc), '[]') from (select at, by_name, by_code, action, target, reason from finance_log order by at desc limit 40) q))
  );
end $f$;

-- ───────── 6) التعاميم: مسودة ← إصدار ← سحب ─────────
create or replace function public.finance_save_circular(p jsonb) returns uuid
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; v_id uuid := nullif(p->>'id', '')::uuid; c finance_circulars; t text[];
begin
  me := _fin_writer();
  t := array(select x from jsonb_array_elements_text(coalesce(p->'targets', '["bank"]')) x where x in ('bank', 'cbi', 'supplier', 'audit', 'planning'));
  if coalesce(array_length(t, 1), 0) = 0 then raise exception 'اختر جهة واحدة على الأقل يصلها التعميم'; end if;
  if length(trim(coalesce(p->>'title', ''))) < 5 then raise exception 'اكتب عنوان التعميم'; end if;
  if length(trim(coalesce(p->>'body', ''))) < 20 then raise exception 'اكتب نص التعميم (20 حرفاً على الأقل)'; end if;
  if v_id is null then
    insert into finance_circulars(kind, title, body, targets, effective_date, created_by, created_by_name)
    values (coalesce(nullif(p->>'kind', ''), 'general'), trim(p->>'title'), trim(p->>'body'), t, nullif(p->>'effective_date', '')::date, me.id, me.full_name)
    returning id into v_id;
    perform _fin_log(me, 'إنشاء مسودة تعميم', trim(p->>'title'), null);
  else
    select * into c from finance_circulars where id = v_id for update;
    if c.id is null then raise exception 'التعميم غير موجود'; end if;
    if c.status <> 'draft' then raise exception 'التعميم الصادر لا يُعدَّل — اسحبه وأصدر تعميماً جديداً'; end if;
    update finance_circulars set kind = coalesce(nullif(p->>'kind', ''), kind), title = trim(p->>'title'), body = trim(p->>'body'), targets = t,
      effective_date = nullif(p->>'effective_date', '')::date where id = v_id;
    perform _fin_log(me, 'تعديل مسودة تعميم', trim(p->>'title'), null);
  end if;
  return v_id;
end $f$;

create or replace function public.finance_issue_circular(p_id uuid) returns text
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; c finance_circulars; v_ref text; o record;
begin
  me := _fin_writer();
  select * into c from finance_circulars where id = p_id for update;
  if c.id is null then raise exception 'التعميم غير موجود'; end if;
  if c.status <> 'draft' then raise exception 'هذا التعميم صدر سابقاً'; end if;
  perform pg_advisory_xact_lock(hashtext('finance_circular_ref'));
  v_ref := 'MOF-' || to_char(now(), 'YYYY') || '-' || lpad((coalesce((select max(split_part(ref_no, '-', 3)::int) from finance_circulars
             where ref_no like 'MOF-' || to_char(now(), 'YYYY') || '-%'), 0) + 1)::text, 3, '0');
  update finance_circulars set status = 'issued', ref_no = v_ref, issued_at = now(), issued_by_name = me.full_name, issued_by_code = me.staff_code where id = p_id;
  for o in select id, type from orgs where type = any (c.targets) loop
    perform _notify(o.id, null, 'finance_circular', 'تعميم وزارة المالية ' || v_ref || ': ' || c.title, left(c.body, 400), c.id);
  end loop;
  perform _fin_log(me, 'إصدار تعميم', v_ref || ' — ' || c.title, null);
  return v_ref;
end $f$;

create or replace function public.finance_withdraw_circular(p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; c finance_circulars; o record;
begin
  me := _fin_writer();
  if length(trim(coalesce(p_reason, ''))) < 5 then raise exception 'اكتب سبب السحب'; end if;
  select * into c from finance_circulars where id = p_id for update;
  if c.id is null or c.status <> 'issued' then raise exception 'يُسحب التعميم الصادر فقط'; end if;
  update finance_circulars set status = 'withdrawn', withdrawn_at = now(), withdrawn_by_name = me.full_name, withdraw_reason = trim(p_reason) where id = p_id;
  for o in select id from orgs where type = any (c.targets) loop
    perform _notify(o.id, null, 'finance_circular', 'سحب تعميم وزارة المالية ' || c.ref_no, 'السبب: ' || trim(p_reason), c.id);
  end loop;
  perform _fin_log(me, 'سحب تعميم', c.ref_no || ' — ' || c.title, p_reason);
end $f$;

create or replace function public.finance_delete_draft(p_id uuid) returns void
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; c finance_circulars;
begin
  me := _fin_writer();
  select * into c from finance_circulars where id = p_id;
  if c.id is null or c.status <> 'draft' then raise exception 'تُحذف المسودة فقط — التعميم الصادر يُسحب بسبب'; end if;
  delete from finance_circulars where id = p_id;
  perform _fin_log(me, 'حذف مسودة تعميم', c.title, null);
end $f$;

revoke all on function public._fin_reader(), public._fin_writer(), public._fin_log(profiles, text, text, text) from public, anon, authenticated;
revoke all on function public.finance_overview(), public.finance_save_circular(jsonb), public.finance_issue_circular(uuid),
  public.finance_withdraw_circular(uuid, text), public.finance_delete_draft(uuid) from public, anon;
grant execute on function public.finance_overview(), public.finance_save_circular(jsonb), public.finance_issue_circular(uuid),
  public.finance_withdraw_circular(uuid, text), public.finance_delete_draft(uuid) to authenticated;

-- ───────── 7) الحساب التجريبي وتعميم تجريبي ─────────
do $$
begin
  if not exists (select 1 from public.profiles where username = 'finance1') then
    perform public._mk_user('finance1', 'Mof@2026mf', 'أ. سلوى كاظم العبيدي', 'finance_officer', 'finance', 'mof', null, null);
  end if;
  update public.profiles set manage_scope = 'org' where username = 'finance1' and manage_scope is null;
end $$;

insert into public.finance_circulars(kind, title, body, targets, effective_date, created_by_name)
select 'customs', 'تطبيق تصفير الرسوم الكمركية على الألواح الشمسية المستوردة',
  'تعميم تجريبي للعرض: استناداً إلى قرار مجلس الوزراء بتصفير الرسوم الكمركية على الألواح الشمسية، يُطلب من الموردين المعتمدين في المنصة عكس أثر الإعفاء على أسعار الكيلوواط المعروضة للمقترضين، وتتابع الوزارة متوسط السعر شهرياً من لوحة «أثر الإعفاء الكمركي».',
  array['supplier', 'bank', 'cbi'], date '2026-10-20', 'أ. سلوى كاظم العبيدي'
where not exists (select 1 from public.finance_circulars);
