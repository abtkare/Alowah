-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 19 (3 تشرين الثاني 2026)
-- (1) الطلبات القديمة التي وصلت المصرف بلا عنوان GPS: يثبّت المقترض عنوان المنظومة من صفحة طلبه
--     مرة واحدة وحتى المرحلة 30 (قبل أمر الشراء)، دون تغيير نوع الموقع أو غرض التمويل،
--     ويصل إشعار للمصرف ليتابع المعاملة المُرجعة
-- الملف قابل لإعادة التشغيل بأمان (idempotent)
-- ═══════════════════════════════════════════════════════════════════════════

create or replace function public.set_app_site(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; late boolean := false; v_type text := p->>'site_type'; v_purpose text; v_other text;
  v_lat float8 := nullif(p->>'lat', '')::float8; v_lng float8 := nullif(p->>'lng', '')::float8; v_acc float8 := nullif(p->>'acc', '')::float8; lim numeric := _setting('site_gps_accuracy_m');
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'عنوان المنظومة لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  -- الجلسة 19: طلب قديم بلا عنوان GPS لدى المصرف — يثبّت المقترض الموقع مرة واحدة قبل أمر الشراء، ونوع الموقع يبقى كما في الطلب
  late := a.stage > 5;
  if late then
    if a.site_geo is not null then raise exception 'الطلب لدى المصرف الآن — عنوان المنظومة مثبّت ولا يُعدَّل'; end if;
    if a.stage > 30 then raise exception 'صدر أمر الشراء — يثبّت فني المورد موقع التركيب في الموقع نفسه'; end if;
    v_purpose := coalesce(a.purpose, 'household');
    v_type := case when v_purpose = 'household' then 'residential' else 'project' end;
    v_other := a.purpose_other;
  end if;
  if not late and v_type not in ('residential', 'project') then raise exception 'اختر نوع الموقع: سكن أو مشروع'; end if;
  if late then null;
  elsif v_type = 'residential' then v_purpose := 'household';
  else
    v_purpose := p->>'purpose';
    if v_purpose not in ('industrial', 'project', 'agricultural', 'vet', 'other') then raise exception 'اختر نوع المشروع: صناعي، تجاري، زراعي، بيطري، أو أخرى'; end if;
    if v_purpose = 'other' then
      v_other := regexp_replace(trim(coalesce(p->>'purpose_other', '')), '\s+', ' ', 'g');
      if length(v_other) < 3 or length(v_other) > 60 then raise exception 'اكتب نوع المشروع (3 إلى 60 حرفاً)'; end if;
    end if;
  end if;
  if v_lat is null or v_lng is null then raise exception 'حدّد موقع المنظومة بالـGPS من الهاتف وأنت في الموقع'; end if;
  if not _geo_in_iraq(v_lat, v_lng) then raise exception 'الموقع المحدد خارج العراق — أعد تحديد الموقع'; end if;
  if v_acc is null or v_acc > lim then raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م) — انتقل إلى مكان مكشوف وأعد المحاولة', round(coalesce(v_acc, 0)), lim; end if;
  if v_purpose is distinct from coalesce(a.purpose, 'household') and exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  update applications set site_type = v_type, purpose = v_purpose, purpose_other = v_other, lat = round(v_lat::numeric, 6), lng = round(v_lng::numeric, 6),
    site_geo = jsonb_build_object('lat', round(v_lat::numeric, 6), 'lng', round(v_lng::numeric, 6), 'acc', round(v_acc::numeric, 1), 'at', now(), 'source', 'gps',
      'address', nullif(left(trim(coalesce(p->>'address', '')), 160), '')), updated_at = now()
  where id = a.id returning * into a;
  if late then
    perform _notify(a.bank_id, 'bank', 'site_gps', 'ثبّت المقترض عنوان المنظومة — ' || a.code,
      'أُضيف عنوان GPS للطلب في المرحلة ' || a.stage || ' — يمكن متابعة المعاملة', a.id);
  end if;
  perform _ev(a.id, a.stage, case when late then 'تثبيت عنوان المنظومة بالـGPS (استكمال لطلب قديم)' else 'تثبيت عنوان المنظومة بالـGPS' end,
    case when v_type = 'residential' then 'سكن' else 'مشروع — ' || coalesce(v_other, _purpose_label(v_purpose)) end || ' · دقة ±' || round(v_acc) || ' م'
    || coalesce(' · ' || nullif(left(trim(coalesce(p->>'address', '')), 160), ''), ''));
  return a;
end $function$;

