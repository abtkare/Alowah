-- ═══════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 33: حساب تجريبي لعرض نافذة «رهن الذهب»
-- citizen4: مقترضة طلبها متوقف عند الخطوة 4 «الضمان» ونوع الضمان «رهن ذهب»،
-- فتظهر لها نافذة رهن الذهب فور فتح الطلب.
-- يُبنى الطلب بدوال المنصة نفسها (بدء الطلب ← الهوية ← «أور» ← التأكيد) لا بإدخال مباشر.
-- آمن للتكرار: لا يفعل شيئاً إن كان لـ citizen4 طلب.
-- ═══════════════════════════════════════════════════════════════
do $$
declare
  uid uuid; ref applications; a applications;
begin
  -- 1) الحساب
  select id into uid from public.profiles where username = 'citizen4';
  if uid is null then
    uid := public._mk_user('citizen4', 'Alwah@1004', 'مريم حسن عبد الله', 'citizen', 'citizen', null, '07701234504', null);
  end if;
  update public.profiles set governorate = coalesce(governorate, 'بغداد'), city = coalesce(city, 'الكرادة'),
    employer = coalesce(employer, 'القطاع الخاص'), monthly_salary = coalesce(monthly_salary, 900000),
    birth_date = coalesce(birth_date, date '1995-06-21')
  where id = uid;

  if exists (select 1 from public.applications where citizen_id = uid) then return; end if;

  -- 2) نفس المنظومة والمصرف في طلب citizen1 (عرض منشور ومصرف يتعامل مع مورده)
  select a1.* into ref from public.applications a1 join public.profiles p on p.id = a1.citizen_id
  where p.username = 'citizen1' order by a1.created_at limit 1;
  if ref.id is null or ref.offer_id is null or ref.bank_id is null then
    raise notice 'citizen4: لا يوجد طلب مرجعي لـ citizen1 — أُنشئ الحساب دون طلب';
    return;
  end if;

  -- 3) تنفيذ الخطوات باسم citizen4 (داخل هذه المعاملة فقط)
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', uid::text, true);

  a := public.start_application_bank(ref.offer_id, ref.bank_id, 60, 'بغداد', 'الكرادة', 33.3045, 44.4206);
  perform public.citizen_step(a.id, 1, jsonb_build_object('national_id', '199506210004', 'liveness', true, 'match_score', 96, 'card_side', 'front+back', 'id_source', 'manual'));
  perform public.citizen_step(a.id, 2, jsonb_build_object('ur_number', '2026100004', 'otp', '1234'));
  perform public.citizen_step(a.id, 3, '{}'::jsonb);
  perform public.set_guarantee_kind(a.id, 'gold');

  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
end $$;
