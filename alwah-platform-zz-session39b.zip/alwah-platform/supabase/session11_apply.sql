-- ألواح — الجلسة 11: إدارة الموظفين اللامركزية داخل كل جهة
-- مدير الجهة ← مدير الفرع/القسم ← الموظف · توزيع المهام والبديل · «حسابي» · إجبار تغيير كلمة المرور · سجل إداري حسب النطاق
-- معاملة واحدة، يُعاد تشغيلها بأمان. لا تمسّ أي طلب أو دفعة قائمة.
begin;

-- ═══ 1) أعمدة جديدة ═══
alter table public.profiles add column if not exists manage_scope text;
alter table public.profiles drop constraint if exists profiles_manage_scope_check;
alter table public.profiles add constraint profiles_manage_scope_check check (manage_scope is null or manage_scope in ('org', 'branch', 'dept'));
alter table public.profiles add column if not exists must_change_password boolean not null default false;
alter table public.profiles add column if not exists away_until timestamptz;
alter table public.profiles add column if not exists away_note text;
alter table public.profiles add column if not exists managed_by uuid;
alter table public.admin_audit add column if not exists org_id uuid;
alter table public.admin_audit add column if not exists branch_id uuid;
alter table public.admin_audit add column if not exists actor_scope text;

-- ═══ 2) توزيع المهام: مستلم كل مرحلة وبديله، على مستوى الفرع أو الجهة ═══
create table if not exists public.stage_assignments (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id),
  branch_id uuid references public.branches(id),
  stage int not null references public.stages(n),
  user_id uuid not null references public.profiles(id),
  backup_id uuid references public.profiles(id),
  updated_by uuid, updated_at timestamptz not null default now()
);
create unique index if not exists stage_assignments_scope_uq on public.stage_assignments (org_id, coalesce(branch_id, '00000000-0000-0000-0000-000000000000'::uuid), stage);
alter table public.stage_assignments enable row level security;
drop policy if exists read_assignments on public.stage_assignments;
create policy read_assignments on public.stage_assignments for select to authenticated using (org_id = my_org() or my_portal() in ('admin', 'cbi', 'integrity'));
drop policy if exists admin_read_all on public.stage_assignments;
create policy admin_read_all on public.stage_assignments for select using (my_portal() = 'admin');

-- ═══ 3) الأدوار ونطاقات الإدارة ═══
-- الهاتف اختياري: الفارغ يبقى فارغاً، وغيره يُوحَّد بصيغة 07XXXXXXXXX
create or replace function public._opt_phone(p text) returns text language sql immutable set search_path = public as $$
  select case when nullif(trim(coalesce(p, '')), '') is null then null else _norm_phone(p) end $$;
create or replace function public._org_roles(p_type text) returns text[] language sql immutable as $$
  select case p_type
    when 'bank' then array['bank_cs','bank_compliance','bank_branch_mgr','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection',
                           'bank_legal','bank_md','bank_admin','bank_ops','bank_teller','bank_collection','bank_risk','bank_committee']
    when 'cbi' then array['cbi_admin'] when 'supplier' then array['supplier_admin'] when 'syndicate' then array['syndicate_officer']
    when 'vetdept' then array['vetdept_officer'] when 'registry' then array['registry_officer'] when 'integrity' then array['integrity_viewer']
    else array[]::text[] end $$;
-- أدوار الفرع: ما يضيفه مدير الفرع في فرعه فقط
create or replace function public._branch_roles() returns text[] language sql immutable as $$
  select array['bank_cs','bank_compliance','bank_teller','bank_collection'] $$;
-- أدوار القسم في الإدارة العامة حسب دور مدير القسم
create or replace function public._dept_roles(p_mgr_role text) returns text[] language sql immutable as $$
  select case p_mgr_role when 'bank_initiatives_mgr' then array['bank_initiatives','bank_credit','bank_inspection'] else array[]::text[] end $$;
create or replace function public._scope_title(s text) returns text language sql immutable as $$
  select case s when 'org' then 'مدير الجهة' when 'branch' then 'مدير الفرع' when 'dept' then 'مدير القسم' else null end $$;

-- المدير الحالي (أو خطأ)
create or replace function public._mgr() returns public.profiles language plpgsql stable security definer set search_path = public as $$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  if me.manage_scope is null or coalesce(me.disabled, false) or me.portal in ('citizen', 'admin') then raise exception 'إدارة الموظفين لمدير الجهة أو الفرع أو القسم فقط'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if me.manage_scope = 'branch' and me.branch_id is null then raise exception 'مدير الفرع غير مربوط بفرع — راجع مدير الجهة'; end if;
  return me;
end $$;

create or replace function public._mgr_roles(m public.profiles) returns text[] language sql stable security definer set search_path = public as $$
  select case m.manage_scope
    when 'org' then _org_roles((select type from orgs where id = m.org_id))
    when 'branch' then case when (select type from orgs where id = m.org_id) = 'bank' then _branch_roles() else array[]::text[] end
    when 'dept' then _dept_roles(m.role)
    else array[]::text[] end $$;

-- هل يستطيع هذا المدير إدارة هذا الموظف؟
create or replace function public._can_manage(m public.profiles, t public.profiles) returns boolean language sql stable security definer set search_path = public as $$
  select t.id is not null and t.id <> m.id and t.portal not in ('citizen', 'admin') and t.org_id = m.org_id
    and t.role = any(_mgr_roles(m))
    and (t.manage_scope is null or (m.manage_scope = 'org' and t.manage_scope in ('branch', 'dept')))
    and (m.manage_scope <> 'branch' or t.branch_id is not distinct from m.branch_id)
    and (m.manage_scope <> 'dept' or t.branch_id is null) $$;

-- سجل إداري بجهة الهدف وفرعه
create or replace function public._taudit(p_action text, p_target text, p_details jsonb, p_org uuid, p_branch uuid) returns void
language sql security definer set search_path = public as $$
  insert into admin_audit(actor_id, actor_name, action, target, details, org_id, branch_id, actor_scope)
  values (auth.uid(), (select full_name from profiles where id = auth.uid()), p_action, p_target, p_details, p_org, p_branch,
          coalesce((select case when portal = 'admin' then 'platform' else manage_scope end from profiles where id = auth.uid()), 'self'))
$$;

-- ═══ 4) دوال مدير الجهة / الفرع / القسم ═══
create or replace function public.team_meta() returns jsonb language plpgsql stable security definer set search_path = public as $$
declare m profiles := _mgr(); o orgs;
begin
  select * into o from orgs where id = m.org_id;
  return jsonb_build_object(
    'scope', m.manage_scope, 'scope_title', _scope_title(m.manage_scope), 'org_id', o.id, 'org_name', o.name, 'org_type', o.type, 'branch_id', m.branch_id,
    'roles', (select coalesce(jsonb_agg(jsonb_build_object('role', r, 'title', _role_title(r)) order by ord), '[]') from unnest(_mgr_roles(m)) with ordinality x(r, ord)),
    'branches', case when m.manage_scope = 'branch' then (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name)), '[]') from branches where id = m.branch_id)
                     when m.manage_scope = 'org' then (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name) order by is_main desc, code), '[]') from branches where bank_id = m.org_id)
                     else '[]'::jsonb end,
    'can_grant', case when m.manage_scope = 'org' and o.type = 'bank' then '["branch","dept"]'::jsonb else '[]'::jsonb end,
    'stages', (select coalesce(jsonb_agg(jsonb_build_object('n', n, 'name', name, 'owner_role', owner_role, 'owner_label', owner_label, 'branch_level', branch_level) order by n), '[]')
               from stages where owner_role = any(_mgr_roles(m)) and not batch_only
                 and (m.manage_scope <> 'branch' or branch_level or owner_role = any(_branch_roles()))));
end $$;

create or replace function public.team_users() returns table (id uuid, username text, full_name text, role text, role_title text, branch_id uuid, branch_name text,
  phone text, staff_code text, manage_scope text, disabled boolean, must_change_password boolean, away_until timestamptz, away_note text,
  created_at timestamptz, last_sign_in_at timestamptz, can_manage boolean, is_me boolean)
language plpgsql stable security definer set search_path = public, auth as $$
declare m profiles := _mgr();
begin
  return query select p.id, p.username, p.full_name, p.role, _role_title(p.role), p.branch_id, b.name, p.phone, p.staff_code, p.manage_scope,
    coalesce(p.disabled, false), p.must_change_password, case when p.away_until > now() then p.away_until end, case when p.away_until > now() then p.away_note end,
    p.created_at, u.last_sign_in_at, _can_manage(m, p), p.id = m.id
  from profiles p left join branches b on b.id = p.branch_id left join auth.users u on u.id = p.id
  where p.org_id = m.org_id and p.portal not in ('citizen', 'admin')
    and (p.id = m.id or _can_manage(m, p)
         or (m.manage_scope = 'branch' and p.branch_id = m.branch_id)
         or (m.manage_scope = 'dept' and p.branch_id is null and p.role = any(_mgr_roles(m))))
  order by (p.id = m.id) desc, p.manage_scope nulls last, p.role, p.username;
end $$;

create or replace function public.team_create_user(p jsonb) returns public.profiles
language plpgsql security definer set search_path = public, auth, extensions as $$
declare m profiles := _mgr(); v_user text := lower(trim(coalesce(p->>'username', ''))); v_role text := p->>'role'; v_br uuid; v_scope text := nullif(p->>'manage_scope', '');
  uid uuid; pr profiles; o orgs;
begin
  select * into o from orgs where id = m.org_id;
  if not (v_role = any(_mgr_roles(m))) then raise exception 'هذا الدور خارج صلاحيتك — الأدوار المسموحة لك تظهر في القائمة'; end if;
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم مستخدم مسبقاً'; end if;
  if length(coalesce(p->>'password', '')) < 8 or (p->>'password') !~ '[0-9]' or (p->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if length(trim(coalesce(p->>'full_name', ''))) < 3 then raise exception 'اكتب الاسم الكامل'; end if;
  -- الفرع حسب النطاق: مدير الفرع ← فرعه حتماً، مدير القسم ← الإدارة العامة، مدير الجهة ← أي فرع من جهته
  v_br := case m.manage_scope when 'branch' then m.branch_id when 'dept' then null else nullif(p->>'branch_id', '')::uuid end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = m.org_id) then raise exception 'الفرع لا يتبع جهتك'; end if;
  if o.type = 'bank' and v_role in ('bank_cs', 'bank_teller', 'bank_branch_mgr') and v_br is null then raise exception 'هذا الدور في الفرع — اختر الفرع'; end if;
  if v_scope is not null then
    if m.manage_scope <> 'org' then raise exception 'نطاق الإدارة يمنحه مدير الجهة فقط'; end if;
    if v_scope = 'org' then raise exception 'مدير الجهة يعيّنه مشغّل النظام فقط'; end if;
    if v_scope = 'branch' and (v_role <> 'bank_branch_mgr' or v_br is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
    if v_scope = 'dept' and (cardinality(_dept_roles(v_role)) = 0 or v_br is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  end if;
  uid := _mk_user(v_user, p->>'password', trim(p->>'full_name'), v_role, _portal_of_role(v_role), o.code, _opt_phone(p->>'phone'), null);
  update profiles set branch_id = v_br, manage_scope = v_scope, must_change_password = true, managed_by = m.id where id = uid returning * into pr;
  perform _taudit('إنشاء موظف', v_user, jsonb_build_object('role', _role_title(v_role), 'branch', (select name from branches where id = v_br), 'manage', _scope_title(v_scope)), m.org_id, v_br);
  return pr;
end $$;

create or replace function public.team_update_user(p_user uuid, p jsonb) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare m profiles := _mgr(); t profiles; v_role text; v_br uuid; v_scope text; ch jsonb := '{}';
begin
  select * into t from profiles where id = p_user;
  if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if;
  v_role := coalesce(nullif(p->>'role', ''), t.role);
  if not (v_role = any(_mgr_roles(m))) then raise exception 'هذا الدور خارج صلاحيتك'; end if;
  v_br := case m.manage_scope when 'branch' then m.branch_id when 'dept' then null
               else case when p ? 'branch_id' then nullif(p->>'branch_id', '')::uuid else t.branch_id end end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = m.org_id) then raise exception 'الفرع لا يتبع جهتك'; end if;
  v_scope := case when p ? 'manage_scope' then nullif(p->>'manage_scope', '') else t.manage_scope end;
  if v_scope is distinct from t.manage_scope or (v_scope is not null and (v_role <> t.role or v_br is distinct from t.branch_id)) then
    if m.manage_scope <> 'org' then raise exception 'نطاق الإدارة يغيّره مدير الجهة فقط'; end if;
    if v_scope = 'org' then raise exception 'مدير الجهة يعيّنه مشغّل النظام فقط'; end if;
    if v_scope = 'branch' and (v_role <> 'bank_branch_mgr' or v_br is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
    if v_scope = 'dept' and (cardinality(_dept_roles(v_role)) = 0 or v_br is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  end if;
  if v_role <> t.role then ch := ch || jsonb_build_object('role', _role_title(t.role) || ' ← ' || _role_title(v_role)); end if;
  if v_br is distinct from t.branch_id then ch := ch || jsonb_build_object('branch', coalesce((select name from branches where id = t.branch_id), 'الإدارة العامة') || ' ← ' || coalesce((select name from branches where id = v_br), 'الإدارة العامة')); end if;
  if v_scope is distinct from t.manage_scope then ch := ch || jsonb_build_object('manage', coalesce(_scope_title(t.manage_scope), 'بلا') || ' ← ' || coalesce(_scope_title(v_scope), 'بلا')); end if;
  if nullif(trim(p->>'full_name'), '') is distinct from null and trim(p->>'full_name') <> t.full_name then ch := ch || jsonb_build_object('name', trim(p->>'full_name')); end if;
  if p ? 'phone' and _opt_phone(p->>'phone') is distinct from t.phone then ch := ch || jsonb_build_object('phone', 'تحديث'); end if;
  update profiles set full_name = coalesce(nullif(trim(p->>'full_name'), ''), full_name), role = v_role, branch_id = v_br, manage_scope = v_scope,
    phone = case when p ? 'phone' then _opt_phone(p->>'phone') else phone end, updated_at = now()
  where id = p_user returning * into t;
  -- المسند إليه مرحلة بدور غير دوره بعد التعديل: يُزال الإسناد
  delete from stage_assignments s using stages st where st.n = s.stage and s.user_id = t.id and st.owner_role <> t.role;
  update stage_assignments s set backup_id = null from stages st where st.n = s.stage and s.backup_id = t.id and st.owner_role <> t.role;
  -- نُقل إلى فرع آخر: يُزال من إسنادات فرعه القديم
  delete from stage_assignments s where s.user_id = t.id and s.branch_id is not null and s.branch_id is distinct from t.branch_id;
  update stage_assignments s set backup_id = null where s.backup_id = t.id and s.branch_id is not null and s.branch_id is distinct from t.branch_id;
  perform _taudit('تعديل موظف', t.username, ch, m.org_id, t.branch_id);
  return t;
end $$;

create or replace function public.team_set_password(p_user uuid, p_new text) returns boolean
language plpgsql security definer set search_path = public, auth, extensions as $$
declare m profiles := _mgr(); t profiles;
begin
  select * into t from profiles where id = p_user;
  if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if;
  if length(coalesce(p_new, '')) < 8 or p_new !~ '[0-9]' or p_new !~ '[A-Za-z]' then raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  update auth.users set encrypted_password = crypt(p_new, gen_salt('bf')), updated_at = now() where id = p_user;
  update profiles set must_change_password = true, updated_at = now() where id = p_user;
  perform _taudit('إعادة ضبط كلمة المرور', t.username, null, m.org_id, t.branch_id);
  return true;
end $$;

create or replace function public.team_set_disabled(p_user uuid, p_disabled boolean, p_reason text default null) returns boolean
language plpgsql security definer set search_path = public, auth as $$
declare m profiles := _mgr(); t profiles;
begin
  select * into t from profiles where id = p_user;
  if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if;
  if p_disabled and coalesce(trim(p_reason), '') = '' then raise exception 'اكتب سبب الإيقاف'; end if;
  update profiles set disabled = p_disabled, updated_at = now() where id = p_user;
  update auth.users set banned_until = case when p_disabled then 'infinity'::timestamptz else null end where id = p_user;
  if p_disabled then begin delete from auth.sessions where user_id = p_user; exception when others then null; end; end if;
  perform _taudit(case when p_disabled then 'إيقاف حساب' else 'إعادة تفعيل حساب' end, t.username, case when p_reason is not null then jsonb_build_object('reason', p_reason) end, m.org_id, t.branch_id);
  return true;
end $$;

-- الغياب: إجازة أو مهمة حتى تاريخ — خلاله يستلم البديل
create or replace function public.team_set_away(p_user uuid, p_until date, p_note text default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare m profiles := _mgr(); t profiles;
begin
  select * into t from profiles where id = p_user;
  if not coalesce(_can_manage(m, t), false) then raise exception 'هذا الموظف خارج نطاق إدارتك'; end if;
  if p_until is not null and (p_until < current_date or p_until > current_date + 180) then raise exception 'تاريخ العودة بين اليوم و180 يوماً'; end if;
  update profiles set away_until = case when p_until is null then null else (p_until + 1)::timestamptz end,
    away_note = case when p_until is null then null else nullif(trim(p_note), '') end, updated_at = now() where id = p_user;
  perform _taudit(case when p_until is null then 'إنهاء غياب' else 'تسجيل غياب' end, t.username,
    case when p_until is not null then jsonb_build_object('until', p_until, 'note', p_note) end, m.org_id, t.branch_id);
  return true;
end $$;

-- توزيع المهام
create or replace function public.team_assignments() returns table (id uuid, stage int, stage_name text, owner_role text, branch_id uuid, branch_name text,
  user_id uuid, user_name text, user_away boolean, backup_id uuid, backup_name text, backup_away boolean, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare m profiles := _mgr();
begin
  return query select s.id, s.stage, st.name, st.owner_role, s.branch_id, b.name, s.user_id, u.full_name, coalesce(u.away_until > now() or u.disabled, false),
    s.backup_id, k.full_name, coalesce(k.away_until > now() or k.disabled, false), s.updated_at
  from stage_assignments s join stages st on st.n = s.stage left join branches b on b.id = s.branch_id
    join profiles u on u.id = s.user_id left join profiles k on k.id = s.backup_id
  where s.org_id = m.org_id and st.owner_role = any(_mgr_roles(m))
    and (m.manage_scope <> 'branch' or s.branch_id = m.branch_id) and (m.manage_scope <> 'dept' or s.branch_id is null)
  order by b.name nulls first, s.stage;
end $$;

create or replace function public.team_set_assignment(p_stage int, p_branch uuid, p_user uuid, p_backup uuid default null) returns public.stage_assignments
language plpgsql security definer set search_path = public as $$
declare m profiles := _mgr(); st stages; v_br uuid; u profiles; k profiles; r stage_assignments;
begin
  select * into st from stages where n = p_stage;
  if st is null or st.owner_role = 'citizen' or st.batch_only then raise exception 'هذه المرحلة لا تُسند لموظف'; end if;
  if not (st.owner_role = any(_mgr_roles(m))) then raise exception 'هذه المرحلة خارج صلاحيتك'; end if;
  v_br := case m.manage_scope when 'branch' then m.branch_id when 'dept' then null else p_branch end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = m.org_id) then raise exception 'الفرع لا يتبع جهتك'; end if;
  if m.manage_scope = 'branch' and not st.branch_level and not (st.owner_role = any(_branch_roles())) then raise exception 'هذه المرحلة في الإدارة العامة'; end if;
  select * into u from profiles where id = p_user;
  if u is null or u.org_id <> m.org_id or u.role <> st.owner_role or coalesce(u.disabled, false) then raise exception 'المستلم يجب أن يحمل دور «%» في جهتك وأن يكون فعّالاً', st.owner_label; end if;
  if v_br is not null and u.branch_id is distinct from v_br then raise exception 'المستلم من فرع آخر'; end if;
  if p_backup is not null then
    if p_backup = p_user then raise exception 'البديل غير المستلم'; end if;
    select * into k from profiles where id = p_backup;
    if k is null or k.org_id <> m.org_id or k.role <> st.owner_role or coalesce(k.disabled, false) then raise exception 'البديل يجب أن يحمل دور «%» في جهتك وأن يكون فعّالاً', st.owner_label; end if;
    if v_br is not null and k.branch_id is distinct from v_br then raise exception 'البديل من فرع آخر'; end if;
  end if;
  insert into stage_assignments(org_id, branch_id, stage, user_id, backup_id, updated_by, updated_at)
  values (m.org_id, v_br, p_stage, p_user, p_backup, m.id, now())
  on conflict (org_id, coalesce(branch_id, '00000000-0000-0000-0000-000000000000'::uuid), stage)
  do update set user_id = excluded.user_id, backup_id = excluded.backup_id, updated_by = excluded.updated_by, updated_at = now()
  returning * into r;
  perform _taudit('إسناد مرحلة', p_stage || '. ' || st.name, jsonb_build_object('to', u.full_name, 'backup', k.full_name, 'branch', (select name from branches where id = v_br)), m.org_id, v_br);
  return r;
end $$;

create or replace function public.team_clear_assignment(p_id uuid) returns boolean
language plpgsql security definer set search_path = public as $$
declare m profiles := _mgr(); r stage_assignments; st stages;
begin
  select * into r from stage_assignments where id = p_id;
  select * into st from stages where n = r.stage;
  if r is null or r.org_id <> m.org_id or not (st.owner_role = any(_mgr_roles(m)))
     or (m.manage_scope = 'branch' and r.branch_id is distinct from m.branch_id) or (m.manage_scope = 'dept' and r.branch_id is not null) then
    raise exception 'هذا الإسناد خارج نطاق إدارتك'; end if;
  delete from stage_assignments where id = p_id;
  perform _taudit('إلغاء إسناد مرحلة', r.stage || '. ' || st.name, null, m.org_id, r.branch_id);
  return true;
end $$;

-- السجل الإداري: مدير الجهة يرى كل ما جرى في جهته، وغيره يرى ما فعله هو وما يخص فرعه
create or replace function public.team_audit(p_limit int default 200) returns table (id bigint, actor_name text, actor_scope text, action text, target text,
  details jsonb, branch_name text, created_at timestamptz, mine boolean)
language plpgsql stable security definer set search_path = public as $$
declare m profiles := _mgr();
begin
  return query select a.id, a.actor_name, a.actor_scope, a.action, a.target, a.details, b.name, a.created_at, a.actor_id = m.id
  from admin_audit a left join branches b on b.id = a.branch_id
  where a.org_id = m.org_id and (m.manage_scope = 'org' or a.actor_id = m.id or (m.manage_scope = 'branch' and a.branch_id = m.branch_id))
  order by a.id desc limit least(greatest(coalesce(p_limit, 200), 1), 1000);
end $$;

-- قواعد الإسناد التي تخص الموظف الحالي (لتصفية صندوقه في الواجهة)
create or replace function public.my_assignment_rules() returns table (stage int, branch_id uuid, user_id uuid, backup_id uuid, primary_available boolean, backup_available boolean)
language sql stable security definer set search_path = public as $$
  select s.stage, s.branch_id, s.user_id, s.backup_id, not (coalesce(u.disabled, false) or coalesce(u.away_until > now(), false)),
    s.backup_id is not null and not (coalesce(k.disabled, false) or coalesce(k.away_until > now(), false))
  from stage_assignments s join profiles u on u.id = s.user_id left join profiles k on k.id = s.backup_id
  where s.org_id = my_org() $$;

-- ═══ 5) فحص الإسناد عند إنجاز المرحلة ═══
-- المستلم ينفّذ. البديل ينفّذ فقط إن غاب المستلم أو أُوقف. إن غاب الاثنان (أو لا بديل) تعود المرحلة لكل من يحمل الدور حتى لا تتوقف المعاملة.
create or replace function public._assignment_ok(a public.applications, me public.profiles) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare r stage_assignments; prim_ok boolean; back_ok boolean;
begin
  select * into r from stage_assignments s
  where s.org_id = case when me.portal = 'supplier' then a.supplier_id else a.bank_id end and s.stage = a.stage
    and (s.branch_id = a.branch_id or s.branch_id is null)
  order by (s.branch_id is null) limit 1;
  if r is null or r.user_id = me.id then return true; end if;
  select not (coalesce(disabled, false) or coalesce(away_until > now(), false)) into prim_ok from profiles where id = r.user_id;
  if coalesce(prim_ok, false) then return false; end if;
  select not (coalesce(disabled, false) or coalesce(away_until > now(), false)) into back_ok from profiles where id = r.backup_id;
  if coalesce(back_ok, false) then return r.backup_id = me.id; end if;
  return true;
end $$;

create or replace function public._assignee_name(a public.applications) returns text language sql stable security definer set search_path = public as $$
  select u.full_name from stage_assignments s join profiles u on u.id = s.user_id
  where s.org_id in (a.bank_id, a.supplier_id) and s.stage = a.stage and (s.branch_id = a.branch_id or s.branch_id is null)
  order by (s.branch_id is null) limit 1 $$;

-- يُضاف السطران إلى دالة إنجاز المرحلة القائمة دون إعادة كتابتها (آمن عند إعادة التشغيل)
do $$
declare d text := pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure);
  anchor text := 'raise exception ''الطلب يخص فرعاً آخر''; end if;';
begin
  if position('_assignment_ok' in d) = 0 then
    if position(anchor in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في advance_application'; end if;
    d := replace(d, anchor, anchor || E'\n    if me.must_change_password then raise exception ''غيّر كلمة المرور المؤقتة أولاً من «حسابي»''; end if;'
      || E'\n    if not _assignment_ok(a, me) then raise exception ''هذه المعاملة مسندة إلى % — يستلمها البديل عند غيابه فقط'', _assignee_name(a); end if;');
    execute d;
  end if;
end $$;

-- ═══ 6) «حسابي» لكل الموظفين ═══
create or replace function public.change_my_password(p_old text, p_new text) returns boolean
language plpgsql security definer set search_path = public, auth, extensions as $$
declare u auth.users; pr profiles;
begin
  select * into u from auth.users where id = auth.uid();
  if u is null then raise exception 'غير مسجل الدخول'; end if;
  if u.encrypted_password <> crypt(p_old, u.encrypted_password) then raise exception 'كلمة المرور الحالية غير صحيحة'; end if;
  if length(coalesce(p_new, '')) < 8 or p_new !~ '[0-9]' or p_new !~ '[A-Za-z]' then
    raise exception 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if p_new = p_old then raise exception 'اختر كلمة مرور مختلفة عن الحالية'; end if;
  update auth.users set encrypted_password = crypt(p_new, gen_salt('bf')), updated_at = now() where id = u.id;
  update profiles set must_change_password = false, updated_at = now() where id = u.id returning * into pr;
  if pr.portal <> 'citizen' then perform _taudit('تغيير كلمة المرور الذاتي', pr.username, null, pr.org_id, pr.branch_id); end if;
  return true;
end $$;

create or replace function public.update_my_staff_phone(p_password text, p_phone text) returns public.profiles
language plpgsql security definer set search_path = public, auth, extensions as $$
declare u auth.users; pr profiles; ph text := _opt_phone(p_phone);
begin
  select * into u from auth.users where id = auth.uid();
  select * into pr from profiles where id = auth.uid();
  if u is null or pr is null then raise exception 'غير مسجل الدخول'; end if;
  if pr.portal = 'citizen' then raise exception 'المواطن يغيّر هاتفه من ملفه الشخصي برمز تحقق'; end if;
  if u.encrypted_password <> crypt(coalesce(p_password, ''), u.encrypted_password) then raise exception 'كلمة المرور الحالية غير صحيحة'; end if;
  if ph is not null and ph !~ '^07[3-9][0-9]{8}$' then raise exception 'رقم الهاتف بصيغة 07XXXXXXXXX'; end if;
  update profiles set phone = ph, updated_at = now() where id = pr.id returning * into pr;
  perform _taudit('تحديث الهاتف الذاتي', pr.username, null, pr.org_id, pr.branch_id);
  return pr;
end $$;

create or replace function public.my_account() returns jsonb language sql stable security definer set search_path = public, auth as $$
  select jsonb_build_object('username', p.username, 'full_name', p.full_name, 'role_title', _role_title(p.role), 'position_title', p.position_title,
    'staff_code', p.staff_code, 'org', o.name, 'branch', b.name, 'phone', p.phone, 'manage_scope', p.manage_scope, 'scope_title', _scope_title(p.manage_scope),
    'must_change_password', p.must_change_password, 'away_until', case when p.away_until > now() then p.away_until end, 'away_note', case when p.away_until > now() then p.away_note end,
    'last_sign_in_at', u.last_sign_in_at, 'password_changed_at', u.updated_at,
    'tasks', (select coalesce(jsonb_agg(jsonb_build_object('stage', s.stage, 'name', st.name, 'branch', bb.name, 'as', case when s.user_id = p.id then 'primary' else 'backup' end) order by s.stage), '[]')
              from stage_assignments s join stages st on st.n = s.stage left join branches bb on bb.id = s.branch_id where p.id in (s.user_id, s.backup_id)))
  from profiles p left join orgs o on o.id = p.org_id left join branches b on b.id = p.branch_id left join auth.users u on u.id = p.id
  where p.id = auth.uid() $$;

-- ═══ 7) مشغّل النظام: تعيين مدير الجهة، وإجبار تغيير كلمة المرور عند الإنشاء وإعادة الضبط ═══
create or replace function public.admin_set_manage_scope(p_user uuid, p_scope text) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare t profiles; v text := nullif(p_scope, '');
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into t from profiles where id = p_user;
  if t is null or t.portal in ('citizen', 'admin') then raise exception 'اختر موظفاً في جهة'; end if;
  if v is not null and v not in ('org', 'branch', 'dept') then raise exception 'نطاق غير معروف'; end if;
  if v = 'branch' and (t.role <> 'bank_branch_mgr' or t.branch_id is null) then raise exception 'إدارة الفرع لمدير فرع مربوط بفرع'; end if;
  if v = 'dept' and (cardinality(_dept_roles(t.role)) = 0 or t.branch_id is not null) then raise exception 'إدارة القسم لمدير قسم في الإدارة العامة'; end if;
  update profiles set manage_scope = v, updated_at = now() where id = p_user returning * into t;
  perform _taudit(case when v is null then 'سحب صلاحية الإدارة' else 'تعيين ' || _scope_title(v) end, t.username, null, t.org_id, t.branch_id);
  return t;
end $$;

-- يُضاف إجبار التغيير إلى دالتي الإنشاء وإعادة الضبط القائمتين دون إعادة كتابتهما
do $$
declare d text;
begin
  d := pg_get_functiondef('public.admin_create_user(jsonb)'::regprocedure);
  if position('must_change_password' in d) = 0 then
    d := replace(d, 'update profiles set branch_id = v_br.id where id = uid', 'update profiles set branch_id = v_br.id, must_change_password = true where id = uid');
    d := replace(d, 'nullif(_norm_phone(p->>''phone''), '''')', '_opt_phone(p->>''phone'')');
    if position('must_change_password' in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في admin_create_user'; end if;
    execute d;
  end if;
  -- إصلاح: الهاتف الفارغ كان يُرفض عند تعديل موظف بلا هاتف
  d := pg_get_functiondef('public.admin_update_user(uuid,jsonb)'::regprocedure);
  if position('_opt_phone' in d) = 0 then
    d := replace(d, 'nullif(_norm_phone(p->>''phone''), '''')', '_opt_phone(p->>''phone'')');
    if position('_opt_phone' in d) > 0 then execute d; end if;
  end if;
  d := pg_get_functiondef('public.admin_set_password(uuid,text)'::regprocedure);
  if position('must_change_password' in d) = 0 then
    d := replace(d, 'perform _audit(''إعادة تعيين كلمة المرور'', un, null);', 'update profiles set must_change_password = true where id = p_user;' || E'\n  ' || 'perform _audit(''إعادة تعيين كلمة المرور'', un, null);');
    if position('must_change_password' in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في admin_set_password'; end if;
    execute d;
  end if;
end $$;

-- قائمة المستخدمين للمشغّل: مع نطاق الإدارة وحالة كلمة المرور
drop function if exists public.admin_users();
create function public.admin_users() returns table (id uuid, username text, full_name text, role text, portal text, org_id uuid, branch_id uuid,
  phone text, staff_code text, position_title text, disabled boolean, created_at timestamptz, last_sign_in_at timestamptz, national_id text, kyc_status text,
  manage_scope text, must_change_password boolean, away_until timestamptz)
language plpgsql stable security definer set search_path = public, auth as $$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return query select p.id, p.username, p.full_name, p.role, p.portal, p.org_id, p.branch_id, p.phone, p.staff_code, p.position_title,
    coalesce(p.disabled, false), p.created_at, u.last_sign_in_at, p.national_id, p.kyc_status, p.manage_scope, p.must_change_password,
    case when p.away_until > now() then p.away_until end
  from profiles p left join auth.users u on u.id = p.id order by p.portal, p.username;
end $$;

-- ═══ 8) حسابات الاختبار: مديرو الجهات والفروع والأقسام (حسابات قائمة، كلمات مرورها في دليل الدخول) ═══
update public.profiles set manage_scope = 'org' where manage_scope is null and username in
  ('snb.admin', 'wah.admin', 'djl.admin', 'cbi1', 'supplier1', 'supplier2', 'supplier3', 'supplier4', 'supplier5', 'syndicate1', 'vetdept1', 'registry1', 'integrity1');
update public.profiles set manage_scope = 'branch' where manage_scope is null and role = 'bank_branch_mgr' and branch_id is not null;
update public.profiles set manage_scope = 'dept' where manage_scope is null and role = 'bank_initiatives_mgr' and branch_id is null;

-- ═══ 9) الصلاحيات ═══
revoke all on function public._mgr(), public._mgr_roles(public.profiles), public._can_manage(public.profiles, public.profiles), public._taudit(text, text, jsonb, uuid, uuid),
  public._assignment_ok(public.applications, public.profiles), public._assignee_name(public.applications) from public, anon, authenticated;
revoke all on function public.team_meta(), public.team_users(), public.team_create_user(jsonb), public.team_update_user(uuid, jsonb), public.team_set_password(uuid, text),
  public.team_set_disabled(uuid, boolean, text), public.team_set_away(uuid, date, text), public.team_assignments(), public.team_set_assignment(int, uuid, uuid, uuid),
  public.team_clear_assignment(uuid), public.team_audit(int), public.my_assignment_rules(), public.update_my_staff_phone(text, text), public.my_account(),
  public.admin_set_manage_scope(uuid, text), public.admin_users() from public, anon;
grant execute on function public.team_meta(), public.team_users(), public.team_create_user(jsonb), public.team_update_user(uuid, jsonb), public.team_set_password(uuid, text),
  public.team_set_disabled(uuid, boolean, text), public.team_set_away(uuid, date, text), public.team_assignments(), public.team_set_assignment(int, uuid, uuid, uuid),
  public.team_clear_assignment(uuid), public.team_audit(int), public.my_assignment_rules(), public.update_my_staff_phone(text, text), public.my_account(),
  public.admin_set_manage_scope(uuid, text), public.admin_users(), public.change_my_password(text, text) to authenticated;

commit;
