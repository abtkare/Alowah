-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 25
-- (أ) نوع مشروع جديد: «تصدير» (export) إلى جانب الصناعي والتجاري والزراعي والبيطري
-- (ب) مكاتب ومراكز إعداد دراسات الجدوى المعتمدة من البنك المركزي:
--     في أول مراحل الطلب يختار المقترض (لأي طلب مشروع) الجهة التي أعدّت دراسته من القائمة المعتمدة،
--     أو يكتب اسم مكتب أو مركز غير مدرج. الدراسة من جهة معتمدة = «مسار ميسّر»:
--     مهلة الخبير المعتمد أقصر (الإعداد fz_accredited_sla_days، افتراضياً يومان) وتتقدّم في صندوق الخبير،
--     وتظهر علامة «معدّة من جهة معتمدة» للمصرف والخبير. الخبير يبقى صاحب القرار (مطابق / غير مطابق).
-- (ج) مشغّل النظام يدير القائمة (إضافة، تعديل، إيقاف) ويرى عدد الطلبات ونتائج الخبراء لكل جهة.
-- كل التغييرات إضافية، والملف آمن لإعادة التشغيل. الطلبات القائمة لا يُطلب منها بند «الجهة المُعِدّة».
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── أ) غرض «تصدير» ─────────
alter table public.applications drop constraint if exists applications_purpose_check;
alter table public.applications add constraint applications_purpose_check
  check (purpose = any (array['household','agricultural','industrial','project','vet','export','other']));

create or replace function public._purpose_label(p text) returns text language sql immutable as $f$
  select case p when 'household' then 'سكن (منزلي)' when 'agricultural' then 'زراعي' when 'industrial' then 'صناعي'
    when 'project' then 'تجاري أو خدمي' when 'vet' then 'بيطري' when 'export' then 'تصدير' when 'other' then 'مشروع آخر' else p end $f$;

-- ───────── ب) سجل جهات إعداد دراسات الجدوى المعتمدة ─────────
create table if not exists public.feasibility_offices (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  kind text not null default 'office' check (kind in ('office','center')),   -- مكتب / مركز
  governorate text,
  license_no text,                 -- رقم الإجازة أو التسجيل
  cbi_ref text,                    -- رقم كتاب اعتماد البنك المركزي وتاريخه
  phone text,
  active boolean not null default true,
  demo boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create unique index if not exists feasibility_offices_name on public.feasibility_offices (lower(regexp_replace(trim(name), '\s+', ' ', 'g')));
alter table public.feasibility_offices enable row level security;   -- القراءة والكتابة عبر الدوال فقط

alter table public.applications add column if not exists fz_office_id uuid references public.feasibility_offices(id);
alter table public.applications add column if not exists fz_office_name text;     -- اسم يكتبه المقترض لجهة غير مدرجة
alter table public.applications add column if not exists fz_office_at timestamptz;
-- الطلبات القائمة قبل الجلسة 25 تبقى null (لا يُطلب منها البند)، والجديدة true
alter table public.applications add column if not exists fz_office_req boolean;
alter table public.applications alter column fz_office_req set default true;

insert into public.settings(key, value, label, circular_no)
select 'fz_accredited_sla_days', 2, 'مهلة الخبير المعتمد لدراسة جدوى أعدّتها جهة معتمدة من البنك المركزي (أيام دوام) — المسار الميسّر', 'سياسة التمويل'
where not exists (select 1 from public.settings where key = 'fz_accredited_sla_days');

-- قائمة تجريبية (أسماء افتراضية للعرض فقط — تُستبدل بالقائمة الرسمية للبنك المركزي)
insert into public.feasibility_offices(name, kind, governorate, license_no, cbi_ref, demo)
select v.n, v.k, v.g, v.l, v.r, true from (values
  ('مكتب دجلة للاستشارات ودراسات الجدوى', 'office', 'بغداد', 'FS-BGD-101', 'اعتماد تجريبي 1/2026'),
  ('مركز الرافدين لدراسات الجدوى الاقتصادية', 'center', 'بغداد', 'FS-BGD-117', 'اعتماد تجريبي 2/2026'),
  ('مكتب الفرات للدراسات الاقتصادية والفنية', 'office', 'النجف', 'FS-NJF-205', 'اعتماد تجريبي 3/2026'),
  ('مركز الكوفة للتخطيط ودراسات المشاريع', 'center', 'النجف', 'FS-NJF-219', 'اعتماد تجريبي 4/2026'),
  ('مكتب شط العرب للاستشارات الاقتصادية', 'office', 'البصرة', 'FS-BSR-302', 'اعتماد تجريبي 5/2026'),
  ('مركز بابل لدراسات الجدوى الزراعية والصناعية', 'center', 'بابل', 'FS-BBL-410', 'اعتماد تجريبي 6/2026'),
  ('مكتب الحدباء للدراسات الاقتصادية', 'office', 'نينوى', 'FS-NNW-508', 'اعتماد تجريبي 7/2026'),
  ('مكتب كربلاء للاستشارات ودراسات المشاريع', 'office', 'كربلاء', 'FS-KRB-611', 'اعتماد تجريبي 8/2026')
) v(n, k, g, l, r)
where not exists (select 1 from public.feasibility_offices f where lower(f.name) = lower(v.n));

-- وصف الجهة المُعِدّة لطلب
create or replace function public._fz_office(a public.applications) returns jsonb
language sql stable security definer set search_path = public as $f$
  select case
    when a.fz_office_id is not null then (select jsonb_build_object('set', true, 'accredited', true, 'id', f.id, 'name', f.name,
        'kind', f.kind, 'governorate', f.governorate, 'license_no', f.license_no, 'cbi_ref', f.cbi_ref, 'active', f.active, 'at', a.fz_office_at)
      from feasibility_offices f where f.id = a.fz_office_id)
    when coalesce(trim(a.fz_office_name), '') <> '' then jsonb_build_object('set', true, 'accredited', false, 'name', a.fz_office_name, 'at', a.fz_office_at)
    else jsonb_build_object('set', false, 'accredited', false) end $f$;

-- القائمة المعتمدة للمقترض (نفس محافظة الطلب أولاً)
create or replace function public.fz_offices_list(p_gov text default null) returns jsonb
language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name, 'kind', kind, 'governorate', governorate, 'license_no', license_no,
      'same_gov', governorate = p_gov) order by (governorate = p_gov) desc nulls last, governorate, name), '[]')
  from feasibility_offices where active $f$;
grant execute on function public.fz_offices_list(text) to authenticated;

-- المقترض يحدد الجهة: { office_id } من القائمة، أو { name } لجهة غير مدرجة
create or replace function public.set_fz_office(p_app uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications; f feasibility_offices; v_name text; was jsonb;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'هذا البند لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active','returned') or a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if coalesce(a.purpose, 'household') = 'household' then raise exception 'دراسة الجدوى لطلبات المشاريع فقط'; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status in ('pending','received','conforming')) then
    raise exception 'دراسة الجدوى محالة إلى الخبير أو صدر قراره — لا تُغيَّر الجهة المُعِدّة'; end if;
  was := _fz_office(a);
  if nullif(p->>'office_id', '') is not null then
    select * into f from feasibility_offices where id = (p->>'office_id')::uuid and active;
    if f.id is null then raise exception 'الجهة المختارة غير موجودة في القائمة المعتمدة'; end if;
    update applications set fz_office_id = f.id, fz_office_name = null, fz_office_at = now(), updated_at = now() where id = a.id returning * into a;
    perform _ev(a.id, a.stage, 'تحديد الجهة المُعِدّة لدراسة الجدوى — معتمدة من البنك المركزي', f.name || coalesce(' · ' || f.governorate, '') || ' · مسار ميسّر لدى الخبير');
  else
    v_name := regexp_replace(trim(coalesce(p->>'name', '')), '\s+', ' ', 'g');
    if length(v_name) < 4 or length(v_name) > 90 then raise exception 'اكتب اسم المكتب أو المركز الذي أعدّ الدراسة (4 إلى 90 حرفاً)'; end if;
    select * into f from feasibility_offices where active and lower(regexp_replace(trim(name), '\s+', ' ', 'g')) = lower(v_name);
    if f.id is not null then   -- الاسم المكتوب موجود في القائمة: يُعدّ معتمداً
      update applications set fz_office_id = f.id, fz_office_name = null, fz_office_at = now(), updated_at = now() where id = a.id returning * into a;
      perform _ev(a.id, a.stage, 'تحديد الجهة المُعِدّة لدراسة الجدوى — معتمدة من البنك المركزي', f.name || ' · مسار ميسّر لدى الخبير');
    else
      update applications set fz_office_id = null, fz_office_name = v_name, fz_office_at = now(), updated_at = now() where id = a.id returning * into a;
      perform _ev(a.id, a.stage, 'تحديد الجهة المُعِدّة لدراسة الجدوى — غير مدرجة في القائمة المعتمدة', v_name || ' · تدقيق كامل لدى الخبير');
    end if;
  end if;
  return _fz_office(a);
end $f$;
grant execute on function public.set_fz_office(uuid, jsonb) to authenticated;

-- المسار الميسّر: مهلة أقصر للخبير حين أعدّت الدراسةَ جهةٌ معتمدة
create or replace function public._fz_ref_sla() returns trigger
language plpgsql security definer set search_path = public as $f$
declare v int;
begin
  if exists (select 1 from applications where id = new.application_id and fz_office_id is not null) then
    v := coalesce(_setting('fz_accredited_sla_days'), 2)::int;
    if v > 0 and v < new.sla_days then new.sla_days := v; end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_fz_ref_sla on public.expert_referrals;
create trigger trg_fz_ref_sla before insert on public.expert_referrals for each row execute function public._fz_ref_sla();

-- ───────── ج) إدارة القائمة لمشغّل النظام ─────────
create or replace function public.admin_fz_offices() returns jsonb
language plpgsql stable security definer set search_path = public as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'name', f.name, 'kind', f.kind, 'governorate', f.governorate,
      'license_no', f.license_no, 'cbi_ref', f.cbi_ref, 'phone', f.phone, 'active', f.active, 'demo', f.demo,
      'apps', (select count(*) from applications a where a.fz_office_id = f.id),
      'conforming', (select count(*) from expert_referrals r join applications a on a.id = r.application_id where a.fz_office_id = f.id and r.status = 'conforming'),
      'non_conforming', (select count(*) from expert_referrals r join applications a on a.id = r.application_id where a.fz_office_id = f.id and r.status = 'non_conforming'))
    order by f.active desc, f.governorate, f.name), '[]') from feasibility_offices f);
end $f$;
grant execute on function public.admin_fz_offices() to authenticated;

-- أسماء كتبها المقترضون لجهات غير مدرجة (لمراجعتها مع البنك المركزي)
create or replace function public.admin_fz_unlisted() returns jsonb
language plpgsql stable security definer set search_path = public as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('name', n, 'apps', c) order by c desc, n), '[]')
    from (select fz_office_name n, count(*) c from applications where fz_office_id is null and coalesce(trim(fz_office_name), '') <> '' group by fz_office_name) x);
end $f$;
grant execute on function public.admin_fz_unlisted() to authenticated;

create or replace function public.admin_save_fz_office(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $f$
declare v_id uuid := nullif(p->>'id', '')::uuid; v_name text := regexp_replace(trim(coalesce(p->>'name', '')), '\s+', ' ', 'g');
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if length(v_name) < 4 then raise exception 'اكتب اسم المكتب أو المركز'; end if;
  if coalesce(p->>'kind', 'office') not in ('office','center') then raise exception 'النوع: مكتب أو مركز'; end if;
  if length(trim(coalesce(p->>'cbi_ref', ''))) < 3 then raise exception 'اكتب رقم كتاب اعتماد البنك المركزي وتاريخه'; end if;
  if exists (select 1 from feasibility_offices where lower(regexp_replace(trim(name), '\s+', ' ', 'g')) = lower(v_name) and id is distinct from v_id) then
    raise exception 'الجهة «%» مسجلة مسبقاً', v_name; end if;
  if v_id is null then
    insert into feasibility_offices(name, kind, governorate, license_no, cbi_ref, phone)
    values (v_name, coalesce(p->>'kind', 'office'), nullif(p->>'governorate', ''), nullif(trim(coalesce(p->>'license_no', '')), ''),
      trim(p->>'cbi_ref'), nullif(trim(coalesce(p->>'phone', '')), '')) returning id into v_id;
    perform _audit('إضافة جهة معتمدة لإعداد دراسات الجدوى', v_name, p);
  else
    update feasibility_offices set name = v_name, kind = coalesce(p->>'kind', kind), governorate = nullif(p->>'governorate', ''),
      license_no = nullif(trim(coalesce(p->>'license_no', '')), ''), cbi_ref = trim(p->>'cbi_ref'), phone = nullif(trim(coalesce(p->>'phone', '')), ''),
      active = coalesce((p->>'active')::boolean, active), updated_at = now() where id = v_id;
    if not found then raise exception 'الجهة غير موجودة'; end if;
    perform _audit('تعديل جهة معتمدة لإعداد دراسات الجدوى', v_name, p);
  end if;
  -- جهة أُضيفت للقائمة: الطلبات التي كتبت اسمها نفسه (ولم تصل المصرف) تُربط بها
  update applications set fz_office_id = v_id, fz_office_name = null
  where fz_office_id is null and stage <= 5 and lower(regexp_replace(trim(coalesce(fz_office_name, '')), '\s+', ' ', 'g')) = lower(v_name)
    and exists (select 1 from feasibility_offices where id = v_id and active);
  return v_id;
end $f$;
grant execute on function public.admin_save_fz_office(jsonb) to authenticated;

-- ───────── د) قائمة التدقيق وحالة الطلب تعرض الجهة المُعِدّة ─────────
create or replace function public.intake_checklist(p_app uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; a applications; it jsonb; ex jsonb; miss int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null then raise exception 'الطلب غير موجود'; end if;
  if not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin','cbi','integrity')) then raise exception 'غير مخوّل'; end if;
  it := _intake_items(a); ex := _expert_state(a);
  select count(*) into miss from jsonb_array_elements(it) x where not (x->>'ok')::boolean;
  return jsonb_build_object('applies', a.program = 'solar', 'purpose', a.purpose, 'purpose_label', _purpose_label(a.purpose), 'items', it, 'missing', miss,
    'expert', ex, 'can_accept', miss = 0 and (ex->>'ok')::boolean, 'feasibility_rejections', a.feasibility_rejections,
    'returned', a.returned_from = 6 and a.stage <= 5, 'intake_missing', a.intake_missing, 'return_note', a.return_note,
    'fz_office', _fz_office(a), 'fz_sla', coalesce(_setting('fz_accredited_sla_days'), 2));
end $f$;
grant execute on function public.intake_checklist(uuid) to authenticated;

-- صندوق الخبير: الجهة المُعِدّة، والمسار الميسّر يتقدّم بين المفتوحة
create or replace function public.expert_inbox() returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.role is distinct from 'expert' then raise exception 'غير مخوّل'; end if;
  return (select coalesce(jsonb_agg(to_jsonb(r) || jsonb_build_object(
      'specialty_label', _specialty_label(r.specialty), 'app_code', a.code, 'purpose', a.purpose, 'purpose_label', coalesce(case when a.purpose = 'other' then a.purpose_other end, _purpose_label(a.purpose)),
      'kw', a.kw, 'amount', a.amount, 'price', a.price, 'term_months', a.term_months, 'governorate', a.governorate, 'city', a.city,
      'app_stage', a.stage, 'app_status', a.status, 'feasibility_rejections', a.feasibility_rejections,
      'offer_title', o.title, 'supplier_name', s.name, 'bank_name', b.name, 'work_days', _wd(r.created_at, coalesce(r.decided_at, now())),
      'fz_office', _fz_office(a),
      'history', (select coalesce(jsonb_agg(jsonb_build_object('round', h.round, 'status', h.status, 'specialty_label', _specialty_label(h.specialty),
          'decided_at', h.decided_at, 'decision_text', h.decision_text, 'notes', h.notes, 'feasibility_doc', h.feasibility_doc) order by h.created_at), '[]')
        from expert_referrals h where h.application_id = r.application_id and h.id <> r.id and h.status in ('conforming','non_conforming')))
    order by (r.status in ('pending','received')) desc, (r.status in ('pending','received') and a.fz_office_id is not null) desc, r.created_at desc), '[]')
    from expert_referrals r join applications a on a.id = r.application_id
    left join supplier_offers o on o.id = a.offer_id left join orgs s on s.id = a.supplier_id join orgs b on b.id = r.bank_id
    where r.expert_id = me.id and r.status <> 'cancelled');
end $f$;
grant execute on function public.expert_inbox() to authenticated;

-- غرض التمويل (واجهة الجلسة 16) يقبل «تصدير»
create or replace function public.set_app_purpose(p_app uuid, p_purpose text) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'غرض التمويل لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active','returned') or a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if p_purpose not in ('household','agricultural','industrial','project','vet','export') then raise exception 'اختر غرض التمويل من القائمة'; end if;
  if p_purpose = a.purpose then return a; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر غرض التمويل بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  update applications set purpose = p_purpose, purpose_other = null, site_type = case when p_purpose = 'household' then 'residential' else 'project' end, updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'تحديد غرض التمويل: ' || _purpose_label(p_purpose),
    case when p_purpose = 'household' then 'المستند المطلوب: عرض المورد المقدَّم' else 'المستندات المطلوبة: عرض المورد المقدَّم + دراسة جدوى' end);
  return a;
end $function$;

-- قائمة التدقيق: بند «الجهة المُعِدّة لدراسة الجدوى» (نسخة الجلسة 17 + البند)
create or replace function public._intake_items(a applications) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare p profiles; it jsonb := '[]'::jsonb; fz app_documents; rejdoc uuid; v_bank uuid; hh boolean; plabel text;
begin
  if a.program is distinct from 'solar' then return '[]'::jsonb; end if;
  select * into p from profiles where id = a.citizen_id;
  hh := coalesce(a.purpose, 'household') = 'household';
  plabel := coalesce(case when a.purpose = 'other' then a.purpose_other end, _purpose_label(coalesce(a.purpose, 'household')));
  v_bank := coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid);
  fz := _latest_feasibility(a.id);
  it := it || _ci('national_id', 'رقم البطاقة الوطنية', 'بيانات الحساب', coalesce(p.national_id, '') ~ '^[0-9]{12}$', '1')
           || _ci('phone', 'رقم الهاتف', 'بيانات الحساب', coalesce(p.phone, '') ~ '^07[3-9][0-9]{8}$', 'profile')
           || _ci('governorate', 'المحافظة', 'بيانات الحساب', coalesce(p.governorate, '') <> '', 'profile')
           || _ci('employer', 'جهة العمل', 'بيانات الحساب', coalesce(trim(p.employer), '') <> '', 'profile')
           || _ci('monthly_salary', 'الدخل الشهري', 'بيانات الحساب', coalesce(p.monthly_salary, 0) > 0, 'profile');
  it := it || _ci('site', 'عنوان المنظومة بالـGPS ونوع الموقع (سكن أو مشروع)', 'بيانات الطلب', a.site_geo is not null and a.site_type is not null, '1')
           || _ci('kyc', 'التحقق من الهوية بالسيلفي وفحص الحيوية', 'بيانات الطلب', coalesce((a.kyc->>'liveness')::boolean, false), '1')
           || _ci('ur', 'رقم «أور»', 'بيانات الطلب', coalesce(a.ur_number, '') <> '', '2')
           || _ci('offer', 'المنظومة المختارة', 'بيانات الطلب', a.offer_id is not null, '3')
           || _ci('bank', 'المصرف المختار', 'بيانات الطلب', v_bank is not null, '3');
  it := it || _ci('quote', 'عرض المورد المقدَّم (مستند مرفق)', 'المستندات — ' || plabel,
                  exists (select 1 from app_documents where application_id = a.id and kind = 'quote'), '3');
  if not hh then
    -- الجلسة 25: من أعدّ دراسة الجدوى؟ (مكتب أو مركز معتمد من البنك المركزي، أو اسم يكتبه المقترض) — للطلبات الجديدة
    if a.fz_office_req then
      it := it || _ci('fz_office', 'الجهة التي أعدّت دراسة الجدوى (مكتب أو مركز)', 'المستندات — ' || plabel,
                      a.fz_office_id is not null or coalesce(trim(a.fz_office_name), '') <> '', '3');
    end if;
    it := it || _ci('feasibility', 'دراسة الجدوى', 'المستندات — ' || plabel, fz.id is not null, '3');
  end if;
  if coalesce(a.feasibility_rejections, 0) > 0 then
    select feasibility_doc into rejdoc from expert_referrals where application_id = a.id and status = 'non_conforming' order by decided_at desc limit 1;
    it := it || _ci('feasibility_update', 'دراسة جدوى حقيقية محدّثة بأرقام واقعية (بعد قرار الخبير)', 'المستندات — ' || plabel,
                    fz.id is not null and fz.id is distinct from rejdoc, '3');
  end if;
  it := it || _ci('guarantee', case when a.guarantee_type = 'mortgage' then 'بيانات العقار المرهون' else 'الكفلاء وموافقتهم برمز التحقق' end, 'الضمان', a.guarantee is not null, '4');
  if a.guarantee_type = 'mortgage' then
    it := it || _ci('deed', 'صورة سند العقار بالكاميرا وإقرار الملكية', 'الضمان',
                    a.ownership is not null and exists (select 1 from app_documents where application_id = a.id and kind = 'deed'), '4');
  end if;
  it := it || _ci('payment', 'دفع عمولة المصرف والرسوم', 'الدفع والتوقيع',
                  exists (select 1 from payments where application_id = a.id and bank_id = v_bank and status = 'paid'), '5')
           || _ci('signed', 'التوقيع الإلكتروني على الطلب', 'الدفع والتوقيع', a.submitted_at is not null, '5');
  return it;
end $function$;

-- عنوان المنظومة ونوع المشروع (نسخة الجلسة 22 + «تصدير»)
create or replace function public.set_app_site(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; late boolean := false; v_type text := p->>'site_type'; v_purpose text; v_other text;
  has_geo boolean := nullif(p->>'lat', '') is not null and nullif(p->>'lng', '') is not null; v_home boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'عنوان المنظومة لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  -- الجلسة 19: طلب لدى المصرف بلا عنوان — يُثبَّت الموقع مرة واحدة قبل أمر الشراء، ونوع الموقع يبقى كما هو
  late := a.stage > 5;
  if late then
    if a.site_geo is not null then raise exception 'الطلب لدى المصرف الآن — عنوان المنظومة مثبّت ولا يُعدَّل'; end if;
    if a.stage > 30 then raise exception 'صدر أمر الشراء — يثبّت فني المورد موقع التركيب في الموقع نفسه'; end if;
    if not has_geo then raise exception 'حدّد موقع المنظومة'; end if;
    return _put_site_geo(a.id, p, 'late');
  end if;
  if v_type is null and a.site_type is not null and not (p ? 'purpose') then   -- تحديث الموقع فقط
    v_type := a.site_type; v_purpose := coalesce(a.purpose, 'household'); v_other := a.purpose_other;
  else
    if v_type not in ('residential', 'project') then raise exception 'اختر نوع الموقع: سكن أو مشروع'; end if;
    if v_type = 'residential' then v_purpose := 'household';
    else
      v_purpose := p->>'purpose';
      if v_purpose not in ('industrial', 'project', 'agricultural', 'vet', 'export', 'other') then raise exception 'اختر نوع المشروع: صناعي، تجاري، زراعي، بيطري، تصدير، أو أخرى'; end if;
      if v_purpose = 'other' then
        v_other := regexp_replace(trim(coalesce(p->>'purpose_other', '')), '\s+', ' ', 'g');
        if length(v_other) < 3 or length(v_other) > 60 then raise exception 'اكتب نوع المشروع (3 إلى 60 حرفاً)'; end if;
      end if;
    end if;
  end if;
  if v_purpose is distinct from coalesce(a.purpose, 'household') and exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  if a.site_type is distinct from v_type or coalesce(a.purpose, 'household') is distinct from v_purpose or a.purpose_other is distinct from v_other then
    update applications set site_type = v_type, purpose = v_purpose, purpose_other = v_other, updated_at = now() where id = a.id;
    perform _ev(a.id, a.stage, 'تحديد نوع موقع المنظومة', case when v_type = 'residential' then 'سكن' else 'مشروع — ' || coalesce(v_other, _purpose_label(v_purpose)) end);
  end if;
  -- المقترح 5: «هل المنظومة في عنوان سكنك؟» بدل كتابة المحافظة والمدينة مرتين
  if p ? 'at_home' and nullif(p->>'at_home', '') is not null then
    v_home := (p->>'at_home')::boolean;
    if v_home then
      if coalesce(me.governorate, '') = '' then raise exception 'أكمل محافظة سكنك في «بياناتك» أولاً'; end if;
      update applications set site_home = true, governorate = me.governorate, city = coalesce(nullif(me.city, ''), me.governorate) where id = a.id;
    else
      if not _gov_ok(p->>'governorate') then raise exception 'اختر محافظة مكان المنظومة'; end if;
      update applications set site_home = false, governorate = p->>'governorate', city = coalesce(nullif(left(trim(coalesce(p->>'city', '')), 60), ''), p->>'governorate') where id = a.id;
    end if;
  end if;
  if has_geo then return _put_site_geo(a.id, p, 'borrower'); end if;
  select * into a from applications where id = p_app;
  return a;
end $function$;

notify pgrst, 'reload schema';
