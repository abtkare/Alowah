-- الجلسة 12: تأكيد مكتوب من كل موظف عند إنجاز مرحلته، والإرجاع الموجَّه بأولوية «مستعجل»
-- آمن عند إعادة التشغيل.

-- ═══ 1) أعمدة جديدة ═══
alter table public.stages add column if not exists confirm_text text;          -- عبارة التأكيد التي يكتبها الموظف
alter table public.stages add column if not exists return_targets int[];       -- المراحل التي يجوز الإرجاع إليها
alter table public.applications add column if not exists priority text not null default 'normal';
alter table public.applications add column if not exists returned_from int;     -- المرحلة التي أرجعت المعاملة
alter table public.applications add column if not exists return_note text;      -- النواقص المكتوبة
alter table public.applications add column if not exists returned_at timestamptz;
alter table public.applications add column if not exists returned_by_title text;
do $$ begin
  alter table public.applications add constraint applications_priority_check check (priority in ('normal','urgent'));
exception when duplicate_object then null; end $$;

-- ═══ 2) عبارات التأكيد ومسارات الإرجاع (مسميات وظيفية فقط) ═══
update public.stages s set confirm_text = v.t, return_targets = v.r from (values
  (6,  'تم تدقيق الوثائق', null::int[]),
  (7,  'تم فتح الحساب', array[6]),
  (8,  'موافقة مبدئية والتوجيه بإجراء الضمان', array[6]),
  (9,  'تم إنجاز إجراءات الضمان الأولية', null),
  (10, 'تم استلام العمولات لحساب المصرف من {pay} (دُققت)', array[9]),
  (11, 'موافق على التمويل', array[10]),
  (12, 'تم استلام الإضبارة وإعداد قائمة التدقيق', array[10]),
  (13, 'تم تدقيق كافة حقول الفرع — الإضبارة كاملة', array[10]),
  (14, 'تم الكشف الموقعي ورفع تقرير الجدارة', null),
  (15, 'تم رفع الدراسة الائتمانية والتوصية', array[13]),
  (16, 'موافق', array[10, 15]),
  (17, 'تم كتابة القرار القانوني', array[16]),
  (18, 'موافق', array[16]),
  (19, 'تم استحصال الضمان النهائي', null),
  (24, 'تم إبلاغ الفرع وفتح التسهيل', null),
  (25, 'تم توقيع العقد والكمبيالة', null),
  (26, 'تم تدقيق العقد والكمبيالة', array[25]),
  (27, 'تم تعبئة استمارة طلب التنفيذ', null),
  (28, 'الطلب مطابق للسياسة', array[27]),
  (29, 'معتمد', array[27]),
  (30, 'تم إصدار أمر الشراء للمورد', null),
  (32, 'مطابق — تم استلام البضاعة', null),
  (33, 'تم تنفيذ التمويل وإصدار جدول الأقساط', null),
  (34, 'تم تسليم جدول الأقساط', null),
  (35, 'تم صرف المبلغ للمورد', null),
  (36, 'تم تدقيق القيد', array[35]),
  (37, 'تم حفظ العقود وإغلاق الملف', null)
) v(n, t, r) where s.n = v.n;

-- ═══ 3) الأولوية تُرفع آلياً حين تتجاوز المعاملة المرحلة التي أرجعتها ═══
create or replace function public._clear_urgent() returns trigger language plpgsql as $$
begin
  if new.returned_from is not null and new.stage > old.stage and new.stage > new.returned_from then
    new.priority := 'normal'; new.returned_from := null;
  end if;
  return new;
end $$;
drop trigger if exists trg_clear_urgent on public.applications;
create trigger trg_clear_urgent before update of stage on public.applications for each row execute function public._clear_urgent();

-- ═══ 4) عبارة التأكيد المتوقعة لمرحلة الطلب الحالية (مع طريقة الدفع الفعلية) ═══
create or replace function public.stage_confirm_text(p_app uuid) returns text language sql stable security definer set search_path = public as $$
  select replace(s.confirm_text, '{pay}', coalesce((
    select case p.method when 'zaincash' then 'زين كاش' when 'qicard' then 'كي كارد' when 'asiapay' then 'آسيا باي'
      when 'fastpay' then 'فاست باي' when 'fib' then 'FIB' when 'visa' then 'Visa' when 'mastercard' then 'Mastercard' else 'وسيلة الدفع الإلكتروني' end
    from payments p where p.application_id = a.id and p.status = 'paid' order by p.paid_at desc limit 1), 'وسيلة الدفع'))
  from applications a join stages s on s.n = a.stage where a.id = p_app $$;

-- ═══ 5) لا إنجاز لمرحلة مصرفية دون تأكيد مكتوب (يُضاف سطر إلى الدالة القائمة) ═══
do $$
declare d text := pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure);
  anchor text := 'raise exception ''هذه المرحلة تُنجز عبر السلفة التجميعية لا للطلب منفرداً''; end if;';
begin
  if position('alwah.confirmed' in d) = 0 then
    if position(anchor in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في advance_application'; end if;
    d := replace(d, anchor, anchor || E'\n    if me.portal = ''bank'' and st.confirm_text is not null and coalesce(current_setting(''alwah.confirmed'', true), '''') <> ''1'' then raise exception ''اكتب تأكيد الإنجاز أولاً (مثل: %)'', st.confirm_text; end if;');
    execute d;
  end if;
end $$;

-- ═══ 6) قرار الموظف: إنجاز بتأكيد مكتوب، أو إرجاع موجَّه بالنواقص وأولوية مستعجل ═══
create or replace function public.stage_decision(p_app uuid, p_action text, p_confirm text default null, p_note text default null, p_to int default null)
returns public.applications language plpgsql security definer set search_path = public as $$
declare a applications; st stages; tgt stages; me profiles; cap bigint; txt text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  select * into st from stages where n = a.stage;

  if p_action = 'advance' then
    if coalesce(length(trim(p_confirm)), 0) < 3 then raise exception 'اكتب تأكيد الإنجاز (مثل: %)', stage_confirm_text(a.id); end if;
    txt := '✔ ' || trim(p_confirm);
    if a.stage = 16 and a.bank_id is not null then
      select single_approval_cap into cap from bank_terms where bank_id = a.bank_id;
      if cap is not null and a.amount > cap then txt := txt || ' — يتجاوز صلاحية القسم (' || to_char(cap, 'FM999,999,999') || ' د.ع) ويُرفع للإدارة العليا'; end if;
    end if;
    if coalesce(trim(p_note), '') <> '' then txt := txt || E'\nملاحظة: ' || trim(p_note); end if;
    perform set_config('alwah.confirmed', '1', true);
    a := advance_application(p_app, 'advance', txt);
    perform set_config('alwah.confirmed', '', true);
    return a;

  elsif p_action = 'send_back' then
    if coalesce(trim(p_note), '') = '' then raise exception 'اكتب ما هو النقص'; end if;
    if p_to is null or st.return_targets is null or not (p_to = any(st.return_targets)) then raise exception 'لا يجوز الإرجاع من هذه المرحلة إلى المرحلة المختارة'; end if;
    select * into tgt from stages where n = p_to;
    -- التحقق من الصلاحية والإسناد وتسجيل الحدث يتم عبر دالة المراحل نفسها
    a := advance_application(p_app, 'return', 'إرجاع إلى «' || tgt.owner_label || ' — ' || tgt.name || '» بأولوية مستعجل' || E'\nالنقص: ' || trim(p_note));
    update applications set stage = p_to, status = 'returned', priority = 'urgent', returned_from = st.n,
      return_note = trim(p_note), returned_at = now(), returned_by_title = coalesce(_role_title(me.role), st.owner_label),
      bank_unit = tgt.owner_label, updated_at = now()
    where id = p_app returning * into a;
    return a;
  end if;
  raise exception 'إجراء غير معروف';
end $$;

grant execute on function public.stage_decision(uuid, text, text, text, int) to authenticated;
grant execute on function public.stage_confirm_text(uuid) to authenticated;
