-- ═══════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 27: هوية شاشات الدخول وشعارات الجهات
-- شعار لكل جهة قطاعية (حسب البوابة) ولكل مصرف، يرفعه ويغيّره مشغّل النظام من «الإعدادات».
-- الشعار يظهر في شاشة الدخول (قبل الدخول) وفي الشريط العلوي بعده.
-- الصورة تُحفظ مصغّرة (data URL) في جدول خاص — لا قراءة مباشرة، فقط عبر الدوال.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════

create table if not exists public.brand_logos (
  key text primary key,                 -- 'portal:<بوابة>' أو 'org:<معرّف الجهة>'
  image text not null,                  -- data:image/...;base64,...
  updated_at timestamptz default now(),
  updated_by uuid
);
alter table public.brand_logos enable row level security;
revoke all on public.brand_logos from anon, authenticated;

-- ───────── 1) قراءة عامة لشاشة الدخول (دون تسجيل) ─────────
create or replace function public.public_brand(p_portal text) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object(
    'logo', (select image from brand_logos where key = 'portal:' || p_portal),
    'banks', case when p_portal = 'bank' then (
      select coalesce(jsonb_agg(jsonb_build_object(
        'id', o.id, 'name', o.name, 'islamic', o.is_islamic,
        'logo', (select image from brand_logos where key = 'org:' || o.id),
        'prefix', (select min(split_part(p.username, '.', 1)) from profiles p where p.org_id = o.id and p.username like '%.%')
      ) order by o.code), '[]'::jsonb) from orgs o where o.type = 'bank') end,
    'stats', jsonb_build_object(
      'banks', (select count(*) from orgs where type = 'bank'),
      'suppliers', (select count(*) from orgs where type = 'supplier'),
      'gov', (select count(*) from orgs where type in ('cbi','registry','integrity','audit','syndicate','vetdept')))
  ) $f$;

-- شعار جهة المستخدم بعد الدخول (المصرف بشعاره، وغيره بشعار بوابته)
create or replace function public.my_brand() returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('logo', coalesce(
    (select image from brand_logos where key = 'org:' || p.org_id),
    (select image from brand_logos where key = 'portal:' || p.portal)))
  from profiles p where p.id = auth.uid() $f$;

-- ───────── 2) إدارة الشعارات — مشغّل النظام فقط ─────────
create or replace function public.admin_brand_list() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return coalesce((select jsonb_object_agg(key, jsonb_build_object('image', image, 'at', updated_at)) from brand_logos), '{}'::jsonb);
end $f$;

create or replace function public.admin_set_logo(p_key text, p_image text) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if p_key !~ '^portal:[a-z]+$' and not (p_key ~ '^org:[0-9a-f-]{36}$' and exists (select 1 from orgs where id = substr(p_key, 5)::uuid)) then
    raise exception 'جهة غير معروفة'; end if;
  if p_image is null or p_image = '' then
    delete from brand_logos where key = p_key;
    perform _audit('حذف شعار جهة', p_key, null);
    return;
  end if;
  if p_image !~ '^data:image/(png|webp|jpeg|svg\+xml);base64,' then raise exception 'صيغة الصورة غير مدعومة — استخدم PNG أو JPG أو WEBP أو SVG'; end if;
  if length(p_image) > 700000 then raise exception 'الصورة كبيرة — الحد الأقصى نحو 500 كيلوبايت'; end if;
  insert into brand_logos(key, image, updated_at, updated_by) values (p_key, p_image, now(), auth.uid())
  on conflict (key) do update set image = excluded.image, updated_at = now(), updated_by = auth.uid();
  perform _audit('تغيير شعار جهة', p_key, null);
end $f$;

revoke all on function public.public_brand(text), public.my_brand(), public.admin_brand_list(), public.admin_set_logo(text, text) from public;
grant execute on function public.public_brand(text) to anon, authenticated;
grant execute on function public.my_brand(), public.admin_brand_list(), public.admin_set_logo(text, text) to authenticated;
