-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 32: أدوار وزارة التجارة ومسار الأقسام
--  طلب التأييد لم يعد يُقرَّر من موظف واحد. يمر على أقسام الوزارة بالتسلسل، ولكل قسم دوره وصندوقه:
--    1) الموارد البشرية وشؤون الموظفين  (trade_hr)         — استمرار الخدمة والتعيين والمباشرة والحالة
--    2) الحسابات والرواتب               (trade_payroll)    — الاسمي والمخصصات والاستقطاعات والصافي والسلف والقروض والحجوزات
--    3) وحدة الكفالات والالتزامات        (trade_guarantees) — الكفالات القائمة وأقساطها والمنتهية
--       ← النظام يحتسب الملاءة آلياً بنسبة استقطاع قصوى قابلة للتهيئة لكل غرض تمويل ولكل مصرف، ويحفظ المدخلات والمعادلة
--    4) المسؤول الإداري المخوَّل         (trade_admin)      — يراجع ويوصي، أو يعيد لقسم بسبب مسجَّل
--    5) صاحب الصلاحية (المدير العام)    (trade_signer)     — يعتمد التأييد أو الرفض المسبَّب، أو يعيد
--  trade_officer يصبح «مدير الجهة»: المتابعة وإدارة الفريق وحدود الاستقطاع، دون إجراء على المعاملات.
--  كل اطلاع على ملف موظف يُسجَّل، وبيانات الأقسام في جدول مستقل لا يراه المصرف.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) الأدوار الخمسة الجديدة بجانب trade_officer ─────────
do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''trade_officer'' then ''MT''',
   'when ''trade_officer'' then ''MT'' when ''trade_hr'' then ''MH'' when ''trade_payroll'' then ''MP'' when ''trade_guarantees'' then ''MG'' when ''trade_admin'' then ''MA'' when ''trade_signer'' then ''MS'''],
  ['public._role_title(text)', 'when ''trade_officer'' then ''مدقق رواتب الكفلاء — وزارة التجارة''',
   'when ''trade_officer'' then ''مدير الجهة — وزارة التجارة (المتابعة والفريق)'' when ''trade_hr'' then ''موظف الموارد البشرية وشؤون الموظفين — وزارة التجارة'' when ''trade_payroll'' then ''موظف الحسابات والرواتب — وزارة التجارة'' when ''trade_guarantees'' then ''موظف وحدة الكفالات والالتزامات — وزارة التجارة'' when ''trade_admin'' then ''المسؤول الإداري المخوَّل — وزارة التجارة'' when ''trade_signer'' then ''صاحب الصلاحية (المدير العام) — وزارة التجارة'''],
  ['public._portal_of_role(text)', 'when r = ''trade_officer'' then ''trade''',
   'when r in (''trade_officer'', ''trade_hr'', ''trade_payroll'', ''trade_guarantees'', ''trade_admin'', ''trade_signer'') then ''trade'''],
  ['public._org_roles(text)', 'when ''trade'' then array[''trade_officer'']',
   'when ''trade'' then array[''trade_hr'', ''trade_payroll'', ''trade_guarantees'', ''trade_admin'', ''trade_signer'', ''trade_officer'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('trade_signer' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'الجلسة 32: لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
end $$;

update public.profiles set position_title = 'مدير الجهة — وزارة التجارة (المتابعة والفريق)'
where username = 'trade1' and position_title in ('مدقق رواتب الكفلاء — دائرة الموارد البشرية', 'مدقق رواتب الكفلاء — وزارة التجارة');

-- ───────── 2) مسار المعاملة داخل الوزارة ─────────
alter table public.employer_checks add column if not exists kind text not null default 'guarantor';
alter table public.employer_checks drop constraint if exists employer_checks_kind_check;
alter table public.employer_checks add constraint employer_checks_kind_check check (kind in ('guarantor', 'borrower'));
alter table public.employer_checks add column if not exists wf_stage text not null default 'hr';
alter table public.employer_checks drop constraint if exists employer_checks_wf_stage_check;
alter table public.employer_checks add constraint employer_checks_wf_stage_check check (wf_stage in ('hr', 'payroll', 'guarantees', 'admin', 'signer', 'done', 'cancelled'));
alter table public.employer_checks add column if not exists wf_at timestamptz not null default now();
alter table public.employer_checks add column if not exists result text;
alter table public.employer_checks add column if not exists returns int not null default 0;
alter table public.employer_checks add column if not exists inbox_no text;
alter table public.employer_checks add column if not exists purpose text;
alter table public.employer_checks add column if not exists deduct_pct numeric;
alter table public.employer_checks add column if not exists available bigint;    -- القدرة المتاحة بعد الاحتساب (تظهر للمصرف بعد الاعتماد)
alter table public.employer_checks add column if not exists seal text;           -- بصمة SHA-256 لقرار صاحب الصلاحية

-- المعاملات السابقة: المنتهية بقرار ← «منجزة»، المعلّقة ← تبدأ من الموارد البشرية
update public.employer_checks set wf_stage = case status when 'pending' then 'hr' when 'cancelled' then 'cancelled' else 'done' end
where wf_stage = 'hr' and status <> 'pending';

-- ملف المعاملة لدى الأقسام: لا يقرؤه المصرف ولا المقترض (أقل قدر من البيانات)
create table if not exists public.employer_check_files (
  check_id uuid primary key references public.employer_checks(id) on delete cascade,
  hr jsonb, payroll jsonb, guarantees jsonb, calc jsonb, admin jsonb, signer jsonb,
  updated_at timestamptz not null default now()
);
alter table public.employer_check_files enable row level security;
drop policy if exists read_ec_files on public.employer_check_files;
create policy read_ec_files on public.employer_check_files for select using (
  (my_portal() = 'trade' and exists (select 1 from public.employer_checks c where c.id = check_id and c.org_id = my_org()))
  or my_portal() in ('integrity', 'audit', 'admin'));
revoke all on public.employer_check_files from anon;
revoke insert, update, delete on public.employer_check_files from authenticated;
grant select on public.employer_check_files to authenticated;

-- سجل كل انتقال: من ← إلى، الإجراء، السبب، المنفّذ ورمزه
create table if not exists public.employer_check_log (
  id bigserial primary key,
  check_id uuid not null references public.employer_checks(id) on delete cascade,
  from_stage text, to_stage text, action text not null, note text,
  actor_id uuid, actor_name text, actor_code text, actor_title text,
  created_at timestamptz not null default now()
);
create index if not exists employer_check_log_c on public.employer_check_log(check_id, created_at);
alter table public.employer_check_log enable row level security;
drop policy if exists read_ec_log on public.employer_check_log;
create policy read_ec_log on public.employer_check_log for select using (
  (my_portal() = 'trade' and exists (select 1 from public.employer_checks c where c.id = check_id and c.org_id = my_org()))
  or my_portal() in ('integrity', 'audit', 'admin'));
revoke all on public.employer_check_log from anon;
revoke insert, update, delete on public.employer_check_log from authenticated;
grant select on public.employer_check_log to authenticated;

-- سجل الاطلاع: كل فتح لملف موظف يُسجَّل (لا التعديل فقط)
create table if not exists public.trade_view_log (
  id bigserial primary key,
  check_id uuid not null references public.employer_checks(id) on delete cascade,
  viewer_id uuid, viewer_name text, viewer_code text, viewer_role text, viewer_portal text,
  at timestamptz not null default now()
);
create index if not exists trade_view_log_c on public.trade_view_log(check_id, at);
alter table public.trade_view_log enable row level security;
revoke all on public.trade_view_log from anon, authenticated;

-- نسبة الاستقطاع القصوى من الراتب الصافي: افتراضية + لكل غرض تمويل + لكل مصرف (الأخص يغلب)
create table if not exists public.trade_deduct_limits (
  id serial primary key,
  purpose text, bank_id uuid references public.orgs(id) on delete cascade,
  pct numeric not null check (pct between 5 and 100),
  note text, updated_by_name text, updated_at timestamptz not null default now()
);
create unique index if not exists trade_deduct_limits_u on public.trade_deduct_limits(coalesce(purpose, ''), coalesce(bank_id, '00000000-0000-0000-0000-000000000000'::uuid));
alter table public.trade_deduct_limits enable row level security;
revoke all on public.trade_deduct_limits from anon, authenticated;
insert into public.trade_deduct_limits(purpose, bank_id, pct, note, updated_by_name)
select null, null, 50, 'النسبة الافتراضية — تُعدَّل وفق تعليمات البنك المركزي وضوابط المصرف', 'الإعداد الأولي (الجلسة 32)'
where not exists (select 1 from public.trade_deduct_limits where purpose is null and bank_id is null);

insert into public.settings(key, value, label) values
  ('mot_stage_sla_hours', 48, 'وزارة التجارة: المدة المسموحة لكل قسم على معاملة التأييد قبل تنبيه التأخير (ساعة)')
on conflict (key) do nothing;

insert into public.rejection_reasons(code, label, ctx, sort) values
  ('emp_over_limit', 'التزاماته المالية القائمة تتجاوز الحد المسموح للاستقطاع من راتبه', 'trade', 7),
  ('emp_guarantees', 'كفالاته القائمة تستنفد قدرته على كفالة جديدة', 'trade', 8),
  ('emp_capacity', 'القدرة المتاحة ضمن نسبة الاستقطاع لا تغطي القسط المطلوب', 'trade', 9),
  ('emp_service', 'لا يستوفي شروط استمرار الخدمة (نقل أو إجازة أو انفكاك أو إيقاف)', 'trade', 10)
on conflict (code) do nothing;

-- ───────── 3) أدوات المسار ─────────
create or replace function public._trade_stage_role(s text) returns text language sql immutable as $f$
  select case s when 'hr' then 'trade_hr' when 'payroll' then 'trade_payroll' when 'guarantees' then 'trade_guarantees'
    when 'admin' then 'trade_admin' when 'signer' then 'trade_signer' end $f$;

create or replace function public._trade_stage_label(s text) returns text language sql immutable as $f$
  select case s when 'hr' then 'الموارد البشرية وشؤون الموظفين' when 'payroll' then 'الحسابات والرواتب' when 'guarantees' then 'وحدة الكفالات والالتزامات'
    when 'admin' then 'المسؤول الإداري المخوَّل' when 'signer' then 'صاحب الصلاحية' when 'done' then 'منجزة' when 'cancelled' then 'ملغاة' else s end $f$;

create or replace function public._trade_result_label(r text) returns text language sql immutable as $f$
  select case r when 'ok' then 'مؤهل وظيفياً ومالياً' when 'fin_no' then 'مؤهل وظيفياً وغير مؤهل مالياً'
    when 'service_no' then 'غير مستوفٍ لشروط استمرار الخدمة' when 'over_limit' then 'لديه التزامات مالية تتجاوز الحد المسموح'
    when 'guarantees' then 'لديه كفالات قائمة تؤثر في قدرته على الضمان' when 'incomplete' then 'البيانات غير مكتملة وتحتاج إلى استكمال'
    when 'admin_review' then 'يحتاج إلى مراجعة أو موافقة إدارية' end $f$;

-- نسبة الاستقطاع المطبَّقة: الأخص يغلب (غرض + مصرف ← مصرف ← غرض ← الافتراضية)
create or replace function public._trade_limit(p_purpose text, p_bank uuid) returns numeric
language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select pct from trade_deduct_limits
    where (purpose is null or purpose = p_purpose) and (bank_id is null or bank_id = p_bank)
    order by (bank_id is not null)::int * 2 + (purpose is not null)::int desc limit 1), 50) $f$;

-- إشعار أصحاب دور معيّن في الوزارة (وإن لم يوجد أحد بعد: إشعار عام للجهة)
create or replace function public._trade_notify_role(p_org uuid, p_role text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  insert into notifications(user_id, kind, title, body, ref_id)
  select id, 'employer_check', p_title, p_body, p_ref from profiles where org_id = p_org and role = p_role and not coalesce(disabled, false);
  if not found then perform _notify(p_org, 'trade', 'employer_check', p_title, p_body, p_ref); end if;
end $f$;

-- رقم الوارد، والملف، والإحالة الأولى إلى الموارد البشرية — عند إنشاء أي معاملة تأييد
create or replace function public._ec_on_insert() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare seq int;
begin
  if new.inbox_no is null then
    perform pg_advisory_xact_lock(hashtext('employer_checks_inbox'));
    select coalesce(max(split_part(inbox_no, '/', 3)::int), 0) + 1 into seq from employer_checks
    where inbox_no like 'و/' || to_char(now(), 'YYYY') || '/%';
    new.inbox_no := 'و/' || to_char(now(), 'YYYY') || '/' || lpad(seq::text, 5, '0');
  end if;
  if new.purpose is null then new.purpose := (select coalesce(purpose, 'household') from applications where id = new.application_id); end if;
  new.wf_stage := case when new.status = 'pending' then 'hr' when new.status = 'cancelled' then 'cancelled' else 'done' end;
  new.wf_at := now();
  return new;
end $f$;
drop trigger if exists trg_ec_insert on public.employer_checks;
create trigger trg_ec_insert before insert on public.employer_checks for each row execute function public._ec_on_insert();

create or replace function public._ec_after_insert() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  insert into employer_check_files(check_id) values (new.id) on conflict do nothing;
  insert into employer_check_log(check_id, from_stage, to_stage, action, note, actor_name, actor_title)
  values (new.id, null, new.wf_stage, 'تسجيل في سجل الوارد الإلكتروني برقم ' || new.inbox_no || ' والإحالة إلى ' || _trade_stage_label(new.wf_stage),
    'ورد آلياً من منصة «ألواح» — ' || case new.kind when 'borrower' then 'الموظف مقترض' else 'الموظف كفيل' end, 'النظام', 'إحالة آلية');
  if new.status = 'pending' then
    perform _trade_notify_role(new.org_id, 'trade_hr', 'معاملة تأييد جديدة — ' || new.code,
      new.guarantor_name || coalesce(' · ' || new.dept, '') || ' — تحقق من استمرار الخدمة والتعيين', new.application_id);
  end if;
  return null;
end $f$;
drop trigger if exists trg_ec_after_insert on public.employer_checks;
create trigger trg_ec_after_insert after insert on public.employer_checks for each row execute function public._ec_after_insert();

-- الإلغاء من المنصة (استبدال الكفيل أو الضمان) يُغلق المسار ويُسجَّل
create or replace function public._ec_on_cancel() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    new.wf_stage := 'cancelled'; new.wf_at := now();
    insert into employer_check_log(check_id, from_stage, to_stage, action, note, actor_name, actor_title)
    values (new.id, old.wf_stage, 'cancelled', 'إلغاء المعاملة من المنصة', new.cancel_note, 'النظام', 'المنصة');
  end if;
  return new;
end $f$;
drop trigger if exists trg_ec_cancel on public.employer_checks;
create trigger trg_ec_cancel before update of status on public.employer_checks for each row execute function public._ec_on_cancel();

-- ملفات للمعاملات السابقة
insert into public.employer_check_files(check_id) select id from public.employer_checks on conflict do nothing;
update public.employer_checks c set inbox_no = 'و/' || to_char(c.created_at, 'YYYY') || '/' || lpad(x.rn::text, 5, '0'),
  purpose = coalesce(c.purpose, (select coalesce(purpose, 'household') from public.applications where id = c.application_id))
from (select id, row_number() over (order by created_at) rn from public.employer_checks) x
where x.id = c.id and c.inbox_no is null;

-- الموظف المنفّذ: في الوزارة نفسها، بدوره المطابق لمرحلة المعاملة
create or replace function public._trade_actor(c employer_checks, p_stage text) returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal <> 'trade' then raise exception 'غير مخوّل'; end if;
  if c.id is null or c.org_id <> me.org_id then raise exception 'المعاملة غير موجودة'; end if;
  if c.status <> 'pending' or c.wf_stage in ('done', 'cancelled') then raise exception 'المعاملة منجزة أو ملغاة'; end if;
  if c.wf_stage <> p_stage then raise exception 'المعاملة الآن لدى: %', _trade_stage_label(c.wf_stage); end if;
  if me.role <> _trade_stage_role(p_stage) then raise exception 'هذا الإجراء من صلاحية: %', _role_title(_trade_stage_role(p_stage)); end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  return me;
end $f$;

-- نقل المعاملة إلى قسم آخر مع تسجيل الانتقال وإشعار القسم المستلم
create or replace function public._trade_move(c employer_checks, p_to text, p_action text, p_note text, me profiles) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare r employer_checks;
begin
  update employer_checks set wf_stage = p_to, wf_at = now(), updated_at = now(),
    returns = returns + case when p_action like 'إعادة%' then 1 else 0 end
  where id = c.id returning * into r;
  insert into employer_check_log(check_id, from_stage, to_stage, action, note, actor_id, actor_name, actor_code, actor_title)
  values (c.id, c.wf_stage, p_to, p_action, p_note, me.id, me.full_name, me.staff_code, _role_title(me.role));
  if _trade_stage_role(p_to) is not null then
    perform _trade_notify_role(c.org_id, _trade_stage_role(p_to),
      case when p_action like 'إعادة%' then 'أُعيدت إليكم معاملة التأييد ' || c.code else 'معاملة تأييد بانتظاركم — ' || c.code end,
      c.guarantor_name || ' · ' || p_action || coalesce(' — ' || p_note, ''), c.application_id);
  end if;
  return r;
end $f$;

-- احتساب الملاءة: آلي، وكل المدخلات والمعادلة محفوظة
create or replace function public._trade_calc(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; f employer_check_files; a applications; h jsonb; py jsonb; gr jsonb;
  v_pct numeric; v_net bigint; v_maxd bigint; v_commit bigint; v_gob bigint; v_plat bigint; v_avail bigint; v_need bigint;
  v_res text; v_reasons text[] := '{}'; v_emp text; v_now text; out jsonb;
begin
  select * into c from employer_checks where id = p_id;
  select * into f from employer_check_files where check_id = p_id;
  select * into a from applications where id = c.application_id;
  h := f.hr; py := f.payroll; gr := f.guarantees;
  v_pct := _trade_limit(coalesce(c.purpose, a.purpose, 'household'), c.bank_id);
  v_need := case when c.kind = 'borrower' then coalesce(a.monthly_installment, c.share) else c.share end;
  v_emp := h->>'employment'; v_now := h->>'status_now';
  -- كفالات المنصة القائمة لهذا الموظف في طلبات أخرى (سجل المنصة — لا يعني عدم وجود كفالات خارجها)
  select coalesce(sum(x.share), 0) into v_plat from employer_checks x join applications ax on ax.id = x.application_id
  where x.id <> c.id and x.status = 'approved' and x.kind = 'guarantor' and ax.status in ('active', 'returned')
    and ((c.guarantor_nid is not null and x.guarantor_nid = c.guarantor_nid) or (c.guarantor_phone is not null and x.guarantor_phone = c.guarantor_phone));

  if h is null then v_res := 'incomplete';
  elsif v_emp = 'not_found' then v_res := 'service_no'; v_reasons := array['emp_not_found'];
  elsif v_emp = 'retired' or v_now in ('separated', 'retired') then v_res := 'service_no'; v_reasons := array['emp_retired'];
  elsif v_emp = 'daily' then v_res := 'service_no'; v_reasons := array['emp_not_permanent'];
  elsif v_now = 'suspended' then v_res := 'service_no'; v_reasons := array['emp_service'];
  elsif py is null or gr is null then v_res := 'incomplete';
  else
    v_net := (py->>'net')::bigint;
    if coalesce(v_net, 0) <= 0 then v_res := 'incomplete';
    else
      v_maxd := floor(v_net * v_pct / 100);
      v_commit := coalesce((py->>'advances_monthly')::bigint, 0) + coalesce((py->>'loans_monthly')::bigint, 0) + coalesce((py->>'garnish_monthly')::bigint, 0);
      v_gob := greatest(coalesce((gr->>'active_monthly')::bigint, 0), v_plat);
      v_avail := v_maxd - v_commit - v_gob;
      if v_commit > v_maxd then v_res := 'over_limit'; v_reasons := array['emp_over_limit'];
      elsif v_need > v_avail then
        if v_need <= v_maxd - v_commit then v_res := 'guarantees'; v_reasons := array['emp_guarantees'];
        else v_res := 'fin_no'; v_reasons := array['emp_capacity']; end if;
      elsif v_emp = 'contract' or v_now in ('leave', 'transferred') then v_res := 'admin_review';
      else v_res := 'ok'; end if;
    end if;
  end if;

  out := jsonb_build_object('result', v_res, 'label', _trade_result_label(v_res), 'reasons', to_jsonb(v_reasons),
    'inputs', jsonb_build_object('kind', c.kind, 'employment', v_emp, 'status_now', v_now, 'net', v_net,
      'advances_monthly', py->>'advances_monthly', 'loans_monthly', py->>'loans_monthly', 'garnish_monthly', py->>'garnish_monthly',
      'guarantees_monthly_ministry', gr->>'active_monthly', 'guarantees_monthly_platform', v_plat, 'need', v_need,
      'purpose', coalesce(c.purpose, a.purpose), 'bank_id', c.bank_id),
    'pct', v_pct, 'max_deduct', v_maxd, 'commitments', v_commit, 'guarantee_obligations', v_gob, 'available', v_avail, 'need', v_need,
    'formula', case when v_maxd is null then null else
      'الحد الأقصى للاستقطاع = الصافي ' || to_char(v_net, 'FM999,999,999') || ' × ' || v_pct || '% = ' || to_char(v_maxd, 'FM999,999,999') ||
      ' · القدرة المتاحة = ' || to_char(v_maxd, 'FM999,999,999') || ' − الأقساط والسلف والحجوزات ' || to_char(v_commit, 'FM999,999,999') ||
      ' − التزامات الكفالات ' || to_char(v_gob, 'FM999,999,999') || ' = ' || to_char(v_avail, 'FM999,999,999') ||
      ' · المطلوب ' || to_char(v_need, 'FM999,999,999') || case when v_need <= v_avail then ' ≤ المتاح ✓' else ' > المتاح ✗' end end,
    'at', now());
  update employer_check_files set calc = out, updated_at = now() where check_id = p_id;
  update employer_checks set result = v_res, deduct_pct = v_pct, available = v_avail, updated_at = now() where id = p_id;
  return out;
end $f$;

-- ───────── 4) إجراءات الأقسام ─────────
create or replace function public._trade_n(p jsonb, k text) returns bigint language sql immutable as $f$
  select nullif(regexp_replace(coalesce(p->>k, ''), '\D', '', 'g'), '')::bigint $f$;

-- (1) الموارد البشرية
create or replace function public.trade_hr_submit(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; me profiles; v_emp text := nullif(p->>'employment', ''); v_now text := nullif(p->>'status_now', '');
  v_no text := trim(coalesce(p->>'employee_no', '')); v_app date; v_start date; v_to text; h jsonb;
begin
  select * into c from employer_checks where id = p_id for update;
  me := _trade_actor(c, 'hr');
  if coalesce((p->>'confirm')::boolean, false) is not true then raise exception 'أكّد أن البيانات منقولة من سجل الموظف الرسمي'; end if;
  if v_emp is null or v_emp not in ('permanent', 'contract', 'daily', 'retired', 'not_found') then raise exception 'اختر نوع التعيين من السجل'; end if;
  if v_emp <> 'not_found' then
    if length(v_no) < 2 then raise exception 'اكتب الرقم الوظيفي'; end if;
    if v_now is null or v_now not in ('on_duty', 'leave', 'transferred', 'suspended', 'separated', 'retired') then raise exception 'اختر حالته الوظيفية الحالية'; end if;
    v_app := nullif(p->>'appoint_date', '')::date; v_start := nullif(p->>'start_date', '')::date;
    if v_app is null then raise exception 'اكتب تاريخ التعيين'; end if;
    if v_app > current_date or v_start > current_date then raise exception 'التاريخ لا يكون في المستقبل'; end if;
    if v_start is not null and v_start < v_app then raise exception 'تاريخ المباشرة لا يسبق تاريخ التعيين'; end if;
    if length(trim(coalesce(p->>'job_title', ''))) < 2 then raise exception 'اكتب العنوان الوظيفي'; end if;
  end if;
  h := jsonb_build_object('employee_no', nullif(v_no, ''), 'employment', v_emp, 'status_now', v_now, 'appoint_date', v_app, 'start_date', v_start,
    'job_title', nullif(trim(coalesce(p->>'job_title', '')), ''), 'section', nullif(trim(coalesce(p->>'section', '')), ''),
    'note', nullif(left(trim(coalesce(p->>'note', '')), 500), ''), 'by', me.full_name, 'by_code', me.staff_code, 'at', now());
  update employer_check_files set hr = h, updated_at = now() where check_id = c.id;
  perform _trade_calc(c.id);
  -- لا يوجد في السجل أو انتهت خدمته: لا معنى لتدقيق الراتب — إلى المسؤول الإداري مباشرة
  v_to := case when v_emp in ('not_found', 'retired') or v_now in ('separated', 'retired') then 'admin' else 'payroll' end;
  return _trade_move(c, v_to, 'إنجاز التدقيق الوظيفي (الموارد البشرية)' || case when v_to = 'admin' then ' — الخدمة غير مستمرة، إلى المسؤول الإداري مباشرة' else '' end,
    case v_emp when 'not_found' then 'لا يوجد في سجلات الدائرة' else 'الرقم الوظيفي ' || v_no end, me);
end $f$;

-- (2) الحسابات والرواتب
create or replace function public.trade_payroll_submit(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; me profiles; v_nom bigint := _trade_n(p, 'nominal'); v_alw bigint := coalesce(_trade_n(p, 'allowances'), 0);
  v_leg bigint := coalesce(_trade_n(p, 'legal_deductions'), 0); v_gross bigint; v_net bigint;
begin
  select * into c from employer_checks where id = p_id for update;
  me := _trade_actor(c, 'payroll');
  if coalesce((p->>'confirm')::boolean, false) is not true then raise exception 'أكّد أن البيانات منقولة من سجل الرواتب'; end if;
  if v_nom is null or v_nom < 100000 then raise exception 'اكتب الراتب الاسمي'; end if;
  v_gross := v_nom + v_alw; v_net := v_gross - v_leg;
  if v_net <= 0 then raise exception 'الاستقطاعات القانونية أكبر من إجمالي الراتب — راجع الأرقام'; end if;
  update employer_check_files set payroll = jsonb_build_object('nominal', v_nom, 'allowances', v_alw, 'gross', v_gross, 'legal_deductions', v_leg, 'net', v_net,
      'advances_monthly', coalesce(_trade_n(p, 'advances_monthly'), 0), 'loans_monthly', coalesce(_trade_n(p, 'loans_monthly'), 0), 'garnish_monthly', coalesce(_trade_n(p, 'garnish_monthly'), 0),
      'note', nullif(left(trim(coalesce(p->>'note', '')), 500), ''), 'by', me.full_name, 'by_code', me.staff_code, 'at', now()), updated_at = now()
  where check_id = c.id;
  update employer_checks set net_salary = v_net, has_advance = coalesce(_trade_n(p, 'advances_monthly'), 0) > 0,
    advance_monthly = nullif(coalesce(_trade_n(p, 'advances_monthly'), 0), 0) where id = c.id;
  perform _trade_calc(c.id);
  return _trade_move(c, 'guarantees', 'إنجاز التدقيق المالي (الحسابات والرواتب)', 'الصافي ' || to_char(v_net, 'FM999,999,999') || ' د.ع', me);
end $f$;

-- (3) وحدة الكفالات — ثم الاحتساب الآلي
create or replace function public.trade_guarantees_submit(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; me profiles; v_cnt int := coalesce(_trade_n(p, 'active_count'), 0)::int; v_mon bigint := coalesce(_trade_n(p, 'active_monthly'), 0); k jsonb;
begin
  select * into c from employer_checks where id = p_id for update;
  me := _trade_actor(c, 'guarantees');
  if coalesce((p->>'confirm')::boolean, false) is not true then raise exception 'أكّد أن البيانات منقولة من سجل الكفالات'; end if;
  if v_cnt = 0 and v_mon > 0 then raise exception 'كتبت أقساطاً دون عدد الكفالات القائمة'; end if;
  if v_cnt > 0 and v_mon = 0 then raise exception 'اكتب مجموع الأقساط الشهرية للكفالات القائمة'; end if;
  update employer_check_files set guarantees = jsonb_build_object('active_count', v_cnt, 'active_monthly', v_mon, 'active_amount', coalesce(_trade_n(p, 'active_amount'), 0),
      'ended_count', coalesce(_trade_n(p, 'ended_count'), 0), 'note', nullif(left(trim(coalesce(p->>'note', '')), 500), ''),
      'by', me.full_name, 'by_code', me.staff_code, 'at', now()), updated_at = now()
  where check_id = c.id;
  update employer_checks set other_guarantee = v_cnt > 0 where id = c.id;
  k := _trade_calc(c.id);
  return _trade_move(c, 'admin', 'إنجاز تدقيق الكفالات واحتساب الملاءة آلياً', 'النتيجة الأولية: ' || (k->>'label'), me);
end $f$;

-- (4) المسؤول الإداري: يوصي ويحيل لصاحب الصلاحية، أو يعيد لقسم بسبب مسجَّل
create or replace function public.trade_admin_act(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; me profiles; v_act text := p->>'action'; v_rec text := p->>'recommendation'; v_to text := p->>'to';
  v_note text := nullif(left(trim(coalesce(p->>'note', '')), 600), ''); k jsonb;
begin
  select * into c from employer_checks where id = p_id for update;
  me := _trade_actor(c, 'admin');
  if v_act = 'return' then
    if v_to not in ('hr', 'payroll', 'guarantees') then raise exception 'اختر القسم الذي تُعاد إليه المعاملة'; end if;
    if v_note is null or length(v_note) < 10 then raise exception 'اكتب سبب الإعادة (النقص أو الخطأ)'; end if;
    return _trade_move(c, v_to, 'إعادة إلى ' || _trade_stage_label(v_to) || ' لاستكمال النواقص', v_note, me);
  end if;
  if v_act <> 'forward' or v_rec not in ('approve', 'reject') then raise exception 'اختر التوصية: تأييد أو رفض'; end if;
  k := _trade_calc(c.id);
  if k->>'result' = 'incomplete' then raise exception 'البيانات غير مكتملة — أعد المعاملة للقسم المختص'; end if;
  if v_rec = 'approve' then
    if k->>'result' not in ('ok', 'admin_review') then raise exception 'لا يصح التأييد: %', k->>'label'; end if;
    if k->>'result' = 'admin_review' and (v_note is null or length(v_note) < 10) then raise exception 'الحالة تحتاج موافقة إدارية — اكتب مسوّغ التأييد'; end if;
  elsif k->>'result' in ('ok', 'admin_review') and (v_note is null or length(v_note) < 10) then
    raise exception 'الموظف مؤهل — إن كان للرفض سبب آخر فاكتبه';
  end if;
  update employer_check_files set admin = jsonb_build_object('recommendation', v_rec, 'note', v_note, 'result', k->>'result',
    'by', me.full_name, 'by_code', me.staff_code, 'at', now()), updated_at = now() where check_id = c.id;
  return _trade_move(c, 'signer', 'مراجعة إدارية وتوصية ب' || case v_rec when 'approve' then 'التأييد' else 'الرفض' end || ' — إحالة لصاحب الصلاحية', v_note, me);
end $f$;

-- (5) صاحب الصلاحية: يعتمد (تأييد أو رفض مسبَّب) — وهو القرار النهائي الذي يصل المصرف — أو يعيد
create or replace function public.trade_signer_act(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
declare c employer_checks; me profiles; a applications; f employer_check_files; v_act text := p->>'action'; v_to text := p->>'to';
  v_note text := nullif(left(trim(coalesce(p->>'note', '')), 600), ''); k jsonb; v_reasons text[]; lbl text; v_seal text;
begin
  select * into c from employer_checks where id = p_id for update;
  me := _trade_actor(c, 'signer');
  if v_act = 'return' then
    if v_to not in ('hr', 'payroll', 'guarantees', 'admin') then raise exception 'اختر الجهة التي تُعاد إليها المعاملة'; end if;
    if v_note is null or length(v_note) < 10 then raise exception 'اكتب سبب الإعادة'; end if;
    return _trade_move(c, v_to, 'إعادة من صاحب الصلاحية إلى ' || _trade_stage_label(v_to), v_note, me);
  end if;
  if v_act not in ('approve', 'reject') then raise exception 'اختر القرار'; end if;
  if coalesce((p->>'confirm')::boolean, false) is not true then raise exception 'أكّد الاعتماد — يُسجَّل باسمك ورمزك الوظيفي'; end if;
  k := _trade_calc(c.id);
  select * into f from employer_check_files where check_id = c.id;
  if k->>'result' = 'incomplete' then raise exception 'البيانات غير مكتملة — أعد المعاملة للقسم المختص'; end if;
  if v_act = 'approve' then
    if k->>'result' not in ('ok', 'admin_review') then raise exception 'لا يصح التأييد: %', k->>'label'; end if;
    if k->>'result' = 'admin_review' and f.admin->>'recommendation' is distinct from 'approve' then raise exception 'الحالة تحتاج موافقة إدارية — أعدها للمسؤول الإداري'; end if;
    v_reasons := null;
  else
    v_reasons := array(select jsonb_array_elements_text(k->'reasons'));
    if coalesce(array_length(v_reasons, 1), 0) = 0 then
      if v_note is null or length(v_note) < 10 then raise exception 'الموظف مؤهل — إن كان للرفض سبب آخر فاكتبه'; end if;
      v_reasons := array['emp_other'];
    end if;
  end if;
  -- بصمة القرار: تُحفظ مع المعاملة وتُبنى عليها بصمة الكتاب الرسمي لاحقاً
  v_seal := encode(sha256(convert_to(jsonb_build_object('code', c.code, 'decision', v_act, 'calc', k, 'hr', f.hr, 'payroll', f.payroll, 'guarantees', f.guarantees,
    'admin', f.admin, 'signer', me.staff_code, 'at', now())::text, 'UTF8')), 'hex');
  update employer_check_files set signer = jsonb_build_object('decision', v_act, 'note', v_note, 'by', me.full_name, 'by_code', me.staff_code, 'at', now(), 'seal', v_seal),
    updated_at = now() where check_id = c.id;
  update employer_checks set status = case when v_act = 'approve' then 'approved' else 'rejected' end, reasons = v_reasons, note = v_note,
    employment = f.hr->>'employment', seal = v_seal,
    decided_by = me.id, decided_by_name = me.full_name, decided_by_code = me.staff_code, decided_by_title = _role_title(me.role), decided_at = now(), updated_at = now()
  where id = c.id returning * into c;
  c := _trade_move(c, 'done', case when v_act = 'approve' then 'اعتماد التأييد من صاحب الصلاحية' else 'اعتماد الرفض المسبَّب من صاحب الصلاحية' end, v_note, me);

  select * into a from applications where id = c.application_id;
  lbl := (select string_agg(label, '، ' order by sort) from rejection_reasons where code = any(c.reasons));
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role)
  values (a.id, a.stage, case when c.status = 'approved' then 'تأييد وزارة التجارة: ' || (k->>'label') || ' — ' || c.guarantor_name || ' (' || c.code || ')'
      else 'رفض وزارة التجارة ' || case c.kind when 'borrower' then 'تأييد المقترض ' else 'كفالة ' end || c.guarantor_name || ' (' || c.code || '): ' || lbl end,
    coalesce(c.dept || ' · ', '') || 'مرّت على الموارد البشرية والحسابات والكفالات والمسؤول الإداري · اعتمدها ' || _role_title(me.role) || coalesce(' · ' || v_note, ''),
    me.id, me.full_name, me.role);
  perform _notify(c.bank_id, 'bank', 'employer_check',
    case when c.status = 'approved' then 'أيّدت وزارة التجارة ' || case c.kind when 'borrower' then 'المقترض' else 'راتب الكفيل' end || ' — ' || a.code
      else 'رفضت وزارة التجارة ' || case c.kind when 'borrower' then 'تأييد المقترض' else 'الكفيل' end || ' — ' || a.code end,
    case when c.status = 'approved' then c.guarantor_name || ': ' || (k->>'label') || ' · القدرة المتاحة ' || to_char((k->>'available')::bigint, 'FM999,999,999') || ' د.ع.'
      else c.guarantor_name || ': ' || lbl || '. أعد الطلب للمقترض لاستبدال الكفيل أو تقديم ضمان آخر.' end, a.id);
  return c;
end $f$;

-- القرار السريع من موظف واحد (الجلسة 31) استُبدل بمسار الأقسام
create or replace function public.trade_decide(p_id uuid, p jsonb) returns employer_checks
language plpgsql security definer set search_path to 'public' as $f$
begin
  raise exception 'القرار يمر الآن على أقسام الوزارة بالتسلسل — افتح المعاملة من صندوق قسمك';
end $f$;

-- ───────── 5) بوابة الوزارة: الصندوق، والملف (مع تسجيل الاطلاع)، وحدود الاستقطاع ─────────
create or replace function public.trade_inbox() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; v_org uuid; v_sla numeric := coalesce(_setting('mot_stage_sla_hours'), 48); my_stage text;
begin
  me := _trade_reader();
  v_org := case when me.portal = 'trade' then me.org_id else (select id from orgs where type = 'trade' order by created_at limit 1) end;
  my_stage := case me.role when 'trade_hr' then 'hr' when 'trade_payroll' then 'payroll' when 'trade_guarantees' then 'guarantees'
    when 'trade_admin' then 'admin' when 'trade_signer' then 'signer' end;
  return jsonb_build_object(
    'my_stage', my_stage, 'my_stage_label', _trade_stage_label(my_stage), 'role_title', _role_title(me.role),
    'can_limits', (me.portal = 'trade' and coalesce(me.manage_scope, '') = 'org') or me.portal = 'admin',
    'sla_hours', v_sla,
    'checks', (select coalesce(jsonb_agg(jsonb_build_object(
        'id', c.id, 'code', c.code, 'inbox_no', c.inbox_no, 'kind', c.kind, 'status', c.status, 'wf_stage', c.wf_stage, 'wf_label', _trade_stage_label(c.wf_stage),
        'wf_at', c.wf_at, 'result', c.result, 'result_label', _trade_result_label(c.result), 'returns', c.returns,
        'guarantor_name', c.guarantor_name, 'dept', c.dept, 'share', c.share, 'created_at', c.created_at, 'decided_at', c.decided_at,
        'late', c.wf_stage not in ('done', 'cancelled') and extract(epoch from now() - c.wf_at) / 3600 > v_sla,
        'hours', round((extract(epoch from now() - c.wf_at) / 3600)::numeric, 1),
        'app_code', a.code, 'borrower', a.citizen_name, 'bank_name', (select name from orgs where id = c.bank_id))
      order by (c.wf_stage = my_stage) desc, (c.status = 'pending') desc, c.created_at desc), '[]'::jsonb)
      from employer_checks c join applications a on a.id = c.application_id where c.org_id = v_org),
    'stats', jsonb_build_object(
      'by_stage', (select coalesce(jsonb_object_agg(wf_stage, n), '{}'::jsonb) from (select wf_stage, count(*) n from employer_checks where org_id = v_org group by 1) s),
      'pending', (select count(*) from employer_checks where org_id = v_org and status = 'pending'),
      'approved', (select count(*) from employer_checks where org_id = v_org and status = 'approved'),
      'rejected', (select count(*) from employer_checks where org_id = v_org and status = 'rejected'),
      'late', (select count(*) from employer_checks where org_id = v_org and wf_stage not in ('done', 'cancelled') and extract(epoch from now() - wf_at) / 3600 > v_sla),
      'avg_hours', (select round(avg(extract(epoch from decided_at - created_at) / 3600)::numeric, 1) from employer_checks where org_id = v_org and decided_at is not null),
      'late_rate', (select round(100.0 * count(*) filter (where extract(epoch from decided_at - created_at) / 3600 > v_sla * 5) / nullif(count(*), 0), 0)
                    from employer_checks where org_id = v_org and decided_at is not null),
      'stage_hours', (select coalesce(jsonb_object_agg(from_stage, h), '{}'::jsonb) from (
          select l.from_stage, round(avg(extract(epoch from l.created_at - p.created_at) / 3600)::numeric, 1) h
          from employer_check_log l join lateral (select created_at from employer_check_log p where p.check_id = l.check_id and p.id < l.id order by p.id desc limit 1) p on true
          join employer_checks c on c.id = l.check_id where c.org_id = v_org and l.from_stage is not null group by 1) q),
      'by_reason', (select coalesce(jsonb_agg(jsonb_build_object('label', r.label, 'n', x.n) order by x.n desc), '[]'::jsonb)
        from (select unnest(reasons) code, count(*) n from employer_checks where org_id = v_org and status = 'rejected' group by 1) x join rejection_reasons r on r.code = x.code),
      'returns', (select coalesce(jsonb_agg(jsonb_build_object('to', _trade_stage_label(l.to_stage), 'note', l.note, 'at', l.created_at, 'code', c.code) order by l.created_at desc), '[]'::jsonb)
        from employer_check_log l join employer_checks c on c.id = l.check_id where c.org_id = v_org and l.action like 'إعادة%'),
      'by_result', (select coalesce(jsonb_agg(jsonb_build_object('label', _trade_result_label(result), 'n', n) order by n desc), '[]'::jsonb)
        from (select result, count(*) n from employer_checks where org_id = v_org and result is not null group by 1) q),
      'by_dept', (select coalesce(jsonb_agg(jsonb_build_object('dept', d, 'n', n, 'ok', ok, 'bad', bad) order by n desc), '[]'::jsonb)
        from (select coalesce(dept, '—') d, count(*) n, count(*) filter (where status = 'approved') ok, count(*) filter (where status = 'rejected') bad
              from employer_checks where org_id = v_org and status <> 'cancelled' group by 1) q)));
end $f$;

-- ملف المعاملة كاملاً لأقسام الوزارة — وكل فتح يُسجَّل في سجل الاطلاع
create or replace function public.trade_check(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; c employer_checks; f employer_check_files; a applications;
begin
  me := _trade_reader();
  select * into c from employer_checks where id = p_id;
  if c.id is null or (me.portal = 'trade' and c.org_id <> me.org_id) then raise exception 'المعاملة غير موجودة'; end if;
  select * into f from employer_check_files where check_id = c.id;
  select * into a from applications where id = c.application_id;
  insert into trade_view_log(check_id, viewer_id, viewer_name, viewer_code, viewer_role, viewer_portal)
  values (c.id, me.id, me.full_name, me.staff_code, me.role, me.portal);
  return to_jsonb(c) - 'decided_by' || jsonb_build_object(
    'wf_label', _trade_stage_label(c.wf_stage), 'result_label', _trade_result_label(c.result),
    'can_act', me.portal = 'trade' and c.status = 'pending' and me.role = _trade_stage_role(c.wf_stage),
    'app_code', a.code, 'borrower', a.citizen_name, 'purpose_label', _purpose_label(coalesce(a.purpose, 'household')),
    'amount', a.amount, 'term_months', a.term_months, 'installment', coalesce(a.monthly_installment, c.share),
    'guarantors_n', greatest(jsonb_array_length(coalesce(a.guarantee->'guarantors', '[]'::jsonb)), 1),
    'guarantee_type', a.guarantee_type, 'bank_name', (select name from orgs where id = c.bank_id),
    'pct', _trade_limit(coalesce(c.purpose, a.purpose, 'household'), c.bank_id),
    'hr', f.hr, 'payroll', f.payroll, 'guarantees', f.guarantees, 'calc', f.calc, 'admin', f.admin, 'signer', f.signer,
    'platform_guarantees', (select coalesce(jsonb_agg(jsonb_build_object('code', x.code, 'app', ax.code, 'bank', (select name from orgs where id = x.bank_id), 'share', x.share, 'at', x.decided_at)), '[]'::jsonb)
      from employer_checks x join applications ax on ax.id = x.application_id
      where x.id <> c.id and x.status = 'approved' and x.kind = 'guarantor' and ax.status in ('active', 'returned')
        and ((c.guarantor_nid is not null and x.guarantor_nid = c.guarantor_nid) or (c.guarantor_phone is not null and x.guarantor_phone = c.guarantor_phone))),
    'reason_labels', (select coalesce(jsonb_agg(r.label order by r.sort), '[]'::jsonb) from rejection_reasons r where r.code = any(c.reasons)),
    'log', (select coalesce(jsonb_agg(jsonb_build_object('from', _trade_stage_label(from_stage), 'to', _trade_stage_label(to_stage), 'action', action, 'note', note,
        'by', actor_name, 'code', actor_code, 'title', actor_title, 'at', created_at) order by id), '[]'::jsonb) from employer_check_log where check_id = c.id),
    'views', (select count(*) from trade_view_log where check_id = c.id),
    'viewers', case when coalesce(me.manage_scope, '') = 'org' or me.portal = 'admin' then
      (select coalesce(jsonb_agg(jsonb_build_object('name', viewer_name, 'code', viewer_code, 'at', at) order by at desc), '[]'::jsonb)
       from (select * from trade_view_log where check_id = c.id order by at desc limit 30) v) end);
end $f$;

-- حدود الاستقطاع: يراها كل موظفي الوزارة، ويعدّلها مدير الجهة ومشغّل النظام
create or replace function public.trade_limits() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  me := _trade_reader();
  return jsonb_build_object(
    'can_edit', (me.portal = 'trade' and coalesce(me.manage_scope, '') = 'org') or me.portal = 'admin',
    'rows', (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'purpose', l.purpose, 'purpose_label', case when l.purpose is null then 'كل الأغراض' else _purpose_label(l.purpose) end,
        'bank_id', l.bank_id, 'bank', coalesce(o.name, 'كل المصارف'), 'pct', l.pct, 'note', l.note, 'by', l.updated_by_name, 'at', l.updated_at)
        order by (l.purpose is null and l.bank_id is null) desc, o.name nulls first, l.purpose nulls first), '[]'::jsonb)
      from trade_deduct_limits l left join orgs o on o.id = l.bank_id),
    'banks', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name) order by name), '[]'::jsonb) from orgs where type = 'bank'));
end $f$;

create or replace function public.trade_set_limit(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; v_pur text := nullif(p->>'purpose', ''); v_bank uuid := nullif(p->>'bank_id', '')::uuid; v_pct numeric := nullif(p->>'pct', '')::numeric;
  v_note text := nullif(left(trim(coalesce(p->>'note', '')), 300), ''); v_old numeric;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or not ((me.portal = 'trade' and coalesce(me.manage_scope, '') = 'org') or me.portal = 'admin') then
    raise exception 'تعديل حدود الاستقطاع من صلاحية مدير الجهة في الوزارة أو مشغّل النظام'; end if;
  if v_pur is not null and v_pur not in ('household', 'agricultural', 'industrial', 'project', 'vet', 'export', 'other') then raise exception 'غرض تمويل غير معروف'; end if;
  if v_bank is not null and not exists (select 1 from orgs where id = v_bank and type = 'bank') then raise exception 'المصرف غير موجود'; end if;
  if (p->>'delete')::boolean is true then
    if v_pur is null and v_bank is null then raise exception 'النسبة الافتراضية لا تُحذف — عدّلها'; end if;
    delete from trade_deduct_limits where coalesce(purpose, '') = coalesce(v_pur, '') and bank_id is not distinct from v_bank;
    perform _taudit('حذف حد استقطاع (وزارة التجارة)', case when v_pur is null then 'كل الأغراض' else _purpose_label(v_pur) end, jsonb_build_object('bank', (select name from orgs where id = v_bank)), me.org_id, null);
    return trade_limits();
  end if;
  if v_pct is null or v_pct < 5 or v_pct > 100 then raise exception 'النسبة بين 5 و100'; end if;
  select pct into v_old from trade_deduct_limits where coalesce(purpose, '') = coalesce(v_pur, '') and bank_id is not distinct from v_bank;
  insert into trade_deduct_limits(purpose, bank_id, pct, note, updated_by_name) values (v_pur, v_bank, v_pct, v_note, me.full_name)
  on conflict (coalesce(purpose, ''), coalesce(bank_id, '00000000-0000-0000-0000-000000000000'::uuid))
  do update set pct = excluded.pct, note = coalesce(excluded.note, trade_deduct_limits.note), updated_by_name = excluded.updated_by_name, updated_at = now();
  perform _taudit('حد استقطاع (وزارة التجارة)', case when v_pur is null then 'كل الأغراض' else _purpose_label(v_pur) end,
    jsonb_build_object('bank', coalesce((select name from orgs where id = v_bank), 'كل المصارف'), 'from', v_old, 'to', v_pct), me.org_id, null);
  return trade_limits();
end $f$;

-- المصرف والمقترض يريان أين وصلت المعاملة في الوزارة (دون بيانات الراتب)
create or replace function public.guarantee_status(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a.id is null or me is null or not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin', 'cbi', 'integrity', 'audit')) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('base', _guarantee_base(a), 'kind', a.guarantee_type, 'return_kind', a.return_kind,
    'gold_gram_21', _setting('gold_gram_21'), 'gold_ltv', _setting('gold_ltv'),
    'checks', (select coalesce(jsonb_agg(jsonb_build_object('code', c.code, 'g_index', c.g_index, 'name', c.guarantor_name, 'phone', c.guarantor_phone, 'dept', c.dept, 'status', c.status,
        'decided_at', c.decided_at, 'created_at', c.created_at, 'note', case when c.status = 'rejected' then c.note end,
        'wf_stage', c.wf_stage, 'wf_label', case when c.status = 'pending' then 'لدى: ' || _trade_stage_label(c.wf_stage) end,
        'reasons', (select coalesce(jsonb_agg(r.label order by r.sort), '[]'::jsonb) from rejection_reasons r where r.code = any(c.reasons))) order by c.created_at), '[]'::jsonb)
      from employer_checks c where c.application_id = a.id and c.status <> 'cancelled'));
end $f$;

-- ───────── 6) الصلاحيات ─────────
revoke all on function public._trade_stage_role(text), public._trade_limit(text, uuid), public._trade_notify_role(uuid, text, text, text, uuid),
  public._trade_actor(employer_checks, text), public._trade_move(employer_checks, text, text, text, profiles), public._trade_calc(uuid) from public, anon, authenticated;
revoke all on function public.trade_hr_submit(uuid, jsonb), public.trade_payroll_submit(uuid, jsonb), public.trade_guarantees_submit(uuid, jsonb),
  public.trade_admin_act(uuid, jsonb), public.trade_signer_act(uuid, jsonb), public.trade_check(uuid), public.trade_limits(), public.trade_set_limit(jsonb) from public, anon;
grant execute on function public.trade_hr_submit(uuid, jsonb), public.trade_payroll_submit(uuid, jsonb), public.trade_guarantees_submit(uuid, jsonb),
  public.trade_admin_act(uuid, jsonb), public.trade_signer_act(uuid, jsonb), public.trade_check(uuid), public.trade_limits(), public.trade_set_limit(jsonb) to authenticated;

-- ───────── 7) حسابات تجريبية لكل دور، وتابعة لمدير الجهة trade1 ─────────
do $$
declare r text[]; rows text[][] := array[
  ['trade.hr',   'Mot@2026hr', 'م. سعاد كاظم الحسيني',   'trade_hr',         'مسؤولة شعبة شؤون الموظفين — قسم الموارد البشرية'],
  ['trade.pay',  'Mot@2026py', 'أ. علي حميد الساعدي',     'trade_payroll',    'محاسب الرواتب — القسم المالي'],
  ['trade.grt',  'Mot@2026gr', 'أ. زينب فاضل العبيدي',    'trade_guarantees', 'مسؤولة وحدة الكفالات والالتزامات المالية'],
  ['trade.adm',  'Mot@2026ma', 'أ. مهدي صالح التميمي',    'trade_admin',      'معاون المدير العام للشؤون الإدارية'],
  ['trade.sign', 'Mot@2026sg', 'د. نزار عبد الأمير الياسري', 'trade_signer',    'المدير العام — صاحب الصلاحية بالتوقيع']];
  i int;
begin
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'trade', 'mot', null, null);
    end if;
    update public.profiles set position_title = coalesce(position_title, rows[i][5]),
      managed_by = coalesce(managed_by, (select id from public.profiles where username = 'trade1'))
    where username = rows[i][1];
  end loop;
end $$;

-- طلب تجريبي في صندوق الموارد البشرية: طلب ALW-2026-00036 (في الاستقبال، بلا كفلاء) يصبح بكفيلة من وزارة التجارة
update public.applications set guarantee = jsonb_build_object('type', 'multi_salary', 'guarantors', jsonb_build_array(jsonb_build_object(
    'name', 'سارة جاسم محمد الربيعي', 'phone', '07701234987', 'national_id', '199012345678', 'employer', 'وزارة التجارة — الشركة العامة لتجارة الحبوب',
    'ministry', 'trade', 'dept', 'الشركة العامة لتجارة الحبوب', 'salary', 1320000, 'relation', 'قريبة',
    'consent', true, 'consent_at', now(), 'consent_via', 'otp', 'id_source', 'manual'))),
  updated_at = now()
where code = 'ALW-2026-00036' and coalesce(jsonb_array_length(guarantee->'guarantors'), 0) = 0 and program = 'solar' and status in ('active', 'returned')
  and not exists (select 1 from public.employer_checks c where c.application_id = applications.id);
