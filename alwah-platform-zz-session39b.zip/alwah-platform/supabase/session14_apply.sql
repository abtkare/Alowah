-- الجلسة 14:
-- (أ) رهن العقار: موظف التسجيل العقاري يرفق إلزامياً صورة كتاب الرهن وصورة إشارة الحجز على السند مع رقم التأشير عند التأشير الإلكتروني
-- (ب) ضمان الراتب: مفاتحة المصرف الموطَّن لديه راتب كل كفيل لتأييد التوطين ثم تفعيل الاستقطاع المباشر (Direct Debit)

-- ───────── أنواع المستندات الجديدة ─────────
alter table app_documents drop constraint if exists app_documents_kind_check;
alter table app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site',
  'mortgage_letter','annotation_mark','dd_letter','dd_auth']));

-- ───────── (أ) الرهن: حقول التأشير ─────────
alter table mortgage_referrals add column if not exists letter_no text;
alter table mortgage_referrals add column if not exists letter_date date;
alter table mortgage_referrals add column if not exists letter_doc uuid references app_documents(id) on delete set null;
alter table mortgage_referrals add column if not exists mark_doc uuid references app_documents(id) on delete set null;

-- ───────── (ب) إحالات الاستقطاع المباشر ─────────
create table if not exists salary_referrals (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  application_id uuid not null references applications(id) on delete cascade,
  bank_id uuid not null references orgs(id),            -- المصرف المُقرض (المحيل)
  salary_bank_id uuid not null references orgs(id),     -- المصرف الموطَّن لديه راتب الكفيل
  g_index int not null default 0,
  guarantor_name text not null, guarantor_phone text, employer text not null, declared_salary bigint,
  salary_account text, net_salary bigint,
  installment bigint not null, term_months int, dd_mode text not null default 'on_default' check (dd_mode in ('on_default','monthly')),
  start_date date, mandate_no text,
  status text not null default 'pending' check (status in ('pending','confirmed','activated','rejected','cancelled')),
  letter_doc uuid, auth_doc uuid, evidence_doc uuid, reject_reason text, note text,
  created_by_title text, decided_by_title text, decided_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists salary_referrals_app on salary_referrals(application_id);
create index if not exists salary_referrals_sbank on salary_referrals(salary_bank_id, status);
alter table app_documents add column if not exists salary_referral_id uuid references salary_referrals(id) on delete set null;

alter table salary_referrals enable row level security;
drop policy if exists read_srefs on salary_referrals;
create policy read_srefs on salary_referrals for select using (
  (my_portal() = 'bank' and (bank_id = my_org() or salary_bank_id = my_org())) or my_portal() in ('cbi','integrity','admin'));
grant select on salary_referrals to authenticated;
revoke insert, update, delete on salary_referrals from authenticated, anon;

-- موظف المصرف الموطِّن يرى مستندات إحالته فقط (لا يرى الطلب نفسه)
drop policy if exists payroll_docs on app_documents;
create policy payroll_docs on app_documents for select using (
  salary_referral_id is not null and my_portal() = 'bank'
  and exists (select 1 from salary_referrals s where s.id = app_documents.salary_referral_id and s.salary_bank_id = my_org()));

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'salary_referrals') then
    alter publication supabase_realtime add table salary_referrals; end if;
end $$;

insert into rejection_reasons(code, label, ctx, sort) values
  ('dd_not_domiciled', 'راتب الكفيل غير موطَّن لدى هذا المصرف', 'payroll', 1),
  ('dd_account_mismatch', 'رقم الحساب أو اسم صاحبه لا يطابق بيانات الكفيل', 'payroll', 2),
  ('dd_salary_low', 'الراتب الصافي لا يغطي مبلغ الاستقطاع', 'payroll', 3),
  ('dd_deductions', 'استقطاعات قائمة تتجاوز الحد المسموح من الراتب', 'payroll', 4),
  ('dd_no_auth', 'الكفيل لم يوقّع نموذج تخويل الاستقطاع المباشر', 'payroll', 5),
  ('dd_status', 'الكفيل منقطع عن الخدمة أو منقول أو محال على التقاعد', 'payroll', 6),
  ('dd_other', 'سبب آخر (يُكتب تفصيلاً)', 'payroll', 99)
on conflict (code) do nothing;

-- ───────── الدور الجديد: موظف توطين الرواتب والاستقطاع المباشر ─────────
create or replace function public._org_roles(p_type text) returns text[] language sql immutable as $f$
  select case p_type
    when 'bank' then array['bank_cs','bank_compliance','bank_branch_mgr','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection',
                           'bank_legal','bank_md','bank_admin','bank_ops','bank_teller','bank_collection','bank_risk','bank_committee','bank_payroll']
    when 'cbi' then array['cbi_admin'] when 'supplier' then array['supplier_admin'] when 'syndicate' then array['syndicate_officer']
    when 'vetdept' then array['vetdept_officer'] when 'registry' then array['registry_officer'] when 'integrity' then array['integrity_viewer']
    else array[]::text[] end $f$;

create or replace function public._role_abbr(r text) returns text language sql immutable as $f$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'bank_payroll' then 'PR' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'platform_admin' then 'SA' else 'XX' end $f$;

create or replace function public._role_title(r text) returns text language sql immutable as $f$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'bank_payroll' then 'موظف توطين الرواتب — الاستقطاع المباشر'
    when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $f$;

-- ───────── (أ) رفع المستندات: التسجيل العقاري يرفق كتاب الرهن وإشارة الحجز ─────────
create or replace function public.add_document(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb, p_referral uuid default null)
 returns uuid language plpgsql security definer set search_path to 'public', 'extensions' as $function$
declare me profiles; a applications; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  if me.portal = 'citizen' then
    if a.citizen_id <> me.id then raise exception 'الطلب لا يخصك'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
    if p_kind not in ('deed','owner_id_front','owner_id_back','poa') and not (a.program = 'vet' and p_kind in ('quote','site')) then raise exception 'نوع مستند غير مسموح'; end if;
    if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
      raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
    delete from app_documents where application_id = a.id and kind = p_kind;
  elsif me.portal = 'registry' then
    if p_kind not in ('evidence','mortgage_letter','annotation_mark') or p_referral is null
       or not exists (select 1 from mortgage_referrals where id = p_referral and application_id = a.id) then raise exception 'المرفق دليل أو كتاب رهن أو إشارة حجز على إحالة رهن فقط'; end if;
    if p_kind <> 'evidence' then delete from app_documents where referral_id = p_referral and kind = p_kind; end if;
  elsif me.portal = 'bank' then
    if a.bank_id <> me.org_id or p_kind not in ('evidence','other') then raise exception 'غير مخوّل'; end if;
  else raise exception 'غير مخوّل'; end if;
  insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_referral, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()), me.id, _role_title(me.role))
  returning id into did;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || case p_kind when 'deed' then 'صورة سند العقار' when 'owner_id_front' then 'هوية مالك العقار (الوجه)'
    when 'poa' then 'وكالة مالك العقار بالرهن' when 'owner_id_back' then 'هوية مالك العقار (الظهر)' when 'evidence' then 'دليل قرار التسجيل العقاري'
    when 'mortgage_letter' then 'صورة كتاب الرهن' when 'annotation_mark' then 'صورة إشارة حجز العقار على السند'
    when 'quote' then 'عرض سعر المورد' when 'site' then 'صورة موقع المشروع' else 'مستند' end,
    case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $function$;

-- التأشير لا يتم إلا عبر registry_annotate (برقم التأشير وكتاب الرهن وصورة الإشارة)
create or replace function public.registry_action(p_ref uuid, p_action text, p_note text default null, p_reason text default null, p_evidence uuid default null)
 returns mortgage_referrals language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; r mortgage_referrals; p properties; act text; newst text; ast int; rr rejection_reasons;
begin
  select * into me from profiles where id=auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id=p_ref for update;
  select * into p from properties where id=r.property_id;
  select stage into ast from applications where id = r.application_id;
  if p_action='check' then
    if r.status <> 'pending' then raise exception 'تم الاستعلام مسبقاً'; end if;
    if p.status = 'free' then newst:='clear'; act:='استعلام الخلو: العقار خالٍ من الإشارات';
    else newst:='encumbered'; act:='استعلام الخلو: العقار عليه إشارة ('||p.status||')'; end if;
  elsif p_action='match' then
    if r.status <> 'clear' then raise exception 'المطابقة بعد تأكيد الخلو'; end if;
    newst:='matched'; act:='مطابقة السند وهوية المالك (الإجراء الأولي)';
  elsif p_action='annotate' then
    raise exception 'التأشير يتم من نموذج «تأشير الرهن» برقم التأشير مع إرفاق صورة كتاب الرهن وصورة إشارة الحجز';
  elsif p_action='release' then
    if r.status <> 'annotated' then raise exception 'الفك لرهن مؤشَّر فقط'; end if;
    newst:='released'; act:='فك الرهن بعد براءة الذمة';
    update properties set status='free' where id=p.id;
  elsif p_action='reject' then
    if r.status not in ('pending','clear','matched','encumbered') then raise exception 'لا يُرفض إلا إحالة قيد الإجراء'; end if;
    select * into rr from rejection_reasons where code = p_reason and ctx = 'registry';
    if rr is null then raise exception 'اختر سبب الرفض من القائمة'; end if;
    if p_reason = 'other' and length(trim(coalesce(p_note, ''))) < 10 then raise exception 'اكتب تفصيل السبب'; end if;
    if p_evidence is null or not exists (select 1 from app_documents where id = p_evidence and referral_id = r.id and kind = 'evidence') then
      raise exception 'أرفق ما يثبت سبب الرفض (صورة أو ملف من السجل)'; end if;
    newst:='rejected'; act:='رفض تأشير الرهن: ' || rr.label;
    update mortgage_referrals set reject_reason = rr.code, evidence_doc = p_evidence where id = r.id;
  else raise exception 'إجراء غير معروف'; end if;
  update mortgage_referrals set status=newst, note=coalesce(p_note,note), updated_at=now(), decided_at = now(),
    decided_by_title = _role_title(me.role) where id=r.id returning * into r;
  perform _ev(r.application_id, ast, act, p_note);
  return r;
end $function$;

create or replace function public.registry_annotate(p_ref uuid, p_data jsonb)
 returns mortgage_referrals language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; r mortgage_referrals; ast int; v_no text := trim(coalesce(p_data->>'annotation_no', '')); v_letter text := trim(coalesce(p_data->>'letter_no', ''));
  v_date date; d_letter uuid; d_mark uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me.portal <> 'registry' then raise exception 'غير مخوّل'; end if;
  select * into r from mortgage_referrals where id = p_ref for update;
  if r is null then raise exception 'الإحالة غير موجودة'; end if;
  if r.status <> 'matched' then raise exception 'التأشير بعد الخلو والمطابقة'; end if;
  select stage into ast from applications where id = r.application_id;
  if ast < 19 then raise exception 'التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)'; end if;
  if length(v_no) < 3 then raise exception 'اكتب رقم تأشير الرهن (إشارة الحجز) كما في السجل'; end if;
  if length(v_letter) < 1 then raise exception 'اكتب رقم كتاب الرهن'; end if;
  begin v_date := (p_data->>'letter_date')::date; exception when others then v_date := null; end;
  if v_date is null or v_date > current_date then raise exception 'اكتب تاريخ كتاب الرهن'; end if;
  select id into d_letter from app_documents where referral_id = r.id and kind = 'mortgage_letter' order by created_at desc limit 1;
  select id into d_mark from app_documents where referral_id = r.id and kind = 'annotation_mark' order by created_at desc limit 1;
  if d_letter is null then raise exception 'أرفق صورة كتاب الرهن'; end if;
  if d_mark is null then raise exception 'أرفق صورة إشارة حجز العقار على السند (صحيفة العقار)'; end if;
  update properties set status = 'mortgaged' where id = r.property_id;
  update mortgage_referrals set status = 'annotated', annotation_no = v_no, letter_no = v_letter, letter_date = v_date, letter_doc = d_letter, mark_doc = d_mark,
    note = coalesce(nullif(trim(p_data->>'note'), ''), note), updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role)
  where id = r.id returning * into r;
  perform _ev(r.application_id, ast, 'تأشير الرهن على السند (الإجراء النهائي) — إشارة ' || v_no,
    'كتاب الرهن ' || v_letter || ' في ' || to_char(v_date, 'YYYY/MM/DD') || ' · أُرفقت صورة الكتاب وصورة إشارة الحجز');
  return r;
end $function$;

create or replace function public.referral_dossier(p_ref uuid)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles; r mortgage_referrals; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from mortgage_referrals where id = p_ref;
  if r is null then raise exception 'غير موجودة'; end if;
  select * into a from applications where id = r.application_id;
  if not (me.portal in ('registry','cbi','integrity','admin') or (me.portal = 'bank' and me.org_id = a.bank_id)) then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('ownership', a.ownership, 'borrower', a.citizen_name, 'stage', a.stage,
    'docs', (select coalesce(jsonb_agg(jsonb_build_object('id', d.id, 'kind', d.kind, 'source', d.source, 'data', d.data, 'mime', d.mime, 'sha256', d.sha256,
      'created_at', d.created_at, 'by', d.uploaded_by_title) order by d.created_at), '[]') from app_documents d
      where d.application_id = a.id and (d.kind in ('deed','poa','owner_id_front','owner_id_back') or d.referral_id = r.id)),
    'reason', (select label from rejection_reasons where code = r.reject_reason));
end $function$;

-- ───────── (ب) ضمان الراتب: المفاتحة والإجراءات ─────────
create or replace function public._salary_required(a applications) returns int language sql stable as $f$
  select greatest(case a.guarantee_type when 'single_salary' then 1 when 'multi_salary' then 2 else 0 end,
                  coalesce(jsonb_array_length(a.guarantee->'guarantors'), 0)) $f$;

-- المصرف المُقرض يفاتح المصرف الموطِّن لراتب الكفيل (خدمة الزبائن في المرحلة 9 أو قسم المبادرات حتى المرحلة 19)
create or replace function public.refer_salary(p_app uuid, p_data jsonb)
 returns salary_referrals language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; s salary_referrals; sb orgs; gi int := coalesce((p_data->>'g_index')::int, 0); g jsonb; seq int; v_inst bigint;
  v_name text; v_emp text; v_sal bigint; v_phone text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_cs','bank_initiatives') then raise exception 'المفاتحة من خدمة الزبائن في الفرع أو إداري قسم المبادرات'; end if;
  if a.guarantee_type not in ('single_salary','multi_salary') then raise exception 'ضمان هذا الطلب ليس كفالة راتب'; end if;
  if a.status not in ('active','returned') or a.stage < 9 or a.stage > 19 then raise exception 'المفاتحة بين المرحلة 9 (الضمان الأولي) والمرحلة 19 (الضمان النهائي)'; end if;
  if gi < 0 or gi > 2 then raise exception 'رقم الكفيل غير صحيح'; end if;
  if exists (select 1 from salary_referrals where application_id = a.id and g_index = gi and status in ('pending','confirmed','activated')) then
    raise exception 'توجد مفاتحة قائمة لهذا الكفيل'; end if;
  select * into sb from orgs where id = (p_data->>'salary_bank_id')::uuid and type = 'bank';
  if sb is null then raise exception 'اختر المصرف الموطَّن لديه راتب الكفيل'; end if;
  g := a.guarantee->'guarantors'->gi;
  v_name := coalesce(nullif(trim(p_data->>'guarantor_name'), ''), g->>'name');
  v_emp := coalesce(nullif(trim(p_data->>'employer'), ''), g->>'employer');
  v_sal := coalesce(nullif(p_data->>'declared_salary', '')::bigint, (g->>'salary')::bigint);
  v_phone := coalesce(nullif(trim(p_data->>'guarantor_phone'), ''), g->>'phone');
  if length(coalesce(v_name, '')) < 6 then raise exception 'اكتب الاسم الثلاثي للكفيل'; end if;
  if coalesce(v_emp, '') = '' then raise exception 'اكتب جهة عمل الكفيل (دائرة التمويل)'; end if;
  if length(regexp_replace(coalesce(p_data->>'salary_account', ''), '\s', '', 'g')) < 6 then raise exception 'اكتب رقم حساب راتب الكفيل (أو IBAN)'; end if;
  v_inst := coalesce(a.monthly_installment, _installment(a.amount, _setting('cbi_rate') + _setting('margin_max'), coalesce(a.term_months, 60)));
  perform pg_advisory_xact_lock(hashtext('salary_referrals_code'));
  select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from salary_referrals where split_part(code, '-', 2) = to_char(now(), 'YYYY');
  insert into salary_referrals(code, application_id, bank_id, salary_bank_id, g_index, guarantor_name, guarantor_phone, employer, declared_salary,
    salary_account, installment, term_months, dd_mode, note, created_by_title)
  values ('DD-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 5, '0'), a.id, a.bank_id, sb.id, gi, v_name, v_phone, v_emp, v_sal,
    regexp_replace(p_data->>'salary_account', '\s', '', 'g'), v_inst, a.term_months,
    case when p_data->>'dd_mode' = 'monthly' then 'monthly' else 'on_default' end, nullif(trim(p_data->>'note'), ''), _role_title(me.role))
  returning * into s;
  perform _ev(a.id, a.stage, 'مفاتحة ' || sb.name || ' (المصرف الموطَّن لراتب الكفيل ' || v_name || ') لتفعيل الاستقطاع المباشر — ' || s.code,
    'مبلغ الاستقطاع ' || to_char(v_inst, 'FM999,999,999') || ' د.ع شهرياً · ' || case s.dd_mode when 'monthly' then 'استقطاع القسط شهرياً' else 'يُستقطع عند تخلّف المقترض عن السداد' end);
  return s;
end $function$;

create or replace function public.cancel_salary_referral(p_ref uuid, p_note text)
 returns salary_referrals language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; s salary_referrals; ast int;
begin
  select * into me from profiles where id = auth.uid();
  select * into s from salary_referrals where id = p_ref for update;
  if s is null or me.portal <> 'bank' or s.bank_id <> me.org_id or me.role not in ('bank_cs','bank_initiatives') then raise exception 'غير مخوّل'; end if;
  if s.status not in ('pending','confirmed') then raise exception 'لا تُلغى إلا مفاتحة قيد الإجراء'; end if;
  if length(trim(coalesce(p_note, ''))) < 5 then raise exception 'اكتب سبب الإلغاء'; end if;
  update salary_referrals set status = 'cancelled', note = p_note, updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role) where id = s.id returning * into s;
  select stage into ast from applications where id = s.application_id;
  perform _ev(s.application_id, ast, 'إلغاء مفاتحة الاستقطاع المباشر ' || s.code, p_note);
  return s;
end $function$;

-- مرفقات موظف المصرف الموطِّن: كتاب التفعيل، نموذج التخويل الموقّع، أو دليل الرفض
create or replace function public.payroll_add_doc(p_ref uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb)
 returns uuid language plpgsql security definer set search_path to 'public', 'extensions' as $function$
declare me profiles; s salary_referrals; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into s from salary_referrals where id = p_ref;
  if s is null or me.role <> 'bank_payroll' or s.salary_bank_id <> me.org_id then raise exception 'غير مخوّل'; end if;
  if p_kind not in ('dd_letter','dd_auth','evidence') then raise exception 'نوع مستند غير مسموح'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  if p_kind <> 'evidence' then delete from app_documents where salary_referral_id = s.id and kind = p_kind; end if;
  insert into app_documents(application_id, salary_referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (s.application_id, s.id, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now()), me.id, _role_title(me.role) || ' — ' || (select name from orgs where id = me.org_id))
  returning id into did;
  return did;
end $function$;

-- إجراءات المصرف الموطِّن: تأييد التوطين ← تفعيل الاستقطاع المباشر، أو الرفض المسبب
create or replace function public.payroll_action(p_ref uuid, p_action text, p_data jsonb default '{}'::jsonb)
 returns salary_referrals language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; s salary_referrals; ast int; rr rejection_reasons; v_net bigint; v_start date; v_no text; d1 uuid; d2 uuid; ev uuid; bname text;
begin
  select * into me from profiles where id = auth.uid();
  select * into s from salary_referrals where id = p_ref for update;
  if s is null then raise exception 'المفاتحة غير موجودة'; end if;
  if me.role <> 'bank_payroll' or s.salary_bank_id <> me.org_id then raise exception 'المفاتحة من صلاحية موظف توطين الرواتب في المصرف الموطَّن'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  select stage into ast from applications where id = s.application_id;
  bname := (select name from orgs where id = me.org_id);
  if p_action = 'confirm' then
    if s.status <> 'pending' then raise exception 'التأييد لمفاتحة جديدة فقط'; end if;
    v_net := nullif(p_data->>'net_salary', '')::bigint;
    if v_net is null or v_net < 250000 then raise exception 'اكتب الراتب الصافي الموطَّن'; end if;
    if v_net < s.installment then raise exception 'الراتب الصافي أقل من مبلغ الاستقطاع — ارفض المفاتحة مسبباً'; end if;
    update salary_referrals set status = 'confirmed', net_salary = v_net, note = coalesce(nullif(trim(p_data->>'note'), ''), note),
      updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role) where id = s.id returning * into s;
    perform _ev(s.application_id, ast, 'تأييد ' || bname || ': راتب الكفيل ' || s.guarantor_name || ' موطَّن لديه (' || s.code || ')',
      'الراتب الصافي ' || to_char(v_net, 'FM999,999,999') || ' د.ع · الحساب ' || s.salary_account);
  elsif p_action = 'activate' then
    if s.status <> 'confirmed' then raise exception 'التفعيل بعد تأييد توطين الراتب'; end if;
    if ast < 19 then raise exception 'يُفعَّل الاستقطاع المباشر بعد موافقة الإدارة العليا للمصرف المُقرض (المرحلة 19) — الطلب الآن في المرحلة %', ast; end if;
    v_no := trim(coalesce(p_data->>'mandate_no', ''));
    if length(v_no) < 3 then raise exception 'اكتب رقم تخويل الاستقطاع المباشر'; end if;
    begin v_start := (p_data->>'start_date')::date; exception when others then v_start := null; end;
    if v_start is null then raise exception 'حدد تاريخ بدء الاستقطاع'; end if;
    select id into d1 from app_documents where salary_referral_id = s.id and kind = 'dd_auth' order by created_at desc limit 1;
    select id into d2 from app_documents where salary_referral_id = s.id and kind = 'dd_letter' order by created_at desc limit 1;
    if d1 is null then raise exception 'أرفق نموذج تخويل الاستقطاع الموقّع من الكفيل'; end if;
    if d2 is null then raise exception 'أرفق كتاب تفعيل الاستقطاع المباشر الصادر من المصرف'; end if;
    update salary_referrals set status = 'activated', mandate_no = v_no, start_date = v_start, auth_doc = d1, letter_doc = d2,
      note = coalesce(nullif(trim(p_data->>'note'), ''), note), updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role)
    where id = s.id returning * into s;
    perform _ev(s.application_id, ast, 'تفعيل الاستقطاع المباشر على راتب الكفيل ' || s.guarantor_name || ' — تخويل ' || v_no,
      bname || ' · ' || to_char(s.installment, 'FM999,999,999') || ' د.ع · يبدأ ' || to_char(v_start, 'YYYY/MM/DD') || ' · أُرفق نموذج التخويل وكتاب التفعيل');
  elsif p_action = 'reject' then
    if s.status not in ('pending','confirmed') then raise exception 'لا تُرفض إلا مفاتحة قيد الإجراء'; end if;
    select * into rr from rejection_reasons where code = p_data->>'reason' and ctx = 'payroll';
    if rr is null then raise exception 'اختر سبب الرفض من القائمة'; end if;
    if rr.code = 'dd_other' and length(trim(coalesce(p_data->>'note', ''))) < 10 then raise exception 'اكتب تفصيل السبب'; end if;
    ev := nullif(p_data->>'evidence', '')::uuid;
    if ev is null or not exists (select 1 from app_documents where id = ev and salary_referral_id = s.id and kind = 'evidence') then raise exception 'أرفق ما يثبت سبب الرفض'; end if;
    update salary_referrals set status = 'rejected', reject_reason = rr.code, evidence_doc = ev, note = nullif(trim(p_data->>'note'), ''),
      updated_at = now(), decided_at = now(), decided_by_title = _role_title(me.role) where id = s.id returning * into s;
    perform _ev(s.application_id, ast, 'رفض ' || bname || ' تفعيل الاستقطاع على راتب الكفيل ' || s.guarantor_name || ': ' || rr.label, p_data->>'note');
  else raise exception 'إجراء غير معروف'; end if;
  return s;
end $function$;

-- ───────── شروط المرحلتين 9 و19 لكل أنواع الضمان ─────────
create or replace function public.advance_application(p_app uuid, p_action text, p_note text default null)
 returns applications language plpgsql security definer set search_path to 'public' as $function$
declare a applications; me profiles; st stages; ref mortgage_referrals; act text; lim int; need int; got int;
begin
  select * into me from profiles where id = auth.uid();
  if me is null then raise exception 'غير مسجل الدخول'; end if;
  select * into a from applications where id = p_app for update;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if a.status not in ('active','returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  select * into st from stages where n = a.stage;

  if st.owner_role = 'citizen' then
    if a.citizen_id is distinct from me.id then raise exception 'هذه المرحلة لصاحب الطلب'; end if;
  else
    if me.role <> st.owner_role then raise exception 'هذه المرحلة من صلاحية: %', st.owner_label; end if;
    if me.portal = 'bank' and a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
    if me.portal = 'supplier' and a.supplier_id is distinct from me.org_id then raise exception 'الطلب لا يخص شركتك'; end if;
    if st.branch_level and me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
    if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
    if not _assignment_ok(a, me) then raise exception 'هذه المعاملة مسندة إلى % — يستلمها البديل عند غيابه فقط', _assignee_name(a); end if;
  end if;
  if p_action in ('reject','return') and coalesce(trim(p_note), '') = '' then raise exception 'اكتب السبب'; end if;

  if p_action = 'reject' then
    if a.cbi_approved_at is not null and a.stage < 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0) where bank_id = a.bank_id;
    end if;
    update applications set status='rejected', updated_at=now() where id=a.id returning * into a; act := 'رفض مسبب';
  elsif p_action = 'return' then
    update applications set status='returned', updated_at=now() where id=a.id returning * into a; act := 'إعادة للاستكمال';
  elsif p_action = 'advance' then
    if st.batch_only then raise exception 'هذه المرحلة تُنجز عبر السلفة التجميعية لا للطلب منفرداً'; end if;
    if me.portal = 'bank' and st.confirm_text is not null and coalesce(current_setting('alwah.confirmed', true), '') <> '1' then raise exception 'اكتب تأكيد الإنجاز أولاً (مثل: %)', st.confirm_text; end if;
    if a.stage = 9 and a.guarantee_type = 'mortgage' then
      select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
      if ref is null or ref.status not in ('clear','matched','annotated') then raise exception 'الإجراء الأولي للرهن: يلزم تأكيد خلو العقار ومطابقة السند من التسجيل العقاري'; end if;
    end if;
    if a.stage in (9, 19) and a.guarantee_type in ('single_salary','multi_salary') then
      need := _salary_required(a);
      select count(*) into got from salary_referrals where application_id = a.id
        and status = any(case when a.stage = 9 then array['confirmed','activated'] else array['activated'] end);
      if got < need then
        if a.stage = 9 then raise exception 'الإجراء الأولي لكفالة الراتب: فاتح المصرف الموطَّن لراتب كل كفيل وانتظر تأييده (% من %)', got, need;
        else raise exception 'الإجراء النهائي لكفالة الراتب: يلزم تفعيل الاستقطاع المباشر على راتب كل كفيل من مصرفه الموطَّن (% من %)', got, need; end if;
      end if;
    end if;
    if a.stage = 14 and a.fees_paid_at is null then raise exception 'أجور الكشف تُستوفى قبل إجراء الكشف (المرحلة 10)'; end if;
    if a.stage = 19 then
      lim := _setting('initial_validity_days')::int;
      if a.initial_approved_at is not null and now() - a.initial_approved_at > make_interval(days => lim) then
        raise exception 'مضت % يوماً على الموافقة المبدئية دون إكمال الضمانات — الموافقة لاغية حسب السياسة، ارفض الطلب مسبباً', lim; end if;
      if a.guarantee_type = 'mortgage' then
        select * into ref from mortgage_referrals where application_id=a.id order by created_at desc limit 1;
        if ref is null or ref.status <> 'annotated' then raise exception 'الإجراء النهائي للرهن: يلزم تأشير الرهن على السند'; end if;
        if ref.letter_doc is null or ref.mark_doc is null then raise exception 'الإجراء النهائي للرهن: لم يرفق التسجيل العقاري صورة كتاب الرهن وصورة إشارة الحجز'; end if;
      end if;
    end if;

    if a.stage = 8 then update applications set initial_approved_at = now() where id = a.id; end if;
    if a.stage = 10 then update applications set fees_paid_at = now() where id = a.id; end if;
    if a.stage = 32 then update applications set inspection_result = 'مطابق' where id = a.id; end if;
    if a.stage = 35 then
      update bank_allocations set reserved = greatest(reserved - a.amount, 0), disbursed = disbursed + a.amount where bank_id = a.bank_id;
    end if;

    if a.stage = 37 then
      update applications set status='completed', updated_at=now() where id=a.id returning * into a;
      act := 'حفظ العقود وإغلاق الملف — اكتمال الطلب';
    else
      update applications set stage = a.stage + 1, status='active', updated_at=now(), bank_unit=(select owner_label from stages where n = a.stage + 1)
      where id=a.id returning * into a;
      act := 'إنجاز: ' || st.name;
    end if;
  else raise exception 'إجراء غير معروف'; end if;
  perform _ev(a.id, st.n, act, p_note);
  return a;
end $function$;

-- الرهون المؤشَّرة سابقاً دون مرفقات تبقى سارية (أُنجزت قبل هذا التعديل)؛ يُطلب الإرفاق من الآن فقط
update mortgage_referrals set letter_no = coalesce(letter_no, 'سابق للتعديل') where status = 'annotated' and letter_doc is null;
-- لا يُوقف شرط المرحلة 19 الرهون السابقة: نعدّها مستوفاة بربطها بدليل «نموذج عرض»
insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by_title)
select m.application_id, m.id, k.kind, 'demo', 'image/png', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 0, null,
  '{"legacy":true}'::jsonb, 'موظف التسجيل العقاري (قبل تعديل الجلسة 14)'
from mortgage_referrals m cross join (values ('mortgage_letter'), ('annotation_mark')) k(kind)
where m.status = 'annotated' and not exists (select 1 from app_documents d where d.referral_id = m.id and d.kind = k.kind);
update mortgage_referrals m set letter_doc = (select id from app_documents where referral_id = m.id and kind = 'mortgage_letter' order by created_at desc limit 1),
  mark_doc = (select id from app_documents where referral_id = m.id and kind = 'annotation_mark' order by created_at desc limit 1)
where status = 'annotated' and (letter_doc is null or mark_doc is null);

revoke all on function public.refer_salary(uuid, jsonb), public.cancel_salary_referral(uuid, text), public.payroll_add_doc(uuid, text, text, text, jsonb),
  public.payroll_action(uuid, text, jsonb), public.registry_annotate(uuid, jsonb) from public, anon;
grant execute on function public.refer_salary(uuid, jsonb), public.cancel_salary_referral(uuid, text), public.payroll_add_doc(uuid, text, text, text, jsonb),
  public.payroll_action(uuid, text, jsonb), public.registry_annotate(uuid, jsonb) to authenticated;

-- صندوق موظف المصرف الموطِّن: المفاتحات الواردة مع رقم الطلب واسم المقترض ومرحلته فقط (لا يرى بقية الطلب)
create or replace function public.payroll_inbox()
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.role is distinct from 'bank_payroll' then raise exception 'غير مخوّل'; end if;
  return (select coalesce(jsonb_agg(to_jsonb(s) || jsonb_build_object('app_code', a.code, 'borrower', a.citizen_name, 'app_stage', a.stage, 'app_status', a.status,
      'bank_name', o.name, 'term_months', a.term_months) order by s.created_at desc), '[]')
    from salary_referrals s join applications a on a.id = s.application_id join orgs o on o.id = s.bank_id where s.salary_bank_id = me.org_id);
end $function$;
revoke all on function public.payroll_inbox() from public, anon;
grant execute on function public.payroll_inbox() to authenticated;

-- ───────── حسابات موظفي توطين الرواتب في المصارف الثلاثة ─────────
do $$ declare r record; uid uuid; begin
  for r in select * from (values ('snb.payroll', 'Snb@2026pr', 'bank1', 'مصرف السنابل'), ('wah.payroll', 'Wah@2026pr', 'bank2', 'مصرف الواحة'), ('djl.payroll', 'Djl@2026pr', 'bank3', 'مصرف دجلة')) v(u, pw, org, bn) loop
    if not exists (select 1 from profiles where username = r.u) then
      uid := _mk_user(r.u, r.pw, 'موظف توطين الرواتب — ' || r.bn, 'bank_payroll', 'bank', r.org, null, null);
      update profiles set position_title = 'موظف توطين الرواتب — الاستقطاع المباشر', must_change_password = false where id = uid;
    end if;
  end loop;
end $$;
