-- الجلسة 13: رقم السلفة التجميعية فريد على مستوى المنصة (أعلى رقم في السنة + 1) مع قفل لمنع التزامن
CREATE OR REPLACE FUNCTION public.batch_create(p_apps uuid[], p_note text DEFAULT NULL::text)
 RETURNS cbi_batches
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare me profiles; b cbi_batches; tot bigint; cnt int; bad int; seq int; pfx text; yr text;
begin
  select * into me from profiles where id = auth.uid();
  if me.role <> 'bank_initiatives' then raise exception 'التجميع من إداري قسم المبادرات'; end if;
  if coalesce(array_length(p_apps, 1), 0) = 0 then raise exception 'اختر طلباً واحداً على الأقل'; end if;
  select count(*) filter (where stage <> 20 or status <> 'active' or bank_id is distinct from me.org_id), count(*), coalesce(sum(amount), 0)
    into bad, cnt, tot from applications where id = any(p_apps);
  if cnt <> array_length(p_apps, 1) or bad > 0 then raise exception 'كل الطلبات يجب أن تكون في مرحلة التجميع ولمصرفك'; end if;
  if tot > _setting('batch_cap') then raise exception 'مجموع السلفة % يتجاوز السقف % دينار', to_char(tot, 'FM999,999,999,999'), to_char(_setting('batch_cap'), 'FM999,999,999,999'); end if;
  perform pg_advisory_xact_lock(hashtext('cbi_batches_code'));
  pfx := coalesce((select split_part(code, '-', 1) from branches where bank_id = me.org_id order by is_main desc limit 1), 'BNK');
  yr := to_char(now(), 'YYYY');
  select coalesce(max(split_part(code, '-', 4)::int), 0) + 1 into seq
    from cbi_batches where split_part(code, '-', 3) = yr and split_part(code, '-', 4) ~ '^[0-9]+$';
  insert into cbi_batches(code, bank_id, total, apps_count, created_by, created_by_name)
  values (pfx || '-ST-' || yr || '-' || lpad(seq::text, 3, '0'), me.org_id, tot, cnt, me.id, me.full_name)
  returning * into b;
  update applications set batch_id = b.id, stage = 21, updated_at = now(), bank_unit = (select owner_label from stages where n = 21) where id = any(p_apps);
  perform _ev(x, 20, 'إضافة إلى السلفة التجميعية ' || b.code, p_note) from unnest(p_apps) x;
  return b;
end $function$;
