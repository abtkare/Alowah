-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 39: الهيئة الشرعية للتمويل الإسلامي (/sharia) — الحزمة 1
--  • قرارات المستخدم: هيئة مركزية واحدة الآن (وهيئة في كل مصرف لاحقاً)، تعتمد المنتجات والعقود فقط،
--    كل الصيغ على المذهب الجعفري، والمقترض يرى عقد كل منتج إسلامي ويختار منها.
--  • كل شيء مربوط بـ board_id حتى يصير الانتقال لهيئة في كل مصرف إعداداً لا إعادة برمجة.
--  • الدورة: المصرف (bank_islamic_products) يقدّم المنتج وعقده ← أمين السر يتحقق ويحيل أو يعيد ←
--    مداولة على بنود العقد ونسخ معدّلة ← تصويت ← قرار الرئيس برقم SH-… وبصمة SHA-256 ← المنتج يظهر للمقترض.
--  • المقترض يرى المنتجات المعتمدة بطاقات و«اقرأ العقد» مملوءاً ببياناته، ويُحفظ المنتج ونسخة العقد وبصمتها في طلبه.
-- التحليل: docs/تحليل-الهيئة-الشرعية.md. الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة والأدوار ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit','planning','finance','trade','eng_audit','sharia']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit','planning','finance','trade','auditor','sharia']));

do $$
declare f regprocedure; d text; pairs text[][] := array[
  ['public._role_abbr(text)', 'when ''auditor_engineer'' then ''EN''',
   'when ''auditor_engineer'' then ''EN'' when ''sharia_head'' then ''SH'' when ''sharia_member'' then ''SM'' when ''sharia_secretary'' then ''SS'' when ''bank_islamic_products'' then ''IP'''],
  ['public._role_title(text)', 'when ''auditor_engineer'' then ''مهندس فاحص — شركة التدقيق الهندسي''',
   'when ''auditor_engineer'' then ''مهندس فاحص — شركة التدقيق الهندسي'' when ''sharia_head'' then ''رئيس الهيئة الشرعية'' when ''sharia_member'' then ''عضو الهيئة الشرعية'' when ''sharia_secretary'' then ''أمين سر الهيئة الشرعية'' when ''bank_islamic_products'' then ''مسؤول المنتجات الإسلامية'''],
  ['public._portal_of_role(text)', 'when r in (''auditor_admin'', ''auditor_engineer'') then ''auditor''',
   'when r in (''auditor_admin'', ''auditor_engineer'') then ''auditor'' when r in (''sharia_head'', ''sharia_member'', ''sharia_secretary'') then ''sharia'''],
  ['public._org_type_of_portal(text)', 'when ''auditor'' then ''eng_audit''',
   'when ''auditor'' then ''eng_audit'' when ''sharia'' then ''sharia'''],
  ['public._org_roles(text)', 'when ''eng_audit'' then array[''auditor_engineer'', ''auditor_admin'']',
   'when ''eng_audit'' then array[''auditor_engineer'', ''auditor_admin''] when ''sharia'' then array[''sharia_member'', ''sharia_secretary'', ''sharia_head'']']];
  i int;
begin
  for i in 1 .. array_length(pairs, 1) loop
    f := pairs[i][1]::regprocedure; d := pg_get_functiondef(f);
    if position('sharia' in d) = 0 then
      if position(pairs[i][2] in d) = 0 then raise exception 'الجلسة 39: لم يُعثر على موضع الإضافة في %', f; end if;
      execute replace(d, pairs[i][2], pairs[i][3]);
    end if;
  end loop;
  -- مسؤول المنتجات الإسلامية ضمن أدوار المصرف («فريقي» لمدير المصرف)
  d := pg_get_functiondef('public._org_roles(text)'::regprocedure);
  if position('bank_islamic_products' in d) = 0 then
    if position('''bank_payroll'']' in d) = 0 then raise exception 'الجلسة 39: لم يُعثر على قائمة أدوار المصرف في _org_roles'; end if;
    execute replace(d, '''bank_payroll'']', '''bank_payroll'',''bank_islamic_products'']');
  end if;
  -- شاشة الدخول: الهيئة ضمن الجهات الحكومية (بعد وزارة التجارة)
  d := pg_get_functiondef('public.public_brand(text)'::regprocedure);
  if position('''sharia''' in d) = 0 then
    if position('''finance'',''trade'')' in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في public_brand'; end if;
    execute replace(d, '''finance'',''trade'')', '''finance'',''trade'',''sharia'')');
  end if;
end $$;

-- ───────── 2) الجداول ─────────
create table if not exists public.sharia_boards (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  scope text not null default 'central' check (scope in ('central', 'bank')),
  org_id uuid references public.orgs(id),        -- جهة الهيئة (بوابة /sharia)
  bank_id uuid references public.orgs(id),       -- المرحلة الثانية: هيئة المصرف
  madhhab text not null default 'jafari',
  marja text,                                    -- المرجع الذي تُعتمد فتاواه
  quorum int not null default 3,
  majority text not null default 'simple' check (majority in ('simple', 'two_thirds')),
  chair_casting boolean not null default true,   -- صوت الرئيس مرجّح عند التساوي
  review_months int not null default 12,
  late_rule text,                                -- معالجة التأخر في السداد كما تقررها الهيئة
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sharia_members (
  board_id uuid not null references public.sharia_boards(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('head', 'member', 'secretary')),
  specialty text,
  appointed_at date default current_date,
  active boolean not null default true,
  primary key (board_id, profile_id)
);

create table if not exists public.sharia_contract_types (
  code text primary key,
  name text not null,
  essence text not null,
  borrower_line text not null,
  sectors text[] not null default '{}',
  rules jsonb not null default '{}'::jsonb,       -- {conditions:[], guards:[], summary:{own,when,pay,late,damage}}
  allowed boolean not null default true,
  sort int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.islamic_products (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                     -- IP-2026-0001
  bank_id uuid not null references public.orgs(id),
  board_id uuid not null references public.sharia_boards(id),
  contract_type text not null references public.sharia_contract_types(code),
  name text not null,
  sector text not null check (sector in ('pv', 'vet', 'exim')),
  subsector text,                                -- individuals | agri | industry | clinic | production | importer | exporter
  line text,                                     -- سطر واحد يشرح الصيغة للمقترض
  pricing jsonb not null default '{}'::jsonb,    -- {profit_min, profit_max, term_min, term_max}
  guarantees text[] not null default '{}',
  attachments text[] not null default '{}',
  status text not null default 'draft' check (status in ('draft', 'submitted', 'returned', 'deliberation', 'approved', 'conditional', 'rejected', 'suspended', 'withdrawn')),
  status_note text,
  current_version_id uuid,
  approved_version_id uuid,
  resolution_id uuid,
  review_due date,
  submitted_at timestamptz,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists islamic_products_bank on public.islamic_products(bank_id, status);

create table if not exists public.islamic_contract_versions (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.islamic_products(id) on delete cascade,
  n int not null,
  clauses jsonb not null default '[]'::jsonb,    -- [{n, title, text}] — المتغيرات بين {{…}}
  sha256 text,
  status text not null default 'draft' check (status in ('draft', 'submitted', 'superseded', 'approved', 'rejected', 'returned')),
  change_note text,
  created_by_name text,
  created_at timestamptz not null default now(),
  unique (product_id, n)
);

create table if not exists public.sharia_reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.islamic_products(id) on delete cascade,
  version_id uuid not null references public.islamic_contract_versions(id) on delete cascade,
  clause_n int,                                  -- null = ملاحظة عامة على المنتج
  parent_id uuid references public.sharia_reviews(id) on delete cascade,
  author_id uuid,
  author_name text,
  author_side text not null default 'board' check (author_side in ('board', 'bank')),
  body text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists sharia_reviews_prod on public.sharia_reviews(product_id, created_at);

create table if not exists public.sharia_votes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.islamic_products(id) on delete cascade,
  version_id uuid not null references public.islamic_contract_versions(id) on delete cascade,
  member_id uuid not null references public.profiles(id),
  member_name text,
  is_head boolean not null default false,
  vote text not null check (vote in ('approve', 'approve_cond', 'reject')),
  condition text,
  reason text,
  at timestamptz not null default now(),
  unique (version_id, member_id)
);

create table if not exists public.sharia_resolutions (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                     -- SH-2026-00001
  board_id uuid not null references public.sharia_boards(id),
  product_id uuid not null references public.islamic_products(id) on delete cascade,
  version_id uuid references public.islamic_contract_versions(id),
  decision text not null check (decision in ('approved', 'conditional', 'returned', 'rejected', 'suspended', 'reinstated', 'withdrawn')),
  body text,
  conditions text,
  votes jsonb,                                   -- {approve, approve_cond, reject, cast, members, quorum}
  dissent jsonb,                                 -- [{name, vote, reason}]
  version_sha256 text,
  seal text,
  signed_by uuid,
  signed_by_name text,
  signed_by_code text,
  signed_via text,
  issued_at timestamptz not null default now()
);
create index if not exists sharia_resolutions_prod on public.sharia_resolutions(product_id, issued_at desc);

create table if not exists public.sharia_log (
  id bigserial primary key,
  product_id uuid not null references public.islamic_products(id) on delete cascade,
  at timestamptz not null default now(),
  actor_name text,
  actor_code text,
  actor_side text,
  action text not null,
  note text
);
create index if not exists sharia_log_prod on public.sharia_log(product_id, at);

-- المنتج والعقد في طلب التمويل
alter table public.applications add column if not exists product_id uuid;
alter table public.applications add column if not exists contract_version_id uuid;
alter table public.applications add column if not exists contract_sha256 text;
alter table public.applications add column if not exists sharia_resolution text;

-- ───────── 3) الصلاحيات على الجداول (القراءة عبر الدوال؛ الكتابة عبر الدوال فقط) ─────────
alter table public.sharia_boards enable row level security;
alter table public.sharia_members enable row level security;
alter table public.sharia_contract_types enable row level security;
alter table public.islamic_products enable row level security;
alter table public.islamic_contract_versions enable row level security;
alter table public.sharia_reviews enable row level security;
alter table public.sharia_votes enable row level security;
alter table public.sharia_resolutions enable row level security;
alter table public.sharia_log enable row level security;

drop policy if exists read_sh_types on public.sharia_contract_types;
create policy read_sh_types on public.sharia_contract_types for select using (true);
drop policy if exists read_isl_products on public.islamic_products;
create policy read_isl_products on public.islamic_products for select using (
  my_portal() in ('sharia', 'cbi', 'integrity', 'audit', 'admin') or (my_portal() = 'bank' and bank_id = my_org()));
drop policy if exists read_sh_votes on public.sharia_votes;
create policy read_sh_votes on public.sharia_votes for select using (my_portal() = 'sharia');
drop policy if exists read_sh_reviews on public.sharia_reviews;
create policy read_sh_reviews on public.sharia_reviews for select using (
  my_portal() = 'sharia' or exists (select 1 from islamic_products p where p.id = product_id and my_portal() = 'bank' and p.bank_id = my_org()));
revoke insert, update, delete on public.sharia_boards, public.sharia_members, public.sharia_contract_types, public.islamic_products, public.islamic_contract_versions,
  public.sharia_reviews, public.sharia_votes, public.sharia_resolutions, public.sharia_log from anon, authenticated;
revoke select on public.sharia_boards, public.sharia_members, public.islamic_contract_versions, public.sharia_resolutions, public.sharia_log from anon, authenticated;
grant select on public.sharia_contract_types, public.islamic_products, public.sharia_votes, public.sharia_reviews to authenticated;

do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'islamic_products') then
      alter publication supabase_realtime add table public.islamic_products; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'sharia_votes') then
      alter publication supabase_realtime add table public.sharia_votes; end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'sharia_reviews') then
      alter publication supabase_realtime add table public.sharia_reviews; end if;
  end if;
end $$;

-- ───────── 4) أدوات ─────────
create or replace function public._sh_status_label(s text) returns text language sql immutable as $f$
  select case s when 'draft' then 'مسودة لدى المصرف' when 'submitted' then 'لدى أمين السر — التحقق من الاكتمال' when 'returned' then 'معاد للمصرف للتعديل'
    when 'deliberation' then 'قيد المداولة والتصويت' when 'approved' then 'معتمد شرعاً' when 'conditional' then 'معتمد بشرط'
    when 'rejected' then 'مرفوض' when 'suspended' then 'معلّق مؤقتاً' when 'withdrawn' then 'مسحوب الاعتماد' else s end $f$;
create or replace function public._sh_decision_label(s text) returns text language sql immutable as $f$
  select case s when 'approved' then 'اعتماد' when 'conditional' then 'اعتماد مشروط' when 'returned' then 'إعادة للتعديل' when 'rejected' then 'رفض'
    when 'suspended' then 'تعليق مؤقت' when 'reinstated' then 'رفع التعليق' when 'withdrawn' then 'سحب الاعتماد' else s end $f$;
create or replace function public._sh_sector_label(s text, sub text) returns text language sql immutable as $f$
  select case s when 'pv' then 'الطاقة الشمسية' when 'vet' then 'الأطباء البيطريون' when 'exim' then 'التصدير والاستيراد' else s end
    || coalesce(' — ' || case sub when 'individuals' then 'الأفراد' when 'agri' then 'الزراعة' when 'industry' then 'الصناعة' when 'clinic' then 'عيادة ومختبر'
      when 'production' then 'خط إنتاج' when 'importer' then 'المستورد' when 'exporter' then 'المصدّر' else sub end, '') $f$;
create or replace function public._sh_madhhab_label(s text) returns text language sql immutable as $f$
  select case s when 'jafari' then 'المذهب الجعفري' else s end $f$;
create or replace function public._sh_fmt(n numeric) returns text language sql immutable as $f$ select to_char(round(coalesce(n, 0)), 'FM999,999,999,999') $f$;

-- بصمة نص العقد: البنود مرتبة بأرقامها
create or replace function public._sh_sha(p_clauses jsonb) returns text
language sql immutable set search_path to 'public', 'extensions' as $f$
  select encode(extensions.digest(coalesce((select string_agg((c->>'n') || '|' || coalesce(c->>'title', '') || '|' || coalesce(c->>'text', ''), E'\n' order by (c->>'n')::int)
    from jsonb_array_elements(coalesce(p_clauses, '[]'::jsonb)) c), ''), 'sha256'), 'hex') $f$;

-- عضو الهيئة الحالي
create or replace function public._sh_me() returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'sharia' or me.role not in ('sharia_head', 'sharia_member', 'sharia_secretary') then raise exception 'هذه الصلاحية لأعضاء الهيئة الشرعية فقط'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  return me;
end $f$;

-- مسؤول المنتجات الإسلامية في مصرف إسلامي
create or replace function public._sh_bank_me() returns profiles
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'bank' or me.role <> 'bank_islamic_products' then raise exception 'هذه الصلاحية لمسؤول المنتجات الإسلامية في المصرف فقط'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if not exists (select 1 from orgs where id = me.org_id and is_islamic) then raise exception 'المنتجات الإسلامية للمصارف الإسلامية فقط'; end if;
  return me;
end $f$;

-- الهيئة المختصة بمصرف: هيئة المصرف إن وُجدت (المرحلة الثانية) وإلا المركزية
create or replace function public._sh_board_for(p_bank uuid) returns uuid
language sql stable security definer set search_path to 'public' as $f$
  select id from sharia_boards where (scope = 'bank' and bank_id = p_bank) or scope = 'central'
  order by (scope = 'bank') desc, created_at limit 1 $f$;

create or replace function public._sh_log(p_prod uuid, p_action text, p_note text) returns void
language sql security definer set search_path to 'public' as $f$
  insert into sharia_log(product_id, actor_name, actor_code, actor_side, action, note)
  select p_prod, coalesce(p.full_name, 'النظام'), p.staff_code, case when p.portal = 'bank' then 'bank' when p.portal = 'sharia' then 'board' end, p_action, p_note
  from (select 1) x left join profiles p on p.id = auth.uid() $f$;

-- إشعار أدوار محددة في جهة (وإن لم يوجد أحد: إشعار عام للجهة)
create or replace function public._sh_notify(p_org uuid, p_portal text, p_roles text[], p_kind text, p_title text, p_body text, p_ref uuid) returns void
language plpgsql security definer set search_path to 'public' as $f$
begin
  if p_org is null then return; end if;
  insert into notifications(user_id, org_id, portal, kind, title, body, ref_id)
  select id, null, null, p_kind, p_title, p_body, p_ref from profiles where org_id = p_org and role = any(p_roles) and not coalesce(disabled, false);
  if not found then perform _notify(p_org, p_portal, p_kind, p_title, p_body, p_ref); end if;
end $f$;

create or replace function public._sh_board_org(p_board uuid) returns uuid language sql stable security definer set search_path to 'public' as $f$
  select org_id from sharia_boards where id = p_board $f$;

-- الأعضاء المصوّتون: الرئيس والأعضاء الفعّالون في جهة الهيئة
create or replace function public._sh_voters(p_board uuid) returns int language sql stable security definer set search_path to 'public' as $f$
  select count(*)::int from profiles where org_id = (select org_id from sharia_boards where id = p_board) and role in ('sharia_head', 'sharia_member') and not coalesce(disabled, false) $f$;

-- عدّ الأصوات والنتيجة المقترحة لنسخة
create or replace function public._sh_tally(p_prod uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; b sharia_boards; a int; c int; r int; n int; mem int; head_vote text; prop text; need_ok boolean;
begin
  select * into p from islamic_products where id = p_prod;
  select * into b from sharia_boards where id = p.board_id;
  select count(*) filter (where vote = 'approve'), count(*) filter (where vote = 'approve_cond'), count(*) filter (where vote = 'reject'), count(*),
    max(vote) filter (where is_head)
  into a, c, r, n, head_vote from sharia_votes where version_id = p.current_version_id;
  mem := _sh_voters(p.board_id);
  need_ok := n >= b.quorum;
  prop := case
    when not need_ok then null
    when b.majority = 'two_thirds' and (a + c) * 3 >= n * 2 then case when c > 0 then 'conditional' else 'approved' end
    when b.majority = 'two_thirds' and r * 3 > n then 'rejected'
    when b.majority = 'simple' and (a + c) > r then case when c > 0 then 'conditional' else 'approved' end
    when b.majority = 'simple' and r > (a + c) then 'rejected'
    when b.chair_casting and head_vote is not null then case when head_vote = 'reject' then 'rejected' when c > 0 then 'conditional' else 'approved' end
    else null end;
  return jsonb_build_object('approve', a, 'approve_cond', c, 'reject', r, 'cast', n, 'members', mem, 'quorum', b.quorum, 'quorum_ok', need_ok,
    'majority', b.majority, 'tie', (a + c) = r and n > 0, 'head_vote', head_vote, 'proposed', prop, 'proposed_label', _sh_decision_label(prop));
end $f$;

-- رقم قرار جديد
create or replace function public._sh_next_code() returns text language plpgsql security definer set search_path to 'public' as $f$
declare y text := to_char(now(), 'YYYY'); n int;
begin
  perform pg_advisory_xact_lock(hashtext('sharia_resolution_code'));
  select coalesce(max(substring(code from '\d+$')::int), 0) + 1 into n from sharia_resolutions where code like 'SH-' || y || '-%';
  return 'SH-' || y || '-' || lpad(n::text, 5, '0');
end $f$;

-- ملخص سطري لمنتج (للصناديق والقوائم)
create or replace function public._sh_row(p islamic_products) returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('id', p.id, 'code', p.code, 'name', p.name, 'bank', (select name from orgs where id = p.bank_id), 'bank_id', p.bank_id,
    'type', p.contract_type, 'type_name', (select name from sharia_contract_types where code = p.contract_type),
    'sector', p.sector, 'subsector', p.subsector, 'sector_label', _sh_sector_label(p.sector, p.subsector), 'line', p.line,
    'status', p.status, 'status_label', _sh_status_label(p.status), 'status_note', p.status_note,
    'version', (select n from islamic_contract_versions where id = p.current_version_id),
    'versions', (select count(*) from islamic_contract_versions where product_id = p.id),
    'comments', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null),
    'comments_open', (select count(*) from sharia_reviews where product_id = p.id and parent_id is null and not resolved and author_side = 'board'),
    'votes', (select count(*) from sharia_votes where version_id = p.current_version_id),
    'my_vote', (select vote from sharia_votes where version_id = p.current_version_id and member_id = auth.uid()),
    'resolution', (select jsonb_build_object('code', code, 'decision', decision, 'decision_label', _sh_decision_label(decision), 'issued_at', issued_at) from sharia_resolutions where id = p.resolution_id),
    'submitted_at', p.submitted_at, 'updated_at', p.updated_at, 'review_due', p.review_due,
    'review_soon', p.review_due is not null and p.review_due <= current_date + 30) $f$;

-- ───────── 5) بوابة الهيئة: الصندوق ─────────
create or replace function public.sharia_inbox() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards;
begin
  me := _sh_me();
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1;
  if b.id is null then raise exception 'لا توجد هيئة مرتبطة بحسابك'; end if;
  return jsonb_build_object(
    'me', jsonb_build_object('id', me.id, 'name', me.full_name, 'role', me.role, 'role_title', _role_title(me.role), 'code', me.staff_code,
      'head', me.role = 'sharia_head', 'secretary', me.role = 'sharia_secretary', 'voter', me.role in ('sharia_head', 'sharia_member')),
    'board', jsonb_build_object('id', b.id, 'code', b.code, 'name', b.name, 'scope', b.scope, 'madhhab', b.madhhab, 'madhhab_label', _sh_madhhab_label(b.madhhab),
      'marja', b.marja, 'quorum', b.quorum, 'majority', b.majority, 'chair_casting', b.chair_casting, 'review_months', b.review_months, 'late_rule', b.late_rule,
      'voters', _sh_voters(b.id),
      'members', coalesce((select jsonb_agg(jsonb_build_object('name', p.full_name, 'role', p.role, 'role_title', _role_title(p.role), 'code', p.staff_code,
        'specialty', m.specialty) order by case p.role when 'sharia_head' then 0 when 'sharia_member' then 1 else 2 end, p.full_name)
        from profiles p left join sharia_members m on m.profile_id = p.id and m.board_id = b.id
        where p.org_id = b.org_id and p.role like 'sharia\_%' and not coalesce(p.disabled, false)), '[]'::jsonb)),
    'products', coalesce((select jsonb_agg(_sh_row(p) order by p.updated_at desc) from islamic_products p where p.board_id = b.id and p.status <> 'draft'), '[]'::jsonb),
    'types', coalesce((select jsonb_agg(to_jsonb(t) order by t.sort) from sharia_contract_types t), '[]'::jsonb),
    'resolutions', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision),
      'product', p.name, 'product_id', p.id, 'bank', (select name from orgs where id = p.bank_id), 'type', p.contract_type, 'issued_at', r.issued_at,
      'signed_by', r.signed_by_name, 'seal', r.seal, 'version', (select n from islamic_contract_versions where id = r.version_id)) order by r.issued_at desc)
      from sharia_resolutions r join islamic_products p on p.id = r.product_id where r.board_id = b.id), '[]'::jsonb));
end $f$;

-- ملف المنتج كاملاً (للهيئة وللمصرف صاحب المنتج وللجهات الرقابية)
create or replace function public.sharia_product(p_id uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; me profiles; side text; cur islamic_contract_versions; prev islamic_contract_versions; b sharia_boards; t sharia_contract_types;
begin
  select * into me from profiles where id = auth.uid();
  select * into p from islamic_products where id = p_id;
  if p.id is null then raise exception 'المنتج غير موجود'; end if;
  side := case when me.portal = 'sharia' then 'board' when me.portal = 'bank' and p.bank_id = me.org_id then 'bank'
    when me.portal in ('cbi', 'integrity', 'audit', 'admin') then 'viewer' end;
  if side is null then raise exception 'لا صلاحية للاطلاع على هذا المنتج'; end if;
  if side = 'board' then perform _sh_me(); end if;
  if side = 'board' and p.status = 'draft' then raise exception 'المنتج مسودة لدى المصرف ولم يُقدَّم بعد'; end if;
  select * into cur from islamic_contract_versions where id = p.current_version_id;
  select * into prev from islamic_contract_versions where product_id = p.id and n < coalesce(cur.n, 0) order by n desc limit 1;
  select * into b from sharia_boards where id = p.board_id;
  select * into t from sharia_contract_types where code = p.contract_type;
  return _sh_row(p) || jsonb_build_object(
    'side', side, 'pricing', p.pricing, 'guarantees', p.guarantees, 'attachments', p.attachments,
    'type_rules', t.rules, 'type_essence', t.essence, 'type_line', t.borrower_line,
    'board', jsonb_build_object('name', b.name, 'madhhab_label', _sh_madhhab_label(b.madhhab), 'marja', b.marja, 'quorum', b.quorum, 'majority', b.majority, 'chair_casting', b.chair_casting),
    'current', case when cur.id is null then null else jsonb_build_object('id', cur.id, 'n', cur.n, 'clauses', cur.clauses, 'sha256', cur.sha256, 'status', cur.status,
      'change_note', cur.change_note, 'by', cur.created_by_name, 'at', cur.created_at) end,
    'previous', case when prev.id is null then null else jsonb_build_object('id', prev.id, 'n', prev.n, 'clauses', prev.clauses, 'sha256', prev.sha256, 'at', prev.created_at) end,
    'version_list', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'n', v.n, 'status', v.status, 'sha256', v.sha256, 'at', v.created_at, 'by', v.created_by_name,
      'change_note', v.change_note, 'clauses', v.clauses) order by v.n desc) from islamic_contract_versions v where v.product_id = p.id), '[]'::jsonb),
    'approved_version', (select jsonb_build_object('n', n, 'sha256', sha256) from islamic_contract_versions where id = p.approved_version_id),
    'reviews', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'clause_n', r.clause_n, 'parent_id', r.parent_id, 'author', r.author_name, 'side', r.author_side,
      'body', r.body, 'resolved', r.resolved, 'at', r.created_at, 'version', v.n, 'mine', r.author_id = auth.uid()) order by r.created_at)
      from sharia_reviews r join islamic_contract_versions v on v.id = r.version_id where r.product_id = p.id), '[]'::jsonb),
    'votes', case when side = 'bank' then '[]'::jsonb else coalesce((select jsonb_agg(jsonb_build_object('name', member_name, 'head', is_head, 'vote', vote, 'condition', condition, 'reason', reason, 'at', at,
      'mine', member_id = auth.uid()) order by at) from sharia_votes where version_id = p.current_version_id), '[]'::jsonb) end,
    'tally', _sh_tally(p.id),
    'resolutions_list', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'decision', r.decision, 'decision_label', _sh_decision_label(r.decision),
      'body', r.body, 'conditions', r.conditions, 'votes', r.votes, 'dissent', r.dissent, 'version_sha256', r.version_sha256, 'seal', r.seal,
      'signed_by', r.signed_by_name, 'signed_code', r.signed_by_code, 'signed_via', r.signed_via, 'issued_at', r.issued_at,
      'version', (select n from islamic_contract_versions where id = r.version_id)) order by r.issued_at desc) from sharia_resolutions r where r.product_id = p.id), '[]'::jsonb),
    'log', coalesce((select jsonb_agg(jsonb_build_object('at', at, 'who', actor_name, 'code', actor_code, 'side', actor_side, 'action', action, 'note', note) order by at desc)
      from sharia_log where product_id = p.id), '[]'::jsonb),
    'checklist', jsonb_build_array(
      jsonb_build_object('k', 'name', 'label', 'اسم المنتج وسطر يشرح الصيغة للمقترض', 'ok', length(coalesce(p.name, '')) >= 3 and length(coalesce(p.line, '')) >= 10),
      jsonb_build_object('k', 'type', 'label', 'الصيغة من المكتبة ومسموحة', 'ok', coalesce(t.allowed, false)),
      jsonb_build_object('k', 'sector', 'label', 'الصيغة مناسبة للقطاع', 'ok', p.sector = any(coalesce(t.sectors, '{}'))),
      jsonb_build_object('k', 'pricing', 'label', 'قواعد التسعير: ربح أدنى وأعلى ومدد', 'ok', (p.pricing ? 'profit_max') and (p.pricing ? 'term_max')),
      jsonb_build_object('k', 'guarantees', 'label', 'الضمانات المسموحة', 'ok', cardinality(p.guarantees) > 0),
      jsonb_build_object('k', 'clauses', 'label', 'نموذج العقد ببنود مرقّمة (5 بنود على الأقل)', 'ok', jsonb_array_length(coalesce(cur.clauses, '[]'::jsonb)) >= 5),
      jsonb_build_object('k', 'late', 'label', 'بند التأخر في السداد بلا زيادة لمصلحة المصرف', 'ok', exists (select 1 from jsonb_array_elements(coalesce(cur.clauses, '[]'::jsonb)) c where c->>'title' like '%تأخر%')),
      jsonb_build_object('k', 'attachments', 'label', 'الملحقات (طلب الشراء أو الوعد، المحضر، جدول الأقساط)', 'ok', cardinality(p.attachments) >= 2)));
end $f$;

-- ───────── 6) أمين السر: التحقق من الاكتمال، الإحالة أو الإعادة ─────────
create or replace function public.sharia_screen(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
begin
  me := _sh_me();
  if me.role not in ('sharia_secretary', 'sharia_head') then raise exception 'التحقق من الاكتمال لأمين السر'; end if;
  select * into pr from islamic_products where id = p_id for update;
  if pr.status <> 'submitted' then raise exception 'المنتج ليس بانتظار التحقق (حالته: %)', _sh_status_label(pr.status); end if;
  if act = 'refer' then
    update islamic_products set status = 'deliberation', status_note = v_note, updated_at = now() where id = pr.id;
    perform _sh_log(pr.id, 'إحالة للأعضاء للمداولة والتصويت', v_note);
    perform _sh_notify(me.org_id, 'sharia', array['sharia_head', 'sharia_member'], 'sharia_review', 'منتج للمداولة: ' || pr.name,
      (select name from orgs where id = pr.bank_id) || ' · ' || (select name from sharia_contract_types where code = pr.contract_type) || ' — علّق على البنود وصوّت', pr.id);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أحيل منتجك للأعضاء: ' || pr.name, 'بدأت المداولة. ستصلك التعليقات على البنود', pr.id);
  elsif act = 'return' then
    if v_note is null or length(v_note) < 5 then raise exception 'اكتب سبب الإعادة للمصرف'; end if;
    update islamic_products set status = 'returned', status_note = v_note, updated_at = now() where id = pr.id;
    update islamic_contract_versions set status = 'returned' where id = pr.current_version_id;
    perform _sh_log(pr.id, 'إعادة للمصرف لاستكمال الملف', v_note);
    perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'أعادت الهيئة منتجك للتعديل: ' || pr.name, v_note, pr.id);
  else raise exception 'إجراء غير معروف'; end if;
  return _sh_row((select x from islamic_products x where id = pr.id));
end $f$;

-- ───────── 7) المداولة: تعليق على بند محدد ─────────
create or replace function public.sharia_comment(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; v_body text := nullif(trim(coalesce(p->>'body', '')), ''); v_clause int := nullif(p->>'clause_n', '')::int; rid uuid;
begin
  me := _sh_me();
  select * into pr from islamic_products where id = p_id;
  if pr.status not in ('deliberation', 'submitted') then raise exception 'التعليق متاح أثناء المداولة فقط'; end if;
  if v_body is null or length(v_body) < 3 then raise exception 'اكتب التعليق'; end if;
  if v_clause is not null and not exists (select 1 from islamic_contract_versions v, jsonb_array_elements(v.clauses) c where v.id = pr.current_version_id and (c->>'n')::int = v_clause) then
    raise exception 'البند % غير موجود في النسخة الحالية', v_clause; end if;
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body)
  values (pr.id, pr.current_version_id, v_clause, me.id, me.full_name, 'board', left(v_body, 2000)) returning id into rid;
  update islamic_products set updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تعليق على ' || coalesce('البند ' || v_clause, 'المنتج'), left(v_body, 200));
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products'], 'sharia_bank', 'تعليق من الهيئة على ' || coalesce('البند ' || v_clause, 'منتجك') || ': ' || pr.name, left(v_body, 160), pr.id);
  return jsonb_build_object('id', rid);
end $f$;

-- تعليم التعليق «معالَج» (كاتبه أو الرئيس أو أمين السر)
create or replace function public.sharia_comment_resolve(p_review uuid, p_resolved boolean) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; r sharia_reviews;
begin
  me := _sh_me();
  select * into r from sharia_reviews where id = p_review;
  if r.id is null then raise exception 'التعليق غير موجود'; end if;
  if r.author_id <> me.id and me.role not in ('sharia_head', 'sharia_secretary') then raise exception 'يعلّم التعليقَ كاتبُه أو الرئيس أو أمين السر'; end if;
  update sharia_reviews set resolved = coalesce(p_resolved, true) where id = r.id;
  perform _sh_log(r.product_id, case when coalesce(p_resolved, true) then 'تعليم تعليق معالَجاً' else 'إعادة فتح تعليق' end, left(r.body, 120));
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 8) التصويت ─────────
create or replace function public.sharia_vote(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; v text := p->>'vote'; v_cond text := nullif(trim(coalesce(p->>'condition', '')), ''); v_reason text := nullif(trim(coalesce(p->>'reason', '')), '');
begin
  me := _sh_me();
  if me.role not in ('sharia_head', 'sharia_member') then raise exception 'التصويت للرئيس والأعضاء'; end if;
  select * into pr from islamic_products where id = p_id;
  if pr.status <> 'deliberation' then raise exception 'التصويت متاح أثناء المداولة فقط'; end if;
  if v not in ('approve', 'approve_cond', 'reject') then raise exception 'اختر: موافق أو موافق بشرط أو غير موافق'; end if;
  if v = 'approve_cond' and (v_cond is null or length(v_cond) < 5) then raise exception 'اكتب الشرط'; end if;
  if v = 'reject' and (v_reason is null or length(v_reason) < 5) then raise exception 'اكتب سبب عدم الموافقة'; end if;
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, condition, reason)
  values (pr.id, pr.current_version_id, me.id, me.full_name, me.role = 'sharia_head', v, case when v = 'approve_cond' then v_cond end, v_reason)
  on conflict (version_id, member_id) do update set vote = excluded.vote, condition = excluded.condition, reason = excluded.reason, at = now();
  update islamic_products set updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تصويت: ' || case v when 'approve' then 'موافق' when 'approve_cond' then 'موافق بشرط' else 'غير موافق' end, coalesce(v_cond, v_reason));
  return _sh_tally(pr.id);
end $f$;

-- ───────── 9) القرار: يصدره الرئيس ويوقّعه (رمز تحقق) ويُختم بالبصمة ─────────
create or replace function public.sharia_decide(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; pr islamic_products; b sharia_boards; cur islamic_contract_versions; tl jsonb; d text := p->>'decision';
  v_body text := nullif(trim(coalesce(p->>'body', '')), ''); v_conds text; v_code text; res sharia_resolutions; v_due date; v_now timestamptz := now();
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إصدار القرار لرئيس الهيئة'; end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح — التوقيع لم يتم'; end if;
  select * into pr from islamic_products where id = p_id for update;
  if pr.status <> 'deliberation' then raise exception 'القرار يصدر بعد المداولة (حالة المنتج: %)', _sh_status_label(pr.status); end if;
  select * into b from sharia_boards where id = pr.board_id;
  select * into cur from islamic_contract_versions where id = pr.current_version_id;
  tl := _sh_tally(pr.id);
  if d not in ('approved', 'conditional', 'returned', 'rejected') then raise exception 'اختر القرار'; end if;
  if d in ('approved', 'conditional', 'rejected') and not (tl->>'quorum_ok')::boolean then
    raise exception 'لم يكتمل النصاب: صوّت % من % مطلوبين', tl->>'cast', tl->>'quorum'; end if;
  if d in ('approved', 'conditional') and coalesce(tl->>'proposed', '') not in ('approved', 'conditional') then
    raise exception 'نتيجة التصويت لا تسمح بالاعتماد (النتيجة: %)', coalesce(tl->>'proposed_label', 'لا أغلبية'); end if;
  if d = 'approved' and tl->>'proposed' = 'conditional' then d := 'conditional'; end if;
  if d = 'rejected' and coalesce(tl->>'proposed', '') <> 'rejected' then raise exception 'نتيجة التصويت لا تسمح بالرفض — يمكنك الإعادة للتعديل'; end if;
  if d in ('returned', 'rejected') and (v_body is null or length(v_body) < 5) then raise exception 'اكتب نص القرار وسببه'; end if;
  select string_agg('• ' || member_name || ': ' || condition, E'\n' order by at) into v_conds from sharia_votes where version_id = cur.id and vote = 'approve_cond';
  v_code := _sh_next_code();
  v_due := case when d in ('approved', 'conditional') then (v_now + make_interval(months => b.review_months))::date end;
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, conditions, votes, dissent, version_sha256, seal, signed_by, signed_by_name, signed_by_code, signed_via, issued_at)
  values (v_code, b.id, pr.id, cur.id, d,
    coalesce(v_body, case d when 'approved' then 'اعتمدت الهيئة المنتج «' || pr.name || '» ونموذج عقده بالنسخة ' || cur.n || ' على ' || _sh_madhhab_label(b.madhhab) || '.'
      when 'conditional' then 'اعتمدت الهيئة المنتج «' || pr.name || '» ونموذج عقده بالنسخة ' || cur.n || ' بالشروط المذكورة، على ' || _sh_madhhab_label(b.madhhab) || '.' end),
    case when d = 'conditional' then v_conds end, tl,
    coalesce((select jsonb_agg(jsonb_build_object('name', member_name, 'vote', vote, 'reason', reason) order by at) from sharia_votes
      where version_id = cur.id and ((d in ('approved', 'conditional') and vote = 'reject') or (d = 'rejected' and vote <> 'reject'))), '[]'::jsonb),
    cur.sha256, encode(extensions.digest(v_code || '|' || coalesce(cur.sha256, '') || '|' || d || '|' || v_now::text, 'sha256'), 'hex'),
    me.id, me.full_name, me.staff_code, 'رمز تحقق على هاتف الرئيس', v_now)
  returning * into res;
  update islamic_contract_versions set status = case d when 'approved' then 'approved' when 'conditional' then 'approved' when 'rejected' then 'rejected' else 'returned' end where id = cur.id;
  if d in ('approved', 'conditional') then
    update islamic_contract_versions set status = 'superseded' where id = pr.approved_version_id and id <> cur.id;
  end if;
  update islamic_products set status = d, status_note = left(coalesce(v_body, v_conds), 400), resolution_id = res.id,
    approved_version_id = case when d in ('approved', 'conditional') then cur.id else approved_version_id end,
    review_due = coalesce(v_due, review_due), updated_at = v_now where id = pr.id;
  perform _sh_log(pr.id, 'قرار ' || v_code || ': ' || _sh_decision_label(d), left(coalesce(v_body, v_conds, ''), 200));
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products', 'bank_md'], 'sharia_bank', 'قرار الهيئة ' || v_code || ' — ' || _sh_decision_label(d) || ': ' || pr.name,
    case when d in ('approved', 'conditional') then 'المنتج يظهر الآن للمقترضين في مصرفكم' else coalesce(v_body, '') end, pr.id);
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_resolution', 'قرار الهيئة الشرعية ' || v_code || ' — ' || _sh_decision_label(d),
    pr.name || ' · ' || (select name from orgs where id = pr.bank_id), pr.id);
  return jsonb_build_object('code', res.code, 'decision', d, 'decision_label', _sh_decision_label(d), 'seal', res.seal, 'version_sha256', res.version_sha256, 'issued_at', res.issued_at);
end $f$;

-- ───────── 10) بعد الاعتماد: تعليق مؤقت، رفع التعليق، سحب الاعتماد ─────────
create or replace function public.sharia_post_action(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare me profiles; pr islamic_products; act text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), ''); v_code text; v_new text; v_dec text; res sharia_resolutions; v_now timestamptz := now();
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'هذا الإجراء لرئيس الهيئة'; end if;
  if not _otp_ok(p->>'otp', me.phone) then raise exception 'رمز التحقق غير صحيح'; end if;
  select * into pr from islamic_products where id = p_id for update;
  if act = 'suspend' then
    if pr.status not in ('approved', 'conditional') then raise exception 'يُعلَّق المنتج المعتمد فقط'; end if;
    v_new := 'suspended'; v_dec := 'suspended';
  elsif act = 'reinstate' then
    if pr.status <> 'suspended' then raise exception 'المنتج ليس معلّقاً'; end if;
    v_dec := 'reinstated';
    v_new := coalesce((select decision from sharia_resolutions where product_id = pr.id and decision in ('approved', 'conditional') order by issued_at desc limit 1), 'approved');
  elsif act = 'withdraw' then
    if pr.status not in ('approved', 'conditional', 'suspended') then raise exception 'يُسحب اعتماد المنتج المعتمد أو المعلّق فقط'; end if;
    v_new := 'withdrawn'; v_dec := 'withdrawn';
  else raise exception 'إجراء غير معروف'; end if;
  if act <> 'reinstate' and (v_note is null or length(v_note) < 5) then raise exception 'اكتب السبب'; end if;
  v_code := _sh_next_code();
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, version_sha256, seal, signed_by, signed_by_name, signed_by_code, signed_via, issued_at)
  select v_code, pr.board_id, pr.id, pr.approved_version_id, v_dec, coalesce(v_note, 'رُفع التعليق وعاد المنتج نافذاً'), v.sha256,
    encode(extensions.digest(v_code || '|' || coalesce(v.sha256, '') || '|' || v_dec || '|' || v_now::text, 'sha256'), 'hex'), me.id, me.full_name, me.staff_code, 'رمز تحقق على هاتف الرئيس', v_now
  from (select 1) x left join islamic_contract_versions v on v.id = pr.approved_version_id
  returning * into res;
  update islamic_products set status = v_new, status_note = v_note, resolution_id = res.id, updated_at = v_now where id = pr.id;
  perform _sh_log(pr.id, 'قرار ' || v_code || ': ' || _sh_decision_label(v_dec), v_note);
  perform _sh_notify(pr.bank_id, 'bank', array['bank_islamic_products', 'bank_md'], 'sharia_bank', 'قرار الهيئة ' || v_code || ' — ' || _sh_decision_label(v_dec) || ': ' || pr.name,
    case when v_new in ('suspended', 'withdrawn') then 'توقف عرض المنتج للطلبات الجديدة. العقود الموقّعة تبقى على نسختها' else 'عاد المنتج للظهور للمقترضين' end, pr.id);
  perform _notify((select id from orgs where type = 'cbi' order by created_at limit 1), 'cbi', 'sharia_resolution', 'قرار الهيئة الشرعية ' || v_code || ' — ' || _sh_decision_label(v_dec), pr.name, pr.id);
  return jsonb_build_object('code', v_code, 'status', v_new, 'status_label', _sh_status_label(v_new));
end $f$;

-- ───────── 11) إعدادات الهيئة (الرئيس) ─────────
create or replace function public.sharia_settings(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards; q int; rm int;
begin
  me := _sh_me();
  if me.role <> 'sharia_head' then raise exception 'إعدادات الهيئة لرئيسها'; end if;
  select * into b from sharia_boards where org_id = me.org_id order by created_at limit 1 for update;
  q := coalesce(nullif(p->>'quorum', '')::int, b.quorum); rm := coalesce(nullif(p->>'review_months', '')::int, b.review_months);
  if q < 1 or q > greatest(_sh_voters(b.id), 1) then raise exception 'النصاب بين 1 وعدد الأعضاء المصوّتين (%)', _sh_voters(b.id); end if;
  if rm < 1 or rm > 60 then raise exception 'دورة المراجعة بين 1 و60 شهراً'; end if;
  if coalesce(p->>'majority', b.majority) not in ('simple', 'two_thirds') then raise exception 'قاعدة الأغلبية غير معروفة'; end if;
  update sharia_boards set
    name = coalesce(nullif(trim(p->>'name'), ''), name),
    marja = case when p ? 'marja' then nullif(trim(p->>'marja'), '') else marja end,
    late_rule = case when p ? 'late_rule' then nullif(trim(p->>'late_rule'), '') else late_rule end,
    quorum = q, review_months = rm, majority = coalesce(p->>'majority', majority),
    chair_casting = coalesce((p->>'chair_casting')::boolean, chair_casting), updated_at = now()
  where id = b.id;
  perform _audit('تعديل إعدادات الهيئة الشرعية', b.code, p);
  return jsonb_build_object('ok', true);
end $f$;

-- ───────── 12) المصرف: منتجاته الإسلامية ─────────
create or replace function public.islamic_my_products() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; b sharia_boards;
begin
  me := _sh_bank_me();
  select * into b from sharia_boards where id = _sh_board_for(me.org_id);
  return jsonb_build_object(
    'bank', (select name from orgs where id = me.org_id),
    'board', jsonb_build_object('name', b.name, 'madhhab_label', _sh_madhhab_label(b.madhhab), 'scope', b.scope),
    'products', coalesce((select jsonb_agg(_sh_row(p) order by p.updated_at desc) from islamic_products p where p.bank_id = me.org_id), '[]'::jsonb),
    'types', coalesce((select jsonb_agg(to_jsonb(t) order by t.sort) from sharia_contract_types t where t.allowed), '[]'::jsonb));
end $f$;

-- إنشاء منتج أو تعديل بياناته (مسودة أو معاد للتعديل)
create or replace function public.islamic_product_save(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; v_type text := p->>'contract_type'; v_sector text := p->>'sector'; v_code text; t sharia_contract_types;
begin
  me := _sh_bank_me();
  if p_id is not null then
    select * into pr from islamic_products where id = p_id for update;
    if pr.bank_id <> me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
    if pr.status not in ('draft', 'returned') then raise exception 'بيانات المنتج تُعدَّل وهو مسودة أو معاد للتعديل فقط'; end if;
  end if;
  v_type := coalesce(v_type, pr.contract_type); v_sector := coalesce(v_sector, pr.sector);
  select * into t from sharia_contract_types where code = v_type;
  if t.code is null or not t.allowed then raise exception 'اختر صيغة من مكتبة الهيئة'; end if;
  if v_sector not in ('pv', 'vet', 'exim') then raise exception 'اختر القطاع'; end if;
  if length(trim(coalesce(p->>'name', pr.name, ''))) < 3 then raise exception 'اكتب اسم المنتج'; end if;
  if p_id is null then
    perform pg_advisory_xact_lock(hashtext('islamic_product_code'));
    select 'IP-' || to_char(now(), 'YYYY') || '-' || lpad((coalesce(max(substring(code from '\d+$')::int), 0) + 1)::text, 4, '0') into v_code from islamic_products where code like 'IP-' || to_char(now(), 'YYYY') || '-%';
    insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, created_by)
    values (v_code, me.org_id, _sh_board_for(me.org_id), v_type, trim(p->>'name'), v_sector, nullif(p->>'subsector', ''),
      coalesce(nullif(trim(p->>'line'), ''), t.borrower_line), coalesce(p->'pricing', '{}'::jsonb),
      coalesce((select array_agg(x) from jsonb_array_elements_text(p->'guarantees') x), '{}'), coalesce((select array_agg(x) from jsonb_array_elements_text(p->'attachments') x), '{}'), me.id)
    returning * into pr;
    perform _sh_log(pr.id, 'إنشاء المنتج', pr.name);
  else
    update islamic_products set contract_type = v_type, sector = v_sector, name = coalesce(nullif(trim(p->>'name'), ''), name),
      subsector = case when p ? 'subsector' then nullif(p->>'subsector', '') else subsector end,
      line = coalesce(nullif(trim(p->>'line'), ''), line), pricing = coalesce(p->'pricing', pricing),
      guarantees = coalesce((select array_agg(x) from jsonb_array_elements_text(p->'guarantees') x), guarantees),
      attachments = coalesce((select array_agg(x) from jsonb_array_elements_text(p->'attachments') x), attachments), updated_at = now()
    where id = pr.id returning * into pr;
    perform _sh_log(pr.id, 'تعديل بيانات المنتج', null);
  end if;
  return _sh_row(pr);
end $f$;

-- حفظ نص العقد: المسودة تُعدَّل في مكانها، وبعد التقديم كل تعديل نسخة جديدة
create or replace function public.islamic_version_save(p_id uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; cur islamic_contract_versions; v_cl jsonb := p->'clauses'; v_note text := nullif(trim(coalesce(p->>'change_note', '')), ''); nv islamic_contract_versions; c jsonb;
begin
  me := _sh_bank_me();
  select * into pr from islamic_products where id = p_id for update;
  if pr.bank_id <> me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
  if pr.status not in ('draft', 'returned', 'deliberation') then raise exception 'نص العقد يُعدَّل وهو مسودة أو معاد أو أثناء المداولة فقط'; end if;
  if jsonb_typeof(v_cl) <> 'array' or jsonb_array_length(v_cl) = 0 then raise exception 'اكتب بنود العقد'; end if;
  -- ترقيم البنود من جديد بترتيبها
  select jsonb_agg(jsonb_build_object('n', i, 'title', left(trim(coalesce(x->>'title', '')), 120), 'text', left(trim(coalesce(x->>'text', '')), 4000)) order by i)
  into v_cl from jsonb_array_elements(v_cl) with ordinality as e(x, i) where length(trim(coalesce(x->>'text', ''))) > 0;
  if v_cl is null then raise exception 'اكتب نص البنود'; end if;
  for c in select * from jsonb_array_elements(v_cl) loop
    if length(c->>'title') < 2 then raise exception 'اكتب عنوان البند %', c->>'n'; end if;
  end loop;
  select * into cur from islamic_contract_versions where id = pr.current_version_id;
  if cur.id is not null and cur.status = 'draft' then
    update islamic_contract_versions set clauses = v_cl, sha256 = _sh_sha(v_cl), change_note = coalesce(v_note, change_note), created_by_name = me.full_name, created_at = now()
    where id = cur.id returning * into nv;
  else
    if cur.id is not null and _sh_sha(v_cl) = cur.sha256 then raise exception 'لم يتغير شيء في النص'; end if;
    if pr.status = 'deliberation' and v_note is null then raise exception 'اكتب ما عدّلته استجابة للتعليقات'; end if;
    if cur.id is not null and cur.status = 'submitted' then update islamic_contract_versions set status = 'superseded' where id = cur.id; end if;
    insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name)
    values (pr.id, coalesce((select max(n) from islamic_contract_versions where product_id = pr.id), 0) + 1, v_cl, _sh_sha(v_cl),
      case when pr.status = 'deliberation' then 'submitted' else 'draft' end, v_note, me.full_name)
    returning * into nv;
    update islamic_products set current_version_id = nv.id, updated_at = now() where id = pr.id;
    if pr.status = 'deliberation' then
      perform _sh_notify(_sh_board_org(pr.board_id), 'sharia', array['sharia_head', 'sharia_member', 'sharia_secretary'], 'sharia_review',
        'نسخة معدّلة ' || nv.n || ' من عقد: ' || pr.name, 'الأصوات السابقة لا تسري على النسخة الجديدة — راجع الفروق وصوّت', pr.id);
    end if;
  end if;
  perform _sh_log(pr.id, 'حفظ نص العقد — النسخة ' || nv.n, v_note);
  return jsonb_build_object('n', nv.n, 'sha256', nv.sha256, 'status', nv.status);
end $f$;

-- تقديم المنتج للهيئة
create or replace function public.islamic_product_submit(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; pr islamic_products; cur islamic_contract_versions;
begin
  me := _sh_bank_me();
  select * into pr from islamic_products where id = p_id for update;
  if pr.bank_id <> me.org_id then raise exception 'المنتج لمصرف آخر'; end if;
  if pr.status not in ('draft', 'returned') then raise exception 'يُقدَّم المنتج وهو مسودة أو معاد للتعديل'; end if;
  select * into cur from islamic_contract_versions where id = pr.current_version_id;
  if cur.id is null or jsonb_array_length(cur.clauses) < 5 then raise exception 'اكتب نموذج العقد (5 بنود على الأقل) قبل التقديم'; end if;
  if pr.status = 'returned' and cur.status <> 'draft' then raise exception 'عدّل نص العقد أولاً (نسخة جديدة) ثم قدّمه'; end if;
  update islamic_contract_versions set status = 'submitted', sha256 = _sh_sha(clauses) where id = cur.id;
  update islamic_products set status = 'submitted', status_note = null, submitted_at = now(), updated_at = now() where id = pr.id;
  perform _sh_log(pr.id, 'تقديم للهيئة — النسخة ' || cur.n, null);
  perform _sh_notify(_sh_board_org(pr.board_id), 'sharia', array['sharia_secretary'], 'sharia_review', 'منتج جديد للتحقق: ' || pr.name,
    (select name from orgs where id = pr.bank_id) || ' · ' || (select name from sharia_contract_types where code = pr.contract_type), pr.id);
  return _sh_row((select x from islamic_products x where id = pr.id));
end $f$;

-- رد المصرف على تعليق
create or replace function public.islamic_product_reply(p_review uuid, p_body text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare me profiles; r sharia_reviews; pr islamic_products; rid uuid;
begin
  me := _sh_bank_me();
  select * into r from sharia_reviews where id = p_review;
  select * into pr from islamic_products where id = r.product_id;
  if pr.bank_id is distinct from me.org_id then raise exception 'التعليق على منتج مصرف آخر'; end if;
  if length(trim(coalesce(p_body, ''))) < 2 then raise exception 'اكتب الرد'; end if;
  insert into sharia_reviews(product_id, version_id, clause_n, parent_id, author_id, author_name, author_side, body)
  values (pr.id, r.version_id, r.clause_n, coalesce(r.parent_id, r.id), me.id, me.full_name, 'bank', left(trim(p_body), 2000)) returning id into rid;
  perform _sh_log(pr.id, 'رد المصرف على تعليق' || coalesce(' — البند ' || r.clause_n, ''), left(p_body, 160));
  perform _sh_notify(_sh_board_org(pr.board_id), 'sharia', array['sharia_head', 'sharia_member', 'sharia_secretary'], 'sharia_review', 'رد المصرف على تعليق: ' || pr.name, left(p_body, 160), pr.id);
  return jsonb_build_object('id', rid);
end $f$;

-- ───────── 13) المقترض: المنتجات المعتمدة و«اقرأ العقد» ─────────
-- القسط بالطريقة نفسها المعروضة في بطاقة المصرف، فيكون الثمن الكلي = القسط × المدة، والربح = الثمن − الكلفة (معلوم وثابت)
create or replace function public._sh_calc(p islamic_products, p_amount numeric, p_term int) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare bt bank_terms; v_rate numeric; v_term int; v_ins numeric;
begin
  select * into bt from bank_terms where bank_id = p.bank_id;
  v_rate := coalesce(nullif(p.pricing->>'profit_rate', '')::numeric, coalesce(_setting('cbi_rate'), 0) + coalesce(bt.margin, 0));
  v_term := least(greatest(coalesce(p_term, 60), coalesce((p.pricing->>'term_min')::int, 12)), coalesce((p.pricing->>'term_max')::int, bt.max_term_months, 84), coalesce(bt.max_term_months, 84));
  v_ins := _installment(p_amount, v_rate, v_term);
  return jsonb_build_object('rate', v_rate, 'term', v_term, 'installment', v_ins, 'total', v_ins * v_term, 'profit', v_ins * v_term - p_amount, 'cost', p_amount, 'residual', 1000);
end $f$;

-- تعبئة المتغيرات في نص
create or replace function public._sh_fill(p_text text, v jsonb) returns text language plpgsql immutable as $f$
declare k text; r text := coalesce(p_text, '');
begin
  for k in select jsonb_object_keys(v) loop r := replace(r, '{{' || k || '}}', coalesce(v->>k, '')); end loop;
  return regexp_replace(r, '\{\{[a-z_]+\}\}', '—', 'g');
end $f$;

create or replace function public.islamic_offer_products(p_bank uuid, p_amount numeric, p_term int, p_sector text default 'pv') returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth.uid() is null then raise exception 'سجّل الدخول أولاً'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'type', p.contract_type, 'type_name', t.name, 'line', coalesce(p.line, t.borrower_line),
      'sector_label', _sh_sector_label(p.sector, p.subsector), 'status', p.status, 'resolution', r.code, 'resolution_at', r.issued_at,
      'conditional', p.status = 'conditional', 'version', v.n, 'sha256', v.sha256, 'calc', _sh_calc(p, p_amount, p_term), 'guarantees', p.guarantees)
      order by p.created_at)
    from islamic_products p join sharia_contract_types t on t.code = p.contract_type
      join islamic_contract_versions v on v.id = p.approved_version_id
      left join sharia_resolutions r on r.id = (select id from sharia_resolutions where product_id = p.id and decision in ('approved', 'conditional') order by issued_at desc limit 1)
    where p.bank_id = p_bank and p.status in ('approved', 'conditional') and p.sector = coalesce(p_sector, 'pv')
      and (p.subsector is null or p.subsector in ('individuals', 'agri', 'industry', 'clinic', 'production'))), '[]'::jsonb);
end $f$;

-- العقد الفعلي مملوءاً ببيانات المقترض (للعرض قبل الاختيار، ولطلب قائم)
create or replace function public.islamic_contract_preview(p_product uuid, p_amount numeric, p_term int, p_offer uuid, p_app uuid default null) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare p islamic_products; v islamic_contract_versions; t sharia_contract_types; b sharia_boards; me profiles; a applications; o supplier_offers; k jsonb; vars jsonb; res sharia_resolutions; v_place text;
begin
  select * into me from profiles where id = auth.uid();
  if me.id is null then raise exception 'سجّل الدخول أولاً'; end if;
  select * into p from islamic_products where id = p_product;
  if p.id is null then raise exception 'المنتج غير موجود'; end if;
  if p_app is not null then
    select * into a from applications where id = p_app;
    if a.id is null or (a.citizen_id <> me.id and me.portal = 'citizen') then raise exception 'الطلب غير موجود'; end if;
    select * into v from islamic_contract_versions where id = coalesce(a.contract_version_id, p.approved_version_id);
    p_amount := coalesce(p_amount, a.amount); p_term := coalesce(p_term, a.term_months, (a.bank_choice->>'term_months')::int); p_offer := coalesce(p_offer, a.offer_id);
  else
    if p.status not in ('approved', 'conditional') then raise exception 'هذا المنتج غير معتمد شرعاً حالياً'; end if;
    select * into v from islamic_contract_versions where id = p.approved_version_id;
  end if;
  select * into t from sharia_contract_types where code = p.contract_type;
  select * into b from sharia_boards where id = p.board_id;
  select * into o from supplier_offers where id = p_offer;
  select * into res from sharia_resolutions where product_id = p.id and version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  k := _sh_calc(p, coalesce(p_amount, o.price, 0), p_term);
  v_place := coalesce(nullif(concat_ws(' — ', a.governorate, a.city), ''), nullif(concat_ws(' — ', me.governorate, me.city), ''), 'العنوان الذي يحدده المقترض في طلبه');
  vars := jsonb_build_object(
    'borrower_name', coalesce(a.citizen_name, me.full_name), 'borrower_nid', coalesce('••••' || right(coalesce(me.national_id, ''), 4), '—'),
    'bank_name', (select name from orgs where id = p.bank_id), 'asset', coalesce(o.title, 'المنظومة المختارة'),
    'supplier', coalesce((select name from orgs where id = o.supplier_id), 'المورد المعتمد'), 'place', v_place,
    'cost', _sh_fmt((k->>'cost')::numeric), 'profit', _sh_fmt((k->>'profit')::numeric), 'price_total', _sh_fmt((k->>'total')::numeric),
    'installment', _sh_fmt((k->>'installment')::numeric), 'term', k->>'term', 'rate', to_char((k->>'rate')::numeric, 'FM990.00'),
    'residual', _sh_fmt((k->>'residual')::numeric), 'board', b.name, 'resolution', coalesce(res.code, 'بانتظار القرار'), 'product', p.name,
    'date', to_char(now(), 'YYYY/MM/DD'), 'madhhab', _sh_madhhab_label(b.madhhab));
  return jsonb_build_object('product', p.name, 'type', t.code, 'type_name', t.name, 'bank', vars->>'bank_name', 'board', b.name, 'madhhab', _sh_madhhab_label(b.madhhab), 'marja', b.marja,
    'resolution', res.code, 'resolution_at', res.issued_at, 'conditions', res.conditions, 'conditional', res.decision = 'conditional',
    'version', v.n, 'sha256', v.sha256, 'calc', k,
    'summary', jsonb_build_array(
      jsonb_build_object('k', 'own', 'label', 'ما تملكه', 'text', _sh_fill(t.rules->'summary'->>'own', vars)),
      jsonb_build_object('k', 'when', 'label', 'متى تملكه', 'text', _sh_fill(t.rules->'summary'->>'when', vars)),
      jsonb_build_object('k', 'pay', 'label', 'ما تدفعه', 'text', _sh_fill(t.rules->'summary'->>'pay', vars)),
      jsonb_build_object('k', 'late', 'label', 'إن تأخرت', 'text', _sh_fill(t.rules->'summary'->>'late', vars)),
      jsonb_build_object('k', 'damage', 'label', 'من يتحمّل التلف', 'text', _sh_fill(t.rules->'summary'->>'damage', vars))),
    'clauses', coalesce((select jsonb_agg(jsonb_build_object('n', (c->>'n')::int, 'title', c->>'title', 'text', _sh_fill(c->>'text', vars)) order by (c->>'n')::int)
      from jsonb_array_elements(v.clauses) c), '[]'::jsonb));
end $f$;

-- المقترض يختار المنتج: يُحفظ المنتج ونسخة العقد وبصمتها ورقم القرار في طلبه
create or replace function public.app_choose_product(p_app uuid, p_product uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; p islamic_products; v islamic_contract_versions; v_bank uuid; res text;
begin
  select * into a from applications where id = p_app for update;
  if a.id is null or a.citizen_id <> auth.uid() then raise exception 'الطلب غير موجود'; end if;
  if a.stage > 5 then raise exception 'لا يمكن تغيير المنتج بعد إرسال الطلب للمصرف'; end if;
  v_bank := coalesce(nullif(a.bank_choice->>'bank_id', '')::uuid, a.bank_id);
  if p_product is null then
    update applications set product_id = null, contract_version_id = null, contract_sha256 = null, sharia_resolution = null, updated_at = now() where id = a.id;
    return jsonb_build_object('ok', true);
  end if;
  select * into p from islamic_products where id = p_product;
  if p.id is null or p.bank_id is distinct from v_bank then raise exception 'المنتج لا يخص المصرف المختار في طلبك'; end if;
  if p.status not in ('approved', 'conditional') then raise exception 'هذا المنتج غير معتمد شرعاً حالياً — اختر منتجاً آخر'; end if;
  select * into v from islamic_contract_versions where id = p.approved_version_id;
  select code into res from sharia_resolutions where product_id = p.id and version_id = v.id and decision in ('approved', 'conditional') order by issued_at desc limit 1;
  update applications set product_id = p.id, contract_version_id = v.id, contract_sha256 = v.sha256, sharia_resolution = res, updated_at = now() where id = a.id;
  insert into application_events(application_id, stage, action, actor_name, note)
  select a.id, a.stage, 'اختيار المنتج الإسلامي: ' || p.name, a.citizen_name, 'نسخة العقد ' || v.n || ' · قرار ' || coalesce(res, '—') || ' · البصمة ' || left(v.sha256, 16) || '…'
  where to_regclass('public.application_events') is not null;
  return jsonb_build_object('ok', true, 'product', p.name, 'resolution', res, 'version', v.n, 'sha256', v.sha256);
end $f$;

-- ───────── 14) الصلاحيات على الدوال ─────────
revoke all on function public._sh_me(), public._sh_bank_me(), public._sh_board_for(uuid), public._sh_log(uuid, text, text),
  public._sh_notify(uuid, text, text[], text, text, text, uuid), public._sh_board_org(uuid), public._sh_voters(uuid), public._sh_tally(uuid), public._sh_next_code(),
  public._sh_row(islamic_products), public._sh_calc(islamic_products, numeric, int) from public, anon, authenticated;
revoke all on function public.sharia_inbox(), public.sharia_product(uuid), public.sharia_screen(uuid, jsonb), public.sharia_comment(uuid, jsonb), public.sharia_comment_resolve(uuid, boolean),
  public.sharia_vote(uuid, jsonb), public.sharia_decide(uuid, jsonb), public.sharia_post_action(uuid, jsonb), public.sharia_settings(jsonb),
  public.islamic_my_products(), public.islamic_product_save(uuid, jsonb), public.islamic_version_save(uuid, jsonb), public.islamic_product_submit(uuid), public.islamic_product_reply(uuid, text),
  public.islamic_offer_products(uuid, numeric, int, text), public.islamic_contract_preview(uuid, numeric, int, uuid, uuid), public.app_choose_product(uuid, uuid) from public, anon;
grant execute on function public.sharia_inbox(), public.sharia_product(uuid), public.sharia_screen(uuid, jsonb), public.sharia_comment(uuid, jsonb), public.sharia_comment_resolve(uuid, boolean),
  public.sharia_vote(uuid, jsonb), public.sharia_decide(uuid, jsonb), public.sharia_post_action(uuid, jsonb), public.sharia_settings(jsonb),
  public.islamic_my_products(), public.islamic_product_save(uuid, jsonb), public.islamic_version_save(uuid, jsonb), public.islamic_product_submit(uuid), public.islamic_product_reply(uuid, text),
  public.islamic_offer_products(uuid, numeric, int, text), public.islamic_contract_preview(uuid, numeric, int, uuid, uuid), public.app_choose_product(uuid, uuid) to authenticated;

-- ───────── 15) مكتبة الصيغ العشر على المذهب الجعفري (ملخص لضوابط التصميم — النص الفقهي النهائي تعتمده الهيئة) ─────────
insert into public.sharia_contract_types(code, name, essence, borrower_line, sectors, sort, rules) values
('MRB', 'المرابحة', 'المصرف يشتري ثم يبيع للمقترض بالكلفة + ربح معلوم مقسّطاً', 'يشتري المصرف المنظومة ثم يبيعها لك بربح معلوم تدفعه أقساطاً', '{pv,vet,exim}', 1, $j${
  "conditions": ["لا يبيع المصرف ما لا يملك: فاتورة المورد باسم المصرف ومحضر قبض قبل العقد", "الوعد بالشراء غير ملزم للمقترض، ويحمي المصرف نفسه بخيار الشرط في عقده مع المورد", "يُعلَن رأس المال والربح في العقد", "الثمن ثابت لا يتغير بعد العقد"],
  "guards": ["طلب شراء ووعد موقّع", "فاتورة المورد باسم المصرف (بوابة المورد)", "محضر استلام أو قبض", "ثم عقد المرابحة — والثمن = الكلفة + الربح المعلن"],
  "summary": {"own": "{{asset}} كاملة بمكوّناتها", "when": "بتوقيع عقد البيع، بعد أن يشتريها المصرف ويستلمها", "pay": "{{installment}} د.ع شهرياً × {{term}} شهراً = {{price_total}} د.ع (الكلفة {{cost}} + ربح معلوم {{profit}})", "late": "لا تُضاف أي زيادة على المبلغ. يطالبك المصرف بالقسط ويرجع إلى الضمان", "damage": "قبل التسليم على المصرف، وبعده عليك لأنك المالك"}}$j$::jsonb),
('NSA', 'بيع النسيئة (التقسيط)', 'بيع بثمن مؤجل أعلى من الحاضر', 'تشتري بثمن مؤجل معلوم تدفعه أقساطاً', '{pv,vet}', 2, $j${
  "conditions": ["الزيادة جزء من ثمن المبيع لا زيادة على دين", "لا زيادة بعد العقد مقابل تأجيل جديد"],
  "guards": ["ثمن البيع المؤجل مكتوب في العقد", "لا تعديل على الثمن بعد التوقيع"],
  "summary": {"own": "المنظومة {{asset}}", "when": "بتوقيع العقد", "pay": "{{installment}} د.ع شهرياً × {{term}} شهراً = {{price_total}} د.ع", "late": "لا زيادة على الثمن بسبب التأخير", "damage": "عليك بعد التسليم لأنك المالك"}}$j$::jsonb),
('IJM', 'الإجارة المنتهية بالتمليك', 'المصرف يملك الأصل ويؤجّره، ويتملكه المستأجر آخر المدة', 'يملك المصرف المنظومة ويؤجّرها لك، وتصير ملكك بعد آخر قسط', '{pv,vet}', 3, $j${
  "conditions": ["التمليك شرط ضمن عقد الإجارة (بيع بثمن رمزي أو هبة) تحدد الهيئة صيغته", "ضمان تلف العين على المالك (المصرف) ما لم يتعدَّ المستأجر أو يفرّط", "الصيانة الأساسية والتأمين على المالك، والتشغيلية على المستأجر", "الأجرة معلومة لكل فترة"],
  "guards": ["الأصل مسجّل باسم المصرف قبل عقد الإجارة", "بدء الأجرة بعد التسليم"],
  "summary": {"own": "تستأجر {{asset}} من المصرف، وتصير ملكك آخر المدة", "when": "بعد آخر قسط إيجار، بثمن رمزي {{residual}} د.ع", "pay": "أجرة {{installment}} د.ع شهرياً × {{term}} شهراً", "late": "لا تُضاف أي زيادة على الأجرة. يطالبك المصرف ويرجع إلى الضمان", "damage": "على المصرف لأنه المالك، إلا إن تعدّيت أو فرّطت. والصيانة الأساسية والتأمين عليه"}}$j$::jsonb),
('MSN', 'المشاركة المتناقصة', 'شركة في ملكية الأصل، يشتري العميل حصة المصرف تدريجياً', 'تشارك المصرف في ملكية المشروع، وتشتري حصته شيئاً فشيئاً', '{pv,vet}', 4, $j${
  "conditions": ["شركة أموال (عنان) فقط — شركات الأبدان والوجوه والمفاوضة باطلة عند الإمامية", "شراء الحصص بعقود بيع مستقلة", "تأجير حصة المصرف للعميل بأجرة", "الربح بالنسبة المتفق عليها، والخسارة على قدر رأس المال"],
  "guards": ["حصة كل طرف مسجلة", "كل شراء لحصة عقد بيع مستقل"],
  "summary": {"own": "حصة في المشروع تكبر كل شهر حتى يصير كله لك", "when": "تملك حصتك من البداية، وحصة المصرف بعقود بيع متتالية", "pay": "أجرة حصة المصرف + ثمن الحصة التي تشتريها، نحو {{installment}} د.ع شهرياً", "late": "لا زيادة على المتأخر لمصلحة المصرف", "damage": "على الشريكين كلٌّ بقدر حصته، ما لم يفرّط أحدهما"}}$j$::jsonb),
('MDR', 'المضاربة', 'المصرف يقدّم المال والعميل يتاجر به، والربح بالنسبة', 'يقدّم المصرف المال وتتاجر أنت به، والربح بينكما بنسبة', '{exim}', 5, $j${
  "conditions": ["تختص بالتجارة (بيع وشراء) على المشهور، ولا تصح للإنتاج أو الصناعة ← للمستورد لا للمصنع", "رأس المال نقد معلوم", "الربح حصة مشاعة لا مبلغ مقطوع", "خسارة المال على صاحبه ما لم يفرّط العامل"],
  "guards": ["الغرض تجارة لا إنتاج", "نسبة الربح مشاعة في العقد"],
  "summary": {"own": "تدير التجارة برأس مال المصرف", "when": "رأس المال يبقى للمصرف، ولك حصتك من الربح", "pay": "حصة المصرف من الربح الفعلي فقط", "late": "لا زيادة على المتأخر", "damage": "خسارة المال على المصرف ما لم تفرّط"}}$j$::jsonb),
('SLM', 'السَّلَم (بيع السلف)', 'المصرف يدفع الثمن الآن ويستلم سلعة موصوفة لاحقاً', 'يدفع لك المصرف الثمن الآن، وتسلّمه بضاعة موصوفة في موعد معلوم', '{pv,exim}', 6, $j${
  "conditions": ["قبض الثمن كاملاً في المجلس", "وصف السلعة وصفاً ينفي الجهالة", "الأجل معلوم", "مناسب للمصدّر والمزارع (تمويل ما قبل التصدير أو الحصاد)"],
  "guards": ["الثمن مدفوع كاملاً عند العقد", "السلعة موصوفة بالحقول الإلزامية (النوع، الكمية، الجودة، موعد ومكان التسليم)"],
  "summary": {"own": "الثمن كاملاً نقداً الآن", "when": "عند توقيع العقد", "pay": "تسلّم البضاعة الموصوفة في موعدها", "late": "لا زيادة مالية على التأخير", "damage": "البضاعة عليك حتى تسلّمها"}}$j$::jsonb),
('IST', 'الاستصناع', 'طلب صنع شيء موصوف (خط إنتاج، منظومة مركّبة)', 'يصنع لك المصرف (عبر صانع) ما تطلبه بمواصفات محددة', '{pv,vet}', 7, $j${
  "conditions": ["تختلف تخريجاته عند فقهاء الإمامية: بيع لموصوف في الذمة، أو إجارة على عمل مع مواد", "الهيئة تحدد التخريج والنظام يطبّق شروطه"],
  "guards": ["التخريج المعتمد من الهيئة مذكور في العقد", "المواصفات ملحقة بالعقد"],
  "summary": {"own": "ما يُصنع لك بالمواصفات", "when": "عند التسليم", "pay": "{{installment}} د.ع شهرياً × {{term}} شهراً", "late": "لا زيادة على المتأخر", "damage": "على الصانع حتى التسليم"}}$j$::jsonb),
('WKL', 'الوكالة بأجر', 'المصرف وكيل عن العميل (مثلاً في اعتماد مستندي والعميل يملك البضاعة)', 'المصرف ينوب عنك في عمل محدد بأجر معلوم', '{exim}', 8, $j${
  "conditions": ["الأجر مقابل عمل حقيقي ومعلوم، لا نسبة على الدين"],
  "guards": ["الأجر مبلغ مقطوع أو محسوب على العمل لا على الدين"],
  "summary": {"own": "البضاعة لك من البداية", "when": "—", "pay": "أجر الوكالة المعلوم فقط", "late": "لا زيادة", "damage": "عليك لأنك المالك"}}$j$::jsonb),
('DMN', 'الضمان / خطاب الضمان بأجر', 'للمصدرين والمستوردين', 'يضمنك المصرف أمام جهة أخرى بأجر معلوم', '{exim}', 9, $j${
  "conditions": ["الأجر مقابل الخدمة", "الضمان عند الإمامية نقل للذمة، ويُصاغ النموذج وفق ما تعتمده الهيئة"],
  "guards": ["الأجر مقابل الخدمة لا نسبة على المبلغ المضمون مع الزمن"],
  "summary": {"own": "—", "when": "—", "pay": "أجر الخطاب المعلوم", "late": "لا زيادة", "damage": "—"}}$j$::jsonb),
('QRD', 'القرض الحسن', 'قرض بلا زيادة', 'قرض تردّه كما هو دون أي زيادة', '{pv,vet,exim}', 10, $j${
  "conditions": ["لا زيادة مشروطة بأي اسم", "أجور الخدمة الفعلية فقط بما تقرّه الهيئة"],
  "guards": ["مجموع الأقساط = أصل القرض"],
  "summary": {"own": "المبلغ قرضاً", "when": "عند الصرف", "pay": "تردّ {{cost}} د.ع فقط على {{term}} شهراً", "late": "لا زيادة", "damage": "—"}}$j$::jsonb)
on conflict (code) do nothing;

-- ───────── 16) الجهة والهيئة والحسابات ─────────
insert into public.orgs(code, type, name, meta)
select 'shb', 'sharia', 'الهيئة الشرعية العليا للتمويل الإسلامي', '{"supervisor": "البنك المركزي العراقي"}'::jsonb
where not exists (select 1 from public.orgs where code = 'shb');

insert into public.sharia_boards(code, name, scope, org_id, madhhab, quorum, majority, chair_casting, review_months, late_rule)
select 'SHB-C', 'الهيئة الشرعية العليا للتمويل الإسلامي', 'central', (select id from public.orgs where code = 'shb'), 'jafari', 3, 'simple', true, 12,
  'لا تُحتسب أي زيادة على الدين المتأخر لمصلحة المصرف. للمصرف المطالبة والرجوع إلى الضمانات.'
where not exists (select 1 from public.sharia_boards where code = 'SHB-C');

do $$
declare r text[]; rows text[][] := array[
  ['sharia.head', 'Shr@2026hd', 'الشيخ د. محمد جعفر الحكيم',   'sharia_head',      'head',      'فقه المعاملات'],
  ['sharia.m1',   'Shr@2026m1', 'السيد د. علي حسن الموسوي',     'sharia_member',    'member',    'فقه المعاملات والعقود'],
  ['sharia.m2',   'Shr@2026m2', 'د. زينب عبد الرضا الياسري',    'sharia_member',    'member',    'المصرفية الإسلامية'],
  ['sharia.m3',   'Shr@2026m3', 'الشيخ حيدر كاظم الخفاجي',      'sharia_member',    'member',    'أصول الفقه'],
  ['sharia.m4',   'Shr@2026m4', 'د. أحمد ناجي العبودي',         'sharia_member',    'member',    'القانون المصرفي'],
  ['sharia.sec',  'Shr@2026sc', 'م. سارة فاضل الربيعي',         'sharia_secretary', 'secretary', 'أمانة السر']];
  i int; uid uuid; bid uuid;
begin
  select id into bid from public.sharia_boards where code = 'SHB-C';
  for i in 1 .. array_length(rows, 1) loop
    if not exists (select 1 from public.profiles where username = rows[i][1]) then
      perform public._mk_user(rows[i][1], rows[i][2], rows[i][3], rows[i][4], 'sharia', 'shb', null, null);
    end if;
    select id into uid from public.profiles where username = rows[i][1];
    update public.profiles set manage_scope = case when rows[i][4] = 'sharia_head' then 'org' else manage_scope end,
      managed_by = case when rows[i][4] <> 'sharia_head' then coalesce(managed_by, (select id from public.profiles where username = 'sharia.head')) else managed_by end
    where id = uid;
    insert into public.sharia_members(board_id, profile_id, role, specialty) values (bid, uid, rows[i][5], rows[i][6]) on conflict do nothing;
  end loop;
  -- مسؤول المنتجات الإسلامية في المصرف الإسلامي الأول (مصرف الواحة الإسلامي)
  if not exists (select 1 from public.profiles where username = 'wah.products') then
    perform public._mk_user('wah.products', 'Wah@2026pd', 'رقية عادل الشمري', 'bank_islamic_products', 'bank',
      (select code from public.orgs where type = 'bank' and is_islamic order by code limit 1), null, null);
  end if;
end $$;

-- ───────── 17) منتجات العرض لمصرف الواحة الإسلامي (مرة واحدة) ─────────
-- 1) «منظومتي بالمرابحة» معتمد (SH-2026-00001) · 2) «منظومتي بالإجارة المنتهية بالتمليك» معتمد بشرط (SH-2026-00002)
-- 3) «مشاركة المصنع» قيد المداولة (نسختان وتعليقات وصوتان) · 4) «أجهزة العيادة بالمرابحة» معاد للتعديل · 5) «سَلَم التصدير» مسودة
do $$
declare bk uuid; bd uuid; p1 uuid; p2 uuid; p3 uuid; p4 uuid; p5 uuid; v uuid; v2 uuid; hd uuid; m1 uuid; m2 uuid; m3 uuid; m4 uuid; sec uuid; r1 uuid; r2 uuid;
  c_mrb jsonb; c_ijm jsonb; c_msn1 jsonb; c_msn2 jsonb; c_vet jsonb; c_slm jsonb; t1 timestamptz := now() - interval '20 days'; t2 timestamptz := now() - interval '9 days';
begin
  if exists (select 1 from public.islamic_products) then return; end if;
  select id into bk from orgs where type = 'bank' and is_islamic order by code limit 1;
  select id into bd from sharia_boards where code = 'SHB-C';
  if bk is null or bd is null then return; end if;
  select id into hd from profiles where username = 'sharia.head'; select id into m1 from profiles where username = 'sharia.m1';
  select id into m2 from profiles where username = 'sharia.m2'; select id into m3 from profiles where username = 'sharia.m3';
  select id into m4 from profiles where username = 'sharia.m4'; select id into sec from profiles where username = 'sharia.sec';

  c_mrb := $j$[
    {"n":1,"title":"الأطراف","text":"الطرف الأول (البائع): {{bank_name}}، ويمثله المخوّل بالتوقيع. الطرف الثاني (المشتري): {{borrower_name}}، رقم البطاقة الوطنية {{borrower_nid}}."},
    {"n":2,"title":"التمهيد والوعد بالشراء","text":"تقدّم المشتري بطلب شراء ووعد بشراء المنظومة الموصوفة في هذا العقد، ووعده غير ملزم له. واشترى البائع المنظومة من المورد {{supplier}} لنفسه، وصدرت فاتورتها باسمه، واستلمها بموجب محضر قبض قبل هذا العقد. وللبائع في عقده مع المورد خيار الشرط يحمي به نفسه إن عدل المشتري."},
    {"n":3,"title":"المبيع","text":"منظومة طاقة شمسية: {{asset}}، بمكوّناتها وأرقامها التسلسلية المذكورة في عرض المورد ومحضر القبض الملحقين بهذا العقد، تُركَّب في {{place}}."},
    {"n":4,"title":"الثمن","text":"رأس مال المبيع (كلفة شرائه على البائع) {{cost}} دينار، والربح المعلوم {{profit}} دينار، فيكون ثمن البيع {{price_total}} دينار. والثمن ثابت لا يزيد بعد هذا العقد لأي سبب."},
    {"n":5,"title":"السداد","text":"يُدفع الثمن على {{term}} قسطاً شهرياً متساوياً، قيمة كل قسط {{installment}} دينار، يُستحق أولها بعد شهر من تسليم المنظومة."},
    {"n":6,"title":"انتقال الملك وتبعة التلف","text":"يملك المشتري المبيع بتمام هذا العقد، ويتحمّل تبعة هلاكه بعد قبضه. وما يتلف قبل التسليم فعلى البائع."},
    {"n":7,"title":"التأخر في السداد","text":"لا يُضاف إلى الثمن أي مبلغ بسبب التأخر أو التأجيل. وللبائع المطالبة بالأقساط المستحقة والرجوع إلى الضمانات بقدر الدين."},
    {"n":8,"title":"الضمانات","text":"يقدّم المشتري الضمان المختار في طلبه (كفالة راتب أو رهن ذهب أو رهن عقار) ضماناً للثمن المؤجل، ولا يُستوفى منه إلا قدر الدين المستحق."},
    {"n":9,"title":"السداد المبكر","text":"للمشتري تعجيل ما بقي من الأقساط. وما يتنازل عنه البائع من الربح عند التعجيل تبرّع منه غير مشروط في هذا العقد."},
    {"n":10,"title":"المرجعية الشرعية","text":"صيغ هذا العقد على {{madhhab}}، واعتمدته {{board}} بالقرار {{resolution}}. وأي تعديل في نصه يحتاج اعتماداً جديداً من الهيئة."}]$j$::jsonb;
  c_ijm := $j$[
    {"n":1,"title":"الأطراف","text":"المؤجر: {{bank_name}}. المستأجر: {{borrower_name}}، رقم البطاقة الوطنية {{borrower_nid}}."},
    {"n":2,"title":"العين المؤجرة","text":"منظومة طاقة شمسية {{asset}} يملكها المؤجر، اشتراها من {{supplier}} وسُجّلت باسمه، وتُركَّب في {{place}}."},
    {"n":3,"title":"المدة والأجرة","text":"مدة الإجارة {{term}} شهراً تبدأ من تاريخ تسليم المنظومة للمستأجر، والأجرة {{installment}} دينار لكل شهر، معلومة لا تتغير طوال المدة."},
    {"n":4,"title":"شرط التمليك","text":"يشترط المستأجر على المؤجر ضمن هذا العقد أن يبيعه المنظومة بثمن رمزي قدره {{residual}} دينار بعد سداد آخر أجرة، ويُكتب البيع عقداً مستقلاً في حينه."},
    {"n":5,"title":"ضمان العين","text":"ضمان تلف المنظومة على المؤجر لأنه مالكها، ما لم يتعدَّ المستأجر أو يفرّط. فإن تلفت بغير تعدٍّ ولا تفريط سقطت الأجرة عن المدة الباقية."},
    {"n":6,"title":"الصيانة والتأمين","text":"الصيانة الأساسية والتأمين على المؤجر، والصيانة التشغيلية (التنظيف والاستعمال المعتاد) على المستأجر."},
    {"n":7,"title":"التأخر في السداد","text":"لا تُضاف إلى الأجرة أي زيادة بسبب التأخر. وللمؤجر المطالبة بالأجرة المستحقة والرجوع إلى الضمانات بقدرها."},
    {"n":8,"title":"الضمانات","text":"يقدّم المستأجر الضمان المختار في طلبه ضماناً للأجرة، ولا يُستوفى منه إلا قدر المستحق."},
    {"n":9,"title":"المرجعية الشرعية","text":"صيغ هذا العقد على {{madhhab}}، واعتمدته {{board}} بالقرار {{resolution}}."}]$j$::jsonb;
  c_msn1 := $j$[
    {"n":1,"title":"الأطراف","text":"الشريك الأول: {{bank_name}}. الشريك الثاني: {{borrower_name}}."},
    {"n":2,"title":"نوع الشركة","text":"شركة بين الطرفين في ملكية منظومة الطاقة الشمسية للمصنع، لكل منهما حصة بقدر ما دفع."},
    {"n":3,"title":"انتقال الحصص","text":"تنتقل حصة المصرف إلى الشريك الثاني تلقائياً بنسبة ما يسدّده كل شهر."},
    {"n":4,"title":"الربح","text":"يحصل المصرف على ربح ثابت قدره {{profit}} دينار طوال المدة."},
    {"n":5,"title":"الخسارة","text":"يتحمّل الشريك الثاني أي خسارة في المشروع."},
    {"n":6,"title":"التأخر في السداد","text":"لا زيادة على المتأخر لمصلحة المصرف، وللمصرف المطالبة والرجوع إلى الضمانات."}]$j$::jsonb;
  c_msn2 := $j$[
    {"n":1,"title":"الأطراف","text":"الشريك الأول: {{bank_name}}. الشريك الثاني: {{borrower_name}}."},
    {"n":2,"title":"نوع الشركة","text":"شركة أموال (عنان) بين الطرفين في ملكية منظومة الطاقة الشمسية للمصنع، رأس مالها {{cost}} دينار، لكل منهما حصة بقدر ما دفع من المال."},
    {"n":3,"title":"شراء الحصص","text":"يشتري الشريك الثاني حصة المصرف على دفعات، وكل دفعة بعقد بيع مستقل بثمن يُتفق عليه عند البيع، ولا تنتقل حصة بغير عقد."},
    {"n":4,"title":"تأجير حصة المصرف","text":"يستأجر الشريك الثاني حصة المصرف الباقية بأجرة شهرية معلومة تنقص بقدر ما اشتراه من الحصص."},
    {"n":5,"title":"الربح والخسارة","text":"ما ينتج عن المنظومة للشريكين بنسبة ملكيتهما، والخسارة على كل شريك بقدر حصته من رأس المال، ما لم يتعدَّ أحدهما أو يفرّط."},
    {"n":6,"title":"التأخر في السداد","text":"لا زيادة على المتأخر لمصلحة المصرف، وللمصرف المطالبة والرجوع إلى الضمانات بقدر الدين."},
    {"n":7,"title":"المرجعية الشرعية","text":"صيغ هذا العقد على {{madhhab}}، ويحتاج اعتماد {{board}} قبل العمل به."}]$j$::jsonb;
  c_vet := $j$[
    {"n":1,"title":"الأطراف","text":"البائع: {{bank_name}}. المشتري: الطبيب البيطري {{borrower_name}}."},
    {"n":2,"title":"المبيع","text":"أجهزة العيادة البيطرية المذكورة في عرض المورد {{supplier}}."},
    {"n":3,"title":"الثمن","text":"الكلفة {{cost}} دينار والربح {{profit}} دينار، والثمن {{price_total}} دينار ثابت."},
    {"n":4,"title":"السداد","text":"{{term}} قسطاً شهرياً، كل قسط {{installment}} دينار."},
    {"n":5,"title":"التأخر في السداد","text":"لا زيادة على المتأخر لمصلحة المصرف."}]$j$::jsonb;
  c_slm := $j$[
    {"n":1,"title":"الأطراف","text":"المشتري (المسلِم): {{bank_name}}. البائع (المسلَم إليه): {{borrower_name}}."},
    {"n":2,"title":"الثمن","text":"يدفع المصرف الثمن كاملاً في مجلس العقد."},
    {"n":3,"title":"المسلَم فيه","text":"التمور المعدّة للتصدير: النوع، الكمية بالطن، درجة الجودة، والتعبئة — تُكتب في ملحق المواصفات."},
    {"n":4,"title":"الأجل ومكان التسليم","text":"يُسلَّم المسلَم فيه في موعد معلوم في مخزن المصرف المعتمد."},
    {"n":5,"title":"التأخر في التسليم","text":"لا يُفرض على البائع أي مبلغ مالي لمصلحة المصرف بسبب التأخر، وللمصرف المطالبة بالتسليم أو فسخ العقد واسترداد الثمن نفسه دون زيادة."}]$j$::jsonb;

  -- (1) المرابحة — معتمد
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, submitted_at, created_at, updated_at)
  values ('IP-2026-0001', bk, bd, 'MRB', 'منظومتي بالمرابحة', 'pv', 'individuals', 'يشتري المصرف المنظومة ثم يبيعها لك بربح معلوم تدفعه أقساطاً',
    '{"profit_min": 4, "profit_max": 9, "term_min": 12, "term_max": 60}', '{single_salary,multi_salary,mortgage,gold}', '{طلب شراء ووعد غير ملزم,محضر قبض واستلام,جدول الأقساط}',
    'approved', t1 - interval '6 days', t1 - interval '8 days', t1) returning id into p1;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p1, 1, c_mrb, _sh_sha(c_mrb), 'approved', 'النسخة الأولى', 'رقية عادل الشمري', t1 - interval '8 days') returning id into v;
  update islamic_products set current_version_id = v, approved_version_id = v where id = p1;
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, at) values
    (p1, v, hd, 'الشيخ د. محمد جعفر الحكيم', true, 'approve', t1 - interval '1 day'), (p1, v, m1, 'السيد د. علي حسن الموسوي', false, 'approve', t1 - interval '2 days'),
    (p1, v, m2, 'د. زينب عبد الرضا الياسري', false, 'approve', t1 - interval '2 days'), (p1, v, m3, 'الشيخ حيدر كاظم الخفاجي', false, 'approve', t1 - interval '1 day');
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body, resolved, created_at) values
    (p1, v, 2, m1, 'السيد د. علي حسن الموسوي', 'board', 'يُثبت في البند صراحةً أن الوعد غير ملزم وأن البيع لا ينعقد قبل قبض المصرف للمنظومة — وهو مثبت. لا ملاحظة.', true, t1 - interval '4 days');
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, votes, dissent, version_sha256, seal, signed_by, signed_by_name, signed_via, issued_at)
  values ('SH-2026-00001', bd, p1, v, 'approved', 'اعتمدت الهيئة المنتج «منظومتي بالمرابحة» ونموذج عقده بالنسخة 1 على المذهب الجعفري.',
    '{"approve": 4, "approve_cond": 0, "reject": 0, "cast": 4, "members": 5, "quorum": 3, "quorum_ok": true, "proposed": "approved"}', '[]', _sh_sha(c_mrb),
    encode(extensions.digest('SH-2026-00001|' || _sh_sha(c_mrb) || '|approved', 'sha256'), 'hex'), hd, 'الشيخ د. محمد جعفر الحكيم', 'رمز تحقق على هاتف الرئيس', t1) returning id into r1;
  update islamic_products set resolution_id = r1, review_due = (t1 + interval '12 months')::date where id = p1;
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values
    (p1, t1 - interval '8 days', 'رقية عادل الشمري', 'bank', 'إنشاء المنتج', null), (p1, t1 - interval '6 days', 'رقية عادل الشمري', 'bank', 'تقديم للهيئة — النسخة 1', null),
    (p1, t1 - interval '5 days', 'م. سارة فاضل الربيعي', 'board', 'إحالة للأعضاء للمداولة والتصويت', 'الملف مكتمل'),
    (p1, t1, 'الشيخ د. محمد جعفر الحكيم', 'board', 'قرار SH-2026-00001: اعتماد', null);

  -- (2) الإجارة المنتهية بالتمليك — معتمد بشرط
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, submitted_at, created_at, updated_at)
  values ('IP-2026-0002', bk, bd, 'IJM', 'منظومتي بالإجارة المنتهية بالتمليك', 'pv', 'individuals', 'يملك المصرف المنظومة ويؤجّرها لك، وتصير ملكك بعد آخر قسط',
    '{"profit_min": 4, "profit_max": 9, "term_min": 24, "term_max": 60}', '{single_salary,multi_salary,mortgage}', '{عقد الإجارة,محضر التسليم,جدول الأجرة,نموذج عقد البيع الرمزي}',
    'conditional', t2 - interval '5 days', t2 - interval '7 days', t2) returning id into p2;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p2, 1, c_ijm, _sh_sha(c_ijm), 'approved', 'النسخة الأولى', 'رقية عادل الشمري', t2 - interval '7 days') returning id into v;
  update islamic_products set current_version_id = v, approved_version_id = v where id = p2;
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, condition, reason, at) values
    (p2, v, hd, 'الشيخ د. محمد جعفر الحكيم', true, 'approve', null, null, t2 - interval '1 day'),
    (p2, v, m1, 'السيد د. علي حسن الموسوي', false, 'approve_cond', 'يُكتب البيع بالثمن الرمزي آخر المدة عقداً مستقلاً بإيجاب وقبول جديدين، ولا يُكتفى بالشرط', null, t2 - interval '2 days'),
    (p2, v, m2, 'د. زينب عبد الرضا الياسري', false, 'approve', null, null, t2 - interval '2 days'),
    (p2, v, m4, 'د. أحمد ناجي العبودي', false, 'reject', null, 'أرى أن تُفصل وثيقة التأمين عن عقد الإجارة في ملحق مستقل قبل الاعتماد', t2 - interval '1 day');
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body, resolved, created_at) values
    (p2, v, 4, m1, 'السيد د. علي حسن الموسوي', 'board', 'الشرط صحيح ضمن الإجارة، لكن البيع نفسه يحتاج عقداً مستقلاً عند انتهاء المدة.', true, t2 - interval '3 days');
  insert into sharia_resolutions(code, board_id, product_id, version_id, decision, body, conditions, votes, dissent, version_sha256, seal, signed_by, signed_by_name, signed_via, issued_at)
  values ('SH-2026-00002', bd, p2, v, 'conditional', 'اعتمدت الهيئة المنتج «منظومتي بالإجارة المنتهية بالتمليك» ونموذج عقده بالنسخة 1 بالشروط المذكورة، على المذهب الجعفري.',
    '• السيد د. علي حسن الموسوي: يُكتب البيع بالثمن الرمزي آخر المدة عقداً مستقلاً بإيجاب وقبول جديدين، ولا يُكتفى بالشرط',
    '{"approve": 2, "approve_cond": 1, "reject": 1, "cast": 4, "members": 5, "quorum": 3, "quorum_ok": true, "proposed": "conditional"}',
    '[{"name": "د. أحمد ناجي العبودي", "vote": "reject", "reason": "أرى أن تُفصل وثيقة التأمين عن عقد الإجارة في ملحق مستقل قبل الاعتماد"}]', _sh_sha(c_ijm),
    encode(extensions.digest('SH-2026-00002|' || _sh_sha(c_ijm) || '|conditional', 'sha256'), 'hex'), hd, 'الشيخ د. محمد جعفر الحكيم', 'رمز تحقق على هاتف الرئيس', t2) returning id into r2;
  update islamic_products set resolution_id = r2, review_due = (t2 + interval '12 months')::date,
    status_note = 'يُكتب البيع بالثمن الرمزي آخر المدة عقداً مستقلاً' where id = p2;
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values
    (p2, t2 - interval '5 days', 'رقية عادل الشمري', 'bank', 'تقديم للهيئة — النسخة 1', null),
    (p2, t2 - interval '4 days', 'م. سارة فاضل الربيعي', 'board', 'إحالة للأعضاء للمداولة والتصويت', null),
    (p2, t2, 'الشيخ د. محمد جعفر الحكيم', 'board', 'قرار SH-2026-00002: اعتماد مشروط', null);

  -- (3) المشاركة المتناقصة — قيد المداولة: النسخة 1 وتعليقاتها، والنسخة 2 المعدّلة، وصوتان عليها
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, submitted_at, created_at, updated_at)
  values ('IP-2026-0003', bk, bd, 'MSN', 'مشاركة المصنع', 'pv', 'industry', 'تشارك المصرف في ملكية منظومة مصنعك، وتشتري حصته شيئاً فشيئاً',
    '{"profit_min": 5, "profit_max": 10, "term_min": 24, "term_max": 84}', '{mortgage}', '{عقد الشركة,نموذج عقد بيع الحصة,عقد إجارة الحصة,جدول الحصص}',
    'deliberation', now() - interval '6 days', now() - interval '7 days', now() - interval '3 hours') returning id into p3;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p3, 1, c_msn1, _sh_sha(c_msn1), 'superseded', 'النسخة الأولى', 'رقية عادل الشمري', now() - interval '7 days') returning id into v;
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body, resolved, created_at) values
    (p3, v, 2, m1, 'السيد د. علي حسن الموسوي', 'board', 'يُنص على أنها شركة أموال (عنان)، لأن شركات الأبدان والوجوه والمفاوضة باطلة عند الإمامية.', true, now() - interval '4 days'),
    (p3, v, 3, m2, 'د. زينب عبد الرضا الياسري', 'board', 'انتقال الحصص «تلقائياً» لا يصح؛ كل شراء لحصة يحتاج عقد بيع مستقلاً.', true, now() - interval '4 days'),
    (p3, v, 4, hd, 'الشيخ د. محمد جعفر الحكيم', 'board', 'الربح الثابت المقطوع لا يصح في الشركة. الناتج بنسبة الملكية، وللمصرف أجرة حصته إن أجّرها.', true, now() - interval '4 days'),
    (p3, v, 5, m1, 'السيد د. علي حسن الموسوي', 'board', 'الخسارة على قدر رأس المال لا على الشريك الثاني وحده.', true, now() - interval '4 days');
  insert into sharia_reviews(product_id, version_id, clause_n, parent_id, author_id, author_name, author_side, body, created_at)
  select p3, v, clause_n, id, null, 'رقية عادل الشمري', 'bank', 'عُدّل في النسخة 2.', now() - interval '2 days' from sharia_reviews where version_id = v;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p3, 2, c_msn2, _sh_sha(c_msn2), 'submitted', 'عُدّلت البنود 2 و3 و5، وحُذف الربح الثابت وأُضيف بند تأجير حصة المصرف والمرجعية الشرعية', 'رقية عادل الشمري', now() - interval '2 days') returning id into v2;
  update islamic_products set current_version_id = v2 where id = p3;
  insert into sharia_reviews(product_id, version_id, clause_n, author_id, author_name, author_side, body, created_at) values
    (p3, v2, 4, m3, 'الشيخ حيدر كاظم الخفاجي', 'board', 'تُحدَّد الأجرة في جدول ملحق لكل فترة حتى تكون معلومة عند العقد.', now() - interval '3 hours');
  insert into sharia_votes(product_id, version_id, member_id, member_name, is_head, vote, condition, at) values
    (p3, v2, m1, 'السيد د. علي حسن الموسوي', false, 'approve', null, now() - interval '1 day'),
    (p3, v2, m2, 'د. زينب عبد الرضا الياسري', false, 'approve_cond', 'يُلحق جدول الأجرة لكل فترة بالعقد قبل التوقيع', now() - interval '20 hours');
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values
    (p3, now() - interval '6 days', 'رقية عادل الشمري', 'bank', 'تقديم للهيئة — النسخة 1', null),
    (p3, now() - interval '5 days', 'م. سارة فاضل الربيعي', 'board', 'إحالة للأعضاء للمداولة والتصويت', null),
    (p3, now() - interval '4 days', 'السيد د. علي حسن الموسوي', 'board', 'تعليق على البند 2', null),
    (p3, now() - interval '2 days', 'رقية عادل الشمري', 'bank', 'حفظ نص العقد — النسخة 2', 'عُدّلت البنود 2 و3 و5'),
    (p3, now() - interval '1 day', 'السيد د. علي حسن الموسوي', 'board', 'تصويت: موافق', null),
    (p3, now() - interval '20 hours', 'د. زينب عبد الرضا الياسري', 'board', 'تصويت: موافق بشرط', 'يُلحق جدول الأجرة لكل فترة بالعقد قبل التوقيع');

  -- (4) أجهزة العيادة بالمرابحة — أعاده أمين السر لنقص الملف
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, status_note, submitted_at, created_at, updated_at)
  values ('IP-2026-0004', bk, bd, 'MRB', 'أجهزة العيادة بالمرابحة', 'vet', 'clinic', 'يشتري المصرف أجهزة عيادتك ثم يبيعها لك بربح معلوم تدفعه أقساطاً',
    '{"profit_min": 4, "profit_max": 8, "term_max": 60}', '{single_salary,mortgage}', '{عرض المورد}', 'returned',
    'الملف ناقص: لا يوجد بند «التمهيد والوعد بالشراء» ولا بند تملّك المصرف وقبضه قبل البيع، ولم تُرفق نماذج طلب الشراء ومحضر القبض وجدول الأقساط.',
    now() - interval '3 days', now() - interval '4 days', now() - interval '2 days') returning id into p4;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p4, 1, c_vet, _sh_sha(c_vet), 'returned', 'النسخة الأولى', 'رقية عادل الشمري', now() - interval '4 days') returning id into v;
  update islamic_products set current_version_id = v where id = p4;
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values
    (p4, now() - interval '3 days', 'رقية عادل الشمري', 'bank', 'تقديم للهيئة — النسخة 1', null),
    (p4, now() - interval '2 days', 'م. سارة فاضل الربيعي', 'board', 'إعادة للمصرف لاستكمال الملف', 'لا يوجد بند الوعد بالشراء ولا بند تملّك المصرف وقبضه، ولم تُرفق النماذج');

  -- (5) سَلَم التصدير — مسودة لدى المصرف (لا تراها الهيئة)
  insert into islamic_products(code, bank_id, board_id, contract_type, name, sector, subsector, line, pricing, guarantees, attachments, status, created_at, updated_at)
  values ('IP-2026-0005', bk, bd, 'SLM', 'سَلَم التصدير', 'exim', 'exporter', 'يدفع لك المصرف ثمن بضاعتك الآن، وتسلّمه إياها قبل الشحن في موعد معلوم',
    '{"term_min": 3, "term_max": 12}', '{mortgage}', '{}', 'draft', now() - interval '1 day', now() - interval '1 day') returning id into p5;
  insert into islamic_contract_versions(product_id, n, clauses, sha256, status, change_note, created_by_name, created_at)
  values (p5, 1, c_slm, _sh_sha(c_slm), 'draft', null, 'رقية عادل الشمري', now() - interval '1 day') returning id into v;
  update islamic_products set current_version_id = v where id = p5;
  insert into sharia_log(product_id, at, actor_name, actor_side, action, note) values (p5, now() - interval '1 day', 'رقية عادل الشمري', 'bank', 'إنشاء المنتج', null);

  -- إشعارات العرض: أمين السر والأعضاء
  insert into notifications(user_id, kind, title, body, ref_id) values
    (hd, 'sharia_review', 'نسخة معدّلة 2 من عقد: مشاركة المصنع', 'الأصوات السابقة لا تسري على النسخة الجديدة — راجع الفروق وصوّت', p3),
    (m3, 'sharia_review', 'نسخة معدّلة 2 من عقد: مشاركة المصنع', 'الأصوات السابقة لا تسري على النسخة الجديدة — راجع الفروق وصوّت', p3),
    (m4, 'sharia_review', 'نسخة معدّلة 2 من عقد: مشاركة المصنع', 'الأصوات السابقة لا تسري على النسخة الجديدة — راجع الفروق وصوّت', p3);
end $$;
