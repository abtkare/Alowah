-- الجلسة 24: إجراء واضح للمقترض في المحطة الرابعة «وقّع عقدك من هاتفك» (المراحل 25–29)
-- 1) المقترض يطلب من الفرع بزر واحد: رابط توقيع جديد / أن يوقّع حضورياً — يصل الطلب إلى الفرع إشعاراً
-- 2) إشعار الفرع فور توقيع المقترض إلكترونياً ليدقق العقد وينجز المرحلة 25
-- آمن للتكرار

create or replace function public.esign_borrower_ask(p_app uuid, p_kind text) returns jsonb
language plpgsql security definer set search_path to 'public' as $f$
declare a applications; r esign_requests; act text; t text; b text; last_at timestamptz;
begin
  if p_kind not in ('link', 'branch') then raise exception 'طلب غير معروف'; end if;
  select * into a from applications where id = p_app and citizen_id = auth.uid() for update;
  if a.id is null then raise exception 'الطلب لا يخصك'; end if;
  if a.stage <> 25 or a.status not in ('active', 'returned') then raise exception 'طلبك ليس في مرحلة توقيع العقد'; end if;
  select * into r from esign_requests where application_id = a.id and status <> 'superseded' order by created_at desc limit 1;
  if r.status = 'completed' then raise exception 'وقّعت عقدك مسبقاً — لا شيء مطلوب منك'; end if;
  if p_kind = 'link' and r.status = 'sent' and r.expires_at > now() then raise exception 'رابط التوقيع صالح الآن — اضغط «وقّع عقدك الآن»'; end if;
  act := case p_kind when 'link' then 'طلب المقترض رابط توقيع إلكتروني للعقد' else 'أبلغ المقترض أنه سيوقّع العقد حضورياً في الفرع' end;
  select max(created_at) into last_at from application_events where application_id = a.id and action = act;
  if last_at > now() - interval '6 hours' then
    return jsonb_build_object('ok', true, 'repeat', true, 'at', last_at);
  end if;
  perform _ev(a.id, a.stage, act, null);
  if p_kind = 'link' then
    t := 'المقترض يطلب رابط توقيع العقد — ' || a.code;
    b := 'يريد المقترض توقيع عقد التمويل والكمبيالة من هاتفه' || case when r.status is not null then ' (حالة الطلب السابق: ' ||
      case r.status when 'expired' then 'انتهت صلاحيته' when 'cancelled' then 'أُلغي' when 'failed' then 'تعذّر' when 'manual_review' then 'اختار الفرع ثم غيّر رأيه' else r.status end || ')' else '' end ||
      ' — افتح المعاملة وأرسل العقد للتوقيع الإلكتروني.';
  else
    t := 'المقترض سيوقّع العقد في الفرع — ' || a.code;
    b := 'أبلغ المقترض أنه سيراجع الفرع لتوقيع العقد والكمبيالة حضورياً — جهّز العقد.';
  end if;
  perform _notify(a.bank_id, 'bank', 'esign_ask', t, b, a.id);
  update applications set updated_at = now() where id = a.id;
  return jsonb_build_object('ok', true, 'at', now());
end $f$;
revoke all on function public.esign_borrower_ask(uuid, text) from public, anon;
grant execute on function public.esign_borrower_ask(uuid, text) to authenticated;

-- إشعار الفرع عند توقيع المقترض
create or replace function public._esign_done_notify() returns trigger
language plpgsql security definer set search_path to 'public' as $f$
declare a applications;
begin
  if new.status = 'completed' and old.status is distinct from 'completed' then
    select * into a from applications where id = new.application_id;
    if a.id is not null then
      perform _notify(a.bank_id, 'bank', 'esign_done', 'وقّع المقترض العقد إلكترونياً — ' || a.code,
        'العقد الموقّع في «المستندات». دقّقه وأنجز المرحلة 25 لينتقل الطلب إلى مدير الفرع.', a.id);
    end if;
  end if;
  return new;
end $f$;
drop trigger if exists trg_esign_done_notify on esign_requests;
create trigger trg_esign_done_notify after update of status on esign_requests for each row execute function _esign_done_notify();
