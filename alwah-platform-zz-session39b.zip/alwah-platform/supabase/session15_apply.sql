-- ═══════════════════════════════════════════════════════════════════════
-- الجلسة 15: التوقيع الإلكتروني لعقد التمويل والكمبيالة (المرحلة 25) — «بوابة المقترض»
--   • موظف خدمة الزبائن يرفق الصورة المرجعية لوجه المقترض ثم يرسل العقد للتوقيع الإلكتروني
--   • المقترض يوقّع من هاتفه: قراءة العقد + موافقة صريحة + التحقق من الوجه وكشف الحيوية + بصمة الجهاز
--   • خدمة التوقيع (على الخادم الخاص) تعيد العقد الموقّع PDF مع شهادة إتمام التوقيع، فيُحفظ في «المستندات»
--   • لا تُنجز المرحلة 25 ما دام طلب توقيع مُرسَل لم يُوقَّع (يمكن إلغاؤه والتوقيع حضورياً في الفرع)
-- الأسرار لا تُكتب في هذا الملف: تُضاف بصماتها مباشرة في قاعدة البيانات.
-- ═══════════════════════════════════════════════════════════════════════

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create table if not exists private.esign_config (
  id int primary key default 1 check (id = 1),
  server_secret_hash text,          -- بصمة السر المشترك بين خادم المنصة وقاعدة البيانات
  pair_hash text,                   -- بصمة رمز الربط المؤقت الذي يستخدمه خادم التوقيع لتسجيل نفسه
  pair_expires timestamptz,
  base_url text,
  api_key text,
  webhook_secret text,
  registered_at timestamptz
);
insert into private.esign_config(id) values (1) on conflict do nothing;

create table if not exists public.esign_requests (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id),
  session_id uuid unique,
  status text not null default 'sent' check (status in ('sent','completed','expired','cancelled','manual_review','failed','superseded')),
  signing_url text,
  expires_at timestamptz,
  document_sha256 text,
  signed_sha256 text,
  certificate_serial text,
  qualified boolean,
  face_doc uuid references public.app_documents(id),
  signed_doc uuid references public.app_documents(id),
  created_by uuid,
  created_by_title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz,
  note text
);
create index if not exists esign_requests_app on public.esign_requests(application_id, created_at desc);
-- لا قراءة مباشرة: رابط التوقيع سرّي ولا يظهر إلا للمقترض نفسه عبر esign_my_link
alter table public.esign_requests enable row level security;
revoke all on public.esign_requests from anon, authenticated;

create or replace function public._esign_server_ok(p_secret text) returns boolean
 language sql stable security definer set search_path to 'public', 'extensions', 'private' as $f$
  select coalesce(length(p_secret) >= 32 and encode(extensions.digest(p_secret, 'sha256'), 'hex') = (select server_secret_hash from private.esign_config where id = 1), false)
$f$;
revoke all on function public._esign_server_ok(text) from public, anon, authenticated;

-- خادم التوقيع يسجّل رابطه ومفاتيحه برمز ربط مؤقت (يُستدعى من سكربت التثبيت على الـVPS)
create or replace function public.esign_register(p_pair text, p_base_url text, p_api_key text, p_webhook_secret text) returns jsonb
 language plpgsql security definer set search_path to 'public', 'extensions', 'private' as $f$
declare c private.esign_config;
begin
  select * into c from private.esign_config where id = 1;
  if c.pair_hash is null or c.pair_expires < now() or encode(extensions.digest(coalesce(p_pair, ''), 'sha256'), 'hex') <> c.pair_hash then
    raise exception 'رمز الربط غير صحيح أو منتهي'; end if;
  if p_base_url !~ '^https://[a-z0-9.-]+(:[0-9]+)?$' or length(p_api_key) < 32 or length(p_webhook_secret) < 24 then
    raise exception 'بيانات غير صالحة'; end if;
  update private.esign_config set base_url = p_base_url, api_key = p_api_key, webhook_secret = p_webhook_secret, registered_at = now() where id = 1;
  return jsonb_build_object('ok', true, 'base_url', p_base_url);
end $f$;
grant execute on function public.esign_register(text, text, text, text) to anon, authenticated;

-- إعدادات الخدمة لخادم المنصة فقط (بالسر المشترك)
create or replace function public.esign_config(p_secret text) returns jsonb
 language plpgsql security definer set search_path to 'public', 'extensions', 'private' as $f$
declare c private.esign_config;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into c from private.esign_config where id = 1;
  return jsonb_build_object('base_url', c.base_url, 'api_key', c.api_key, 'webhook_secret', c.webhook_secret, 'registered_at', c.registered_at);
end $f$;
grant execute on function public.esign_config(text) to anon, authenticated;

-- آخر طلب توقيع (دون الرابط) — للمقترض وموظفي مصرفه والجهات الرقابية
create or replace function public.esign_status(p_app uuid) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; me profiles; r esign_requests; face uuid;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  if not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('cbi','integrity','admin')) then raise exception 'غير مخوّل'; end if;
  select * into r from esign_requests where application_id = p_app order by created_at desc limit 1;
  select id into face from app_documents where application_id = p_app and kind = 'kyc_face' order by created_at desc limit 1;
  if r.status = 'sent' and r.expires_at < now() then r.status := 'expired'; end if;
  return jsonb_build_object('face_doc', face, 'request', case when r.id is null then null else jsonb_build_object(
    'id', r.id, 'status', r.status, 'expires_at', r.expires_at, 'created_at', r.created_at, 'created_by_title', r.created_by_title,
    'completed_at', r.completed_at, 'signed_doc', r.signed_doc, 'certificate_serial', r.certificate_serial, 'qualified', r.qualified,
    'document_sha256', r.document_sha256, 'signed_sha256', r.signed_sha256, 'note', r.note) end);
end $f$;
grant execute on function public.esign_status(uuid) to authenticated;

-- رابط التوقيع للمقترض نفسه فقط
create or replace function public.esign_my_link(p_app uuid) returns text
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r esign_requests;
begin
  if not exists (select 1 from applications where id = p_app and citizen_id = auth.uid()) then raise exception 'الطلب لا يخصك'; end if;
  select * into r from esign_requests where application_id = p_app and status = 'sent' and expires_at > now() order by created_at desc limit 1;
  if r.id is null then raise exception 'لا يوجد عقد بانتظار توقيعك الآن'; end if;
  return r.signing_url;
end $f$;
grant execute on function public.esign_my_link(uuid) to authenticated;

-- بيانات العقد لخادم المنصة: يُستدعى بجلسة موظف خدمة الزبائن نفسه (الصلاحية تُفحص هنا)
create or replace function public.esign_prepare(p_app uuid) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare a applications; me profiles; c profiles; r esign_requests; fd app_documents;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  if me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'الطلب لا يخص مصرفك'; end if;
  if me.role not in ('bank_cs','bank_branch_mgr') then raise exception 'إرسال العقد للتوقيع من صلاحية خدمة الزبائن — العمليات الائتمانية'; end if;
  if me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.status not in ('active','returned') or a.stage <> 25 then raise exception 'التوقيع الإلكتروني للعقد في المرحلة 25 فقط'; end if;
  select * into c from profiles where id = a.citizen_id;
  select * into r from esign_requests where application_id = a.id order by created_at desc limit 1;
  select * into fd from app_documents where application_id = a.id and kind = 'kyc_face' order by created_at desc limit 1;
  return jsonb_build_object(
    'app', to_jsonb(a) - 'kyc',
    'borrower', jsonb_build_object('id', c.id, 'full_name', c.full_name, 'phone', c.phone, 'national_id', c.national_id,
      'governorate', c.governorate, 'city', c.city, 'address', c.address, 'employer', c.employer, 'mother_name', c.mother_name, 'birth_date', c.birth_date),
    'bank', (select name from orgs where id = a.bank_id),
    'branch', (select name from branches where id = a.branch_id),
    'supplier', (select name from orgs where id = a.supplier_id),
    'staff', jsonb_build_object('id', me.id, 'title', _role_title(me.role), 'code', me.staff_code),
    'face', case when fd.id is null then null else jsonb_build_object('id', fd.id, 'data', fd.data) end,
    'request', case when r.id is null then null else jsonb_build_object('id', r.id, 'session_id', r.session_id, 'status',
      case when r.status = 'sent' and r.expires_at < now() then 'expired' else r.status end) end);
end $f$;
grant execute on function public.esign_prepare(uuid) to authenticated;

-- تسجيل طلب التوقيع بعد إنشائه لدى خدمة التوقيع (خادم المنصة بالسر المشترك + جلسة الموظف)
create or replace function public.esign_record(p_secret text, p_app uuid, p_data jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare a applications; me profiles; rid uuid;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  update esign_requests set status = 'superseded', updated_at = now() where application_id = a.id and status = 'sent';
  insert into esign_requests(application_id, session_id, status, signing_url, expires_at, document_sha256, face_doc, created_by, created_by_title)
  values (a.id, (p_data->>'session_id')::uuid, 'sent', p_data->>'signing_url', (p_data->>'expires_at')::timestamptz, p_data->>'document_sha256',
    nullif(p_data->>'face_doc', '')::uuid, me.id, _role_title(me.role))
  returning id into rid;
  perform _ev(a.id, a.stage, 'إرسال عقد التمويل والكمبيالة إلى المقترض للتوقيع الإلكتروني',
    'يوقّع المقترض من هاتفه: قراءة العقد والموافقة، التحقق من الوجه وكشف الحيوية، ثم بصمة الجهاز — بصمة العقد ' || left(coalesce(p_data->>'document_sha256', ''), 16));
  return jsonb_build_object('id', rid);
end $f$;
grant execute on function public.esign_record(text, uuid, jsonb) to authenticated;

-- أحداث خدمة التوقيع (Webhook) والإلغاء من الموظف
create or replace function public.esign_apply(p_secret text, p_session uuid, p_event text, p_data jsonb default '{}'::jsonb, p_pdf text default null) returns jsonb
 language plpgsql security definer set search_path to 'public', 'extensions' as $f$
declare r esign_requests; a applications; c profiles; did uuid; act text; nt text;
begin
  if not _esign_server_ok(p_secret) then raise exception 'غير مخوّل'; end if;
  select * into r from esign_requests where session_id = p_session for update;
  if r.id is null then return jsonb_build_object('ok', true, 'ignored', 'unknown_session'); end if;
  if r.status in ('completed') then return jsonb_build_object('ok', true, 'ignored', 'already_completed'); end if;
  select * into a from applications where id = r.application_id;
  select * into c from profiles where id = a.citizen_id;

  if p_event = 'signature.completed' then
    if p_pdf is null or p_pdf !~ '^data:application/pdf;base64,' then raise exception 'العقد الموقّع مفقود'; end if;
    insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
    values (a.id, 'contract_signed', 'esign', 'application/pdf', p_pdf, length(p_pdf), encode(extensions.digest(p_pdf, 'sha256'), 'hex'),
      jsonb_build_object('session_id', p_session, 'signed_document_sha256', p_data->>'signed_document_sha256', 'certificate_serial', p_data->>'certificate_serial',
        'qualified', coalesce((p_data->>'qualified_certificate')::boolean, false), 'server_at', now()),
      c.id, 'المقترض — توقيع إلكتروني')
    returning id into did;
    update esign_requests set status = 'completed', signed_doc = did, signed_sha256 = p_data->>'signed_document_sha256', certificate_serial = p_data->>'certificate_serial',
      qualified = coalesce((p_data->>'qualified_certificate')::boolean, false), completed_at = coalesce((p_data->>'completed_at')::timestamptz, now()), updated_at = now()
    where id = r.id;
    act := 'توقيع المقترض عقد التمويل والكمبيالة إلكترونياً';
    nt := 'تحقق من الوجه وكشف الحيوية وبصمة الجهاز — شهادة التوقيع ' || coalesce(p_data->>'certificate_serial', '') ||
      case when coalesce((p_data->>'qualified_certificate')::boolean, false) then '' else ' (جهة تصديق تجريبية)' end || ' — العقد الموقّع في «المستندات»';
  elsif p_event in ('session.expired','session.cancelled','session.manual_review','session.failed') then
    update esign_requests set status = case p_event when 'session.expired' then 'expired' when 'session.cancelled' then 'cancelled'
      when 'session.manual_review' then 'manual_review' else 'failed' end, note = coalesce(p_data->>'note', note), updated_at = now() where id = r.id;
    if r.status <> 'sent' then return jsonb_build_object('ok', true); end if;
    act := case p_event when 'session.expired' then 'انتهت صلاحية رابط التوقيع الإلكتروني دون توقيع'
      when 'session.cancelled' then 'إلغاء طلب التوقيع الإلكتروني' when 'session.manual_review' then 'طلب المقترض توقيع العقد حضورياً في الفرع'
      else 'تعذّر إتمام التوقيع الإلكتروني' end;
    nt := p_data->>'note';
  else return jsonb_build_object('ok', true, 'ignored', p_event); end if;

  if auth.uid() is not null then perform _ev(a.id, a.stage, act, nt);
  else
    insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role, actor_title)
    values (a.id, a.stage, act, nt, c.id, c.full_name, 'citizen', 'المقترض — عبر خدمة التوقيع الإلكتروني');
  end if;
  update applications set updated_at = now() where id = a.id;
  return jsonb_build_object('ok', true, 'doc', did);
end $f$;
grant execute on function public.esign_apply(text, uuid, text, jsonb, text) to anon, authenticated;

-- موظف المصرف يرفق «الصورة المرجعية لوجه المقترض» (صورة البطاقة الوطنية أو صورة حضورية)
do $do$
declare d text; n text;
begin
  d := pg_get_functiondef('public.add_document(uuid,text,text,text,jsonb,uuid)'::regprocedure);
  if position('kyc_face' in d) = 0 then
    n := replace(d, $q$p_kind not in ('evidence','other') then raise exception 'غير مخوّل'$q$, $q$p_kind not in ('evidence','other','kyc_face') then raise exception 'غير مخوّل'$q$);
    if n = d then raise exception 'تعذّر تعديل add_document — النص المتوقع غير موجود'; end if;
    n := replace(n, $q$when 'site' then 'صورة موقع المشروع'$q$, $q$when 'site' then 'صورة موقع المشروع' when 'kyc_face' then 'الصورة المرجعية لوجه المقترض (للتوقيع الإلكتروني)'$q$);
    execute n;
  end if;
end $do$;

-- لا تُنجز المرحلة 25 ما دام العقد مُرسَلاً للتوقيع الإلكتروني ولم يُوقَّع
do $do$
declare d text; n text;
begin
  d := pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure);
  if position('esign_requests' in d) = 0 then
    n := replace(d, $q$    if a.stage = 14 and a.fees_paid_at is null$q$,
      $q$    if a.stage = 25 and exists (select 1 from esign_requests where application_id = a.id and status = 'sent' and expires_at > now()) then
      raise exception 'العقد مُرسَل للمقترض للتوقيع الإلكتروني ولم يوقّعه بعد — انتظر توقيعه أو ألغِ طلب التوقيع ليوقّع حضورياً'; end if;
    if a.stage = 14 and a.fees_paid_at is null$q$);
    if n = d then raise exception 'تعذّر تعديل advance_application — النص المتوقع غير موجود'; end if;
    execute n;
  end if;
end $do$;
