-- ═══════════════════════════════════════════════════════════════════════
-- «ألواح» — الجلسة 26: ديوان الرقابة المالية الاتحادي
-- جهة رقابية حكومية بصلاحية اطلاع وتصدير فقط — لا تكتب على أي معاملة ولا تعدّلها ولا توقفها.
-- يرى ما تراه الجهات الرقابية (البنك المركزي وهيئة النزاهة) من معاملات ومستندات وسجلات تدقيق،
-- مع لوحة وتقارير مالية تناسب دوره: الموقف المالي، الصرف مقابل الإنجاز، العمولات، الأسعار، مؤشرات التدقيق.
-- لا يرى تنبيهات هيئة النزاهة ولا المخاطبات السرية بين الهيئة والبنك المركزي.
-- الملف آمن للتكرار.
-- ═══════════════════════════════════════════════════════════════════════

-- ───────── 1) نوع الجهة والبوابة ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert','audit']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert','audit']));

insert into public.orgs(code, type, name)
select 'fbsa', 'audit', 'ديوان الرقابة المالية الاتحادي'
where not exists (select 1 from public.orgs where type = 'audit');

-- ───────── 2) الدور: مراقب ديوان الرقابة المالية (audit_viewer) ─────────
create or replace function public._role_abbr(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'bank_payroll' then 'PR' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'supplier_tech' then 'TC' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'expert' then 'EX' when 'audit_viewer' then 'FA'
    when 'platform_admin' then 'SA' else 'XX' end $function$;

create or replace function public._role_title(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'bank_payroll' then 'موظف توطين الرواتب — الاستقطاع المباشر'
    when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'supplier_tech' then 'الفني المختص — فريق التركيب لدى المورد'
    when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'expert' then 'خبير معتمد — دراسات الجدوى'
    when 'audit_viewer' then 'مراقب مالي — ديوان الرقابة المالية الاتحادي'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $function$;

create or replace function public._portal_of_role(r text) returns text language sql immutable as $function$
  select case when r like 'bank\_%' then 'bank' when r = 'cbi_admin' then 'cbi' when r = 'registry_officer' then 'registry'
    when r in ('supplier_admin', 'supplier_tech') then 'supplier' when r = 'integrity_viewer' then 'integrity' when r = 'syndicate_officer' then 'syndicate'
    when r = 'vetdept_officer' then 'vetdept' when r = 'platform_admin' then 'admin' when r = 'expert' then 'expert' when r = 'audit_viewer' then 'audit'
    when r = 'citizen' then 'citizen' end $function$;

create or replace function public._org_type_of_portal(p text) returns text language sql immutable as $function$
  select case p when 'bank' then 'bank' when 'cbi' then 'cbi' when 'registry' then 'registry' when 'supplier' then 'supplier'
    when 'integrity' then 'integrity' when 'syndicate' then 'syndicate' when 'vetdept' then 'vetdept' when 'admin' then 'platform' when 'expert' then 'expert'
    when 'audit' then 'audit' end $function$;

create or replace function public._org_roles(p_type text) returns text[] language sql immutable as $function$
  select case p_type
    when 'bank' then array['bank_cs','bank_compliance','bank_branch_mgr','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection',
                           'bank_legal','bank_md','bank_admin','bank_ops','bank_teller','bank_collection','bank_risk','bank_committee','bank_payroll']
    when 'cbi' then array['cbi_admin'] when 'supplier' then array['supplier_admin'] when 'syndicate' then array['syndicate_officer']
    when 'vetdept' then array['vetdept_officer'] when 'registry' then array['registry_officer'] when 'integrity' then array['integrity_viewer']
    when 'expert' then array['expert'] when 'audit' then array['audit_viewer']
    else array[]::text[] end $function$;

-- ───────── 3) صلاحية القراءة: كل سياسة تسمح لهيئة النزاهة بالقراءة تسمح للديوان كذلك ─────────
-- (عدا تنبيهات هيئة النزاهة: تبقى للهيئة والبنك المركزي). كل السياسات هنا قراءة فقط (SELECT).
do $$
declare r record;
begin
  for r in select tablename, policyname, qual from pg_policies
    where schemaname = 'public' and cmd = 'SELECT' and tablename <> 'integrity_alerts'
      and qual like '%''integrity''::text%' and qual not like '%''audit''::text%'
  loop
    execute format('alter policy %I on public.%I using (%s)', r.policyname, r.tablename,
      replace(r.qual, '''integrity''::text', '''integrity''::text, ''audit''::text'));
  end loop;
end $$;

-- ───────── 4) دوال الاطلاع الرقابي: الأداء، السداد، التحليل، ملفات الطلب ─────────
-- تُضاف 'audit' بجانب 'integrity' في شرط الصلاحية فقط — لا تُمس أي دالة تكتب على المعاملات.
do $$
declare f regprocedure; d text;
begin
  foreach f in array array[
    'public._perf_scope(uuid)', 'public._repay_access(public.applications)', 'public.app_expert_refs(uuid)', 'public.cbi_analytics()',
    'public.esign_status(uuid)', 'public.intake_checklist(uuid)', 'public.oversight_repayments()', 'public.referral_dossier(uuid)'
  ]::regprocedure[] loop
    d := pg_get_functiondef(f);
    if position('''audit''' in d) = 0 and position('''integrity''' in d) > 0 then
      execute replace(d, '''integrity''', '''integrity'', ''audit''');
    end if;
  end loop;
end $$;

-- ───────── 5) لوحة الديوان وتقاريره (قراءة فقط) ─────────
-- p_days: الفترة بالأيام (null = منذ البداية) · p_bank: مصرف محدد (null = كل المصارف)
create or replace function public.audit_overview(p_days integer default null, p_bank uuid default null) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $f$
declare me profiles; v_from timestamptz; res jsonb;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or coalesce(me.disabled, false) or me.portal not in ('audit', 'admin') then raise exception 'غير مخوّل'; end if;
  v_from := case when p_days is null then '-infinity'::timestamptz else now() - make_interval(days => p_days) end;

  with a as (
    select x.*, coalesce(x.submitted_at, x.created_at) at_,
      (x.status = 'completed' or x.stage > 35) as is_disb,
      case when x.program = 'vet' then 'vet_program' when x.purpose is null or x.purpose = 'household' then 'residential' else x.purpose end sector,
      coalesce(p.national_id, x.citizen_id::text) who
    from applications x left join profiles p on p.id = x.citizen_id
    where x.bank_id is not null and x.stage >= 6 and coalesce(x.submitted_at, x.created_at) >= v_from
      and (p_bank is null or x.bank_id = p_bank)),
  disb as (   -- المصروف فعلاً للمورد: كامل المبلغ بعد مرحلة الصرف، أو الدفعات المصروفة في المشاريع البيطرية
    select a.id, a.bank_id, case when a.program = 'vet' then coalesce((select sum(t.amount) from vet_tranches t where t.application_id = a.id and t.status = 'paid'), 0)
      when a.is_disb then a.amount else 0 end amt from a),
  pay as (select py.application_id, sum(py.amount) amt from payments py join a on a.id = py.application_id where py.status = 'paid' group by 1),
  inst as (
    select i.application_id, sum(i.amount) due, sum(i.amount) filter (where i.paid_at is not null) paid,
      sum(i.amount) filter (where i.paid_at is null and i.due_date < current_date) late,
      sum(i.amount) filter (where i.paid_at is null and i.due_date < current_date - 90) late90
    from installments i join a on a.id = i.application_id group by 1),
  ppk as (select a.*, a.price::numeric / a.kw ppk from a where coalesce(a.program, '') <> 'vet' and a.kw > 0 and a.price > 0 and a.status <> 'cancelled'),
  med as (select percentile_cont(0.5) within group (order by ppk) m from ppk),
  ex as (
    -- مؤشرات تدقيق محسوبة آلياً من بيانات المعاملات (لا يُدخلها أحد)
    select 'high' sev, 'disb_no_install' rule, a.id app_id, a.code, a.bank_id, a.amount,
      'صُرف المبلغ للمورد دون توثيق موقع التركيب ولا نتيجة الكشف على التركيب' detail
    from a where a.is_disb and coalesce(a.program, '') <> 'vet' and a.install_geo is null and a.inspection_result is null
    union all
    select 'high', 'late90', a.id, a.code, a.bank_id, i.late90, 'أقساط مستحقة غير مسددة منذ أكثر من 90 يوماً'
    from a join inst i on i.application_id = a.id where coalesce(i.late90, 0) > 0
    union all
    select 'medium', 'fees_missing', a.id, a.code, a.bank_id, a.amount, 'تجاوزت المعاملة مرحلة إيداع العمولات (10) دون قيد إيداع أو دفع إلكتروني'
    from a where a.stage > 10 and a.status not in ('cancelled', 'rejected') and a.fees_paid_at is null and not exists (select 1 from pay where pay.application_id = a.id)
    union all
    select 'medium', 'price_high', p.id, p.code, p.bank_id, p.price,
      'سعر الكيلوواط ' || to_char(round(p.ppk), 'FM999,999,999') || ' دينار — أعلى من الوسيط العام بنسبة ' || round((p.ppk / med.m - 1) * 100) || '%'
    from ppk p, med where med.m > 0 and p.ppk > med.m * 1.25
    union all
    select 'medium', 'dup_beneficiary', a.id, a.code, a.bank_id, a.amount,
      'المستفيد نفسه لديه ' || d.n || ' معاملات تمويل قائمة أو مكتملة'
    from a join (select who, count(*) n from a where status not in ('cancelled', 'rejected') group by who having count(*) > 1) d on d.who = a.who
    where a.status not in ('cancelled', 'rejected')
    union all
    select 'low', 'exec_extended', a.id, a.code, a.bank_id, a.amount, 'مُددت مدة التنفيذ ' || a.exec_extensions || ' مرات'
    from a where coalesce(a.exec_extensions, 0) >= 2
    union all
    select 'low', 'fz_rejected', a.id, a.code, a.bank_id, a.amount, 'رُفضت دراسة الجدوى ' || a.feasibility_rejections || ' مرات قبل قبولها أو ما زالت مرفوضة'
    from a where coalesce(a.feasibility_rejections, 0) >= 2
    union all
    select 'medium', 'ledger_gap', null, null, b.bank_id, abs(b.disbursed - coalesce(c.amt, 0)),
      'المصروف المسجل على ائتمان المصرف (' || to_char(b.disbursed, 'FM999,999,999,999') || ') لا يطابق مجموع ما صُرف في المعاملات (' || to_char(coalesce(c.amt, 0), 'FM999,999,999,999') || ')'
    from bank_allocations b left join (select bank_id, sum(amt) amt from disb group by 1) c on c.bank_id = b.bank_id
    where p_days is null and (p_bank is null or b.bank_id = p_bank) and abs(b.disbursed - coalesce(c.amt, 0)) > greatest(1000000, b.disbursed * 0.01)
  )
  select jsonb_build_object(
    'scope', jsonb_build_object('days', p_days, 'bank', p_bank, 'at', now()),
    'totals', jsonb_build_object(
      'allocated', (select coalesce(sum(allocated), 0) from bank_allocations where p_bank is null or bank_id = p_bank),
      'reserved', (select coalesce(sum(reserved), 0) from bank_allocations where p_bank is null or bank_id = p_bank),
      'ledger_disbursed', (select coalesce(sum(disbursed), 0) from bank_allocations where p_bank is null or bank_id = p_bank),
      'recovered', (select coalesce(sum(recovered), 0) from bank_allocations where p_bank is null or bank_id = p_bank),
      'apps', (select count(*) from a), 'completed', (select count(*) from a where status = 'completed'),
      'active', (select count(*) from a where status in ('active', 'returned')),
      'rejected', (select count(*) from a where status = 'rejected'), 'cancelled', (select count(*) from a where status = 'cancelled'),
      'requested', (select coalesce(sum(amount), 0) from a where status <> 'cancelled'),
      'approved', (select coalesce(sum(amount), 0) from a where (stage > 18 or status = 'completed') and status not in ('cancelled', 'rejected')),
      'disbursed', (select coalesce(sum(amt), 0) from disb),
      'kw', (select coalesce(sum(kw), 0) from a where status = 'completed'),
      'fees', (select coalesce(sum(amt), 0) from pay),
      'cbi_fees', (select coalesce(sum(cbi_fee), 0) from a where fees_paid_at is not null),
      'inst_due', (select coalesce(sum(due), 0) from inst), 'inst_paid', (select coalesce(sum(paid), 0) from inst),
      'inst_late', (select coalesce(sum(late), 0) from inst),
      'budget', (select coalesce(sum(budget), 0) from initiatives where status <> 'withdrawn'),
      'ex_high', (select count(*) from ex where sev = 'high'), 'ex_medium', (select count(*) from ex where sev = 'medium'), 'ex_low', (select count(*) from ex where sev = 'low'),
      'median_ppk', (select round(m) from med)),
    'banks', (select coalesce(jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name, 'islamic', o.is_islamic,
        'allocated', coalesce(b.allocated, 0), 'reserved', coalesce(b.reserved, 0), 'ledger_disbursed', coalesce(b.disbursed, 0), 'recovered', coalesce(b.recovered, 0),
        'apps', (select count(*) from a where a.bank_id = o.id), 'completed', (select count(*) from a where a.bank_id = o.id and a.status = 'completed'),
        'requested', (select coalesce(sum(amount), 0) from a where a.bank_id = o.id and a.status <> 'cancelled'),
        'disbursed', (select coalesce(sum(amt), 0) from disb where disb.bank_id = o.id),
        'fees', (select coalesce(sum(pay.amt), 0) from pay join a on a.id = pay.application_id where a.bank_id = o.id),
        'inst_due', (select coalesce(sum(i.due), 0) from inst i join a on a.id = i.application_id where a.bank_id = o.id),
        'inst_paid', (select coalesce(sum(i.paid), 0) from inst i join a on a.id = i.application_id where a.bank_id = o.id),
        'inst_late', (select coalesce(sum(i.late), 0) from inst i join a on a.id = i.application_id where a.bank_id = o.id),
        'exceptions', (select count(*) from ex where ex.bank_id = o.id)) order by o.name), '[]')
      from orgs o left join bank_allocations b on b.bank_id = o.id where o.type = 'bank' and (p_bank is null or o.id = p_bank)),
    'batches', (select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'code', c.code, 'bank', o.name, 'total', c.total, 'apps', c.apps_count, 'status', c.status,
        'letter', c.letter_ref, 'signed_by', c.signed_by_name, 'signed_at', c.signed_at, 'sent_at', c.sent_at, 'decided_by', c.decided_by_name, 'decided_at', c.decided_at,
        'note', c.decision_note) order by c.created_at desc), '[]')
      from cbi_batches c join orgs o on o.id = c.bank_id where c.created_at >= v_from and (p_bank is null or c.bank_id = p_bank)),
    'suppliers', (select coalesce(jsonb_agg(s order by (s->>'amount')::numeric desc), '[]') from (
      select jsonb_build_object('id', o.id, 'name', o.name,
        'apps', count(a.*), 'completed', count(a.*) filter (where a.status = 'completed'),
        'amount', coalesce(sum(a.amount) filter (where a.status <> 'cancelled'), 0),
        'disbursed', coalesce((select sum(d.amt) from disb d join a a2 on a2.id = d.id where a2.supplier_id = o.id), 0),
        'kw', coalesce(sum(a.kw) filter (where a.status <> 'cancelled' and coalesce(a.program, '') <> 'vet'), 0),
        'ppk', round(sum(a.price) filter (where coalesce(a.program, '') <> 'vet' and a.kw > 0 and a.status <> 'cancelled')::numeric
                / nullif(sum(a.kw) filter (where coalesce(a.program, '') <> 'vet' and a.kw > 0 and a.status <> 'cancelled'), 0)),
        'high_price', (select count(*) from ex where ex.rule = 'price_high' and ex.app_id in (select id from a a3 where a3.supplier_id = o.id)),
        'no_install', (select count(*) from ex where ex.rule = 'disb_no_install' and ex.app_id in (select id from a a3 where a3.supplier_id = o.id))) s
      from orgs o join a on a.supplier_id = o.id where o.type = 'supplier' group by o.id, o.name) q),
    'govs', (select coalesce(jsonb_agg(g order by (g->>'apps')::int desc), '[]') from (
      select jsonb_build_object('name', coalesce(a.governorate, '—'), 'apps', count(*), 'completed', count(*) filter (where a.status = 'completed'),
        'amount', coalesce(sum(a.amount) filter (where a.status <> 'cancelled'), 0), 'disbursed', coalesce(sum(d.amt), 0),
        'kw', coalesce(sum(a.kw) filter (where a.status = 'completed'), 0)) g
      from a join disb d on d.id = a.id group by a.governorate) q),
    'sectors', (select coalesce(jsonb_agg(g order by (g->>'amount')::numeric desc), '[]') from (
      select jsonb_build_object('key', a.sector, 'apps', count(*), 'completed', count(*) filter (where a.status = 'completed'),
        'amount', coalesce(sum(a.amount) filter (where a.status <> 'cancelled'), 0), 'disbursed', coalesce(sum(d.amt), 0)) g
      from a join disb d on d.id = a.id group by a.sector) q),
    'initiatives', (select coalesce(jsonb_agg(jsonb_build_object('code', i.code, 'title', i.title, 'budget', i.budget, 'status', i.status,
        'start_on', i.start_on, 'end_on', i.end_on, 'circular', i.circular_no,
        'banks', (select count(*) from initiative_banks ib where ib.initiative_id = i.id)) order by i.created_at desc), '[]') from initiatives i),
    'exceptions', (select coalesce(jsonb_agg(jsonb_build_object('sev', ex.sev, 'rule', ex.rule, 'app_id', ex.app_id, 'code', ex.code,
        'bank', (select name from orgs where id = ex.bank_id), 'amount', ex.amount, 'detail', ex.detail)
        order by case ex.sev when 'high' then 1 when 'medium' then 2 else 3 end, ex.amount desc nulls last), '[]') from ex)
  ) into res;
  return res;
end $f$;
revoke all on function public.audit_overview(integer, uuid) from public, anon;
grant execute on function public.audit_overview(integer, uuid) to authenticated;

-- ───────── 6) الحساب التجريبي للديوان (مدير الجهة: يضيف مراقبيه من «فريقي») ─────────
do $$
begin
  if not exists (select 1 from public.profiles where username = 'audit1') then
    perform public._mk_user('audit1', 'Fsa@2026fa', 'م. حيدر صالح الجبوري', 'audit_viewer', 'audit', 'fbsa', null, null);
  end if;
  update public.profiles set manage_scope = 'org' where username = 'audit1' and manage_scope is null;
end $$;
