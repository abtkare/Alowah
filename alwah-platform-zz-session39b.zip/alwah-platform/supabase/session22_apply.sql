-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 22 (3 تشرين الثاني 2026) — المقترحات 5–11 من «مراجعة دورة حياة المقترض»
--  (5)  المحافظة والمدينة من الموقع: سؤال «هل المنظومة في عنوان سكنك؟» والمحافظة تُؤخذ من موقع الـGPS
--  (6)  بدء الطلب دون الموقع: يُطلب مكان المنظومة قبل الإرسال لا قبل الخطوة الأولى
--  (10) إرجاع بنواقص قابلة للإصلاح من الهاتف: «طلب نواقص» من المصرف بسطر وزر لكل بند
--  (7)  رابط تحديد الموقع لشخص آخر: لمرة واحدة، ينتهي خلال 48 ساعة، دون تسجيل
--  (9)  موافقة الكفيل من هاتفه برابط: لمرة واحدة، ينتهي خلال 48 ساعة، برمز تحقق على هاتف الكفيل
--  (8)  دبوس على الخريطة «محدد يدوياً» تؤكده لجنة الكشف الموقعي في المرحلة 14 — خيار يشغّله المصرف
--  (11) استلام جدول الأقساط من الهاتف برمز تحقق (المرحلة 34) — خيار يشغّله المصرف
--  + إصلاح: نسخة الجلسة 19 من set_app_site لم تُطبَّق فعلياً (فحصها كان يتحقق خطأً) — مدموجة هنا
-- الملف قابل لإعادة التشغيل بأمان (idempotent)
-- ═══════════════════════════════════════════════════════════════════════════

alter table public.applications add column if not exists site_home boolean;
alter table public.applications add column if not exists schedule_ack jsonb;

-- ───────── خيارات المصرف (المقترحان 8 و11) — مطفأة افتراضياً ─────────
create or replace function public._bank_opt(p_bank uuid, p_key text) returns boolean
language sql stable security definer set search_path to 'public' as $$
  select coalesce((select (meta->>p_key)::boolean from orgs where id = p_bank and type = 'bank'), false) $$;

create or replace function public.bank_set_option(p_key text, p_on boolean) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; o orgs;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'bank' or me.role not in ('bank_md', 'bank_admin') then
    raise exception 'إعدادات المصرف للإدارة العليا ومدير المصرف فقط'; end if;
  if p_key not in ('opt_manual_pin', 'opt_phone_schedule') then raise exception 'خيار غير معروف'; end if;
  update orgs set meta = coalesce(meta, '{}'::jsonb) || jsonb_build_object(p_key, coalesce(p_on, false), p_key || '_at', now(),
      p_key || '_by', _role_title(me.role) || ' — ' || me.full_name)
  where id = me.org_id and type = 'bank' returning * into o;
  perform _audit(case when p_on then 'تشغيل خيار المصرف' else 'إيقاف خيار المصرف' end, o.name,
    jsonb_build_object('option', p_key, 'label', case p_key when 'opt_manual_pin' then 'تحديد مكان المنظومة بدبوس على الخريطة عند تعذّر الـGPS'
      else 'استلام جدول الأقساط من هاتف المقترض برمز تحقق' end, 'on', p_on));
  return o.meta;
end $function$;

-- ───────── المحافظات (المقترح 5) ─────────
create or replace function public._gov_ok(p text) returns boolean language sql immutable as $$
  select coalesce(p, '') = any (array['بغداد','البصرة','نينوى','أربيل','النجف','كربلاء','بابل','ذي قار','الأنبار','ديالى','واسط','ميسان',
    'الديوانية','صلاح الدين','كركوك','المثنى','السليمانية','دهوك']) $$;

-- حدث على الطلب من شخص غير مسجَّل (صاحب رابط) — _ev لا يكتب شيئاً دون مستخدم مسجَّل
create or replace function public._ev_as(p_app uuid, p_stage int, p_act text, p_note text, p_name text, p_title text) returns void
language sql security definer set search_path to 'public' as $$
  insert into application_events(application_id, stage, action, note, actor_id, actor_name, actor_role, actor_title)
  values (p_app, p_stage, p_act, p_note, null, p_name, 'link', p_title) $$;

-- ───────── تثبيت موقع المنظومة — مشترك بين المقترض والرابط (المقترحات 5 و7 و8) ─────────
create or replace function public._put_site_geo(p_app uuid, p jsonb, p_via text, p_actor text default null)
returns applications language plpgsql security definer set search_path to 'public' as $function$
declare a applications; g jsonb; lim numeric := _setting('site_gps_accuracy_m');
  v_lat float8 := nullif(p->>'lat', '')::float8; v_lng float8 := nullif(p->>'lng', '')::float8; v_acc float8 := nullif(p->>'acc', '')::float8;
  v_src text := coalesce(nullif(p->>'source', ''), 'gps'); v_gov text := nullif(trim(coalesce(p->>'geo_gov', '')), ''); v_city text := nullif(left(trim(coalesce(p->>'geo_city', '')), 60), '');
  v_addr text := nullif(left(trim(coalesce(p->>'address', '')), 160), ''); act text; nt text;
begin
  select * into a from applications where id = p_app for update;
  if v_lat is null or v_lng is null then raise exception 'حدّد موقع المنظومة'; end if;
  if not _geo_in_iraq(v_lat, v_lng) then raise exception 'الموقع المحدد خارج العراق — أعد تحديد الموقع'; end if;
  if v_src = 'manual' then
    if not _bank_opt(coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid), 'opt_manual_pin') then
      raise exception 'مصرفك لا يقبل تحديد المكان يدوياً على الخريطة — حدّده بالـGPS، أو أرسل الرابط لشخص في المكان'; end if;
    v_acc := null;
  elsif v_src = 'gps' then
    if v_acc is null or v_acc > lim then raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م) — انتقل إلى مكان مكشوف وأعد المحاولة', round(coalesce(v_acc, 0)), lim; end if;
  else raise exception 'مصدر الموقع غير معروف'; end if;
  if not _gov_ok(v_gov) then v_gov := null; end if;
  g := jsonb_build_object('lat', round(v_lat::numeric, 6), 'lng', round(v_lng::numeric, 6), 'acc', case when v_acc is null then null else round(v_acc::numeric, 1) end,
    'at', now(), 'source', v_src, 'via', p_via, 'address', v_addr, 'gov', v_gov, 'city', v_city);
  update applications set lat = round(v_lat::numeric, 6), lng = round(v_lng::numeric, 6), site_geo = g,
    -- المقترح 5: المحافظة والمدينة من الموقع نفسه (قبل الإرسال فقط — الفرع يُسنَد عند الإرسال حسب المحافظة)
    governorate = case when a.stage <= 5 and v_gov is not null then v_gov else governorate end,
    city = case when a.stage <= 5 and v_gov is not null then coalesce(v_city, case when v_gov = a.governorate then a.city else v_gov end) else city end,
    updated_at = now()
  where id = a.id returning * into a;
  act := 'تثبيت عنوان المنظومة ' || case when v_src = 'manual' then 'بدبوس على الخريطة (محدد يدوياً)' else 'بالـGPS' end
    || case when p_via = 'link' then ' — عبر رابط أُرسل لشخص في المكان' when p_via = 'late' then ' (استكمال لطلب قديم)' else '' end;
  nt := case when a.site_type = 'residential' then 'سكن' when a.site_type = 'project' then 'مشروع — ' || coalesce(a.purpose_other, _purpose_label(a.purpose)) else '' end
    || case when v_src = 'manual' then ' · محدد يدوياً — تؤكده لجنة الكشف الموقعي (المرحلة 14)' else ' · دقة ±' || round(v_acc) || ' م' end
    || coalesce(' · ' || v_gov || coalesce(' / ' || v_city, ''), '') || coalesce(' · ' || v_addr, '');
  if p_actor is null then perform _ev(a.id, a.stage, act, nt);
  else perform _ev_as(a.id, a.stage, act, nt, p_actor, 'صاحب رابط تحديد الموقع'); end if;
  if a.stage > 5 then
    perform _notify(a.bank_id, 'bank', 'site_gps', 'ثُبّت عنوان المنظومة — ' || a.code, 'أُضيف عنوان المنظومة للطلب في المرحلة ' || a.stage || ' — يمكن متابعة المعاملة', a.id);
  end if;
  return a;
end $function$;

-- عنوان المنظومة: نوع الموقع والمحافظة دون GPS عند البدء (المقترحان 5 و6)، والموقع حين يتوفر
create or replace function public.set_app_site(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; late boolean := false; v_type text := p->>'site_type'; v_purpose text; v_other text;
  has_geo boolean := nullif(p->>'lat', '') is not null and nullif(p->>'lng', '') is not null; v_home boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'عنوان المنظومة لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  -- الجلسة 19: طلب لدى المصرف بلا عنوان — يُثبَّت الموقع مرة واحدة قبل أمر الشراء، ونوع الموقع يبقى كما هو
  late := a.stage > 5;
  if late then
    if a.site_geo is not null then raise exception 'الطلب لدى المصرف الآن — عنوان المنظومة مثبّت ولا يُعدَّل'; end if;
    if a.stage > 30 then raise exception 'صدر أمر الشراء — يثبّت فني المورد موقع التركيب في الموقع نفسه'; end if;
    if not has_geo then raise exception 'حدّد موقع المنظومة'; end if;
    return _put_site_geo(a.id, p, 'late');
  end if;
  if v_type is null and a.site_type is not null and not (p ? 'purpose') then   -- تحديث الموقع فقط
    v_type := a.site_type; v_purpose := coalesce(a.purpose, 'household'); v_other := a.purpose_other;
  else
    if v_type not in ('residential', 'project') then raise exception 'اختر نوع الموقع: سكن أو مشروع'; end if;
    if v_type = 'residential' then v_purpose := 'household';
    else
      v_purpose := p->>'purpose';
      if v_purpose not in ('industrial', 'project', 'agricultural', 'vet', 'other') then raise exception 'اختر نوع المشروع: صناعي، تجاري، زراعي، بيطري، أو أخرى'; end if;
      if v_purpose = 'other' then
        v_other := regexp_replace(trim(coalesce(p->>'purpose_other', '')), '\s+', ' ', 'g');
        if length(v_other) < 3 or length(v_other) > 60 then raise exception 'اكتب نوع المشروع (3 إلى 60 حرفاً)'; end if;
      end if;
    end if;
  end if;
  if v_purpose is distinct from coalesce(a.purpose, 'household') and exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  if a.site_type is distinct from v_type or coalesce(a.purpose, 'household') is distinct from v_purpose or a.purpose_other is distinct from v_other then
    update applications set site_type = v_type, purpose = v_purpose, purpose_other = v_other, updated_at = now() where id = a.id;
    perform _ev(a.id, a.stage, 'تحديد نوع موقع المنظومة', case when v_type = 'residential' then 'سكن' else 'مشروع — ' || coalesce(v_other, _purpose_label(v_purpose)) end);
  end if;
  -- المقترح 5: «هل المنظومة في عنوان سكنك؟» بدل كتابة المحافظة والمدينة مرتين
  if p ? 'at_home' and nullif(p->>'at_home', '') is not null then
    v_home := (p->>'at_home')::boolean;
    if v_home then
      if coalesce(me.governorate, '') = '' then raise exception 'أكمل محافظة سكنك في «بياناتك» أولاً'; end if;
      update applications set site_home = true, governorate = me.governorate, city = coalesce(nullif(me.city, ''), me.governorate) where id = a.id;
    else
      if not _gov_ok(p->>'governorate') then raise exception 'اختر محافظة مكان المنظومة'; end if;
      update applications set site_home = false, governorate = p->>'governorate', city = coalesce(nullif(left(trim(coalesce(p->>'city', '')), 60), ''), p->>'governorate') where id = a.id;
    end if;
  end if;
  if has_geo then return _put_site_geo(a.id, p, 'borrower'); end if;
  select * into a from applications where id = p_app;
  return a;
end $function$;

-- المقترح 6: مكان المنظومة شرط للإرسال (5 ← 6) لا للخطوة الأولى
create or replace function public._guard_site() returns trigger
language plpgsql security definer set search_path to 'public' as $function$
begin
  if new.stage > old.stage and old.stage <= 5 and new.stage >= 6 and new.program = 'solar' and (new.site_geo is null or new.site_type is null) then
    raise exception 'حدّد مكان المنظومة (من هاتفك وأنت في المكان، أو برابط لشخص هناك) قبل إرسال الطلب'; end if;
  -- المقترح 8: الموقع المحدد يدوياً تؤكده لجنة الكشف الموقعي قبل إنجاز المرحلة 14
  if new.stage > old.stage and old.stage = 14 and new.program = 'solar' and new.site_geo->>'source' = 'manual' and new.site_geo->>'confirmed_at' is null then
    raise exception 'مكان المنظومة محدد يدوياً على الخريطة — أكّده بالـGPS في الموقع («تأكيد مكان المنظومة») قبل رفع تقرير الكشف'; end if;
  return new;
end $function$;

-- ───────── المقترح 8: تأكيد الدبوس اليدوي من لجنة الكشف الموقعي ─────────
create or replace function public.site_confirm(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; g jsonb; d numeric; lim numeric := _setting('site_gps_accuracy_m');
  v_lat float8 := nullif(p->>'lat', '')::float8; v_lng float8 := nullif(p->>'lng', '')::float8; v_acc float8 := nullif(p->>'acc', '')::float8;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or me is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role not in ('bank_inspection', 'bank_branch_mgr') then raise exception 'تأكيد المكان من لجنة الكشف الموقعي'; end if;
  if a.stage <> 14 then raise exception 'تأكيد المكان في مرحلة الكشف الموقعي (14)'; end if;
  if a.site_geo->>'source' is distinct from 'manual' then raise exception 'المكان محدد بالـGPS أصلاً — لا يحتاج تأكيداً'; end if;
  if v_lat is null or v_lng is null or not _geo_in_iraq(v_lat, v_lng) then raise exception 'حدّد الموقع بالـGPS وأنت في مكان المنظومة'; end if;
  if v_acc is null or v_acc > lim then raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م)', round(coalesce(v_acc, 0)), lim; end if;
  d := round(_geo_dist_m((a.site_geo->>'lat')::float8, (a.site_geo->>'lng')::float8, v_lat, v_lng)::numeric);
  g := a.site_geo || jsonb_build_object('pin', jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng', 'at', a.site_geo->'at'),
    'lat', round(v_lat::numeric, 6), 'lng', round(v_lng::numeric, 6), 'acc', round(v_acc::numeric, 1), 'confirmed_at', now(),
    'confirmed_by', _role_title(me.role) || coalesce(' — ' || me.staff_code, ''), 'confirm_dist_m', d, 'confirm_note', nullif(left(trim(coalesce(p->>'note', '')), 300), ''));
  update applications set site_geo = g, lat = round(v_lat::numeric, 6), lng = round(v_lng::numeric, 6), updated_at = now() where id = a.id returning * into a;
  perform _ev(a.id, 14, 'تأكيد مكان المنظومة المحدد يدوياً — لجنة الكشف الموقعي',
    'بالـGPS في الموقع · دقة ±' || round(v_acc) || ' م · يبعد ' || d || ' م عن دبوس المقترض' || coalesce(' · ' || nullif(trim(coalesce(p->>'note', '')), ''), ''));
  return a;
end $function$;

-- ───────── المقترحان 7 و9: روابط لمرة واحدة تنتهي خلال 48 ساعة ─────────
create table if not exists public.app_links (
  token text primary key,
  application_id uuid not null references public.applications(id) on delete cascade,
  kind text not null check (kind in ('site', 'guarantor')),
  g_index int,
  data jsonb not null default '{}'::jsonb,
  created_by uuid,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  used_at timestamptz,
  revoked_at timestamptz,
  result jsonb
);
create index if not exists app_links_app on public.app_links(application_id);
alter table public.app_links enable row level security;
drop policy if exists read_own_links on public.app_links;
create policy read_own_links on public.app_links for select using (exists (select 1 from applications a where a.id = application_id and a.citizen_id = auth.uid()));
revoke insert, update, delete on public.app_links from anon, authenticated;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'app_links') then alter publication supabase_realtime add table public.app_links; end if;
end $$;

create or replace function public._link_state(l app_links) returns text language sql stable as $$
  select case when l.token is null then 'missing' when l.revoked_at is not null then 'revoked' when l.used_at is not null then 'used'
    when l.expires_at < now() then 'expired' else 'ok' end $$;

create or replace function public.link_create(p_app uuid, p_kind text, p_data jsonb default '{}'::jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $function$
declare me profiles; a applications; tok text; d jsonb := '{}'::jsonb; ph text; v_i int; l app_links;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'الروابط لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  if p_kind = 'site' then
    if a.site_type is null then raise exception 'اختر نوع الموقع (سكن أو مشروع) أولاً'; end if;
    if a.stage > 5 and (a.site_geo is not null or a.stage > 30) then raise exception 'عنوان المنظومة لا يُعدَّل الآن'; end if;
    update app_links set revoked_at = now() where application_id = a.id and kind = 'site' and used_at is null and revoked_at is null;
  elsif p_kind = 'guarantor' then
    if a.guarantee_type not in ('single_salary', 'multi_salary') then raise exception 'هذا الطلب بضمان رهن عقار — لا كفلاء'; end if;
    if a.stage < 4 or a.stage > 5 then raise exception 'موافقة الكفلاء في خطوة الضمان'; end if;
    v_i := coalesce(nullif(p_data->>'i', '')::int, 0);
    if v_i < 0 or v_i > 2 then raise exception 'رقم الكفيل غير صحيح'; end if;
    if array_length(regexp_split_to_array(trim(coalesce(p_data->>'name', '')), '\s+'), 1) < 3 or length(trim(p_data->>'name')) < 6 then raise exception 'اكتب الاسم الثلاثي للكفيل'; end if;
    ph := _norm_phone(p_data->>'phone');
    if ph = me.phone then raise exception 'لا يكفل المتقدم نفسه'; end if;
    if coalesce(trim(p_data->>'employer'), '') = '' then raise exception 'اكتب جهة عمل الكفيل'; end if;
    if coalesce(nullif(p_data->>'salary', '')::bigint, 0) < 250000 then raise exception 'راتب الكفيل غير صحيح'; end if;
    d := jsonb_build_object('name', regexp_replace(trim(p_data->>'name'), '\s+', ' ', 'g'), 'phone', ph, 'employer', trim(p_data->>'employer'),
      'salary', (p_data->>'salary')::bigint, 'relation', nullif(p_data->>'relation', ''));
    update app_links set revoked_at = now() where application_id = a.id and kind = 'guarantor' and used_at is null and revoked_at is null and (g_index = v_i or data->>'phone' = ph);
  else raise exception 'نوع الرابط غير معروف'; end if;
  tok := translate(encode(gen_random_bytes(18), 'base64'), '+/=', '-_');
  insert into app_links(token, application_id, kind, g_index, data, created_by, expires_at)
  values (tok, a.id, p_kind, v_i, d, me.id, now() + interval '48 hours') returning * into l;
  perform _ev(a.id, a.stage, case when p_kind = 'site' then 'إنشاء رابط تحديد مكان المنظومة لشخص في المكان' else 'إرسال رابط الموافقة إلى الكفيل ' || (d->>'name') end,
    'رابط لمرة واحدة ينتهي ' || to_char(l.expires_at at time zone 'Asia/Baghdad', 'YYYY-MM-DD HH24:MI') || case when p_kind = 'guarantor' then ' · هاتف ' || left(ph, 4) || '••••' || right(ph, 3) else '' end);
  return jsonb_build_object('token', l.token, 'expires_at', l.expires_at, 'kind', l.kind, 'g_index', l.g_index);
end $function$;

-- ما يراه صاحب الرابط (دون تسجيل): الحد الأدنى فقط
create or replace function public.link_info(p_token text) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare l app_links; a applications; st text; bn text; inst bigint; months int;
begin
  select * into l from app_links where token = p_token;
  st := _link_state(l);
  if st = 'missing' then return jsonb_build_object('state', 'missing'); end if;
  select * into a from applications where id = l.application_id;
  if a.status not in ('active', 'returned') then st := 'closed'; end if;
  if st = 'ok' and l.kind = 'site' and a.stage > 5 and (a.site_geo is not null or a.stage > 30) then st := 'closed'; end if;
  if st = 'ok' and l.kind = 'guarantor' and a.stage > 5 then st := 'closed'; end if;
  if st <> 'ok' then return jsonb_build_object('state', st, 'kind', l.kind, 'borrower', split_part(a.citizen_name, ' ', 1), 'result', l.result); end if;
  select name into bn from orgs where id = coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid);
  months := coalesce((a.bank_choice->>'term_months')::int, a.term_months, 60);
  inst := coalesce(a.monthly_installment, _installment(a.amount, _setting('cbi_rate') + _setting('margin_max'), months));
  return jsonb_build_object('state', 'ok', 'kind', l.kind, 'expires_at', l.expires_at, 'code', a.code,
    'borrower', split_part(a.citizen_name, ' ', 1) || ' ' || split_part(a.citizen_name, ' ', 2),
    'site_type', a.site_type, 'purpose', _purpose_label(coalesce(a.purpose, 'household')), 'accuracy_m', _setting('site_gps_accuracy_m'),
    'manual_ok', l.kind = 'site' and _bank_opt(coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid), 'opt_manual_pin'),
    'guarantor', case when l.kind = 'guarantor' then jsonb_build_object('name', l.data->>'name', 'employer', l.data->>'employer', 'salary', (l.data->>'salary')::bigint,
      'phone', left(l.data->>'phone', 4) || '••••' || right(l.data->>'phone', 3), 'amount', a.amount, 'installment', inst, 'months', months, 'bank', bn,
      'guarantors_needed', case when a.guarantee_type = 'single_salary' then 1 else 2 end) end);
end $function$;

-- المقترح 7: الشخص في المكان يحدد الموقع بضغطة دون تسجيل
create or replace function public.link_site_submit(p_token text, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare l app_links; a applications; st text;
begin
  select * into l from app_links where token = p_token for update;
  st := _link_state(l);
  if st = 'missing' then raise exception 'الرابط غير صحيح'; end if;
  if l.kind <> 'site' then raise exception 'الرابط غير صحيح'; end if;
  if st = 'used' then raise exception 'استُخدم هذا الرابط من قبل — شكراً لك'; end if;
  if st = 'expired' then raise exception 'انتهت صلاحية الرابط (48 ساعة) — اطلب من صاحب الطلب رابطاً جديداً'; end if;
  if st = 'revoked' then raise exception 'أُلغي هذا الرابط — اطلب من صاحب الطلب الرابط الأحدث'; end if;
  select * into a from applications where id = l.application_id for update;
  if a.status not in ('active', 'returned') or (a.stage > 5 and (a.site_geo is not null or a.stage > 30)) then raise exception 'لم يعد الطلب يحتاج هذا الرابط — شكراً لك'; end if;
  a := _put_site_geo(a.id, p, 'link', 'شخص في مكان المنظومة');
  update app_links set used_at = now(), result = jsonb_build_object('lat', a.site_geo->'lat', 'lng', a.site_geo->'lng', 'acc', a.site_geo->'acc', 'source', a.site_geo->'source') where token = l.token;
  insert into notifications(user_id, kind, title, body, ref_id)
  values (a.citizen_id, 'site_link', 'حُدد مكان منظومتك', 'حدّد الشخص الذي أرسلت له الرابط مكان المنظومة — أكمل طلبك.', a.id);
  return jsonb_build_object('ok', true, 'gov', a.site_geo->>'gov', 'source', a.site_geo->>'source');
end $function$;

-- المقترح 9: الكفيل يوافق (أو يعتذر) من هاتفه برمز تحقق يصله
create or replace function public.link_guarantor_consent(p_token text, p_otp text, p_accept boolean) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare l app_links; a applications; st text;
begin
  select * into l from app_links where token = p_token for update;
  st := _link_state(l);
  if st = 'missing' or l.kind <> 'guarantor' then raise exception 'الرابط غير صحيح'; end if;
  if st = 'used' then raise exception 'سُجّل ردّك من قبل — شكراً لك'; end if;
  if st = 'expired' then raise exception 'انتهت صلاحية الرابط (48 ساعة) — اطلب من صاحب الطلب رابطاً جديداً'; end if;
  if st = 'revoked' then raise exception 'أُلغي هذا الرابط — اطلب من صاحب الطلب الرابط الأحدث'; end if;
  select * into a from applications where id = l.application_id;
  if a.status not in ('active', 'returned') or a.stage > 5 then raise exception 'لم يعد الطلب يحتاج هذا الرابط — شكراً لك'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح'; end if;
  update app_links set used_at = now(), result = jsonb_build_object('accepted', coalesce(p_accept, false), 'at', now(), 'method', 'link_otp') where token = l.token;
  perform _ev_as(a.id, a.stage, case when p_accept then 'وافق الكفيل على الكفالة من هاتفه' else 'اعتذر الكفيل عن الكفالة' end,
    (l.data->>'name') || ' · ' || (l.data->>'employer') || ' · برمز تحقق على هاتفه ' || left(l.data->>'phone', 4) || '••••' || right(l.data->>'phone', 3),
    l.data->>'name', 'كفيل — عبر رابط الموافقة');
  insert into notifications(user_id, kind, title, body, ref_id)
  values (a.citizen_id, 'guarantor_link', case when p_accept then 'وافق كفيلك ' || split_part(l.data->>'name', ' ', 1) else 'اعتذر ' || split_part(l.data->>'name', ' ', 1) || ' عن الكفالة' end,
    case when p_accept then 'أكمل خطوة الضمان في طلبك.' else 'اختر كفيلاً آخر في خطوة الضمان.' end, a.id);
  return jsonb_build_object('ok', true, 'accepted', coalesce(p_accept, false));
end $function$;

create or replace function public._g_link_ok(p_app uuid, p_token text, p_phone text, g jsonb) returns boolean
language plpgsql stable security definer set search_path to 'public' as $function$
declare l app_links;
begin
  if coalesce(p_token, '') = '' then return false; end if;
  select * into l from app_links where token = p_token and application_id = p_app and kind = 'guarantor';
  if l.token is null or l.revoked_at is not null or coalesce((l.result->>'accepted')::boolean, false) is not true then return false; end if;
  if l.data->>'phone' is distinct from p_phone then return false; end if;
  if regexp_replace(trim(coalesce(g->>'name', '')), '\s+', ' ', 'g') is distinct from l.data->>'name' or coalesce((g->>'salary')::bigint, 0) is distinct from (l.data->>'salary')::bigint then
    raise exception 'تغيّرت بيانات الكفيل % بعد موافقته — أرسل له رابطاً جديداً', l.data->>'name'; end if;
  return true;
end $function$;

-- خطوة الضمان تقبل موافقة الكفيل عبر الرابط بدل حضوره مع رمز التحقق
do $$
declare d text; o text := 'if not _otp_ok(g->>''otp'') then raise exception'; n text := 'if not (_otp_ok(g->>''otp'') or _g_link_ok(a.id, g->>''link'', ph, g)) then raise exception';
  o2 text := '''consent'', true, ''consent_at'', now())'; n2 text := '''consent'', true, ''consent_at'', now(), ''consent_via'', case when _otp_ok(g->>''otp'') then ''otp'' else ''link'' end)';
begin
  d := pg_get_functiondef('public._citizen_step_solar(uuid,integer,jsonb)'::regprocedure);
  if position('_g_link_ok' in d) = 0 then
    if position(o in d) = 0 or position(o2 in d) = 0 then raise exception 'الجلسة 22: لم يُعثر على نص موافقة الكفيل في _citizen_step_solar'; end if;
    execute replace(replace(d, o, n), o2, n2);
  end if;
end $$;

-- ───────── المقترح 10: طلب نواقص من المقترض يصلحها من هاتفه ─────────
create table if not exists public.app_fix_requests (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  stage int not null,
  items jsonb not null,
  note text,
  status text not null default 'open' check (status in ('open', 'answered', 'closed')),
  created_by uuid, created_by_title text,
  created_at timestamptz not null default now(),
  answered_at timestamptz, closed_at timestamptz, closed_note text
);
create index if not exists app_fix_requests_app on public.app_fix_requests(application_id);
alter table public.app_fix_requests enable row level security;
drop policy if exists read_fix_requests on public.app_fix_requests;
create policy read_fix_requests on public.app_fix_requests for select using (exists (select 1 from applications a where a.id = application_id
  and (a.citizen_id = auth.uid() or (my_portal() = 'bank' and a.bank_id = my_org()) or my_portal() in ('admin', 'cbi', 'integrity'))));
revoke insert, update, delete on public.app_fix_requests from anon, authenticated;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'app_fix_requests') then alter publication supabase_realtime add table public.app_fix_requests; end if;
end $$;

create or replace function public.fix_request_create(p_app uuid, p_items jsonb, p_note text default null) returns app_fix_requests
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; it jsonb := '[]'::jsonb; x jsonb; k int := 0; r app_fix_requests; lbl text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.branch_id is not null and a.branch_id is not null and me.branch_id <> a.branch_id then raise exception 'الطلب في فرع آخر'; end if;
  if a.status not in ('active', 'returned') or a.stage < 6 or a.stage > 36 then raise exception 'لا يُطلب من المقترض شيء في هذه المرحلة'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'أضف بنداً واحداً على الأقل'; end if;
  if jsonb_array_length(p_items) > 8 then raise exception 'ثمانية بنود كحد أقصى'; end if;
  for x in select * from jsonb_array_elements(p_items) loop
    k := k + 1; lbl := regexp_replace(trim(coalesce(x->>'label', '')), '\s+', ' ', 'g');
    if length(lbl) < 4 or length(lbl) > 140 then raise exception 'اكتب كل نقص بجملة واضحة (4 إلى 140 حرفاً)'; end if;
    if coalesce(x->>'kind', 'doc') not in ('doc', 'text') then raise exception 'نوع البند: صورة أو مستند، أو جواب مكتوب'; end if;
    it := it || jsonb_build_object('key', k::text, 'label', lbl, 'kind', coalesce(x->>'kind', 'doc'), 'done', false);
  end loop;
  insert into app_fix_requests(application_id, stage, items, note, created_by, created_by_title)
  values (a.id, a.stage, it, nullif(left(trim(coalesce(p_note, '')), 400), ''), me.id, _role_title(me.role) || coalesce(' — ' || (select name from branches where id = me.branch_id), ''))
  returning * into r;
  perform _ev(a.id, a.stage, 'طلب نواقص من المقترض يصلحها من هاتفه',
    (select string_agg('★ ' || (i->>'label'), E'\n') from jsonb_array_elements(it) i) || coalesce(E'\nملاحظة: ' || r.note, ''));
  insert into notifications(user_id, kind, title, body, ref_id)
  values (a.citizen_id, 'fix_request', 'المصرف يطلب منك ' || jsonb_array_length(it) || case when jsonb_array_length(it) = 1 then ' بنداً' else ' بنود' end,
    'افتح «طلبي» وأصلح كل بند من هاتفك.', a.id);
  return r;
end $function$;

create or replace function public.fix_request_answer(p_req uuid, p_key text, p jsonb) returns app_fix_requests
language plpgsql security definer set search_path to 'public', 'extensions' as $function$
declare me profiles; a applications; r app_fix_requests; it jsonb; x jsonb; did uuid; mime text; sz int; txt text; found boolean := false; left_n int;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from app_fix_requests where id = p_req for update;
  select * into a from applications where id = r.application_id;
  if r.id is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if r.status <> 'open' then raise exception 'أُرسلت هذه النواقص من قبل'; end if;
  if a.status not in ('active', 'returned') then raise exception 'الطلب ليس قيد المعالجة'; end if;
  it := '[]'::jsonb;
  for x in select * from jsonb_array_elements(r.items) loop
    if x->>'key' = p_key then
      found := true;
      if x->>'kind' = 'text' then
        txt := nullif(left(trim(coalesce(p->>'text', '')), 500), '');
        if txt is null or length(txt) < 2 then raise exception 'اكتب الجواب'; end if;
        x := x || jsonb_build_object('done', true, 'text', txt, 'at', now());
      else
        sz := length(coalesce(p->>'data', ''));
        mime := substring(p->>'data' from '^data:([a-z]+/[a-z+.-]+);base64,');
        if mime is null or mime not in ('image/jpeg', 'image/png', 'application/pdf') then raise exception 'صورة أو ملف PDF فقط'; end if;
        if sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
        insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
        values (a.id, 'fix', case when p->>'source' = 'camera' then 'camera' else 'file' end, mime, p->>'data', sz, encode(extensions.digest(p->>'data', 'sha256'), 'hex'),
          coalesce(p->'meta', '{}'::jsonb) || jsonb_build_object('fix_request', r.id, 'fix_key', p_key, 'label', x->>'label', 'server_at', now()), me.id, 'المقترض')
        returning id into did;
        x := x || jsonb_build_object('done', true, 'doc_id', did, 'at', now());
      end if;
    end if;
    it := it || x;
  end loop;
  if not found then raise exception 'بند غير معروف'; end if;
  select count(*) into left_n from jsonb_array_elements(it) i where not coalesce((i->>'done')::boolean, false);
  update app_fix_requests set items = it, status = case when left_n = 0 then 'answered' else 'open' end, answered_at = case when left_n = 0 then now() end
  where id = r.id returning * into r;
  perform _ev(a.id, a.stage, 'إصلاح نقص من هاتف المقترض', (select i->>'label' from jsonb_array_elements(it) i where i->>'key' = p_key)
    || case when left_n = 0 then ' — اكتملت كل النواقص المطلوبة' else ' — بقي ' || left_n end);
  if left_n = 0 then
    perform _notify(a.bank_id, 'bank', 'fix_answered', 'أكمل المقترض النواقص — ' || a.code, 'أرسل المقترض كل ما طُلب منه من هاتفه — راجعه في المعاملة.', a.id);
  end if;
  return r;
end $function$;

create or replace function public.fix_request_close(p_req uuid, p_note text default null) returns app_fix_requests
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; r app_fix_requests;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from app_fix_requests where id = p_req for update;
  select * into a from applications where id = r.application_id;
  if r.id is null or me is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if r.status = 'closed' then raise exception 'أُغلق من قبل'; end if;
  update app_fix_requests set status = 'closed', closed_at = now(), closed_note = nullif(left(trim(coalesce(p_note, '')), 300), '') where id = r.id returning * into r;
  perform _ev(a.id, a.stage, 'إغلاق طلب النواقص', coalesce(r.closed_note, case when r.answered_at is not null then 'استُلمت النواقص' else 'أُغلق دون إكمال' end));
  return r;
end $function$;

-- قائمة التدقيق في الاستقبال: النواقص المطلوبة من المقترض بنجمة حمراء حتى يصلحها، وموقع المنظومة يُصلَح من لوحته
do $$
declare d text; o text := '  return it;'; n text;
begin
  d := pg_get_functiondef('public._intake_items(applications)'::regprocedure);
  if position('app_fix_requests' in d) = 0 then
    if position(o in d) = 0 then raise exception 'الجلسة 22: لم يُعثر على نهاية _intake_items'; end if;
    n := '  it := it || coalesce((select jsonb_agg(_ci(''fix:'' || r.id || '':'' || (i->>''key''), i->>''label'', ''نواقص طلبها المصرف'', false, ''req''))
      from app_fix_requests r, jsonb_array_elements(r.items) i where r.application_id = a.id and r.status = ''open'' and r.stage <= 6
      and not coalesce((i->>''done'')::boolean, false)), ''[]''::jsonb);
  return it;';
    d := replace(d, o, n);
    d := replace(d, 'a.site_geo is not null and a.site_type is not null, ''1'')', 'a.site_geo is not null and a.site_type is not null, ''site'')');
    execute d;
  end if;
end $$;

-- إرجاع الطلب للمقترض يُغلق ما لم يُرسَل بعدُ في الاستقبال؟ لا — يبقى مفتوحاً ليصلحه من هاتفه، ويُغلق آلياً عند إعادة الإرسال
create or replace function public._fix_on_resubmit() returns trigger
language plpgsql security definer set search_path to 'public' as $function$
begin
  if new.stage > old.stage and old.stage <= 5 and new.stage >= 6 then
    update app_fix_requests set status = 'closed', closed_at = now(), closed_note = 'أُعيد إرسال الطلب' where application_id = new.id and status = 'answered' and stage <= 6;
  end if;
  return new;
end $function$;
drop trigger if exists trg_fix_on_resubmit on public.applications;
create trigger trg_fix_on_resubmit after update of stage on public.applications for each row execute function public._fix_on_resubmit();

-- ───────── المقترح 11: استلام جدول الأقساط من الهاتف (المرحلة 34) ─────────
create or replace function public.schedule_ack(p_app uuid, p_otp text) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; cnt int; first_due date; s35 stages;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or me is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' or a.status <> 'active' or a.stage <> 34 then raise exception 'استلام جدول الأقساط في مرحلة التسليم (34) فقط'; end if;
  if not _bank_opt(a.bank_id, 'opt_phone_schedule') then raise exception 'مصرفك يسلّم جدول الأقساط في الفرع — راجع فرعك'; end if;
  select count(*), min(due_date) into cnt, first_due from installments where application_id = a.id;
  if cnt = 0 then raise exception 'لم يصدر جدول الأقساط بعد'; end if;
  if not _otp_ok(p_otp) then raise exception 'رمز التحقق غير صحيح'; end if;
  select * into s35 from stages where n = 35;
  update applications set schedule_ack = jsonb_build_object('at', now(), 'method', 'phone_otp', 'count', cnt, 'first_due', first_due, 'installment', a.monthly_installment),
    stage = 35, bank_unit = s35.owner_label, updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, 34, 'استلام جدول الأقساط والتوقيع على الاستلام من هاتف المقترض',
    cnt || ' قسطاً بمبلغ ' || to_char(a.monthly_installment, 'FM999,999,999') || ' د.ع — أول استحقاق ' || to_char(first_due, 'YYYY-MM-DD') || ' · برمز تحقق على هاتفه (خيار المصرف)');
  perform _notify(a.bank_id, 'bank', 'schedule_ack', 'استلم المقترض جدول أقساطه من هاتفه — ' || a.code, 'انتقل الطلب إلى صرف المبلغ للمورد (المرحلة 35).', a.id);
  return a;
end $function$;

-- ───────── الصلاحيات ─────────
revoke execute on function public._put_site_geo(uuid, jsonb, text, text) from public, anon, authenticated;
revoke execute on function public._ev_as(uuid, integer, text, text, text, text) from public, anon, authenticated;
revoke execute on function public._g_link_ok(uuid, text, text, jsonb) from public, anon, authenticated;
revoke execute on function public.link_create(uuid, text, jsonb) from public, anon;
revoke execute on function public.fix_request_create(uuid, jsonb, text) from public, anon;
revoke execute on function public.fix_request_answer(uuid, text, jsonb) from public, anon;
revoke execute on function public.fix_request_close(uuid, text) from public, anon;
revoke execute on function public.schedule_ack(uuid, text) from public, anon;
revoke execute on function public.site_confirm(uuid, jsonb) from public, anon;
revoke execute on function public.bank_set_option(text, boolean) from public, anon;
grant execute on function public.link_create(uuid, text, jsonb), public.fix_request_create(uuid, jsonb, text), public.fix_request_answer(uuid, text, jsonb),
  public.fix_request_close(uuid, text), public.schedule_ack(uuid, text), public.site_confirm(uuid, jsonb), public.bank_set_option(text, boolean) to authenticated;
-- روابط بلا تسجيل: صاحب الرابط يستخدمها دون حساب
grant execute on function public.link_info(text), public.link_site_submit(text, jsonb), public.link_guarantor_consent(text, text, boolean) to anon, authenticated;
