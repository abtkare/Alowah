-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 18 (3 تشرين الثاني 2026)
-- (1) الصرف للمورد مع استقطاع عمولة المنصة: عند إنجاز المرحلة 35 (أمين الصندوق) يُسجَّل قيد صرف
--     إجمالي / عمولة المنصة (نسبة متفق عليها مع كل مورد) / الصافي للمورد، ويُبلَّغ المورد
-- (2) جدول الأقساط: يُولَّد آلياً عند إنجاز المرحلة 33 (تنفيذ التمويل وإصدار جدول الأقساط)
-- (3) متابعة الأقساط: موظف التحصيل والمتابعة يسجّل استيفاء كل قسط برقم الإيصال أو القيد،
--     والمقترض يرى جدوله، والمصرف يرى دفتر التحصيل والمتأخرات
-- (4) البنك المركزي وهيئة النزاهة: اطلاع رقابي فقط على السداد والمتأخرات (دون أي إجراء)
-- (5) مشغّل النظام: نسبة عمولة كل مورد وإيرادات المنصة
-- نطاق هذه الجلسة: طلبات منظومات الطاقة الشمسية (للمشروع البيطري دفعاته الخاصة)
-- الملف قابل لإعادة التشغيل بأمان (idempotent)
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── أ) الإعدادات ─────────
insert into settings(key, value, label, circular_no)
select * from (values
  ('supplier_commission_pct', 2::numeric, 'عمولة المنصة الافتراضية من مبلغ الصرف للمورد (%) — تُستبدل بالنسبة المتفق عليها مع كل مورد', 'ألواح'),
  ('npl_days', 90::numeric, 'عدد أيام التأخر الذي يُعدّ بعده القسط متعثراً (يوم)', 'سياسة التمويل')
) v(key, value, label, circular_no)
where not exists (select 1 from settings s where s.key = v.key);

-- نسبة عمولة كل مورد (يضبطها مشغّل النظام وفق الاتفاق الموقّع معه)
create or replace function public._supplier_commission_pct(p_supplier uuid) returns numeric
language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select nullif(meta->>'platform_commission_pct', '')::numeric from orgs where id = p_supplier), _setting('supplier_commission_pct'), 0) $f$;

create or replace function public.admin_set_supplier_commission(p_supplier uuid, p_pct numeric) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare o orgs; old numeric;
begin
  if not _is_admin() then raise exception 'غير مخوّل'; end if;
  select * into o from orgs where id = p_supplier and type = 'supplier' for update;
  if o is null then raise exception 'المورد غير موجود'; end if;
  if p_pct is null or p_pct < 0 or p_pct > 15 then raise exception 'النسبة بين 0 و15 بالمئة'; end if;
  old := _supplier_commission_pct(o.id);
  update orgs set meta = coalesce(meta, '{}'::jsonb) || jsonb_build_object('platform_commission_pct', round(p_pct, 2)) where id = o.id;
  perform _audit('تعديل عمولة المنصة على المورد', o.name, jsonb_build_object('from', old, 'to', round(p_pct, 2)));
  return jsonb_build_object('supplier', o.name, 'pct', round(p_pct, 2));
end $function$;

-- ───────── ب) قيد الصرف للمورد وعمولة المنصة ─────────
create table if not exists disbursements (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null unique references applications(id) on delete cascade,
  bank_id uuid references orgs(id),
  supplier_id uuid references orgs(id),
  gross bigint not null,
  commission_pct numeric not null,
  commission bigint not null,
  net bigint not null,
  paid_by uuid references profiles(id),
  paid_by_name text,
  paid_by_title text,
  paid_by_code text,
  created_at timestamptz not null default now()
);
alter table disbursements enable row level security;
revoke all on disbursements from anon, authenticated;

-- ───────── ج) جدول الأقساط ─────────
create table if not exists installments (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references applications(id) on delete cascade,
  n int not null,
  due_date date not null,
  principal bigint not null,
  profit bigint not null,
  amount bigint not null,
  balance_after bigint not null,
  paid_at timestamptz,
  paid_ref text,
  paid_by uuid references profiles(id),
  paid_by_title text,
  paid_by_code text,
  unique (application_id, n)
);
create index if not exists installments_due on installments(due_date) where paid_at is null;
alter table installments enable row level security;
revoke all on installments from anon, authenticated;

create or replace function public._repay_rate(a applications) returns numeric
language sql stable security definer set search_path to 'public' as $f$
  select case when a.program = 'vet' then coalesce(a.margin, _setting('vet_rate'))
    else coalesce(_setting('cbi_rate'), 0) + coalesce(a.margin, 0) end $f$;

-- النسبة السنوية التي يُطفئ بها القسطُ المعلن المبلغَ في عدد الأشهر نفسه (للتوفيق مع القسط الموقَّع)
create or replace function public._implied_rate(p_amount numeric, p_inst numeric, p_months int) returns numeric
language plpgsql immutable as $f$
declare lo numeric := 0; hi numeric := 60; mid numeric; k int;
begin
  if p_inst * p_months <= p_amount then return 0; end if;
  for k in 1..60 loop
    mid := (lo + hi) / 2;
    if p_amount * (mid / 1200) / (1 - power(1 + mid / 1200, -p_months)) > p_inst then hi := mid; else lo := mid; end if;
  end loop;
  return (lo + hi) / 2;
end $f$;

-- توليد الجدول بالتقسيط المتناقص — القسط نفسه المعلن للمقترض عند توقيع الطلب
create or replace function public._make_schedule(p_app uuid, p_base timestamptz default now()) returns int
language plpgsql security definer set search_path to 'public' as $function$
declare a applications; r numeric; m int; inst bigint; bal bigint; pr bigint; pf bigint; i int; base date;
begin
  select * into a from applications where id = p_app;
  if a is null or a.amount is null or a.term_months is null then return 0; end if;
  if exists (select 1 from installments where application_id = a.id) then return 0; end if;
  m := greatest(a.term_months - coalesce(a.grace_months, 0), 1);
  inst := coalesce(nullif(a.monthly_installment, 0), _installment(a.amount, _repay_rate(a), m));
  r := _implied_rate(a.amount, inst, m) / 1200;
  bal := a.amount;
  base := (p_base at time zone 'Asia/Baghdad')::date;
  for i in 1..m loop
    pf := round(bal * r);
    pr := case when i = m then bal else least(greatest(inst - pf, 0), bal) end;
    bal := bal - pr;
    insert into installments(application_id, n, due_date, principal, profit, amount, balance_after)
    values (a.id, i, (base + make_interval(months => coalesce(a.grace_months, 0) + i))::date, pr, pf, pr + pf, bal);
  end loop;
  return m;
end $function$;
revoke execute on function public._make_schedule(uuid, timestamptz) from public, anon, authenticated;

-- المشغّل: المرحلة 33 → 34 يولّد الجدول، والمرحلة 35 → 36 يسجّل قيد الصرف ويستقطع عمولة المنصة
create or replace function public._repay_hooks() returns trigger language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; pct numeric; c bigint; cnt int; sup text;
begin
  if new.program is distinct from 'solar' or new.stage <= old.stage then return new; end if;
  select * into me from profiles where id = auth.uid();
  if old.stage <= 33 and new.stage > 33 then
    cnt := _make_schedule(new.id);
    if cnt > 0 then
      perform _ev(new.id, 33, 'إصدار جدول الأقساط آلياً',
        cnt || ' قسطاً شهرياً بمبلغ ' || to_char(new.monthly_installment, 'FM999,999,999') || ' د.ع — أول استحقاق '
        || to_char((select min(due_date) from installments where application_id = new.id), 'YYYY-MM-DD'));
    end if;
  end if;
  if old.stage <= 35 and new.stage > 35 and not exists (select 1 from disbursements where application_id = new.id) then
    pct := _supplier_commission_pct(new.supplier_id);
    c := round(new.amount * pct / 100);
    insert into disbursements(application_id, bank_id, supplier_id, gross, commission_pct, commission, net, paid_by, paid_by_name, paid_by_title, paid_by_code)
    values (new.id, new.bank_id, new.supplier_id, new.amount, pct, c, new.amount - c, me.id, me.full_name, _role_title(me.role), me.staff_code);
    select name into sup from orgs where id = new.supplier_id;
    perform _ev(new.id, 35, 'قيد الصرف للمورد واستقطاع عمولة المنصة',
      'الإجمالي ' || to_char(new.amount, 'FM999,999,999') || ' · عمولة المنصة ' || pct || '% = ' || to_char(c, 'FM999,999,999')
      || ' · الصافي للمورد ' || to_char(new.amount - c, 'FM999,999,999') || ' د.ع');
    perform _notify(new.supplier_id, 'supplier', 'disbursement', 'صُرف مبلغ الطلب ' || new.code,
      'الصافي ' || to_char(new.amount - c, 'FM999,999,999') || ' د.ع بعد استقطاع عمولة المنصة ' || pct || '%', new.id);
  end if;
  return new;
end $function$;
drop trigger if exists trg_repay_hooks on applications;
create trigger trg_repay_hooks after update of stage on applications for each row execute function _repay_hooks();

-- ───────── د) الاطلاع: الصرف والجدول لكل طلب ─────────
create or replace function public._repay_access(a applications) returns text
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or a is null then return null; end if;
  if a.citizen_id = me.id then return 'borrower'; end if;
  if me.portal = 'bank' and a.bank_id = me.org_id then return 'bank'; end if;
  if me.portal = 'supplier' and a.supplier_id = me.org_id and me.role = 'supplier_admin' then return 'supplier'; end if;
  if me.portal in ('cbi', 'integrity') then return 'oversight'; end if;
  if me.portal = 'admin' and _is_admin() then return 'admin'; end if;
  return null;
end $function$;

create or replace function public.repay_info(p_app uuid) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare a applications; who text; me profiles; d disbursements; pct numeric; npl int := coalesce(_setting('npl_days'), 90)::int; sch jsonb; sm jsonb;
begin
  select * into a from applications where id = p_app;
  who := _repay_access(a);
  if who is null then raise exception 'غير مخوّل'; end if;
  select * into me from profiles where id = auth.uid();
  select * into d from disbursements where application_id = a.id;
  pct := coalesce(d.commission_pct, _supplier_commission_pct(a.supplier_id));
  if who <> 'supplier' then
    select coalesce(jsonb_agg(jsonb_build_object('n', n, 'due', due_date, 'principal', principal, 'profit', profit, 'amount', amount, 'balance', balance_after,
        'paid_at', paid_at, 'ref', case when who in ('bank', 'admin') then paid_ref end, 'by', paid_by_title,
        'late', case when paid_at is null and due_date < (now() at time zone 'Asia/Baghdad')::date then (now() at time zone 'Asia/Baghdad')::date - due_date
                     when paid_at is not null and (paid_at at time zone 'Asia/Baghdad')::date > due_date then (paid_at at time zone 'Asia/Baghdad')::date - due_date else 0 end)
        order by n), '[]'::jsonb) into sch from installments where application_id = a.id;
    select jsonb_build_object('count', count(*), 'paid', count(paid_at), 'paid_amt', coalesce(sum(amount) filter (where paid_at is not null), 0),
      'remaining', coalesce(sum(amount) filter (where paid_at is null), 0),
      'overdue', count(*) filter (where paid_at is null and due_date < (now() at time zone 'Asia/Baghdad')::date),
      'overdue_amt', coalesce(sum(amount) filter (where paid_at is null and due_date < (now() at time zone 'Asia/Baghdad')::date), 0),
      'max_late', coalesce(max((now() at time zone 'Asia/Baghdad')::date - due_date) filter (where paid_at is null and due_date < (now() at time zone 'Asia/Baghdad')::date), 0),
      'next', (select jsonb_build_object('n', n, 'due', due_date, 'amount', amount) from installments where application_id = a.id and paid_at is null order by n limit 1),
      'npl_days', npl)
      into sm from installments where application_id = a.id;
  end if;
  return jsonb_build_object('who', who,
    'disbursement', case when d.id is null then null else jsonb_build_object('gross', d.gross, 'pct', d.commission_pct, 'commission', d.commission, 'net', d.net,
      'at', d.created_at, 'by', d.paid_by_title, 'code', d.paid_by_code) end,
    'preview', case when d.id is null and a.stage between 30 and 35 and who in ('bank', 'supplier', 'admin', 'oversight') then
      jsonb_build_object('gross', a.amount, 'pct', pct, 'commission', round(a.amount * pct / 100), 'net', a.amount - round(a.amount * pct / 100)) end,
    'schedule', coalesce(sch, '[]'::jsonb), 'summary', sm,
    'can_collect', who = 'bank' and me.role = 'bank_collection' and not coalesce(me.disabled, false));
end $function$;

-- ───────── هـ) التحصيل: موظف التحصيل والمتابعة يسجّل استيفاء القسط التالي ─────────
create or replace function public.installment_collect(p_app uuid, p_n int, p_ref text) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; i installments; nxt int; late int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null or me.portal <> 'bank' or me.role <> 'bank_collection' or a.bank_id is distinct from me.org_id then
    raise exception 'تسجيل الاستيفاء من صلاحية موظف التحصيل والمتابعة في المصرف المُقرض'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if coalesce(trim(p_ref), '') = '' or length(trim(p_ref)) < 3 then raise exception 'اكتب رقم الإيصال أو القيد'; end if;
  select min(n) into nxt from installments where application_id = a.id and paid_at is null;
  if nxt is null then raise exception 'لا أقساط مستحقة — الجدول مسدَّد بالكامل أو لم يصدر بعد'; end if;
  if p_n is distinct from nxt then raise exception 'تُستوفى الأقساط بالترتيب — القسط التالي رقم %', nxt; end if;
  update installments set paid_at = now(), paid_ref = trim(p_ref), paid_by = me.id, paid_by_title = _role_title(me.role), paid_by_code = me.staff_code
  where application_id = a.id and n = nxt returning * into i;
  late := greatest((now() at time zone 'Asia/Baghdad')::date - i.due_date, 0);
  perform _ev(a.id, a.stage, 'استيفاء القسط ' || i.n || ' من ' || (select count(*) from installments where application_id = a.id),
    to_char(i.amount, 'FM999,999,999') || ' د.ع · استحقاق ' || to_char(i.due_date, 'YYYY-MM-DD')
    || case when late > 0 then ' · متأخر ' || late || ' يوماً' else '' end || ' · إيصال/قيد ' || trim(p_ref) || ' · ' || coalesce(me.staff_code, ''));
  return jsonb_build_object('n', i.n, 'amount', i.amount, 'late', late);
end $function$;

-- دفتر التحصيل للمصرف: كل طلب له جدول أقساط
create or replace function public.collection_book() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles; t date := (now() at time zone 'Asia/Baghdad')::date;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'bank' then raise exception 'غير مخوّل'; end if;
  return coalesce((select jsonb_agg(x order by (x->>'overdue')::int desc, x->>'next_due') from (
    select jsonb_build_object('id', a.id, 'code', a.code, 'name', a.citizen_name, 'branch_id', a.branch_id, 'amount', a.amount,
      'inst', a.monthly_installment, 'count', count(i.*), 'paid', count(i.paid_at),
      'overdue', count(*) filter (where i.paid_at is null and i.due_date < t),
      'overdue_amt', coalesce(sum(i.amount) filter (where i.paid_at is null and i.due_date < t), 0),
      'max_late', coalesce(max(t - i.due_date) filter (where i.paid_at is null and i.due_date < t), 0),
      'next_due', min(i.due_date) filter (where i.paid_at is null),
      'remaining', coalesce(sum(i.amount) filter (where i.paid_at is null), 0)) x
    from applications a join installments i on i.application_id = a.id
    where a.bank_id = me.org_id and (me.branch_id is null or a.branch_id = me.branch_id)
    group by a.id) q), '[]'::jsonb);
end $function$;

-- ───────── و) اطلاع رقابي للبنك المركزي وهيئة النزاهة (دون أي إجراء) ─────────
create or replace function public.oversight_repayments() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles; t date := (now() at time zone 'Asia/Baghdad')::date; npl int := coalesce(_setting('npl_days'), 90)::int;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal not in ('cbi', 'integrity', 'admin') then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('npl_days', npl,
    'banks', coalesce((select jsonb_agg(b order by b->>'name') from (
      select jsonb_build_object('bank_id', a.bank_id, 'name', (select name from orgs where id = a.bank_id),
        'loans', count(distinct a.id),
        'due_amt', coalesce(sum(i.amount) filter (where i.due_date <= t), 0),
        'collected', coalesce(sum(i.amount) filter (where i.paid_at is not null), 0),
        'collected_due', coalesce(sum(i.amount) filter (where i.paid_at is not null and i.due_date <= t), 0),
        'overdue_amt', coalesce(sum(i.amount) filter (where i.paid_at is null and i.due_date < t), 0),
        'overdue_loans', count(distinct a.id) filter (where i.paid_at is null and i.due_date < t),
        'npl_loans', count(distinct a.id) filter (where i.paid_at is null and i.due_date < t - npl),
        'outstanding', coalesce(sum(i.principal) filter (where i.paid_at is null), 0)) b
      from applications a join installments i on i.application_id = a.id group by a.bank_id) q), '[]'::jsonb),
    'late', coalesce((select jsonb_agg(l order by (l->>'max_late')::int desc) from (
      select jsonb_build_object('id', a.id, 'code', a.code, 'bank', (select name from orgs where id = a.bank_id), 'governorate', a.governorate,
        'overdue', count(*), 'overdue_amt', sum(i.amount), 'max_late', max(t - i.due_date)) l
      from applications a join installments i on i.application_id = a.id
      where i.paid_at is null and i.due_date < t group by a.id limit 200) q), '[]'::jsonb),
    'disbursed', coalesce((select jsonb_build_object('count', count(*), 'gross', sum(gross), 'commission', sum(commission), 'net', sum(net)) from disbursements), '{}'::jsonb));
end $function$;

-- ───────── ز) المورد: مستحقاتي وعمولة المنصة ─────────
create or replace function public.supplier_disbursements() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'supplier' or me.role <> 'supplier_admin' then raise exception 'من صلاحية مدير حساب المورد'; end if;
  return jsonb_build_object('pct', _supplier_commission_pct(me.org_id),
    'items', coalesce((select jsonb_agg(jsonb_build_object('code', a.code, 'bank', (select name from orgs where id = d.bank_id), 'gross', d.gross, 'pct', d.commission_pct,
      'commission', d.commission, 'net', d.net, 'at', d.created_at) order by d.created_at desc)
      from disbursements d join applications a on a.id = d.application_id where d.supplier_id = me.org_id), '[]'::jsonb));
end $function$;

-- ───────── ح) مشغّل النظام: إيرادات المنصة ─────────
create or replace function public.admin_revenue() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
begin
  if not _is_admin() then raise exception 'غير مخوّل'; end if;
  return jsonb_build_object('default_pct', _setting('supplier_commission_pct'),
    'suppliers', coalesce((select jsonb_agg(jsonb_build_object('id', o.id, 'name', o.name, 'pct', _supplier_commission_pct(o.id),
        'custom', (o.meta ? 'platform_commission_pct'),
        'count', (select count(*) from disbursements d where d.supplier_id = o.id),
        'gross', (select coalesce(sum(gross), 0) from disbursements d where d.supplier_id = o.id),
        'commission', (select coalesce(sum(commission), 0) from disbursements d where d.supplier_id = o.id)) order by o.name)
      from orgs o where o.type = 'supplier'), '[]'::jsonb),
    'recent', coalesce((select jsonb_agg(jsonb_build_object('code', a.code, 'supplier', (select name from orgs where id = d.supplier_id),
        'bank', (select name from orgs where id = d.bank_id), 'gross', d.gross, 'pct', d.commission_pct, 'commission', d.commission, 'net', d.net, 'at', d.created_at)
        order by d.created_at desc)
      from (select * from disbursements order by created_at desc limit 100) d join applications a on a.id = d.application_id), '[]'::jsonb));
end $function$;

grant execute on function public.repay_info(uuid), public.installment_collect(uuid, int, text), public.collection_book(),
  public.oversight_repayments(), public.supplier_disbursements(), public.admin_revenue(), public.admin_set_supplier_commission(uuid, numeric) to authenticated;
revoke execute on function public._repay_hooks() from public, anon, authenticated;
