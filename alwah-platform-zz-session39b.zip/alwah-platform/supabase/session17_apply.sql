-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 17 (3 تشرين الثاني 2026)
-- (1) توثيق التركيب في المرحلة 31: الفريق الفني للمورد يثبّت موقع التركيب بالـGPS ويصوّر الألواح والعاكس وفيديو التشغيل
-- (2) عنوان المنظومة بالـGPS ونوع الموقع (سكن / مشروع: صناعي، تجاري، زراعي، بيطري، أخرى) في أول الطلب
-- (3) مهلة التنفيذ (30 يوماً من تعزيز السلفة) مطبّقة، مع تمديد مسبّب واحد من الإدارة العليا للمصرف
-- (4) البنك المركزي يضيف حسابات هيئة النزاهة، ومخاطبات رسمية بينهما لا يطّلع عليها غيرهما
-- (5) إعلان المبادرات الجديدة للمصارف والإشعارات داخل المنصة
-- (6) تحليل ونسب نمو للبنك المركزي
-- الملف قابل لإعادة التشغيل بأمان (idempotent)
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── أ) الأعمدة والقيود والإعدادات ─────────
alter table applications add column if not exists site_type text;
alter table applications add column if not exists purpose_other text;
alter table applications add column if not exists site_geo jsonb;
alter table applications add column if not exists install_geo jsonb;
alter table applications add column if not exists exec_extended_until timestamptz;
alter table applications add column if not exists exec_extensions int not null default 0;
alter table applications add column if not exists exec_extension_note text;
alter table applications drop constraint if exists applications_site_type_check;
alter table applications add constraint applications_site_type_check check (site_type is null or site_type in ('residential','project'));
alter table applications drop constraint if exists applications_purpose_check;
alter table applications add constraint applications_purpose_check check (purpose = any (array['household','agricultural','industrial','project','vet','other']));

alter table app_documents drop constraint if exists app_documents_kind_check;
alter table app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site',
  'mortgage_letter','annotation_mark','dd_letter','dd_auth','kyc_face','contract_signed','feasibility','expert_report',
  'install_panels','install_inverter','install_video']));

insert into settings(key, value, label, circular_no)
select * from (values
  ('site_gps_accuracy_m', 100::numeric, 'أقصى هامش لدقة موقع المنظومة عند تثبيته من المقترض (متر)', 'ألواح'),
  ('install_gps_accuracy_m', 50::numeric, 'أقصى هامش لدقة موقع التركيب عند تثبيته من فني المورد (متر)', 'ألواح'),
  ('install_max_distance_m', 300::numeric, 'أقصى بعد بين موقع التركيب وعنوان المنظومة الذي ثبّته المقترض (متر)', 'ألواح'),
  ('install_video_min_s', 5::numeric, 'أقل مدة لفيديو تشغيل المنظومة (ثانية)', 'ألواح'),
  ('exec_extension_max_days', 15::numeric, 'أقصى تمديد مسبّب لمهلة التنفيذ — مرة واحدة من الإدارة العليا للمصرف (يوم)', 'سياسة التمويل')
) v(key, value, label, circular_no)
where not exists (select 1 from settings s where s.key = v.key);

create or replace function public._purpose_label(p text) returns text language sql immutable as $f$
  select case p when 'household' then 'سكن (منزلي)' when 'agricultural' then 'زراعي' when 'industrial' then 'صناعي'
    when 'project' then 'تجاري أو خدمي' when 'vet' then 'بيطري' when 'other' then 'مشروع آخر' else p end $f$;

-- ───────── ب) أدوات الموقع الجغرافي ─────────
create or replace function public._geo_dist_m(a1 float8, o1 float8, a2 float8, o2 float8) returns float8 language sql immutable as $f$
  select 2 * 6371000 * asin(sqrt(power(sin(radians(a2 - a1) / 2), 2) + cos(radians(a1)) * cos(radians(a2)) * power(sin(radians(o2 - o1) / 2), 2))) $f$;
create or replace function public._geo_in_iraq(lat float8, lng float8) returns boolean language sql immutable as $f$
  select lat between 29.0 and 37.5 and lng between 38.7 and 48.8 $f$;

-- ───────── ج) الأدوار: الفني المختص لدى المورد ─────────
create or replace function public._portal_of_role(r text) returns text language sql immutable as $function$
  select case when r like 'bank\_%' then 'bank' when r = 'cbi_admin' then 'cbi' when r = 'registry_officer' then 'registry'
    when r in ('supplier_admin', 'supplier_tech') then 'supplier' when r = 'integrity_viewer' then 'integrity' when r = 'syndicate_officer' then 'syndicate'
    when r = 'vetdept_officer' then 'vetdept' when r = 'platform_admin' then 'admin' when r = 'expert' then 'expert' when r = 'citizen' then 'citizen' end $function$;

create or replace function public._role_title(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'bank_payroll' then 'موظف توطين الرواتب — الاستقطاع المباشر'
    when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'supplier_tech' then 'الفني المختص — فريق التركيب لدى المورد'
    when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'expert' then 'خبير معتمد — دراسات الجدوى'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $function$;

create or replace function public._role_abbr(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'bank_payroll' then 'PR' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'supplier_tech' then 'TC' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'expert' then 'EX'
    when 'platform_admin' then 'SA' else 'XX' end $function$;

-- إنشاء حساب موظف من جهة مخوّلة (مدير حساب المورد لفنييه، البنك المركزي لهيئة النزاهة) — داخلي
create or replace function public._create_staff(p jsonb, p_role text, p_org uuid) returns profiles
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $function$
declare v_user text := lower(trim(coalesce(p->>'username', ''))); v_org orgs; uid uuid; pr profiles;
begin
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم مستخدم مسبقاً'; end if;
  if length(coalesce(p->>'password', '')) < 8 or (p->>'password') !~ '[0-9]' or (p->>'password') !~ '[A-Za-z]' then raise exception 'كلمة المرور المؤقتة 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
  if array_length(string_to_array(regexp_replace(trim(coalesce(p->>'full_name', '')), '\s+', ' ', 'g'), ' '), 1) < 2 then raise exception 'اكتب الاسم الكامل للموظف'; end if;
  select * into v_org from orgs where id = p_org;
  if v_org is null then raise exception 'الجهة غير موجودة'; end if;
  uid := _mk_user(v_user, p->>'password', regexp_replace(trim(p->>'full_name'), '\s+', ' ', 'g'), p_role, _portal_of_role(p_role), v_org.code, _opt_phone(p->>'phone'), null);
  update profiles set must_change_password = true where id = uid returning * into pr;
  return pr;
end $function$;
revoke execute on function public._create_staff(jsonb, text, uuid) from public, anon, authenticated;

-- مدير حساب المورد يضيف فنيي التركيب ويوقفهم
create or replace function public.supplier_team() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'supplier' then raise exception 'غير مخوّل'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'username', username, 'full_name', full_name, 'role', role, 'title', _role_title(role),
    'phone', phone, 'staff_code', staff_code, 'disabled', coalesce(disabled, false), 'must_change_password', must_change_password) order by role, username), '[]')
    from profiles where org_id = me.org_id and portal = 'supplier');
end $function$;

create or replace function public.supplier_add_tech(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; pr profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'supplier_admin' or coalesce(me.disabled, false) then raise exception 'إضافة الفنيين لمدير حساب المورد فقط'; end if;
  pr := _create_staff(p, 'supplier_tech', me.org_id);
  perform _audit('إضافة فني تركيب لدى المورد', pr.username, jsonb_build_object('org', (select name from orgs where id = me.org_id), 'by', me.username));
  return jsonb_build_object('username', pr.username, 'staff_code', pr.staff_code);
end $function$;

create or replace function public.supplier_set_tech(p_user uuid, p_disabled boolean) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; t profiles;
begin
  select * into me from profiles where id = auth.uid();
  select * into t from profiles where id = p_user;
  if me is null or me.role <> 'supplier_admin' or t is null or t.org_id <> me.org_id or t.role <> 'supplier_tech' then raise exception 'غير مخوّل'; end if;
  update profiles set disabled = p_disabled, updated_at = now() where id = t.id;
  perform _audit(case when p_disabled then 'إيقاف فني تركيب' else 'تفعيل فني تركيب' end, t.username, null);
  return jsonb_build_object('ok', true);
end $function$;

-- ───────── د) عنوان المنظومة بالـGPS ونوع الموقع (المقترض) ─────────
create or replace function public.set_app_site(p_app uuid, p jsonb) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; v_type text := p->>'site_type'; v_purpose text; v_other text;
  v_lat float8 := nullif(p->>'lat', '')::float8; v_lng float8 := nullif(p->>'lng', '')::float8; v_acc float8 := nullif(p->>'acc', '')::float8; lim numeric := _setting('site_gps_accuracy_m');
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'عنوان المنظومة لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active', 'returned') or a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if v_type not in ('residential', 'project') then raise exception 'اختر نوع الموقع: سكن أو مشروع'; end if;
  if v_type = 'residential' then v_purpose := 'household';
  else
    v_purpose := p->>'purpose';
    if v_purpose not in ('industrial', 'project', 'agricultural', 'vet', 'other') then raise exception 'اختر نوع المشروع: صناعي، تجاري، زراعي، بيطري، أو أخرى'; end if;
    if v_purpose = 'other' then
      v_other := regexp_replace(trim(coalesce(p->>'purpose_other', '')), '\s+', ' ', 'g');
      if length(v_other) < 3 or length(v_other) > 60 then raise exception 'اكتب نوع المشروع (3 إلى 60 حرفاً)'; end if;
    end if;
  end if;
  if v_lat is null or v_lng is null then raise exception 'حدّد موقع المنظومة بالـGPS من الهاتف وأنت في الموقع'; end if;
  if not _geo_in_iraq(v_lat, v_lng) then raise exception 'الموقع المحدد خارج العراق — أعد تحديد الموقع'; end if;
  if v_acc is null or v_acc > lim then raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م) — انتقل إلى مكان مكشوف وأعد المحاولة', round(coalesce(v_acc, 0)), lim; end if;
  if v_purpose is distinct from coalesce(a.purpose, 'household') and exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر نوع المشروع بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  update applications set site_type = v_type, purpose = v_purpose, purpose_other = v_other, lat = round(v_lat::numeric, 6), lng = round(v_lng::numeric, 6),
    site_geo = jsonb_build_object('lat', round(v_lat::numeric, 6), 'lng', round(v_lng::numeric, 6), 'acc', round(v_acc::numeric, 1), 'at', now(), 'source', 'gps',
      'address', nullif(left(trim(coalesce(p->>'address', '')), 160), '')), updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'تثبيت عنوان المنظومة بالـGPS',
    case when v_type = 'residential' then 'سكن' else 'مشروع — ' || coalesce(v_other, _purpose_label(v_purpose)) end || ' · دقة ±' || round(v_acc) || ' م'
    || coalesce(' · ' || nullif(left(trim(coalesce(p->>'address', '')), 160), ''), ''));
  return a;
end $function$;

-- لا تكتمل الخطوة الأولى قبل تثبيت عنوان المنظومة
create or replace function public._guard_site() returns trigger language plpgsql security definer set search_path to 'public' as $function$
begin
  if new.stage > old.stage and old.stage = 1 and new.program = 'solar' and (new.site_geo is null or new.site_type is null) then
    raise exception 'ثبّت عنوان المنظومة بالـGPS واختر نوع الموقع (سكن أو مشروع) قبل إكمال الخطوة الأولى'; end if;
  return new;
end $function$;
drop trigger if exists trg_guard_site on applications;
create trigger trg_guard_site before update of stage on applications for each row execute function _guard_site();

-- قائمة التدقيق: بند «عنوان المنظومة بالـGPS ونوع الموقع»
create or replace function public._intake_items(a applications) returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare p profiles; it jsonb := '[]'::jsonb; fz app_documents; rejdoc uuid; v_bank uuid; hh boolean; plabel text;
begin
  if a.program is distinct from 'solar' then return '[]'::jsonb; end if;
  select * into p from profiles where id = a.citizen_id;
  hh := coalesce(a.purpose, 'household') = 'household';
  plabel := coalesce(case when a.purpose = 'other' then a.purpose_other end, _purpose_label(coalesce(a.purpose, 'household')));
  v_bank := coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid);
  fz := _latest_feasibility(a.id);
  it := it || _ci('national_id', 'رقم البطاقة الوطنية', 'بيانات الحساب', coalesce(p.national_id, '') ~ '^[0-9]{12}$', '1')
           || _ci('phone', 'رقم الهاتف', 'بيانات الحساب', coalesce(p.phone, '') ~ '^07[3-9][0-9]{8}$', 'profile')
           || _ci('governorate', 'المحافظة', 'بيانات الحساب', coalesce(p.governorate, '') <> '', 'profile')
           || _ci('employer', 'جهة العمل', 'بيانات الحساب', coalesce(trim(p.employer), '') <> '', 'profile')
           || _ci('monthly_salary', 'الدخل الشهري', 'بيانات الحساب', coalesce(p.monthly_salary, 0) > 0, 'profile');
  it := it || _ci('site', 'عنوان المنظومة بالـGPS ونوع الموقع (سكن أو مشروع)', 'بيانات الطلب', a.site_geo is not null and a.site_type is not null, '1')
           || _ci('kyc', 'التحقق من الهوية بالسيلفي وفحص الحيوية', 'بيانات الطلب', coalesce((a.kyc->>'liveness')::boolean, false), '1')
           || _ci('ur', 'رقم «أور»', 'بيانات الطلب', coalesce(a.ur_number, '') <> '', '2')
           || _ci('offer', 'المنظومة المختارة', 'بيانات الطلب', a.offer_id is not null, '3')
           || _ci('bank', 'المصرف المختار', 'بيانات الطلب', v_bank is not null, '3');
  it := it || _ci('quote', 'عرض المورد المقدَّم (مستند مرفق)', 'المستندات — ' || plabel,
                  exists (select 1 from app_documents where application_id = a.id and kind = 'quote'), '3');
  if not hh then
    it := it || _ci('feasibility', 'دراسة الجدوى', 'المستندات — ' || plabel, fz.id is not null, '3');
  end if;
  if coalesce(a.feasibility_rejections, 0) > 0 then
    select feasibility_doc into rejdoc from expert_referrals where application_id = a.id and status = 'non_conforming' order by decided_at desc limit 1;
    it := it || _ci('feasibility_update', 'دراسة جدوى حقيقية محدّثة بأرقام واقعية (بعد قرار الخبير)', 'المستندات — ' || plabel,
                    fz.id is not null and fz.id is distinct from rejdoc, '3');
  end if;
  it := it || _ci('guarantee', case when a.guarantee_type = 'mortgage' then 'بيانات العقار المرهون' else 'الكفلاء وموافقتهم برمز التحقق' end, 'الضمان', a.guarantee is not null, '4');
  if a.guarantee_type = 'mortgage' then
    it := it || _ci('deed', 'صورة سند العقار بالكاميرا وإقرار الملكية', 'الضمان',
                    a.ownership is not null and exists (select 1 from app_documents where application_id = a.id and kind = 'deed'), '4');
  end if;
  it := it || _ci('payment', 'دفع عمولة المصرف والرسوم', 'الدفع والتوقيع',
                  exists (select 1 from payments where application_id = a.id and bank_id = v_bank and status = 'paid'), '5')
           || _ci('signed', 'التوقيع الإلكتروني على الطلب', 'الدفع والتوقيع', a.submitted_at is not null, '5');
  return it;
end $function$;

-- غرض التمويل القديم (الجلسة 16) يقبل القيم الجديدة أيضاً
create or replace function public.set_app_purpose(p_app uuid, p_purpose text) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'غرض التمويل لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active','returned') or a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if p_purpose not in ('household','agricultural','industrial','project','vet') then raise exception 'اختر غرض التمويل من القائمة'; end if;
  if p_purpose = a.purpose then return a; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر غرض التمويل بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  update applications set purpose = p_purpose, purpose_other = null, site_type = case when p_purpose = 'household' then 'residential' else 'project' end, updated_at = now()
  where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'تحديد غرض التمويل: ' || _purpose_label(p_purpose),
    case when p_purpose = 'household' then 'المستند المطلوب: عرض المورد المقدَّم' else 'المستندات المطلوبة: عرض المورد المقدَّم + دراسة جدوى' end);
  return a;
end $function$;

-- ───────── هـ) توثيق التركيب في المرحلة 31 (فريق المورد الفني) ─────────
create or replace function public.install_proof(p_app uuid, p_kind text, p_data text default null, p_meta jsonb default '{}'::jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'extensions' as $function$
declare me profiles; a applications; g jsonb; lat float8; lng float8; acc float8; d float8; mx numeric := _setting('install_max_distance_m');
  mime text; sz int := length(coalesce(p_data, '')); did uuid; ig jsonb; lbl text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me is null or a is null or me.portal <> 'supplier' or me.role not in ('supplier_admin', 'supplier_tech') or a.supplier_id is distinct from me.org_id then
    raise exception 'الطلب لا يخص شركتك'; end if;
  if coalesce(me.disabled, false) then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.program is distinct from 'solar' then raise exception 'هذا التوثيق لمنظومات الطاقة الشمسية — المشروع البيطري له توثيق التوريد والتركيب والتشغيل'; end if;
  if a.stage <> 31 or a.status <> 'active' then raise exception 'التوثيق بعد صدور أمر الشراء من المصرف (المرحلة 31)'; end if;
  p_meta := coalesce(p_meta, '{}'::jsonb);
  g := coalesce(p_meta->'gps', '{}'::jsonb);
  lat := nullif(g->>'lat', '')::float8; lng := nullif(g->>'lng', '')::float8; acc := nullif(g->>'acc', '')::float8;
  if lat is null or lng is null then raise exception 'فعّل الموقع (GPS) في الهاتف — كل توثيق يُثبَّت بموقعه'; end if;
  if not _geo_in_iraq(lat, lng) then raise exception 'الموقع خارج العراق — أعد تحديد الموقع'; end if;
  if acc is null or acc > _setting('install_gps_accuracy_m') then
    raise exception 'دقة الموقع ±% م أضعف من المطلوب (±% م) — اصعد إلى سطح المبنى أو مكان مكشوف وأعد المحاولة', round(coalesce(acc, 0)), _setting('install_gps_accuracy_m'); end if;

  if p_kind = 'install_gps' then
    if a.site_geo is not null then
      d := _geo_dist_m(lat, lng, (a.site_geo->>'lat')::float8, (a.site_geo->>'lng')::float8);
      if d > mx then raise exception 'موقعك يبعد % م عن عنوان المنظومة الذي ثبّته المقترض (الحد % م) — ثبّت الموقع وأنت في موقع التركيب نفسه', round(d), mx; end if;
    end if;
    ig := jsonb_build_object('lat', round(lat::numeric, 6), 'lng', round(lng::numeric, 6), 'acc', round(acc::numeric, 1), 'at', now(),
      'by', me.full_name, 'by_code', me.staff_code, 'by_title', _role_title(me.role), 'dist_m', round(d::numeric), 'ref', case when a.site_geo is null then 'none' else 'site' end);
    update applications set install_geo = ig, updated_at = now() where id = a.id;
    -- تغيّر الموقع: الأدلة الملتقطة على الموقع السابق تُعاد
    delete from app_documents where application_id = a.id and kind in ('install_panels', 'install_inverter', 'install_video')
      and _geo_dist_m(lat, lng, (meta->'gps'->>'lat')::float8, (meta->'gps'->>'lng')::float8) > mx;
    perform _ev(a.id, 31, 'تثبيت موقع تركيب المنظومة بالـGPS',
      'دقة ±' || round(acc) || ' م' || case when d is not null then ' · يبعد ' || round(d) || ' م عن عنوان المنظومة الذي ثبّته المقترض' else ' · لا عنوان GPS سابق للمقترض (طلب قديم)' end
      || ' · ' || coalesce(me.staff_code, ''));
    return ig;
  end if;

  if p_kind not in ('install_panels', 'install_inverter', 'install_video') then raise exception 'نوع توثيق غير معروف'; end if;
  if a.install_geo is null then raise exception 'ثبّت موقع التركيب بالـGPS أولاً'; end if;
  d := _geo_dist_m(lat, lng, (a.install_geo->>'lat')::float8, (a.install_geo->>'lng')::float8);
  if d > mx then raise exception 'التُقط هذا التوثيق على بعد % م من موقع التركيب المثبّت — صوّر في موقع المنظومة نفسه', round(d); end if;
  if coalesce((p_meta->>'live')::boolean, false) is not true then raise exception 'يُلتقط التوثيق بكاميرا الهاتف مباشرة — لا يُقبل ملف من المعرض'; end if;
  if p_kind = 'install_video' then
    mime := substring(p_data from '^data:(video/(webm|mp4));base64,');
    if mime is null then raise exception 'صيغة الفيديو غير مقبولة — صوّر من داخل المنصة'; end if;
    if sz > 12000000 then raise exception 'الفيديو أكبر من المسموح — صوّر مقطعاً أقصر (حتى 20 ثانية)'; end if;
    if coalesce(nullif(p_meta->>'duration', '')::numeric, 0) < _setting('install_video_min_s') then
      raise exception 'مدة الفيديو أقل من % ثوانٍ — صوّر المنظومة وهي تعمل', _setting('install_video_min_s'); end if;
  else
    mime := substring(p_data from '^data:(image/jpeg);base64,');
    if mime is null then raise exception 'الصورة تُلتقط بكاميرا الهاتف (JPEG)'; end if;
    if sz > 4000000 then raise exception 'حجم الصورة كبير — الحد 3 ميغابايت'; end if;
  end if;
  delete from app_documents where application_id = a.id and kind = p_kind;
  insert into app_documents(application_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, p_kind, 'camera', mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    p_meta || jsonb_build_object('server_at', now(), 'dist_m', round(d::numeric), 'by_code', me.staff_code, 'by', me.full_name), me.id, _role_title(me.role))
  returning id into did;
  lbl := case p_kind when 'install_panels' then 'صورة الألواح المركّبة' when 'install_inverter' then 'صورة العاكس والبطاريات' else 'فيديو تشغيل المنظومة' end;
  perform _ev(a.id, 31, 'توثيق التركيب: ' || lbl, 'كاميرا مباشرة · على بعد ' || round(d) || ' م من موقع التركيب · ' || coalesce(me.staff_code, ''));
  return jsonb_build_object('id', did, 'dist_m', round(d));
end $function$;

-- لا يُعتمد محضر التركيب قبل اكتمال التوثيق
create or replace function public._guard_install() returns trigger language plpgsql security definer set search_path to 'public' as $function$
declare miss text;
begin
  if new.stage > old.stage and old.stage = 31 and new.program = 'solar' then
    if new.install_geo is null then raise exception 'اعتماد المحضر: يثبّت فني المورد موقع التركيب بالـGPS أولاً'; end if;
    select string_agg(l, '، ') into miss from (values ('install_panels', 'صورة الألواح المركّبة'), ('install_inverter', 'صورة العاكس والبطاريات'), ('install_video', 'فيديو تشغيل المنظومة')) v(k, l)
      where not exists (select 1 from app_documents d where d.application_id = new.id and d.kind = v.k);
    if miss is not null then raise exception 'اعتماد المحضر يتطلب توثيق التركيب: %', miss; end if;
  end if;
  return new;
end $function$;
drop trigger if exists trg_guard_install on applications;
create trigger trg_guard_install before update of stage on applications for each row execute function _guard_install();

-- ───────── و) مهلة التنفيذ ─────────
create or replace function public._exec_deadline(a applications) returns timestamptz language sql stable set search_path to 'public' as $f$
  select case when a.cbi_approved_at is null then null
    else greatest(coalesce(a.exec_extended_until, '-infinity'::timestamptz), a.cbi_approved_at + make_interval(days => _setting('execution_window_days')::int)) end $f$;

create or replace function public._guard_exec() returns trigger language plpgsql security definer set search_path to 'public' as $function$
declare dl timestamptz;
begin
  if new.stage > old.stage and old.stage between 24 and 34 and new.cbi_approved_at is not null then
    dl := _exec_deadline(new);
    if dl < now() then
      raise exception 'انتهت مهلة التنفيذ في % (% يوماً من تعزيز السلفة%) — يلزم تمديد مسبّب من الإدارة العليا للمصرف، أو رفض الطلب ليعود المبلغ المحجوز إلى ائتمان المصرف',
        to_char(dl at time zone 'Asia/Baghdad', 'YYYY-MM-DD'), _setting('execution_window_days'), case when new.exec_extensions > 0 then ' مع التمديد' else '' end; end if;
  end if;
  return new;
end $function$;
drop trigger if exists trg_guard_exec on applications;
create trigger trg_guard_exec before update of stage on applications for each row execute function _guard_exec();

create or replace function public.exec_extend(p_app uuid, p_days integer, p_note text) returns applications
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; a applications; dl timestamptz; mx int := _setting('exec_extension_max_days')::int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if me is null or a is null or me.role <> 'bank_md' or a.bank_id is distinct from me.org_id then raise exception 'تمديد مهلة التنفيذ للإدارة العليا للمصرف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.status <> 'active' or a.stage not between 24 and 34 or a.cbi_approved_at is null then raise exception 'التمديد للطلبات المعزَّزة قبل الصرف للمورد'; end if;
  if a.exec_extensions >= 1 then raise exception 'مُدّدت مهلة هذا الطلب مسبقاً — التمديد مرة واحدة فقط'; end if;
  if p_days is null or p_days < 1 or p_days > mx then raise exception 'مدة التمديد بين 1 و% يوماً', mx; end if;
  if length(coalesce(trim(p_note), '')) < 10 then raise exception 'اكتب سبب التمديد بوضوح — يُسجَّل باسم منصبك ويطّلع عليه البنك المركزي وهيئة النزاهة'; end if;
  dl := _exec_deadline(a);
  update applications set exec_extended_until = greatest(dl, now()) + make_interval(days => p_days), exec_extensions = exec_extensions + 1,
    exec_extension_note = trim(p_note), updated_at = now() where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'تمديد مهلة التنفيذ ' || p_days || ' يوماً حتى ' || to_char(a.exec_extended_until at time zone 'Asia/Baghdad', 'YYYY-MM-DD'), trim(p_note));
  insert into integrity_alerts(type, severity, title, details, application_id, entity)
  values ('exec_extension', 'medium', 'تمديد مهلة تنفيذ تمويل', a.code || ': مُدّدت المهلة ' || p_days || ' يوماً — ' || trim(p_note), a.id, (select name from orgs where id = a.bank_id));
  return a;
end $function$;

-- ───────── ز) الإشعارات داخل المنصة ─────────
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  org_id uuid references orgs(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  portal text,
  kind text not null,
  title text not null,
  body text,
  ref_id uuid,
  created_at timestamptz not null default now()
);
create index if not exists notifications_org on notifications(org_id, created_at desc);
create table if not exists notification_reads (
  notification_id uuid references notifications(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (notification_id, user_id)
);
alter table notifications enable row level security;
alter table notification_reads enable row level security;
drop policy if exists read_notifs on notifications;
create policy read_notifs on notifications for select using (user_id = auth.uid() or (org_id = my_org() and (portal is null or portal = my_portal())));
drop policy if exists read_own_reads on notification_reads;
create policy read_own_reads on notification_reads for select using (user_id = auth.uid());
revoke insert, update, delete on notifications, notification_reads from anon, authenticated;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'notifications') then
    alter publication supabase_realtime add table notifications; end if;
end $$;

create or replace function public._notify(p_org uuid, p_portal text, p_kind text, p_title text, p_body text, p_ref uuid) returns void
language sql security definer set search_path to 'public' as $f$
  insert into notifications(org_id, portal, kind, title, body, ref_id) values (p_org, p_portal, p_kind, p_title, p_body, p_ref) $f$;
revoke execute on function public._notify(uuid, text, text, text, text, uuid) from public, anon, authenticated;

create or replace function public.my_notifications() returns jsonb
language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object(
    'items', coalesce((select jsonb_agg(x order by x->>'at' desc) from (
      select jsonb_build_object('id', n.id, 'kind', n.kind, 'title', n.title, 'body', n.body, 'ref', n.ref_id, 'at', n.created_at,
        'read', exists (select 1 from notification_reads r where r.notification_id = n.id and r.user_id = auth.uid())) x
      from notifications n where n.user_id = auth.uid() or (n.org_id = my_org() and (n.portal is null or n.portal = my_portal()))
      order by n.created_at desc limit 40) q), '[]'::jsonb),
    'unread', (select count(*) from notifications n where (n.user_id = auth.uid() or (n.org_id = my_org() and (n.portal is null or n.portal = my_portal())))
      and not exists (select 1 from notification_reads r where r.notification_id = n.id and r.user_id = auth.uid()))) $f$;

create or replace function public.notifications_read(p_ids uuid[] default null) returns void
language sql security definer set search_path to 'public' as $f$
  insert into notification_reads(notification_id, user_id)
  select n.id, auth.uid() from notifications n
  where (n.user_id = auth.uid() or (n.org_id = my_org() and (n.portal is null or n.portal = my_portal()))) and (p_ids is null or n.id = any(p_ids))
  on conflict do nothing $f$;

-- ───────── ح) إعلان المبادرات الجديدة للمصارف ─────────
create table if not exists initiatives (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  title text not null,
  summary text not null,
  details text,
  sectors text[] not null default '{}',
  budget bigint,
  start_on date not null,
  end_on date,
  circular_no text,
  status text not null default 'published' check (status in ('published', 'withdrawn')),
  created_by uuid references profiles(id),
  created_by_title text,
  created_at timestamptz not null default now(),
  withdrawn_at timestamptz,
  withdraw_note text
);
create table if not exists initiative_banks (
  initiative_id uuid references initiatives(id) on delete cascade,
  bank_id uuid references orgs(id) on delete cascade,
  seen_at timestamptz, seen_by_title text,
  response text check (response is null or response in ('join', 'decline')),
  response_note text, responded_at timestamptz, responded_by_title text,
  primary key (initiative_id, bank_id)
);
alter table initiatives enable row level security;
alter table initiative_banks enable row level security;
drop policy if exists read_initiatives on initiatives;
create policy read_initiatives on initiatives for select using (my_portal() in ('cbi', 'integrity', 'admin')
  or (my_portal() = 'bank' and exists (select 1 from initiative_banks ib where ib.initiative_id = initiatives.id and ib.bank_id = my_org())));
drop policy if exists read_initiative_banks on initiative_banks;
create policy read_initiative_banks on initiative_banks for select using (my_portal() in ('cbi', 'integrity', 'admin') or (my_portal() = 'bank' and bank_id = my_org()));
revoke insert, update, delete on initiatives, initiative_banks from anon, authenticated;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'initiatives') then alter publication supabase_realtime add table initiatives; end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'initiative_banks') then alter publication supabase_realtime add table initiative_banks; end if;
end $$;

create or replace function public.cbi_publish_initiative(p jsonb) returns initiatives
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; r initiatives; seq int; banks uuid[]; v_sectors text[]; b uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'cbi_admin' or coalesce(me.disabled, false) then raise exception 'إعلان المبادرات للبنك المركزي'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if length(coalesce(trim(p->>'title'), '')) < 5 then raise exception 'اكتب عنوان المبادرة'; end if;
  if length(coalesce(trim(p->>'summary'), '')) < 10 then raise exception 'اكتب ملخص المبادرة (10 أحرف على الأقل)'; end if;
  if nullif(p->>'start_on', '') is null then raise exception 'حدّد تاريخ بدء المبادرة'; end if;
  if nullif(p->>'end_on', '') is not null and (p->>'end_on')::date < (p->>'start_on')::date then raise exception 'تاريخ الانتهاء قبل تاريخ البدء'; end if;
  v_sectors := array(select jsonb_array_elements_text(coalesce(p->'sectors', '[]'::jsonb)));
  if exists (select 1 from unnest(v_sectors) s where s not in ('residential', 'industrial', 'project', 'agricultural', 'vet', 'other', 'vet_program')) then raise exception 'قطاع غير معروف'; end if;
  banks := array(select id from orgs where type = 'bank' and (jsonb_array_length(coalesce(p->'banks', '[]'::jsonb)) = 0 or id::text in (select jsonb_array_elements_text(p->'banks'))));
  if coalesce(array_length(banks, 1), 0) = 0 then raise exception 'اختر مصرفاً واحداً على الأقل'; end if;
  perform pg_advisory_xact_lock(hashtext('initiatives_code'));
  select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from initiatives where split_part(code, '-', 2) = to_char(now(), 'YYYY');
  insert into initiatives(code, title, summary, details, sectors, budget, start_on, end_on, circular_no, created_by, created_by_title)
  values ('MBD-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 3, '0'), trim(p->>'title'), trim(p->>'summary'), nullif(trim(coalesce(p->>'details', '')), ''),
    v_sectors, nullif(regexp_replace(coalesce(p->>'budget', ''), '[^0-9]', '', 'g'), '')::bigint, (p->>'start_on')::date, nullif(p->>'end_on', '')::date,
    nullif(trim(coalesce(p->>'circular_no', '')), ''), me.id, _role_title(me.role))
  returning * into r;
  foreach b in array banks loop
    insert into initiative_banks(initiative_id, bank_id) values (r.id, b);
    perform _notify(b, 'bank', 'initiative', 'مبادرة جديدة من البنك المركزي: ' || r.title, r.code || ' — ' || left(r.summary, 180), r.id);
  end loop;
  perform _audit('إعلان مبادرة جديدة', r.code, jsonb_build_object('title', r.title, 'banks', array_length(banks, 1)));
  return r;
end $function$;

create or replace function public.cbi_withdraw_initiative(p_id uuid, p_note text) returns initiatives
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; r initiatives; b uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'cbi_admin' then raise exception 'سحب المبادرات للبنك المركزي'; end if;
  if length(coalesce(trim(p_note), '')) < 5 then raise exception 'اكتب سبب السحب'; end if;
  update initiatives set status = 'withdrawn', withdrawn_at = now(), withdraw_note = trim(p_note) where id = p_id and status = 'published' returning * into r;
  if r.id is null then raise exception 'المبادرة غير موجودة أو مسحوبة'; end if;
  for b in select bank_id from initiative_banks where initiative_id = r.id loop
    perform _notify(b, 'bank', 'initiative', 'سُحبت المبادرة: ' || r.title, r.code || ' — ' || trim(p_note), r.id);
  end loop;
  return r;
end $function$;

create or replace function public.bank_initiative_seen(p_id uuid) returns void
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'bank' then return; end if;
  update initiative_banks set seen_at = now(), seen_by_title = _role_title(me.role) where initiative_id = p_id and bank_id = me.org_id and seen_at is null;
end $function$;

create or replace function public.bank_initiative_respond(p_id uuid, p_response text, p_note text default null) returns initiative_banks
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; r initiative_banks; i initiatives;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'bank' or me.role not in ('bank_md', 'bank_initiatives_mgr') then raise exception 'الرد على المبادرة للإدارة العليا للمصرف أو مدير قسم المبادرات'; end if;
  if p_response not in ('join', 'decline') then raise exception 'اختر: المشاركة أو الاعتذار'; end if;
  if p_response = 'decline' and length(coalesce(trim(p_note), '')) < 5 then raise exception 'اكتب سبب الاعتذار'; end if;
  select * into i from initiatives where id = p_id;
  if i.id is null or i.status <> 'published' then raise exception 'المبادرة غير متاحة'; end if;
  update initiative_banks set response = p_response, response_note = nullif(trim(coalesce(p_note, '')), ''), responded_at = now(), responded_by_title = _role_title(me.role),
    seen_at = coalesce(seen_at, now()), seen_by_title = coalesce(seen_by_title, _role_title(me.role))
  where initiative_id = p_id and bank_id = me.org_id returning * into r;
  if r.initiative_id is null then raise exception 'المبادرة لم تُوجَّه لمصرفك'; end if;
  perform _notify((select id from orgs where type = 'cbi' limit 1), 'cbi', 'initiative_reply',
    (select name from orgs where id = me.org_id) || (case when p_response = 'join' then ' يشارك في ' else ' يعتذر عن ' end) || i.title, i.code || coalesce(' — ' || nullif(trim(coalesce(p_note, '')), ''), ''), i.id);
  return r;
end $function$;

-- ───────── ط) حسابات هيئة النزاهة يضيفها البنك المركزي ─────────
create or replace function public.cbi_integrity_users() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal <> 'cbi' then raise exception 'غير مخوّل'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'username', username, 'full_name', full_name, 'phone', phone, 'staff_code', staff_code,
    'disabled', coalesce(disabled, false), 'must_change_password', must_change_password, 'created_at', created_at) order by created_at), '[]')
    from profiles where role = 'integrity_viewer');
end $function$;

create or replace function public.cbi_create_integrity_user(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; pr profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.role <> 'cbi_admin' or coalesce(me.disabled, false) then raise exception 'إضافة حسابات هيئة النزاهة للبنك المركزي'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  pr := _create_staff(p, 'integrity_viewer', (select id from orgs where type = 'integrity' limit 1));
  perform _audit('إضافة حساب هيئة النزاهة من البنك المركزي', pr.username, jsonb_build_object('by', me.username));
  return jsonb_build_object('username', pr.username, 'staff_code', pr.staff_code);
end $function$;

create or replace function public.cbi_set_integrity_user(p_user uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $function$
declare me profiles; t profiles; pw text := p->>'password';
begin
  select * into me from profiles where id = auth.uid();
  select * into t from profiles where id = p_user;
  if me is null or me.role <> 'cbi_admin' or t is null or t.role <> 'integrity_viewer' then raise exception 'غير مخوّل'; end if;
  if p ? 'disabled' then update profiles set disabled = (p->>'disabled')::boolean, updated_at = now() where id = t.id; end if;
  if nullif(pw, '') is not null then
    if length(pw) < 8 or pw !~ '[0-9]' or pw !~ '[A-Za-z]' then raise exception 'كلمة المرور المؤقتة 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً'; end if;
    update auth.users set encrypted_password = crypt(pw, gen_salt('bf')), updated_at = now() where id = t.id;
    update profiles set must_change_password = true where id = t.id;
  end if;
  perform _audit('تعديل حساب هيئة النزاهة من البنك المركزي', t.username, p - 'password');
  return jsonb_build_object('ok', true);
end $function$;

-- مشغّل النظام لا يضيف حسابات هيئة النزاهة ولا يحوّل أحداً إليها
create or replace function public.admin_create_user(p jsonb) returns profiles
language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $function$
declare v_user text := lower(trim(coalesce(p->>'username', ''))); v_role text := p->>'role'; v_portal text; v_org orgs; v_br branches; uid uuid; pr profiles;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if v_role = 'integrity_viewer' then raise exception 'حسابات هيئة النزاهة يضيفها البنك المركزي من لوحته'; end if;
  if v_user !~ '^[a-z][a-z0-9._-]{2,30}$' then raise exception 'اسم المستخدم: حروف إنجليزية صغيرة وأرقام ونقطة، 3 أحرف على الأقل ويبدأ بحرف'; end if;
  if exists (select 1 from profiles where username = v_user) or exists (select 1 from auth.users where email = v_user || '@alwah.demo') then raise exception 'اسم المستخدم مستخدم مسبقاً'; end if;
  if length(coalesce(p->>'password', '')) < 8 then raise exception 'كلمة المرور 8 أحرف على الأقل'; end if;
  if length(trim(coalesce(p->>'full_name', ''))) < 3 then raise exception 'اكتب الاسم أو المسمى الوظيفي'; end if;
  v_portal := _portal_of_role(v_role);
  if v_portal is null or v_portal = 'citizen' then raise exception 'اختر دوراً وظيفياً صحيحاً (المواطن يسجّل بنفسه من بوابة المواطن)'; end if;
  select * into v_org from orgs where id = nullif(p->>'org_id', '')::uuid;
  if v_org is null or v_org.type <> _org_type_of_portal(v_portal) then raise exception 'اختر الجهة المناسبة لهذا الدور'; end if;
  if nullif(p->>'branch_id', '') is not null then
    select * into v_br from branches where id = (p->>'branch_id')::uuid;
    if v_br is null or v_br.bank_id <> v_org.id then raise exception 'الفرع لا يتبع هذا المصرف'; end if;
  end if;
  uid := _mk_user(v_user, p->>'password', trim(p->>'full_name'), v_role, v_portal, v_org.code, _opt_phone(p->>'phone'), null);
  update profiles set branch_id = v_br.id, must_change_password = true where id = uid returning * into pr;
  perform _audit('إنشاء مستخدم', v_user, jsonb_build_object('role', v_role, 'org', v_org.name, 'branch', v_br.name));
  return pr;
end $function$;

create or replace function public.admin_update_user(p_user uuid, p jsonb) returns profiles
language plpgsql security definer set search_path to 'public' as $function$
declare pr profiles; v_role text; v_portal text; v_org orgs; v_br uuid;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  select * into pr from profiles where id = p_user;
  if pr is null then raise exception 'المستخدم غير موجود'; end if;
  if pr.portal = 'citizen' and (p ? 'role' or p ? 'org_id') then raise exception 'لا يُغيَّر دور المواطن'; end if;
  v_role := coalesce(nullif(p->>'role', ''), pr.role);
  if (v_role = 'integrity_viewer') <> (pr.role = 'integrity_viewer') then raise exception 'حسابات هيئة النزاهة يديرها البنك المركزي من لوحته'; end if;
  v_portal := _portal_of_role(v_role);
  if pr.portal <> 'citizen' and (v_portal is null or v_portal = 'citizen') then raise exception 'دور غير صحيح'; end if;
  if pr.id = auth.uid() and v_role <> 'platform_admin' then raise exception 'لا يمكنك سحب صلاحية مشغّل النظام من حسابك'; end if;
  select * into v_org from orgs where id = coalesce(nullif(p->>'org_id', '')::uuid, pr.org_id);
  if pr.portal <> 'citizen' and (v_org is null or v_org.type <> _org_type_of_portal(v_portal)) then raise exception 'الجهة لا تناسب هذا الدور'; end if;
  v_br := case when p ? 'branch_id' then nullif(p->>'branch_id', '')::uuid else pr.branch_id end;
  if v_br is not null and not exists (select 1 from branches where id = v_br and bank_id = v_org.id) then v_br := null; end if;
  update profiles set full_name = coalesce(nullif(trim(p->>'full_name'), ''), full_name), role = v_role, portal = coalesce(v_portal, portal),
    org_id = case when portal = 'citizen' then org_id else v_org.id end, branch_id = v_br,
    phone = case when p ? 'phone' then _opt_phone(p->>'phone') else phone end, updated_at = now()
  where id = p_user returning * into pr;
  perform _audit('تعديل مستخدم', pr.username, p - 'password');
  return pr;
end $function$;

-- ───────── ي) المخاطبات الرسمية بين البنك المركزي وهيئة النزاهة — لا يطّلع عليها غيرهما ─────────
create table if not exists oversight_letters (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  from_org uuid not null references orgs(id),
  to_org uuid not null references orgs(id),
  from_user uuid references profiles(id),
  from_name text, from_title text, from_code text,
  subject text not null,
  body text not null,
  attachment text, attachment_mime text, attachment_name text,
  reply_to uuid references oversight_letters(id),
  created_at timestamptz not null default now(),
  read_at timestamptz, read_by_title text
);
alter table oversight_letters enable row level security;
-- بلا أي سياسة قراءة: لا يُقرأ الجدول مباشرة من أي حساب (ولا مشغّل النظام) — فقط عبر الدوال أدناه للجهتين
drop policy if exists admin_read_all on oversight_letters;
revoke all on oversight_letters from anon, authenticated;

create or replace function public._letters_me() returns profiles language sql stable security definer set search_path to 'public' as $f$
  select * from profiles where id = auth.uid() and portal in ('cbi', 'integrity') and not coalesce(disabled, false) $f$;
revoke execute on function public._letters_me() from public, anon, authenticated;

create or replace function public.letters_box() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles;
begin
  me := _letters_me();
  if me.id is null then raise exception 'المخاطبات بين البنك المركزي وهيئة النزاهة فقط'; end if;
  return jsonb_build_object('me_org', me.org_id, 'items', (select coalesce(jsonb_agg(jsonb_build_object('id', l.id, 'code', l.code, 'dir', case when l.from_org = me.org_id then 'out' else 'in' end,
      'from_org', fo.name, 'to_org', t.name, 'from_name', l.from_name, 'from_title', l.from_title, 'subject', l.subject, 'created_at', l.created_at,
      'read_at', l.read_at, 'reply_to', l.reply_to, 'has_att', l.attachment is not null) order by l.created_at desc), '[]')
    from oversight_letters l join orgs fo on fo.id = l.from_org join orgs t on t.id = l.to_org where me.org_id in (l.from_org, l.to_org)),
    'unread', (select count(*) from oversight_letters where to_org = me.org_id and read_at is null));
end $function$;

create or replace function public.letter_open(p_id uuid) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; l oversight_letters;
begin
  me := _letters_me();
  if me.id is null then raise exception 'المخاطبات بين البنك المركزي وهيئة النزاهة فقط'; end if;
  select * into l from oversight_letters where id = p_id and me.org_id in (from_org, to_org);
  if l.id is null then raise exception 'المخاطبة غير موجودة'; end if;
  if l.to_org = me.org_id and l.read_at is null then
    update oversight_letters set read_at = now(), read_by_title = _role_title(me.role) || coalesce(' — ' || me.staff_code, '') where id = l.id returning * into l;
  end if;
  return to_jsonb(l) || jsonb_build_object('from_org_name', (select name from orgs where id = l.from_org), 'to_org_name', (select name from orgs where id = l.to_org),
    'reply_code', (select code from oversight_letters where id = l.reply_to));
end $function$;

create or replace function public.letter_send(p jsonb) returns jsonb
language plpgsql security definer set search_path to 'public' as $function$
declare me profiles; v_to uuid; l oversight_letters; seq int; att text := nullif(p->>'attachment', ''); mime text; rt oversight_letters;
begin
  me := _letters_me();
  if me.id is null then raise exception 'المخاطبات بين البنك المركزي وهيئة النزاهة فقط'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  v_to := (select id from orgs where type = case me.portal when 'cbi' then 'integrity' else 'cbi' end limit 1);
  if length(coalesce(trim(p->>'subject'), '')) < 3 or length(trim(p->>'subject')) > 200 then raise exception 'اكتب موضوع المخاطبة (3 إلى 200 حرف)'; end if;
  if length(coalesce(trim(p->>'body'), '')) < 10 or length(p->>'body') > 20000 then raise exception 'اكتب نص المخاطبة (10 أحرف على الأقل)'; end if;
  if att is not null then
    mime := substring(att from '^data:(image/jpeg|image/png|application/pdf);base64,');
    if mime is null then raise exception 'المرفق PDF أو صورة فقط'; end if;
    if length(att) > 4000000 then raise exception 'حجم المرفق كبير — الحد 3 ميغابايت'; end if;
  end if;
  if nullif(p->>'reply_to', '') is not null then
    select * into rt from oversight_letters where id = (p->>'reply_to')::uuid and me.org_id in (from_org, to_org);
    if rt.id is null then raise exception 'المخاطبة الأصلية غير موجودة'; end if;
  end if;
  perform pg_advisory_xact_lock(hashtext('oversight_letters_code'));
  select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from oversight_letters where split_part(code, '-', 2) = to_char(now(), 'YYYY');
  insert into oversight_letters(code, from_org, to_org, from_user, from_name, from_title, from_code, subject, body, attachment, attachment_mime, attachment_name, reply_to)
  values ('MKH-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 5, '0'), me.org_id, v_to, me.id, me.full_name, _role_title(me.role), me.staff_code,
    trim(p->>'subject'), trim(p->>'body'), att, mime, nullif(left(trim(coalesce(p->>'attachment_name', '')), 120), ''), rt.id)
  returning * into l;
  perform _notify(v_to, case me.portal when 'cbi' then 'integrity' else 'cbi' end, 'letter', 'مخاطبة رسمية جديدة من ' || (select name from orgs where id = me.org_id), l.code, l.id);
  return jsonb_build_object('id', l.id, 'code', l.code);
end $function$;

-- ───────── ك) تحليل ونسب نمو للبنك المركزي ─────────
create or replace function public.cbi_analytics() returns jsonb
language plpgsql stable security definer set search_path to 'public' as $function$
declare me profiles; res jsonb;
begin
  select * into me from profiles where id = auth.uid();
  if me is null or me.portal not in ('cbi', 'integrity', 'admin') then raise exception 'غير مخوّل'; end if;
  with months as (select generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') m),
  ap as (
    select a.*, case when a.program = 'vet' then 'vet_program' when coalesce(a.purpose, 'household') = 'household' then 'residential' else a.purpose end sector,
      case when a.status = 'completed' then coalesce((select min(e.created_at) from application_events e where e.application_id = a.id and e.stage = 37), a.updated_at) end done_at
    from applications a where a.status <> 'cancelled')
  select jsonb_build_object(
    'months', (select jsonb_agg(jsonb_build_object('m', to_char(m, 'YYYY-MM'),
        'created', (select count(*) from ap where date_trunc('month', created_at) = m),
        'submitted', (select count(*) from ap where date_trunc('month', submitted_at) = m),
        'funded', (select count(*) from ap where date_trunc('month', cbi_approved_at) = m),
        'funded_amt', (select coalesce(sum(amount), 0) from ap where date_trunc('month', cbi_approved_at) = m),
        'completed', (select count(*) from ap where date_trunc('month', done_at) = m),
        'completed_amt', (select coalesce(sum(amount), 0) from ap where date_trunc('month', done_at) = m),
        'kw', (select coalesce(sum(kw), 0) from ap where date_trunc('month', done_at) = m)) order by m) from months),
    'sectors', (select coalesce(jsonb_agg(jsonb_build_object('k', sector, 'n', n, 'live', live, 'done', done, 'amt', amt, 'kw', kw) order by n desc), '[]') from (
        select sector, count(*) n, count(*) filter (where status in ('active', 'returned') and stage >= 6) live, count(*) filter (where status = 'completed') done,
          coalesce(sum(amount) filter (where cbi_approved_at is not null), 0) amt, coalesce(sum(kw) filter (where status = 'completed'), 0) kw from ap group by sector) s),
    'banks', (select coalesce(jsonb_agg(jsonb_build_object('id', bank_id, 'n', n, 'funded', funded, 'done', done, 'amt', amt, 'days', days) order by n desc), '[]') from (
        select bank_id, count(*) n, count(*) filter (where cbi_approved_at is not null) funded, count(*) filter (where status = 'completed') done,
          coalesce(sum(amount) filter (where cbi_approved_at is not null), 0) amt,
          round(avg(extract(epoch from done_at - submitted_at) / 86400) filter (where done_at is not null and submitted_at is not null)::numeric, 1) days
        from ap where bank_id is not null and stage >= 6 group by bank_id) b),
    'govs', (select coalesce(jsonb_agg(jsonb_build_object('g', governorate, 'n', n, 'done', done, 'amt', amt) order by n desc), '[]') from (
        select governorate, count(*) n, count(*) filter (where status = 'completed') done, coalesce(sum(amount) filter (where cbi_approved_at is not null), 0) amt
        from ap group by governorate) g)
  ) into res;
  return res;
end $function$;
