-- ═══════════════════════════════════════════════════════════════════════════
-- ألواح — الجلسة 16
-- (أ) غرض التمويل: منزلي / زراعي / صناعي / مشروع — والمستندات الإلزامية لكل غرض
--     منزلي: عرض المورد المقدَّم · زراعي/صناعي/مشروع: عرض المورد + دراسة جدوى
-- (ب) قائمة التدقيق لموظف الاستقبال (المرحلة 6): كل بند ناقص بنجمة حمراء ★ — لا قبول قبل اكتمالها،
--     و«رفض فوري» = إرجاع الطلب للمقترض لإكمال النواقص مع إخباره بما هو مطلوب
-- (ج) دور «الخبير المعتمد» و«بوابة الخبراء»: خبراء مختصون معتمدون خارج المصرف — استلام الطلب ← دراسة الجدوى ← القرار
--     (مطابق / غير مطابق) ← كتابة القرار ← كتابة الملاحظة. القرار «غير مطابق» يرفض الطلب بسبب دراسة الجدوى ويعيده
--     للمقترض لرفع دراسة حقيقية محدّثة، ثم يُعاد إرساله بنفس رقمه وبياناته مع علامة «مرفوض سابقاً بسبب دراسة الجدوى»
--     والاحتفاظ بالدراسة السابقة والحديثة (بعلامة «محدّثة»)
-- كل التغييرات إضافية: لا يُحذف شيء مما بُني، والطلبات القائمة تُعدّ «منزلية» تلقائياً
-- ═══════════════════════════════════════════════════════════════════════════

-- ───────── 0) القيود (يشمل أنواع الجلسة 15 kyc_face و contract_signed ومصدر esign) ─────────
alter table public.orgs drop constraint if exists orgs_type_check;
alter table public.orgs add constraint orgs_type_check check (type = any (array['bank','supplier','cbi','registry','integrity','platform','syndicate','vetdept','expert']));
alter table public.profiles drop constraint if exists profiles_portal_check;
alter table public.profiles add constraint profiles_portal_check check (portal = any (array['citizen','bank','registry','cbi','supplier','integrity','syndicate','vetdept','admin','expert']));
alter table public.app_documents drop constraint if exists app_documents_kind_check;
alter table public.app_documents add constraint app_documents_kind_check check (kind = any (array['deed','owner_id_front','owner_id_back','poa','evidence','other','quote','site',
  'mortgage_letter','annotation_mark','dd_letter','dd_auth','kyc_face','contract_signed','feasibility','expert_report']));
alter table public.app_documents drop constraint if exists app_documents_source_check;
alter table public.app_documents add constraint app_documents_source_check check (source = any (array['camera','file','demo','esign']));

-- ───────── 1) غرض التمويل وعلامات الإرجاع ─────────
alter table public.applications add column if not exists purpose text not null default 'household';
alter table public.applications drop constraint if exists applications_purpose_check;
alter table public.applications add constraint applications_purpose_check check (purpose in ('household','agricultural','industrial','project'));
alter table public.applications add column if not exists feasibility_rejections int not null default 0;  -- عدد مرات رفض دراسة الجدوى
alter table public.applications add column if not exists intake_missing jsonb;                          -- النواقص المطلوبة من المقترض عند الإرجاع

create or replace function public._purpose_label(p text) returns text language sql immutable as $f$
  select case p when 'household' then 'منزلي' when 'agricultural' then 'زراعي' when 'industrial' then 'صناعي' when 'project' then 'مشروع تجاري أو خدمي' else p end $f$;
create or replace function public._specialty_label(p text) returns text language sql immutable as $f$
  select case p when 'industrial' then 'صناعي' when 'agricultural' then 'زراعي' when 'energy' then 'طاقة وهندسة كهربائية' when 'economic' then 'اقتصادي ومالي' else p end $f$;

-- ───────── 2) الخبراء المعتمدون وإحالاتهم ─────────
insert into public.orgs(code, type, name, meta) values ('EXP', 'expert', 'سجل الخبراء المعتمدين', '{"note":"خبراء مختصون معتمدون خارج المصارف"}')
on conflict (code) do nothing;

create table if not exists public.experts (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  specialties text[] not null default '{}',
  governorate text, license_no text not null, accreditor text not null, qualification text,
  active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.expert_referrals (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  application_id uuid not null references public.applications(id) on delete cascade,
  bank_id uuid not null references public.orgs(id),
  expert_id uuid not null references public.profiles(id),
  specialty text not null check (specialty in ('industrial','agricultural','energy','economic')),
  round int not null default 1,
  feasibility_doc uuid references public.app_documents(id) on delete set null,   -- إصدار الدراسة المُحال
  status text not null default 'pending' check (status in ('pending','received','conforming','non_conforming','cancelled')),
  referral_note text, referred_by uuid, referred_by_title text,
  received_at timestamptz, decided_at timestamptz, decision_text text, notes text, report_doc uuid,
  sla_days int not null default 5, cancel_note text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists expert_referrals_app on public.expert_referrals(application_id);
create index if not exists expert_referrals_expert on public.expert_referrals(expert_id, status);
alter table public.app_documents add column if not exists expert_referral_id uuid references public.expert_referrals(id) on delete set null;

alter table public.experts enable row level security;
drop policy if exists read_experts on public.experts;
create policy read_experts on public.experts for select using (profile_id = auth.uid() or my_portal() in ('admin','bank','cbi','integrity'));
grant select on public.experts to authenticated;
revoke insert, update, delete on public.experts from authenticated, anon;

alter table public.expert_referrals enable row level security;
drop policy if exists read_xrefs on public.expert_referrals;
create policy read_xrefs on public.expert_referrals for select using (
  expert_id = auth.uid() or (my_portal() = 'bank' and bank_id = my_org()) or my_portal() in ('cbi','integrity','admin')
  or exists (select 1 from public.applications a where a.id = expert_referrals.application_id and a.citizen_id = auth.uid()));
grant select on public.expert_referrals to authenticated;
revoke insert, update, delete on public.expert_referrals from authenticated, anon;

-- الخبير يرى دراسة الجدوى وعرض المورد وتقريره فقط للطلبات المحالة إليه (لا يرى بقية الإضبارة)
drop policy if exists expert_docs on public.app_documents;
create policy expert_docs on public.app_documents for select using (
  my_portal() = 'expert' and kind in ('feasibility','quote','expert_report')
  and exists (select 1 from public.expert_referrals r where r.application_id = app_documents.application_id and r.expert_id = auth.uid() and r.status <> 'cancelled'));

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'expert_referrals') then
    alter publication supabase_realtime add table public.expert_referrals; end if;
end $$;

-- ───────── 3) الدور الجديد في الدوال المساعدة ─────────
create or replace function public._role_title(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'موظف خدمة الزبائن — العمليات الائتمانية' when 'bank_compliance' then 'موظف الامتثال وفتح الحسابات'
    when 'bank_branch_mgr' then 'مدير الفرع' when 'bank_initiatives' then 'إداري قسم المبادرات الائتمانية' when 'bank_credit' then 'مسؤول شعبة ائتمان المبادرات'
    when 'bank_inspection' then 'عضو لجنة الكشف الموقعي' when 'bank_initiatives_mgr' then 'مدير قسم المبادرات الائتمانية' when 'bank_legal' then 'مدير القسم القانوني'
    when 'bank_md' then 'الإدارة العليا للمصرف' when 'bank_admin' then 'موظف قسم الإدارة' when 'bank_ops' then 'موظف قسم العمليات المصرفية'
    when 'bank_teller' then 'أمين الصندوق' when 'bank_collection' then 'موظف التحصيل والمتابعة' when 'bank_risk' then 'مدقق المخاطر والتدقيق الداخلي'
    when 'bank_committee' then 'عضو اللجنة الائتمانية العليا' when 'bank_payroll' then 'موظف توطين الرواتب — الاستقطاع المباشر'
    when 'cbi_admin' then 'موظف البنك المركزي — دائرة الائتمان' when 'registry_officer' then 'موظف التسجيل العقاري'
    when 'supplier_admin' then 'مدير حساب المورد' when 'integrity_viewer' then 'مدقق هيئة النزاهة' when 'citizen' then 'المقترض'
    when 'syndicate_officer' then 'موظف لجنة التسجيل — نقابة الأطباء البيطريين' when 'vetdept_officer' then 'موظف دائرة البيطرة — قسم الإجازات'
    when 'expert' then 'خبير معتمد — دراسات الجدوى'
    when 'platform_admin' then 'مشغّل النظام — الإدارة العامة للمنصة' else r end $function$;

create or replace function public._role_abbr(r text) returns text language sql immutable as $function$
  select case r when 'bank_cs' then 'CS' when 'bank_compliance' then 'CO' when 'bank_branch_mgr' then 'BM' when 'bank_initiatives' then 'IN'
    when 'bank_credit' then 'CR' when 'bank_inspection' then 'IC' when 'bank_initiatives_mgr' then 'IM' when 'bank_legal' then 'LG'
    when 'bank_md' then 'MD' when 'bank_admin' then 'AD' when 'bank_ops' then 'OP' when 'bank_teller' then 'TL' when 'bank_collection' then 'CL'
    when 'bank_risk' then 'RK' when 'bank_committee' then 'CM' when 'bank_payroll' then 'PR' when 'cbi_admin' then 'CB' when 'registry_officer' then 'RE'
    when 'supplier_admin' then 'SP' when 'integrity_viewer' then 'NZ' when 'syndicate_officer' then 'SY' when 'vetdept_officer' then 'VD'
    when 'expert' then 'EX'
    when 'platform_admin' then 'SA' else 'XX' end $function$;

create or replace function public._portal_of_role(r text) returns text language sql immutable as $function$
  select case when r like 'bank\_%' then 'bank' when r = 'cbi_admin' then 'cbi' when r = 'registry_officer' then 'registry'
    when r = 'supplier_admin' then 'supplier' when r = 'integrity_viewer' then 'integrity' when r = 'syndicate_officer' then 'syndicate'
    when r = 'vetdept_officer' then 'vetdept' when r = 'platform_admin' then 'admin' when r = 'expert' then 'expert' when r = 'citizen' then 'citizen' end $function$;

create or replace function public._org_type_of_portal(p text) returns text language sql immutable as $function$
  select case p when 'bank' then 'bank' when 'cbi' then 'cbi' when 'registry' then 'registry' when 'supplier' then 'supplier'
    when 'integrity' then 'integrity' when 'syndicate' then 'syndicate' when 'vetdept' then 'vetdept' when 'admin' then 'platform' when 'expert' then 'expert' end $function$;

create or replace function public._org_roles(p_type text) returns text[] language sql immutable as $function$
  select case p_type
    when 'bank' then array['bank_cs','bank_compliance','bank_branch_mgr','bank_initiatives','bank_initiatives_mgr','bank_credit','bank_inspection',
                           'bank_legal','bank_md','bank_admin','bank_ops','bank_teller','bank_collection','bank_risk','bank_committee','bank_payroll']
    when 'cbi' then array['cbi_admin'] when 'supplier' then array['supplier_admin'] when 'syndicate' then array['syndicate_officer']
    when 'vetdept' then array['vetdept_officer'] when 'registry' then array['registry_officer'] when 'integrity' then array['integrity_viewer']
    when 'expert' then array['expert']
    else array[]::text[] end $function$;

-- ───────── 4) قائمة التدقيق ─────────
create or replace function public._ci(p_key text, p_label text, p_group text, p_ok boolean, p_fix text) returns jsonb language sql immutable as $f$
  select jsonb_build_object('key', p_key, 'label', p_label, 'group', p_group, 'ok', coalesce(p_ok, false), 'fix', p_fix) $f$;

-- آخر إصدار من دراسة الجدوى
create or replace function public._latest_feasibility(p_app uuid) returns public.app_documents language sql stable security definer set search_path = public as $f$
  select * from app_documents where application_id = p_app and kind = 'feasibility' order by coalesce((meta->>'version')::int, 0) desc, created_at desc limit 1 $f$;

-- كل بنود قائمة التدقيق (ok = مكتمل). fix = الخطوة التي يُكمل فيها المقترض النقص (1..5 أو profile)
create or replace function public._intake_items(a public.applications) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare p profiles; it jsonb := '[]'::jsonb; fz app_documents; rejdoc uuid; v_bank uuid; hh boolean;
begin
  if a.program is distinct from 'solar' then return '[]'::jsonb; end if;
  select * into p from profiles where id = a.citizen_id;
  hh := coalesce(a.purpose, 'household') = 'household';
  v_bank := coalesce(a.bank_id, nullif(a.bank_choice->>'bank_id', '')::uuid);
  fz := _latest_feasibility(a.id);
  -- بيانات الحساب
  it := it || _ci('national_id', 'رقم البطاقة الوطنية', 'بيانات الحساب', coalesce(p.national_id, '') ~ '^[0-9]{12}$', '1')
           || _ci('phone', 'رقم الهاتف', 'بيانات الحساب', coalesce(p.phone, '') ~ '^07[3-9][0-9]{8}$', 'profile')
           || _ci('governorate', 'المحافظة', 'بيانات الحساب', coalesce(p.governorate, '') <> '', 'profile')
           || _ci('employer', 'جهة العمل', 'بيانات الحساب', coalesce(trim(p.employer), '') <> '', 'profile')
           || _ci('monthly_salary', 'الدخل الشهري', 'بيانات الحساب', coalesce(p.monthly_salary, 0) > 0, 'profile');
  -- بيانات الطلب
  it := it || _ci('kyc', 'التحقق من الهوية بالسيلفي وفحص الحيوية', 'بيانات الطلب', coalesce((a.kyc->>'liveness')::boolean, false), '1')
           || _ci('ur', 'رقم «أور»', 'بيانات الطلب', coalesce(a.ur_number, '') <> '', '2')
           || _ci('offer', 'المنظومة المختارة', 'بيانات الطلب', a.offer_id is not null, '3')
           || _ci('bank', 'المصرف المختار', 'بيانات الطلب', v_bank is not null, '3');
  -- المستندات حسب غرض التمويل
  it := it || _ci('quote', 'عرض المورد المقدَّم (مستند مرفق)', 'المستندات — ' || _purpose_label(coalesce(a.purpose, 'household')),
                  exists (select 1 from app_documents where application_id = a.id and kind = 'quote'), '3');
  if not hh then
    it := it || _ci('feasibility', 'دراسة الجدوى', 'المستندات — ' || _purpose_label(a.purpose), fz.id is not null, '3');
  end if;
  if coalesce(a.feasibility_rejections, 0) > 0 then
    -- محدّثة = آخر إصدار من الدراسة غير الإصدار الذي صدر عليه قرار «غير مطابق»
    select feasibility_doc into rejdoc from expert_referrals where application_id = a.id and status = 'non_conforming' order by decided_at desc limit 1;
    it := it || _ci('feasibility_update', 'دراسة جدوى حقيقية محدّثة بأرقام واقعية (بعد قرار الخبير)', 'المستندات — ' || _purpose_label(coalesce(a.purpose, 'household')),
                    fz.id is not null and fz.id is distinct from rejdoc, '3');
  end if;
  -- الضمان
  it := it || _ci('guarantee', case when a.guarantee_type = 'mortgage' then 'بيانات العقار المرهون' else 'الكفلاء وموافقتهم برمز التحقق' end, 'الضمان', a.guarantee is not null, '4');
  if a.guarantee_type = 'mortgage' then
    it := it || _ci('deed', 'صورة سند العقار بالكاميرا وإقرار الملكية', 'الضمان',
                    a.ownership is not null and exists (select 1 from app_documents where application_id = a.id and kind = 'deed'), '4');
  end if;
  -- الدفع والتوقيع
  it := it || _ci('payment', 'دفع عمولة المصرف والرسوم', 'الدفع والتوقيع',
                  exists (select 1 from payments where application_id = a.id and bank_id = v_bank and status = 'paid'), '5')
           || _ci('signed', 'التوقيع الإلكتروني على الطلب', 'الدفع والتوقيع', a.submitted_at is not null, '5');
  return it;
end $f$;

create or replace function public._intake_missing(a public.applications) returns jsonb language sql stable security definer set search_path = public as $f$
  select coalesce(jsonb_agg(x), '[]'::jsonb) from jsonb_array_elements(_intake_items(a)) x where not (x->>'ok')::boolean $f$;

-- حالة دراسة الجدوى لدى الخبير
create or replace function public._expert_state(a public.applications) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare r expert_referrals; fz app_documents; st text; msg text;
begin
  if a.program is distinct from 'solar' or coalesce(a.purpose, 'household') = 'household' then
    return jsonb_build_object('required', false, 'ok', true, 'state', 'not_required', 'msg', 'لا تلزم دراسة جدوى للاستخدام المنزلي'); end if;
  fz := _latest_feasibility(a.id);
  select * into r from expert_referrals where application_id = a.id and status <> 'cancelled' order by round desc, created_at desc limit 1;
  if fz.id is null then st := 'no_study'; msg := 'لم يرفق المقترض دراسة الجدوى';
  elsif r.id is null then st := 'none'; msg := 'أحِل دراسة الجدوى إلى خبير معتمد مختص';
  elsif r.status = 'non_conforming' and r.feasibility_doc is distinct from fz.id then st := 'none'; msg := 'وصلت دراسة جدوى محدّثة بعد الرفض — أحِلها إلى خبير معتمد';
  elsif r.status = 'pending' then st := 'pending'; msg := 'محالة إلى الخبير ' || r.code || ' — بانتظار استلامه';
  elsif r.status = 'received' then st := 'received'; msg := 'الخبير يدرس دراسة الجدوى (' || r.code || ')';
  elsif r.status = 'non_conforming' then st := 'non_conforming'; msg := 'قرار الخبير: غير مطابق — بانتظار دراسة محدّثة من المقترض';
  elsif r.feasibility_doc is distinct from fz.id then st := 'stale'; msg := 'حُدّثت دراسة الجدوى بعد قرار الخبير — أعد الإحالة';
  else st := 'conforming'; msg := 'قرار الخبير: مطابق (' || r.code || ')'; end if;
  return jsonb_build_object('required', true, 'ok', st = 'conforming', 'state', st, 'msg', msg, 'ref', r.code, 'round', r.round);
end $f$;

create or replace function public.intake_checklist(p_app uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; a applications; it jsonb; ex jsonb; miss int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null then raise exception 'الطلب غير موجود'; end if;
  if not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin','cbi','integrity')) then raise exception 'غير مخوّل'; end if;
  it := _intake_items(a); ex := _expert_state(a);
  select count(*) into miss from jsonb_array_elements(it) x where not (x->>'ok')::boolean;
  return jsonb_build_object('applies', a.program = 'solar', 'purpose', a.purpose, 'purpose_label', _purpose_label(a.purpose), 'items', it, 'missing', miss,
    'expert', ex, 'can_accept', miss = 0 and (ex->>'ok')::boolean, 'feasibility_rejections', a.feasibility_rejections,
    'returned', a.returned_from = 6 and a.stage <= 5, 'intake_missing', a.intake_missing, 'return_note', a.return_note);
end $f$;
grant execute on function public.intake_checklist(uuid) to authenticated;

-- بوابة القبول في المرحلة 6: لا قبول قبل اكتمال قائمة التدقيق وقرار «مطابق» من الخبير (حين تلزم دراسة جدوى)
create or replace function public._intake_gate(p_app uuid) returns void language plpgsql stable security definer set search_path = public as $f$
declare a applications; miss jsonb; ex jsonb;
begin
  select * into a from applications where id = p_app;
  if a.program is distinct from 'solar' then return; end if;
  miss := _intake_missing(a);
  if jsonb_array_length(miss) > 0 then
    raise exception 'قائمة التدقيق غير مكتملة (% نواقص): % — اضغط «رفض فوري — إرجاع للمقترض لإكمال النواقص»', jsonb_array_length(miss),
      (select string_agg('★ ' || (x->>'label'), '، ') from jsonb_array_elements(miss) x); end if;
  ex := _expert_state(a);
  if not (ex->>'ok')::boolean then raise exception 'دراسة الجدوى: %', ex->>'msg'; end if;
end $f$;

-- حقن سطر البوابة في دالة المراحل القائمة (بنفس أسلوب الجلسة 12 — دون إعادة كتابتها)
do $$
declare d text := pg_get_functiondef('public.advance_application(uuid,text,text)'::regprocedure);
  anchor text := 'if a.stage = 14 and a.fees_paid_at is null then';
begin
  if position('_intake_gate' in d) = 0 then
    if position(anchor in d) = 0 then raise exception 'لم يُعثر على موضع الإضافة في advance_application'; end if;
    d := replace(d, anchor, 'if a.stage = 6 then perform _intake_gate(a.id); end if;' || E'\n    ' || anchor);
    execute d;
  end if;
end $$;

-- لا يُرسل المقترض طلبه (من الخطوة 5 إلى المصرف) وفيه نجمة حمراء
create or replace function public._guard_intake() returns trigger language plpgsql security definer set search_path = public as $f$
declare miss jsonb;
begin
  if new.stage = old.stage then return new; end if;
  if new.program = 'solar' and old.stage <= 5 and new.stage >= 6 and auth.uid() is not distinct from new.citizen_id then
    miss := _intake_missing(new);
    if jsonb_array_length(miss) > 0 then
      raise exception 'لا يُرسل الطلب قبل إكمال النواقص: %', (select string_agg('★ ' || (x->>'label'), '، ') from jsonb_array_elements(miss) x); end if;
    new.intake_missing := null;
  end if;
  return new;
end $f$;
drop trigger if exists trg_guard_intake on public.applications;
create trigger trg_guard_intake before update of stage on public.applications for each row execute function public._guard_intake();

-- «رفض فوري»: إرجاع الطلب من المرحلة 6 إلى المقترض لإكمال النواقص (يبقى رقمه وبياناته)
create or replace function public.intake_return(p_app uuid, p_note text default null) returns public.applications
language plpgsql security definer set search_path = public as $f$
declare a applications; me profiles; miss jsonb; lbls text; txt text; note text := nullif(trim(coalesce(p_note, '')), '');
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null then raise exception 'الطلب غير موجود'; end if;
  if a.program is distinct from 'solar' then raise exception 'هذا الإجراء لطلبات منظومات الطاقة الشمسية'; end if;
  if a.stage <> 6 then raise exception 'الإرجاع للمقترض من مرحلة الاستقبال (6) فقط'; end if;
  miss := _intake_missing(a);
  if jsonb_array_length(miss) = 0 and note is null then raise exception 'لا نواقص في قائمة التدقيق — اكتب في الملاحظة ما المطلوب من المقترض إكماله'; end if;
  lbls := (select string_agg('★ ' || (x->>'label'), E'\n') from jsonb_array_elements(miss) x);
  txt := 'رفض فوري — إرجاع للمقترض لإكمال النواقص' || coalesce(E'\n' || lbls, '') || coalesce(E'\nملاحظة الموظف: ' || note, '');
  -- الصلاحية والإسناد وتسجيل الحدث عبر دالة المراحل نفسها
  a := advance_application(p_app, 'return', txt);
  if note is not null then miss := miss || jsonb_build_array(_ci('note', note, 'ملاحظة موظف الاستقبال', false, null)); end if;
  update applications set stage = 5, status = 'returned', priority = 'urgent', returned_from = 6,
    return_note = coalesce(lbls, '') || coalesce(case when lbls is not null then E'\n' else '' end || 'ملاحظة: ' || note, ''),
    returned_at = now(), returned_by_title = _role_title(me.role) || coalesce(' — ' || (select name from branches where id = me.branch_id), ''),
    intake_missing = miss, bank_unit = 'المقترض', updated_at = now()
  where id = p_app returning * into a;
  return a;
end $f$;
grant execute on function public.intake_return(uuid, text) to authenticated;

-- المقترض يحدد غرض التمويل (قبل الإرسال أو عند الإرجاع)
create or replace function public.set_app_purpose(p_app uuid, p_purpose text) returns public.applications
language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or a.citizen_id is distinct from me.id then raise exception 'الطلب لا يخصك'; end if;
  if a.program is distinct from 'solar' then raise exception 'غرض التمويل لطلبات منظومات الطاقة الشمسية'; end if;
  if a.status not in ('active','returned') or a.stage > 5 then raise exception 'الطلب لدى المصرف الآن — لا يمكن تعديل بياناته'; end if;
  if p_purpose not in ('household','agricultural','industrial','project') then raise exception 'اختر غرض التمويل من القائمة'; end if;
  if p_purpose = a.purpose then return a; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status <> 'cancelled') then
    raise exception 'لا يُغيَّر غرض التمويل بعد إحالة دراسة الجدوى إلى الخبير — حدّث الدراسة نفسها'; end if;
  update applications set purpose = p_purpose, updated_at = now() where id = a.id returning * into a;
  perform _ev(a.id, a.stage, 'تحديد غرض التمويل: ' || _purpose_label(p_purpose),
    case when p_purpose = 'household' then 'المستند المطلوب: عرض المورد المقدَّم' else 'المستندات المطلوبة: عرض المورد المقدَّم + دراسة جدوى' end);
  return a;
end $f$;
grant execute on function public.set_app_purpose(uuid, text) to authenticated;

-- ───────── 5) المستندات: عرض المورد ودراسة الجدوى (ملف PDF أو صورة) — الدراسة السابقة تُحفظ ولا تُحذف ─────────
create or replace function public.add_document(p_app uuid, p_kind text, p_data text, p_source text, p_meta jsonb default '{}'::jsonb, p_referral uuid default null)
returns uuid language plpgsql security definer set search_path = public, extensions as $function$
declare me profiles; a applications; did uuid; sz int := length(coalesce(p_data, '')); mime text; v int; lbl text;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if me is null or a is null then raise exception 'غير مخوّل'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if p_kind = 'feasibility' then
    if sz > 7000000 then raise exception 'حجم دراسة الجدوى كبير — الحد 5 ميغابايت'; end if;
  elsif sz > 4000000 then raise exception 'حجم الملف كبير — الحد 3 ميغابايت'; end if;
  p_meta := coalesce(p_meta, '{}'::jsonb);
  if me.portal = 'citizen' then
    if a.citizen_id <> me.id then raise exception 'الطلب لا يخصك'; end if;
    if a.stage > 5 then raise exception 'الطلب لدى المصرف الآن'; end if;
    if a.program = 'solar' and p_kind in ('quote','feasibility') then
      -- عرض المورد ودراسة الجدوى مستندات مطبوعة: يُقبل ملف PDF أو صورة
      if p_kind = 'feasibility' and coalesce(a.purpose, 'household') = 'household' then raise exception 'دراسة الجدوى لطلبات الأغراض الزراعية والصناعية والمشاريع — اختر غرض التمويل أولاً'; end if;
      if p_kind = 'quote' then delete from app_documents where application_id = a.id and kind = 'quote';
      else
        select count(*) + 1 into v from app_documents where application_id = a.id and kind = 'feasibility';
        update app_documents set meta = meta || jsonb_build_object('superseded', true, 'superseded_at', now()) where application_id = a.id and kind = 'feasibility';
        p_meta := p_meta || jsonb_build_object('version', v, 'updated', v > 1, 'after_rejection', coalesce(a.feasibility_rejections, 0) > 0);
      end if;
    else
      if p_kind not in ('deed','owner_id_front','owner_id_back','poa') and not (a.program = 'vet' and p_kind in ('quote','site')) then raise exception 'نوع مستند غير مسموح'; end if;
      if p_source <> 'camera' or mime <> 'image/jpeg' or coalesce((p_meta->>'live')::boolean, false) is not true then
        raise exception 'يُصوَّر المستند بكاميرا الهاتف مباشرة — لا تُقبل صورة من المعرض أو ملف'; end if;
      delete from app_documents where application_id = a.id and kind = p_kind;
    end if;
  elsif me.portal = 'registry' then
    if p_kind not in ('evidence','mortgage_letter','annotation_mark') or p_referral is null
       or not exists (select 1 from mortgage_referrals where id = p_referral and application_id = a.id) then raise exception 'المرفق دليل أو كتاب رهن أو إشارة حجز على إحالة رهن فقط'; end if;
    if p_kind <> 'evidence' then delete from app_documents where referral_id = p_referral and kind = p_kind; end if;
  elsif me.portal = 'bank' then
    if a.bank_id <> me.org_id or p_kind not in ('evidence','other','kyc_face') then raise exception 'غير مخوّل'; end if;
  else raise exception 'غير مخوّل'; end if;
  insert into app_documents(application_id, referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (a.id, case when me.portal = 'registry' then p_referral end, p_kind, p_source, mime, p_data, sz, encode(extensions.digest(p_data, 'sha256'), 'hex'),
    p_meta || jsonb_build_object('server_at', now()), me.id, _role_title(me.role))
  returning id into did;
  lbl := case p_kind when 'deed' then 'صورة سند العقار' when 'owner_id_front' then 'هوية مالك العقار (الوجه)'
    when 'poa' then 'وكالة مالك العقار بالرهن' when 'owner_id_back' then 'هوية مالك العقار (الظهر)' when 'evidence' then 'دليل قرار التسجيل العقاري'
    when 'mortgage_letter' then 'صورة كتاب الرهن' when 'annotation_mark' then 'صورة إشارة حجز العقار على السند'
    when 'quote' then case when a.program = 'solar' then 'عرض المورد المقدَّم' else 'عرض سعر المورد' end
    when 'feasibility' then 'دراسة الجدوى' || case when v > 1 then ' — محدّثة (الإصدار ' || v || ') مع الاحتفاظ بالسابقة' else '' end
    when 'site' then 'صورة موقع المشروع' when 'kyc_face' then 'الصورة المرجعية لوجه المقترض (للتوقيع الإلكتروني)' else 'مستند' end;
  perform _ev(a.id, a.stage, 'إرفاق مستند: ' || lbl, case when p_source = 'camera' then 'التُقط بالكاميرا مباشرة' else 'ملف مرفوع' end);
  return did;
end $function$;

-- ───────── 6) الإحالة إلى الخبير ─────────
-- الخبراء المتاحون لطلب (لموظف المصرف) مع عبء العمل الحالي
create or replace function public.experts_for(p_app uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'name', p.full_name, 'code', p.staff_code, 'specialties', e.specialties,
      'governorate', e.governorate, 'license_no', e.license_no, 'accreditor', e.accreditor, 'qualification', e.qualification,
      'open', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status in ('pending','received')),
      'done', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status in ('conforming','non_conforming')),
      'same_gov', e.governorate = a.governorate)
    order by (e.governorate = a.governorate) desc, (select count(*) from expert_referrals r where r.expert_id = p.id and r.status in ('pending','received')), p.full_name), '[]')
    from experts e join profiles p on p.id = e.profile_id where e.active and not coalesce(p.disabled, false) and p.role = 'expert');
end $f$;
grant execute on function public.experts_for(uuid) to authenticated;

create or replace function public.refer_expert(p_app uuid, p_expert uuid, p_specialty text, p_note text default null) returns public.expert_referrals
language plpgsql security definer set search_path = public as $f$
declare me profiles; a applications; fz app_documents; e experts; ep profiles; r expert_referrals; seq int; rnd int;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app for update;
  if a is null or me.portal <> 'bank' or a.bank_id is distinct from me.org_id then raise exception 'غير مخوّل'; end if;
  if me.role <> 'bank_cs' then raise exception 'الإحالة إلى الخبير من موظف الاستقبال (خدمة الزبائن في الفرع)'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  if a.stage <> 6 or a.status not in ('active','returned') then raise exception 'الإحالة من مرحلة الاستقبال (6) فقط'; end if;
  if me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  if not _assignment_ok(a, me) then raise exception 'هذه المعاملة مسندة إلى % — يستلمها البديل عند غيابه فقط', _assignee_name(a); end if;
  if a.program is distinct from 'solar' or coalesce(a.purpose, 'household') = 'household' then raise exception 'الإحالة للخبير لطلبات الأغراض الزراعية والصناعية والمشاريع (فيها دراسة جدوى)'; end if;
  fz := _latest_feasibility(a.id);
  if fz.id is null then raise exception 'لم يرفق المقترض دراسة الجدوى — أرجع الطلب له لإكمال النقص'; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status in ('pending','received')) then raise exception 'توجد إحالة قائمة لدى خبير — انتظر قراره أو ألغِ الإحالة'; end if;
  if exists (select 1 from expert_referrals where application_id = a.id and status in ('conforming','non_conforming') and feasibility_doc = fz.id) then
    raise exception 'صدر قرار الخبير على هذا الإصدار من دراسة الجدوى'; end if;
  if p_specialty not in ('industrial','agricultural','energy','economic') then raise exception 'اختر اختصاص الخبير'; end if;
  select * into e from experts where profile_id = p_expert and active;
  select * into ep from profiles where id = p_expert and role = 'expert' and not coalesce(disabled, false);
  if e.profile_id is null or ep.id is null then raise exception 'الخبير غير متاح'; end if;
  if not (p_specialty = any(e.specialties)) then raise exception 'الخبير المختار غير معتمد في اختصاص «%»', _specialty_label(p_specialty); end if;
  select count(*) + 1 into rnd from expert_referrals where application_id = a.id and status <> 'cancelled';
  perform pg_advisory_xact_lock(hashtext('expert_referrals_code'));
  select coalesce(max(split_part(code, '-', 3)::int), 0) + 1 into seq from expert_referrals where split_part(code, '-', 2) = to_char(now(), 'YYYY');
  insert into expert_referrals(code, application_id, bank_id, expert_id, specialty, round, feasibility_doc, referral_note, referred_by, referred_by_title)
  values ('EXP-' || to_char(now(), 'YYYY') || '-' || lpad(seq::text, 5, '0'), a.id, a.bank_id, p_expert, p_specialty, rnd, fz.id,
    nullif(trim(coalesce(p_note, '')), ''), me.id, _role_title(me.role) || coalesce(' — ' || (select name from branches where id = me.branch_id), ''))
  returning * into r;
  -- اسم الخبير لا يُكتب في سجل الطلب الذي يراه المقترض (حياد الخبير)
  perform _ev(a.id, a.stage, 'إحالة دراسة الجدوى إلى خبير معتمد — اختصاص ' || _specialty_label(p_specialty) || ' — ' || r.code,
    'الجولة ' || rnd || case when rnd > 1 then ' (بعد تحديث الدراسة)' else '' end || coalesce(E'\nملاحظة: ' || r.referral_note, ''));
  return r;
end $f$;
grant execute on function public.refer_expert(uuid, uuid, text, text) to authenticated;

create or replace function public.cancel_expert_referral(p_ref uuid, p_note text) returns public.expert_referrals
language plpgsql security definer set search_path = public as $f$
declare me profiles; r expert_referrals; a applications;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from expert_referrals where id = p_ref for update;
  if r.id is null or me.portal <> 'bank' or r.bank_id is distinct from me.org_id or me.role <> 'bank_cs' then raise exception 'غير مخوّل'; end if;
  if r.status not in ('pending','received') then raise exception 'لا يمكن إلغاء إحالة صدر قرارها'; end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'اكتب سبب الإلغاء'; end if;
  select * into a from applications where id = r.application_id;
  if me.branch_id is not null and a.branch_id is distinct from me.branch_id then raise exception 'الطلب يخص فرعاً آخر'; end if;
  update expert_referrals set status = 'cancelled', cancel_note = trim(p_note), updated_at = now() where id = r.id returning * into r;
  perform _ev(r.application_id, a.stage, 'إلغاء إحالة الخبير — ' || r.code, trim(p_note));
  return r;
end $f$;
grant execute on function public.cancel_expert_referral(uuid, text) to authenticated;

-- سجل إحالات الخبراء لطلب: للمصرف والجهات الرقابية باسم الخبير، وللمقترض دون اسم الخبير
create or replace function public.app_expert_refs(p_app uuid) returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles; a applications; named boolean;
begin
  select * into me from profiles where id = auth.uid();
  select * into a from applications where id = p_app;
  if a is null or me is null then raise exception 'الطلب غير موجود'; end if;
  if not (a.citizen_id = me.id or (me.portal = 'bank' and a.bank_id = me.org_id) or me.portal in ('admin','cbi','integrity')) then raise exception 'غير مخوّل'; end if;
  named := me.portal <> 'citizen';
  return (select coalesce(jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'round', r.round, 'status', r.status, 'specialty', r.specialty,
      'specialty_label', _specialty_label(r.specialty), 'expert_name', case when named then p.full_name end, 'expert_code', case when named then p.staff_code end,
      'license_no', case when named then e.license_no end, 'accreditor', case when named then e.accreditor end,
      'created_at', r.created_at, 'received_at', r.received_at, 'decided_at', r.decided_at, 'decision_text', r.decision_text, 'notes', r.notes,
      'report_doc', r.report_doc, 'feasibility_doc', r.feasibility_doc, 'referral_note', case when named then r.referral_note end,
      'referred_by_title', case when named then r.referred_by_title end, 'cancel_note', r.cancel_note, 'sla_days', r.sla_days,
      'work_days', _wd(r.created_at, coalesce(r.decided_at, now()))) order by r.round, r.created_at), '[]')
    from expert_referrals r join profiles p on p.id = r.expert_id left join experts e on e.profile_id = r.expert_id where r.application_id = a.id);
end $f$;
grant execute on function public.app_expert_refs(uuid) to authenticated;

-- ───────── 7) بوابة الخبراء: الصندوق والإجراءات ─────────
create or replace function public.expert_inbox() returns jsonb language plpgsql stable security definer set search_path = public as $f$
declare me profiles;
begin
  select * into me from profiles where id = auth.uid();
  if me.role is distinct from 'expert' then raise exception 'غير مخوّل'; end if;
  -- المقترض لا يُعرض اسمه للخبير (حياد الخبير) — يرى المشروع والدراسة وعرض المورد فقط
  return (select coalesce(jsonb_agg(to_jsonb(r) || jsonb_build_object(
      'specialty_label', _specialty_label(r.specialty), 'app_code', a.code, 'purpose', a.purpose, 'purpose_label', _purpose_label(a.purpose),
      'kw', a.kw, 'amount', a.amount, 'price', a.price, 'term_months', a.term_months, 'governorate', a.governorate, 'city', a.city,
      'app_stage', a.stage, 'app_status', a.status, 'feasibility_rejections', a.feasibility_rejections,
      'offer_title', o.title, 'supplier_name', s.name, 'bank_name', b.name, 'work_days', _wd(r.created_at, coalesce(r.decided_at, now())),
      'history', (select coalesce(jsonb_agg(jsonb_build_object('round', h.round, 'status', h.status, 'specialty_label', _specialty_label(h.specialty),
          'decided_at', h.decided_at, 'decision_text', h.decision_text, 'notes', h.notes, 'feasibility_doc', h.feasibility_doc) order by h.created_at), '[]')
        from expert_referrals h where h.application_id = r.application_id and h.id <> r.id and h.status in ('conforming','non_conforming')))
    order by (r.status in ('pending','received')) desc, r.created_at desc), '[]')
    from expert_referrals r join applications a on a.id = r.application_id
    left join supplier_offers o on o.id = a.offer_id left join orgs s on s.id = a.supplier_id join orgs b on b.id = r.bank_id
    where r.expert_id = me.id and r.status <> 'cancelled');
end $f$;
grant execute on function public.expert_inbox() to authenticated;

create or replace function public.expert_me() returns jsonb language sql stable security definer set search_path = public as $f$
  select jsonb_build_object('specialties', e.specialties, 'specialty_labels', (select jsonb_agg(_specialty_label(x)) from unnest(e.specialties) x),
    'governorate', e.governorate, 'license_no', e.license_no, 'accreditor', e.accreditor, 'qualification', e.qualification, 'active', e.active)
  from experts e where e.profile_id = auth.uid() $f$;
grant execute on function public.expert_me() to authenticated;

create or replace function public.expert_add_report(p_ref uuid, p_data text, p_source text, p_meta jsonb default '{}'::jsonb) returns uuid
language plpgsql security definer set search_path = public, extensions as $f$
declare me profiles; r expert_referrals; did uuid; sz int := length(coalesce(p_data, '')); mime text;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from expert_referrals where id = p_ref;
  if r.id is null or me.role is distinct from 'expert' or r.expert_id <> me.id then raise exception 'غير مخوّل'; end if;
  if r.status <> 'received' then raise exception 'يُرفق التقرير بعد استلام الطلب وقبل القرار'; end if;
  mime := substring(p_data from '^data:([a-z]+/[a-z+.-]+);base64,');
  if mime is null or mime not in ('image/jpeg','image/png','application/pdf') then raise exception 'نوع الملف غير مقبول — صورة أو PDF فقط'; end if;
  if sz > 7000000 then raise exception 'حجم التقرير كبير — الحد 5 ميغابايت'; end if;
  delete from app_documents where expert_referral_id = r.id and kind = 'expert_report';
  insert into app_documents(application_id, expert_referral_id, kind, source, mime, data, bytes, sha256, meta, uploaded_by, uploaded_by_title)
  values (r.application_id, r.id, 'expert_report', case when p_source = 'camera' then 'camera' else 'file' end, mime, p_data, sz,
    encode(extensions.digest(p_data, 'sha256'), 'hex'), coalesce(p_meta, '{}'::jsonb) || jsonb_build_object('server_at', now(), 'referral', r.code), me.id, _role_title(me.role))
  returning id into did;
  return did;
end $f$;
grant execute on function public.expert_add_report(uuid, text, text, jsonb) to authenticated;

create or replace function public.expert_action(p_ref uuid, p_action text, p_data jsonb default '{}'::jsonb) returns public.expert_referrals
language plpgsql security definer set search_path = public as $f$
declare me profiles; r expert_referrals; a applications; dec text; txt text; nt text; rep uuid;
begin
  select * into me from profiles where id = auth.uid();
  select * into r from expert_referrals where id = p_ref for update;
  if r.id is null or me.role is distinct from 'expert' or r.expert_id <> me.id then raise exception 'غير مخوّل'; end if;
  if me.disabled then raise exception 'الحساب موقوف'; end if;
  if me.must_change_password then raise exception 'غيّر كلمة المرور المؤقتة أولاً من «حسابي»'; end if;
  select * into a from applications where id = r.application_id for update;

  if p_action = 'receive' then
    if r.status <> 'pending' then raise exception 'الطلب مستلم مسبقاً'; end if;
    update expert_referrals set status = 'received', received_at = now(), updated_at = now() where id = r.id returning * into r;
    perform _ev(a.id, a.stage, 'استلام الخبير المعتمد للطلب — ' || r.code, 'اختصاص ' || _specialty_label(r.specialty) || ' · بدأت مدة الدراسة (' || r.sla_days || ' أيام دوام)');
    return r;

  elsif p_action = 'decide' then
    if r.status <> 'received' then raise exception 'استلم الطلب أولاً ثم ادرس دراسة الجدوى'; end if;
    dec := p_data->>'decision';
    if dec not in ('conforming','non_conforming') then raise exception 'اختر القرار: مطابق أو غير مطابق'; end if;
    txt := trim(coalesce(p_data->>'decision_text', ''));
    if length(txt) < 10 then raise exception 'اكتب القرار مفصلاً (10 أحرف على الأقل)'; end if;
    nt := nullif(trim(coalesce(p_data->>'notes', '')), '');
    if dec = 'non_conforming' and nt is null then raise exception 'اكتب الملاحظة: ما المطلوب تصحيحه في دراسة الجدوى'; end if;
    if coalesce((p_data->>'pledge')::boolean, false) is not true then raise exception 'أقرّ بأنك درست الدراسة وأن قرارك مستقل ولا يوجد تضارب مصالح'; end if;
    rep := (select id from app_documents where expert_referral_id = r.id and kind = 'expert_report' order by created_at desc limit 1);
    update expert_referrals set status = dec, decided_at = now(), decision_text = txt, notes = nt, report_doc = rep, updated_at = now()
    where id = r.id returning * into r;
    perform _ev(a.id, a.stage, 'قرار الخبير المعتمد (اختصاص ' || _specialty_label(r.specialty) || '): ' || case when dec = 'conforming' then 'مطابق' else 'غير مطابق' end || ' — ' || r.code,
      'القرار: ' || txt || coalesce(E'\nالملاحظة: ' || nt, '') || case when rep is not null then E'\nتقرير الخبير مرفق' else '' end);
    if dec = 'non_conforming' and a.status in ('active','returned') then
      -- رفض بسبب دراسة الجدوى: يعود الطلب للمقترض بنفس رقمه وبياناته ليرفع دراسة حقيقية محدّثة
      update applications set feasibility_rejections = coalesce(feasibility_rejections, 0) + 1, updated_at = now(),
        intake_missing = jsonb_build_array(_ci('feasibility_update', 'دراسة جدوى حقيقية محدّثة بأرقام واقعية', 'المستندات', false, '3'))
      where id = a.id returning * into a;
      if a.stage = 6 then
        update applications set stage = 5, status = 'returned', priority = 'urgent', returned_from = 6,
          return_note = 'رُفض الطلب بسبب دراسة الجدوى — قرار الخبير المعتمد: ' || txt || coalesce(E'\nالمطلوب: ' || nt, ''),
          returned_at = now(), returned_by_title = 'خبير معتمد — اختصاص ' || _specialty_label(r.specialty), bank_unit = 'المقترض', updated_at = now()
        where id = a.id returning * into a;
        perform _ev(a.id, 6, 'رفض بسبب دراسة الجدوى — إعادة الطلب للمقترض',
          'المطلوب: إعداد دراسة جدوى حقيقية بأرقام واقعية ورفعها على الطلب، ثم إعادة إرساله بنفس رقمه وبياناته. تُحفظ الدراسة السابقة مع الحديثة.');
      end if;
    end if;
    return r;
  end if;
  raise exception 'إجراء غير معروف';
end $f$;
grant execute on function public.expert_action(uuid, text, jsonb) to authenticated;

-- ───────── 8) مشغّل النظام: إدارة الخبراء ─────────
create or replace function public.admin_experts() returns jsonb language plpgsql stable security definer set search_path = public as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  return (select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'username', p.username, 'name', p.full_name, 'code', p.staff_code, 'phone', p.phone,
      'disabled', p.disabled, 'specialties', e.specialties, 'governorate', e.governorate, 'license_no', e.license_no, 'accreditor', e.accreditor,
      'qualification', e.qualification, 'active', e.active,
      'open', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status in ('pending','received')),
      'conforming', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status = 'conforming'),
      'non_conforming', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status = 'non_conforming'),
      'avg_days', (select round(avg(_wd(r.created_at, r.decided_at)), 1) from expert_referrals r where r.expert_id = p.id and r.decided_at is not null),
      'overdue', (select count(*) from expert_referrals r where r.expert_id = p.id and r.status in ('pending','received') and _wd(r.created_at, now()) > r.sla_days))
    order by p.full_name), '[]') from experts e join profiles p on p.id = e.profile_id);
end $f$;
grant execute on function public.admin_experts() to authenticated;

create or replace function public._expert_fields(p jsonb) returns void language plpgsql as $f$
declare s text;
begin
  if jsonb_typeof(p->'specialties') <> 'array' or jsonb_array_length(p->'specialties') = 0 then raise exception 'اختر اختصاصاً واحداً على الأقل'; end if;
  for s in select jsonb_array_elements_text(p->'specialties') loop
    if s not in ('industrial','agricultural','energy','economic') then raise exception 'اختصاص غير معروف'; end if;
  end loop;
  if length(trim(coalesce(p->>'license_no', ''))) < 3 then raise exception 'اكتب رقم الاعتماد'; end if;
  if length(trim(coalesce(p->>'accreditor', ''))) < 3 then raise exception 'اكتب جهة الاعتماد (مثل: نقابة المهندسين، نقابة الاقتصاديين)'; end if;
end $f$;

create or replace function public.admin_create_expert(p jsonb) returns public.profiles language plpgsql security definer set search_path = public as $f$
declare pr profiles;
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  perform _expert_fields(p);
  pr := admin_create_user(p || jsonb_build_object('role', 'expert', 'org_id', (select id from orgs where code = 'EXP'), 'branch_id', ''));
  insert into experts(profile_id, specialties, governorate, license_no, accreditor, qualification)
  values (pr.id, array(select jsonb_array_elements_text(p->'specialties')), nullif(p->>'governorate', ''), trim(p->>'license_no'), trim(p->>'accreditor'), nullif(trim(coalesce(p->>'qualification', '')), ''));
  perform _audit('إضافة خبير معتمد', pr.username, jsonb_build_object('specialties', p->'specialties', 'license_no', p->>'license_no', 'accreditor', p->>'accreditor'));
  return pr;
end $f$;
grant execute on function public.admin_create_expert(jsonb) to authenticated;

create or replace function public.admin_set_expert(p_user uuid, p jsonb) returns void language plpgsql security definer set search_path = public as $f$
begin
  if not _is_admin() then raise exception 'هذه الصلاحية لمشغّل النظام فقط'; end if;
  if not exists (select 1 from experts where profile_id = p_user) then raise exception 'الخبير غير موجود'; end if;
  perform _expert_fields(p);
  update experts set specialties = array(select jsonb_array_elements_text(p->'specialties')), governorate = nullif(p->>'governorate', ''),
    license_no = trim(p->>'license_no'), accreditor = trim(p->>'accreditor'), qualification = nullif(trim(coalesce(p->>'qualification', '')), ''),
    active = coalesce((p->>'active')::boolean, active), updated_at = now() where profile_id = p_user;
  if nullif(trim(coalesce(p->>'full_name', '')), '') is not null then update profiles set full_name = trim(p->>'full_name') where id = p_user; end if;
  perform _audit('تعديل بيانات خبير معتمد', (select username from profiles where id = p_user), p - 'password');
end $f$;
grant execute on function public.admin_set_expert(uuid, jsonb) to authenticated;

-- ───────── 9) حسابات الخبراء التجريبية ─────────
do $$
declare uid uuid; x record;
begin
  for x in select * from (values
    ('exp.ind', 'Exp@2026in', 'م. سامر خليل الدباغ', array['industrial','energy'], 'بغداد', 'ENG-IND-4471', 'نقابة المهندسين العراقيين', 'دكتوراه هندسة صناعية — خبرة 18 سنة'),
    ('exp.agr', 'Exp@2026ag', 'د. هدى ناظم العبيدي', array['agricultural'], 'بابل', 'AGR-2208', 'نقابة المهندسين الزراعيين', 'دكتوراه اقتصاد زراعي — خبرة 15 سنة'),
    ('exp.eco', 'Exp@2026ec', 'د. فراس مجيد السامرائي', array['economic','industrial'], 'النجف', 'ECO-1093', 'نقابة الاقتصاديين العراقيين', 'دكتوراه اقتصاد مالي — خبرة 20 سنة'),
    ('exp.en', 'Exp@2026en', 'م. ليث عدنان الحيدري', array['energy'], 'البصرة', 'ENG-PWR-3310', 'نقابة المهندسين العراقيين', 'ماجستير هندسة قدرة كهربائية — خبرة 12 سنة')
  ) t(u, pw, n, sp, gov, lic, acc, q) loop
    if not exists (select 1 from profiles where username = x.u) then
      uid := _mk_user(x.u, x.pw, x.n, 'expert', 'expert', 'EXP', null, null);
      insert into experts(profile_id, specialties, governorate, license_no, accreditor, qualification) values (uid, x.sp, x.gov, x.lic, x.acc, x.q);
    end if;
  end loop;
end $$;
