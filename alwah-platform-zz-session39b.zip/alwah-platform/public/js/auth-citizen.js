// بوابة المقترض — الدخول وإنشاء الحساب واستعادة كلمة المرور (كلها برمز تحقق OTP)
import { esc, el, toast, cleanErr, rpc, askOtp, serverOtp, govOptions, normPhone, validPhone, digits } from './core.js';
import { mountIdScan, ocrEnabled, scanNote } from './id-scan.js';

const PW_RULE = 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً';
const pwOk = p => p.length >= 8 && /\d/.test(p) && /[A-Za-z]/.test(p);
// تاريخ بثلاث قوائم (يوم/شهر/سنة) — حقل التاريخ في آيفون يظهر مقلوباً مع الاتجاه العربي
const MONTHS = ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];
function dateSel(id, val) {
  const [y, m, d] = String(val || '').split('-').map(Number), Y = new Date().getFullYear();
  const o = (v, t, sel) => `<option value="${v}" ${sel ? 'selected' : ''}>${t}</option>`;
  return `<div class="datesel" data-date="${id}">
    <select class="input" data-p="d" aria-label="اليوم">${o('', 'اليوم')}${Array.from({ length: 31 }, (_, i) => o(i + 1, i + 1, d === i + 1)).join('')}</select>
    <select class="input" data-p="m" aria-label="الشهر">${o('', 'الشهر')}${MONTHS.map((t, i) => o(i + 1, `${i + 1} — ${t}`, m === i + 1)).join('')}</select>
    <select class="input" data-p="y" aria-label="السنة">${o('', 'السنة')}${Array.from({ length: 83 }, (_, i) => Y - 18 - i).map(v => o(v, v, y === v)).join('')}</select></div>`;
}
function dateVal(root, id) {
  const b = root.querySelector(`[data-date="${id}"]`), g = k => Number(b.querySelector(`[data-p="${k}"]`).value);
  const y = g('y'), m = g('m'), d = g('d'); if (!y || !m || !d) return '';
  const dt = new Date(Date.UTC(y, m - 1, d)); if (dt.getUTCMonth() !== m - 1) return '';
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
const emailOf = u => u.includes('@') ? u : `${u}@alwah.demo`;

export function mountCitizenAuth(box, { sb, onDone, err = '' }) {
  const dev = window.ALWAH_DEV || {};
  let mode = 'login';
  draw();

  function draw() {
    box.innerHTML = `
      <div class="seg" role="tablist">
        <button type="button" class="${mode === 'login' ? 'on' : ''}" data-m="login">تسجيل الدخول</button>
        <button type="button" class="${mode === 'register' ? 'on' : ''}" data-m="register">إنشاء حساب</button>
      </div>
      ${dev.dev_mode ? `<div class="devbar">وضع المطور مفعّل — أي شاشة تطلب رمز تحقق تقبل <b class="num">${esc(dev.dev_otp || '1234')}</b></div>` : ''}
      <div data-body></div>`;
    box.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { mode = b.dataset.m; err = ''; draw(); });
    const body = box.querySelector('[data-body]');
    ({ login, register, forgot }[mode])(body);
  }

  function errBox(msg) { return `<div class="err ${msg ? 'on' : ''}">${esc(msg)}</div>`; }
  function showErr(root, msg) { const e = root.querySelector('.err'); e.textContent = msg; e.classList.toggle('on', !!msg); if (msg) e.scrollIntoView({ block: 'nearest' }); }

  async function signIn(username, password) {
    const { error } = await sb.auth.signInWithPassword({ email: emailOf(username), password });
    if (error) throw new Error('رقم الهاتف أو كلمة المرور غير صحيحة');
  }

  function login(root) {
    root.innerHTML = `<form autocomplete="on" novalidate>
      <h2>أهلاً بعودتك</h2><p class="sub">ادخل برقم هاتفك أو اسم المستخدم</p>
      ${errBox(err)}
      <div class="field"><label for="u">رقم الهاتف أو اسم المستخدم</label><input class="input" id="u" name="username" autocomplete="username" dir="ltr" placeholder="07XXXXXXXXX" required></div>
      <div class="field"><label for="p">كلمة المرور</label><div class="pw"><input class="input" id="p" name="password" type="password" autocomplete="current-password" dir="ltr" required><button type="button" class="eye" aria-label="إظهار كلمة المرور">👁</button></div></div>
      <div class="row" style="margin:-4px 0 16px"><span class="sp"></span><button type="button" class="linkbtn" data-forgot>نسيت كلمة المرور؟</button></div>
      <button class="btn cyan block" type="submit">دخول</button>
      <p class="other">ليس لديك حساب؟ <button type="button" class="linkbtn" data-reg>أنشئ حساباً خلال دقيقتين</button></p>
      <p class="other" style="margin-top:6px"><a href="/">العودة إلى الصفحة الرئيسية</a></p>
    </form>`;
    const f = root.querySelector('form');
    eye(root);
    root.querySelector('[data-forgot]').onclick = () => { mode = 'forgot'; draw(); };
    root.querySelector('[data-reg]').onclick = () => { mode = 'register'; draw(); };
    f.onsubmit = async ev => {
      ev.preventDefault();
      let u = f.u.value.trim().toLowerCase();
      if (!u || !f.p.value) return showErr(root, 'اكتب رقم الهاتف وكلمة المرور');
      if (/^[\d\s+٠-٩]+$/.test(u)) u = normPhone(u);
      const btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'جارِ التحقق…'; showErr(root, '');
      try { await signIn(u, f.p.value); onDone(); }
      catch (e) { showErr(root, cleanErr(e)); btn.disabled = false; btn.textContent = 'دخول'; }
    };
  }

  function register(root) {
    // الخطوات: 1 الهاتف ← 1.5 البطاقة (التقاط تلقائي) ← 2 البيانات وكلمة المرور ← إرسال
    const st = { step: 1, phone: '', otp: '', scan: null, n: { first: '', father: '', grand: '', fourth: '', surname: '' }, mo: { m1: '', m2: '', m3: '' }, okd: {} };
    const SCAN = ocrEnabled();
    const labels = SCAN ? ['رقم الهاتف', 'البطاقة', 'البيانات'] : ['رقم الهاتف', 'البيانات'];
    paint();
    function paint() {
      const cur = SCAN ? ({ 1: 0, 1.5: 1, 2: 2 })[st.step] : ({ 1: 0, 2: 1 })[st.step];
      root.innerHTML = `<div class="steps3">${labels.map((s, i) => `<span class="${i < cur ? 'done' : i === cur ? 'cur' : ''}"><i>${i < cur ? '✓' : i + 1}</i>${s}</span>`).join('')}</div>
        <form novalidate></form>`;
      const f = root.querySelector('form');
      if (st.step === 1) {
        f.innerHTML = `<h2>حساب جديد</h2><p class="sub">نتحقق من رقم هاتفك برسالة نصية</p>${errBox('')}
          <div class="field"><label for="ph">رقم الهاتف المحمول</label><input class="input" id="ph" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(st.phone)}" autocomplete="tel"></div>
          <button class="btn cyan block" type="submit">إرسال رمز التحقق</button>
          <p class="other">لديك حساب؟ <button type="button" class="linkbtn" data-login>سجّل الدخول</button></p>`;
        f.querySelector('[data-login]').onclick = () => { mode = 'login'; draw(); };
        f.onsubmit = async ev => {
          ev.preventDefault();
          const ph = normPhone(f.ph.value);
          if (!validPhone(ph)) return showErr(root, 'رقم الهاتف غير صحيح — اكتبه بالصيغة 07XXXXXXXXX');
          const code = await askOtp({ kind: 'register', title: 'تأكيد رقم الهاتف', phone: ph, purpose: 'لإنشاء حسابك في منصة ألواح', verify: serverOtp(sb, ph, 'register') });
          if (!code) return;
          st.phone = ph; st.otp = code; st.step = SCAN ? 1.5 : 2; paint();
        };
      } else if (st.step === 1.5) {
        mountIdScan(f, {
          errBox,
          onBack: () => { st.step = 1; paint(); },
          onSkip: () => { st.scan = null; st.step = 2; paint(); },
          onResult: r => {
            st.scan = r; st.okd = {};
            Object.keys(st.n).forEach(k => { st.n[k] = r.parts[k] || ''; });
            st.mo = { m1: r.motherParts?.m1 || '', m2: r.motherParts?.m2 || '', m3: r.motherParts?.m3 || '' };
            st.nid = r.nid || ''; st.bd = r.bd || ''; if (r.gov) st.gov = r.gov;
            st.step = 2; paint();
            // الحقل الوحيد الذي لا تحمله البطاقة: الاسم الرابع
            setTimeout(() => { const i = root.querySelector('#n_fourth'); if (i && !i.value) { i.focus({ preventScroll: true }); i.scrollIntoView({ block: 'center', behavior: 'smooth' }); } }, 250);
          },
        });
      } else {
        const r = st.scan, N = st.n;
        const FL = (r && r.flags) || {}, MO = st.mo;
        // حقل مشكوك فيه: إطار أحمر وسبب، ولا يُقبل الإرسال حتى يُصحَّح أو يؤكَّد صراحةً
        const flagHtml = k => FL[k] ? `<small class="fl-why">⚠ ${esc(FL[k])}</small><label class="fl-ok"><input type="checkbox" data-okd="${k}" ${st.okd[k] ? 'checked' : ''}> راجعته وهو مطابق لبطاقتي</label>` : '';
        const nf = (k, label, ph, must, val = N[k], id = 'n_' + k) => `<div class="field ${must ? 'must' : ''} ${FL[k] ? 'flag' : ''}"><label for="${id}">${label}</label><input class="input" id="${id}" value="${esc(val || '')}" placeholder="${ph}">${flagHtml(k)}</div>`;
        const locked = !!(r && r.verified);
        const expired = r && r.expiry && r.expiry < new Date().toISOString().slice(0, 10);
        f.innerHTML = `<h2>بياناتك الشخصية</h2><p class="sub">${r ? 'مقروءة من بطاقتك — أكمل «الاسم الرابع» وراجع الباقي' : 'كما هي في البطاقة الوطنية الموحدة'} · تُستخدم لفتح حسابك المصرفي</p>
          ${r ? scanNote(r) : ''}${expired ? '<div class="notice" style="background:var(--bad-bg);color:var(--bad)"><b>البطاقة منتهية النفاذ</b> — جدّدها قبل التقديم.</div>' : ''}${errBox('')}
          <div class="namegrid">
            ${nf('first', 'الاسم', 'مثال: علي')}${nf('father', 'اسم الأب', 'مثال: حسن')}
            ${nf('grand', 'اسم الجد', 'مثال: محمد')}${nf('fourth', 'الاسم الرابع (والد الجد)', 'يُكتب يدوياً — غير موجود في البطاقة', true)}
            ${nf('surname', 'اللقب', 'مثال: الربيعي — إن وُجد')}<div></div>
          </div>
          <h4 class="subh">اسم الأم الثلاثي</h4>
          <div class="namegrid">
            ${nf('m1', 'اسم الأم', 'كما في البطاقة', true, MO.m1, 'mo1')}${nf('m2', 'اسم والد الأم', 'سطر «الجد» تحت اسم الأم في البطاقة', true, MO.m2, 'mo2')}
            ${nf('m3', 'اسم جد الأم', 'يُكتب يدوياً — غير موجود في البطاقة', true, MO.m3, 'mo3')}<div></div>
          </div>
          <div class="field ${FL.nid ? 'flag' : ''}"><label for="nid">الرقم الوطني (12 رقماً)${locked ? ' <span class="lock">🔒 متحقق منه بالشريط السفلي</span>' : ''}</label><input class="input" id="nid" inputmode="numeric" dir="ltr" maxlength="12" value="${esc(st.nid || '')}" ${locked && st.nid ? 'readonly' : ''}></div>
          <div class="field ${locked && st.bd ? 'locked' : ''}"><label>تاريخ الميلاد${locked && st.bd ? ' <span class="lock">🔒 متحقق منه</span>' : ''}</label>${dateSel('bd', st.bd)}</div>
          ${locked ? '<p class="small muted" style="margin:-4px 0 10px">الحقول المقفلة قُرئت من البطاقة وطابقت شريطها السفلي، فلا تُعدَّل يدوياً. إن كانت خاطئة <button type="button" class="linkbtn" data-rescan>أعد تصوير البطاقة</button>.</p>' : ''}
          <div class="field"><label for="gv">محافظة السكن</label><select class="input" id="gv">${govOptions(st.gov)}</select>${r && r.place ? `<small class="muted">مكان الولادة في البطاقة: ${esc(r.place)}</small>` : ''}</div>
          ${r ? `<dl class="idinfo">${[['رقم البطاقة', r.cardNo], ['الرقم العائلي', r.family], ['تاريخ الإصدار', r.issue], ['تاريخ النفاذ', r.expiry]].map(([k, v]) => `<div><dt>${k}</dt><dd class="num" dir="ltr" style="text-align:right">${esc(v || '—')}</dd></div>`).join('')}</dl>` : ''}
          <div class="field"><label for="pw">كلمة المرور</label><div class="pw"><input class="input" id="pw" type="password" dir="ltr" autocomplete="new-password"><button type="button" class="eye" aria-label="إظهار">👁</button></div>
            <div class="pwm"><i></i></div><small class="muted">${PW_RULE}</small></div>
          <div class="field"><label for="pw2">تأكيد كلمة المرور</label><input class="input" id="pw2" type="password" dir="ltr" autocomplete="new-password"></div>
          <label class="check"><input type="checkbox" id="ok"> أقرّ بصحة بياناتي، وأوافق على شروط المنصة ومشاركة بياناتي مع المصرف الذي أختاره لفتح حسابي ودراسة طلبي</label>
          <div class="row mt"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button class="btn cyan" type="submit">إرسال</button></div>`;
        eye(root);
        const meter = f.querySelector('.pwm i');
        f.pw.oninput = () => { const p = f.pw.value; const s = (p.length >= 8) + /\d/.test(p) + /[A-Za-z]/.test(p) + /[^A-Za-z0-9]/.test(p) + (p.length >= 12); meter.style.width = s * 20 + '%'; meter.style.background = s < 3 ? 'var(--bad)' : s < 4 ? 'var(--sun)' : 'var(--ok)'; };
        if (locked && st.bd) f.querySelectorAll('select[id^="bd"], [data-date="bd"] select').forEach(x => { x.disabled = true; });
        const rs = f.querySelector('[data-rescan]'); if (rs) rs.onclick = () => { st.step = 1.5; paint(); };
        f.querySelectorAll('[data-okd]').forEach(c => c.onchange = () => { st.okd[c.dataset.okd] = c.checked; });
        const clean = v => v.trim().replace(/\s+/g, ' ');
        const keep = () => { Object.keys(N).forEach(k => N[k] = clean(f.querySelector('#n_' + k).value)); ['m1', 'm2', 'm3'].forEach((k, i) => MO[k] = clean(f.querySelector('#mo' + (i + 1)).value));
          st.mother = [MO.m1, MO.m2, MO.m3].filter(Boolean).join(' '); st.nid = digits(f.nid.value); if (!(locked && r.bd)) st.bd = dateVal(f, 'bd'); st.gov = f.gv.value; };
        f.querySelector('[data-back]').onclick = () => { keep(); st.step = SCAN ? 1.5 : 1; paint(); };
        f.onsubmit = async ev => {
          ev.preventDefault(); keep();
          const AR = /^[؀-ۿ\s]+$/;
          for (const [k, l] of [['first', 'الاسم'], ['father', 'اسم الأب'], ['grand', 'اسم الجد'], ['fourth', 'الاسم الرابع']]) {
            if (N[k].length < 2) { f.querySelector('#n_' + k).focus(); return showErr(root, `اكتب ${l}`); }
            if (!AR.test(N[k])) { f.querySelector('#n_' + k).focus(); return showErr(root, `${l} بالحروف العربية كما في البطاقة`); }
          }
          if (N.surname && !AR.test(N.surname)) return showErr(root, 'اللقب بالحروف العربية');
          for (const [k, l, i] of [['m1', 'اسم الأم', 1], ['m2', 'اسم والد الأم', 2], ['m3', 'اسم جد الأم', 3]]) {
            if (MO[k].length < 2) { f.querySelector('#mo' + i).focus(); return showErr(root, `اكتب ${l} — اسم الأم يُطلب ثلاثياً`); }
            if (!AR.test(MO[k])) { f.querySelector('#mo' + i).focus(); return showErr(root, `${l} بالحروف العربية`); }
          }
          // كل حقل مشكوك فيه يجب أن يُصحَّح أو يؤكَّد — لا يمر خطأ قراءة دون انتباه المواطن
          if (r) for (const k of Object.keys(r.flags || {})) {
            const now = k in N ? N[k] : MO[k], orig = k in N ? (r.parts[k] || '') : (r.motherParts?.[k] || '');
            if (now === orig && !st.okd[k]) { const el = f.querySelector(k in N ? '#n_' + k : '#mo' + k.slice(1)); el && el.focus(); el && el.scrollIntoView({ block: 'center' });
              return showErr(root, 'يوجد حقل عليه ملاحظة باللون الأحمر — صحّحه أو أكّد أنه مطابق لبطاقتك'); }
          }
          if (!r && !AR.test(N.fourth)) return showErr(root, 'الاسم الرابع بالحروف العربية');
          if (N.first === N.father && N.father === N.grand) return showErr(root, 'الاسم والأب والجد متطابقة — راجعها');
          if (!/^\d{12}$/.test(st.nid)) return showErr(root, 'الرقم الوطني 12 رقماً');
          if (!st.bd) return showErr(root, 'اختر تاريخ الميلاد كاملاً (اليوم والشهر والسنة)');
          if (new Date(st.bd) > new Date(Date.now() - 18 * 365.25 * 864e5)) return showErr(root, 'يجب أن يكون عمرك 18 سنة فأكثر');
          if (!st.gov) return showErr(root, 'اختر محافظة السكن');
          if (expired) return showErr(root, 'البطاقة الوطنية منتهية النفاذ — جدّدها قبل التقديم');
          if (!pwOk(f.pw.value)) return showErr(root, PW_RULE);
          if (f.pw.value !== f.pw2.value) return showErr(root, 'كلمتا المرور غير متطابقتين');
          if (!f.ok.checked) return showErr(root, 'يلزم الإقرار والموافقة على الشروط');
          const name = [N.first, N.father, N.grand, N.fourth, N.surname].filter(Boolean).join(' ');
          const btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'جارِ الإرسال…'; showErr(root, '');
          try {
            const res = await rpc(sb, 'register_citizen', { p_phone: st.phone, p_otp: st.otp, p_full_name: name, p_national_id: st.nid, p_birth_date: st.bd, p_governorate: st.gov, p_password: f.pw.value });
            await signIn(res.username, f.pw.value);
            // بقية بيانات البطاقة (الرقم العائلي، الإصدار، النفاذ، اسم الأم…) — لا تُفشل إنشاء الحساب إن تعذرت
            try {
              await rpc(sb, 'update_my_id_card', { p: { national_id: st.nid, full_name: name, birth_date: st.bd, mother_name: st.mother,
                ...(r ? { gender: r.gender, place_of_birth: r.place, name_latin: r.latin, blood_type: r.blood, card_number: r.cardNo, issue_date: r.issue, expiry_date: r.expiry, issuer: r.issuer, family_number: r.family, mrz_verified: r.verified,
                  id_review: reviewOf(r, N, MO, st) } : {}) } });
            } catch (e2) { console.warn('update_my_id_card', e2); }
            toast('أهلاً بك في ألواح — تم إنشاء حسابك', 'ok');
            onDone({ fresh: true });
          } catch (e) { showErr(root, cleanErr(e)); btn.disabled = false; btn.textContent = 'إرسال'; }
        };
      }
    }
  }

  // سجل للتدقيق: ما قرأته البطاقة، وما غيّره المواطن، وما نُبّه إليه وأكّده — يراه موظف المصرف
  function reviewOf(r, N, MO, st) {
    const orig = { ...r.parts, ...(r.motherParts || {}), nid: r.nid, bd: r.bd };
    const now = { ...N, ...MO, nid: st.nid, bd: st.bd };
    const edited = Object.keys(orig).filter(k => orig[k] && now[k] !== orig[k] && k !== 'fourth');
    return { ocr: orig, edited, flags: r.flags || {}, confirmed: Object.keys(st.okd).filter(k => st.okd[k]), mrz_verified: !!r.verified, latin: r.latin || '', at: new Date().toISOString() };
  }

  function forgot(root) {
    root.innerHTML = `<form novalidate><h2>استعادة كلمة المرور</h2><p class="sub">نرسل رمز تحقق إلى هاتفك المسجل</p>${errBox('')}
      <div class="field"><label for="ph">رقم الهاتف</label><input class="input" id="ph" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label for="pw">كلمة المرور الجديدة</label><div class="pw"><input class="input" id="pw" type="password" dir="ltr" autocomplete="new-password"><button type="button" class="eye" aria-label="إظهار">👁</button></div><small class="muted">${PW_RULE}</small></div>
      <button class="btn cyan block" type="submit">إرسال الرمز وتغيير كلمة المرور</button>
      <p class="other"><button type="button" class="linkbtn" data-login>العودة لتسجيل الدخول</button></p>
      <p class="small muted" style="text-align:center">الحسابات التجريبية (citizen1…) تُدار من المطور ولا تُستعاد من هنا.</p></form>`;
    eye(root);
    const f = root.querySelector('form');
    f.querySelector('[data-login]').onclick = () => { mode = 'login'; draw(); };
    f.onsubmit = async ev => {
      ev.preventDefault();
      const ph = normPhone(f.ph.value);
      if (!validPhone(ph)) return showErr(root, 'رقم الهاتف غير صحيح');
      if (!pwOk(f.pw.value)) return showErr(root, PW_RULE);
      const pw = f.pw.value;
      const code = await askOtp({ kind: 'reset', title: 'استعادة كلمة المرور', phone: ph, verify: c => rpc(sb, 'reset_password_otp', { p_phone: ph, p_otp: c, p_new_password: pw }) });
      if (!code) return;
      try { await signIn(ph, pw); toast('تم تغيير كلمة المرور', 'ok'); onDone(); }
      catch (e) { showErr(root, cleanErr(e)); }
    };
  }

  function eye(root) {
    root.querySelectorAll('.eye').forEach(b => b.onclick = () => { const i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; });
  }
}
