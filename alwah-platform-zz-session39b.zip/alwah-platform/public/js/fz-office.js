// الجلسة 25: الجهة التي أعدّت دراسة الجدوى — قائمة المكاتب والمراكز المعتمدة من البنك المركزي، أو اسم يكتبه المقترض
import { esc, badge, rpc, toast, cleanErr, modal } from './core.js';

let cache = null;
export async function fzOffices(sb) {
  if (cache) return cache;
  try { cache = await rpc(sb, 'fz_offices_list', { p_gov: null }) || []; } catch (e) { cache = []; }
  return cache;
}

// شارة قصيرة تصف الجهة المُعِدّة (للمصرف والخبير والمقترض)
export function fzBadge(fz) {
  if (!fz?.set) return badge(['الجهة المُعِدّة غير محددة', 'warn']);
  return fz.accredited ? badge(['✓ جهة معتمدة من البنك المركزي', 'ok']) : badge(['جهة غير مدرجة في القائمة المعتمدة', 'warn']);
}

export function fzLine(fz, { sla } = {}) {
  if (!fz?.set) return '<div class="small muted">لم يحدد المقترض الجهة التي أعدّت دراسة الجدوى.</div>';
  return `<div class="fz-line ${fz.accredited ? 'ok' : 'warn'}"><span>${fz.accredited ? '🏛' : '✎'}</span><div>
    <b>أعدّها: ${esc(fz.name)}</b> ${fzBadge(fz)}
    <div class="small muted">${fz.accredited
      ? `${fz.kind === 'center' ? 'مركز' : 'مكتب'}${fz.governorate ? ` · ${esc(fz.governorate)}` : ''}${fz.license_no ? ` · إجازة <span class="num">${esc(fz.license_no)}</span>` : ''}${fz.cbi_ref ? ` · ${esc(fz.cbi_ref)}` : ''} — <b>مسار ميسّر</b>: مهلة الخبير <span class="num">${sla || 2}</span> يوم دوام وتتقدّم في صندوقه`
      : 'اسم كتبه المقترض — تدقيق كامل لدى الخبير بالمهلة الاعتيادية'}</div></div></div>`;
}

/**
 * منتقي الجهة: يرسم داخل box ويعيد { valid(), payload() }
 * state = { id, name, mode: 'list' | 'other' }
 */
export function fzPicker(box, sb, { state, gov = '', onChange } = {}) {
  const q = state || { id: '', name: '', mode: '', search: '' };
  let list = cache || [];
  const valid = () => (q.mode === 'list' && !!q.id) || (q.mode === 'other' && q.name.trim().length >= 4);
  const draw = () => {
    const s = (q.search || '').trim();
    const rows = list.filter(o => !s || o.name.includes(s) || (o.governorate || '').includes(s))
      .sort((a, b) => (b.governorate === gov) - (a.governorate === gov));
    box.innerHTML = `<label class="lbl mt">من أعدّ دراسة الجدوى لمشروعك؟ ★</label>
      <div class="notice ok" style="margin:4px 0 8px"><span>⚡</span><span class="small">إذا أعدّ دراستك <b>مكتب أو مركز معتمد من البنك المركزي</b> تمر معاملتك بخطوات أسرع: يدرسها الخبير خلال يومين بدل خمسة.</span></div>
      <div class="seg"><label class="${q.mode === 'list' ? 'on' : ''}"><input type="radio" name="fzm" value="list" ${q.mode === 'list' ? 'checked' : ''}>🏛 القائمة المعتمدة</label>
        <label class="${q.mode === 'other' ? 'on' : ''}"><input type="radio" name="fzm" value="other" ${q.mode === 'other' ? 'checked' : ''}>✎ جهة أخرى</label></div>
      ${q.mode === 'list' ? `<input class="input mt" data-fzs placeholder="ابحث بالاسم أو المحافظة" value="${esc(q.search || '')}">
        <div class="fz-list">${rows.map(o => `<label class="fz-o ${q.id === o.id ? 'on' : ''}"><input type="radio" name="fzo" value="${o.id}" ${q.id === o.id ? 'checked' : ''}>
          <div><b>${esc(o.name)}</b><div class="small muted">${o.kind === 'center' ? 'مركز' : 'مكتب'} · ${esc(o.governorate || '—')}${o.governorate && o.governorate === gov ? ' ' + badge(['محافظتك', 'ok']) : ''}</div></div></label>`).join('')
          || '<div class="muted small" style="padding:8px">لا نتيجة — جرّب كلمة أخرى، أو اختر «جهة أخرى» واكتب الاسم.</div>'}</div>` : ''}
      ${q.mode === 'other' ? `<div class="field mt"><label>اسم المكتب أو المركز الذي أعدّ الدراسة ★</label>
        <input class="input" data-fzn maxlength="90" value="${esc(q.name)}" placeholder="مثال: مكتب … للاستشارات الاقتصادية">
        <p class="small muted" style="margin:4px 0 0">الجهة غير المدرجة مقبولة، لكن يدقق الخبير دراستها بالمهلة الاعتيادية.</p></div>` : ''}`;
    box.querySelectorAll('input[name=fzm]').forEach(r => r.onchange = () => { q.mode = r.value; draw(); });
    box.querySelectorAll('input[name=fzo]').forEach(r => r.onchange = () => { q.id = r.value; draw(); });
    const se = box.querySelector('[data-fzs]'); if (se) se.oninput = () => { q.search = se.value; const p = se.selectionStart; draw(); const n = box.querySelector('[data-fzs]'); n.focus(); n.setSelectionRange(p, p); };
    const nm = box.querySelector('[data-fzn]'); if (nm) nm.oninput = () => { q.name = nm.value; onChange && onChange(); };
    onChange && queueMicrotask(onChange);
  };
  if (!cache) { box.innerHTML = '<div class="spin"></div>'; fzOffices(sb).then(l => { list = l; draw(); }); } else draw();
  return {
    valid, state: () => q,
    payload: () => q.mode === 'list' ? { office_id: q.id } : { name: q.name.trim() },
  };
}

// نافذة لتغيير الجهة من صفحة الطلب
export function fzDialog(sb, app, { current, onSaved } = {}) {
  const st = { mode: current?.set ? (current.accredited ? 'list' : 'other') : '', id: current?.accredited ? current.id : '', name: current?.set && !current.accredited ? current.name : '', search: '' };
  const m = modal(`<h3>الجهة التي أعدّت دراسة الجدوى</h3><div data-p></div>
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-go disabled>حفظ</button></div>`, { wide: true });
  const go = m.el.querySelector('[data-go]');
  const pk = fzPicker(m.el.querySelector('[data-p]'), sb, { state: st, gov: app.governorate, onChange: () => { go.disabled = !pk.valid(); } });
  m.el.querySelector('[data-x]').onclick = m.close;
  go.onclick = async () => {
    go.disabled = true;
    try { const fz = await rpc(sb, 'set_fz_office', { p_app: app.id, p: pk.payload() }); m.close(); toast(fz.accredited ? 'حُفظت — جهة معتمدة: مسار ميسّر' : 'حُفظ اسم الجهة', 'ok'); onSaved && onSaved(fz); }
    catch (e) { toast(cleanErr(e), 'bad'); go.disabled = !pk.valid(); }
  };
}
