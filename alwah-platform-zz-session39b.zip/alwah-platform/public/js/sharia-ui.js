// الجلسة 39: أدوات مشتركة للهيئة الشرعية — عرض العقد ببنوده، الفروق بين النسخ، التعليقات على البنود، القرارات، وقارئ العقد للمقترض
import { esc, dt, badge, el } from './core.js';

export const SH_STATUS = {
  draft: ['مسودة لدى المصرف', 'muted'], submitted: ['لدى أمين السر', 'info'], returned: ['معاد للمصرف للتعديل', 'warn'],
  deliberation: ['قيد المداولة والتصويت', 'warn'], approved: ['معتمد شرعاً', 'ok'], conditional: ['معتمد بشرط', 'ok'],
  rejected: ['مرفوض', 'bad'], suspended: ['معلّق مؤقتاً', 'bad'], withdrawn: ['مسحوب الاعتماد', 'muted'],
};
export const shBadge = s => badge(SH_STATUS[s] || [s, 'muted']);
export const DECISION = { approved: ['اعتماد', 'ok'], conditional: ['اعتماد مشروط', 'ok'], returned: ['إعادة للتعديل', 'warn'], rejected: ['رفض', 'bad'], suspended: ['تعليق مؤقت', 'bad'], reinstated: ['رفع التعليق', 'ok'], withdrawn: ['سحب الاعتماد', 'muted'] };
export const VOTE = { approve: ['موافق', 'ok'], approve_cond: ['موافق بشرط', 'warn'], reject: ['غير موافق', 'bad'] };
export const SECTORS = { pv: ['☀️', 'الطاقة الشمسية'], vet: ['🐾', 'الأطباء البيطريون'], exim: ['🚢', 'التصدير والاستيراد'] };
export const SUBSECTORS = { pv: [['individuals', 'الأفراد'], ['agri', 'الزراعة'], ['industry', 'الصناعة']], vet: [['clinic', 'عيادة ومختبر'], ['production', 'خط إنتاج']], exim: [['importer', 'المستورد'], ['exporter', 'المصدّر']] };
export const GUARANTEES = [['single_salary', 'كفالة راتب موظف'], ['multi_salary', 'كفالة رواتب عدة موظفين'], ['mortgage', 'رهن عقار'], ['gold', 'رهن ذهب']];
export const ATTACHMENTS = ['طلب شراء ووعد غير ملزم', 'وكالة شراء', 'محضر قبض واستلام', 'جدول الأقساط', 'عقد الإجارة', 'محضر التسليم', 'نموذج عقد بيع الحصة', 'ملحق المواصفات'];
export const shortSha = s => s ? `<span class="num sh-sha" title="${esc(s)}">${esc(s.slice(0, 12))}…</span>` : '—';

// الفروق بين نسختين على مستوى البند: جديد / معدّل / كما هو، والمحذوف من السابقة
export function diffClauses(prev = [], cur = []) {
  const key = c => (c.title || '').trim();
  const pm = new Map(prev.map(c => [key(c), c]));
  const marks = cur.map(c => { const p = pm.get(key(c)); return !p ? 'new' : (p.text || '').trim() === (c.text || '').trim() ? 'same' : 'changed'; });
  const curKeys = new Set(cur.map(key));
  const removed = prev.filter(c => !curKeys.has(key(c)));
  return { marks, removed, prevOf: c => pm.get(key(c)) };
}

// تعليقات بند واحد (مع ردود المصرف)
export function threadHtml(reviews, n, { canResolve = false, canReply = false } = {}) {
  const roots = reviews.filter(r => !r.parent_id && (n === null ? r.clause_n == null : r.clause_n === n));
  if (!roots.length) return '';
  return `<div class="sh-thread">${roots.map(r => `<div class="sh-cm ${r.resolved ? 'done' : ''} ${r.side}">
      <div class="row small"><b>${esc(r.author)}</b><span class="muted">· النسخة <span class="num">${r.version}</span> · ${dt(r.at)}</span><span class="sp"></span>
        ${r.resolved ? '<span class="sh-ok">✓ معالَج</span>' : canResolve ? `<button class="linkbtn" data-resolve="${r.id}">تعليم معالَجاً</button>` : '<span class="sh-open">مفتوح</span>'}</div>
      <p>${esc(r.body)}</p>
      ${reviews.filter(x => x.parent_id === r.id).map(x => `<div class="sh-reply ${x.side}"><b>${esc(x.author)}</b> <span class="muted small">${x.side === 'bank' ? '— المصرف' : ''} · ${dt(x.at)}</span><p>${esc(x.body)}</p></div>`).join('')}
      ${canReply && !r.resolved ? `<button class="linkbtn small" data-reply="${r.id}">↩ ردّ على التعليق</button>` : ''}
    </div>`).join('')}</div>`;
}

// نص العقد: البنود مرقّمة، مع شارة الفرق عن النسخة السابقة وعدد التعليقات
export function contractHtml(P, { showDiff = false, canComment = false, canResolve = false, canReply = false } = {}) {
  const cur = P.current?.clauses || [];
  const d = P.previous ? diffClauses(P.previous.clauses || [], cur) : null;
  const rv = P.reviews || [];
  return `<div class="sh-contract">
    ${cur.map((c, i) => { const mk = d?.marks[i] || 'same', cnt = rv.filter(r => !r.parent_id && r.clause_n === c.n).length, old = d?.prevOf(c);
      return `<div class="sh-cl ${showDiff ? 'd-' + mk : ''}" id="cl-${c.n}">
        <div class="sh-cl-h"><span class="sh-n num">${c.n}</span><b>${esc(c.title)}</b>
          ${showDiff && mk === 'new' ? '<span class="sh-dtag new">جديد</span>' : ''}${showDiff && mk === 'changed' ? '<span class="sh-dtag ch">معدّل</span>' : ''}
          <span class="sp"></span>${cnt ? `<span class="sh-cc">💬 <span class="num">${cnt}</span></span>` : ''}
          ${canComment ? `<button class="btn ghost sm" data-comment="${c.n}">علّق على البند</button>` : ''}</div>
        ${showDiff && mk === 'changed' && old ? `<div class="sh-old"><small>النص في النسخة <span class="num">${P.previous.n}</span>:</small><p>${esc(old.text)}</p></div>` : ''}
        <p class="sh-txt">${esc(c.text)}</p>
        ${threadHtml(rv, c.n, { canResolve, canReply })}
      </div>`; }).join('')}
    ${showDiff && d?.removed.length ? `<div class="sh-cl d-removed"><div class="sh-cl-h"><b>بنود حُذفت من النسخة <span class="num">${P.previous.n}</span></b></div>${d.removed.map(c => `<p class="sh-txt"><b>${esc(c.title)}:</b> ${esc(c.text)}</p>`).join('')}</div>` : ''}
    ${threadHtml(rv, null, { canResolve, canReply }) ? `<div class="sh-cl"><div class="sh-cl-h"><b>ملاحظات عامة على المنتج</b></div>${threadHtml(rv, null, { canResolve, canReply })}</div>` : ''}
  </div>`;
}

export function tallyHtml(t) {
  if (!t) return '';
  const tot = Math.max(t.members || 0, 1), w = n => `${Math.round((n || 0) / tot * 100)}%`;
  return `<div class="sh-tally">
    <div class="sh-bar"><i class="ok" style="width:${w(t.approve)}"></i><i class="cond" style="width:${w(t.approve_cond)}"></i><i class="bad" style="width:${w(t.reject)}"></i></div>
    <div class="row small" style="flex-wrap:wrap;gap:6px 14px"><span>✓ موافق <b class="num">${t.approve}</b></span><span>◐ بشرط <b class="num">${t.approve_cond}</b></span><span>✗ غير موافق <b class="num">${t.reject}</b></span>
      <span class="sp"></span><span class="${t.quorum_ok ? 'ok-t' : 'warn-t'}">صوّت <b class="num">${t.cast}</b> من <span class="num">${t.members}</span> — النصاب <span class="num">${t.quorum}</span> ${t.quorum_ok ? '✓' : ''}</span></div>
    ${t.proposed ? `<div class="small mt">النتيجة الآن: <b>${esc(t.proposed_label)}</b>${t.tie ? ' (تساوٍ — صوت الرئيس مرجّح)' : ''}</div>` : `<div class="small muted mt">${t.quorum_ok ? 'لا أغلبية بعد' : 'لم يكتمل النصاب بعد'}</div>`}
  </div>`;
}

export function resolutionHtml(r) {
  return `<div class="sh-res ${r.decision}">
    <div class="row"><b class="num">${esc(r.code)}</b>${badge(DECISION[r.decision] || [r.decision, 'muted'])}<span class="sp"></span><span class="small muted">${dt(r.issued_at)}</span></div>
    ${r.body ? `<p>${esc(r.body)}</p>` : ''}
    ${r.conditions ? `<div class="sh-conds"><b>الشروط:</b><div style="white-space:pre-line">${esc(r.conditions)}</div></div>` : ''}
    ${r.votes?.cast != null ? `<div class="small muted">الأصوات: موافق <span class="num">${r.votes.approve}</span> · بشرط <span class="num">${r.votes.approve_cond}</span> · غير موافق <span class="num">${r.votes.reject}</span> من <span class="num">${r.votes.members}</span></div>` : ''}
    ${(r.dissent || []).length ? `<div class="sh-dissent"><b>الرأي المخالف:</b>${r.dissent.map(x => `<div>• ${esc(x.name)}: ${esc(x.reason || VOTE[x.vote]?.[0] || '')}</div>`).join('')}</div>` : ''}
    <div class="small muted mt">وقّعه ${esc(r.signed_by || '—')}${r.signed_code ? ` (<span class="num">${esc(r.signed_code)}</span>)` : ''} · ${esc(r.signed_via || '')}${r.version ? ` · نسخة العقد <span class="num">${r.version}</span>` : ''}</div>
    <div class="small muted">بصمة النسخة ${shortSha(r.version_sha256)} · ختم القرار ${shortSha(r.seal)}</div>
  </div>`;
}

// ───────── قارئ العقد للمقترض: ملخص بخمسة أسطر ثم العقد الفعلي مملوءاً ببياناته ─────────
const SUM_IC = { own: '🏠', when: '🗓', pay: '💳', late: '⏳', damage: '🛡' };
export function contractReader(C, { onChoose = null, chooseLabel = 'اختر هذا المنتج' } = {}) {
  const bg = el(`<div class="ct-bg" role="dialog" aria-modal="true" aria-label="عقد ${esc(C.product)}">
    <div class="ct">
      <header class="ct-top"><button type="button" class="ct-x" aria-label="رجوع">→</button><div><b>${esc(C.product)}</b><small>${esc(C.type_name)} · ${esc(C.bank)}</small></div></header>
      <div class="ct-body">
        <div class="ct-seal"><span class="ct-ok">✓</span><div><b>معتمد شرعاً — قرار <span class="num">${esc(C.resolution || '—')}</span></b><small>${esc(C.board)} · ${esc(C.madhhab)}${C.conditional ? ' · اعتماد مشروط' : ''}</small></div></div>
        <h3 class="ct-h">باختصار</h3>
        <dl class="ct-sum">${(C.summary || []).map(s => `<div><dt><i>${SUM_IC[s.k] || '•'}</i>${esc(s.label)}</dt><dd>${esc(s.text)}</dd></div>`).join('')}</dl>
        ${C.conditions ? `<div class="notice mt"><span>ℹ</span><span class="small"><b>شروط الهيئة على هذا المنتج:</b><br>${esc(C.conditions).replace(/\n/g, '<br>')}</span></div>` : ''}
        <h3 class="ct-h">نص العقد كما ستوقّعه</h3>
        <ol class="ct-cls">${(C.clauses || []).map(c => `<li><b>${esc(c.title)}</b><p>${esc(c.text)}</p></li>`).join('')}</ol>
        <p class="small muted ct-foot">هذا هو النص المعتمد حرفياً (النسخة <span class="num">${C.version}</span>) مملوءاً ببيانات طلبك. بصمته الرقمية ${shortSha(C.sha256)} — أي تغيير في النص يغيّر البصمة.</p>
      </div>
      <footer class="ct-act"><button type="button" class="btn ghost" data-back>رجوع</button>${onChoose ? `<button type="button" class="btn cyan" data-choose>${esc(chooseLabel)}</button>` : ''}</footer>
    </div></div>`);
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  const close = () => { bg.classList.remove('on'); setTimeout(() => bg.remove(), 220); document.removeEventListener('keydown', k); };
  const k = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', k);
  bg.querySelector('.ct-x').onclick = close; bg.querySelector('[data-back]').onclick = close;
  const ch = bg.querySelector('[data-choose]'); if (ch) ch.onclick = () => { close(); onChoose(); };
  return { close };
}
