// ألواح — الجلسة 11: «حسابي» لكل موظف، و«فريقي» لمدير الجهة / الفرع / القسم
// كل صلاحية تُفحص في قاعدة البيانات (دوال team_*). الواجهة تعرض فقط ما يسمح به الخادم.
import { esc, el, toast, cleanErr, rpc, badge, modal, dt, ago, tabs, kpi } from './core.js';

const SCOPE = { org: 'مدير الجهة', branch: 'مدير الفرع', dept: 'مدير القسم' };
const genPw = () => { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz'; let s = ''; for (let i = 0; i < 6; i++) s += c[Math.floor(Math.random() * c.length)]; return s + '@' + (1000 + Math.floor(Math.random() * 9000)); };
const pwOk = v => v.length >= 8 && /[0-9]/.test(v) && /[A-Za-z]/.test(v);
const copyBox = (l, v) => `<div class="field"><label>${l}</label><div class="row" style="gap:6px;flex-wrap:nowrap"><input class="input" dir="ltr" readonly value="${esc(v)}"><button type="button" class="btn ghost sm" data-copy="${esc(v)}">نسخ</button></div></div>`;
const wireCopy = root => root.querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); toast('نُسخ', 'ok'); } catch { b.previousElementSibling.select(); } });

// بيانات الدخول بعد الإنشاء أو إعادة الضبط: الرابط واسم المستخدم وكلمة المرور كلٌّ في مربع نسخ
function credsCard(title, user, pw, portal) {
  const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h3>${esc(title)}</h3></div>
    ${copyBox('الرابط', `${location.origin}/${portal}`)}${copyBox('اسم المستخدم', user)}${copyBox('كلمة المرور المؤقتة', pw)}
    <p class="small muted">أعطها للموظف بقناة آمنة. سيُطلب منه تغييرها عند أول دخول، وهذه آخر مرة تظهر فيها.</p>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-x>تم</button></div>`);
  wireCopy(m.el); m.el.querySelector('[data-x]').onclick = m.close;
}

// ───────── حسابي ─────────
function passwordForm(ctx, { force = false, onDone } = {}) {
  const f = el(`<form class="card" autocomplete="on"><h3>${force ? 'اختر كلمة مرور جديدة قبل البدء' : 'تغيير كلمة المرور'}</h3>
    ${force ? '<p class="small muted">كلمة المرور الحالية مؤقتة (أنشأها مديرك أو أعاد ضبطها). لا يمكنك إنجاز أي معاملة قبل تغييرها.</p>' : ''}
    <input type="text" name="username" autocomplete="username" value="${esc(ctx.profile.username)}" hidden>
    <div class="field"><label>كلمة المرور الحالية</label><input class="input" type="password" data-old dir="ltr" autocomplete="current-password" required></div>
    <div class="field"><label>كلمة المرور الجديدة</label><input class="input" type="password" data-new dir="ltr" autocomplete="new-password" required>
      <small class="muted">8 أحرف على الأقل، فيها حروف إنجليزية وأرقام.</small></div>
    <div class="field"><label>أعد كتابة الجديدة</label><input class="input" type="password" data-new2 dir="ltr" autocomplete="new-password" required></div>
    <label class="small row" style="gap:6px"><input type="checkbox" data-show> إظهار كلمات المرور</label>
    <div class="row" style="margin-top:12px"><span class="sp"></span><button class="btn cyan" type="submit">حفظ كلمة المرور</button></div></form>`);
  f.querySelector('[data-show]').onchange = e => f.querySelectorAll('input[type=password],input[data-pwv]').forEach(i => { i.type = e.target.checked ? 'text' : 'password'; i.toggleAttribute('data-pwv', true); });
  f.onsubmit = async ev => {
    ev.preventDefault();
    const o = f.querySelector('[data-old]').value, n = f.querySelector('[data-new]').value, n2 = f.querySelector('[data-new2]').value;
    if (!pwOk(n)) return toast('الجديدة 8 أحرف على الأقل، فيها حروف إنجليزية وأرقام', 'bad');
    if (n !== n2) return toast('الكلمتان الجديدتان غير متطابقتين', 'bad');
    const b = f.querySelector('button[type=submit]'); b.disabled = true;
    try { await rpc(ctx.sb, 'change_my_password', { p_old: o, p_new: n }); toast('تم تغيير كلمة المرور', 'ok'); ctx.profile.must_change_password = false; f.reset(); onDone && onDone(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
    b.disabled = false;
  };
  return f;
}

// شاشة الإجبار: لا تُفتح اللوحة قبل تغيير كلمة المرور المؤقتة
export function renderForceChange(ctx, onDone) {
  const { root } = ctx;
  root.innerHTML = `<div style="max-width:520px;margin:0 auto"><div class="page-head"><div><h1>مرحباً ${esc(ctx.profile.full_name)}</h1>
    <p>لحماية حسابك وحساب جهتك، غيّر كلمة المرور المؤقتة الآن.</p></div></div></div>`;
  root.firstElementChild.appendChild(passwordForm(ctx, { force: true, onDone }));
}

export async function renderAccount(ctx) {
  const { root, sb } = ctx;
  root.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  let A = {};
  try { A = await rpc(sb, 'my_account'); } catch (e) { A = { full_name: ctx.profile.full_name, username: ctx.profile.username, phone: ctx.profile.phone }; }
  const row = (k, v) => v ? `<dt>${k}</dt><dd>${v}</dd>` : '';
  root.innerHTML = `<div class="page-head"><div><h1>حسابي</h1><p>بياناتك الوظيفية، كلمة المرور، والهاتف.</p></div><span class="sp"></span><a class="btn ghost sm" href="#">← رجوع إلى لوحتي</a></div>
    <div class="grid g2 mb">
      <div class="card"><h3>بياناتي ${A.scope_title ? `<span class="badge info">${esc(A.scope_title)}</span>` : ''}</h3>
        <dl class="kv">${row('الاسم', esc(A.full_name))}${row('اسم الدخول', `<span class="num" dir="ltr">${esc(A.username)}</span>`)}${row('المنصب', esc(A.position_title || A.role_title))}
          ${row('الرمز الوظيفي', A.staff_code ? `<code>${esc(A.staff_code)}</code>` : '')}${row('الجهة', esc(A.org))}${row('الفرع', esc(A.branch || (A.org ? 'الإدارة العامة' : '')))}
          ${row('آخر دخول', A.last_sign_in_at ? dt(A.last_sign_in_at) : '')}${row('غياب مسجّل', A.away_until ? `حتى ${dt(A.away_until)}${A.away_note ? ' — ' + esc(A.away_note) : ''}` : '')}</dl>
        ${(A.tasks || []).length ? `<h3 style="margin-top:14px">المراحل المسندة إليّ</h3><ul class="small" style="margin:0;padding-inline-start:18px">${A.tasks.map(t => `<li><b class="num">${t.stage}</b>. ${esc(t.name)}${t.branch ? ` — ${esc(t.branch)}` : ''} ${t.as === 'backup' ? badge(['بديل', 'muted']) : badge(['مستلم', 'ok'])}</li>`).join('')}</ul>` : ''}
      </div>
      <div data-pw></div>
    </div>
    <form class="card" data-ph style="max-width:560px"><h3>رقم الهاتف</h3>
      <div class="field"><label>الهاتف</label><input class="input" data-phone dir="ltr" inputmode="tel" placeholder="07XXXXXXXXX" value="${esc(A.phone || '')}"></div>
      <div class="field"><label>كلمة المرور الحالية للتأكيد</label><input class="input" type="password" data-cpw dir="ltr" autocomplete="current-password"></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" type="submit">حفظ الهاتف</button></div></form>`;
  root.querySelector('[data-pw]').appendChild(passwordForm(ctx));
  const ph = root.querySelector('[data-ph]');
  ph.onsubmit = async ev => {
    ev.preventDefault();
    const b = ph.querySelector('button'); b.disabled = true;
    try { const p = await rpc(sb, 'update_my_staff_phone', { p_password: ph.querySelector('[data-cpw]').value, p_phone: ph.querySelector('[data-phone]').value }); ctx.profile.phone = p.phone; ph.querySelector('[data-cpw]').value = ''; toast('حُفظ رقم الهاتف', 'ok'); }
    catch (e) { toast(cleanErr(e), 'bad'); }
    b.disabled = false;
  };
}

// ───────── فريقي ─────────
const T = {};
export async function renderTeam(ctx) {
  const { root, sb } = ctx;
  root.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  try {
    const [meta, users, asg] = await Promise.all([rpc(sb, 'team_meta'), rpc(sb, 'team_users'), rpc(sb, 'team_assignments')]);
    Object.assign(T, { ctx, meta, users, asg });
  } catch (e) { root.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  const { meta, users } = T;
  const staff = users.filter(u => !u.is_me);
  root.innerHTML = `<div class="page-head"><div><h1>فريقي</h1><p>${esc(meta.scope_title)} — ${esc(meta.org_name)}${meta.scope === 'branch' ? ` · ${esc(meta.branches[0]?.name || '')}` : meta.scope === 'dept' ? ' · الإدارة العامة' : ''}.
      تضيف وتعدّل وتوقف موظفي نطاقك فقط، وتوزّع المراحل عليهم مع بديل عند الغياب.</p></div><span class="sp"></span><a class="btn ghost sm" href="#">← رجوع إلى لوحتي</a></div>
    <div class="grid g4 mb">
      ${kpi('موظفو نطاقي', `<span class="num">${staff.length}</span>`, `${staff.filter(u => u.disabled).length} موقوف`, true)}
      ${kpi('غائبون الآن', `<span class="num">${staff.filter(u => u.away_until).length}</span>`, 'يستلم البديل مراحلهم')}
      ${kpi('لم يغيّروا كلمة المرور', `<span class="num">${staff.filter(u => u.must_change_password && !u.disabled).length}</span>`, 'لا يستطيعون العمل بعد')}
      ${kpi('مراحل مسندة', `<span class="num">${T.asg.length}</span>`, `من ${meta.stages.length} مرحلة في نطاقي`)}
    </div><div data-tabs></div><div data-body></div>`;
  T.tab = T.tab || 'staff';
  const defs = [{ key: 'staff', label: 'الموظفون' }, { key: 'asg', label: 'توزيع المهام' }, { key: 'audit', label: 'سجل الإدارة' }];
  tabs(root.querySelector('[data-tabs]'), defs, k => { T.tab = k; paint(); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === T.tab));
  paint();
}
const reload = () => renderTeam(T.ctx);
function paint() {
  const body = T.ctx.root.querySelector('[data-body]');
  ({ staff: pageStaff, asg: pageAsg, audit: pageAudit }[T.tab])(body);
}

function pageStaff(body) {
  const f = T.f = T.f || { q: '' };
  body.innerHTML = `<div class="adm-filters row mb"><input class="input" data-q placeholder="بحث بالاسم أو اسم الدخول أو الرمز" value="${esc(f.q)}" style="max-width:320px">
      <span class="sp"></span><button class="btn cyan sm" data-new>＋ إضافة موظف</button></div>
    <div class="team-list" data-t></div>
    <p class="small muted">الأدوار التي تستطيع منحها: ${T.meta.roles.map(r => esc(r.title)).join('، ')}. لا تُعرض كلمات المرور — تُعاد ضبطها فقط، ويُجبر الموظف على تغييرها.</p>`;
  const draw = () => {
    const q = f.q.trim().toLowerCase();
    const list = T.users.filter(u => !q || [u.full_name, u.username, u.staff_code, u.phone].some(x => String(x || '').toLowerCase().includes(q)));
    body.querySelector('[data-t]').innerHTML = list.map(u => `<div class="team-card">
      <div class="hd"><div><b>${esc(u.full_name)}</b>${u.is_me ? ' <span class="badge muted sm">أنا</span>' : ''}${u.manage_scope ? ` <span class="badge info sm">${esc(SCOPE[u.manage_scope])}</span>` : ''}
        <div class="meta"><span class="num" dir="ltr">${esc(u.username)}</span>${u.staff_code ? ` · <code>${esc(u.staff_code)}</code>` : ''}</div></div><span class="sp"></span>
        ${u.disabled ? badge(['موقوف', 'bad']) : u.away_until ? badge([`غائب حتى ${new Date(new Date(u.away_until) - 864e5).toLocaleDateString('ar-IQ-u-nu-latn')}`, 'warn']) : u.must_change_password ? badge(['بانتظار تغيير كلمة المرور', 'warn']) : badge(['فعّال', 'ok'])}</div>
      <div class="meta">${esc(u.role_title)} — ${esc(u.branch_name || 'الإدارة العامة')} · ${u.last_sign_in_at ? 'آخر دخول ' + ago(u.last_sign_in_at) : 'لم يدخل بعد'}</div>
      ${u.can_manage ? `<div class="acts"><button class="btn ghost sm" data-ed="${u.id}">تعديل</button><button class="btn ghost sm" data-more="${u.id}">كلمة المرور · الغياب · الإيقاف</button></div>` : u.is_me ? '<div class="acts"><a class="btn ghost sm" href="#account">حسابي</a></div>' : '<div class="meta">خارج نطاق إدارتك</div>'}
    </div>`).join('') || '<div class="card empty">لا نتائج.</div>';
    body.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => userForm(T.users.find(u => u.id === b.dataset.ed)));
    body.querySelectorAll('[data-more]').forEach(b => b.onclick = () => moreMenu(T.users.find(u => u.id === b.dataset.more)));
  };
  body.querySelector('[data-q]').oninput = e => { f.q = e.target.value; draw(); };
  body.querySelector('[data-new]').onclick = () => userForm(null);
  draw();
}

function userForm(u) {
  const isNew = !u, M = T.meta;
  const brSel = M.scope === 'org' && M.branches.length;
  const m = modal(`<h3>${isNew ? 'إضافة موظف' : `تعديل ${esc(u.full_name)}`}</h3>
    <div class="grid g2" style="gap:12px">
      ${isNew ? `<div class="field"><label>اسم الدخول (إنجليزي صغير)</label><input class="input" data-k="username" dir="ltr" placeholder="مثال: ${esc((T.ctx.profile.username.split('.')[0] || 'staff') + '.cs3')}"></div>` : ''}
      <div class="field"><label>الاسم الكامل</label><input class="input" data-k="full_name" value="${esc(u?.full_name || '')}"></div>
      <div class="field"><label>الدور</label><select class="input" data-k="role">${M.roles.map(r => `<option value="${r.role}" ${u?.role === r.role ? 'selected' : ''}>${esc(r.title)}</option>`).join('')}</select></div>
      ${brSel ? `<div class="field"><label>الفرع</label><select class="input" data-k="branch_id"><option value="">الإدارة العامة</option>${M.branches.map(b => `<option value="${b.id}" ${u?.branch_id === b.id ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>`
        : `<div class="field"><label>الفرع</label><input class="input" disabled value="${esc(M.scope === 'branch' ? M.branches[0]?.name : 'الإدارة العامة')}"></div>`}
      <div class="field"><label>الهاتف (اختياري)</label><input class="input" data-k="phone" dir="ltr" inputmode="tel" placeholder="07XXXXXXXXX" value="${esc(u?.phone || '')}"></div>
      ${M.can_grant.length ? `<div class="field" data-scw><label>صلاحية إدارة</label><select class="input" data-k="manage_scope"><option value="">بلا — موظف</option>
        ${M.can_grant.map(s => `<option value="${s}" ${u?.manage_scope === s ? 'selected' : ''}>${esc(SCOPE[s])}</option>`).join('')}</select><small class="muted">مدير الفرع لمدير فرع مربوط بفرع؛ مدير القسم لمدير قسم المبادرات في الإدارة العامة.</small></div>` : ''}
      ${isNew ? `<div class="field"><label>كلمة المرور المؤقتة</label><div class="row" style="gap:6px;flex-wrap:nowrap"><input class="input" data-k="password" dir="ltr" value="${genPw()}"><button type="button" class="btn ghost sm" data-gen>توليد</button></div></div>` : ''}
    </div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-s>${isNew ? 'إنشاء الحساب' : 'حفظ'}</button></div>`, { wide: true });
  const g = m.el.querySelector('[data-gen]'); if (g) g.onclick = () => { m.el.querySelector('[data-k=password]').value = genPw(); };
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    const d = {}; m.el.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    e.target.disabled = true;
    try {
      if (isNew) { await rpc(T.ctx.sb, 'team_create_user', { p: d }); m.close(); credsCard('أُنشئ الحساب', d.username, d.password, T.ctx.portal); }
      else { await rpc(T.ctx.sb, 'team_update_user', { p_user: u.id, p: d }); m.close(); toast('حُفظت التغييرات', 'ok'); }
      reload();
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

function moreMenu(u) {
  const today = new Date().toISOString().slice(0, 10);
  const m = modal(`<h3>${esc(u.full_name)}</h3><p class="small muted">${esc(u.role_title)} — ${esc(u.branch_name || 'الإدارة العامة')}</p>
    <div class="card mb"><h3>إعادة ضبط كلمة المرور</h3><p class="small muted">تُلغى الحالية فوراً ويُجبر الموظف على تغيير المؤقتة عند دخوله.</p>
      <div class="row" style="gap:6px;flex-wrap:nowrap"><input class="input" data-npw dir="ltr" value="${genPw()}"><button class="btn cyan sm" data-reset>إعادة الضبط</button></div></div>
    <div class="card mb"><h3>الغياب (إجازة أو مهمة)</h3><p class="small muted">خلال الغياب يستلم البديل المراحل المسندة إليه.</p>
      <div class="grid g2" style="gap:10px"><div class="field"><label>حتى تاريخ</label><input class="input" type="date" data-until min="${today}" value="${u.away_until ? new Date(new Date(u.away_until) - 864e5).toISOString().slice(0, 10) : ''}"></div>
      <div class="field"><label>ملاحظة</label><input class="input" data-anote value="${esc(u.away_note || '')}" placeholder="إجازة اعتيادية"></div></div>
      <div class="row"><span class="sp"></span>${u.away_until ? '<button class="btn ghost sm" data-back>عاد — إنهاء الغياب</button>' : ''}<button class="btn warn sm" data-away>تسجيل الغياب</button></div></div>
    <div class="card"><h3>${u.disabled ? 'إعادة تفعيل الحساب' : 'إيقاف الحساب'}</h3>
      ${u.disabled ? '' : '<div class="field"><label>السبب (يُحفظ في السجل)</label><input class="input" data-reason placeholder="انتقال، إنهاء خدمة…"></div>'}
      <div class="row"><span class="sp"></span><button class="btn sm ${u.disabled ? 'ok' : 'bad'}" data-dis>${u.disabled ? 'تفعيل' : 'إيقاف'}</button></div></div>`);
  const $ = s => m.el.querySelector(s), sb = T.ctx.sb;
  const run = async (b, fn, msg) => { b.disabled = true; try { await fn(); toast(msg, 'ok'); m.close(); reload(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; } };
  $('[data-reset]').onclick = e => { const v = $('[data-npw]').value.trim(); e.target.disabled = true;
    rpc(sb, 'team_set_password', { p_user: u.id, p_new: v }).then(() => { m.close(); credsCard('أُعيد ضبط كلمة المرور', u.username, v, T.ctx.portal); reload(); }).catch(er => { toast(cleanErr(er), 'bad'); e.target.disabled = false; }); };
  $('[data-away]').onclick = e => { const d = $('[data-until]').value; if (!d) return toast('اختر تاريخ العودة', 'bad');
    run(e.target, () => rpc(sb, 'team_set_away', { p_user: u.id, p_until: d, p_note: $('[data-anote]').value.trim() || null }), 'سُجّل الغياب'); };
  if ($('[data-back]')) $('[data-back]').onclick = e => run(e.target, () => rpc(sb, 'team_set_away', { p_user: u.id, p_until: null, p_note: null }), 'انتهى الغياب');
  $('[data-dis]').onclick = e => run(e.target, () => rpc(sb, 'team_set_disabled', { p_user: u.id, p_disabled: !u.disabled, p_reason: $('[data-reason]')?.value.trim() || null }), u.disabled ? 'أُعيد التفعيل' : 'أُوقف الحساب');
}

// توزيع المهام: لكل مرحلة في نطاقي مستلم وبديل، في فرع محدد أو على مستوى الجهة
function pageAsg(body) {
  const M = T.meta;
  const scopes = M.scope === 'branch' ? [M.branches[0]] : M.scope === 'dept' ? [null] : [null, ...M.branches];
  T.asgScope = scopes.some(s => (s?.id || '') === T.asgScope) ? T.asgScope : (scopes[0]?.id || '');
  const scopeId = T.asgScope || null;
  const stages = M.stages.filter(s => scopeId ? (s.branch_level || ['bank_cs', 'bank_compliance', 'bank_teller', 'bank_collection'].includes(s.owner_role)) : (M.scope !== 'org' || !s.branch_level || !M.branches.length));
  const people = role => T.users.filter(u => u.role === role && !u.disabled && (!scopeId || u.branch_id === scopeId));
  body.innerHTML = `${scopes.length > 1 ? `<div class="row mb"><label class="small muted">النطاق</label><select class="input" data-scope style="max-width:280px">${scopes.map(s => `<option value="${s?.id || ''}" ${(s?.id || '') === (T.asgScope || '') ? 'selected' : ''}>${esc(s ? s.name : 'الإدارة العامة / كل الجهة')}</option>`).join('')}</select></div>` : ''}
    <div class="asg-list">
    ${stages.map(s => {
      const a = T.asg.find(x => x.stage === s.n && (x.branch_id || null) === scopeId), ps = people(s.owner_role);
      const opt = (sel, none) => `<option value="">${none}</option>` + ps.map(p => `<option value="${p.id}" ${p.id === sel ? 'selected' : ''}>${esc(p.full_name)}${p.away_until ? ' (غائب)' : ''}</option>`).join('');
      return `<div class="asg-card" data-st="${s.n}"><div><b class="num">${s.n}</b>. <b>${esc(s.name)}</b><div class="small muted">${esc(s.owner_label)}</div></div>
        <div class="field"><label>المستلم</label><select class="input" data-u>${opt(a?.user_id, 'كل من يحمل الدور')}</select>${a?.user_away ? '<small style="color:var(--warn)">غائب الآن — يستلم البديل</small>' : ''}</div>
        <div class="field"><label>البديل عند الغياب</label><select class="input" data-b>${opt(a?.backup_id, 'بلا بديل')}</select></div>
        <div class="row"><span class="sp"></span>${a ? `<button class="btn ghost sm" data-clear="${a.id}">إلغاء الإسناد</button>` : ''}<button class="btn cyan sm" data-save>حفظ</button></div></div>`;
    }).join('') || '<div class="card empty">لا مراحل في هذا النطاق.</div>'}</div>
    <p class="small muted">بلا إسناد: ينفّذ المرحلة كل من يحمل دورها (كما كان). مع الإسناد: ينفّذها المستلم وحده، والبديل فقط حين يغيب المستلم أو يُوقف. إن غاب الاثنان تعود لكل من يحمل الدور حتى لا تتوقف المعاملة.
    إسناد الفرع يتقدّم على إسناد الجهة.</p>`;
  const sc = body.querySelector('[data-scope]'); if (sc) sc.onchange = e => { T.asgScope = e.target.value; pageAsg(body); };
  body.querySelectorAll('.asg-card[data-st]').forEach(tr => {
    tr.querySelector('[data-save]').onclick = async e => {
      const u = tr.querySelector('[data-u]').value, b = tr.querySelector('[data-b]').value, n = Number(tr.dataset.st);
      e.target.disabled = true;
      try {
        if (!u) { const a = T.asg.find(x => x.stage === n && (x.branch_id || null) === scopeId); if (a) await rpc(T.ctx.sb, 'team_clear_assignment', { p_id: a.id }); }
        else await rpc(T.ctx.sb, 'team_set_assignment', { p_stage: n, p_branch: scopeId, p_user: u, p_backup: b || null });
        toast('حُفظ التوزيع', 'ok'); reload();
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
    const c = tr.querySelector('[data-clear]');
    if (c) c.onclick = async () => { try { await rpc(T.ctx.sb, 'team_clear_assignment', { p_id: c.dataset.clear }); toast('أُلغي الإسناد', 'ok'); reload(); } catch (er) { toast(cleanErr(er), 'bad'); } };
  });
}

const DETAIL_LABEL = { role: 'الدور', branch: 'الفرع', manage: 'الإدارة', name: 'الاسم', phone: 'الهاتف', reason: 'السبب', until: 'حتى', note: 'ملاحظة', to: 'المستلم', backup: 'البديل' };
async function pageAudit(body) {
  body.innerHTML = '<div class="loading"><div class="spin"></div></div>';
  let rows = [];
  try { rows = await rpc(T.ctx.sb, 'team_audit', { p_limit: 300 }); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  body.innerHTML = `<div class="audit-list">${rows.map(r => `<div class="audit-row"><div class="row" style="gap:8px"><b>${esc(r.action)}</b><span dir="auto">${esc(r.target || '')}</span>${r.branch_name ? `<span class="badge muted sm">${esc(r.branch_name)}</span>` : ''}<span class="sp"></span><span class="muted">${dt(r.created_at)}</span></div>
      <div class="muted">${esc(r.actor_name || '—')}${r.mine ? ' (أنا)' : ''} — ${esc(SCOPE[r.actor_scope] || (r.actor_scope === 'platform' ? 'مشغّل النظام' : r.actor_scope === 'self' ? 'بنفسه' : ''))}</div>
      ${Object.entries(r.details || {}).filter(([, v]) => v != null && v !== '').map(([k, v]) => `${esc(DETAIL_LABEL[k] || k)}: ${esc(v)}`).join(' · ') ? `<div>${Object.entries(r.details || {}).filter(([, v]) => v != null && v !== '').map(([k, v]) => `${esc(DETAIL_LABEL[k] || k)}: ${esc(v)}`).join(' · ')}</div>` : ''}</div>`).join('') || '<div class="card empty">لا إجراءات بعد.</div>'}</div>
    <p class="small muted" style="margin-top:10px">${T.meta.scope === 'org' ? 'ترى كل ما جرى في جهتك من مديري الفروع والأقسام ومشغّل النظام.' : 'ترى ما فعلته أنت' + (T.meta.scope === 'branch' ? ' وما جرى في فرعك.' : '.')} السجل لا يُعدّل ولا يُحذف.</p>`;
}

// تصفية صندوق الموظف حسب الإسناد (الخادم يفحص الشيء نفسه عند الإنجاز)
export function assignAllows(rules, app, me) {
  const ofApp = (rules || []).filter(r => r.stage === app.stage && (r.branch_id === app.branch_id || !r.branch_id));
  const r = ofApp.find(x => x.branch_id) || ofApp.find(x => !x.branch_id);
  if (!r || r.user_id === me.id) return true;
  if (r.primary_available) return false;
  if (r.backup_available) return r.backup_id === me.id;
  return true;
}
