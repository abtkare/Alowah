// الجلسة 17: المخاطبات الرسمية بين البنك المركزي وهيئة النزاهة — لا يطّلع عليها غير الجهتين (ولا مشغّل النظام)
import { esc, badge, dt, rpc, toast, cleanErr, modal } from './core.js';
import { pickFile } from './intake-ui.js';

export async function lettersView(ctx, body) {
  const { sb, portal } = ctx;
  const other = portal === 'cbi' ? 'هيئة النزاهة' : 'البنك المركزي العراقي';
  body.innerHTML = '<div class="card"><div class="spin"></div></div>';
  let box;
  try { box = await rpc(sb, 'letters_box', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  let f = ctx.lettersFilter || 'all';
  const draw = () => {
    const items = box.items.filter(x => f === 'all' || x.dir === f);
    body.innerHTML = `<div class="notice dark">🔒 <span><b>مخاطبات سرية بين البنك المركزي وهيئة النزاهة.</b> لا يطّلع عليها أي مصرف أو جهة أخرى ولا مشغّل النظام — تُقرأ من حسابات الجهتين فقط، ويُسجَّل وقت قراءتها ومن قرأها.</span></div>
      <div class="row mb" style="gap:8px;flex-wrap:wrap"><div class="seg sm">${[['all', 'الكل'], ['in', `الوارد${box.unread ? ` (${box.unread})` : ''}`], ['out', 'الصادر']].map(([k, t]) => `<label class="${f === k ? 'on' : ''}"><input type="radio" name="lf" value="${k}" ${f === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
        <span class="sp"></span><button class="btn cyan" data-new>✉ مخاطبة جديدة إلى ${esc(other)}</button></div>
      <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الرقم</th><th></th><th>الموضوع</th><th>من</th><th>التاريخ</th><th>الحالة</th></tr></thead><tbody>
      ${items.map(x => `<tr class="click ${x.dir === 'in' && !x.read_at ? 'unread' : ''}" data-open="${x.id}"><td class="num"><b>${esc(x.code)}</b></td><td>${x.dir === 'in' ? badge(['وارد', 'info']) : badge(['صادر', 'muted'])}</td>
        <td>${x.reply_to ? '↩ ' : ''}${esc(x.subject)}${x.has_att ? ' 📎' : ''}</td><td class="small">${esc(x.from_title || '')}<div class="muted">${esc(x.from_org)}</div></td><td class="small">${dt(x.created_at)}</td>
        <td class="small">${x.read_at ? `<span style="color:var(--ok)">قُرئت ${dt(x.read_at)}</span>` : x.dir === 'out' ? '<span class="muted">لم تُقرأ بعد</span>' : '<b>جديدة</b>'}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا مخاطبات بعد.</td></tr>'}
      </tbody></table></div></div>`;
    body.querySelectorAll('input[name=lf]').forEach(r => r.onchange = () => { f = ctx.lettersFilter = r.value; draw(); });
    body.querySelector('[data-new]').onclick = () => compose();
    body.querySelectorAll('[data-open]').forEach(r => r.onclick = () => openLetter(r.dataset.open));
  };
  const reload = async () => { box = await rpc(sb, 'letters_box', {}); draw(); ctx.bell?.reload(); };
  async function openLetter(id) {
    let l;
    try { l = await rpc(sb, 'letter_open', { p_id: id }); } catch (e) { return toast(cleanErr(e), 'bad'); }
    const m = modal(`<div class="letter"><div class="row small muted"><span>رقم <b class="num">${esc(l.code)}</b></span><span class="sp"></span><span>${dt(l.created_at)}</span></div>
      <h3 style="margin:6px 0">${esc(l.subject)}</h3>
      <dl class="kv small"><dt>من</dt><dd>${esc(l.from_title || '')} — ${esc(l.from_org_name)} <span class="num muted">${esc(l.from_code || '')}</span></dd><dt>إلى</dt><dd>${esc(l.to_org_name)}</dd>
        ${l.reply_code ? `<dt>رداً على</dt><dd class="num">${esc(l.reply_code)}</dd>` : ''}${l.read_at ? `<dt>قُرئت</dt><dd>${dt(l.read_at)} — ${esc(l.read_by_title || '')}</dd>` : ''}</dl>
      <div class="letter-body">${esc(l.body)}</div>
      ${l.attachment ? `<p class="mt">📎 <a href="${l.attachment}" download="${esc(l.attachment_name || 'مرفق')}">${esc(l.attachment_name || 'المرفق')}</a></p>` : ''}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-reply>↩ رد</button></div></div>`, { wide: true });
    m.el.querySelector('[data-reply]').onclick = () => { m.close(); compose(l); };
    reload();
  }
  function compose(re = null) {
    let att = null;
    const m = modal(`<h3>${re ? `رد على المخاطبة ${esc(re.code)}` : `مخاطبة جديدة إلى ${esc(other)}`}</h3>
      <div class="field"><label>الموضوع</label><input class="input" data-s maxlength="200" value="${re ? esc('رد: ' + re.subject.replace(/^رد: /, '')) : ''}"></div>
      <div class="field"><label>نص المخاطبة</label><textarea class="input" rows="8" data-b placeholder="نص الكتاب الرسمي…"></textarea></div>
      <div class="row" style="gap:8px"><button type="button" class="btn ghost sm" data-att>📎 إرفاق ملف (PDF أو صورة)</button><span class="small muted" data-an></span></div>
      <p class="small muted">تُرسل المخاطبة باسمك ومنصبك ورمزك الوظيفي، ولا تُعدَّل ولا تُحذف بعد الإرسال.</p>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>إرسال</button></div>`, { wide: true });
    m.el.querySelector('[data-att]').onclick = async () => { const fl = await pickFile({ maxMB: 3 }); if (fl) { att = fl; m.el.querySelector('[data-an]').textContent = fl.meta?.name || 'مرفق'; } };
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try {
        const r = await rpc(sb, 'letter_send', { p: { subject: m.el.querySelector('[data-s]').value.trim(), body: m.el.querySelector('[data-b]').value.trim(), reply_to: re?.id || null,
          attachment: att?.data || null, attachment_name: att?.meta?.name || null } });
        m.close(); toast(`أُرسلت المخاطبة ${r.code}`, 'ok'); f = 'out'; reload();
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }
  draw();
}
