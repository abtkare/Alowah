// الجلسة 22: تبسيط رحلة المقترض — المقترحات 5–11 من «مراجعة دورة حياة المقترض»
// مكان المنظومة (أنا هناك / رابط لشخص هناك / دبوس على الخريطة)، المحافظة من الموقع، مشاركة الروابط،
// النواقص التي يصلحها المقترض من هاتفه، تأكيد الدبوس في الكشف الموقعي، استلام جدول الأقساط من الهاتف، وخيارات المصرف
import { esc, badge, rpc, toast, cleanErr, modal, dt, GOVS, SITE_TYPE, purposeText, mapsLink, askOtp, viewDoc, iqd, num } from './core.js';
import { gpsDialog } from './geo.js';
import { cameraCapture } from './capture.js';
import { pickFile } from './intake-ui.js';

// ───────── خيارات المصرف (المقترحان 8 و11) ─────────
export const BANK_OPTS = {
  opt_manual_pin: ['تحديد مكان المنظومة بدبوس على الخريطة', 'إذا تعذّر الـGPS يضع المقترض دبوساً بإصبعه على الخريطة. يُعلَّم الطلب «محدد يدوياً»، ولا تُنجز المرحلة 14 حتى تؤكد لجنة الكشف الموقعي المكان بالـGPS وهي فيه.'],
  opt_phone_schedule: ['استلام جدول الأقساط من هاتف المقترض', 'في المرحلة 34 يراجع المقترض جدول أقساطه ويوقّع على استلامه برمز تحقق يصل هاتفه، بدل زيارة الفرع. يبقى التسليم في الفرع متاحاً.'],
};
export const bankOpt = (bank, k) => !!bank?.meta?.[k];

// ───────── المحافظة والمدينة من الموقع (المقترح 5) ─────────
const norm = s => String(s || '').replace(/^محافظة\s+/, '').replace(/[أإآ]/g, 'ا').replace(/ة$/, 'ه').replace(/^ال/, '').trim();
const ALIAS = { 'قادسيه': 'الديوانية', 'ديوانيه': 'الديوانية', 'موصل': 'نينوى', 'ناصريه': 'ذي قار', 'رمادي': 'الأنبار', 'تكريت': 'صلاح الدين', 'حله': 'بابل', 'عماره': 'ميسان', 'كوت': 'واسط', 'سماوه': 'المثنى', 'بعقوبه': 'ديالى', 'اربيل': 'أربيل', 'انبار': 'الأنبار' };
const matchGov = s => { const n = norm(s); if (!n) return null; const g = GOVS.find(([x]) => norm(x) === n) || GOVS.find(([x]) => n.includes(norm(x)) || norm(x).includes(n)); return g ? g[0] : ALIAS[n] || null; };
const nearestGov = (lat, lng) => GOVS.reduce((b, g) => { const d = (g[1] - lat) ** 2 + (g[2] - lng) ** 2; return !b || d < b[1] ? [g[0], d] : b; }, null)[0];
// يحاول اسم المحافظة والمدينة من خريطة OpenStreetMap، وإلا أقرب مركز محافظة
export async function placeFromGeo(lat, lng) {
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 5000);
    const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12&accept-language=ar&lat=${lat}&lon=${lng}`, { signal: ctl.signal });
    clearTimeout(t);
    const j = await r.json(), a = j.address || {};
    const gov = matchGov(a.state) || matchGov(a.province) || matchGov(a.county) || nearestGov(lat, lng);
    const city = a.city || a.town || a.village || a.suburb || a.county || '';
    return { gov, city: String(city).replace(/^(قضاء|ناحية)\s+/, '').slice(0, 60), src: 'osm' };
  } catch { return { gov: nearestGov(lat, lng), city: '', src: 'near' }; }
}

// ───────── مشاركة رابط بالواتساب أو الرسائل أو النسخ ─────────
export function shareLink({ title, url, text, expires, sms = null }) {
  // الجلسة 23: رابط الكفيل يمكن أن ترسله المنصة نفسها برسالة إلى هاتفه (حين تكون خدمة الرسائل مربوطة)
  const viaUs = sms && window.ALWAH_DEV?.sms;
  const msg = `${text}\n${url}`;
  const m = modal(`<h3>${esc(title)}</h3>
    <p class="muted small" style="margin-top:0">الرابط لمرة واحدة، وينتهي ${expires ? `في <b>${esc(dt(expires))}</b>` : 'خلال 48 ساعة'}. لا يحتاج من يفتحه إلى حساب أو كلمة مرور.</p>
    <div class="share-url" dir="ltr">${esc(url)}</div>
    <div class="share-btns">
      ${viaUs ? `<button type="button" class="btn cyan big-btn" data-oursms>أرسله إليه برسالة من المنصة<br><small><bdi dir="ltr" class="num">${esc(sms.masked || '')}</bdi></small></button>` : ''}
      <a class="btn wa big-btn" href="https://wa.me/?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">إرسال بالواتساب</a>
      <a class="btn ghost big-btn" href="sms:?&body=${encodeURIComponent(msg)}">إرسال برسالة نصية</a>
      <button type="button" class="btn ghost big-btn" data-copy>نسخ الرابط</button>
      ${navigator.share ? '<button type="button" class="btn ghost big-btn" data-native>مشاركة بطريقة أخرى</button>' : ''}
    </div>`);
  m.el.querySelector('[data-copy]').onclick = async () => { try { await navigator.clipboard.writeText(url); toast('نُسخ الرابط', 'ok'); } catch { toast('انسخ الرابط من المربع أعلاه', 'bad'); } };
  const n = m.el.querySelector('[data-native]'); if (n) n.onclick = () => navigator.share({ title, text, url }).catch(() => {});
  const o = m.el.querySelector('[data-oursms]');
  if (o) o.onclick = async () => {
    o.disabled = true;
    try {
      const r = await rpc(sms.sb, 'link_send_sms', { p_token: sms.token });
      if (r.status === 'skipped') throw new Error('تعذّر الإرسال الآن — أرسل الرابط بالواتساب');
      o.className = 'btn ghost big-btn'; o.innerHTML = `✓ أُرسل الرابط برسالة إلى <bdi dir="ltr" class="num">${esc(r.phone || sms.masked || '')}</bdi>`; toast('أُرسل الرابط إلى هاتف الكفيل', 'ok');
    } catch (e) { o.disabled = false; toast(cleanErr(e), 'bad'); }
  };
  return m;
}

// ───────── خريطة: دبوس بإصبع المقترض (المقترح 8) ─────────
let leaflet;
export function loadLeaflet() {
  if (leaflet) return leaflet;
  leaflet = new Promise((res, rej) => {
    if (window.L?.map) return res(window.L);
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = () => { leaflet = null; rej(new Error('تعذّر تحميل الخريطة — تحقق من الإنترنت')); };
    document.head.appendChild(s);
  });
  return leaflet;
}
export function pinDialog({ center, gov } = {}) {
  return new Promise(resolve => {
    let done = false, pin = null;
    const m = modal(`<h3>ضع الدبوس على مكان المنظومة</h3>
      <ol class="gps-steps small" style="margin:0 0 8px"><li>كبّر الخريطة بإصبعين حتى ترى البيوت والشوارع.</li><li>اضغط على مكان المنظومة نفسه (السطح أو الأرض).</li><li>اضغط «اعتماد هذا المكان».</li></ol>
      <div class="pin-map" data-map><div class="spin"></div></div>
      <p class="small muted" data-h style="margin:6px 0">لم تضع الدبوس بعد.</p>
      <div class="notice"><span>ℹ</span><span class="small">يُعلَّم طلبك <b>«محدد يدوياً»</b>، وتتأكد منه لجنة الكشف الموقعي حين تزور المكان.</span></div>
      <button class="btn cyan big-btn mt" data-ok disabled>✓ اعتماد هذا المكان</button>`, { wide: true, onClose: () => { if (!done) resolve(null); } });
    const ok = m.el.querySelector('[data-ok]'), h = m.el.querySelector('[data-h]');
    loadLeaflet().then(L => {
      const box = m.el.querySelector('[data-map]'); box.innerHTML = '';
      const g = GOVS.find(x => x[0] === gov);
      const c = center?.lat ? [center.lat, center.lng] : g ? [g[1], g[2]] : [33.2, 43.7];
      const map = L.map(box, { zoomControl: true }).setView(c, center?.lat ? 17 : g ? 12 : 6);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
      let mk = null;
      const put = ll => {
        pin = { lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6) };
        mk ? mk.setLatLng(ll) : (mk = L.marker(ll, { draggable: true }).addTo(map).on('dragend', e => put(e.target.getLatLng())));
        const z = map.getZoom();
        ok.disabled = z < 16;
        h.innerHTML = z < 16 ? '⚠ كبّر الخريطة أكثر ثم ضع الدبوس — نحتاج المكان بدقة البيت.' : '📍 وُضع الدبوس — اسحبه إن أردت تعديله.';
      };
      map.on('click', e => put(e.latlng));
      map.on('zoomend', () => { if (pin) put(pin); });
      setTimeout(() => map.invalidateSize(), 250);
    }).catch(e => { m.el.querySelector('[data-map]').innerHTML = `<div class="notice warn">${esc(e.message)}</div>`; });
    ok.onclick = () => { done = true; m.close(); resolve(pin); };
  });
}

// ───────── لوحة «مكان المنظومة» (المقترحات 5 و6 و7 و8) ─────────
// opts: { sb, bank, accMax, onSaved, required, late }
export function placePanel(box, app, { sb, bank, accMax = 100, onSaved, required = false, late = false } = {}) {
  if (!box) return;
  const g = app.site_geo, canEdit = app.stage <= 5;
  const manualOk = bankOpt(bank, 'opt_manual_pin');
  let link = null;
  const save = async (p, how) => {
    const geo = await placeFromGeo(p.lat, p.lng);
    const a = await rpc(sb, 'set_app_site', { p_app: app.id, p: { ...p, geo_gov: geo.gov, geo_city: geo.city } });
    Object.assign(app, a);
    toast(`${how} — ${a.governorate || ''}${a.city && a.city !== a.governorate ? ' / ' + a.city : ''}`, 'ok');
    onSaved ? onSaved(a) : paint();
  };
  const viaTxt = x => x?.source === 'manual' ? (x.confirmed_at ? badge(['محدد يدوياً — أكدته لجنة الكشف', 'ok']) : badge(['محدد يدوياً — تؤكده لجنة الكشف', 'warn'])) : x?.via === 'link' ? badge(['حدّده شخص في المكان عبر الرابط', 'ok']) : badge(['بالـGPS', 'ok']);
  const paint = () => {
    const x = app.site_geo;
    if (x && !box.dataset.edit) {
      box.innerHTML = `<div class="card wiz-body mb site-sum"><div class="row" style="flex-wrap:wrap;gap:8px"><b>📍 مكان المنظومة:</b> ${esc(SITE_TYPE[app.site_type] || '')} — ${esc(purposeText(app))}
        <span class="small muted">· ${esc(app.governorate || '')}${app.city && app.city !== app.governorate ? ' / ' + esc(app.city) : ''} · <a href="${mapsLink(x)}" target="_blank" rel="noopener">على الخريطة</a></span> ${viaTxt(x)}
        <span class="sp"></span>${canEdit ? '<button type="button" class="btn ghost sm" data-edit>تغيير</button>' : ''}</div></div>`;
      const e = box.querySelector('[data-edit]'); if (e) e.onclick = () => { box.dataset.edit = '1'; paint(); };
      return;
    }
    // سؤال واحد في الشاشة: قبل الخطوة الأخيرة يبقى مكان المنظومة سطراً صغيراً لا يزاحم الخطوة الحالية
    if (!x && !required && !late && !box.dataset.edit) {
      box.innerHTML = `<div class="card wiz-body mb site-sum"><div class="row" style="flex-wrap:wrap;gap:8px"><b>📍 مكان المنظومة:</b> <span class="small muted">لم يُحدَّد بعد — تحدده قبل الإرسال، من هاتفك وأنت هناك أو برابط لشخص هناك</span>
        <span class="sp"></span><button type="button" class="btn ghost sm" data-open>حدّده الآن</button></div></div>`;
      box.querySelector('[data-open]').onclick = () => { box.dataset.edit = '1'; paint(); };
      return;
    }
    box.innerHTML = `<div class="card wiz-body mb place-card ${required ? 'req' : ''}">
      <h2 style="margin-top:0">📍 أين ستُركَّب المنظومة؟</h2>
      ${late ? '<div class="notice warn"><span>★</span><span><b>مطلوب منك الآن:</b> طلبك وصل المصرف بلا مكان المنظومة — حدّده مرة واحدة ليزور المصرفُ المكان.</span></div>'
        : required ? '<div class="notice warn"><span>★</span><span><b>بقي هذا قبل الإرسال:</b> حدّد مكان المنظومة — يزوره المصرف ثم فني المورد.</span></div>'
        : '<p class="muted small" style="margin-top:0">ليس مطلوباً الآن — أكمل طلبك، وحدّد المكان في أي وقت قبل الإرسال.</p>'}
      <div class="place-opts">
        <button type="button" class="place-opt" data-here><i>📍</i><b>أنا في المكان الآن</b><small>نحدد الموقع من هاتفك بضغطة</small></button>
        <button type="button" class="place-opt" data-link><i>🔗</i><b>أرسل الرابط لشخص هناك</b><small>بالواتساب — يضغط زراً واحداً دون تسجيل</small></button>
        ${manualOk ? '<button type="button" class="place-opt" data-pin><i>🗺</i><b>حدّده على الخريطة</b><small>إن لم يعمل الموقع — تتأكد منه لجنة المصرف</small></button>' : ''}
      </div>
      <div data-linkst></div>
      ${x || (!required && !late) ? '<div class="row mt"><span class="sp"></span><button type="button" class="btn ghost sm" data-cancel>لاحقاً</button></div>' : ''}
    </div>`;
    box.querySelector('[data-here]').onclick = async () => {
      const r = await gpsDialog({ title: 'تحديد مكان المنظومة', hint: 'سيصل المصرف ثم فني المورد إلى هذا المكان بالضبط.', want: Math.min(25, accMax), accMax });
      if (!r) return;
      try { delete box.dataset.edit; await save({ lat: r.lat, lng: r.lng, acc: r.acc, source: 'gps' }, 'حُفظ مكان المنظومة'); } catch (e) { toast(cleanErr(e), 'bad'); }
    };
    box.querySelector('[data-link]').onclick = async () => {
      try {
        const r = await rpc(sb, 'link_create', { p_app: app.id, p_kind: 'site', p_data: {} });
        link = r; drawLink();
        shareLink({ title: 'أرسل الرابط لمن هو في مكان المنظومة', url: `${location.origin}/l/${r.token}`, expires: r.expires_at,
          text: `السلام عليكم، أرجو أن تفتح هذا الرابط وأنت في مكان تركيب المنظومة الشمسية وتضغط «حدّد المكان الآن» — يأخذ دقيقة واحدة (طلب ${app.code} في منصة ألواح):` });
      } catch (e) { toast(cleanErr(e), 'bad'); }
    };
    const pb = box.querySelector('[data-pin]');
    if (pb) pb.onclick = async () => {
      const p = await pinDialog({ center: app.site_geo, gov: app.governorate });
      if (!p) return;
      try { delete box.dataset.edit; await save({ lat: p.lat, lng: p.lng, source: 'manual' }, 'حُفظ المكان — محدد يدوياً'); } catch (e) { toast(cleanErr(e), 'bad'); }
    };
    const c = box.querySelector('[data-cancel]'); if (c) c.onclick = () => { delete box.dataset.edit; paint(); };
    drawLink();
  };
  const drawLink = () => {
    const el = box.querySelector('[data-linkst]'); if (!el || !link) return;
    const exp = new Date(link.expires_at) < new Date();
    el.innerHTML = `<div class="notice ${exp ? 'warn' : ''} mt"><span>🔗</span><span class="small">${exp ? 'انتهت صلاحية الرابط — أرسل رابطاً جديداً.' : `أرسلت رابطاً ينتهي <b>${esc(dt(link.expires_at))}</b>. حين يحدد الشخص المكان يظهر هنا تلقائياً.`}</span></div>`;
  };
  // آخر رابط لم يُستخدم (يظهر حالته بعد إعادة فتح الصفحة)
  sb.from('app_links').select('token,expires_at,used_at,revoked_at').eq('application_id', app.id).eq('kind', 'site').order('created_at', { ascending: false }).limit(1)
    .then(r => { const l = (r.data || [])[0]; if (l && !l.used_at && !l.revoked_at) { link = l; drawLink(); } }).catch(() => {});
  paint();
}

// ───────── النواقص التي يصلحها المقترض من هاتفه (المقترح 10) ─────────
export async function loadFix(sb, appId) {
  const r = await sb.from('app_fix_requests').select('*').eq('application_id', appId).order('created_at');
  return r.data || [];
}
const FIX_ST = { open: ['بانتظار المقترض', 'warn'], answered: ['أرسل المقترض النواقص', 'ok'], closed: ['مغلق', 'muted'] };

// المقترض: كل نقص في سطر، وزر يصلحه من الهاتف
export function mountBorrowerFix(box, reqs, { sb, onDone } = {}) {
  const open = reqs.filter(r => r.status === 'open');
  if (!box || !open.length) { if (box) box.innerHTML = ''; return; }
  box.innerHTML = open.map(r => `<div class="card mb fix-card" data-r="${r.id}">
    <h3 style="margin-top:0">المصرف يطلب منك ${r.items.length === 1 ? 'بنداً واحداً' : `<span class="num">${r.items.length}</span> بنود`}<span class="sp"></span><span class="small muted">${esc(r.created_by_title || '')} · ${dt(r.created_at)}</span></h3>
    ${r.note ? `<p class="small" style="margin:0 0 8px">${esc(r.note)}</p>` : ''}
    <div class="fix-list">${r.items.map(i => `<div class="fix-i ${i.done ? 'ok' : ''}"><span class="ck-m">${i.done ? '✓' : '★'}</span><span class="fix-l">${esc(i.label)}${i.done && i.text ? `<small>جوابك: ${esc(i.text)}</small>` : ''}</span>
      ${i.done ? badge(['تم', 'ok']) : i.kind === 'text' ? `<button type="button" class="btn cyan sm" data-txt="${esc(i.key)}">اكتب الجواب</button>`
        : `<span class="row" style="gap:6px"><button type="button" class="btn cyan sm" data-cam="${esc(i.key)}">📷 صوّره</button><button type="button" class="btn ghost sm" data-file="${esc(i.key)}">ملف</button></span>`}</div>`).join('')}</div>
    <p class="small muted" style="margin:8px 0 0">يصل للمصرف كل بند فور إصلاحه — لا تحتاج زيارة الفرع.</p></div>`).join('');
  const send = async (rid, key, p) => {
    try { const r = await rpc(sb, 'fix_request_answer', { p_req: rid, p_key: key, p }); toast(r.status === 'answered' ? 'وصلت كل النواقص إلى المصرف ✓' : 'وصل هذا البند إلى المصرف', 'ok'); onDone && onDone(r); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
  box.querySelectorAll('[data-cam]').forEach(b => b.onclick = async () => {
    const rid = b.closest('[data-r]').dataset.r, it = reqs.find(r => r.id === rid).items.find(i => i.key === b.dataset.cam);
    const x = await cameraCapture({ title: it.label, allowFile: true }); if (x) send(rid, b.dataset.cam, { data: x.data, source: x.meta?.live ? 'camera' : 'file', meta: x.meta });
  });
  box.querySelectorAll('[data-file]').forEach(b => b.onclick = async () => {
    const rid = b.closest('[data-r]').dataset.r; const f = await pickFile({ maxMB: 3 }); if (f) send(rid, b.dataset.file, { data: f.data, source: 'file', meta: f.meta });
  });
  box.querySelectorAll('[data-txt]').forEach(b => b.onclick = () => {
    const rid = b.closest('[data-r]').dataset.r, it = reqs.find(r => r.id === rid).items.find(i => i.key === b.dataset.txt);
    const m = modal(`<h3>${esc(it.label)}</h3><div class="field"><textarea class="input" rows="3" maxlength="500" data-v></textarea></div><div class="row"><span class="sp"></span><button class="btn cyan" data-ok>إرسال</button></div>`);
    m.el.querySelector('[data-ok]').onclick = async () => { const v = m.el.querySelector('[data-v]').value.trim(); if (v.length < 2) return toast('اكتب الجواب', 'bad'); m.close(); send(rid, b.dataset.txt, { text: v }); };
    setTimeout(() => m.el.querySelector('[data-v]').focus(), 50);
  });
}

// المصرف: «اطلب من المقترض» وما أرسله
export function bankFixCard(a, reqs, { canAsk }) {
  if (a.program === 'vet') return '';
  if (!reqs.length && !canAsk) return '';
  return `<div class="card mb"><h3>نواقص يصلحها المقترض من هاتفه${canAsk ? '<span class="sp"></span><button type="button" class="btn cyan sm" data-fixnew>＋ اطلب من المقترض</button>' : ''}</h3>
    ${reqs.length ? reqs.slice().reverse().map(r => `<div class="fix-req"><div class="row" style="flex-wrap:wrap;gap:6px"><b class="small">المرحلة <span class="num">${r.stage}</span></b><span class="small muted">${esc(r.created_by_title || '')} · ${dt(r.created_at)}</span><span class="sp"></span>${badge(FIX_ST[r.status])}
      ${r.status !== 'closed' && canAsk ? `<button type="button" class="linkbtn small" data-fixclose="${r.id}">${r.status === 'answered' ? 'استلمت — إغلاق' : 'إلغاء الطلب'}</button>` : ''}</div>
      ${r.items.map(i => `<div class="fix-i ${i.done ? 'ok' : ''}"><span class="ck-m">${i.done ? '✓' : '★'}</span><span class="fix-l">${esc(i.label)}${i.text ? `<small>الجواب: <b>${esc(i.text)}</b></small>` : ''}</span>${i.doc_id ? `<button type="button" class="btn ghost sm" data-doc="${i.doc_id}">عرض</button>` : ''}</div>`).join('')}
      ${r.note ? `<div class="small muted">ملاحظة: ${esc(r.note)}</div>` : ''}</div>`).join('')
    : '<p class="small muted" style="margin:0">لا يصل المقترضَ إلا ما تكتبه هنا: كل نقص بجملة واضحة، ويصلحه من هاتفه بصورة أو ملف أو جواب مكتوب. في الاستقبال (المرحلة 6) تُضاف البنود إلى قائمة التدقيق بنجمة حمراء حتى يصلحها.</p>'}</div>`;
}
export function bindBankFix(sb, a, root, { refresh } = {}) {
  if (!root) return;
  root.querySelectorAll('[data-doc]').forEach(b => { if (!b.onclick) b.onclick = () => viewDoc(sb, b.dataset.doc); });
  const nb = root.querySelector('[data-fixnew]');
  if (nb) nb.onclick = () => {
    const rows = [{ label: '', kind: 'doc' }];
    const m = modal(`<h3>اطلب من المقترض إصلاح نقص</h3><p class="small muted" style="margin-top:0">اكتب كل نقص بجملة يفهمها أي شخص، مثل: «صورة أوضح لظهر البطاقة الوطنية» أو «ما رقم هاتف جهة عملك؟».</p>
      <div data-rows></div><button type="button" class="btn ghost sm" data-add>＋ بند آخر</button>
      <div class="field mt"><label>ملاحظة للمقترض (اختياري)</label><input class="input" data-note maxlength="400"></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>إرسال للمقترض</button></div>`, { wide: true });
    const draw = () => {
      m.el.querySelector('[data-rows]').innerHTML = rows.map((r, i) => `<div class="row fix-row" data-i="${i}"><input class="input" data-l maxlength="140" placeholder="النقص المطلوب" value="${esc(r.label)}">
        <select class="input" data-k style="max-width:150px"><option value="doc" ${r.kind === 'doc' ? 'selected' : ''}>صورة أو ملف</option><option value="text" ${r.kind === 'text' ? 'selected' : ''}>جواب مكتوب</option></select>
        ${rows.length > 1 ? `<button type="button" class="linkbtn" data-rm="${i}">حذف</button>` : ''}</div>`).join('');
      m.el.querySelectorAll('[data-i]').forEach(d => { const i = +d.dataset.i; d.querySelector('[data-l]').oninput = e => rows[i].label = e.target.value; d.querySelector('[data-k]').onchange = e => rows[i].kind = e.target.value; });
      m.el.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { rows.splice(+b.dataset.rm, 1); draw(); });
      m.el.querySelector('[data-add]').hidden = rows.length >= 8;
    };
    m.el.querySelector('[data-add]').onclick = () => { rows.push({ label: '', kind: 'doc' }); draw(); };
    m.el.querySelector('[data-go]').onclick = async e => {
      const items = rows.filter(r => r.label.trim());
      if (!items.length) return toast('اكتب النقص المطلوب', 'bad');
      e.target.disabled = true;
      try { await rpc(sb, 'fix_request_create', { p_app: a.id, p_items: items, p_note: m.el.querySelector('[data-note]').value }); m.close(); toast('أُرسل الطلب للمقترض — يصله في «طلبي»', 'ok'); refresh && refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
    draw();
  };
  root.querySelectorAll('[data-fixclose]').forEach(b => b.onclick = async () => {
    try { await rpc(sb, 'fix_request_close', { p_req: b.dataset.fixclose, p_note: null }); toast('أُغلق طلب النواقص', 'ok'); refresh && refresh(); } catch (e) { toast(cleanErr(e), 'bad'); }
  });
}

// ───────── المقترح 8: تأكيد الدبوس اليدوي في الكشف الموقعي ─────────
export function siteConfirmCard(a, { mine, role }) {
  const g = a.site_geo; if (!g || g.source !== 'manual') return '';
  const can = mine && a.stage === 14 && ['bank_inspection', 'bank_branch_mgr'].includes(role) && !g.confirmed_at;
  return `<div class="card mb ${g.confirmed_at ? '' : 'warn-card'}"><h3>مكان المنظومة محدد يدوياً ${g.confirmed_at ? badge(['أكدته لجنة الكشف', 'ok']) : badge(['بانتظار تأكيد لجنة الكشف', 'warn'])}</h3>
    <p class="small" style="margin:0 0 6px">وضع المقترض دبوساً على الخريطة لأن الـGPS تعذّر في هاتفه. <a href="${mapsLink(g.pin || g)}" target="_blank" rel="noopener">موضع الدبوس على الخريطة</a></p>
    ${g.confirmed_at ? `<p class="small muted" style="margin:0">أُكّد بالـGPS في الموقع ${dt(g.confirmed_at)} · ${esc(g.confirmed_by || '')} · يبعد <b class="num">${num(g.confirm_dist_m)}</b> م عن الدبوس${g.confirm_note ? ` · ${esc(g.confirm_note)}` : ''}</p>`
      : `<p class="small muted" style="margin:0">لا تُنجز المرحلة 14 قبل التأكيد: قف في مكان المنظومة واضغط الزر — يُسجَّل الموقع الفعلي وبُعده عن الدبوس.</p>
      ${can ? '<button type="button" class="btn cyan mt" data-siteok>📍 تأكيد مكان المنظومة بالـGPS</button>' : ''}`}</div>`;
}
export function bindSiteConfirm(sb, a, root, { accMax = 100, refresh } = {}) {
  const b = root?.querySelector('[data-siteok]'); if (!b) return;
  b.onclick = async () => {
    const r = await gpsDialog({ title: 'تأكيد مكان المنظومة', hint: 'قف في مكان تركيب المنظومة نفسه.', want: Math.min(25, accMax), accMax });
    if (!r) return;
    const m = modal(`<h3>تأكيد مكان المنظومة</h3><p class="small muted" style="margin-top:0">الموقع الفعلي بدقة ±<span class="num">${Math.round(r.acc)}</span> م.</p>
      <div class="field"><label>ملاحظة (اختياري): هل المكان يطابق ما وضعه المقترض؟</label><textarea class="input" rows="2" maxlength="300" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-go>تأكيد المكان</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try { const x = await rpc(sb, 'site_confirm', { p_app: a.id, p: { lat: r.lat, lng: r.lng, acc: r.acc, note: m.el.querySelector('[data-n]').value } }); m.close(); toast(`أُكّد المكان — يبعد ${x.site_geo.confirm_dist_m} م عن الدبوس`, 'ok'); refresh && refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

// ───────── المقترح 11: استلام جدول الأقساط من الهاتف ─────────
export function scheduleAckHtml(app, bank) {
  if (app.stage !== 34 || app.status !== 'active' || !bankOpt(bank, 'opt_phone_schedule')) return '';
  return `<div class="card mb ack-card" data-ackbox><h3 style="margin-top:0">استلم جدول أقساطك من هاتفك</h3>
    <ol class="gps-steps small"><li>راجع جدول أقساطك بالأسفل: المبلغ وموعد كل قسط.</li><li>اضغط «استلمت جدول أقساطي» واكتب الرمز الذي يصل هاتفك.</li></ol>
    <p class="small muted">هذا بدل زيارة الفرع للتوقيع على الاستلام — توقيعك برمز التحقق محفوظ في سجل طلبك.</p>
    <button type="button" class="btn cyan big-btn" data-ack>✓ استلمت جدول أقساطي</button></div>`;
}
export function bindScheduleAck(sb, app, profile, root, { onDone } = {}) {
  const b = root?.querySelector('[data-ack]'); if (!b) return;
  b.onclick = async () => {
    const c = await askOtp({ kind: 'schedule', title: 'التوقيع على استلام جدول الأقساط', phone: profile.phone, purpose: `استلام جدول أقساط الطلب ${app.code}`,
      verify: code => rpc(sb, 'schedule_ack', { p_app: app.id, p_otp: code }) });
    if (c) { toast('سُجّل استلامك لجدول الأقساط ✓', 'ok'); onDone && onDone(); }
  };
}

// ───────── إعدادات المصرف: الخياران (المقترحان 8 و11) ─────────
export function bankSettings(ctx, box, org) {
  const can = ['bank_md', 'bank_admin'].includes(ctx.profile.role);
  const paint = () => {
    box.innerHTML = `<div class="card"><h3>إعدادات رحلة المقترض</h3>
      <p class="small muted" style="margin-top:0">خياران يحتاجان موافقة المصرف — كلاهما مطفأ حتى تشغّله الإدارة العليا أو مدير المصرف. يُسجَّل كل تغيير في سجل التدقيق.</p>
      ${Object.entries(BANK_OPTS).map(([k, [t, d]]) => `<div class="opt-row"><div><b>${esc(t)}</b><p class="small muted" style="margin:2px 0 0">${esc(d)}</p>
        ${org.meta?.[k + '_at'] ? `<p class="small muted" style="margin:2px 0 0">آخر تغيير: ${esc(org.meta[k + '_by'] || '')} · ${dt(org.meta[k + '_at'])}</p>` : ''}</div>
        <label class="switch ${can ? '' : 'dis'}"><input type="checkbox" data-opt="${k}" ${org.meta?.[k] ? 'checked' : ''} ${can ? '' : 'disabled'}><span></span><b>${org.meta?.[k] ? 'مفعّل' : 'مطفأ'}</b></label></div>`).join('')}
      ${can ? '' : '<p class="small muted mt">تغيير الخيارات للإدارة العليا ومدير المصرف.</p>'}</div>`;
    box.querySelectorAll('[data-opt]').forEach(i => i.onchange = async () => {
      i.disabled = true;
      try { org.meta = await rpc(ctx.sb, 'bank_set_option', { p_key: i.dataset.opt, p_on: i.checked }); toast(i.checked ? 'شُغّل الخيار' : 'أُطفئ الخيار', 'ok'); }
      catch (e) { toast(cleanErr(e), 'bad'); i.checked = !i.checked; }
      paint();
    });
  };
  paint();
}
