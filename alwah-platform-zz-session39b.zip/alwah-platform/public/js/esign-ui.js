// الجلسة 15: التوقيع الإلكتروني لعقد التمويل والكمبيالة (المرحلة 25)
// بطاقة لموظف المصرف (إرفاق الصورة المرجعية، الإرسال، الإلغاء) وبطاقة للمقترض (التوقيع من هاتفه)
import { esc, badge, dt, toast, cleanErr, rpc, modal, viewDoc, what } from './core.js';

export const ESIGN_STATUS = {
  sent: ['بانتظار توقيع المقترض', 'warn'], completed: ['وقّع المقترض إلكترونياً', 'ok'], expired: ['انتهت صلاحية الرابط', 'bad'],
  cancelled: ['أُلغي طلب التوقيع', 'bad'], manual_review: ['اختار التوقيع حضورياً في الفرع', 'warn'], failed: ['تعذّر التوقيع', 'bad'], superseded: ['استُبدل بطلب أحدث', ''],
};

async function token(sb) { return (await sb.auth.getSession()).data.session?.access_token || ''; }
async function api(sb, path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${await token(sb)}` }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'تعذّر الاتصال بخدمة التوقيع');
  return j;
}
const certLine = q => `<div class="small muted mt">شهادة التوقيع <code dir="ltr">${esc(q.certificate_serial || '—')}</code>${q.qualified ? '' : ' · <b>جهة تصديق تجريبية</b> — يُعتمد قانونياً بعد الربط بجهة تصديق مرخّصة'}</div>`;

// ───────── المصرف ─────────
export async function mountEsignBank(ctx, a, mine, box) {
  if (!box) return;
  const { sb, profile } = ctx;
  let st;
  try { st = await rpc(sb, 'esign_status', { p_app: a.id }); } catch (e) { box.innerHTML = ''; return; }
  const q = st.request, s = q?.status;
  const canAct = mine && a.stage === 25 && ['active', 'returned'].includes(a.status) && ['bank_cs', 'bank_branch_mgr'].includes(profile.role);
  if (!q && !canAct && a.stage !== 25) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="card mb"><h3>التوقيع الإلكتروني للعقد<span class="sp"></span>${q ? badge(ESIGN_STATUS[s] || [s, '']) : badge(['لم يُرسَل بعد', ''])}</h3>
    ${q ? `<p class="small" style="margin:0">أُرسل ${dt(q.created_at)}${q.created_by_title ? ` — ${esc(q.created_by_title)}` : ''}${s === 'sent' ? ` · ينتهي الرابط ${dt(q.expires_at)}` : ''}${s === 'completed' ? ` · وُقّع ${dt(q.completed_at)}` : ''}</p>` : ''}
    ${s === 'completed' ? `<div class="row mt"><button class="btn sm" data-signed>العقد الموقّع (PDF)</button></div>${certLine(q)}` : ''}
    ${s === 'completed' && a.stage === 25 && mine ? '<div class="notice mt" style="background:var(--ok-bg,#E7F7EF)"><b>المطلوب منك:</b> دقّق العقد الموقّع ثم أنجز المرحلة 25 بزر الإنجاز أدناه — ينتقل الطلب إلى مدير الفرع.</div>' : ''}
    ${s === 'manual_review' ? '<div class="notice warn mt">طلب المقترض التوقيع حضورياً — وقّع العقد ورقياً في الفرع ثم أنجز المرحلة.</div>' : ''}
    ${canAct && s !== 'completed' ? `
      <div class="row mt" style="flex-wrap:wrap;gap:8px">
        <span class="small">${st.face_doc ? '<span class="ok-ic sm">✓</span> الصورة المرجعية لوجه المقترض مرفقة <button class="linkbtn" data-face-view>عرض</button>' : '<b>الخطوة 1:</b> أرفق الصورة المرجعية لوجه المقترض'}</span>
        <span class="sp"></span><button class="btn ${st.face_doc ? 'ghost' : 'cyan'} sm" data-face>${st.face_doc ? 'تغيير الصورة المرجعية' : 'تصوير الصورة المرجعية'}</button>
      </div>
      <div class="row mt">${s === 'sent'
        ? '<button class="btn bad sm" data-cancel>إلغاء طلب التوقيع (للتوقيع حضورياً)</button>'
        : `<button class="btn cyan" data-send ${st.face_doc ? '' : 'disabled'}>${q ? 'إعادة إرسال العقد للتوقيع الإلكتروني' : 'إرسال العقد للمقترض للتوقيع الإلكتروني'}</button>`}</div>
      <p class="small muted" style="margin:8px 0 0">الصورة المرجعية: صورة الوجه الأمامي للبطاقة الوطنية الموحدة، أو صورة وجه المقترض عند حضوره. يوقّع المقترض من «بوابة المقترض» على هاتفه: يقرأ العقد ويوافق، ثم يُطابَق وجهه مع الصورة المرجعية مع كشف الحيوية، ثم يؤكد ببصمة الجهاز. يصل العقد الموقّع إلى «المستندات» تلقائياً.</p>` : ''}
  </div>`;
  const on = (sel, fn) => { const b = box.querySelector(sel); if (b) b.onclick = fn; };
  const again = () => mountEsignBank(ctx, a, mine, box);
  on('[data-signed]', () => viewDoc(sb, q.signed_doc));
  on('[data-face-view]', () => viewDoc(sb, st.face_doc));
  on('[data-face]', async () => {
    const { cameraCapture } = await import('./capture.js');
    const r = await cameraCapture({ title: 'الصورة المرجعية لوجه المقترض', hint: 'صوّر وجه البطاقة الوطنية الموحدة (الصورة واضحة دون انعكاس) أو وجه المقترض من الأمام', ratio: 0.63, allowFile: true });
    if (!r) return;
    if (!String(r.data).startsWith('data:image/')) return toast('الصورة المرجعية يجب أن تكون صورة لا ملف PDF', 'bad');
    try { await rpc(sb, 'add_document', { p_app: a.id, p_kind: 'kyc_face', p_data: r.data, p_source: r.meta?.live ? 'camera' : 'file', p_meta: r.meta || {} }); toast('أُرفقت الصورة المرجعية', 'ok'); again(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  });
  on('[data-send]', async e => {
    e.target.disabled = true; e.target.textContent = 'جارِ تجهيز العقد وإرساله…';
    try { await api(sb, '/api/esign/start', { app_id: a.id }); toast('أُرسل العقد للمقترض — يظهر له في «بوابة المقترض» للتوقيع', 'ok'); again(); }
    catch (er) { toast(cleanErr(er), 'bad'); again(); }
  });
  on('[data-cancel]', () => {
    const m = modal(`<h3>إلغاء طلب التوقيع الإلكتروني</h3><p class="small muted">يُلغى الرابط فوراً، ويمكنك إرسال طلب جديد أو توقيع العقد حضورياً في الفرع.</p>
      <div class="field"><label>السبب</label><textarea class="input" rows="2" data-n></textarea></div><div class="row mt"><span class="sp"></span><button class="btn bad" data-go>إلغاء الطلب</button></div>`);
    m.el.querySelector('[data-go]').onclick = async ev => {
      ev.target.disabled = true;
      try { await api(sb, '/api/esign/cancel', { app_id: a.id, note: m.el.querySelector('[data-n]').value }); m.close(); toast('أُلغي طلب التوقيع', 'ok'); again(); }
      catch (er) { toast(cleanErr(er), 'bad'); ev.target.disabled = false; }
    };
  });
}

// ───────── المقترض ─────────
// الجلسة 24: فتح صفحة التوقيع مباشرة، وطلب رابط جديد أو التوقيع في الفرع بضغطة واحدة
export async function borrowerSign(sb, app, btn) {
  if (btn) btn.disabled = true;
  try { location.href = await rpc(sb, 'esign_my_link', { p_app: app.id }); }
  catch (er) { toast(cleanErr(er), 'bad'); if (btn) btn.disabled = false; }
}
export async function borrowerAsk(sb, app, kind, btn, { branch, onDone } = {}) {
  if (btn) btn.disabled = true;
  try {
    const r = await rpc(sb, 'esign_borrower_ask', { p_app: app.id, p_kind: kind });
    const br = branch?.name ? `فرع ${branch.name.replace(/^فرع\s*/, '')}` : 'الفرع';
    toast(r?.repeat ? `أبلغنا ${br} قبل قليل — سيتواصل معك` : kind === 'link' ? `أبلغنا ${br} — سيصلك رابط التوقيع برسالة` : `أبلغنا ${br} ليجهّز عقدك — راجعه مع بطاقتك الوطنية`, 'ok');
    if (onDone) await onDone();
  } catch (er) { toast(cleanErr(er), 'bad'); if (btn) btn.disabled = false; }
}

export async function mountEsignBorrower(sb, app, box, opts = {}) {
  if (!box) return;
  let st;
  try { st = await rpc(sb, 'esign_status', { p_app: app.id }); } catch { box.innerHTML = ''; return; }
  const q = st.request, s = q?.status;
  if (!q || s === 'superseded') { box.innerHTML = ''; return; }
  if (s === 'sent') {
    box.innerHTML = `<div class="card mb esign-cta" style="border:2px solid var(--cyan)">
      <h3>✍️ عقدك جاهز للتوقيع الإلكتروني</h3>
      <p style="margin:4px 0 10px">وقّع عقد التمويل والكمبيالة ${what('kambiala')} من هاتفك الآن — دون مراجعة الفرع. يستغرق ذلك نحو دقيقتين:</p>
      <ol class="how" style="margin:0 0 10px">
        <li><i>1</i>اقرأ العقد كاملاً ووافق عليه</li>
        <li><i>2</i>صوّر وجهك وحرّك رأسك كما يُطلب منك</li>
        <li><i>3</i>أكّد ببصمة إصبعك أو وجهك على الهاتف</li>
      </ol>
      <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn cyan" data-sign>وقّع عقدك الآن</button><span class="small muted">الرابط صالح حتى ${dt(q.expires_at)}</span></div>
      <p class="small muted" style="margin:8px 0 0">تحتاج هاتفاً بكاميرا أمامية وقفل شاشة مفعّل (بصمة أو وجه أو رمز). لا تُحفظ صور وجهك. إن تعذّر التوقيع اختر «التوقيع في الفرع» من صفحة التوقيع.</p>
    </div>`;
    box.querySelector('[data-sign]').onclick = e => borrowerSign(sb, app, e.target);
    return;
  }
  const late = app.stage === 25 && ['active', 'returned'].includes(app.status);
  const msg = {
    completed: `<span class="ok-ic sm">✓</span> وقّعت عقد التمويل والكمبيالة إلكترونياً — نسخة العقد الموقّع محفوظة في ملفك.${app.stage === 25 ? ' <b>لا شيء مطلوب منك الآن</b> — يدقق الفرع العقد ثم يكمل المصرف التمويل.' : ''}`,
    expired: 'انتهت صلاحية رابط التوقيع قبل التوقيع.',
    cancelled: 'أُلغي طلب التوقيع الإلكتروني السابق.',
    manual_review: 'اخترت توقيع العقد حضورياً — راجع فرعك مع بطاقتك الوطنية الموحدة.',
    failed: 'تعذّر إتمام التوقيع الإلكتروني.',
  }[s];
  const acts = late && s !== 'completed' ? `<div class="row mt" style="flex-wrap:wrap;gap:8px">
      <button class="btn ${s === 'manual_review' ? 'ghost' : 'cyan'} sm" data-ask="link">${s === 'manual_review' ? 'أريد التوقيع من هاتفي' : 'اطلب رابط توقيع جديد'}</button>
      ${s === 'manual_review' ? '' : '<button class="btn ghost sm" data-ask="branch">سأوقّع في الفرع</button>'}</div>` : '';
  box.innerHTML = `<div class="card mb"><h3>توقيع العقد<span class="sp"></span>${badge(ESIGN_STATUS[s] || [s, ''])}</h3><p style="margin:0">${msg || ''}</p>
    ${s === 'completed' ? `<div class="row mt"><button class="btn sm" data-signed>عرض العقد الموقّع (PDF)</button><span class="small muted">وُقّع ${dt(q.completed_at)}</span></div>${certLine(q)}` : ''}${acts}</div>`;
  const b = box.querySelector('[data-signed]'); if (b) b.onclick = () => viewDoc(sb, q.signed_doc);
  box.querySelectorAll('[data-ask]').forEach(x => x.onclick = () => borrowerAsk(sb, app, x.dataset.ask, x, opts));
}
