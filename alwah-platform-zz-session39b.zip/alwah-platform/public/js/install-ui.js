// الجلسة 17: توثيق التركيب في المرحلة 31 — يثبّت فني المورد موقع التركيب بالـGPS ويصوّر الألواح والعاكس وفيديو التشغيل في الموقع نفسه
import { esc, badge, dt, rpc, toast, cleanErr, viewDoc, mapsLink, fmtM } from './core.js';
import { cameraCapture } from './capture.js';
import { getGps, gpsDialog, recordVideo } from './geo.js';

const PROOFS = [
  ['install_panels', 'صورة الألواح المركّبة', 'صوّر الألواح كاملة على السطح أو الهيكل'],
  ['install_inverter', 'صورة العاكس والبطاريات', 'صوّر العاكس (الإنفيرتر) والبطاريات ولوحة التوزيع'],
  ['install_video', 'فيديو تشغيل المنظومة', 'فيديو مباشر يظهر الألواح والعاكس وشاشة التشغيل وهي تعمل'],
];

export async function mountInstall(ctx, app, box) {
  const { sb, profile } = ctx;
  const S = Object.fromEntries(Object.entries(ctx.settings || {}));
  const accMax = Number(S.install_gps_accuracy_m || 50), maxDist = Number(S.install_max_distance_m || 300);
  const canCap = profile?.portal === 'supplier' && ['supplier_admin', 'supplier_tech'].includes(profile.role) && app.supplier_id === profile.org_id && app.stage === 31 && app.status === 'active';

  const load = async () => {
    const [a, d] = await Promise.all([
      sb.from('applications').select('id,stage,status,site_geo,install_geo').eq('id', app.id).maybeSingle().then(r => r.data || app),
      sb.from('app_documents').select('id,kind,meta,created_at,uploaded_by_title').eq('application_id', app.id).in('kind', PROOFS.map(p => p[0])).then(r => r.data || []),
    ]);
    Object.assign(app, a);
    return d;
  };

  const paint = docs => {
    const ig = app.install_geo, sg = app.site_geo;
    const got = k => docs.filter(x => x.kind === k).slice(-1)[0];
    const ready = ig && PROOFS.every(([k]) => got(k));
    box.innerHTML = `<div class="card mb inst"><h3>توثيق التركيب في الموقع <span class="sp"></span>${ready ? badge(['مكتمل — يُعتمد المحضر', 'ok']) : badge(['غير مكتمل', 'warn'])}</h3>
      <dl class="kv">
        <dt>عنوان المنظومة (المقترض)</dt><dd>${sg ? `📍 <a href="${mapsLink(sg)}" target="_blank" rel="noopener">فتح على الخريطة — للوصول إلى الموقع</a> · دقة ±<span class="num">${Math.round(sg.acc)}</span> م${sg.address ? `<div class="small muted">${esc(sg.address)}</div>` : ''}` : '<span class="muted">طلب قديم بلا عنوان GPS — يُعتمد موقع التركيب الذي يثبّته الفني</span>'}</dd>
        <dt>موقع التركيب (الفني)</dt><dd>${ig ? `📍 <a href="${mapsLink(ig)}" target="_blank" rel="noopener">على الخريطة</a> · دقة ±<span class="num">${Math.round(ig.acc)}</span> م
          ${ig.dist_m != null ? ` · يبعد ${fmtM(ig.dist_m)} عن عنوان المقترض ${Number(ig.dist_m) <= maxDist ? badge(['مطابق', 'ok']) : badge(['بعيد', 'bad'])}` : ''}
          <div class="small muted">${esc(ig.by || '')} <span class="num">${esc(ig.by_code || '')}</span> · ${dt(ig.at)}</div>` : badge(['لم يُثبَّت بعد', 'warn'])}</dd>
      </dl>
      <div class="inst-grid">${PROOFS.map(([k, l]) => { const d = got(k);
        return `<div class="inst-item ${d ? 'ok' : ''}"><b>${d ? '✓' : '★'} ${esc(l)}</b>
          ${d ? `<div class="small muted">${dt(d.created_at)}${d.meta?.dist_m != null ? ` · على بعد ${fmtM(d.meta.dist_m)} من موقع التركيب` : ''}${d.meta?.duration ? ` · <span class="num">${d.meta.duration}</span> ث` : ''}</div>
            <button type="button" class="linkbtn" data-view="${d.id}">عرض</button>` : '<div class="small muted">مطلوب قبل اعتماد المحضر</div>'}
          ${canCap && ig ? `<button type="button" class="btn ${d ? 'ghost' : 'cyan'} sm" data-cap="${k}">${d ? 'إعادة التصوير' : 'تصوير الآن'}</button>` : ''}</div>`; }).join('')}</div>
      ${canCap ? `<div class="row mt" style="flex-wrap:wrap;gap:8px"><button type="button" class="btn ${ig ? 'ghost' : 'cyan'}" data-gps>📍 ${ig ? 'إعادة تثبيت موقع التركيب' : 'تثبيت موقع التركيب بالـGPS'}</button>
        <span class="small muted" style="flex:1 1 260px">ابدأ بتثبيت الموقع وأنت عند المنظومة (دقة ±${accMax} م أو أفضل، وعلى بعد ${maxDist} م أو أقل من عنوان المقترض)، ثم صوّر الصورتين والفيديو في الموقع نفسه. كل صورة وفيديو يُختمان بالموقع والوقت والرمز الوظيفي، ولا تُقبل ملفات من المعرض.</span></div>`
      : app.stage === 31 ? '<p class="small muted" style="margin:8px 0 0">يوثّق فني المورد التركيب في الموقع، ثم يعتمد مدير حساب المورد المحضر. لا يُعتمد قبل اكتمال التوثيق.</p>' : ''}
    </div>`;
    box.querySelectorAll('[data-view]').forEach(b => b.onclick = () => viewDoc(sb, b.dataset.view));
    const gb = box.querySelector('[data-gps]');
    if (gb) gb.onclick = async () => {
      const g = await gpsDialog({ title: 'تثبيت موقع التركيب', hint: `قف عند المنظومة المركّبة (على السطح أو بجانب الألواح). الدقة المطلوبة ±${accMax} م.`, want: Math.min(20, accMax), accMax });
      if (!g) return;
      gb.disabled = true;
      try { const r = await rpc(sb, 'install_proof', { p_app: app.id, p_kind: 'install_gps', p_data: null, p_meta: { gps: g } }); toast(r.dist_m != null ? `ثُبّت موقع التركيب — يبعد ${Math.round(r.dist_m)} م عن عنوان المقترض` : 'ثُبّت موقع التركيب', 'ok'); }
      catch (e) { toast(cleanErr(e), 'bad'); }
      paint(await load());
    };
    box.querySelectorAll('[data-cap]').forEach(b => b.onclick = () => capture(b.dataset.cap, b));
  };

  async function capture(kind, btn) {
    const [, label, hint] = PROOFS.find(p => p[0] === kind);
    // الموقع يُقرأ لحظة الالتقاط ويُرسل مع الدليل ليتحقق منه الخادم
    const gpsP = getGps({ want: Math.min(20, accMax), maxMs: 15000 }).catch(e => e);
    let file;
    if (kind === 'install_video') {
      const v = await recordVideo({ title: label, hint, minSec: Number(S.install_video_min_s || 5) });
      if (!v) return;
      file = { data: v.data, meta: { live: true, duration: v.duration, mime: v.mime, captured_at: new Date().toISOString(), ua: navigator.userAgent.slice(0, 160) } };
    } else {
      const c = await cameraCapture({ title: label, hint, ratio: 0.75 });
      if (!c) return;
      if (!c.meta?.live) return toast('يُلتقط التوثيق بالكاميرا مباشرة', 'bad');
      file = c;
    }
    const g = await gpsP;
    if (g instanceof Error) return toast(g.message, 'bad');
    btn.disabled = true; btn.textContent = 'جارِ الرفع…';
    try { const r = await rpc(sb, 'install_proof', { p_app: app.id, p_kind: kind, p_data: file.data, p_meta: { ...file.meta, gps: g } }); toast(`وُثّق: ${label} — على بعد ${Math.round(r.dist_m)} م من موقع التركيب`, 'ok'); }
    catch (e) { toast(cleanErr(e), 'bad'); }
    paint(await load());
  }

  box.innerHTML = '<div class="card mb"><div class="spin"></div></div>';
  paint(await load());
}
