// الجلسة 31: تأييد وزارة التجارة لرواتب الكفلاء، وإعادة الطلب للمقترض لاستبدال الضمان، ورهن الذهب
// أدوات مشتركة بين بوابة المصرف وبوابة المقترض
import { esc, iqd, num, badge, dt, rpc, toast, cleanErr, modal, ECHK_STATUS, MOT_DEPTS, GUARANTEE } from './core.js';

export const isSalaryG = t => ['single_salary', 'multi_salary'].includes(t);
export async function loadGuarantee(sb, app) {
  try { return await rpc(sb, 'guarantee_status', { p_app: app.id }); } catch { return null; }
}
// طلبات الوزارة الخاصة بالكفلاء الحاليين فقط (الأحدث لكل هاتف)
export function currentChecks(app, gs) {
  const gl = app.guarantee?.guarantors || [];
  return gl.map((g, i) => ({ i, g, ck: (gs?.checks || []).filter(c => c.phone === g.phone).slice(-1)[0] || null }));
}
export const ministryRejected = (app, gs) => currentChecks(app, gs).filter(x => x.ck?.status === 'rejected');

// ───────── بوابة المصرف ─────────
export function bankGuaranteeCard(a, gs, { can, srefRejected = false } = {}) {
  if (!gs) return '';
  if (a.guarantee_type === 'gold') {
    const g = a.guarantee || {}, cu = g.custody;
    return `<div class="card mb"><h3>رهن ذهب ${cu ? badge(['استُلم في الفرع ووُزن وقُيِّم', 'ok']) : badge(['بانتظار استلام الذهب في الفرع', 'warn'])}</h3>
      <dl class="kv"><dt>ما صرّح به المقترض</dt><dd><span class="num">${num(g.grams)}</span> غرام عيار <span class="num">${esc(g.karat)}</span>${g.items ? ` — ${esc(g.items)}` : ''}</dd>
        <dt>القيمة التقديرية</dt><dd>${iqd(g.value)} <span class="muted small">(غرام عيار 21 = ${iqd(g.gram_price)} · التمويل = <span class="num">${g.ltv}%</span> من القيمة)</span></dd>
        ${cu ? `<dt>وصل الاستلام</dt><dd class="num">${esc(cu.receipt_no)}</dd><dt>الوزن الفعلي</dt><dd><span class="num">${num(cu.grams)}</span> غرام عيار <span class="num">${esc(cu.karat)}</span></dd>
          <dt>القيمة المقيَّمة</dt><dd>${iqd(cu.value)}</dd><dt>الاستلام</dt><dd>${esc(cu.by || '')} · <span class="num">${esc(cu.by_code || '')}</span> · ${dt(cu.at)}</dd>` : ''}</dl>
      ${can && !cu ? '<button type="button" class="btn cyan mt" data-gold>تسجيل استلام الذهب ووزنه وتقييمه</button>' : ''}
      <p class="small muted" style="margin:8px 0 0">يُسلّم المقترض الذهب للفرع فيُوزن ويُقيَّم بوصل. لا يُنجز الضمان الأولي (9) ولا النهائي (19) قبل تسجيل الاستلام.</p>
      ${can ? '<div class="row mt"><span class="sp"></span><button type="button" class="linkbtn" data-gret>إعادة الطلب للمقترض لاستبدال الضمان</button></div>' : ''}</div>`;
  }
  if (!isSalaryG(a.guarantee_type)) return '';
  const rows = currentChecks(a, gs);
  if (!rows.length) return '';
  const rej = rows.filter(x => x.ck?.status === 'rejected');
  return `<div class="card mb"><h3>جهة عمل الكفلاء — تأييد الراتب ${rej.length ? badge(['رفضت الوزارة كفيلاً', 'bad']) : ''}</h3>
    ${rows.map(({ i, g, ck }) => `<div class="echk"><div><b>الكفيل ${i + 1}: ${esc(g.name)}</b><div class="small muted">${esc(g.ministry === 'trade' ? `وزارة التجارة — ${g.dept || ''}` : g.employer || '—')}${ck ? ` · <span class="num">${esc(ck.code)}</span>` : ''}${ck?.wf_label ? ` · ${esc(ck.wf_label)}` : ''}</div>
      ${ck?.status === 'rejected' ? `<div class="small" style="color:var(--bad)">${(ck.reasons || []).map(x => `★ ${esc(x)}`).join('<br>')}${ck.note ? `<br>✎ ${esc(ck.note)}` : ''}</div>` : ''}</div>
      <span class="sp"></span>${ck ? badge(ECHK_STATUS[ck.status] || [ck.status, 'muted']) : g.ministry === 'trade' ? badge(['ستُرسل للوزارة عند وصول الطلب', 'muted']) : badge(['جهة أخرى — لا تأييد إلكتروني', 'muted'])}
      ${can && !ck && g.ministry !== 'trade' ? `<button type="button" class="linkbtn small" data-mot="${i}">موظف في وزارة التجارة؟ أرسل للتأييد</button>` : ''}</div>`).join('')}
    ${rej.length || srefRejected ? `<div class="notice warn mt"><span>⚠</span><span><b>الضمان الحالي لا يصلح.</b> أعد الطلب إلى المقترض بزر واحد — يصله السبب ويختار من هاتفه: كفيلاً آخر، أو رهن ذهب، أو رهن عقار. بعد إعادة الإرسال يرجع الطلب إلى مدير الفرع (المرحلة 8) ليوافق على الضمان الجديد.
      ${can ? '<div class="mt"><button type="button" class="btn warn" data-gret>إعادة الطلب للمقترض لاستبدال الضمان</button></div>' : ''}</span></div>`
      : `<p class="small muted" style="margin:8px 0 0">كفلاء وزارة التجارة تُرسل طلباتهم إلى الوزارة آلياً حين يصل الطلب للمصرف. لا يُنجز الضمان الأولي (9) قبل تأييد الوزارة لكل منهم.</p>
        ${can ? '<div class="row"><span class="sp"></span><button type="button" class="linkbtn small" data-gret>إعادة الطلب للمقترض لاستبدال الضمان</button></div>' : ''}`}</div>`;
}

export function bindBankGuarantee(ctx, a, gs, dr) {
  if (!dr) return;
  const { sb } = ctx;
  const done = msg => { document.querySelectorAll('.drawer,.drawer-bg').forEach(n => n.remove()); toast(msg, 'ok'); ctx.refresh(); };
  dr.querySelectorAll('[data-gret]').forEach(b => b.onclick = () => returnDialog(ctx, a, gs, done));
  dr.querySelectorAll('[data-mot]').forEach(b => b.onclick = () => {
    const i = Number(b.dataset.mot), g = a.guarantee?.guarantors?.[i] || {};
    const m = modal(`<h3>الكفيل ${esc(g.name || '')} موظف في وزارة التجارة</h3>
      <p class="small muted" style="margin-top:0">تُرسل إلى الوزارة آلياً «طلب تأييد راتب» تدقق فيه: هل راتبه حر (غير ضامن ولا عليه سلفة) ويغطي حصته من القسط.</p>
      <div class="field"><label>دائرته في الوزارة</label><input class="input" list="motdepts" data-dept placeholder="اختر أو اكتب"><datalist id="motdepts">${MOT_DEPTS.map(x => `<option value="${esc(x)}">`).join('')}</datalist></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>إرسال للوزارة</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try { const r = await rpc(sb, 'employer_check_send', { p_app: a.id, p_g: i, p_dept: m.el.querySelector('[data-dept]').value }); m.close(); done(`أُرسل طلب التأييد ${r?.code || ''} إلى وزارة التجارة`); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  });
  const gb = dr.querySelector('[data-gold]');
  if (gb) gb.onclick = () => {
    const g = a.guarantee || {};
    const m = modal(`<h3>استلام الذهب المرهون</h3>
      <p class="small muted" style="margin-top:0">صرّح المقترض بـ <b class="num">${num(g.grams)}</b> غرام عيار <b class="num">${esc(g.karat)}</b>. زِن الذهب وقيّمه، واكتب ما في الوصل.</p>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>رقم وصل الاستلام</label><input class="input" data-k="receipt_no" dir="ltr"></div>
        <div class="field"><label>الوزن الفعلي (غرام)</label><input class="input" data-k="grams" inputmode="decimal" dir="ltr" value="${esc(g.grams || '')}"></div>
        <div class="field"><label>العيار</label><select class="input" data-k="karat">${[21, 18, 22, 24].map(k => `<option ${Number(g.karat) === k ? 'selected' : ''}>${k}</option>`).join('')}</select></div>
        <div class="field"><label>القيمة المقيَّمة (د.ع)</label><input class="input" data-k="value" inputmode="numeric" dir="ltr"></div>
      </div>
      <div class="field"><label>ملاحظة (القطع وحالتها)</label><textarea class="input" rows="2" data-k="note"></textarea></div>
      <p class="small muted">مبلغ التمويل ${iqd(a.amount)} — يلزم أن تكون القيمة المقيَّمة <b>${iqd(Math.ceil(a.amount * 100 / (gs?.gold_ltv || 80)))}</b> على الأقل.</p>
      <div class="row mt"><span class="sp"></span><button class="btn ok" data-go>تسجيل الاستلام</button></div>`, { wide: true });
    m.el.querySelector('[data-go]').onclick = async e => {
      const p = {}; m.el.querySelectorAll('[data-k]').forEach(x => p[x.dataset.k] = x.value.trim());
      e.target.disabled = true;
      try { await rpc(sb, 'gold_custody', { p_app: a.id, p }); m.close(); done('سُجّل استلام الذهب — يمكن إنجاز الضمان الآن'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

export function returnDialog(ctx, a, gs, done) {
  const rej = ministryRejected(a, gs);
  const m = modal(`<h3>إعادة الطلب للمقترض لاستبدال الضمان</h3>
    <p class="small muted" style="margin-top:0">يصل المقترضَ إشعار ورسالة بالسبب، ويفتح طلبه فيجد زراً واحداً يأخذه إلى خطوة الضمان ليختار: كفيلاً آخر، أو رهن ذهب، أو رهن عقار. يبقى رقم الطلب وبياناته، ويرجع بعد إعادة الإرسال إلى <b>${a.stage >= 8 ? 'الموافقة المبدئية (8) ليوافق مدير الفرع على الضمان الجديد' : `المرحلة ${a.stage}`}</b> — دون إعادة الاستقبال وفتح الحساب.</p>
    ${rej.length ? `<div class="notice warn"><span>★</span><span>${rej.map(x => `رفضت وزارة التجارة كفالة <b>${esc(x.g.name)}</b>: ${esc((x.ck.reasons || []).join('، '))}`).join('<br>')}<div class="small">يُرسل هذا السبب للمقترض كما هو.</div></span></div>` : ''}
    <div class="field"><label>${rej.length ? 'ملاحظة إضافية للمقترض (اختيارية)' : 'اكتب للمقترض سبب استبدال الضمان'}</label><textarea class="input" rows="3" data-n placeholder="مثل: راتب الكفيل لا يغطي القسط — قدّم كفيلاً براتب أعلى أو رهن ذهب"></textarea></div>
    <div class="row mt"><span class="sp"></span><button class="btn warn" data-go>إعادة الطلب للمقترض</button></div>`);
  m.el.querySelector('[data-go]').onclick = async e => {
    e.target.disabled = true;
    try { await rpc(ctx.sb, 'guarantee_return', { p_app: a.id, p_note: m.el.querySelector('[data-n]').value }); m.close(); done('أُعيد الطلب للمقترض — يختار كفيلاً آخر أو ذهباً أو عقاراً من هاتفه'); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── بوابة المقترض ─────────
// أنواع الضمان المتاحة حسب مبلغ التمويل (الأقوى مسموح دائماً)
export function guaranteeOptions(base) {
  const all = [
    ['salary', '👤', 'كفيل موظف', base === 'multi_salary' ? 'كفيلان موظفان أو أكثر براتب يغطي القسط' : 'موظف براتب حر يغطي القسط'],
    ['gold', '💍', 'رهن ذهب', 'تسلّمه للفرع فيُوزن ويُقيَّم بوصل'],
    ['mortgage', '🏠', 'رهن عقار', 'سند عقار باسمك أو بوكالة من مالكه'],
  ];
  return base === 'mortgage' ? all.filter(x => x[0] !== 'salary') : all;
}
export const kindOf = t => isSalaryG(t) ? 'salary' : t;
export const G_TXT = GUARANTEE;
