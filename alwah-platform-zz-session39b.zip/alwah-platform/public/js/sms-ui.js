// الجلسة 23: الرسائل النصية — شريط تفعيل الإشعارات للمقترض، ولوحة الرسائل لمشغّل النظام
import { esc, rpc, toast, cleanErr, askOtp, maskPhone, dt, badge } from './core.js';

// يظهر للمقترض مرة واحدة إن كانت الرسائل مربوطة ولم يتحقق رقمه برمز حقيقي بعد
let ST = null;
export async function mountSmsBanner(sb, profile, root) {
  try {
    if (!window.ALWAH_DEV?.sms || !root) return;
    ST = ST || await rpc(sb, 'my_sms_status');
    if (!ST.live || !ST.notify || ST.verified) return;
    const anchor = root.querySelector('.now-card') || root.querySelector('.page-head');
    if (!anchor || root.querySelector('.sms-ban')) return;
    const box = document.createElement('div');
    box.className = 'card mb sms-ban';
    box.innerHTML = `<div class="sms-ban-ic">✉</div><div class="sms-ban-t"><b>فعّل الرسائل النصية</b>
      <p class="small muted">نرسل إلى <bdi dir="ltr" class="num">${esc(maskPhone(profile.phone))}</bdi> رسالة كلما طلب منك المصرف شيئاً، ولا ترسل ليلاً.</p></div>
      <button type="button" class="btn cyan" data-on>فعّلها</button>`;
    anchor.after(box);
    box.querySelector('[data-on]').onclick = async () => {
      const t = await askOtp({ kind: 'verify', title: 'تفعيل الرسائل النصية', phone: profile.phone, purpose: 'اكتب الرمز الذي وصلك لنتأكد أن الرسائل تصل إلى هاتفك' });
      if (!t) return;
      ST = await rpc(sb, 'my_sms_status').catch(() => ({ verified: true }));
      if (ST.verified) { box.remove(); toast('فُعّلت الرسائل النصية — تصلك كل المطلوبات على هاتفك', 'ok'); }
      else toast('فُعّل الرمز في وضع المطور فقط — جرّب برمز وصل برسالة', 'bad');
    };
  } catch { /* لا شيء — الشريط اختياري */ }
}

// ───────── لوحة مشغّل النظام: حالة الخدمة وآخر الرسائل ─────────
const KIND = { otp: 'رمز تحقق', notice: 'إشعار مقترض', link: 'رابط كفيل', test: 'تجربة' };
const STAT = { queued: ['بالانتظار', 'warn'], sending: ['قيد الإرسال', 'warn'], sent: ['أُرسلت', 'ok'], failed: ['فشلت', 'bad'], expired: ['انتهت', 'muted'], skipped: ['لم تُرسل', 'muted'] };
const PROV = { smsgate: 'هاتف أندرويد بشريحة عراقية (SMS Gateway)', otpiq: 'OTPIQ', twilio: 'Twilio', infobip: 'Infobip', webhook: 'بوابة خاصة (Webhook)' };

export async function adminSmsPanel(sb, box) {
  let D;
  try { D = await rpc(sb, 'admin_sms_status'); } catch (e) { box.innerHTML = `<div class="card mb"><h3>الرسائل النصية</h3><p class="muted">${esc(cleanErr(e))}</p></div>`; return; }
  const t = D.today || {};
  box.innerHTML = `<div class="card mb sms-adm">
    <h3>الرسائل النصية (SMS)<span class="sp"></span>${D.live ? badge(['مربوطة', 'ok']) : badge(['غير مربوطة', 'bad'])}</h3>
    ${D.live ? `<p class="small">المزوّد: <b>${esc(PROV[D.provider] || D.provider)}</b> · آخر اتصال للخادم ${esc(dt(D.seen_at))}</p>`
      : `<p class="small muted">لم يُضبط مزوّد رسائل في Render بعد. أضِف متغيرات المزوّد (انظر «دليل الخدمات» — الرسائل النصية) ثم أعد النشر. حتى ذلك الحين يعمل وضع المطور (1234) فقط.</p>`}
    ${D.last_error ? `<p class="small err-line">آخر خطأ (${esc(dt(D.last_error_at))}): ${esc(D.last_error)}</p>` : ''}
    <div class="sms-stats">
      <div><b class="num">${t.sent || 0}</b><small>أُرسلت اليوم</small></div>
      <div><b class="num">${(t.queued || 0) + (t.sending || 0)}</b><small>بالانتظار</small></div>
      <div><b class="num">${t.failed || 0}</b><small>فشلت</small></div>
      <div><b class="num">${t.skipped || 0}</b><small>لم تُرسل</small></div>
      <div><b class="num">${D.verified_phones}</b><small>رقم متحقق</small></div>
    </div>
    <div class="grid g2 mt">
      <div class="field"><label>إشعار المقترضين بكل ما يُطلب منهم</label>
        <div class="row">${D.notify ? badge(['مفعّل', 'ok']) : badge(['متوقف', 'warn'])}<span class="sp"></span><button class="btn sm ghost" data-notify="${D.notify ? 0 : 1}">${D.notify ? 'إيقاف' : 'تشغيل'}</button></div></div>
      <div class="field"><label>الحد الأعلى للرسائل في اليوم</label>
        <div class="row"><input data-cap inputmode="numeric" value="${esc(D.cap)}" style="max-width:120px"><button class="btn sm ghost" data-capsave>حفظ</button></div></div>
    </div>
    <div class="field mt"><label>رسالة تجربة</label>
      <div class="row"><input data-tp inputmode="tel" placeholder="07XXXXXXXXX" style="max-width:180px"><button class="btn sm cyan" data-test ${D.live ? '' : 'disabled'}>أرسل</button></div></div>
    ${D.dev_mode && D.live ? '<p class="small warn-line">الرسائل الحقيقية تعمل، والرمز الثابت 1234 ما زال مقبولاً. بعد التأكد من وصول الرسائل أطفئ «وضع المطور» أعلاه.</p>' : ''}
    <details class="mt"><summary class="small">آخر الرسائل (<span class="num">${D.items.length}</span>)</summary>
      <div class="tbl-wrap"><table class="tbl small"><thead><tr><th>الوقت</th><th>الرقم</th><th>النوع</th><th>الحالة</th><th>النص</th></tr></thead><tbody>
      ${D.items.map(i => `<tr><td class="num">${esc(dt(i.at))}</td><td class="num" dir="ltr">${esc(i.phone)}</td><td>${esc(KIND[i.kind] || i.kind)}</td>
        <td>${badge(STAT[i.status] || [i.status, 'muted'])}${i.error ? `<br><small class="muted">${esc(i.error)}</small>` : ''}</td><td>${esc(i.body)}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">لا رسائل بعد</td></tr>'}
      </tbody></table></div></details>
  </div>`;
  const q = s => box.querySelector(s);
  const set = async (k, v) => { try { await rpc(sb, 'admin_set_setting', { p_key: k, p_value: v }); toast('حُفظ', 'ok'); adminSmsPanel(sb, box); } catch (e) { toast(cleanErr(e), 'bad'); } };
  q('[data-notify]').onclick = e => set('sms_notify', Number(e.target.dataset.notify));
  q('[data-capsave]').onclick = () => set('sms_daily_cap', Number(q('[data-cap]').value.replace(/\D/g, '')) || 0);
  q('[data-test]').onclick = async () => {
    try { await rpc(sb, 'admin_sms_test', { p_phone: q('[data-tp]').value }); toast('أُضيفت رسالة التجربة — تصل خلال ثوانٍ', 'ok'); setTimeout(() => adminSmsPanel(sb, box), 4000); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}
