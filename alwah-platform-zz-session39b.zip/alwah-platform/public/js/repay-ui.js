// الجلسة 18: الصرف للمورد واستقطاع عمولة المنصة، جدول الأقساط ومتابعة التحصيل، والاطلاع الرقابي
import { esc, iqd, num, kpi, badge, dt, rpc, toast, cleanErr, modal } from './core.js';

const day = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { dateStyle: 'medium' }) : '—';
const instBadge = r => r.paid_at ? badge([r.late > 0 ? `مسدَّد متأخراً ${r.late} يوماً` : 'مسدَّد', r.late > 0 ? 'warn' : 'ok'])
  : r.late > 0 ? badge([`متأخر ${r.late} يوماً`, 'bad']) : badge(['مستحق لاحقاً', 'muted']);

function disbCard(info, who) {
  const d = info.disbursement, p = info.preview;
  if (!d && !p) return '';
  const x = d || p;
  return `<div class="card mb"><h3>${d ? 'قيد الصرف للمورد' : 'الصرف للمورد (عند المرحلة 35)'}<span class="sp"></span>${d ? badge(['صُرف', 'ok']) : badge(['تقديري', 'muted'])}</h3>
    <dl class="kv"><dt>مبلغ التمويل</dt><dd>${iqd(x.gross)}</dd>
    <dt>عمولة المنصة (<span class="num">${num(x.pct)}</span>%)</dt><dd>− ${iqd(x.commission)}</dd>
    <dt><b>الصافي للمورد</b></dt><dd><b>${iqd(x.net)}</b></dd>
    ${d ? `<dt>الصرف</dt><dd>${dt(d.at)} — ${esc(d.by || '')}${d.code ? ` <span class="num small">${esc(d.code)}</span>` : ''}</dd>` : ''}</dl>
    <p class="small muted" style="margin:8px 0 0">${d ? 'تُستقطع عمولة المنصة آلياً عند الصرف بالنسبة المتفق عليها مع المورد، ويُبلَّغ المورد بالصافي.'
      : 'يُسجَّل القيد آلياً حين يُنجز أمين الصندوق المرحلة 35، وتُستقطع عمولة المنصة بالنسبة المتفق عليها مع المورد.'}</p></div>`;
}

function scheduleCard(info, opts = {}) {
  const s = info.summary, rows = info.schedule || [];
  if (!rows.length) return '';
  const nx = s.next;
  return `<div class="card mb"><h3>${opts.borrower ? 'جدول أقساطي' : 'جدول الأقساط والتحصيل'}<span class="sp"></span>${s.overdue ? badge([`${s.overdue} قسط متأخر`, 'bad']) : s.paid === s.count ? badge(['مسدَّد بالكامل', 'ok']) : badge(['منتظم', 'ok'])}</h3>
    <div class="grid g4 mb">
      ${kpi('المسدَّد', `<span class="num">${s.paid}</span> من <span class="num">${s.count}</span>`, iqd(s.paid_amt))}
      ${kpi('المتبقي', iqd(s.remaining))}
      ${kpi('المتأخر', iqd(s.overdue_amt), s.max_late ? `أقدمه منذ <span class="num">${s.max_late}</span> يوماً` : 'لا متأخرات')}
      ${kpi('القسط التالي', nx ? iqd(nx.amount) : '—', nx ? `رقم <span class="num">${nx.n}</span> · ${day(nx.due)}` : '')}
    </div>
    ${s.max_late > s.npl_days ? `<div class="notice bad mb">⚠ تجاوز التأخر <b class="num">${s.npl_days}</b> يوماً — يُعدّ التمويل متعثراً ويُتابَع مع الكفيل أو التأمين حسب الضمان.</div>` : ''}
    ${info.can_collect && nx ? `<div class="row mb"><button class="btn cyan" data-collect="${nx.n}">تسجيل استيفاء القسط ${nx.n}</button><span class="small muted">بالترتيب وبرقم الإيصال أو القيد</span></div>` : ''}
    <details${opts.open ? ' open' : ''}><summary class="small">الجدول الكامل (<span class="num">${rows.length}</span> قسطاً)</summary>
      <div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>#</th><th>الاستحقاق</th><th>القسط</th><th>الأصل</th><th>العائد</th><th>الرصيد بعده</th><th>الحالة</th></tr></thead><tbody>
      ${rows.map(r => `<tr><td class="num">${r.n}</td><td>${day(r.due)}</td><td>${iqd(r.amount)}</td><td>${iqd(r.principal)}</td><td>${iqd(r.profit)}</td><td>${iqd(r.balance)}</td>
        <td>${instBadge(r)}${r.paid_at ? `<div class="small muted">${day(r.paid_at)}${r.ref ? ` · <span class="num" dir="ltr">${esc(r.ref)}</span>` : ''}</div>` : ''}</td></tr>`).join('')}
      </tbody></table></div></details>
    ${opts.borrower ? '<p class="small muted" style="margin:8px 0 0">يُستقطع القسط شهرياً من حسابك أو راتبك حسب العقد. لأي استفسار راجع فرع المصرف.</p>' : ''}</div>`;
}

// درج الطلب (الموظفون) وصفحة المقترض
export async function mountRepay(ctx, app, box, opts = {}) {
  if (!box) return;
  const sb = ctx.sb || ctx;
  let info;
  try { info = await rpc(sb, 'repay_info', { p_app: app.id }); } catch { box.innerHTML = ''; return; }
  box.innerHTML = (opts.borrower ? '' : disbCard(info)) + scheduleCard(info, opts);
  const b = box.querySelector('[data-collect]');
  if (b) b.onclick = () => {
    const n = Number(b.dataset.collect), row = info.schedule.find(r => r.n === n);
    const m = modal(`<h3>استيفاء القسط ${n} — ${esc(app.code)}</h3>
      <dl class="kv"><dt>المبلغ</dt><dd>${iqd(row.amount)}</dd><dt>الاستحقاق</dt><dd>${day(row.due)}</dd></dl>
      <div class="field mt"><label>رقم الإيصال أو القيد</label><input class="input" data-ref dir="ltr" placeholder="مثل RC-2026-000123"></div>
      <div class="row mt"><button class="btn cyan" data-ok>تسجيل الاستيفاء</button></div>`);
    m.el.querySelector('[data-ok]').onclick = async e => {
      e.target.disabled = true;
      try {
        const r = await rpc(sb, 'installment_collect', { p_app: app.id, p_n: n, p_ref: m.el.querySelector('[data-ref]').value.trim() });
        m.close(); toast(`سُجّل استيفاء القسط ${r.n}${r.late ? ` (متأخر ${r.late} يوماً)` : ''}`, 'ok');
        mountRepay(ctx, app, box, opts);
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

// المصرف: دفتر التحصيل والمتأخرات
export async function collectionView(ctx, body, onOpen, apps) {
  body.innerHTML = '<div class="card"><div class="empty">جارِ التحميل…</div></div>';
  let rows;
  try { rows = await rpc(ctx.sb, 'collection_book'); } catch (e) { body.innerHTML = `<div class="notice bad">${esc(cleanErr(e))}</div>`; return; }
  const late = rows.filter(r => r.overdue > 0);
  body.innerHTML = `<div class="grid g4 mb">
      ${kpi('تمويلات قيد السداد', `<span class="num">${rows.length}</span>`)}
      ${kpi('المتبقي للتحصيل', iqd(rows.reduce((s, r) => s + Number(r.remaining), 0)))}
      ${kpi('تمويلات متأخرة', `<span class="num">${late.length}</span>`, iqd(late.reduce((s, r) => s + Number(r.overdue_amt), 0)))}
      ${kpi('أقدم تأخر', `<span class="num">${Math.max(0, ...rows.map(r => r.max_late))}</span> يوماً`)}
    </div>
    <div class="card flush"><h3>دفتر التحصيل<span class="sp"></span><span class="small muted">يُصدر الجدول آلياً عند إنجاز المرحلة 33 — افتح الطلب لتسجيل الاستيفاء</span></h3>
    ${rows.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المقترض</th><th>القسط</th><th>المسدَّد</th><th>القسط التالي</th><th>المتأخر</th><th>المتبقي</th></tr></thead><tbody>
      ${rows.map(r => `<tr data-open="${r.id}" style="cursor:pointer"><td><b class="num">${esc(r.code)}</b></td><td>${esc(r.name || '')}</td><td>${iqd(r.inst)}</td>
        <td class="num">${r.paid} / ${r.count}</td><td>${day(r.next_due)}</td>
        <td>${r.overdue ? `${badge([`${r.overdue} قسط · ${r.max_late} يوماً`, r.max_late > 90 ? 'bad' : 'warn'])}<div class="small">${iqd(r.overdue_amt)}</div>` : badge(['منتظم', 'ok'])}</td>
        <td>${iqd(r.remaining)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا تمويلات قيد السداد بعد.</div>'}</div>`;
  body.querySelectorAll('[data-open]').forEach(tr => tr.onclick = () => { const a = apps.find(x => x.id === tr.dataset.open); if (a) onOpen(a); });
}

// البنك المركزي وهيئة النزاهة: اطلاع رقابي فقط
export async function oversightRepayView(ctx, body) {
  body.innerHTML = '<div class="card"><div class="empty">جارِ التحميل…</div></div>';
  let d;
  try { d = await rpc(ctx.sb, 'oversight_repayments'); } catch (e) { body.innerHTML = `<div class="notice bad">${esc(cleanErr(e))}</div>`; return; }
  const B = d.banks || [], t = k => B.reduce((s, b) => s + Number(b[k] || 0), 0);
  const rate = t('due_amt') ? Math.round(t('collected_due') / t('due_amt') * 1000) / 10 : null;
  body.innerHTML = `<div class="notice dark mb">👁 اطلاع رقابي فقط — التحصيل والمتابعة من صلاحية المصرف المُقرض. البنك المركزي لا يتدخل إلا في الحالات التي تستدعي تدخله.</div>
    <div class="grid g4 mb">
      ${kpi('المصروف للموردين', iqd(d.disbursed?.gross || 0), `<span class="num">${d.disbursed?.count || 0}</span> تمويل`)}
      ${kpi('نسبة التحصيل من المستحق', rate == null ? '—' : `<span class="num">${rate}</span>%`, `محصَّل ${iqd(t('collected_due'))} من ${iqd(t('due_amt'))}`)}
      ${kpi('المتأخرات', iqd(t('overdue_amt')), `<span class="num">${t('overdue_loans')}</span> تمويل`)}
      ${kpi(`متعثر (+${d.npl_days} يوماً)`, `<span class="num">${t('npl_loans')}</span>`, `الرصيد القائم ${iqd(t('outstanding'))}`)}
    </div>
    <div class="card flush mb"><h3>السداد حسب المصرف</h3>${B.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>التمويلات</th><th>المستحق حتى اليوم</th><th>المحصَّل</th><th>المتأخر</th><th>متأخرة / متعثرة</th><th>الرصيد القائم</th></tr></thead><tbody>
      ${B.map(b => `<tr><td>${esc(b.name)}</td><td class="num">${b.loans}</td><td>${iqd(b.due_amt)}</td><td>${iqd(b.collected)}</td><td>${iqd(b.overdue_amt)}</td>
        <td class="num">${b.overdue_loans} / ${b.npl_loans}</td><td>${iqd(b.outstanding)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا تمويلات قيد السداد بعد.</div>'}</div>
    <div class="card flush"><h3>التمويلات المتأخرة<span class="sp"></span><span class="small muted">برقم الطلب فقط</span></h3>${(d.late || []).length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المصرف</th><th>المحافظة</th><th>أقساط متأخرة</th><th>المبلغ</th><th>أقدم تأخر</th></tr></thead><tbody>
      ${d.late.map(l => `<tr><td><b class="num">${esc(l.code)}</b></td><td>${esc(l.bank)}</td><td>${esc(l.governorate || '')}</td><td class="num">${l.overdue}</td><td>${iqd(l.overdue_amt)}</td>
        <td>${badge([`${l.max_late} يوماً`, l.max_late > d.npl_days ? 'bad' : 'warn'])}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">لا متأخرات.</div>'}</div>`;
}

// المورد: المبالغ المصروفة وعمولة المنصة
export async function supplierPayoutsView(ctx, body) {
  body.innerHTML = '<div class="card"><div class="empty">جارِ التحميل…</div></div>';
  let d;
  try { d = await rpc(ctx.sb, 'supplier_disbursements'); } catch (e) { body.innerHTML = `<div class="notice bad">${esc(cleanErr(e))}</div>`; return; }
  const it = d.items || [], s = k => it.reduce((t, x) => t + Number(x[k] || 0), 0);
  body.innerHTML = `<div class="grid g3 mb">
      ${kpi('المصروف لشركتك (صافي)', iqd(s('net')), `<span class="num">${it.length}</span> طلب`)}
      ${kpi('إجمالي التمويل', iqd(s('gross')))}
      ${kpi('عمولة المنصة', iqd(s('commission')), `النسبة المتفق عليها الآن <span class="num">${num(d.pct)}</span>%`)}
    </div>
    <div class="card flush"><h3>قيود الصرف</h3>${it.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المصرف</th><th>الإجمالي</th><th>العمولة</th><th>الصافي</th><th>التاريخ</th></tr></thead><tbody>
      ${it.map(x => `<tr><td><b class="num">${esc(x.code)}</b></td><td>${esc(x.bank || '')}</td><td>${iqd(x.gross)}</td><td>${iqd(x.commission)} <span class="small muted num">(${num(x.pct)}%)</span></td><td><b>${iqd(x.net)}</b></td><td class="small">${dt(x.at)}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">لم يُصرف لشركتك أي مبلغ بعد.</div>'}</div>`;
}

// مشغّل النظام: نسبة عمولة كل مورد وإيرادات المنصة
export async function adminRevenueView(ctx, body) {
  body.innerHTML = '<div class="card"><div class="empty">جارِ التحميل…</div></div>';
  let d;
  try { d = await rpc(ctx.sb, 'admin_revenue'); } catch (e) { body.innerHTML = `<div class="notice bad">${esc(cleanErr(e))}</div>`; return; }
  const S = d.suppliers || [], R = d.recent || [];
  body.innerHTML = `<div class="grid g3 mb">
      ${kpi('عمولات المنصة من الموردين', iqd(S.reduce((t, x) => t + Number(x.commission), 0)), `<span class="num">${S.reduce((t, x) => t + Number(x.count), 0)}</span> قيد صرف`)}
      ${kpi('إجمالي المصروف للموردين', iqd(S.reduce((t, x) => t + Number(x.gross), 0)))}
      ${kpi('النسبة الافتراضية', `<span class="num">${num(d.default_pct)}</span>%`, 'لمن لا اتفاق خاص معه')}
    </div>
    <div class="card flush mb"><h3>نسبة العمولة المتفق عليها مع كل مورد</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المورد</th><th>النسبة %</th><th>قيود الصرف</th><th>الإجمالي</th><th>العمولة</th><th></th></tr></thead><tbody>
      ${S.map(x => `<tr><td>${esc(x.name)}${x.custom ? '' : ' <span class="small muted">(افتراضي)</span>'}</td>
        <td><input class="input" style="max-width:90px" inputmode="decimal" data-pct="${x.id}" value="${num(x.pct)}"></td>
        <td class="num">${x.count}</td><td>${iqd(x.gross)}</td><td>${iqd(x.commission)}</td><td><button class="btn sm" data-save="${x.id}">حفظ</button></td></tr>`).join('')}
      </tbody></table></div><p class="small muted" style="padding:0 16px 12px;margin:0">تسري النسبة الجديدة على الصرف القادم فقط، ويُسجَّل التعديل في السجل الإداري.</p></div>
    <div class="card flush"><h3>آخر قيود الصرف</h3>${R.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الطلب</th><th>المورد</th><th>المصرف</th><th>الإجمالي</th><th>العمولة</th><th>الصافي</th><th>التاريخ</th></tr></thead><tbody>
      ${R.map(x => `<tr><td class="num">${esc(x.code)}</td><td>${esc(x.supplier)}</td><td>${esc(x.bank)}</td><td>${iqd(x.gross)}</td><td>${iqd(x.commission)} <span class="small muted num">(${num(x.pct)}%)</span></td><td>${iqd(x.net)}</td><td class="small">${dt(x.at)}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty">لا قيود صرف بعد.</div>'}</div>`;
  body.querySelectorAll('[data-save]').forEach(b => b.onclick = async () => {
    const v = Number(String(body.querySelector(`[data-pct="${b.dataset.save}"]`).value).replace(/[^\d.]/g, ''));
    b.disabled = true;
    try { await rpc(ctx.sb, 'admin_set_supplier_commission', { p_supplier: b.dataset.save, p_pct: v }); toast('حُفظت النسبة', 'ok'); adminRevenueView(ctx, body); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  });
}
