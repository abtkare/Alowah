// الجلسة 37: تقرير شركة التدقيق الهندسي داخل ملف الطلب — للمصرف والمورد والبنك المركزي والجهات الرقابية والمقترض
// + طلب «كشف رقابي بالعيّنة» (البنك المركزي)، و«إعادة الكشف بعد الإصلاح» (المورد ولجنة الكشف في المصرف)
import { esc, dt, badge, rpc, cleanErr, modal, mapsLink, fmtM, resultScreen, toast } from './core.js';

export const ENG_RESULT = { conforming: ['مطابق', 'ok'], conditional: ['مطابق بملاحظات', 'warn'], non_conforming: ['غير مطابق', 'bad'], pending: ['بانتظار الكشف', 'info'] };
export const ITEM_RES = { pass: ['مطابق', 'ok', '✓'], fail: ['غير مطابق', 'bad', '✗'], other: ['أخرى', 'warn', '…'] };

export async function engPhoto(sb, id) {
  try {
    const d = await rpc(sb, 'eng_photo', { p_doc: id });
    const g = d.meta?.gps;
    modal(`<div class="docview"><h3>صورة الفحص — البند ${esc(d.meta?.item || '')}: ${esc(d.meta?.label || '')}</h3>
      <img src="${esc(d.data)}" alt="" style="width:100%;border-radius:12px">
      <p class="small muted">${esc(d.meta?.by || '')} <span class="num">${esc(d.meta?.by_code || '')}</span> · ${dt(d.at)}${g ? ` · 📍 <a href="${mapsLink(g)}" target="_blank" rel="noopener">موقع الالتقاط</a>` : ''}
      <br>بصمة الملف <span class="num" dir="ltr">${esc((d.sha256 || '').slice(0, 24))}…</span></p></div>`, { wide: true });
  } catch (e) { toast(cleanErr(e), 'bad'); }
}

export async function mountEngReport(ctx, app, box) {
  const { sb } = ctx;
  let R;
  try { R = await rpc(sb, 'eng_app_report', { p_app: app.id }); } catch { return; }   // قبل تطبيق تحديث الجلسة 37
  if (!R) return;
  const list = R.list || [];
  if (!list.length && !R.can_sample) return;
  const cur = list[0];
  const head = cur ? (cur.status === 'done' ? badge(ENG_RESULT[cur.result] || ['—', 'muted']) : badge([cur.status_label, 'info'])) : badge(['لم يُفحص', 'muted']);
  box.innerHTML = `<div class="card mb eng-rep"><h3>🔍 التدقيق الهندسي المستقل <span class="sp"></span>${head}</h3>
    ${list.map((i, k) => insp(i, k === 0)).join('') || '<p class="small muted" style="margin:0">لم يُطلب كشف هندسي لهذا الطلب بعد.</p>'}
    ${R.can_reinspect ? `<div class="notice warn mt"><b>التقرير «غير مطابق».</b> بعد إصلاح البنود اطلب إعادة الكشف — يُسند أمر جديد للشركة نفسها.<div class="row mt"><button class="btn cyan sm" data-re>↻ طلب إعادة الكشف بعد الإصلاح</button></div></div>` : ''}
    ${R.can_sample ? '<div class="row mt"><span class="small muted" style="flex:1">يمكن للبنك المركزي طلب كشف مستقل على المشروع في موقعه في أي وقت.</span><button class="btn ghost sm" data-sample>🔍 طلب كشف رقابي بالعيّنة</button></div>' : ''}
  </div>`;
  box.querySelectorAll('[data-ph]').forEach(b => b.onclick = () => engPhoto(sb, b.dataset.ph));
  box.querySelectorAll('[data-more]').forEach(b => b.onclick = () => { b.closest('.eng-i').classList.toggle('open'); });
  const ask = (title, hint, fn, okLabel) => {
    const m = modal(`<h3>${esc(title)}</h3><p class="muted small">${esc(hint)}</p><div class="field"><textarea class="input" rows="3" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn cyan" data-y>${esc(okLabel)}</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-y]').onclick = async e => {
      const note = m.el.querySelector('[data-n]').value.trim();
      if (note.length < 5) return toast('اكتب السبب بوضوح', 'bad');
      e.target.disabled = true;
      try { const r = await fn(note); m.close(); await resultScreen({ ok: true, title: title.replace('طلب ', 'أُرسل طلب '), ref: r.code, msg: `أُسند الأمر إلى «${r.company}» ووصلها إشعار فوري.`, rows: [['الطلب', esc(app.code)], ['السبب', esc(note)]] }); mountEngReport(ctx, app, box); }
      catch (er) { resultScreen({ ok: false, title: 'لم يُرسل الطلب', msg: cleanErr(er), ref: app.code }); e.target.disabled = false; }
    };
  };
  const sm = box.querySelector('[data-sample]');
  if (sm) sm.onclick = () => ask('طلب كشف رقابي بالعيّنة', 'اكتب سبب الكشف — يصل لشركة التدقيق مع الأمر، ولا يوقف الطلب.', note => rpc(sb, 'eng_order_sample', { p_app: app.id, p_note: note }), 'إرسال للشركة');
  const re = box.querySelector('[data-re]');
  if (re) re.onclick = () => ask('طلب إعادة الكشف', 'اكتب ما أُصلح من البنود غير المطابقة.', note => rpc(sb, 'eng_reinspect', { p_app: app.id, p_note: note }), 'إرسال للشركة');
}

function insp(i, first) {
  const items = i.items || [];
  const v = i.visits || [];
  const prog = i.progress || {};
  return `<div class="eng-i ${first ? 'open' : ''}">
    <button type="button" class="eng-ih" data-more>
      <span><b class="num">${esc(i.code)}</b> · ${i.purpose === 'sample' ? 'كشف رقابي بالعيّنة' : `كشف الاستلام${i.round > 1 ? ` — الجولة <span class="num">${i.round}</span>` : ''}`}</span>
      <span class="sp"></span>${i.status === 'done' ? badge(ENG_RESULT[i.result]) : `<span class="small muted"><span class="num">${prog.checked || 0}/${prog.total || 0}</span> بند</span>`}<i class="chev">⌄</i></button>
    <div class="eng-ib">
      <dl class="kv sm">
        <dt>الشركة</dt><dd>${esc(i.company || '—')}</dd>
        <dt>الحالة</dt><dd>${esc(i.status_label)}${i.status !== 'done' && i.due_at ? ` · المهلة ${dt(i.due_at)}` : ''}</dd>
        ${i.ordered_by ? `<dt>طلبه</dt><dd>${esc(i.ordered_by)}${i.order_note ? `<div class="small muted">${esc(i.order_note)}</div>` : ''}</dd>` : ''}
        ${v.length ? `<dt>الزيارة</dt><dd>${v.map(x => `📍 <a href="${mapsLink(x)}" target="_blank" rel="noopener">${esc(x.name)}</a> <span class="small muted">· ${dt(x.at)} · دقة ±<span class="num">${Math.round(x.acc)}</span> م${x.dist_m != null ? ` · ${fmtM(x.dist_m)} عن ${x.ref === 'install' ? 'موقع التركيب' : x.ref === 'site' ? 'عنوان المقترض' : 'نقطة الزيارة الأولى'}` : ''}</span>`).join('<br>')}</dd>` : ''}
        ${i.decided_at ? `<dt>اعتمده</dt><dd>${esc(i.decided_by || '')} · ${dt(i.decided_at)}${i.note ? `<div class="small">${esc(i.note)}</div>` : ''}</dd>` : ''}
        ${i.seal ? `<dt>البصمة</dt><dd class="num small" dir="ltr" style="word-break:break-all">${esc(i.seal)}</dd>` : ''}
      </dl>
      ${items.length ? `<div class="eng-list">${items.map(x => { const r = ITEM_RES[x.result];
        return `<div class="eng-li ${x.result || 'wait'}"><span class="eng-dot">${r ? r[2] : '○'}</span><div><b>${x.n}. ${esc(x.label)}</b> <span class="small muted">${esc(x.detail || '')}</span>
          <div class="small">${esc(x.spec)}${x.by ? ` · ${esc(x.by)}` : ''}${x.other_kind ? ` · <b>${esc(x.other_kind)}</b>` : ''}</div>
          ${x.reason ? `<div class="small bad-t">✗ ${esc(x.reason)}</div>` : ''}${x.note ? `<div class="small muted">${esc(x.note)}</div>` : ''}
          ${x.photo_id ? `<button type="button" class="linkbtn small" data-ph="${x.photo_id}">📷 الصورة</button>` : ''}</div></div>`; }).join('')}</div>` : ''}
    </div></div>`;
}
