// الجلسة 37: أصوات المنصة — نغمة الإشعار، ونغمتا النجاح والفشل، والاهتزاز
// تُولَّد النغمات بالمتصفح نفسه (Web Audio) دون ملفات صوتية.
// آيفون وسفاري لا يسمحان بأي صوت قبل أول لمسة للشاشة: نفتح الصوت عند أول لمسة أو نقرة.

let AC = null;
const PREF = 'alwah-sound';

function ac() {
  if (AC) return AC;
  const C = window.AudioContext || window.webkitAudioContext;
  if (!C) return null;
  try { AC = new C(); } catch { AC = null; }
  return AC;
}

let unlocked = false;
export function unlockAudio() {
  const c = ac(); if (!c) return;
  try {
    if (c.state === 'suspended') c.resume();
    // مقطع صامت قصير — يفتح الصوت في آيفون
    const b = c.createBuffer(1, 1, 22050), s = c.createBufferSource();
    s.buffer = b; s.connect(c.destination); s.start(0);
    unlocked = true;
  } catch { /* لا شيء */ }
  if (unlocked) EVENTS.forEach(e => document.removeEventListener(e, unlockAudio, true));
}
const EVENTS = ['pointerdown', 'touchend', 'keydown', 'click'];
EVENTS.forEach(e => document.addEventListener(e, unlockAudio, { capture: true, passive: true }));

export const soundOn = () => { try { return localStorage.getItem(PREF) !== 'off'; } catch { return true; } };
export const setSound = on => { try { localStorage.setItem(PREF, on ? 'on' : 'off'); } catch { /* لا شيء */ } };
export const audioReady = () => unlocked && AC && AC.state === 'running';

// نغمة واحدة بغلاف ناعم: هجوم سريع ثم خفوت أسّي (صوت جرس لا صفير)
function note(c, t, freq, { dur = 0.5, vol = 0.18, type = 'sine', bell = true } = {}) {
  const g = c.createGain(); g.connect(c.destination);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, t); o.connect(g); o.start(t); o.stop(t + dur + 0.05);
  if (bell) {   // نغمة توافقية خفيفة تعطي لون الجرس
    const g2 = c.createGain(); g2.connect(c.destination);
    g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(vol * 0.28, t + 0.01); g2.gain.exponentialRampToValueAtTime(0.0001, t + dur * 0.55);
    const o2 = c.createOscillator(); o2.type = 'sine'; o2.frequency.setValueAtTime(freq * 2.76, t); o2.connect(g2); o2.start(t); o2.stop(t + dur);
  }
}

const PATTERNS = {
  notify:  [[0, 1046.5, 0.55], [0.13, 1318.5, 0.75]],                         // دو ← مي: «تنبيه» لطيف
  success: [[0, 784, 0.32], [0.1, 988, 0.32], [0.2, 1318.5, 0.7]],             // صعود مبهج
  fail:    [[0, 392, 0.34, 'triangle'], [0.17, 311, 0.6, 'triangle']],          // هبوط هادئ
};

export function chime(kind = 'notify') {
  if (!soundOn()) return;
  const c = ac(); if (!c) return;
  try {
    if (c.state === 'suspended') c.resume();
    const t0 = c.currentTime + 0.02;
    (PATTERNS[kind] || PATTERNS.notify).forEach(([dt, f, dur, type]) => note(c, t0 + dt, f, { dur, type: type || 'sine', vol: kind === 'fail' ? 0.16 : 0.18, bell: !type }));
  } catch { /* لا شيء */ }
}

export function buzz(pattern = [60]) {
  try { if (soundOn() && navigator.vibrate) navigator.vibrate(pattern); } catch { /* لا شيء */ }
}
