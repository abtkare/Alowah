// الجلسة 34 — رأس المعالج الموحّد لبوابة المقترض: شاشة واحدة لكل خطوة
// يعرض: زر «حفظ والخروج»، عنوان الطلب، شريط تقدم مقسّم بعدد الخطوات، «الخطوة X من N» واسم الخطوة التالية.
// الخطوات السابقة قابلة للضغط للرجوع إليها. زر «التالي» في كل خطوة يثبت أسفل الشاشة في الهاتف (CSS: .wiz-body .row.mt).
import { esc } from './core.js';

/**
 * @param {object} o
 * @param {string} o.title      عنوان الطلب (مثلاً: طلب تمويل منظومة شمسية)
 * @param {string} [o.sub]      سطر صغير تحت العنوان (رقم الطلب، المبلغ)
 * @param {Array<[string,string]>} o.steps  [اسم الخطوة، وصف قصير]
 * @param {number} o.cur        رقم الخطوة الحالية (يبدأ من 0)
 * @param {number} o.done       عدد الخطوات المنجزة
 * @param {number} o.reach      أبعد خطوة يمكن الانتقال إليها (يبدأ من 0)
 * @param {string} [o.exit]     رابط الخروج
 * @param {string} [o.exitLabel]
 */
export function wizHead({ title, sub = '', steps, cur, done, reach, exit = '#home', exitLabel = 'حفظ والخروج' }) {
  const n = steps.length, [name, hint] = steps[cur] || ['', ''], nextName = steps[cur + 1]?.[0];
  return `<header class="wz" aria-label="خطوات الطلب">
    <div class="wz-top">
      <div class="wz-ttl"><b>${esc(title)}</b>${sub ? `<small>${sub}</small>` : ''}</div>
      <a class="wz-x" href="${esc(exit)}"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg><span>${esc(exitLabel)}</span></a>
    </div>
    <div class="wz-bar" role="progressbar" aria-valuemin="1" aria-valuemax="${n}" aria-valuenow="${cur + 1}" aria-label="الخطوة ${cur + 1} من ${n}">
      ${steps.map(([t], i) => { const st = i === cur ? 'cur' : i < done ? 'done' : ''; const can = i !== cur && i <= reach;
        return `<button type="button" class="wz-seg ${st}" ${can ? `data-wz="${i}"` : 'tabindex="-1"'} aria-label="${i < done ? '✓ ' : ''}${esc(t)}"><i></i><span>${i < done && i !== cur ? '✓ ' : ''}${esc(t)}</span></button>`; }).join('')}
    </div>
    <div class="wz-now">
      <span class="wz-cnt">الخطوة <b class="num">${cur + 1}</b> من <b class="num">${n}</b></span>
      <span class="wz-name">${esc(name)}${hint ? ` <small>— ${esc(hint)}</small>` : ''}</span>
      ${nextName ? `<span class="wz-next">التالية: ${esc(nextName)}</span>` : '<span class="wz-next">الأخيرة ✓</span>'}
    </div>
  </header>`;
}

/** ربط الضغط على الخطوات السابقة */
export function wireWizHead(root, onGo) {
  root.querySelectorAll('.wz [data-wz]').forEach(b => b.onclick = () => { onGo(Number(b.dataset.wz)); window.scrollTo(0, 0); });
}
