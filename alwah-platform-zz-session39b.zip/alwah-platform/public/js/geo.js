// الجلسة 17: تحديد الموقع بالـGPS وتصوير الفيديو المباشر — أدوات مشتركة
import { esc, toast, modal } from './core.js';

// الجلسة 20: أخطاء الموقع مصنّفة (kind) كي تُعرض للمستخدم خطوات حلّ مناسبة لهاتفه
const gErr = (kind, msg) => Object.assign(new Error(msg), { kind });

// يقرأ الموقع لعدة ثوانٍ ويحتفظ بأدق قراءة. يعيد { lat, lng, acc, at } أو يرمي خطأً فيه kind: denied | off | weak | unsupported | insecure
export function getGps({ want = 30, maxMs = 25000, onProgress } = {}) {
  return new Promise((resolve, reject) => {
    if (!window.isSecureContext) return reject(gErr('insecure', 'افتح المنصة من رابطها الآمن (https)'));
    if (!navigator.geolocation) return reject(gErr('unsupported', 'هذا المتصفح لا يدعم تحديد الموقع'));
    let best = null, done = false, lastErr = null;
    const stop = () => { done = true; navigator.geolocation.clearWatch(id); clearTimeout(t); };
    const finish = () => {
      if (done) return; stop();
      if (best) return resolve(best);
      reject(lastErr === 2 ? gErr('off', 'خدمة الموقع (GPS) مطفأة في الهاتف') : gErr('weak', 'لم يلتقط الهاتف إشارة الموقع'));
    };
    const id = navigator.geolocation.watchPosition(p => {
      const r = { lat: +p.coords.latitude.toFixed(6), lng: +p.coords.longitude.toFixed(6), acc: Math.round(p.coords.accuracy * 10) / 10, at: new Date(p.timestamp).toISOString() };
      if (!best || r.acc < best.acc) best = r;
      onProgress && onProgress(best);
      if (best.acc <= want) finish();
    }, err => {
      if (done) return;
      if (err.code === 1) { stop(); return reject(gErr('denied', 'لم يُسمح للمنصة باستخدام الموقع')); }
      lastErr = err.code;   // 2 = الموقع غير متاح (غالباً GPS مطفأ)، 3 = انتهت المهلة — نستمر حتى المهلة الكاملة
    }, { enableHighAccuracy: true, maximumAge: 0, timeout: maxMs });
    const t = setTimeout(finish, maxMs);
  });
}

// نوع الهاتف والمتصفح — لعرض خطوات الإعدادات الصحيحة بالضبط
function device() {
  const u = navigator.userAgent || '';
  const ios = /iPhone|iPad|iPod/i.test(u) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const android = /Android/i.test(u);
  const inApp = /FBAN|FBAV|FB_IAB|Instagram|WhatsApp|Telegram|Line\/|Snapchat|TikTok|; wv\)/i.test(u);
  const chrome = /CriOS|Chrome/i.test(u) && !/EdgiOS|Edg\//i.test(u);
  return { ios, android, inApp, browser: ios ? (/CriOS/i.test(u) ? 'chrome' : /FxiOS/i.test(u) ? 'firefox' : 'safari') : chrome ? 'chrome' : 'other' };
}

// خطوات إصلاح مرقّمة بكلمات قائمة الهاتف نفسها — لأبسط مستخدم
function fixSteps(kind) {
  const d = device();
  if (kind === 'insecure') return ['افتح المنصة من الرابط الرسمي الذي يبدأ بـ https'];
  if (d.inApp) return ['أنت تفتح المنصة من داخل تطبيق (واتساب أو فيسبوك أو غيره)، وهذا لا يسمح بتحديد الموقع.',
    `اضغط زر النقاط الثلاث <b>⋯</b> أعلى الشاشة واختر <b>«الفتح في ${d.ios ? 'Safari' : 'Chrome'}»</b>.`, 'سجّل الدخول هناك وأعد تحديد الموقع.'];
  if (kind === 'off' || kind === 'weak') {
    const on = d.ios ? 'افتح <b>الإعدادات</b> ← <b>الخصوصية والأمن</b> ← <b>خدمات الموقع</b> وتأكد أنها <b>مفعّلة</b>.'
      : 'اسحب الشريط العلوي للهاتف إلى الأسفل وشغّل زر <b>الموقع</b> 📍.';
    return kind === 'off' ? [on, 'ارجع إلى هنا واضغط <b>«حاول مرة أخرى»</b>.']
      : ['اخرج إلى السطح أو الساحة بعيداً عن الجدران والسقوف — الإشارة تضعف داخل الغرف.', on, 'اضغط <b>«حاول مرة أخرى»</b> وانتظر نصف دقيقة.'];
  }
  // denied: رُفض الإذن
  if (d.ios && d.browser === 'safari') return [
    'اضغط زر <b>«aA»</b> أو زر <b>الإعدادات ☰</b> بجانب رابط الموقع في أعلى أو أسفل الشاشة.',
    'اختر <b>«إعدادات موقع الويب»</b> ← <b>«الموقع»</b> ← <b>«سماح»</b>.',
    'إن لم ينجح: افتح <b>الإعدادات</b> ← <b>الخصوصية والأمن</b> ← <b>خدمات الموقع</b> ← <b>مواقع Safari</b> ← اختر <b>«أثناء استخدام التطبيق»</b>.',
    'ارجع إلى هنا واضغط <b>«حاول مرة أخرى»</b>، ثم اضغط <b>«سماح»</b> عندما يسألك الهاتف.'];
  if (d.ios) return [
    `افتح <b>الإعدادات</b> في الهاتف ← انزل إلى <b>${d.browser === 'chrome' ? 'Chrome' : 'المتصفح الذي تستخدمه'}</b> ← <b>الموقع</b> ← اختر <b>«أثناء استخدام التطبيق»</b>.`,
    'تأكد أيضاً: <b>الإعدادات</b> ← <b>الخصوصية والأمن</b> ← <b>خدمات الموقع</b> مفعّلة.',
    'ارجع إلى هنا واضغط <b>«حاول مرة أخرى»</b>، ثم <b>«سماح»</b>.'];
  if (d.android) return [
    'اضغط رمز <b>القفل 🔒</b> أو <b>الإعدادات</b> على يسار رابط الموقع في أعلى الشاشة.',
    'اختر <b>«الأذونات»</b> ← <b>«الموقع»</b> ← <b>«سماح»</b>.',
    'تأكد أن زر <b>الموقع</b> 📍 مشغّل في الشريط العلوي للهاتف.',
    'ارجع إلى هنا واضغط <b>«حاول مرة أخرى»</b>.'];
  return ['اضغط رمز القفل 🔒 بجانب رابط الموقع ← <b>الموقع</b> ← <b>سماح</b>.', 'اضغط <b>«حاول مرة أخرى»</b>.'];
}
const TITLES = { denied: 'الهاتف لم يسمح بمعرفة الموقع', off: 'خدمة الموقع مطفأة في هاتفك', weak: 'الإشارة ضعيفة هنا', unsupported: 'هذا المتصفح لا يحدد الموقع', insecure: 'الرابط غير آمن' };

// نافذة تحديد الموقع بثلاث حالات واضحة: (1) شرح قبل السؤال، (2) قراءة حيّة، (3) خطوات حل إن فشل
// تعيد { lat, lng, acc, at } أو null عند الإلغاء
export function gpsDialog({ title = 'تحديد الموقع', hint = '', want = 30, accMax = 100 } = {}) {
  return new Promise(resolve => {
    let best = null, settled = false;
    const end = v => { if (settled) return; settled = true; resolve(v); };
    const m = modal(`<h3>${esc(title)}</h3><div data-v></div>`, { onClose: () => end(null) });
    const v = m.el.querySelector('[data-v]');
    const accept = () => { const x = best; end(x); m.close(); };

    // (1) قبل سؤال الهاتف: نخبره ماذا سيرى وماذا يضغط
    const intro = () => {
      v.innerHTML = `<ol class="gps-steps">
          <li>قف <b>في مكان تركيب المنظومة نفسه</b>، ويُفضّل في السطح أو الساحة.</li>
          <li>اضغط زر <b>«حدّد موقعي الآن»</b> بالأسفل.</li>
          <li>سيسألك الهاتف: <b>«هل تسمح باستخدام موقعك؟»</b> — اضغط <b class="ok-t">«سماح»</b>.</li></ol>
        ${hint ? `<p class="small muted">${esc(hint)}</p>` : ''}
        <button class="btn cyan big-btn" data-go>📍 حدّد موقعي الآن</button>`;
      v.querySelector('[data-go]').onclick = run;   // الطلب من ضغطة المستخدم نفسها — شرط في آيفون
    };
    // (2) القراءة الحية
    const run = () => {
      v.innerHTML = `<div class="gps-live"><span class="gps-dot"></span><span data-s>جارِ تحديد الموقع… لا تغلق الصفحة</span></div>
        <div data-a></div>`;
      const s = v.querySelector('[data-s]'), a = v.querySelector('[data-a]');
      const showAccept = b => {
        const good = b.acc <= accMax;
        a.innerHTML = good ? `<button class="btn cyan big-btn mt" data-ok>✓ اعتماد هذا الموقع</button>` : '';
        const ok = a.querySelector('[data-ok]'); if (ok) ok.onclick = accept;
      };
      getGps({ want, onProgress: b => { best = b; s.innerHTML = b.acc <= want ? `✓ الموقع جاهز — الدقة ±<b class="num">${Math.round(b.acc)}</b> م`
          : `الدقة الآن ±<b class="num">${Math.round(b.acc)}</b> م — ${b.acc <= accMax ? 'مقبولة، ويمكنك الانتظار لتحسينها' : 'انتظر قليلاً حتى تتحسن…'}`; showAccept(b); } })
        .then(b => { best = b; s.innerHTML = `✓ الموقع جاهز — الدقة ±<b class="num">${Math.round(b.acc)}</b> م`; showAccept(b); })
        .catch(e => {
          if (best && best.acc <= accMax) { s.innerHTML = `✓ الموقع جاهز — الدقة ±<b class="num">${Math.round(best.acc)}</b> م`; return showAccept(best); }
          fail(e.kind || 'weak');
        });
    };
    // (3) فشل: عنوان واضح + خطوات مرقّمة لهاتفه + حاول مرة أخرى
    const fail = kind => {
      v.innerHTML = `<div class="gps-fail"><b>⚠ ${esc(TITLES[kind] || TITLES.weak)}</b>${best ? `<div class="small">أفضل دقة وصلنا لها ±<span class="num">${Math.round(best.acc)}</span> م والمطلوب ±<span class="num">${accMax}</span> م أو أفضل.</div>` : ''}</div>
        <p style="margin:12px 0 6px"><b>افعل هذا:</b></p>
        <ol class="gps-steps">${fixSteps(kind).map(x => `<li>${x}</li>`).join('')}</ol>
        <button class="btn cyan big-btn" data-retry>↻ حاول مرة أخرى</button>
        <p class="small muted mt" style="text-align:center">ما زالت لا تعمل؟ اطلب من أحد أفراد عائلتك المساعدة، أو اتصل بفرعك وسيرشدك الموظف.</p>`;
      v.querySelector('[data-retry]').onclick = () => { best = null; run(); };
    };

    // إن كان الإذن مرفوضاً مسبقاً نعرض خطوات الحل مباشرة بدل سؤال لن يظهر
    (navigator.permissions?.query?.({ name: 'geolocation' }) || Promise.reject())
      .then(p => p.state === 'denied' ? fail('denied') : p.state === 'granted' ? run() : intro())
      .catch(intro);
  });
}

// تصوير فيديو مباشر بكاميرا الهاتف (لا معرض) — يعيد { data, duration, mime } أو null
export function recordVideo({ title = 'فيديو التشغيل', hint = '', maxSec = 20, minSec = 5 } = {}) {
  return new Promise(resolve => {
    if (!window.MediaRecorder || !navigator.mediaDevices?.getUserMedia) { toast('هذا المتصفح لا يدعم تصوير الفيديو — استخدم Chrome أو Safari حديث', 'bad'); return resolve(null); }
    const bg = document.createElement('div');
    bg.className = 'cam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <p class="cam-hint">${esc(title)}<small>${esc(hint || `صوّر الألواح والعاكس وشاشة التشغيل وهي تعمل — من ${minSec} إلى ${maxSec} ثانية`)}</small><small class="rec-t" data-t></small></p>
      <div class="cam-bar"><button type="button" class="cam-x" aria-label="إغلاق">✕</button><button type="button" class="cam-shoot rec" aria-label="تسجيل"></button><span class="cam-gal" style="visibility:hidden">—</span></div>`;
    document.body.appendChild(bg);
    const video = bg.querySelector('video'), btn = bg.querySelector('.cam-shoot'), tEl = bg.querySelector('[data-t]');
    let stream, rec, chunks = [], t0 = 0, tick, stopT, cancelled = false;
    const cleanup = () => { clearInterval(tick); clearTimeout(stopT); stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); };
    bg.querySelector('.cam-x').onclick = () => { cancelled = true; if (rec && rec.state === 'recording') rec.stop(); cleanup(); resolve(null); };
    const types = ['video/mp4', 'video/webm;codecs=vp8', 'video/webm'];
    const type = types.find(t => MediaRecorder.isTypeSupported?.(t)) || '';
    const base = type.startsWith('video/mp4') ? 'video/mp4' : 'video/webm';
    btn.onclick = () => {
      if (!stream) return;
      if (rec && rec.state === 'recording') {
        if ((Date.now() - t0) / 1000 < minSec) return toast(`استمر في التصوير — ${minSec} ثوانٍ على الأقل`, 'bad');
        return rec.stop();
      }
      chunks = [];
      rec = new MediaRecorder(stream, { ...(type ? { mimeType: type } : {}), videoBitsPerSecond: 900000 });
      rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      rec.onstop = () => {
        if (cancelled) return;
        const duration = Math.round((Date.now() - t0) / 100) / 10;
        const blob = new Blob(chunks, { type: base });
        cleanup();
        if (blob.size > 8.5e6) { toast('الفيديو أكبر من المسموح — صوّر مقطعاً أقصر', 'bad'); return resolve(null); }
        const r = new FileReader();
        r.onload = () => resolve({ data: String(r.result).replace(/^data:[^;,]+(;[^,]*)?;base64,/, `data:${base};base64,`), duration, mime: base });
        r.readAsDataURL(blob);
      };
      rec.start(500); t0 = Date.now(); btn.classList.add('on');
      tick = setInterval(() => { tEl.textContent = `● تسجيل ${Math.floor((Date.now() - t0) / 1000)} / ${maxSec} ث`; }, 250);
      stopT = setTimeout(() => rec.state === 'recording' && rec.stop(), maxSec * 1000);
    };
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 960 }, height: { ideal: 540 } }, audio: false })
      .then(st => { stream = st; video.srcObject = st; })
      .catch(() => { bg.querySelector('.cam-hint').innerHTML = 'تعذر فتح الكاميرا — اسمح للمنصة باستخدام الكاميرا من إعدادات المتصفح'; btn.disabled = true; });
  });
}
