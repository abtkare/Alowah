// الجلسة 16: «بوابة الخبراء» — خبير معتمد مختص من خارج المصرف يدرس دراسة جدوى طلبات الأغراض الزراعية والصناعية والمشاريع
// رحلة الخبير: استلام الطلب ← دراسة الجدوى ← القرار (مطابق / غير مطابق) ← كتابة القرار ← كتابة الملاحظة ← التوقيع والإرسال للمصرف
// يرى الخبير ملخص المشروع ودراسة الجدوى وعرض المورد فقط — لا يرى اسم المقترض ولا بقية الإضبارة (حياد الخبير)
import { esc, el, iqd, num, kpi, badge, dt, ago, rpc, toast, cleanErr, closeDrawer, tabs, viewDoc, wdTxt, XREF_STATUS, PURPOSE } from '../core.js';
import { studiesHtml, pickFile } from '../intake-ui.js';
import { fzLine } from '../fz-office.js';

export async function render(ctx) {
  const { sb, root, profile } = ctx;
  const [me, refs] = await Promise.all([rpc(sb, 'expert_me', {}).catch(() => null), rpc(sb, 'expert_inbox', {}).catch(e => { toast(cleanErr(e), 'bad'); return []; })]);
  const open = refs.filter(r => ['pending', 'received'].includes(r.status));
  const done = refs.filter(r => ['conforming', 'non_conforming'].includes(r.status));
  const late = open.filter(r => Number(r.work_days) > r.sla_days);
  const avg = done.length ? done.reduce((t, r) => t + Number(r.work_days || 0), 0) / done.length : null;
  root.innerHTML = `
    <div class="page-head"><div><h1>بوابة الخبراء — ${esc(profile.full_name)}</h1>
      <p>خبير معتمد${me ? ` في اختصاص <b>${esc((me.specialty_labels || []).join('، '))}</b> · اعتماد <span class="num">${esc(me.license_no)}</span> — ${esc(me.accreditor)}` : ''} · الرمز الوظيفي <code>${esc(profile.staff_code || '')}</code>.
      قرارك مستقل ويُوقَّع برمزك الوظيفي وختمك الإلكتروني ويصل إلى المصرف مباشرة.</p></div></div>
    ${me && !me.active ? '<div class="notice warn">اعتمادك موقوف حالياً على المنصة — لا تُحال إليك طلبات جديدة.</div>' : ''}
    <div class="grid g4 mb">
      ${kpi('طلبات جديدة', `<span class="num">${refs.filter(r => r.status === 'pending').length}</span>`, 'بانتظار استلامك', true)}
      ${kpi('قيد الدراسة', `<span class="num">${refs.filter(r => r.status === 'received').length}</span>`, late.length ? `<span style="color:var(--bad)">${late.length} متأخرة عن المدة</span>` : 'ضمن المدة المسموحة')}
      ${kpi('قرارات صادرة', `<span class="num">${done.length}</span>`, `${done.filter(r => r.status === 'conforming').length} مطابق · ${done.filter(r => r.status === 'non_conforming').length} غير مطابق`)}
      ${kpi('متوسط مدة الدراسة', avg == null ? '—' : wdTxt(avg), 'المدة المسموحة 5 أيام دوام')}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'open', label: 'الطلبات المحالة إليّ', count: open.length }, { key: 'done', label: 'القرارات الصادرة' }];
  ctx.exTab = ctx.exTab || 'open';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.exTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.exTab));

  function show(k) {
    const list = k === 'open' ? open : done;
    body.innerHTML = list.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th>رقم الإحالة</th><th>رقم الطلب</th><th>الغرض</th><th>الاختصاص</th><th>المصرف المحيل</th><th>مبلغ التمويل</th><th>الجولة</th><th>الحالة</th><th>المدة</th></tr></thead><tbody>
      ${list.map((r, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(r.code)}</b></td><td class="num">${esc(r.app_code)}</td><td>${esc(r.purpose_label)}${r.fz_office?.accredited ? '<div class="small" style="color:var(--ok)">⚡ مسار ميسّر</div>' : ''}</td>
        <td>${esc(r.specialty_label)}</td><td>${esc(r.bank_name)}</td><td>${iqd(r.amount)}</td>
        <td><span class="num">${r.round}</span>${r.round > 1 ? ' ' + badge(['دراسة محدّثة', 'warn']) : ''}</td><td>${badge(XREF_STATUS[r.status])}</td>
        <td class="small ${['pending', 'received'].includes(r.status) && Number(r.work_days) > r.sla_days ? '" style="color:var(--bad)' : 'muted'}">${wdTxt(r.work_days)}</td></tr>`).join('')}
      </tbody></table></div></div>` : `<div class="card empty">${k === 'open' ? 'لا توجد طلبات محالة إليك الآن.' : 'لم تصدر قرارات بعد.'}</div>`;
    body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openRef(list[+tr.dataset.i]));
  }
  show(ctx.exTab);

  async function openRef(r) {
    closeDrawer();
    const docs = (await sb.from('app_documents').select('id,kind,mime,source,meta,created_at').eq('application_id', r.application_id).order('created_at')).data || [];
    const fz = docs.filter(d => d.kind === 'feasibility'), q = docs.filter(d => d.kind === 'quote');
    const cur = fz.find(d => d.id === r.feasibility_doc);
    const decided = ['conforming', 'non_conforming'].includes(r.status);
    const stepN = r.status === 'pending' ? 0 : r.status === 'received' ? 1 : 5;
    const J = [['استلام الطلب', 'تأكيد الاستلام يبدأ المدة'], ['دراسة الجدوى', 'الدراسة وعرض المورد'], ['القرار', 'مطابق أو غير مطابق'], ['كتابة القرار', 'نص القرار مفصلاً'], ['كتابة الملاحظة', 'المطلوب تصحيحه']];
    const hist = (r.history || []).map(h => ({ ...h, status: h.status, feasibility_doc: h.feasibility_doc }));
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer" role="dialog"><div class="dh"><div><div class="small" style="color:#8FA3C0">إحالة دراسة جدوى</div><h2 class="num">${esc(r.code)}</h2></div><span class="sp"></span>${badge(XREF_STATUS[r.status])}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">
        <ol class="xjour">${J.map(([t, s], i) => `<li class="${i < stepN || decided ? 'done' : i === stepN ? 'cur' : ''}"><b>${i + 1}. ${t}</b>${s}</li>`).join('')}</ol>
        ${r.round > 1 ? `<div class="notice warn mb"><span>⚠</span><span><b>مرفوض سابقاً بسبب دراسة الجدوى</b> — هذه الجولة <span class="num">${r.round}</span> بدراسة محدّثة رفعها المقترض. القرارات السابقة أدناه، والدراسة السابقة محفوظة للمقارنة.</span></div>` : ''}
        <div class="card mb"><h3>المشروع</h3><dl class="kv">
          <dt>رقم الطلب</dt><dd class="num">${esc(r.app_code)}</dd>
          <dt>غرض التمويل</dt><dd>${esc(r.purpose_label)}</dd>
          <dt>الاختصاص المطلوب</dt><dd>${esc(r.specialty_label)}</dd>
          <dt>المنظومة</dt><dd>${esc(r.offer_title || '—')} · <span class="num">${num(r.kw)}</span> kW</dd>
          <dt>المورد</dt><dd>${esc(r.supplier_name || '—')}</dd>
          <dt>مبلغ التمويل</dt><dd>${iqd(r.amount)} · <span class="num">${num(r.term_months)}</span> شهراً</dd>
          <dt>الموقع</dt><dd>${esc(r.governorate || '')}${r.city ? ` — ${esc(r.city)}` : ''}</dd>
          <dt>المصرف المحيل</dt><dd>${esc(r.bank_name)} · ${esc(r.referred_by_title || '')}</dd>
          <dt>أُحيلت</dt><dd>${dt(r.created_at)} (${ago(r.created_at)})${r.received_at ? ` · استُلمت ${dt(r.received_at)}` : ''}</dd>
          <dt>المدة</dt><dd>${wdTxt(r.work_days)} من <span class="num">${r.sla_days}</span> أيام دوام مسموحة</dd>
          <dt>المقترض</dt><dd class="muted small">لا يُعرض اسمه حفاظاً على حياد الخبير</dd></dl>
          ${r.referral_note ? `<div class="xdec mt"><b>ملاحظة المصرف:</b> ${esc(r.referral_note)}</div>` : ''}</div>
        <div class="card mb"><h3>دراسة الجدوى وعرض المورد</h3>
          ${fzLine(r.fz_office, { sla: r.sla_days })}
          ${cur ? `<p class="small" style="margin:0 0 6px">الإصدار المحال إليك: <b>الإصدار <span class="num">${cur.meta?.version || 1}</span></b>${cur.meta?.updated ? ' ' + badge(['محدّثة', 'ok']) : ''}</p>` : ''}
          ${studiesHtml([...q, ...fz], hist)}</div>
        ${hist.length ? `<div class="card mb"><h3>القرارات السابقة على هذا الطلب</h3>${hist.map(h => `<div class="xref ${h.status}"><div class="row"><b>الجولة <span class="num">${h.round}</span></b><span class="small">اختصاص ${esc(h.specialty_label)}</span><span class="sp"></span>${badge(XREF_STATUS[h.status])}</div>
          <div class="xdec"><b>القرار:</b> ${esc(h.decision_text || '')}${h.notes ? `<br><b>الملاحظة:</b> ${esc(h.notes)}` : ''}</div><div class="small muted">${dt(h.decided_at)}</div></div>`).join('')}</div>` : ''}
        ${decided ? `<div class="card mb"><h3>قرارك</h3><div class="xref ${r.status}"><div class="row"><b>${r.status === 'conforming' ? 'مطابق' : 'غير مطابق'}</b><span class="sp"></span><span class="small muted">${dt(r.decided_at)}</span></div>
          <div class="xdec"><b>القرار:</b> ${esc(r.decision_text || '')}${r.notes ? `<br><b>الملاحظة:</b> ${esc(r.notes)}` : ''}</div>
          ${r.report_doc ? `<button type="button" class="btn ghost sm" data-doc="${r.report_doc}">تقريري المرفق</button>` : ''}
          ${r.status === 'non_conforming' ? '<p class="small muted" style="margin:4px 0 0">رُفض الطلب بسبب دراسة الجدوى وأُعيد للمقترض لرفع دراسة حقيقية محدّثة. إن أُعيد إرساله تصل إحالة جديدة بجولة جديدة.</p>' : ''}</div></div>` : ''}
        ${r.status === 'received' ? `<div class="card mb" data-form><h3>القرار</h3>
          <div class="decide"><label class="c"><input type="radio" name="dec" value="conforming">✓ مطابق</label><label class="n"><input type="radio" name="dec" value="non_conforming">✕ غير مطابق</label></div>
          <div class="field mt"><label>كتابة القرار *</label><textarea class="input" rows="3" data-k="decision_text" placeholder="مثال: الدراسة واقعية، الكلف مطابقة لأسعار السوق، والتدفقات النقدية تغطي القسط الشهري بهامش أمان كافٍ."></textarea></div>
          <div class="field"><label>كتابة الملاحظة <span data-nreq class="small muted">(اختيارية — إلزامية عند «غير مطابق»: ما المطلوب تصحيحه)</span></label><textarea class="input" rows="3" data-k="notes" placeholder="مثال: أعد احتساب الإيرادات المتوقعة بأسعار البيع الحالية، وأضف كلفة الصيانة السنوية."></textarea></div>
          <div class="field"><label>تقرير الخبير (اختياري — PDF أو صورة حتى 5 ميغابايت)</label><div class="row" style="gap:8px"><button type="button" class="btn ghost sm" data-rep>إرفاق التقرير</button><span class="small muted" data-repn>لم يُرفق</span></div></div>
          <label class="check"><input type="checkbox" data-pledge> أقرّ بأنني درست دراسة الجدوى وعرض المورد، وأن قراري فني مستقل، ولا تربطني بالمقترض أو المورد أي مصلحة.</label>
        </div>` : ''}
      </div><div class="df"><div class="row"></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;
    dr.querySelectorAll('[data-doc]').forEach(x => x.onclick = () => viewDoc(sb, x.dataset.doc));
    const row = dr.querySelector('.df .row');
    const btn = (l, k, fn) => { const b = el(`<button class="btn ${k}">${l}</button>`); b.onclick = () => fn(b); row.appendChild(b); return b; };
    const finish = msg => { closeDrawer(); toast(msg, 'ok'); ctx.refresh(); };

    if (r.status === 'pending') {
      row.insertAdjacentHTML('beforeend', '<span class="small muted">بالاستلام تبدأ مدة الدراسة (5 أيام دوام) ويُسجَّل باسمك.</span><span class="sp"></span>');
      btn('استلام الطلب', 'ok', async b => { b.disabled = true; try { await rpc(sb, 'expert_action', { p_ref: r.id, p_action: 'receive', p_data: {} }); finish('استلمت الطلب — ادرس دراسة الجدوى ثم أصدر قرارك'); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; } });
    } else if (r.status === 'received') {
      const f = dr.querySelector('[data-form]');
      f.querySelectorAll('input[name=dec]').forEach(i => i.onchange = () => {
        f.querySelectorAll('.decide label').forEach(l => l.classList.toggle('on', l.querySelector('input').checked));
        f.querySelector('[data-nreq]').textContent = i.value === 'non_conforming' ? '(إلزامية — ما المطلوب تصحيحه في الدراسة)' : '(اختيارية)';
      });
      f.querySelector('[data-rep]').onclick = async () => {
        const x = await pickFile({ maxMB: 5 }); if (!x) return;
        try { await rpc(sb, 'expert_add_report', { p_ref: r.id, p_data: x.data, p_source: 'file', p_meta: x.meta }); f.querySelector('[data-repn]').textContent = '✓ ' + (x.meta.name || 'مرفق'); toast('أُرفق التقرير', 'ok'); }
        catch (e) { toast(cleanErr(e), 'bad'); }
      };
      row.insertAdjacentHTML('beforeend', '<span class="small muted">يُوقَّع القرار برمزك الوظيفي وختمك الإلكتروني.</span><span class="sp"></span>');
      btn('توقيع القرار وإرساله للمصرف', 'cyan', async b => {
        const dec = f.querySelector('input[name=dec]:checked')?.value;
        const v = k => f.querySelector(`[data-k="${k}"]`).value.trim();
        if (!dec) return toast('اختر القرار: مطابق أو غير مطابق', 'bad');
        if (v('decision_text').length < 10) return toast('اكتب القرار مفصلاً', 'bad');
        if (dec === 'non_conforming' && !v('notes')) return toast('اكتب الملاحظة: ما المطلوب تصحيحه في دراسة الجدوى', 'bad');
        if (!f.querySelector('[data-pledge]').checked) return toast('ضع علامة ✓ على الإقرار', 'bad');
        if (dec === 'non_conforming' && !window.confirm('القرار «غير مطابق» يرفض الطلب بسبب دراسة الجدوى ويعيده للمقترض لرفع دراسة محدّثة. تأكيد؟')) return;
        b.disabled = true;
        try { await rpc(sb, 'expert_action', { p_ref: r.id, p_action: 'decide', p_data: { decision: dec, decision_text: v('decision_text'), notes: v('notes'), pledge: true } });
          finish(dec === 'conforming' ? 'صدر قرارك «مطابق» ووصل إلى المصرف' : 'صدر قرارك «غير مطابق» — رُفض الطلب بسبب دراسة الجدوى وأُعيد للمقترض'); }
        catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
      });
    } else dr.querySelector('.df').innerHTML = '<p class="muted small" style="margin:0">صدر القرار — لا إجراء مطلوب.</p>';
  }
}
