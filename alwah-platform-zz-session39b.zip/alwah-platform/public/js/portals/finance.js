// الجلسة 29: لوحة وزارة المالية — الأثر المالي للمبادرة على المال العام
// اطلاع بأرقام مجمّعة (دون أسماء المقترضين) + كتابة على شيء واحد: تعاميم الوزارة. لا كتابة على أي معاملة.
import { esc, num, iqd, mln, pct, dt, kpi, tabs, rpc, cleanErr, badge, toast, modal, SECTORS } from '../core.js';

const KIND = { customs: 'الكمارك والإعفاءات', interest: 'دعم الفائدة', salary: 'الاستقطاع من الرواتب', tax: 'الضرائب', general: 'تعميم عام' };
const TARGET = { bank: 'المصارف', supplier: 'الموردون', cbi: 'البنك المركزي', audit: 'ديوان الرقابة المالية', planning: 'وزارة التخطيط' };
const CST = { draft: ['مسودة', 'warn'], issued: ['صادر', 'ok'], withdrawn: ['مسحوب', 'muted'] };
const ratio = (a, b) => b > 0 ? a / b * 100 : null;
const pctOr = v => v == null ? '—' : pct(v);
const sectorName = k => SECTORS[k]?.[0] || k;
const bar = (v, max, color = 'var(--indigo)') => `<span class="bar" style="min-width:80px"><i style="width:${max > 0 ? Math.max(2, v / max * 100) : 0}%;background:${color}"></i></span>`;

function exportCsv(name, head, rows) {
  const cell = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = '﻿' + [head, ...rows].map(r => r.map(cell).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `${name}-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast('جُهّز ملف التصدير', 'ok');
}
const xBtn = k => `<button type="button" class="btn ghost sm" data-x="${k}">⬇️ تصدير Excel</button>`;

export async function render(ctx) {
  const { sb, root } = ctx;
  const F = ctx.mf ||= { tab: 'sum', sub: 50, scope: 'household' };
  root.innerHTML = `
    <div class="page-head"><div><h1>وزارة المالية</h1><p>أثر مبادرة تمويل منظومات الطاقة الشمسية على المال العام: الرواتب، دعم الفائدة، الكمارك، والضرائب.</p></div></div>
    <div class="notice dark"><div>💰 <b>صلاحية الوزارة:</b> اطلاع على أرقام مجمّعة وتصديرها، وإصدار <b>تعاميم الوزارة</b> فقط. لا تكتب الوزارة على أي معاملة، ولا توافق ولا ترفض أي قرض، ولا ترى أسماء المقترضين.</div></div>
    <div data-kpis><div class="card"><div class="spin"></div></div></div><div id="tabs"></div><div id="body"></div>`;

  let d;
  try { d = await rpc(sb, 'finance_overview'); }
  catch (e) { root.querySelector('[data-kpis]').innerHTML = `<div class="card empty">${esc(cleanErr(e))}${/does not exist|PGRST202/.test(String(e?.message)) ? '<br>لم يُطبَّق تحديث الجلسة 29 بعد — افتح ‎/migrate‎' : ''}</div>`; return; }
  const t = d.totals || {}, s = d.salary || {}, c = d.customs || {};
  const drafts = (d.circulars || []).filter(x => x.status === 'draft').length;
  const drop = c.before?.avg && c.after?.avg ? (1 - c.after.avg / c.before.avg) * 100 : null;
  root.querySelector('[data-kpis]').innerHTML = `<div class="grid g4 mb">
    ${kpi('القروض المموّلة', mln(t.funded_amt), `<span class="num">${num(t.funded_n)}</span> قرضاً · ${pctOr(ratio(t.funded_amt, t.budget))} من رصيد المبادرة`, true)}
    ${kpi('قيد المعالجة لدى المصارف', mln(t.pipeline_amt), `<span class="num">${num(t.pipeline_n)}</span> طلباً`)}
    ${kpi('مضمونة برواتب موظفين', mln(s.amount), `<span class="num">${num(s.gov_guarantors)}</span> كفيلاً من موظفي الدولة`)}
    ${kpi('أثر الإعفاء الكمركي', drop == null ? '—' : `${drop >= 0 ? '▼' : '▲'} ${pct(Math.abs(drop))}`, 'تغيّر متوسط سعر الكيلوواط بعد القرار')}
  </div>`;

  const body = root.querySelector('#body');
  const defs = [
    { key: 'sum', label: 'الخلاصة والمصارف' }, { key: 'sal', label: 'رواتب موظفي الدولة' }, { key: 'sub', label: 'محاكي دعم الفائدة' },
    { key: 'cus', label: 'أثر الإعفاء الكمركي' }, { key: 'tax', label: 'الضرائب' }, { key: 'dist', label: 'المحافظات والقطاعات' },
    { key: 'circ', label: 'تعاميم الوزارة', count: drafts }, { key: 'log', label: 'السجل' },
  ];
  tabs(root.querySelector('#tabs'), defs, k => { F.tab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === F.tab));
  const wireX = map => body.querySelectorAll('[data-x]').forEach(b => b.onclick = () => map[b.dataset.x]?.());

  const views = {
    sum() {
      const B = d.by_bank || [], mx = Math.max(1, ...B.map(b => b.amount + b.pipeline));
      body.innerHTML = `<div class="grid g4 mb">
          ${kpi('رصيد المبادرة', t.budget >= 1e12 ? `<span class="num">${num(t.budget / 1e12)}</span> ترليون دينار` : mln(t.budget))}
          ${kpi('الأقساط الشهرية للقروض المموّلة', mln(t.monthly_inst))}
          ${kpi('أرباح المصارف على القروض المموّلة', mln(t.profit_funded), `متوسط هامش الربح ${pctOr(t.avg_margin)} · متوسط المدة <span class="num">${num(t.avg_term)}</span> شهراً`)}
          ${kpi('المصروف فعلياً للموردين', mln(t.disbursed), `عمولة المنصة المستقطعة ${mln(t.commission)}`)}
        </div>
        <div class="card flush"><div class="row" style="padding:14px 16px"><h3 style="margin:0">المصارف الوسيطة</h3><span class="sp"></span>${xBtn('bank')}</div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>الطلبات</th><th>المموّل</th><th>قيد المعالجة</th><th></th><th>الأرباح</th><th>الهامش</th></tr></thead><tbody>
        ${B.map(b => `<tr><td><b>${esc(b.name)}</b> ${b.islamic ? badge(['إسلامي', 'info']) : ''}</td><td class="num">${num(b.apps)}</td><td>${mln(b.amount)} <span class="small muted">(${num(b.funded)})</span></td><td>${mln(b.pipeline)}</td>
          <td>${bar(b.amount + b.pipeline, mx)}</td><td>${mln(b.profit)}</td><td>${b.margin == null ? '—' : pct(b.margin)}</td></tr>`).join('') || '<tr><td colspan="7" class="empty">لا بيانات</td></tr>'}
        </tbody></table></div></div>`;
      wireX({ bank: () => exportCsv('mof-banks', ['المصرف', 'إسلامي', 'الطلبات', 'المموّل', 'عدد المموّل', 'قيد المعالجة', 'الأرباح', 'الهامش'],
        B.map(b => [b.name, b.islamic ? 'نعم' : 'لا', b.apps, b.amount, b.funded, b.pipeline, b.profit, b.margin])) });
    },
    sal() {
      const E = s.employers || [], mx = Math.max(1, ...E.map(e => e.n));
      body.innerHTML = `<div class="notice"><span>ℹ️</span><span>رواتب موظفي الدولة تُموَّل من الموازنة العامة. كل قرض مضمون براتب موظف حكومي يعني استقطاعاً شهرياً يعتمد على انتظام صرف الرواتب — هذا هو انكشاف المبادرة على المال العام.</span></div>
        <div class="grid g4 mb">
          ${kpi('قروض مضمونة بالرواتب', `<span class="num">${num(s.loans)}</span>`, mln(s.amount), true)}
          ${kpi('الاستقطاع الشهري المحتمل', mln(s.monthly), 'إن تخلّف كل المقترضين')}
          ${kpi('كفلاء من موظفي الدولة', `<span class="num">${num(s.gov_guarantors)}</span> من <span class="num">${num(s.guarantors)}</span>`, `على <span class="num">${num(s.gov_loans)}</span> قرضاً · ${mln(s.gov_monthly)} شهرياً`)}
          ${kpi('قروض برهن عقار', `<span class="num">${num(s.mortgage_loans)}</span>`, `${mln(s.mortgage_amount)} — لا تمسّ الرواتب`)}
        </div>
        <div class="card flush"><div class="row" style="padding:14px 16px"><h3 style="margin:0">جهات عمل الكفلاء</h3><span class="sp"></span>${xBtn('emp')}</div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>جهة العمل</th><th>النوع</th><th>الكفلاء</th><th>القروض</th><th></th></tr></thead><tbody>
        ${E.map(e => `<tr><td>${esc(e.employer)}</td><td>${e.gov ? badge(['دولة', 'info']) : badge(['خاص / غير محدد', 'muted'])}</td><td class="num">${num(e.n)}</td><td class="num">${num(e.loans)}</td><td>${bar(e.n, mx, e.gov ? 'var(--indigo)' : '#9AA8BE')}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">لا كفلاء مسجلين بعد</td></tr>'}
        </tbody></table></div><p class="small muted" style="padding:0 16px 14px">تصنيف «دولة» آلي من اسم جهة العمل كما كتبها الكفيل (وزارة، هيئة، دائرة، مديرية، جامعة، شركة عامة…).</p></div>`;
      wireX({ emp: () => exportCsv('mof-employers', ['جهة العمل', 'دولة', 'الكفلاء', 'القروض'], E.map(e => [e.employer, e.gov ? 'نعم' : 'لا', e.n, e.loans])) });
    },
    sub() {
      const draw = () => {
        const hh = F.scope === 'household';
        const profit = hh ? t.profit_household : t.profit_funded + t.profit_pipeline;
        const n = hh ? t.n_household : t.apps, term = t.avg_term || 60;
        const cost = profit * F.sub / 100, perYear = cost / (term / 12), perLoanMonth = n ? cost / n / term : 0;
        body.querySelector('[data-res]').innerHTML = `<div class="grid g3">
          ${kpi('الكلفة الكلية على الموازنة', iqd(cost), `على مدى <span class="num">${num(term)}</span> شهراً`, true)}
          ${kpi('الكلفة السنوية التقريبية', iqd(perYear))}
          ${kpi('ما يوفّره كل مقترض شهرياً', iqd(perLoanMonth), `<span class="num">${num(n)}</span> قرضاً ضمن النطاق`)}</div>`;
      };
      body.innerHTML = `<div class="card mb"><h3>محاكي دعم الفائدة</h3>
        <p class="small muted">إن تحمّلت الموازنة جزءاً من أرباح المصارف على قروض المبادرة، كم يكلّف ذلك؟ المحاكي يحسب من القروض القائمة فعلاً. لا يغيّر شيئاً في المعاملات — هو أداة قرار.</p>
        <div class="seg mb">${[['household', 'القروض المنزلية فقط'], ['all', 'كل القروض']].map(([k, l]) => `<label class="${F.scope === k ? 'on' : ''}"><input type="radio" name="scope" value="${k}" ${F.scope === k ? 'checked' : ''}>${l}</label>`).join('')}</div>
        <label class="lbl">نسبة الفائدة التي تتحملها الوزارة: <b class="num" data-pv>${F.sub}%</b></label>
        <input type="range" min="0" max="100" step="5" value="${F.sub}" data-sub style="width:100%">
        <div class="mt" data-res></div></div>`;
      body.querySelector('[data-sub]').oninput = e => { F.sub = +e.target.value; body.querySelector('[data-pv]').textContent = `${F.sub}%`; draw(); };
      body.querySelectorAll('input[name=scope]').forEach(r => r.onchange = () => { F.scope = r.value; views.sub(); });
      draw();
    },
    cus() {
      const M = c.monthly || [], mx = Math.max(1, ...M.map(m => m.avg));
      const cut = String(d.customs_date || '').slice(0, 7);
      body.innerHTML = `<div class="notice"><span>🚢</span><span>قرر مجلس الوزراء في <b class="num">${esc(d.customs_date)}</b> تصفير الرسوم الكمركية على الألواح الشمسية المستوردة. الهيئة العامة للكمارك تابعة لوزارة المالية — وهنا تتابع الوزارة هل وصل أثر الإعفاء إلى المقترض في سعر الكيلوواط.</span></div>
        <div class="grid g3 mb">
          ${kpi('متوسط سعر الكيلوواط قبل القرار', c.before?.avg ? iqd(c.before.avg) : '—', `<span class="num">${num(c.before?.n)}</span> طلباً`)}
          ${kpi('متوسط سعر الكيلوواط بعد القرار', c.after?.avg ? iqd(c.after.avg) : '—', `<span class="num">${num(c.after?.n)}</span> طلباً`, true)}
          ${kpi('التغيّر', drop == null ? 'لا بيانات كافية بعد' : `${drop >= 0 ? '▼ انخفض' : '▲ ارتفع'} ${pct(Math.abs(drop))}`, drop != null && drop < 2 ? 'الأثر لم يظهر في الأسعار بعد — يمكن إصدار تعميم للموردين' : '')}
        </div>
        <div class="card"><h3>متوسط سعر الكيلوواط شهرياً</h3>
        ${M.map(m => `<div class="row" style="gap:10px;margin:6px 0"><span class="num small" style="width:64px">${esc(m.m)}</span>${bar(m.avg, mx, m.m >= cut ? 'var(--cyan)' : 'var(--indigo)')}<span style="width:150px">${iqd(m.avg)}</span><span class="small muted num">${num(m.n)}</span></div>`).join('') || '<p class="empty">لا بيانات</p>'}
        <p class="small muted">الأشهر بعد القرار بلون مختلف.</p></div>`;
    },
    tax() {
      const T = d.tax || {}, S = T.suppliers || [], mx = Math.max(1, ...S.map(x => x.sales));
      body.innerHTML = `<div class="notice"><span>🧾</span><span>المبيعات والأرباح المتحققة عبر المنصة موثقة بالكامل — تساعد الهيئة العامة للضرائب على مطابقة إقرارات الموردين والمصارف.</span></div>
        <div class="grid g3 mb">
          ${kpi('مبيعات الموردين (قروض مموّلة)', mln(S.reduce((a, x) => a + Number(x.sales), 0)), '', true)}
          ${kpi('أرباح المصارف على القروض المموّلة', mln(T.bank_profit), 'على مدى عمر القروض')}
          ${kpi('عمولة المنصة المستقطعة', mln(T.platform_commission))}
        </div>
        <div class="card flush"><div class="row" style="padding:14px 16px"><h3 style="margin:0">مبيعات كل مورد</h3><span class="sp"></span>${xBtn('sup')}</div>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>المورد</th><th>المنظومات</th><th>المبيعات</th><th></th></tr></thead><tbody>
        ${S.map(x => `<tr><td>${esc(x.name)}</td><td class="num">${num(x.n)}</td><td>${iqd(x.sales)}</td><td>${bar(x.sales, mx)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">لا مبيعات بعد</td></tr>'}
        </tbody></table></div></div>`;
      wireX({ sup: () => exportCsv('mof-suppliers', ['المورد', 'المنظومات', 'المبيعات'], S.map(x => [x.name, x.n, x.sales])) });
    },
    dist() {
      const G = d.by_gov || [], Q = d.by_sector || [], mg = Math.max(1, ...G.map(x => x.amount)), mq = Math.max(1, ...Q.map(x => x.amount));
      body.innerHTML = `<div class="grid g2">
        <div class="card"><h3>المحافظات</h3>${G.map(x => `<div class="row" style="gap:10px;margin:6px 0"><span style="width:90px">${esc(x.gov)}</span>${bar(x.amount, mg)}<span style="width:110px">${mln(x.amount)}</span></div>`).join('') || '<p class="empty">لا بيانات</p>'}</div>
        <div class="card"><h3>القطاعات</h3>${Q.map(x => `<div class="row" style="gap:10px;margin:6px 0"><span style="width:120px">${esc(sectorName(x.key))}</span>${bar(x.amount, mq, SECTORS[x.key]?.[1])}<span style="width:110px">${mln(x.amount)}</span></div>`).join('') || '<p class="empty">لا بيانات</p>'}</div></div>`;
    },
    circ() {
      const C = d.circulars || [];
      body.innerHTML = `<div class="row mb"><p class="small muted" style="margin:0">التعميم الصادر يصل إشعاراً فورياً إلى كل موظفي الجهات المختارة، ولا يُعدَّل بعد صدوره — يُسحب بسبب مكتوب.</p><span class="sp"></span>
        ${d.can_edit ? '<button class="btn cyan" data-new>+ تعميم جديد</button>' : ''}</div>
        ${C.map(x => `<div class="card mb"><div class="row" style="flex-wrap:wrap;gap:8px"><b>${esc(x.title)}</b>${badge(CST[x.status])}<span class="badge muted">${esc(KIND[x.kind] || x.kind)}</span>
          ${x.ref_no ? `<span class="num small">${esc(x.ref_no)}</span>` : ''}<span class="sp"></span>
          ${d.can_edit && x.status === 'draft' ? `<button class="btn sm ghost" data-ed="${x.id}">تعديل</button><button class="btn sm ghost" data-del="${x.id}">حذف</button><button class="btn sm cyan" data-iss="${x.id}">إصدار</button>` : ''}
          ${d.can_edit && x.status === 'issued' ? `<button class="btn sm ghost" data-wd="${x.id}">سحب</button>` : ''}</div>
          <p style="white-space:pre-wrap;margin:8px 0">${esc(x.body)}</p>
          <p class="small muted" style="margin:0">إلى: ${(x.targets || []).map(k => esc(TARGET[k] || k)).join('، ')}${x.effective_date ? ` · نافذ من <span class="num">${esc(x.effective_date)}</span>` : ''}
          ${x.issued_at ? ` · صدر ${dt(x.issued_at)} — ${esc(x.issued_by_name || '')}` : ''}${x.withdrawn_at ? ` · سُحب ${dt(x.withdrawn_at)}: ${esc(x.withdraw_reason || '')}` : ''}</p></div>`).join('') || '<div class="card empty">لا تعاميم بعد.</div>'}`;
      const act = async (fn, args, ok) => { try { const r = await rpc(sb, fn, args); toast(ok(r), 'ok'); render(ctx); } catch (e) { toast(cleanErr(e), 'bad'); } };
      const nb = body.querySelector('[data-new]'); if (nb) nb.onclick = () => editor(ctx, null);
      body.querySelectorAll('[data-ed]').forEach(b => b.onclick = () => editor(ctx, C.find(x => x.id === b.dataset.ed)));
      body.querySelectorAll('[data-del]').forEach(b => b.onclick = () => confirm('حذف المسودة؟') && act('finance_delete_draft', { p_id: b.dataset.del }, () => 'حُذفت المسودة'));
      body.querySelectorAll('[data-iss]').forEach(b => b.onclick = () => confirm('إصدار التعميم؟ يصل فوراً إلى الجهات المختارة ولا يُعدَّل بعده.') && act('finance_issue_circular', { p_id: b.dataset.iss }, r => `صدر التعميم ${r}`));
      body.querySelectorAll('[data-wd]').forEach(b => b.onclick = () => { const r = prompt('سبب سحب التعميم:'); if (r) act('finance_withdraw_circular', { p_id: b.dataset.wd, p_reason: r }, () => 'سُحب التعميم وأُبلغت الجهات'); });
    },
    log() {
      body.innerHTML = `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الوقت</th><th>من</th><th>الإجراء</th><th>على</th><th>السبب</th></tr></thead><tbody>
        ${(d.log || []).map(l => `<tr><td class="small muted">${dt(l.at)}</td><td class="small">${esc(l.by_name || '')} <span class="num muted">${esc(l.by_code || '')}</span></td><td><b class="small">${esc(l.action)}</b></td><td class="small">${esc(l.target || '')}</td><td class="small muted">${esc(l.reason || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">لا إجراءات بعد</td></tr>'}
        </tbody></table></div></div>`;
    },
  };
  const show = k => (views[k] || views.sum)();
  show(F.tab);
}

function editor(ctx, x) {
  const m = modal(`<h3>${x ? 'تعديل مسودة التعميم' : 'تعميم جديد'}</h3>
    <div class="field"><label>النوع</label><select class="input" data-k>${Object.entries(KIND).map(([k, l]) => `<option value="${k}" ${x?.kind === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="field"><label>العنوان ★</label><input class="input" data-t maxlength="160" value="${esc(x?.title || '')}"></div>
    <div class="field"><label>نص التعميم ★</label><textarea class="input" data-b rows="6">${esc(x?.body || '')}</textarea></div>
    <div class="field"><label>يصل إلى ★</label><div class="chips">${Object.entries(TARGET).map(([k, l]) => `<label class="chip ${(x?.targets || ['bank']).includes(k) ? 'on' : ''}"><input type="checkbox" value="${k}" ${(x?.targets || ['bank']).includes(k) ? 'checked' : ''}>${l}</label>`).join('')}</div></div>
    <div class="field"><label>نافذ من (اختياري)</label><input class="input" type="date" data-e value="${esc(x?.effective_date || '')}"></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-s>حفظ كمسودة</button></div>`, { wide: true });
  const q = s => m.el.querySelector(s);
  m.el.querySelectorAll('.chip input').forEach(i => i.onchange = () => i.parentElement.classList.toggle('on', i.checked));
  q('[data-s]').onclick = async () => {
    try {
      await rpc(ctx.sb, 'finance_save_circular', { p: { id: x?.id || null, kind: q('[data-k]').value, title: q('[data-t]').value, body: q('[data-b]').value,
        targets: [...m.el.querySelectorAll('.chip input:checked')].map(i => i.value), effective_date: q('[data-e]').value || null } });
      toast('حُفظت المسودة — راجعها ثم اضغط «إصدار»', 'ok'); m.close(); render(ctx);
    } catch (e) { toast(cleanErr(e), 'bad'); }
  };
}
