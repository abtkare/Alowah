// الجلسة 32: بوابة وزارة التجارة — معاملة التأييد تمر على أقسام الوزارة بالتسلسل
//   الموارد البشرية ← الحسابات والرواتب ← وحدة الكفالات ← (النظام يحتسب الملاءة) ← المسؤول الإداري ← صاحب الصلاحية
// لكل موظف صندوق بدوره فقط، وزر واحد في أسفل المعاملة. كل فتح لملف موظف يُسجَّل.
// مدير الجهة (trade_officer) يتابع ويدير الفريق ويضبط نسبة الاستقطاع القصوى — دون إجراء على المعاملات.
import { esc, el, iqd, num, kpi, badge, dt, ago, rpc, toast, cleanErr, closeDrawer, tabs, ECHK_STATUS, EMPLOYMENT, PURPOSE } from '../core.js';

export const shouldRefresh = () => !document.querySelector('.drawer');

const STAGES = [['hr', 'الموارد البشرية'], ['payroll', 'الحسابات والرواتب'], ['guarantees', 'وحدة الكفالات'], ['admin', 'المسؤول الإداري'], ['signer', 'صاحب الصلاحية']];
const STAGE_FULL = { hr: 'الموارد البشرية وشؤون الموظفين', payroll: 'الحسابات والرواتب', guarantees: 'وحدة الكفالات والالتزامات', admin: 'المسؤول الإداري المخوَّل', signer: 'صاحب الصلاحية', done: 'منجزة', cancelled: 'ملغاة' };
const EMP_NOW = { on_duty: 'مستمر بالخدمة', leave: 'في إجازة', transferred: 'منقول', suspended: 'موقوف عن العمل', separated: 'منفك عن الخدمة', retired: 'محال على التقاعد' };
const RES_KIND = { ok: 'ok', admin_review: 'warn', incomplete: 'muted' };
const resBadge = (r, l) => r ? badge([l || r, RES_KIND[r] || 'bad']) : '';
const stageBadge = c => c.wf_stage === 'done' ? badge(ECHK_STATUS[c.status] || [c.status, 'muted']) : c.wf_stage === 'cancelled' ? badge(['ملغاة', 'muted'])
  : badge([`لدى: ${STAGE_FULL[c.wf_stage] || c.wf_stage}`, c.late ? 'bad' : 'warn']);
const n0 = v => Number(String(v ?? '').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g, '')) || 0;

export async function render(ctx) {
  const { sb, root, org, profile } = ctx;
  let d;
  try { d = await rpc(sb, 'trade_inbox', {}); }
  catch (e) {
    root.innerHTML = `<div class="card empty">${/trade_inbox|my_stage/.test(cleanErr(e)) ? 'لم يُطبَّق تحديث الجلسة 32 على قاعدة البيانات بعد — افتح ‎/migrate‎' : esc(cleanErr(e))}</div>`;
    return;
  }
  if (!('my_stage' in d)) { root.innerHTML = '<div class="card empty">لم يُطبَّق تحديث الجلسة 32 على قاعدة البيانات بعد — افتح ‎/migrate‎</div>'; return; }
  const all = d.checks || [], st = d.stats || {}, bs = st.by_stage || {};
  const mine = d.my_stage ? all.filter(c => c.wf_stage === d.my_stage && c.status === 'pending') : [];
  const open = all.filter(c => c.status === 'pending');
  const lateN = open.filter(c => c.late).length;

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org?.name || 'وزارة التجارة')} — التحقق الوظيفي والمالي</h1>
      <p>${esc(profile.position_title || d.role_title)}. ${d.my_stage ? `صندوقك: <b>${esc(STAGE_FULL[d.my_stage])}</b> — تصلك المعاملة حين يأتي دور قسمك، وتنتقل للقسم التالي بزر واحد.` : 'متابعة المعاملات في كل الأقسام، وإدارة الفريق ونسب الاستقطاع.'}</p></div></div>
    <div class="card mb"><div class="row" style="gap:6px;flex-wrap:wrap;align-items:stretch">
      ${STAGES.map(([k, t], i) => `<div style="flex:1 1 110px;border:1.5px solid ${k === d.my_stage ? 'var(--indigo)' : 'var(--line)'};border-radius:12px;padding:8px 10px;background:${k === d.my_stage ? '#EEF1FB' : 'var(--surface)'}">
        <div class="small muted"><span class="num">${i + 1}</span>. ${esc(t)}</div><b class="num" style="font-size:20px">${bs[k] || 0}</b></div>`).join('')}
    </div><p class="small muted" style="margin:8px 0 0">عدد المعاملات الموجودة الآن لدى كل قسم. بعد وحدة الكفالات يحتسب النظام الملاءة آلياً قبل وصولها للمسؤول الإداري.</p></div>
    <div class="grid g4 mb">
      ${d.my_stage ? kpi('بانتظارك الآن', `<span class="num">${mine.length}</span>`, STAGE_FULL[d.my_stage], true) : kpi('قيد التدقيق', `<span class="num">${st.pending || 0}</span>`, 'في كل الأقسام', true)}
      ${kpi('متأخرة', `<span class="num">${st.late || 0}</span>`, `أكثر من ${num(d.sla_hours)} ساعة لدى قسم`)}
      ${kpi('أيّدتها الوزارة', `<span class="num">${st.approved || 0}</span>`, `رُفض <span class="num">${st.rejected || 0}</span>`)}
      ${kpi('متوسط الإنجاز', st.avg_hours == null ? '—' : `<span class="num">${st.avg_hours}</span> ساعة`, 'من الوصول حتى اعتماد صاحب الصلاحية')}
    </div>
    ${lateN && d.my_stage ? `<div class="notice warn mb"><span>⏱</span><span>توجد <b class="num">${lateN}</b> معاملة متأخرة في الوزارة — يُشعَر المسؤول بالتأخير.</span></div>` : ''}
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [
    ...(d.my_stage ? [{ key: 'mine', label: 'صندوقي', count: mine.length }] : []),
    { key: 'open', label: 'قيد التدقيق', count: open.length }, { key: 'all', label: 'كل المعاملات' },
    { key: 'stats', label: 'التحليل' }, { key: 'limits', label: 'نسب الاستقطاع' }];
  ctx.trTab = defs.find(x => x.key === ctx.trTab) ? ctx.trTab : defs[0].key;
  tabs(root.querySelector('#tabs'), defs, k => { ctx.trTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.trTab));

  function show(k) {
    if (k === 'stats') return showStats();
    if (k === 'limits') return showLimits();
    const list = k === 'mine' ? mine : k === 'open' ? open : all;
    body.innerHTML = list.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th>المعاملة</th><th>الموظف</th><th>الدائرة</th><th>المصرف</th><th>أين وصلت</th><th>النتيجة الأولية</th><th>ورد</th></tr></thead><tbody>
      ${list.map((c, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(c.code)}</b><div class="small muted num">${esc(c.inbox_no || '')}</div></td>
        <td><b>${esc(c.guarantor_name)}</b><div class="small muted">${c.kind === 'borrower' ? 'مقترض' : 'كفيل'} · طلب <span class="num">${esc(c.app_code)}</span></div></td>
        <td class="small">${esc(c.dept || '—')}</td><td class="small">${esc(c.bank_name || '—')}</td>
        <td>${stageBadge(c)}${c.status === 'pending' ? `<div class="small muted">منذ <span class="num">${c.hours}</span> ساعة${c.returns ? ` · أُعيدت <span class="num">${c.returns}</span>` : ''}</div>` : ''}</td>
        <td>${resBadge(c.result, c.result_label) || '<span class="muted small">—</span>'}</td><td class="muted small">${ago(c.created_at)}</td></tr>`).join('')}
      </tbody></table></div></div>`
      : `<div class="card empty">${k === 'mine' ? '✓ لا معاملات تنتظر قسمك الآن.' : 'لا معاملات.'}</div>`;
    body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openCheck(list[+tr.dataset.i].id));
  }

  function bars(rows, color) {
    const max = Math.max(1, ...rows.map(x => x.n));
    return rows.map(x => `<div class="mb"><div class="row small"><span>${esc(x.label)}</span><span class="sp"></span><b class="num">${x.n}</b></div>
      <div class="bar"><i style="width:${x.n / max * 100}%;background:${color}"></i></div></div>`).join('');
  }
  function showStats() {
    const br = st.by_reason || [], bd = st.by_dept || [], rs = st.by_result || [], rt = st.returns || [], sh = st.stage_hours || {};
    body.innerHTML = `<div class="grid g2">
      <div class="card"><h3>متوسط بقاء المعاملة لدى كل قسم</h3>${STAGES.map(([k, t]) => `<div class="row small mb"><span>${esc(t)}</span><span class="sp"></span><b class="num">${sh[k] ?? '—'}</b>&nbsp;ساعة</div>`).join('')}
        <p class="small muted" style="margin:0">نسبة المعاملات التي تجاوزت مدة الإنجاز الكلية: <b class="num">${st.late_rate ?? 0}%</b></p></div>
      <div class="card"><h3>النتائج الأولية للاحتساب</h3>${rs.length ? bars(rs, 'var(--indigo)') : '<p class="muted small" style="margin:0">لا احتساب بعد.</p>'}</div>
      <div class="card"><h3>أسباب الرفض</h3>${br.length ? bars(br, 'var(--bad)') : '<p class="muted small" style="margin:0">لا رفض بعد.</p>'}</div>
      <div class="card"><h3>أسباب الإعادة للأقسام</h3>${rt.length ? rt.slice(0, 12).map(x => `<div class="small mb"><b>${esc(x.to)}</b> · <span class="num">${esc(x.code)}</span> · <span class="muted">${ago(x.at)}</span><br>${esc(x.note || '')}</div>`).join('') : '<p class="muted small" style="margin:0">لا إعادات.</p>'}</div>
      <div class="card"><h3>حسب الدائرة</h3>${bd.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>الدائرة</th><th>المعاملات</th><th>أُيّدت</th><th>رُفضت</th></tr></thead><tbody>
        ${bd.map(x => `<tr><td>${esc(x.dept)}</td><td class="num">${x.n}</td><td class="num">${x.ok}</td><td class="num">${x.bad}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small" style="margin:0">لا معاملات بعد.</p>'}</div></div>`;
  }

  // نسبة الاستقطاع القصوى: افتراضية، ولكل غرض تمويل، ولكل مصرف — الأخص يغلب
  async function showLimits() {
    body.innerHTML = '<div class="card empty">…</div>';
    let L;
    try { L = await rpc(sb, 'trade_limits', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
    const paint = () => {
      body.innerHTML = `<div class="notice mb"><span>⚖</span><span class="small">أقصى نسبة تُستقطع من <b>الراتب الصافي</b> لكل الأقساط والسلف والحجوزات والكفالات معاً. تُضبط وفق تعليمات البنك المركزي وضوابط كل مصرف، ويمكن أن تختلف لكل غرض تمويل ولكل مصرف. عند الاحتساب تُطبَّق <b>النسبة الأخص</b>: غرض ومصرف ← مصرف ← غرض ← الافتراضية.</span></div>
        <div class="card flush mb"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الغرض</th><th>المصرف</th><th>النسبة</th><th>آخر تعديل</th>${L.can_edit ? '<th></th>' : ''}</tr></thead><tbody>
        ${L.rows.map((r, i) => `<tr><td>${esc(r.purpose_label)}</td><td>${esc(r.bank)}</td><td><b class="num">${r.pct}%</b>${r.note ? `<div class="small muted">${esc(r.note)}</div>` : ''}</td>
          <td class="small muted">${esc(r.by || '')}<br>${dt(r.at)}</td>${L.can_edit ? `<td>${r.purpose || r.bank_id ? `<button class="linkbtn small" data-del="${i}">حذف</button>` : ''}</td>` : ''}</tr>`).join('')}</tbody></table></div></div>
        ${L.can_edit ? `<div class="card"><h3>إضافة نسبة أو تعديلها</h3>
          <div class="grid g2"><div class="field"><label>غرض التمويل</label><select class="input" data-pur><option value="">كل الأغراض</option>${Object.entries(PURPOSE).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></div>
          <div class="field"><label>المصرف</label><select class="input" data-bank><option value="">كل المصارف</option>${L.banks.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('')}</select></div>
          <div class="field"><label>النسبة القصوى من الصافي (%)</label><input class="input" data-pct inputmode="numeric" dir="ltr" placeholder="50"></div>
          <div class="field"><label>المرجع (تعميم أو كتاب) — اختياري</label><input class="input" data-note></div></div>
          <div class="row"><span class="sp"></span><button class="btn ok" data-save>حفظ النسبة</button></div></div>`
        : '<p class="small muted">التعديل من صلاحية مدير الجهة في الوزارة أو مشغّل النظام.</p>'}`;
      body.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
        const r = L.rows[+b.dataset.del]; b.disabled = true;
        try { L = await rpc(sb, 'trade_set_limit', { p: { purpose: r.purpose || '', bank_id: r.bank_id || '', delete: true } }); toast('حُذفت النسبة', 'ok'); paint(); }
        catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
      });
      const sv = body.querySelector('[data-save]');
      if (sv) sv.onclick = async () => {
        const q = s => body.querySelector(s).value;
        sv.disabled = true;
        try { L = await rpc(sb, 'trade_set_limit', { p: { purpose: q('[data-pur]'), bank_id: q('[data-bank]'), pct: n0(q('[data-pct]')) || '', note: q('[data-note]') } }); toast('حُفظت النسبة — تُطبَّق على كل احتساب قادم', 'ok'); paint(); }
        catch (e) { toast(cleanErr(e), 'bad'); sv.disabled = false; }
      };
    };
    paint();
  }
  show(ctx.trTab);

  // ───────── ملف المعاملة ─────────
  async function openCheck(id) {
    closeDrawer();
    let c;
    try { c = await rpc(sb, 'trade_check', { p_id: id }); } catch (e) { return toast(cleanErr(e), 'bad'); }
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer"><div class="dh"><div><div class="small" style="color:#8FA3C0">معاملة تأييد ${c.kind === 'borrower' ? 'موظف مقترض' : 'موظف كفيل'} · وارد <span class="num">${esc(c.inbox_no || '')}</span></div><h2 class="num">${esc(c.code)}</h2></div><span class="sp"></span>${stageBadge(c)}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">${fileHtml(c)}</div><div class="df"><div class="row" data-foot style="width:100%"></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;
    const foot = dr.querySelector('[data-foot]'), box = dr.querySelector('[data-form]');
    if (c.can_act && box) FORMS[c.wf_stage](c, box, foot);
    else foot.innerHTML = `<p class="muted small" style="margin:0">${c.status !== 'pending' ? 'المعاملة منجزة — لا إجراء.' : `المعاملة الآن لدى: <b>${esc(STAGE_FULL[c.wf_stage])}</b>. الاطلاع فقط.`}</p>`;
  }

  function fileHtml(c) {
    const idx = STAGES.findIndex(([k]) => k === c.wf_stage);
    const done = c.wf_stage === 'done';
    const steps = `<div class="card mb"><div class="row" style="gap:4px;flex-wrap:wrap">${STAGES.map(([k, t], i) => {
      const s = done || i < idx ? 'ok' : i === idx ? 'warn' : 'muted';
      return `<span class="badge ${s}" style="flex:1 1 auto;justify-content:center">${s === 'ok' ? '✓' : `<span class="num">${i + 1}</span>`} ${esc(t)}</span>`; }).join('')}</div>
      ${c.returns ? `<p class="small muted" style="margin:8px 0 0">أُعيدت هذه المعاملة لاستكمال النواقص <b class="num">${c.returns}</b> مرة — الأسباب في السجل أدناه.</p>` : ''}</div>`;
    const letter = `<div class="card mb letter" style="line-height:1.9">
      <p style="margin:0"><b>إلى/ وزارة التجارة — ${esc(c.dept || 'الدائرة المختصة')}</b></p>
      <p style="margin:0"><b>م/ تأييد استمرار خدمة وراتب ${c.kind === 'borrower' ? '(موظف طالب تمويل)' : '(كفيل)'}</b></p>
      <p style="margin:8px 0 0">يرجى تأييد استمرار خدمة السيد/ة <b>${esc(c.guarantor_name)}</b>${c.guarantor_nid ? ` (الرقم الوطني <span class="num">${esc(c.guarantor_nid)}</span>)` : ''} وبيان مفردات راتبه واستقطاعاته وقروضه وكفالاته القائمة،
      ${c.kind === 'borrower' ? 'لطلبه' : `بصفته كفيلاً للمقترض <b>${esc(c.borrower || '')}</b> في`} طلب التمويل <b class="num">${esc(c.app_code)}</b> لدى <b>${esc(c.bank_name || '')}</b>.</p>
      <p class="small muted" style="margin:6px 0 0">ورد آلياً من منصة «ألواح» · ${dt(c.created_at)} · بموافقة صاحب العلاقة على معالجة بياناته (رمز التحقق)</p></div>`;
    const req = `<div class="card mb"><h3>ما يطلبه التمويل</h3><dl class="kv">
      <dt>الغرض والمبلغ</dt><dd>${esc(c.purpose_label || '—')} · ${iqd(c.amount)} على <span class="num">${num(c.term_months || 0)}</span> شهراً</dd>
      <dt>القسط الشهري</dt><dd>${iqd(c.installment)}${c.kind !== 'borrower' && c.guarantors_n > 1 ? ` — يتقاسمه <span class="num">${c.guarantors_n}</span> كفلاء` : ''}</dd>
      ${c.kind !== 'borrower' ? `<dt>حصة هذا الكفيل</dt><dd><b>${iqd(c.share)}</b> شهرياً</dd>` : ''}
      <dt>نسبة الاستقطاع القصوى</dt><dd><b class="num">${c.pct}%</b> من الراتب الصافي <span class="muted small">(لهذا الغرض وهذا المصرف)</span></dd>
      ${c.declared_salary ? `<dt>الراتب كما ذكره المقترض</dt><dd>${iqd(c.declared_salary)} <span class="muted small">— يُدقَّق من سجلكم</span></dd>` : ''}</dl></div>`;
    const sec = (k, title, data, rows) => {
      const here = c.wf_stage === k && c.status === 'pending';
      return `<div class="card mb" ${here ? 'style="border:2px solid var(--indigo)"' : ''}><h3>${esc(title)} ${data ? badge(['أُنجز', 'ok']) : here ? badge(['دوره الآن', 'warn']) : badge(['لم يصل بعد', 'muted'])}</h3>
        ${data ? `<dl class="kv">${rows(data)}<dt>المنفّذ</dt><dd>${esc(data.by || '')} · <span class="num">${esc(data.by_code || '')}</span> · <span class="small muted">${dt(data.at)}</span></dd></dl>` : ''}
        ${here && c.can_act ? '<div data-form></div>' : ''}</div>`;
    };
    const hr = sec('hr', '1. الموارد البشرية — التدقيق الوظيفي', c.hr, h => `
      <dt>نوع التعيين</dt><dd>${esc(EMPLOYMENT[h.employment] || h.employment)}</dd>
      ${h.employee_no ? `<dt>الرقم الوظيفي</dt><dd class="num">${esc(h.employee_no)}</dd>` : ''}
      ${h.status_now ? `<dt>الحالة الحالية</dt><dd>${esc(EMP_NOW[h.status_now] || h.status_now)}</dd>` : ''}
      ${h.job_title ? `<dt>العنوان الوظيفي</dt><dd>${esc(h.job_title)}${h.section ? ` · ${esc(h.section)}` : ''}</dd>` : ''}
      ${h.appoint_date ? `<dt>التعيين / المباشرة</dt><dd class="num">${esc(h.appoint_date)}${h.start_date ? ` / ${esc(h.start_date)}` : ''}</dd>` : ''}
      ${h.note ? `<dt>ملاحظة</dt><dd>${esc(h.note)}</dd>` : ''}`);
    const pay = sec('payroll', '2. الحسابات والرواتب — التدقيق المالي', c.payroll, p => `
      <dt>الاسمي + المخصصات</dt><dd>${iqd(p.nominal)} + ${iqd(p.allowances)} = <b>${iqd(p.gross)}</b></dd>
      <dt>الاستقطاعات القانونية</dt><dd>${iqd(p.legal_deductions)}</dd><dt>الصافي</dt><dd><b>${iqd(p.net)}</b></dd>
      <dt>السلف / القروض / الحجوزات</dt><dd>${iqd(p.advances_monthly)} · ${iqd(p.loans_monthly)} · ${iqd(p.garnish_monthly)} <span class="small muted">شهرياً</span></dd>
      ${p.note ? `<dt>ملاحظة</dt><dd>${esc(p.note)}</dd>` : ''}`);
    const plat = (c.platform_guarantees || []);
    const grt = sec('guarantees', '3. وحدة الكفالات والالتزامات', c.guarantees, g => `
      <dt>الكفالات القائمة</dt><dd><span class="num">${g.active_count}</span> كفالة · أقساطها ${iqd(g.active_monthly)} شهرياً${g.active_amount ? ` · مبالغها ${iqd(g.active_amount)}` : ''}</dd>
      <dt>المنتهية / إخلاء الطرف</dt><dd class="num">${g.ended_count || 0}</dd>
      ${g.note ? `<dt>ملاحظة</dt><dd>${esc(g.note)}</dd>` : ''}`)
      .replace(/<\/h3>/, `</h3>${plat.length ? `<div class="notice warn mb"><span>⚑</span><span class="small"><b>كفالات قائمة لهذا الموظف في منصة «ألواح»:</b><br>${plat.map(x => `<span class="num">${esc(x.app)}</span> · ${esc(x.bank || '')} · حصته ${iqd(x.share)}`).join('<br>')}<br>تُحتسب في الالتزامات إن كانت أكبر مما في سجلكم.</span></div>` : ''}`);
    const k = c.calc;
    const calc = k ? `<div class="card mb verdict ${k.result === 'ok' ? 'ok' : ['incomplete', 'admin_review'].includes(k.result) ? '' : 'bad'}"><h3 style="margin:0 0 6px">احتساب الملاءة: ${esc(k.label || '')}</h3>
      ${k.max_deduct != null ? `<dl class="kv" style="color:var(--text)"><dt>الحد الأقصى للاستقطاع</dt><dd>${iqd(k.max_deduct)} <span class="small muted">(${k.pct}% من الصافي)</span></dd>
        <dt>الأقساط والسلف والحجوزات</dt><dd>− ${iqd(k.commitments)}</dd><dt>التزامات الكفالات</dt><dd>− ${iqd(k.guarantee_obligations)}</dd>
        <dt>القدرة المتاحة</dt><dd><b>${iqd(k.available)}</b></dd><dt>المطلوب</dt><dd><b>${iqd(k.need)}</b> ${k.need <= k.available ? '✓' : '✗'}</dd></dl>
        <p class="small muted" style="margin:6px 0 0">${esc(k.formula || '')}</p>` : ''}
      <p class="small muted" style="margin:6px 0 0">نتيجة أولية آلية تُحفظ مدخلاتها ومعادلتها — القرار النهائي لصاحب الصلاحية. سجل الوزارة لا يُثبت عدم وجود كفالات لدى جهات أخرى.</p></div>` : '';
    const adm = sec('admin', '4. المسؤول الإداري — المراجعة والتوصية', c.admin, a => `
      <dt>التوصية</dt><dd>${a.recommendation === 'approve' ? badge(['التأييد', 'ok']) : badge(['الرفض', 'bad'])}</dd>${a.note ? `<dt>المسوّغ</dt><dd>${esc(a.note)}</dd>` : ''}`);
    const sig = sec('signer', '5. صاحب الصلاحية — الاعتماد', c.signer, s => `
      <dt>القرار</dt><dd>${s.decision === 'approve' ? badge(['اعتماد التأييد', 'ok']) : badge(['رفض مسبَّب', 'bad'])}</dd>
      ${(c.reason_labels || []).length ? `<dt>الأسباب</dt><dd>${c.reason_labels.map(x => `<div>★ ${esc(x)}</div>`).join('')}</dd>` : ''}
      ${s.note ? `<dt>ملاحظة</dt><dd>${esc(s.note)}</dd>` : ''}<dt>بصمة القرار</dt><dd class="num small" style="word-break:break-all">${esc(s.seal || '')}</dd>`);
    const log = `<div class="card mb"><h3>سجل المعاملة</h3>${(c.log || []).map(l => `<div class="small mb" style="border-inline-start:3px solid ${/^إعادة/.test(l.action) ? 'var(--warn)' : 'var(--line)'};padding-inline-start:8px">
        <b>${esc(l.action)}</b>${l.note ? `<br>${esc(l.note)}` : ''}<br><span class="muted">${esc(l.by || '')}${l.code ? ` · <span class="num">${esc(l.code)}</span>` : ''}${l.title ? ` · ${esc(l.title)}` : ''} · ${dt(l.at)}</span></div>`).join('')}
      <p class="small muted" style="margin:0">فُتح هذا الملف <b class="num">${c.views}</b> مرة — كل اطلاع يُسجَّل باسم صاحبه.</p>
      ${c.viewers ? `<details class="small mt"><summary>من اطّلع</summary>${c.viewers.map(v => `<div>${esc(v.name)} · <span class="num">${esc(v.code || '')}</span> · ${dt(v.at)}</div>`).join('')}</details>` : ''}</div>`;
    return steps + letter + req + hr + pay + grt + calc + adm + sig + log;
  }

  // ───────── نماذج الأقسام: أسئلة قليلة، وزر واحد ─────────
  const confirmBox = t => `<label class="row small mt" style="gap:8px;align-items:flex-start"><input type="checkbox" data-confirm style="margin-top:4px"><span>${t}</span></label>`;
  const segHtml = (key, opts) => `<div class="seg wrap" data-seg="${key}">${Object.entries(opts).map(([k, t]) => `<button type="button" data-v="${k}">${esc(t)}</button>`).join('')}</div>`;
  const bindSegs = (box, f, after) => box.querySelectorAll('[data-seg]').forEach(s => s.querySelectorAll('button').forEach(b => b.onclick = () => {
    f[s.dataset.seg] = b.dataset.v; s.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); after && after(); }));
  const bindInputs = (box, f, after) => box.querySelectorAll('[data-k]').forEach(i => i.oninput = () => { f[i.dataset.k] = i.value; after && after(); });
  const send = async (fn, args, btn, okMsg) => {
    btn.disabled = true;
    try { await rpc(sb, fn, args); closeDrawer(); toast(okMsg, 'ok'); ctx.refresh(); }
    catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
  };
  const footBtn = (foot, label, kind = 'ok') => { foot.innerHTML = `<span class="sp"></span><button class="btn ${kind}" data-go>${esc(label)}</button>`; return foot.querySelector('[data-go]'); };
  const money = (k, label, ph = '') => `<div class="field"><label>${label}</label><input class="input" data-k="${k}" inputmode="numeric" dir="ltr" placeholder="${ph}"></div>`;

  const FORMS = {
    hr(c, box, foot) {
      const f = { employment: '', status_now: '' };
      box.innerHTML = `<div class="field"><label>نوع التعيين</label>${segHtml('employment', EMPLOYMENT)}</div>
        <div data-more hidden>
          <div class="field"><label>الحالة الوظيفية الآن</label>${segHtml('status_now', EMP_NOW)}</div>
          <div class="grid g2"><div class="field"><label>الرقم الوظيفي</label><input class="input" data-k="employee_no" dir="ltr"></div>
            <div class="field"><label>العنوان الوظيفي</label><input class="input" data-k="job_title"></div>
            <div class="field"><label>تاريخ التعيين</label><input class="input" type="date" data-k="appoint_date"></div>
            <div class="field"><label>تاريخ المباشرة</label><input class="input" type="date" data-k="start_date"></div>
            <div class="field"><label>القسم أو الشعبة</label><input class="input" data-k="section"></div></div></div>
        <div class="field"><label>ملاحظة (اختيارية)</label><input class="input" data-k="note"></div>
        ${confirmBox('أؤكد أن البيانات منقولة من سجل الموظف الرسمي، وتُسجَّل باسمي ورمزي الوظيفي.')}`;
      const upd = () => { box.querySelector('[data-more]').hidden = !f.employment || f.employment === 'not_found'; };
      bindSegs(box, f, upd); bindInputs(box, f);
      const go = footBtn(foot, 'إنجاز وإحالة إلى الحسابات والرواتب');
      go.onclick = () => send('trade_hr_submit', { p_id: c.id, p: { ...f, confirm: box.querySelector('[data-confirm]').checked } }, go, 'أُنجز التدقيق الوظيفي وأُحيلت المعاملة');
    },
    payroll(c, box, foot) {
      const f = {};
      box.innerHTML = `<div class="grid g2">${money('nominal', 'الراتب الاسمي', '900000')}${money('allowances', 'المخصصات', '250000')}${money('legal_deductions', 'الاستقطاعات القانونية (ضريبة وتقاعد)', '150000')}</div>
        <div class="card mb" style="background:var(--surface-2)" data-sum></div>
        <p class="small" style="margin:0 0 6px"><b>الالتزامات الشهرية المسجلة لدى الوزارة</b> (اكتب 0 إن لم توجد)</p>
        <div class="grid g2">${money('advances_monthly', 'أقساط السلف')}${money('loans_monthly', 'أقساط القروض')}${money('garnish_monthly', 'الحجوزات والاستقطاعات الأخرى')}</div>
        <div class="field"><label>ملاحظة (اختيارية)</label><input class="input" data-k="note"></div>
        ${confirmBox('أؤكد أن المفردات منقولة من سجل الرواتب الرسمي.')}`;
      const sum = () => { const g = n0(f.nominal) + n0(f.allowances), net = g - n0(f.legal_deductions);
        box.querySelector('[data-sum]').innerHTML = `<div class="row small"><span>إجمالي الراتب</span><span class="sp"></span><b>${iqd(g)}</b></div><div class="row small"><span>الصافي</span><span class="sp"></span><b>${iqd(net)}</b></div>`; };
      bindInputs(box, f, sum); sum();
      const go = footBtn(foot, 'إنجاز وإحالة إلى وحدة الكفالات');
      go.onclick = () => send('trade_payroll_submit', { p_id: c.id, p: { ...f, confirm: box.querySelector('[data-confirm]').checked } }, go, 'أُنجز التدقيق المالي وأُحيلت المعاملة');
    },
    guarantees(c, box, foot) {
      const f = {};
      box.innerHTML = `<div class="grid g2"><div class="field"><label>عدد الكفالات القائمة</label><input class="input" data-k="active_count" inputmode="numeric" dir="ltr" placeholder="0"></div>
        ${money('active_monthly', 'مجموع أقساطها الشهرية')}${money('active_amount', 'مجموع مبالغ القروض المكفولة (اختياري)')}
        <div class="field"><label>كفالات منتهية أو أُخلي طرفه منها</label><input class="input" data-k="ended_count" inputmode="numeric" dir="ltr" placeholder="0"></div></div>
        <div class="field"><label>ملاحظة (اختيارية)</label><input class="input" data-k="note"></div>
        ${confirmBox('أؤكد أن البيانات منقولة من سجل الكفالات في الوزارة.')}
        <p class="small muted" style="margin:6px 0 0">بعد الإنجاز يحتسب النظام الملاءة آلياً وتصل النتيجة للمسؤول الإداري.</p>`;
      bindInputs(box, f);
      const go = footBtn(foot, 'إنجاز واحتساب الملاءة');
      go.onclick = () => send('trade_guarantees_submit', { p_id: c.id, p: { ...f, confirm: box.querySelector('[data-confirm]').checked } }, go, 'احتُسبت الملاءة وأُحيلت للمسؤول الإداري');
    },
    admin(c, box, foot) {
      const r = c.calc?.result, canApprove = ['ok', 'admin_review'].includes(r);
      const f = { act: r === 'incomplete' ? 'return' : canApprove ? 'approve' : 'reject', to: '', note: '' };
      box.innerHTML = `<div class="field"><label>الإجراء</label>${segHtml('act', { ...(canApprove ? { approve: 'أوصي بالتأييد' } : {}), ...(r !== 'incomplete' ? { reject: 'أوصي بالرفض' } : {}), return: 'إعادة لقسم' })}</div>
        <div class="field" data-to hidden><label>يُعاد إلى</label>${segHtml('to', { hr: 'الموارد البشرية', payroll: 'الحسابات والرواتب', guarantees: 'وحدة الكفالات' })}</div>
        <div class="field"><label data-nl>ملاحظة</label><textarea class="input" rows="2" data-k="note"></textarea></div>
        ${r === 'admin_review' ? '<p class="small" style="margin:0;color:var(--warn)">الحالة تحتاج موافقة إدارية (عقد أو إجازة أو نقل) — اكتب مسوّغ التأييد.</p>' : ''}`;
      const upd = () => {
        box.querySelectorAll('[data-seg="act"] button').forEach(b => b.classList.toggle('on', b.dataset.v === f.act));
        box.querySelector('[data-to]').hidden = f.act !== 'return';
        box.querySelector('[data-nl]').textContent = f.act === 'return' ? 'سبب الإعادة (النقص أو الخطأ) — إلزامي' : f.act === 'approve' && r === 'admin_review' ? 'مسوّغ التأييد — إلزامي' : f.act === 'reject' && canApprove ? 'سبب الرفض — إلزامي (الموظف مؤهل)' : 'ملاحظة (اختيارية)';
        const go = footBtn(foot, f.act === 'return' ? 'إعادة المعاملة للقسم' : `إحالة لصاحب الصلاحية مع التوصية ب${f.act === 'approve' ? 'التأييد' : 'الرفض'}`, f.act === 'approve' ? 'ok' : f.act === 'return' ? 'warn' : 'bad');
        go.onclick = () => send('trade_admin_act', { p_id: c.id, p: f.act === 'return' ? { action: 'return', to: f.to, note: f.note } : { action: 'forward', recommendation: f.act, note: f.note } }, go,
          f.act === 'return' ? 'أُعيدت المعاملة للقسم' : 'أُحيلت لصاحب الصلاحية');
      };
      bindSegs(box, f, upd); bindInputs(box, f); upd();
    },
    signer(c, box, foot) {
      const r = c.calc?.result, rec = c.admin?.recommendation;
      const canApprove = r === 'ok' || (r === 'admin_review' && rec === 'approve');
      const f = { act: rec === 'approve' && canApprove ? 'approve' : 'reject', to: 'admin', note: '' };
      box.innerHTML = `<div class="notice mb"><span>✎</span><span class="small">توصية المسؤول الإداري: <b>${rec === 'approve' ? 'التأييد' : 'الرفض'}</b>. قرارك هو القرار النهائي للوزارة ويصل المصرف فوراً، ويُحفظ ببصمة رقمية (SHA-256).</span></div>
        <div class="field"><label>القرار</label>${segHtml('act', { ...(canApprove ? { approve: 'اعتماد التأييد' } : {}), reject: 'رفض مسبَّب', return: 'إعادة' })}</div>
        <div class="field" data-to hidden><label>يُعاد إلى</label>${segHtml('to', { admin: 'المسؤول الإداري', hr: 'الموارد البشرية', payroll: 'الحسابات والرواتب', guarantees: 'وحدة الكفالات' })}</div>
        <div class="field"><label data-nl>ملاحظة</label><textarea class="input" rows="2" data-k="note"></textarea></div>
        <div data-cf>${confirmBox('أعتمد هذا القرار بصفتي صاحب الصلاحية، ويُسجَّل باسمي ورمزي الوظيفي.')}</div>`;
      const upd = () => {
        box.querySelectorAll('[data-seg="act"] button').forEach(b => b.classList.toggle('on', b.dataset.v === f.act));
        box.querySelectorAll('[data-seg="to"] button').forEach(b => b.classList.toggle('on', b.dataset.v === f.to));
        box.querySelector('[data-to]').hidden = f.act !== 'return'; box.querySelector('[data-cf]').hidden = f.act === 'return';
        box.querySelector('[data-nl]').textContent = f.act === 'return' ? 'سبب الإعادة — إلزامي' : 'ملاحظة (اختيارية)';
        const go = footBtn(foot, f.act === 'approve' ? 'اعتماد التأييد وإشعار المصرف' : f.act === 'reject' ? 'اعتماد الرفض وإشعار المصرف' : 'إعادة المعاملة', f.act === 'approve' ? 'ok' : f.act === 'return' ? 'warn' : 'bad');
        go.onclick = () => send('trade_signer_act', { p_id: c.id, p: { action: f.act, to: f.to, note: f.note, confirm: !!box.querySelector('[data-confirm]')?.checked } }, go,
          f.act === 'approve' ? 'اعتُمد التأييد وأُشعر المصرف' : f.act === 'reject' ? 'اعتُمد الرفض وأُشعر المصرف' : 'أُعيدت المعاملة');
      };
      bindSegs(box, f, upd); bindInputs(box, f); upd();
    },
  };
}
