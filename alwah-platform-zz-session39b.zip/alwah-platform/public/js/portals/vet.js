// بوابة المقترض — مسار الطبيب البيطري (مبادرة تمويل مشاريع أعضاء نقابة الأطباء البيطريين)
// الخطوات: الهوية ← العضوية وتأييد النقابة ← المشروع والمصرف (موافقة دائرة البيطرة) ← الضمان ← الدفع والإرسال
import { cameraCapture, docThumb } from '../capture.js';
import { wizHead, wireWizHead } from '../wizard-ui.js';
import {
  esc, num, iqd, dt, ago, badge, statusBadge, stageBar, stageList, eventsList, GUARANTEE, rpc, toast, cleanErr, GOVS, govOptions, installment,
  modal, askOtp, digits, el, PAY_METHODS, PAY_LABEL, VET_STEPS, MEMBER_STATUS, VETDEPT_STATUS, TRANCHE_STATUS, MILESTONES
} from '../core.js';

let A;                       // واجهة بوابة المقترض: { S, C(), load, saveStep, pageApply, step1, step4 }
const V = {};                // بيانات المبادرة: الأنواع، عضويتي، مستنداتها، مشروع الطلب الحالي
export function initVet(api) { A = api; }
const C = () => A.C();
const set = () => A.S.ref.set;
const curYear = () => new Date().getFullYear();

export async function loadVet() {
  const { sb, profile } = C();
  const active = A.S.active;
  const [types, mem, proj, docs] = await Promise.all([
    V.types ? V.types : sb.from('vet_project_types').select('*').order('sort').then(r => r.data || []),
    sb.from('vet_memberships').select('*').eq('profile_id', profile.id).maybeSingle().then(r => r.data),
    active?.program === 'vet' ? sb.from('vet_projects').select('*').eq('application_id', active.id).maybeSingle().then(r => r.data) : null,
    active?.program === 'vet' ? sb.from('app_documents').select('id,kind,data,source,meta').eq('application_id', active.id).in('kind', ['quote', 'site']).then(r => r.data || []) : [],
  ]);
  V.types = types; V.mem = mem; V.proj = proj; V.docs = docs;
  V.memDocs = mem ? ((await sb.from('vet_member_docs').select('kind,data,meta').eq('membership_id', mem.id)).data || []) : [];
}
const typeOf = code => V.types?.find(t => t.code === code);
const capOf = code => Number(set()[typeOf(code)?.cap_key] || 0);
const memberOk = () => V.mem?.status === 'endorsed' && Number(V.mem.license_year) === curYear();
const vetSuppliers = () => C().orgs.filter(o => o.type === 'supplier' && o.meta?.kind === 'vet');
const vetGuarantee = amount => amount <= set().vet_guarantee_t1 ? 'single_salary' : amount <= set().vet_guarantee_t2 ? 'multi_salary' : 'mortgage';
const G_HINT = { single_salary: 'كفيل واحد موظف', multi_salary: 'كفيلان موظفان', mortgage: 'رهن عقار' };
const vetInst = (amount, term, grace) => installment(amount, set().vet_rate, Math.max(1, term - grace));
const mlnTxt = n => `<span class="num">${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`;

// بطاقة المبادرة في الصفحة الرئيسية للمواطن
export function vetBanner() {
  return `<a class="card mb vet-banner" href="#vet"><div class="vb-ic">⚕</div><div><span class="pill">مبادرة البنك المركزي للطب البيطري</span>
    <h2>طبيب بيطري؟ موّل مختبرك أو عيادتك أو معملك</h2><p>يُصرف القرض للمورد مباشرة على دفعات، سداد حتى <b class="num">${num(set().vet_term_max_months / 12)}</b> سنوات، وسماح حتى <b class="num">${num(set().vet_grace_max_months)}</b> شهراً — لأعضاء نقابة الأطباء البيطريين.</p></div><span class="go">ابدأ ←</span></a>`;
}

// ───────── صفحة المبادرة وبدء الطلب ─────────
export async function pageVetStart(body) {
  await loadVet();
  const s = set(), active = A.S.active, m = V.mem;
  body.innerHTML = `
    <section class="cz-hero vet-hero">
      <div><span class="pill">مبادرة تمويل مشاريع أعضاء نقابة الأطباء البيطريين</span>
        <h1>موّل مشروعك البيطري — من عرض السعر إلى التشغيل</h1>
        <p>مختبر بيطري، عيادة، مستشفى، معمل أدوية ولقاحات، أو معمل مستلزمات بيطرية. يُصرف القرض للمورد مباشرة على دفعات: توريد ← تركيب ← تشغيل وإجازة دائرة البيطرة.</p>
        <div class="chips-d"><span>سداد حتى <b class="num">${num(s.vet_term_max_months)}</b> شهراً</span><span>سماح حتى <b class="num">${num(s.vet_grace_max_months)}</b> شهراً</span><span>مساهمتك من <b class="num">${num(s.vet_min_contribution_pct)}%</b></span></div></div>
      <ol class="how">${VET_STEPS.map((t, i) => `<li><i>${i + 1}</i>${t}</li>`).join('')}</ol>
    </section>
    <div class="grid g2">
      <div class="card"><h3>عضويتك في النقابة</h3>
        ${m ? `<p>${badge(MEMBER_STATUS[m.status] || [m.status, 'muted'])}</p><dl class="kv"><dt>رقم العضوية</dt><dd class="num">${esc(m.membership_no || '—')}</dd><dt>إجازة الممارسة</dt><dd><span class="num">${esc(m.license_no || '—')}</span> لسنة <span class="num">${esc(m.license_year || '—')}</span></dd>
          ${m.letter_no ? `<dt>كتاب التأييد</dt><dd class="num">${esc(m.letter_no)}</dd><dt>ساري حتى</dt><dd class="num">${esc(m.valid_until || '')}</dd>` : ''}</dl>
          ${m.status === 'endorsed' && Number(m.license_year) !== curYear() ? `<div class="notice warn">انتهى تأييد سنة ${m.license_year} — جدّد إجازة الممارسة لسنة ${curYear()} وأعد إرسالها داخل الطلب.</div>` : ''}`
        : '<p class="muted">لم تسجّل عضويتك بعد. ستصوّر هوية النقابة وإجازة الممارسة السارية وشهادة التخرج في الخطوة الثانية من الطلب، وترسلها للنقابة لتأييدها إلكترونياً.</p>'}
        <p class="small muted" style="margin:8px 0 0">العضوية في النقابة إلزامية لكل طبيب بيطري، وإجازة الممارسة تُجدَّد في كانون الثاني من كل سنة. النقابة تؤيد العضوية فقط ولا تقرر القرض.</p></div>
      <div class="card"><h3>أنواع المشاريع وسقوفها</h3>
        <div class="tbl-wrap"><table class="tbl"><thead><tr><th>المشروع</th><th>سقف القرض</th></tr></thead><tbody>${V.types.map(t => `<tr><td><b>${esc(t.label)}</b><div class="small muted">${esc(t.hint || '')}</div></td><td>${mlnTxt(capOf(t.code))} د.ع</td></tr>`).join('')}</tbody></table></div>
        <p class="small muted" style="margin:8px 0 0">السقوف والضمانات ونسبة المساهمة قيم مبدئية يحدّثها البنك المركزي عند صدور ضوابط المبادرة.</p></div>
    </div>
    <div class="card mt" data-start></div>`;
  const box = body.querySelector('[data-start]');
  if (active) {
    box.innerHTML = active.program === 'vet'
      ? `<div class="row"><div><h3 style="margin:0">لديك طلب تمويل بيطري <span class="num">${esc(active.code)}</span></h3><p class="muted small" style="margin:4px 0 0">${active.stage <= 5 ? 'أكمل خطواته وأرسله للمصرف.' : 'طلبك لدى المصرف — تابعه من «طلبي».'}</p></div><span class="sp"></span><a class="btn cyan" href="${active.stage <= 5 ? '#apply' : '#home'}">${active.stage <= 5 ? 'أكمل طلبك' : 'متابعة طلبي'}</a></div>`
      : `<div class="notice warn">لديك طلب تمويل منظومة شمسية قائم (<b class="num">${esc(active.code)}</b>). طلب واحد قائم لكل مواطن — أكمله أو ألغِه قبل طلب التمويل البيطري.</div>`;
    return;
  }
  let type = V.types[0]?.code;
  const p = C().profile;
  const paint = () => {
    box.innerHTML = `<h3>بدء طلب تمويل مشروع بيطري</h3>
      <div class="vtypes">${V.types.map(t => `<button type="button" class="vtype ${t.code === type ? 'on' : ''}" data-t="${t.code}"><b>${esc(t.label)}</b><small>${esc(t.hint || '')}</small><span>حتى ${mlnTxt(capOf(t.code))}</span></button>`).join('')}</div>
      <div class="grid g2 mt" style="gap:12px">
        <div class="field"><label>محافظة موقع المشروع</label><select class="input" data-gv>${govOptions(p.governorate || '')}</select></div>
        <div class="field"><label>المدينة / الحي</label><input class="input" data-ct value="${esc(p.city || '')}" placeholder="مثال: الكرادة"></div>
      </div>
      <div class="row"><span class="small muted">يُحفظ تقدمك تلقائياً ويمكنك العودة لاحقاً.</span><span class="sp"></span><button class="btn cyan" data-go>ابدأ الطلب ←</button></div>`;
    box.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { type = b.dataset.t; const gv = box.querySelector('[data-gv]').value, ct = box.querySelector('[data-ct]').value; paint(); box.querySelector('[data-gv]').value = gv; box.querySelector('[data-ct]').value = ct; });
    box.querySelector('[data-go]').onclick = async e => {
      const gov = box.querySelector('[data-gv]').value; if (!gov) return toast('اختر المحافظة', 'bad');
      const c = GOVS.find(x => x[0] === gov), j = () => (Math.random() - .5) * .3;
      e.target.disabled = true;
      try {
        await rpc(C().sb, 'start_vet_application', { p_type: type, p_governorate: gov, p_city: box.querySelector('[data-ct]').value.trim() || null, p_lat: c ? +(c[1] + j()).toFixed(4) : null, p_lng: c ? +(c[2] + j()).toFixed(4) : null });
        await A.load(); C().czStep = null; location.hash = '#apply';
        toast('بدأ طلبك — الخطوة الأولى: التحقق من الهوية', 'ok');
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  paint();
}

// ───────── «طلبي»: المسودة والمتابعة ─────────
export async function homeDraftVet(body, app, first) {
  await loadVet();
  const p = V.proj, t = typeOf(p?.project_type);
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>طلب تمويل مشروعك البيطري محفوظ — أكمل الخطوات وأرسله للمصرف.</p></div></div>
    <div class="card mb draft"><div class="draft-b" style="flex:1">
      <div class="row"><span class="badge info"><i class="dot"></i>مسودة</span><b class="num">${esc(app.code)}</b><span class="sp"></span><span class="small muted">بدأ ${ago(app.created_at)}</span></div>
      <h2 style="font-size:21px;margin:8px 0 2px">${esc(p?.title || t?.label || 'مشروع بيطري')}</h2>
      <div class="muted">${esc(t?.label || '')}${app.amount ? ` · القرض ${iqd(app.amount)} · الضمان: ${esc(GUARANTEE[app.guarantee_type])}` : ''}</div>
      <div class="row mt" style="gap:8px;flex-wrap:wrap">${V.mem ? badge(MEMBER_STATUS[V.mem.status]) : badge(['العضوية لم تُسجل', 'muted'])}${p ? badge(VETDEPT_STATUS[p.vetdept_status]) : ''}</div>
      <div class="prog"><i style="width:${(app.stage - 1) * 20}%"></i></div>
      <div class="small muted">أنجزت <b class="num">${app.stage - 1}</b> من 5 خطوات — التالية: <b style="color:var(--text)">${esc(VET_STEPS[app.stage - 1])}</b></div>
      ${V.mem?.status === 'returned' || V.mem?.status === 'rejected' ? `<div class="notice warn mt"><b>ملاحظة النقابة:</b> ${esc(V.mem.note || '')}</div>` : ''}
      ${p?.vetdept_status === 'returned' ? `<div class="notice warn mt"><b>ملاحظة دائرة البيطرة:</b> ${esc(p.vetdept_note || '')}</div>` : ''}
      <div class="row mt"><a class="btn cyan" href="#apply">أكمل طلبك</a><button class="btn ghost" data-cancel>إلغاء الطلب</button></div>
    </div></div>`;
  body.querySelector('[data-cancel]').onclick = () => A.cancelApp(app);
}

// بطاقة المشروع في صفحة المتابعة بعد الإرسال للمصرف
export async function vetTrackCard(app) {
  await loadVet();
  const { sb } = C(), p = V.proj || (await sb.from('vet_projects').select('*').eq('application_id', app.id).maybeSingle()).data;
  const tr = (await sb.from('vet_tranches').select('*').eq('application_id', app.id).order('n')).data || [];
  const ms = p?.milestones || {};
  return `<div class="card"><h3>مشروعي البيطري</h3><dl class="kv"><dt>المشروع</dt><dd>${esc(p?.title || '')}<div class="small muted">${esc(typeOf(p?.project_type)?.label || '')}</div></dd>
      <dt>المورد</dt><dd>${esc(C().orgs.find(x => x.id === app.supplier_id)?.name || '—')}</dd><dt>الكلفة الكلية</dt><dd>${iqd(p?.total_cost)}</dd><dt>مساهمتي</dt><dd>${iqd(p?.contribution)}</dd>
      <dt>القرض</dt><dd><b>${iqd(app.amount)}</b></dd><dt>المصرف</dt><dd>${esc(C().orgs.find(x => x.id === app.bank_id)?.name || '—')}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd>
      <dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً منها <span class="num">${app.grace_months || 0}</span> سماح</dd>
      <dt>الإجازة</dt><dd>${p?.license_no ? `${badge(['ممنوحة', 'ok'])} <span class="num">${esc(p.license_no)}</span>` : '<span class="muted">بعد التشغيل</span>'}</dd></dl>
    ${tr.length ? `<h3 class="mt">الصرف للمورد</h3><ul class="vet-tr">${tr.map(t => `<li><span>${esc(t.label)}</span><span class="sp"></span>${iqd(t.amount)} ${badge(TRANCHE_STATUS[t.status])}</li>`).join('')}</ul>
      <p class="small muted" style="margin:6px 0 0">${MILESTONES.map(([k, l]) => `${ms[k] ? '✓' : '○'} ${l}`).join(' · ')}</p>` : ''}</div>`;
}

// ───────── معالج الطلب البيطري ─────────
export async function pageApplyVet(body, app) {
  await loadVet();
  const step = Math.min(C().czStep || app.stage, app.stage);
  const t = typeOf(V.proj?.project_type);
  const sub = ['التحقق بالسيلفي', 'تأييد النقابة', 'الدراسة والكلفة', 'الكفلاء أو العقار', 'العمولة والتوقيع'];
  body.innerHTML = `
    ${wizHead({ title: 'طلب تمويل بيطري', sub: `رقم <b class="num">${esc(app.code)}</b>${app.amount ? ` · ${iqd(app.amount)}` : ''}`, steps: VET_STEPS.map((ti, i) => [ti, sub[i]]), cur: step - 1, done: app.stage - 1, reach: app.stage - 1 })}
    <div class="card wiz-body" id="wb"></div>`;
  wireWizHead(body, i => { C().czStep = i + 1; pageApplyVet(body, app); });
  const wb = body.querySelector('#wb'), done = step < app.stage;
  if (step === 1) return A.step1(wb, app, done);
  if (step === 2) return vstep2(wb, app, done);
  if (step === 3) return vstep3(wb, app, done);
  if (step === 4) return A.step4(wb, app, done);
  return vstep5(wb, app);
}

// 2) العضوية في النقابة: صور المستندات الثلاثة بالكاميرا ثم إرسالها للتأييد
const MDOCS = [['union_id', 'هوية نقابة الأطباء البيطريين', .63], ['license', `إجازة ممارسة المهنة لسنة ${new Date().getFullYear()}`, .72], ['degree', 'شهادة التخرج من كلية الطب البيطري', .72]];
function vstep2(wb, app, done, edit) {
  const m = V.mem;
  if (done && !edit) {
    wb.innerHTML = `<div class="done-box"><span class="ok-ic">${m?.status === 'endorsed' ? '✓' : '…'}</span><div><b>${m?.status === 'endorsed' ? 'عضويتك مؤيدة من النقابة' : 'أُرسلت عضويتك إلى النقابة'}</b>
      <dl class="kv mt"><dt>الحالة</dt><dd>${badge(MEMBER_STATUS[m?.status || 'draft'])}</dd><dt>رقم العضوية</dt><dd class="num">${esc(m?.membership_no || '—')}</dd><dt>إجازة الممارسة</dt><dd><span class="num">${esc(m?.license_no || '—')}</span> لسنة <span class="num">${esc(m?.license_year || '')}</span></dd>
      ${m?.letter_no ? `<dt>كتاب التأييد</dt><dd class="num">${esc(m.letter_no)}</dd>` : ''}${m?.note ? `<dt>ملاحظة النقابة</dt><dd>${esc(m.note)}</dd>` : ''}</dl>
      ${m?.status === 'pending' ? '<p class="small muted" style="margin:8px 0 0">تابع الخطوات التالية أثناء الانتظار — يُرسل الطلب للمصرف بعد التأييد فقط.</p>' : ''}</div></div>
      <div class="row mt"><button class="btn ghost" data-edit>${['returned', 'rejected', 'draft'].includes(m?.status) ? 'تعديل وإعادة الإرسال' : 'تعديل هذه الخطوة'}</button><span class="sp"></span><button class="btn cyan" data-next>الخطوة التالية ←</button></div>`;
    wb.querySelector('[data-edit]').onclick = () => vstep2(wb, app, done, true);
    wb.querySelector('[data-next]').onclick = () => { C().czStep = null; A.pageApply(C().root.querySelector('#cz')); };
    return;
  }
  const docs = Object.fromEntries((V.memDocs || []).map(d => [d.kind, d]));
  const y = curYear();
  wb.innerHTML = `<h2>العضوية وتأييد النقابة</h2><p class="muted">ترسل المنصة بيانات عضويتك ومستنداتها إلى نقابة الأطباء البيطريين لتأييد العضوية وسريان إجازة الممارسة لهذه السنة. النقابة لا تقرر القرض — تؤيد العضوية فقط.</p>
    ${m && m.status !== 'draft' ? `<div class="notice ${m.status === 'endorsed' ? '' : 'warn'}">${badge(MEMBER_STATUS[m.status])} ${m.note ? esc(m.note) : ''}</div>` : ''}
    <div class="card soft mb"><h3>1. صوّر المستندات بكاميرا الهاتف</h3><p class="small muted" style="margin-top:0">تصوير مباشر فقط — لا تُقبل صورة من المعرض أو ملف.</p>
      <div class="doc-row">${MDOCS.map(([k, l]) => `<div data-box="${k}">${docThumb(docs[k] ? { data: docs[k].data, meta: { live: true } } : null, l)}</div>`).join('')}</div>
      <div class="row" style="gap:8px;flex-wrap:wrap">${MDOCS.map(([k, l]) => `<button type="button" class="btn sm ${docs[k] ? 'ghost' : ''}" data-shoot="${k}">📷 ${esc(l.split(' ').slice(0, 2).join(' '))}</button>`).join('')}</div></div>
    <div class="card soft mb"><h3>2. بيانات العضوية</h3><div class="grid g2" style="gap:12px">
      <div class="field"><label>رقم العضوية في النقابة</label><input class="input" data-k="membership_no" dir="ltr" value="${esc(m?.membership_no || '')}"></div>
      <div class="field"><label>فرع النقابة المسجل فيه</label><select class="input" data-k="syndicate_branch">${govOptions(m?.syndicate_branch || C().profile.governorate || '')}</select></div>
      <div class="field"><label>رقم إجازة ممارسة المهنة</label><input class="input" data-k="license_no" dir="ltr" value="${esc(m?.license_no || '')}"></div>
      <div class="field"><label>سنة الإجازة (مجددة)</label><input class="input" data-k="license_year" dir="ltr" value="${y}" readonly></div>
      <div class="field"><label>سنة التخرج</label><input class="input" data-k="graduation_year" inputmode="numeric" maxlength="4" dir="ltr" value="${esc(m?.graduation_year || '')}"></div>
      <div class="field"><label>الكلية والجامعة</label><input class="input" data-k="college" value="${esc(m?.college || '')}" placeholder="كلية الطب البيطري — جامعة …"></div>
      <div class="field"><label>الاختصاص (اختياري)</label><input class="input" data-k="specialty" value="${esc(m?.specialty || '')}"></div>
    </div></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${m?.status === 'endorsed' && Number(m.license_year) === y ? 'تأكيد العضوية المؤيدة' : 'إرسال العضوية للنقابة'}</button></div>`;
  wb.querySelectorAll('[data-shoot]').forEach(b => b.onclick = async () => {
    const [k, l, ratio] = MDOCS.find(x => x[0] === b.dataset.shoot);
    const shot = await cameraCapture({ title: `صوّر ${l}`, ratio: ratio > .7 ? .72 : 1.58 });
    if (!shot) return;
    try {
      await rpc(C().sb, 'vet_member_doc', { p_kind: k, p_data: shot.data, p_source: 'camera', p_meta: shot.meta });
      wb.querySelector(`[data-box="${k}"]`).innerHTML = docThumb(shot, l); b.classList.add('ghost'); toast('حُفظت الصورة', 'ok');
      V.memDocs = (V.memDocs || []).filter(d => d.kind !== k).concat({ kind: k, data: shot.data });
    } catch (e) { toast(cleanErr(e), 'bad'); }
  });
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = {}; wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    d.license_year = y; d.graduation_year = Number(digits(d.graduation_year));
    if (!d.membership_no) return toast('اكتب رقم العضوية', 'bad');
    if (!d.license_no) return toast('اكتب رقم إجازة الممارسة', 'bad');
    if ((V.memDocs || []).length < 3) return toast('صوّر المستندات الثلاثة أولاً', 'bad');
    e.target.disabled = true;
    try { await A.saveStep(app, 2, d, 'أُرسلت العضوية للنقابة'); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 3) دراسة المشروع والمصرف — النظام يحسب الكلفة والقرض والقسط وعمولة المصرف، ويرسل المشروع لدائرة البيطرة
function vstep3(wb, app, done, edit) {
  const p = V.proj || {}, s = set();
  if (done && !edit) {
    const b = A.S.banks.find(x => x.id === app.bank_choice?.bank_id);
    wb.innerHTML = `<div class="done-box"><span class="ok-ic">${p.vetdept_status === 'approved' ? '✓' : '…'}</span><div><b>${esc(p.title || '')}</b>
      <dl class="kv mt"><dt>دائرة البيطرة</dt><dd>${badge(VETDEPT_STATUS[p.vetdept_status])}${p.vetdept_ref ? ` <span class="num">${esc(p.vetdept_ref)}</span>` : ''}${p.vetdept_note ? `<div class="small muted">${esc(p.vetdept_note)}</div>` : ''}</dd>
        <dt>الكلفة الكلية</dt><dd>${iqd(p.total_cost)}</dd><dt>مساهمتك</dt><dd>${iqd(p.contribution)}</dd><dt>القرض</dt><dd><b>${iqd(app.amount)}</b></dd>
        <dt>المصرف</dt><dd>${esc(b?.name || '—')}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)} × <span class="num">${app.term_months - (app.grace_months || 0)}</span> شهراً بعد سماح <span class="num">${app.grace_months || 0}</span></dd>
        <dt>الضمان المطلوب</dt><dd>${esc(G_HINT[app.guarantee_type] || '—')}</dd></dl></div></div>
      <div class="row mt"><button class="btn ghost" data-edit>تعديل الدراسة</button><span class="sp"></span><button class="btn cyan" data-next>الخطوة التالية ←</button></div>`;
    wb.querySelector('[data-edit]').onclick = () => vstep3(wb, app, done, true);
    wb.querySelector('[data-next]').onclick = () => { C().czStep = null; A.pageApply(C().root.querySelector('#cz')); };
    return;
  }
  const st = {
    type: p.project_type || V.types[0]?.code, title: p.title || '', gov: p.site_governorate || app.governorate, city: p.site_city || app.city || '', addr: p.site_address || '',
    own: p.site_ownership || '', area: p.site_area || '', items: (p.items?.length ? p.items : [{ name: '', qty: 1, price: '' }]).map(x => ({ ...x })),
    other: p.other_cost || '', contrib: p.contribution || '', rev: p.revenue_monthly || '', staff: p.staff_count || '', capacity: p.capacity || '', products: p.products || '',
    sup: app.supplier_id || vetSuppliers()[0]?.id, quote: p.quote_no || '', bank: app.bank_choice?.bank_id || A.S.banks.find(b => b.open && b.terms)?.id,
    term: Math.min(app.bank_choice?.term_months || s.vet_term_max_months, s.vet_term_max_months), grace: Math.min(app.bank_choice?.grace_months ?? 12, s.vet_grace_max_months),
  };
  const docs = Object.fromEntries((V.docs || []).map(d => [d.kind, d]));
  const calc = () => {
    const equip = st.items.reduce((t, i) => t + (Number(digits(i.qty)) || 0) * (Number(digits(i.price)) || 0), 0);
    const other = Number(digits(st.other)) || 0, total = equip + other, contrib = Number(digits(st.contrib)) || 0, minC = Math.ceil(total * s.vet_min_contribution_pct / 100);
    const loan = Math.max(0, total - contrib), cap = capOf(st.type), g = vetGuarantee(loan);
    const errs = [];
    if (total && contrib < minC) errs.push(`مساهمتك لا تقل عن ${num(s.vet_min_contribution_pct)}% (${num(minC)} د.ع)`);
    if (loan > equip) errs.push('القرض يُصرف للمورد فقط ولا يتجاوز كلفة الأجهزة — غطِّ الأعمال الأخرى من مساهمتك');
    if (loan > cap) errs.push(`القرض يتجاوز سقف ${typeOf(st.type)?.label} (${num(cap)} د.ع)`);
    return { equip, other, total, contrib, minC, loan, cap, g, errs };
  };
  const paint = () => {
    const k = calc(), banks = A.S.banks.filter(b => b.terms), t = typeOf(st.type);
    const ins = k.loan ? vetInst(k.loan, st.term, st.grace) : 0;
    wb.innerHTML = `<h2>دراسة المشروع والمصرف</h2><p class="muted">اكتب الأجهزة كما في عرض سعر المورد. يحسب النظام الكلفة والقرض والقسط، ثم يرسل الدراسة إلى دائرة البيطرة للموافقة المبدئية على المشروع وموقعه.</p>
      ${p.vetdept_status === 'returned' ? `<div class="notice warn"><b>أعادت دائرة البيطرة الدراسة:</b> ${esc(p.vetdept_note || '')}</div>` : ''}
      <div class="card soft mb"><h3>1. نوع المشروع</h3><div class="vtypes">${V.types.map(x => `<button type="button" class="vtype ${x.code === st.type ? 'on' : ''}" data-t="${x.code}"><b>${esc(x.label)}</b><span>حتى ${mlnTxt(capOf(x.code))}</span></button>`).join('')}</div>
        <div class="field mt"><label>اسم المشروع</label><input class="input" data-v="title" value="${esc(st.title)}" placeholder="مثال: مختبر الرافدين للتشخيص البيطري"></div>
        ${t?.factory ? `<div class="grid g2" style="gap:12px"><div class="field"><label>منتجات المعمل</label><input class="input" data-v="products" value="${esc(st.products)}" placeholder="مثال: مضادات حيوية بيطرية، لقاحات دواجن"></div>
          <div class="field"><label>الطاقة الإنتاجية</label><input class="input" data-v="capacity" value="${esc(st.capacity)}" placeholder="مثال: 50 ألف عبوة شهرياً"></div></div>` : ''}</div>
      <div class="card soft mb"><h3>2. الموقع</h3><div class="grid g2" style="gap:12px">
        <div class="field"><label>المحافظة</label><select class="input" data-v="gov">${govOptions(st.gov)}</select></div>
        <div class="field"><label>المدينة / الحي</label><input class="input" data-v="city" value="${esc(st.city)}"></div>
        <div class="field" style="grid-column:1/-1"><label>العنوان التفصيلي</label><input class="input" data-v="addr" value="${esc(st.addr)}" placeholder="الشارع، أقرب نقطة دالة"></div>
        <div class="field"><label>ملكية الموقع</label><div class="seg" style="margin:0"><button type="button" data-own="owned" class="${st.own === 'owned' ? 'on' : ''}">ملك</button><button type="button" data-own="rented" class="${st.own === 'rented' ? 'on' : ''}">إيجار</button></div></div>
        <div class="field"><label>المساحة (م²)</label><input class="input" data-v="area" inputmode="numeric" dir="ltr" value="${esc(st.area)}"></div></div>
        <div class="doc-row">${docThumb(docs.site, 'صورة الموقع (اختياري)')}</div><button type="button" class="btn ghost sm" data-shoot="site">📷 تصوير الموقع</button></div>
      <div class="card soft mb"><h3>3. الأجهزة وعرض سعر المورد</h3>
        <div class="grid g2" style="gap:12px"><div class="field"><label>المورد المعتمد</label><select class="input" data-v="sup">${vetSuppliers().map(o => `<option value="${o.id}" ${o.id === st.sup ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></div>
          <div class="field"><label>رقم عرض السعر</label><input class="input" data-v="quote" dir="ltr" value="${esc(st.quote)}"></div></div>
        <div class="vitems">${st.items.map((i, n) => `<div class="vitem" data-i="${n}"><input class="input" data-f="name" value="${esc(i.name)}" placeholder="الجهاز أو البند"><input class="input" data-f="qty" inputmode="numeric" dir="ltr" value="${esc(i.qty)}" placeholder="العدد"><input class="input" data-f="price" inputmode="numeric" dir="ltr" value="${esc(i.price)}" placeholder="سعر الوحدة (د.ع)">${st.items.length > 1 ? `<button type="button" class="linkbtn" data-rm="${n}" aria-label="حذف">✕</button>` : '<span></span>'}</div>`).join('')}</div>
        <button type="button" class="btn ghost sm" data-add>＋ إضافة جهاز</button>
        <div class="doc-row mt">${docThumb(docs.quote, 'عرض سعر المورد')}</div><button type="button" class="btn sm ${docs.quote ? 'ghost' : 'cyan'}" data-shoot="quote">📷 تصوير عرض السعر</button></div>
      <div class="card soft mb"><h3>4. الكلفة والمساهمة</h3><div class="grid g2" style="gap:12px">
        <div class="field"><label>أعمال وتكاليف أخرى (بناء، تأسيس، إيجار) — من مساهمتك</label><input class="input" data-v="other" inputmode="numeric" dir="ltr" value="${esc(st.other)}"></div>
        <div class="field"><label>مساهمتك النقدية (د.ع)</label><input class="input" data-v="contrib" inputmode="numeric" dir="ltr" value="${esc(st.contrib)}"></div>
        <div class="field"><label>الإيراد الشهري المتوقع (د.ع)</label><input class="input" data-v="rev" inputmode="numeric" dir="ltr" value="${esc(st.rev)}"></div>
        <div class="field"><label>عدد العاملين</label><input class="input" data-v="staff" inputmode="numeric" dir="ltr" value="${esc(st.staff)}"></div></div>
        <div class="review" data-calc></div></div>
      <div class="card soft mb"><h3>5. المصرف والمدة والسماح</h3>
        <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${st.term}</span> شهراً (<span class="num">${(st.term / 12).toFixed(1)}</span> سنة)</b></div>
        <input type="range" class="range" data-r="term" min="24" max="${s.vet_term_max_months}" step="12" value="${st.term}" aria-label="مدة السداد">
        <div class="row"><span class="small">مدة السماح (داخل مدة السداد)</span><span class="sp"></span><b><span class="num">${st.grace}</span> شهراً</b></div>
        <input type="range" class="range" data-r="grace" min="0" max="${s.vet_grace_max_months}" step="3" value="${st.grace}" aria-label="مدة السماح">
        <div class="bcards">${banks.map(b => { const comm = Math.round(k.loan * Number(b.terms.commission_pct ?? 1) / 100), acc = A.accepts(b, st.sup); return `<label class="bcard ${b.id === st.bank ? 'on' : ''} ${b.open && acc ? '' : 'off'}">
          <input type="radio" name="bk" value="${b.id}" ${b.id === st.bank ? 'checked' : ''} ${b.open && acc ? '' : 'disabled'}>
          <div class="row"><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i><b>${esc(b.name)}</b><span class="sp"></span>${b.is_islamic ? '<span class="badge info">مرابحة</span>' : ''}</div>
          ${b.open && !acc ? '<div class="small mt" style="color:var(--warn)">لا يتعامل مع المورد المختار</div>' : b.open ? `<dl class="kv small"><dt>عمولة المصرف</dt><dd><b class="cm">${iqd(comm)}</b> <span class="num">(${Number(b.terms.commission_pct ?? 1)}%)</span></dd><dt>رسوم الملف</dt><dd>${iqd(b.terms.file_fee)}</dd><dt>مدة الدراسة</dt><dd><span class="num">${b.terms.processing_days}</span> أيام عمل</dd></dl>` : '<div class="small muted mt">لا يستقبل طلبات عبر المنصة حالياً</div>'}</label>`; }).join('')}</div>
        <div class="review"><dl class="kv"><dt>الفائدة السنوية</dt><dd class="num">${num(s.vet_rate)}%</dd><dt>القسط الشهري بعد السماح</dt><dd style="color:var(--indigo);font-size:17px">${iqd(ins)} × <span class="num">${st.term - st.grace}</span> شهراً</dd>
          <dt>أول قسط</dt><dd>بعد <span class="num">${st.grace}</span> شهراً من التنفيذ</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[k.g]}</dd></dl></div></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>تثبيت الدراسة وإرسالها لدائرة البيطرة</button></div>`;
    paintCalc();
    // ربط الحقول (بلا إعادة رسم أثناء الكتابة كي لا يضيع المؤشر)
    wb.querySelectorAll('[data-v]').forEach(i => i.oninput = i.onchange = e => { st[i.dataset.v] = i.value; if (['other', 'contrib'].includes(i.dataset.v)) paintCalc(); if (i.dataset.v === 'sup' && e.type === 'change') paint(); });
    wb.querySelectorAll('.vitem [data-f]').forEach(i => i.oninput = () => { st.items[Number(i.closest('[data-i]').dataset.i)][i.dataset.f] = i.value; paintCalc(); });
    wb.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { st.items.splice(Number(b.dataset.rm), 1); paint(); });
    wb.querySelector('[data-add]').onclick = () => { st.items.push({ name: '', qty: 1, price: '' }); paint(); };
    wb.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { st.type = b.dataset.t; paint(); });
    wb.querySelectorAll('[data-own]').forEach(b => b.onclick = () => { st.own = b.dataset.own; wb.querySelectorAll('[data-own]').forEach(x => x.classList.toggle('on', x === b)); });
    wb.querySelectorAll('[data-r]').forEach(r => r.oninput = () => { st[r.dataset.r] = Number(r.value); if (st.grace > st.term - 12) st.grace = st.term - 12; paint(); wb.querySelector(`[data-r=${r.dataset.r}]`).focus(); });
    wb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { st.bank = r.value; paint(); });
    wb.querySelectorAll('[data-shoot]').forEach(b => b.onclick = async () => {
      const kind = b.dataset.shoot, shot = await cameraCapture({ title: kind === 'quote' ? 'صوّر عرض سعر المورد' : 'صوّر موقع المشروع', ratio: kind === 'quote' ? .72 : 1.33 });
      if (!shot) return;
      try { await rpc(C().sb, 'add_document', { p_app: app.id, p_kind: kind, p_data: shot.data, p_source: 'camera', p_meta: shot.meta }); V.docs = (V.docs || []).filter(d => d.kind !== kind).concat({ kind, data: shot.data, meta: shot.meta }); docs[kind] = { data: shot.data, meta: shot.meta }; toast('حُفظت الصورة', 'ok'); paint(); }
      catch (e) { toast(cleanErr(e), 'bad'); }
    });
    wb.querySelector('[data-ok]').onclick = async e => {
      const k2 = calc();
      if (!st.title.trim()) return toast('اكتب اسم المشروع', 'bad');
      if (!st.own) return toast('حدّد ملكية الموقع: ملك أم إيجار', 'bad');
      if (!docs.quote) return toast('صوّر عرض سعر المورد', 'bad');
      if (k2.errs.length) return toast(k2.errs[0], 'bad');
      e.target.disabled = true;
      try {
        await A.saveStep(app, 3, {
          project_type: st.type, title: st.title.trim(), site_governorate: st.gov, site_city: st.city, site_address: st.addr, site_ownership: st.own, site_area: digits(st.area),
          items: st.items.filter(i => i.name.trim()).map(i => ({ name: i.name.trim(), qty: Number(digits(i.qty)), price: Number(digits(i.price)) })),
          other_cost: String(k2.other), contribution: String(k2.contrib), revenue_monthly: digits(st.rev), staff_count: digits(st.staff), capacity: st.capacity, products: st.products,
          supplier_id: st.sup, quote_no: st.quote, bank_id: st.bank, term_months: st.term, grace_months: st.grace,
        }, 'حُفظت الدراسة وأُرسلت لدائرة البيطرة');
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  const paintCalc = () => {
    const k = calc(), box = wb.querySelector('[data-calc]'); if (!box) return;
    box.innerHTML = `<dl class="kv"><dt>كلفة الأجهزة</dt><dd>${iqd(k.equip)}</dd><dt>تكاليف أخرى</dt><dd>${iqd(k.other)}</dd><dt>الكلفة الكلية</dt><dd><b>${iqd(k.total)}</b></dd>
      <dt>أدنى مساهمة (${num(set().vet_min_contribution_pct)}%)</dt><dd>${iqd(k.minC)}</dd><dt>مبلغ القرض</dt><dd style="color:var(--indigo);font-size:17px"><b>${iqd(k.loan)}</b> <span class="small muted">من سقف ${iqd(k.cap)}</span></dd>
      <dt>الضمان المطلوب</dt><dd>${G_HINT[k.g]}</dd></dl>${k.errs.map(x => `<div class="small" style="color:var(--bad)">• ${esc(x)}</div>`).join('')}`;
  };
  paint();
}

// 5) الدفع والتوقيع: لا يُرسل الطلب قبل تأييد النقابة وموافقة دائرة البيطرة
function vstep5(wb, app) {
  const bk = A.S.banks.find(b => b.id === app.bank_choice?.bank_id), p = V.proj || {};
  if (!bk?.terms) { wb.innerHTML = '<div class="notice warn">اختر المصرف في خطوة «المشروع والمصرف» أولاً.</div>'; return; }
  const comm = Math.round(app.amount * Number(bk.terms.commission_pct ?? 1) / 100);
  const f = [['عمولة المصرف', comm, true], ['رسم دراسة الملف', Number(bk.terms.file_fee || 0)], ['أجور الكشف الموقعي', Number(set().inspection_fee || 0)], ['عمولة المنصة', Number(set().platform_fee || 0)]];
  const tot = f.reduce((t, x) => t + x[1], 0);
  const gates = [[memberOk(), 'تأييد نقابة الأطباء البيطريين للعضوية وإجازة ' + curYear(), V.mem ? MEMBER_STATUS[V.mem.status][0] : 'لم تُرسل'], [p.vetdept_status === 'approved', 'موافقة دائرة البيطرة على المشروع وموقعه', VETDEPT_STATUS[p.vetdept_status || 'draft'][0]]];
  const ready = gates.every(g => g[0]);
  C().czVetWait = !ready;   // تحديث لحظي لهذه الشاشة حتى تصل الموافقات
  let paid = [], method = 'zaincash';
  C().sb.from('payments').select('*').eq('application_id', app.id).then(r => { paid = r.data || []; paint(); });
  const paint = () => {
    const pay = paid.find(x => x.bank_id === bk.id && x.status === 'paid');
    wb.innerHTML = `<h2>دفع العمولة وإرسال الطلب</h2><p class="muted">يُرسل طلبك إلى ${esc(bk.name)} بعد تأييد النقابة وموافقة دائرة البيطرة ودفع العمولة، ثم توقيعك الإلكتروني.</p>
      <div class="review"><h3>الموافقات المطلوبة قبل الإرسال</h3><ul class="gates">${gates.map(([ok, l, s]) => `<li class="${ok ? 'ok' : ''}"><i>${ok ? '✓' : '…'}</i><span>${l}</span><span class="sp"></span>${badge([s, ok ? 'ok' : 'warn'])}</li>`).join('')}</ul>
        ${ready ? '' : '<p class="small muted" style="margin:6px 0 0">تصلك الموافقات لحظياً هنا — يمكنك الدفع الآن والتوقيع بعد اكتمالها.</p>'}</div>
      <div class="review"><h3>ملخص الطلب</h3><dl class="kv"><dt>المشروع</dt><dd>${esc(p.title || '')}</dd><dt>القرض</dt><dd>${iqd(app.amount)}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])} ${badge(['مؤكد', 'ok'])}</dd>
        <dt>المصرف</dt><dd>${esc(bk.name)}</dd><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً منها <span class="num">${app.grace_months || 0}</span> سماح</dd><dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(app.monthly_installment)}</dd>
        <dt>الصرف</dt><dd>للمورد مباشرة على ثلاث دفعات: توريد ← تركيب ← تشغيل وإجازة</dd></dl></div>
      <div class="review pay ${pay ? 'done' : ''}"><h3>1. العمولة والرسوم ${pay ? '<span class="badge ok">مدفوعة</span>' : ''}</h3>
        <dl class="kv">${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${Number(bk.terms.commission_pct ?? 1)}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(tot)}</b></dd></dl>
        ${pay ? `<p class="small muted" style="margin:6px 0 0">رقم العملية <b class="num">${esc(pay.ref)}</b> · ${esc(PAY_LABEL[pay.method] || pay.method)} · ${dt(pay.paid_at)}</p>` : `
        <div class="paygrid">${PAY_METHODS.map(([k, t, col]) => `<button type="button" data-m="${k}" class="${k === method ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>
        <div class="row mt"><span class="sp"></span><button type="button" class="btn warn" data-pay>ادفع ${iqd(tot)}</button></div>`}</div>
      <div class="review"><h3>2. الإقرار والتوقيع الإلكتروني</h3>
        <label class="check"><input type="checkbox" data-ack> أقرّ بصحة بيانات المشروع، وأوافق على صرف القرض للمورد على دفعات، وعلى استقطاع القسط بعد مدة السماح.</label>
        ${!ready ? `<div class="notice warn" style="margin:8px 0 0"><b>التوقيع مقفل حتى تصل الموافقات التالية:</b><br>${gates.filter(g => !g[0]).map(g => `• ${g[1]} — <b>${esc(g[2])}</b>`).join('<br>')}<br><span class="small">يُفتح التوقيع هنا تلقائياً فور وصولها.</span></div>` : ''}<p class="small muted" style="margin:6px 0 0">${!ready ? 'يمكنك الدفع الآن والتوقيع بعد وصول الموافقات.' : pay ? 'العمولة مدفوعة — اضغط الزر أدناه ووقّع برمز التحقق.' : 'ضع علامة الإقرار ثم اضغط الزر أدناه: ندفع العمولة ثم توقّع ويُرسل الطلب.'}</p></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok ${ready ? '' : 'disabled'}>${!ready ? 'بانتظار الموافقات' : pay ? 'التوقيع وإرسال طلب التمويل' : `ادفع ${iqd(tot)} ووقّع وأرسل الطلب`}</button></div>`;
    wb.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; wb.querySelectorAll('[data-m]').forEach(x => x.classList.toggle('on', x === b)); });
    const doPay = async () => !!(await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: C().profile.phone, purpose: `دفع ${num(tot)} د.ع (عمولة ${bk.name} والرسوم)`,
        verify: async c2 => { const x = await rpc(C().sb, 'pay_application_fees', { p_app: app.id, p_bank: bk.id, p_method: method, p_otp: c2 }); paid = paid.filter(y => y.id !== x.id).concat(x); } }));
    const pb = wb.querySelector('[data-pay]');
    if (pb) pb.onclick = async () => { const ack = wb.querySelector('[data-ack]')?.checked; if (await doPay()) { toast('تم الدفع', 'ok'); paint(); if (ack) wb.querySelector('[data-ack]').checked = true; } };
    wb.querySelector('[data-ok]').onclick = async () => {
      if (!wb.querySelector('[data-ack]')?.checked) return toast('ضع علامة ✓ على الإقرار أولاً', 'bad');
      if (!paid.find(x => x.bank_id === bk.id && x.status === 'paid')) { if (!(await doPay())) return; toast('تم الدفع — بقي التوقيع', 'ok'); paint(); wb.querySelector('[data-ack]').checked = true; }
      const code = await askOtp({ kind: 'sign', title: 'التوقيع الإلكتروني', phone: C().profile.phone, purpose: `توقيع طلب تمويل ${num(app.amount)} د.ع لدى ${bk.name}`,
        verify: c2 => rpc(C().sb, 'citizen_step', { p_app: app.id, p_step: 5, p_data: { bank_id: bk.id, otp: c2 } }) });
      if (!code) return;
      await A.load(); C().czStep = null;
      const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h2>أُرسل طلبك إلى ${esc(bk.name)}</h2>
        <p class="muted">رقم الطلب <b class="num">${esc(app.code)}</b> — الآن لدى <b>خدمة الزبائن في الفرع</b>. تتابع كل مرحلة من «طلبي».</p><a class="btn cyan" href="#home" data-x>متابعة طلبي</a></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      location.hash = '#home';
    };
  };
  paint();
}
