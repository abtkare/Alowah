// الجلسة 39: بوابة الهيئة الشرعية للتمويل الإسلامي (/sharia)
// الهيئة تعتمد المنتجات والعقود فقط — لا تراجع طلبات التمويل. كل الصيغ على المذهب الجعفري (من إعدادات الهيئة).
// أمين السر: يتحقق من اكتمال الملف ويحيله للأعضاء أو يعيده للمصرف بسبب.
// الأعضاء والرئيس: يعلّقون على بند محدد في نص العقد، ويرون الفروق بين النسخ، ويصوّتون.
// الرئيس: يصدر القرار برقم SH-… ويوقّعه برمز تحقق، ويعلّق المنتج أو يسحب اعتماده، ويضبط الإعدادات.
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, resultScreen, askOtp } from '../core.js';
import { shBadge, SECTORS, VOTE, DECISION, contractHtml, tallyHtml, resolutionHtml, shortSha } from '../sharia-ui.js';

let D;   // صندوق الهيئة

// التوقيع برمز تحقق على هاتف الرئيس. إن لم يُسجَّل له هاتف بعد: رمز وضع المطور فقط (والقاعدة تتحقق منه)
const noPhoneCli = { rpc: async fn => fn === 'otp_request' ? { data: { mode: 'dev' } } : { data: null } };
const signOtp = (ctx, o) => askOtp({ kind: 'sign', phone: ctx.profile.phone || '', ...(ctx.profile.phone ? {} : { sb: noPhoneCli }), ...o });

export const shouldRefresh = () => !document.querySelector('.mdl-bg,.rs-bg,.ct-bg');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'sharia_inbox');
  if (ctx.shOpen) {
    if (D.products.some(p => p.id === ctx.shOpen)) return detail(ctx, ctx.shOpen);
    ctx.shOpen = null;
  }
  const me = D.me, b = D.board, P = D.products;
  const mine = p => (me.secretary && p.status === 'submitted') || (me.voter && p.status === 'deliberation' && !p.my_vote) || (me.head && p.status === 'deliberation' && p.votes >= b.quorum);
  const todo = P.filter(mine);
  const live = P.filter(p => ['approved', 'conditional'].includes(p.status));
  const tab = ctx.shTab || 'work';
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(b.name)}</h1>
      <p>${esc(me.name)} — ${esc(me.role_title)} · الصيغ على <b>${esc(b.madhhab_label)}</b>${b.marja ? ` · المرجع: ${esc(b.marja)}` : ''}</p></div></div>
    <div class="notice"><span>ℹ</span><span class="small">الهيئة <b>تعتمد المنتجات والعقود فقط</b> ولا تراجع طلبات التمويل. بعد الاعتماد يطبّق النظام شروط الصيغة في كل طلب، ويوقّع المقترض النص المعتمد حرفياً.</span></div>
    <div class="grid g4 mb">
      ${kpi('المطلوب منك الآن', `<span class="num">${todo.length}</span>`, me.secretary ? 'ملفات بانتظار التحقق' : 'منتجات بانتظار صوتك أو قرارك', true)}
      ${kpi('قيد المداولة', `<span class="num">${P.filter(p => p.status === 'deliberation').length}</span>`, `النصاب <span class="num">${b.quorum}</span> من <span class="num">${b.voters}</span>`)}
      ${kpi('معتمدة نافذة', `<span class="num">${live.length}</span>`, `${live.filter(p => p.review_soon).length ? `<span class="warn-t">${live.filter(p => p.review_soon).length} مراجعتها قريبة</span>` : 'تظهر للمقترضين'}`)}
      ${kpi('القرارات الصادرة', `<span class="num">${D.resolutions.length}</span>`, 'سجل القرارات')}
    </div>
    <div class="seg sm sh-tabs" role="tablist">${[['work', `المنتجات (${P.length})`], ['res', `سجل القرارات (${D.resolutions.length})`], ['lib', 'مكتبة الصيغ'], ['board', me.head ? 'الهيئة والإعدادات' : 'الهيئة']]
      .map(([k, t]) => `<button type="button" class="${tab === k ? 'on' : ''}" data-tab="${k}">${t}</button>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('[data-tab]').forEach(x => x.onclick = () => { ctx.shTab = x.dataset.tab; render(ctx); });
  const body = root.querySelector('[data-body]');
  if (tab === 'res') return resList(ctx, body);
  if (tab === 'lib') return library(body);
  if (tab === 'board') return boardView(ctx, body);
  const rest = P.filter(p => !mine(p));
  body.innerHTML = `
    ${todo.length ? `<h3 class="sh-sec">المطلوب منك الآن</h3><div class="eng-cards">${todo.map(p => card(p, true)).join('')}</div>` : `<div class="card empty mb">لا شيء مطلوب منك الآن ✓</div>`}
    ${rest.length ? `<h3 class="sh-sec">كل المنتجات</h3><div class="eng-cards">${rest.map(p => card(p)).join('')}</div>` : ''}`;
  body.querySelectorAll('[data-open]').forEach(x => x.onclick = () => { ctx.shOpen = x.dataset.open; window.scrollTo(0, 0); render(ctx); });
}

function card(p, hot = false) {
  const [ic] = SECTORS[p.sector] || ['•'];
  const need = D.me.secretary && p.status === 'submitted' ? 'تحقق من الاكتمال وأحِل أو أعِد'
    : D.me.voter && p.status === 'deliberation' && !p.my_vote ? 'صوّت على النسخة الحالية'
    : D.me.head && p.status === 'deliberation' && p.votes >= D.board.quorum ? 'اكتمل النصاب — أصدر القرار' : '';
  return `<button type="button" class="eng-card sh-card ${p.status} ${hot ? 'hot' : ''}" data-open="${p.id}">
    <div class="row"><b class="num">${esc(p.code)}</b><span class="tag">${esc(p.type)}</span><span class="sp"></span>${shBadge(p.status)}</div>
    <div class="eng-proj">${ic} ${esc(p.name)}</div>
    <div class="small muted">${esc(p.bank)} · ${esc(p.type_name)} · ${esc(p.sector_label)}</div>
    <div class="row small mt">
      <span>النسخة <b class="num">${p.version ?? '—'}</b></span>
      ${p.comments_open ? `<span class="warn-t">💬 <span class="num">${p.comments_open}</span> تعليق مفتوح</span>` : p.comments ? `<span class="muted">💬 <span class="num">${p.comments}</span></span>` : ''}
      ${p.status === 'deliberation' ? `<span>🗳 <span class="num">${p.votes}/${D.board.quorum}</span></span>` : ''}
      ${p.my_vote ? `<span class="ok-t">صوتك: ${esc(VOTE[p.my_vote][0])}</span>` : ''}
      <span class="sp"></span>${p.resolution ? `<span class="num small">${esc(p.resolution.code)}</span>` : `<span class="muted">${dt(p.updated_at)}</span>`}</div>
    ${need ? `<div class="sh-need">← ${need}</div>` : ''}
    ${p.review_soon ? `<div class="sh-need warn">المراجعة الدورية قبل ${esc(p.review_due)}</div>` : ''}
  </button>`;
}

// ───────── ملف المنتج ─────────
async function detail(ctx, id) {
  const { sb, root } = ctx;
  let P;
  try { P = await rpc(sb, 'sharia_product', { p_id: id }); }
  catch (e) { ctx.shOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const me = D.me, delib = P.status === 'deliberation';
  ctx.shDiff = ctx.shDiff ?? !!P.previous;
  const back = () => { ctx.shOpen = null; render(ctx); };
  root.innerHTML = `
    <button class="btn ghost sm eng-back" data-back>→ كل المنتجات</button>
    <div class="card sh-head">
      <div class="row"><b class="num">${esc(P.code)}</b><span class="tag">${esc(P.type)}</span><span class="sp"></span>${shBadge(P.status)}</div>
      <h2>${(SECTORS[P.sector] || ['•'])[0]} ${esc(P.name)}</h2>
      <p class="muted" style="margin:2px 0 8px">${esc(P.line || '')}</p>
      <dl class="kv sm"><dt>المصرف</dt><dd>${esc(P.bank)}</dd><dt>الصيغة</dt><dd>${esc(P.type_name)} — ${esc(P.type_essence)}</dd><dt>القطاع</dt><dd>${esc(P.sector_label)}</dd>
        <dt>نسخة العقد</dt><dd><span class="num">${P.current?.n ?? '—'}</span> · البصمة ${shortSha(P.current?.sha256)}${P.approved_version ? ` · المعتمدة: <span class="num">${P.approved_version.n}</span>` : ''}</dd>
        ${P.status_note ? `<dt>ملاحظة</dt><dd>${esc(P.status_note)}</dd>` : ''}${P.review_due ? `<dt>المراجعة الدورية</dt><dd class="${P.review_soon ? 'warn-t' : ''}">${esc(P.review_due)}</dd>` : ''}</dl>
    </div>
    <div data-act></div>
    <div class="row sh-ctl"><h3 class="sh-sec" style="margin:0">نص العقد — النسخة <span class="num">${P.current?.n ?? '—'}</span></h3><span class="sp"></span>
      ${P.previous ? `<label class="sh-sw"><input type="checkbox" data-diff ${ctx.shDiff ? 'checked' : ''}> الفروق عن النسخة <span class="num">${P.previous.n}</span></label>` : ''}
      ${['deliberation', 'submitted'].includes(P.status) && me.role !== 'sharia_secretary' ? '<button class="btn ghost sm" data-general>ملاحظة عامة</button>' : ''}</div>
    ${P.current?.change_note && P.current.n > 1 ? `<div class="notice"><span>✎</span><span class="small"><b>ما عدّله المصرف في النسخة <span class="num">${P.current.n}</span>:</b> ${esc(P.current.change_note)}</span></div>` : ''}
    ${contractHtml(P, { showDiff: ctx.shDiff, canComment: ['deliberation', 'submitted'].includes(P.status), canResolve: true })}
    <div class="grid g2 mt">
      <div class="card"><h3>ضوابط الصيغة على ${esc(P.board.madhhab_label)}</h3>
        <ul class="ticks">${(P.type_rules?.conditions || []).map(c => `<li>${esc(c)}</li>`).join('')}</ul>
        <h4 class="mt">الحرّاس الآليون بعد الاعتماد</h4><ol class="small">${(P.type_rules?.guards || []).map(c => `<li>${esc(c)}</li>`).join('')}</ol></div>
      <div class="card"><h3>بيانات المنتج</h3><dl class="kv sm">
        <dt>نسبة الربح</dt><dd>${P.pricing?.profit_min != null ? `<span class="num">${P.pricing.profit_min}%</span> – <span class="num">${P.pricing.profit_max}%</span> سنوياً` : '—'}</dd>
        <dt>المدة</dt><dd>${P.pricing?.term_max ? `<span class="num">${P.pricing.term_min || 1}</span> – <span class="num">${P.pricing.term_max}</span> شهراً` : '—'}</dd>
        <dt>الضمانات</dt><dd>${(P.guarantees || []).map(g => ({ single_salary: 'كفالة راتب', multi_salary: 'كفالة رواتب', mortgage: 'رهن عقار', gold: 'رهن ذهب' }[g] || g)).join('، ') || '—'}</dd>
        <dt>الملحقات</dt><dd>${(P.attachments || []).map(esc).join('، ') || '—'}</dd></dl></div>
    </div>
    ${P.votes.length ? `<h3 class="sh-sec">الأصوات على النسخة <span class="num">${P.current?.n}</span></h3><div class="card">${P.votes.map(v => `<div class="sh-vote"><b>${esc(v.name)}</b>${v.head ? ' <span class="tag">الرئيس</span>' : ''} ${badge(VOTE[v.vote])}
      ${v.condition ? `<div class="small">الشرط: ${esc(v.condition)}</div>` : ''}${v.reason ? `<div class="small">السبب: ${esc(v.reason)}</div>` : ''}<div class="small muted">${dt(v.at)}</div></div>`).join('')}</div>` : ''}
    ${P.resolutions_list.length ? `<h3 class="sh-sec">قرارات الهيئة على هذا المنتج</h3>${P.resolutions_list.map(resolutionHtml).join('')}` : ''}
    <details class="card mt"><summary><b>نسخ العقد (<span class="num">${P.version_list.length}</span>) والسجل الزمني</b></summary>
      <div class="sh-vers">${P.version_list.map(v => `<div><b>النسخة <span class="num">${v.n}</span></b> · ${esc(v.status)} · ${dt(v.at)} · ${esc(v.by || '')} · ${shortSha(v.sha256)}${v.change_note ? `<div class="small muted">${esc(v.change_note)}</div>` : ''}</div>`).join('')}</div>
      <ul class="sh-log">${P.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.who || '')}</b> ${l.side === 'bank' ? '<span class="tag">المصرف</span>' : ''} — ${esc(l.action)}${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>`;
  root.querySelector('[data-back]').onclick = back;
  const dsw = root.querySelector('[data-diff]'); if (dsw) dsw.onchange = () => { ctx.shDiff = dsw.checked; detail(ctx, id); };
  const reload = () => detail(ctx, id);
  root.querySelectorAll('[data-comment]').forEach(x => x.onclick = () => comment(ctx, P, Number(x.dataset.comment), reload));
  const g = root.querySelector('[data-general]'); if (g) g.onclick = () => comment(ctx, P, null, reload);
  root.querySelectorAll('[data-resolve]').forEach(x => x.onclick = async () => {
    try { await rpc(sb, 'sharia_comment_resolve', { p_review: x.dataset.resolve, p_resolved: true }); toast('عُلّم التعليق معالَجاً', 'ok'); reload(); } catch (e) { toast(cleanErr(e), 'bad'); }
  });
  actionCard(ctx, P, root.querySelector('[data-act]'), reload);
}

function comment(ctx, P, n, reload) {
  const cl = n ? P.current.clauses.find(c => c.n === n) : null;
  const m = modal(`<h3>${n ? `تعليق على البند <span class="num">${n}</span>: ${esc(cl?.title || '')}` : 'ملاحظة عامة على المنتج'}</h3>
    ${cl ? `<blockquote class="sh-q">${esc(cl.text)}</blockquote>` : ''}
    <div class="field"><label>تعليقك (يراه المصرف وبقية الأعضاء)</label><textarea class="input" rows="4" data-b placeholder="مثال: يُنص على أن الوعد غير ملزم…"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إرسال التعليق</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = async e => {
    e.target.disabled = true;
    try { await rpc(ctx.sb, 'sharia_comment', { p_id: P.id, p: { clause_n: n, body: m.el.querySelector('[data-b]').value } }); m.close(); toast('أُرسل التعليق للمصرف', 'ok'); reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  setTimeout(() => m.el.querySelector('[data-b]').focus(), 80);
}

// «المطلوب منك الآن» حسب دورك وحالة المنتج
function actionCard(ctx, P, box, reload) {
  const me = D.me, sb = ctx.sb;
  if (P.status === 'submitted' && (me.secretary || me.head)) {
    const ok = P.checklist.every(c => c.ok);
    box.innerHTML = `<div class="card sh-now"><h3>المطلوب منك الآن: التحقق من اكتمال الملف</h3>
      <ul class="sh-check">${P.checklist.map(c => `<li class="${c.ok ? 'ok' : 'no'}"><i>${c.ok ? '✓' : '✗'}</i>${esc(c.label)}</li>`).join('')}</ul>
      ${ok ? '<p class="small ok-t">الملف مكتمل — أحِله للأعضاء.</p>' : '<p class="small warn-t">في الملف نقص — أعِده للمصرف مع السبب، أو أحِله إن رأيت ذلك.</p>'}
      <div class="row mt"><button class="btn ghost" data-ret>إعادة للمصرف بسبب</button><span class="sp"></span><button class="btn cyan" data-ref>إحالة للأعضاء للمداولة ←</button></div></div>`;
    box.querySelector('[data-ref]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'sharia_screen', { p_id: P.id, p: { action: 'refer' } });
        await resultScreen({ title: 'أُحيل للأعضاء', msg: 'بدأت المداولة على بنود العقد والتصويت.', chips: ['رئيس الهيئة', 'الأعضاء', P.bank] }); reload(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
    box.querySelector('[data-ret]').onclick = () => {
      const miss = P.checklist.filter(c => !c.ok).map(c => '• ' + c.label).join('\n');
      const m = modal(`<h3>إعادة الملف للمصرف</h3><div class="field"><label>السبب (يصل المصرف كما تكتبه)</label><textarea class="input" rows="5" data-n>${esc(miss ? 'الملف ناقص:\n' + miss : '')}</textarea></div>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إعادة للمصرف</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      m.el.querySelector('[data-ok]').onclick = async e => {
        e.target.disabled = true;
        try { await rpc(sb, 'sharia_screen', { p_id: P.id, p: { action: 'return', note: m.el.querySelector('[data-n]').value } }); m.close();
          await resultScreen({ title: 'أُعيد للمصرف', msg: 'يصل المصرفَ السببُ ويعدّل ثم يقدّم من جديد.', chips: [P.bank] }); reload(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    };
    return;
  }
  if (P.status === 'deliberation') {
    const mv = P.votes.find(v => v.mine);
    box.innerHTML = `<div class="card sh-now"><h3>${me.voter ? (mv ? 'صوتك مسجّل — يمكنك تغييره حتى صدور القرار' : 'المطلوب منك الآن: صوّت على النسخة <span class="num">' + P.current.n + '</span>') : 'المداولة جارية'}</h3>
      ${tallyHtml(P.tally)}
      ${me.voter ? `<div class="sh-votebtns mt">${Object.entries(VOTE).map(([k, [t]]) => `<button type="button" class="sh-vb ${k} ${mv?.vote === k ? 'on' : ''}" data-v="${k}">${k === 'approve' ? '✓' : k === 'approve_cond' ? '◐' : '✗'} ${t}</button>`).join('')}</div>` : ''}
      ${me.head ? `<div class="row mt"><span class="small muted">بعد اكتمال النصاب تصدر القرار وتوقّعه برمز تحقق.</span><span class="sp"></span><button class="btn cyan" data-dec>إصدار القرار ←</button></div>` : ''}</div>`;
    box.querySelectorAll('[data-v]').forEach(x => x.onclick = () => vote(ctx, P, x.dataset.v, reload));
    const dec = box.querySelector('[data-dec]'); if (dec) dec.onclick = () => decide(ctx, P, reload);
    return;
  }
  if (me.head && ['approved', 'conditional', 'suspended'].includes(P.status)) {
    box.innerHTML = `<div class="card sh-now calm"><h3>المنتج ${P.status === 'suspended' ? 'معلّق — لا يظهر للمقترضين' : 'نافذ ويظهر للمقترضين'}</h3>
      <p class="small muted">التعليق أو السحب يوقف الطلبات الجديدة فقط، والعقود الموقّعة تبقى على نسختها.</p>
      <div class="row">${P.status === 'suspended' ? '<button class="btn cyan" data-pa="reinstate">رفع التعليق</button>' : '<button class="btn ghost" data-pa="suspend">تعليق مؤقت</button>'}
        <button class="btn ghost" data-pa="withdraw" style="color:var(--bad)">سحب الاعتماد</button></div></div>`;
    box.querySelectorAll('[data-pa]').forEach(x => x.onclick = () => postAction(ctx, P, x.dataset.pa, reload));
    return;
  }
  box.innerHTML = '';
}

function vote(ctx, P, v, reload) {
  const need = v === 'approve_cond' ? 'الشرط' : v === 'reject' ? 'سبب عدم الموافقة' : '';
  const go = async (extra = {}) => {
    try { const t = await rpc(ctx.sb, 'sharia_vote', { p_id: P.id, p: { vote: v, ...extra } });
      toast(`سُجّل صوتك: ${VOTE[v][0]}${t.proposed ? ` — النتيجة الآن: ${t.proposed_label}` : ''}`, 'ok'); reload(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
  if (!need) return go();
  const m = modal(`<h3>${VOTE[v][0]}</h3><div class="field"><label>${need} ★</label><textarea class="input" rows="4" data-t></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>تسجيل الصوت</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = () => { const t = m.el.querySelector('[data-t]').value; m.close(); go(v === 'approve_cond' ? { condition: t } : { reason: t }); };
}

function decide(ctx, P, reload) {
  const t = P.tally, prop = t.proposed;
  const opts = [['approved', 'اعتماد'], ['conditional', 'اعتماد مشروط'], ['returned', 'إعادة للتعديل'], ['rejected', 'رفض']];
  // المتاح: الإعادة دائماً، وغيرها فقط إن طابق نتيجة التصويت بعد اكتمال النصاب
  const allowed = k => k === 'returned' || (t.quorum_ok && k === prop);
  let sel = allowed(prop) ? prop : 'returned';
  const m = modal(`<h3>إصدار قرار الهيئة — ${esc(P.name)}</h3>${tallyHtml(t)}
    <label class="lbl mt">القرار</label><div class="sh-decs">${opts.map(([k, l]) => `<label class="${allowed(k) ? '' : 'off'} ${sel === k ? 'on' : ''}"><input type="radio" name="dc" value="${k}" ${sel === k ? 'checked' : ''} ${allowed(k) ? '' : 'disabled'}>${l}</label>`).join('')}</div>
    ${!t.quorum_ok ? `<p class="small warn-t">لم يكتمل النصاب (<span class="num">${t.cast}/${t.quorum}</span>) — المتاح الآن الإعادة للتعديل فقط.</p>` : ''}
    <div class="field mt"><label>نص القرار <span class="muted small" data-req>(اختياري للاعتماد — يُكتب تلقائياً)</span></label><textarea class="input" rows="4" data-b></textarea></div>
    <p class="small muted">يُختم القرار ببصمة نسخة العقد <span class="num">${P.current.n}</span> (${shortSha(P.current.sha256)})، وتوقّعه برمز تحقق.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>توقيع وإصدار</button></div>`, { wide: true });
  const req = m.el.querySelector('[data-req]');
  m.el.querySelectorAll('input[name=dc]').forEach(r => r.onchange = () => { sel = r.value; m.el.querySelectorAll('.sh-decs label').forEach(l => l.classList.toggle('on', l.querySelector('input').checked)); req.textContent = ['returned', 'rejected'].includes(sel) ? '★ (السبب مطلوب)' : '(اختياري للاعتماد — يُكتب تلقائياً)'; });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-ok]').onclick = async () => {
    const body = m.el.querySelector('[data-b]').value;
    if (['returned', 'rejected'].includes(sel) && body.trim().length < 5) return toast('اكتب نص القرار وسببه', 'bad');
    m.close();
    let res;
    const tk = await signOtp(ctx, { title: 'توقيع قرار الهيئة', purpose: `${DECISION[sel][0]}: ${P.name}`,
      verify: async otp => { res = await rpc(ctx.sb, 'sharia_decide', { p_id: P.id, p: { decision: sel, body, otp } }); } });
    if (!tk || !res) return;
    await resultScreen({ ok: true, title: `صدر القرار: ${res.decision_label}`, ref: res.code,
      msg: ['approved', 'conditional'].includes(res.decision) ? 'المنتج يظهر الآن للمقترضين في المصرف، بالنسخة المعتمدة حرفياً.' : 'وصل القرار وسببه إلى المصرف.',
      chips: [P.bank, 'البنك المركزي العراقي', 'سجل قرارات الهيئة'], seal: res.seal });
    reload();
  };
}

async function postAction(ctx, P, act, reload) {
  const L = { suspend: ['تعليق مؤقت', 'سبب التعليق'], reinstate: ['رفع التعليق', ''], withdraw: ['سحب الاعتماد', 'سبب السحب'] }[act];
  let note = '';
  if (L[1]) {
    note = await new Promise(res => {
      const m = modal(`<h3>${L[0]} — ${esc(P.name)}</h3><div class="field"><label>${L[1]} ★</label><textarea class="input" rows="4" data-t></textarea></div>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>متابعة</button></div>`, { onClose: () => res(null) });
      m.el.querySelector('[data-x]').onclick = m.close;
      m.el.querySelector('[data-ok]').onclick = () => { const v = m.el.querySelector('[data-t]').value; if (v.trim().length < 5) return toast('اكتب السبب', 'bad'); res(v); m.close(); };
    });
    if (note == null) return;
  }
  let r;
  const tk = await signOtp(ctx, { title: `توقيع: ${L[0]}`, purpose: P.name,
    verify: async otp => { r = await rpc(ctx.sb, 'sharia_post_action', { p_id: P.id, p: { action: act, note, otp } }); } });
  if (!tk || !r) return;
  await resultScreen({ title: `صدر القرار: ${L[0]}`, ref: r.code, msg: act === 'reinstate' ? 'عاد المنتج للظهور للمقترضين.' : 'توقف عرض المنتج للطلبات الجديدة. العقود الموقّعة تبقى على نسختها.', chips: [P.bank, 'البنك المركزي العراقي'] });
  reload();
}

// ───────── سجل القرارات ─────────
function resList(ctx, body) {
  body.innerHTML = D.resolutions.length ? `<div class="card"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم القرار</th><th>القرار</th><th>المنتج</th><th>المصرف</th><th>النسخة</th><th>التاريخ</th><th>الختم</th></tr></thead><tbody>
    ${D.resolutions.map(r => `<tr data-open="${r.product_id}" style="cursor:pointer"><td class="num"><b>${esc(r.code)}</b></td><td>${badge(DECISION[r.decision] || [r.decision, 'muted'])}</td><td>${esc(r.product)}</td><td>${esc(r.bank)}</td><td class="num">${r.version ?? '—'}</td><td>${dt(r.issued_at)}</td><td>${shortSha(r.seal)}</td></tr>`).join('')}
    </tbody></table></div></div>` : '<div class="card empty">لم تصدر قرارات بعد</div>';
  body.querySelectorAll('[data-open]').forEach(x => x.onclick = () => { ctx.shOpen = x.dataset.open; ctx.shTab = 'work'; window.scrollTo(0, 0); render(ctx); });
}

// ───────── مكتبة الصيغ ─────────
function library(body) {
  body.innerHTML = `<div class="notice"><span>ℹ</span><span class="small">ملخص لضوابط التصميم على ${esc(D.board.madhhab_label)}. <b>النص الفقهي النهائي لكل صيغة وشروطها تعتمده الهيئة</b>، والحرّاس الآليون يمنعون أي خطوة تخالفها في مسار المصرف الإسلامي.</span></div>
    <div class="sh-lib">${D.types.map(t => `<details class="card sh-type"><summary><b class="num">${esc(t.code)}</b> <b>${esc(t.name)}</b> <span class="small muted">— ${esc(t.essence)}</span>
      <span class="sp"></span>${t.sectors.map(s => `<span class="tag">${(SECTORS[s] || ['', s])[0]} ${(SECTORS[s] || ['', s])[1]}</span>`).join('')}</summary>
      <p class="small"><b>للمقترض:</b> ${esc(t.borrower_line)}</p>
      <h4>الضوابط</h4><ul class="ticks">${(t.rules.conditions || []).map(c => `<li>${esc(c)}</li>`).join('')}</ul>
      <h4>الحرّاس الآليون</h4><ol class="small">${(t.rules.guards || []).map(c => `<li>${esc(c)}</li>`).join('')}</ol></details>`).join('')}</div>
    <div class="card mt"><h3>ضابط عام في كل الصيغ — التأخر في السداد</h3><p class="small">يُمنع آلياً احتساب أي زيادة على الدين المتأخر لمصلحة المصرف. ما يُسمح به يحدده قرار الهيئة: المطالبة والضمانات، أو التعويض عن ضرر فعلي إن أقرّته، أو شرط تبرّع لصندوق خيري لا يدخل إيرادات المصرف.</p>
      ${D.board.late_rule ? `<p class="small"><b>قاعدة الهيئة الحالية:</b> ${esc(D.board.late_rule)}</p>` : ''}</div>`;
}

// ───────── الهيئة والإعدادات ─────────
function boardView(ctx, body) {
  const b = D.board, head = D.me.head;
  body.innerHTML = `<div class="grid g2">
    <div class="card"><h3>أعضاء الهيئة</h3>${b.members.map(m => `<div class="sh-mem"><span class="av sm">${esc(m.name.replace(/^(الشيخ|السيد|د\.|م\.)\s*/g, '').trim()[0] || '؟')}</span><div><b>${esc(m.name)}</b><div class="small muted">${esc(m.role_title)}${m.specialty ? ' · ' + esc(m.specialty) : ''} · <span class="num">${esc(m.code || '')}</span></div></div></div>`).join('')}
      <p class="small muted mt">${head ? 'تضيف عضواً جديداً من «فريقي» في الأعلى.' : ''} نطاق الاعتماد الآن: <b>${b.scope === 'central' ? 'هيئة مركزية واحدة لكل المصارف الإسلامية' : 'هيئة المصرف'}</b>. المرحلة الثانية: هيئة في كل مصرف إسلامي.</p></div>
    <div class="card"><h3>إعدادات الهيئة</h3>
      <form data-f class="grid" style="gap:10px">
        <div class="field"><label>اسم الهيئة</label><input class="input" name="name" value="${esc(b.name)}" ${head ? '' : 'disabled'}></div>
        <div class="field"><label>المذهب</label><input class="input" value="${esc(b.madhhab_label)}" disabled><small class="muted">قرار المستخدم: كل الصيغ على المذهب الجعفري.</small></div>
        <div class="field"><label>المرجع الذي تُعتمد فتاواه</label><input class="input" name="marja" value="${esc(b.marja || '')}" placeholder="تحدده الهيئة" ${head ? '' : 'disabled'}></div>
        <div class="grid g2" style="gap:10px">
          <div class="field"><label>النصاب (عدد المصوّتين)</label><input class="input" name="quorum" type="number" min="1" max="${b.voters}" value="${b.quorum}" dir="ltr" ${head ? '' : 'disabled'}></div>
          <div class="field"><label>المراجعة الدورية (شهر)</label><input class="input" name="review_months" type="number" min="1" max="60" value="${b.review_months}" dir="ltr" ${head ? '' : 'disabled'}></div></div>
        <div class="field"><label>قاعدة الأغلبية</label><select class="input" name="majority" ${head ? '' : 'disabled'}><option value="simple" ${b.majority === 'simple' ? 'selected' : ''}>أغلبية بسيطة</option><option value="two_thirds" ${b.majority === 'two_thirds' ? 'selected' : ''}>ثلثا الأصوات</option></select></div>
        <label class="row small"><input type="checkbox" name="chair_casting" ${b.chair_casting ? 'checked' : ''} ${head ? '' : 'disabled'}> صوت الرئيس مرجّح عند التساوي</label>
        <div class="field"><label>معالجة التأخر في السداد</label><textarea class="input" name="late_rule" rows="3" ${head ? '' : 'disabled'}>${esc(b.late_rule || '')}</textarea></div>
        ${head ? '<div class="row"><span class="sp"></span><button class="btn cyan">حفظ الإعدادات</button></div>' : '<p class="small muted">الإعدادات يضبطها رئيس الهيئة.</p>'}
      </form></div></div>`;
  const f = body.querySelector('[data-f]');
  if (head) f.onsubmit = async e => {
    e.preventDefault();
    const p = { name: f.name.value, marja: f.marja.value, quorum: f.quorum.value, review_months: f.review_months.value, majority: f.majority.value, chair_casting: f.chair_casting.checked, late_rule: f.late_rule.value };
    try { await rpc(ctx.sb, 'sharia_settings', { p }); toast('حُفظت إعدادات الهيئة', 'ok'); render(ctx); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
}
