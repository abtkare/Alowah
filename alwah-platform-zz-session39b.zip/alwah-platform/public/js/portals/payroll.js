// الجلسة 14: موظف توطين الرواتب في المصرف الموطَّن — يستلم مفاتحات المصارف المُقرضة لتأييد توطين راتب الكفيل ثم تفعيل الاستقطاع المباشر
// يرى المفاتحة فقط (الكفيل وحسابه ومبلغ الاستقطاع ورقم الطلب) دون بقية تفاصيل التمويل
import { esc, el, iqd, num, kpi, badge, SREF_STATUS, DD_MODE, DOC_LABEL, dt, ago, rpc, toast, cleanErr, closeDrawer, tabs, modal, viewDoc } from '../core.js';
import { cameraCapture, docThumb } from '../capture.js';

export async function render(ctx) {
  const { sb, root, org } = ctx;
  const refs = await rpc(sb, 'payroll_inbox', {}).catch(e => { toast(cleanErr(e), 'bad'); return []; });
  const open = refs.filter(r => ['pending', 'confirmed'].includes(r.status));
  const ready = refs.filter(r => r.status === 'confirmed' && r.app_stage >= 19);
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)} — توطين الرواتب</h1><p>مفاتحات المصارف المُقرضة لتفعيل الاستقطاع المباشر على رواتب الكفلاء الموطَّنة لديكم. ترى المفاتحة فقط دون بقية تفاصيل التمويل.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('مفاتحات تنتظر إجراء', `<span class="num">${open.length}</span>`, 'تأييد أو تفعيل', true)}
      ${kpi('جاهزة للتفعيل', `<span class="num">${ready.length}</span>`, 'بعد موافقة الإدارة العليا للمصرف المُقرض')}
      ${kpi('استقطاعات مفعَّلة', `<span class="num">${refs.filter(r => r.status === 'activated').length}</span>`)}
      ${kpi('مرفوضة', `<span class="num">${refs.filter(r => r.status === 'rejected').length}</span>`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;
  const body = root.querySelector('#body');
  const defs = [{ key: 'open', label: 'المفاتحات الواردة', count: open.length }, { key: 'all', label: 'كل المفاتحات' }];
  ctx.prTab = ctx.prTab || 'open';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.prTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.prTab));

  function show(k) {
    const list = k === 'open' ? open : refs;
    body.innerHTML = list.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
      <th>رقم المفاتحة</th><th>المصرف المُقرض</th><th>رقم الطلب</th><th>الكفيل</th><th>جهة العمل</th><th>حساب الراتب</th><th>مبلغ الاستقطاع</th><th>الحالة</th><th>وردت</th></tr></thead><tbody>
      ${list.map((r, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(r.code)}</b></td><td>${esc(r.bank_name)}</td><td class="num">${esc(r.app_code)}</td>
        <td>${esc(r.guarantor_name)}</td><td>${esc(r.employer)}</td><td class="num" dir="ltr">${esc(r.salary_account)}</td><td>${iqd(r.installment)}</td>
        <td>${badge(SREF_STATUS[r.status])}</td><td class="muted small">${ago(r.created_at)}</td></tr>`).join('')}
      </tbody></table></div></div>` : `<div class="card empty">${k === 'open' ? 'لا توجد مفاتحات تنتظر إجراءك.' : 'لا توجد مفاتحات.'}</div>`;
    body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openRef(list[+tr.dataset.i]));
  }
  show(ctx.prTab);

  async function openRef(r) {
    closeDrawer();
    const docs = (await sb.from('app_documents').select('id,kind,source,mime,data,created_at,uploaded_by_title').eq('salary_referral_id', r.id).order('created_at')).data || [];
    const dk = k => docs.filter(d => d.kind === k).slice(-1)[0];
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer"><div class="dh"><div><div class="small" style="color:#8FA3C0">مفاتحة استقطاع مباشر</div><h2 class="num">${esc(r.code)}</h2></div><span class="sp"></span>${badge(SREF_STATUS[r.status])}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">
        <div class="card mb letter" style="line-height:1.9">
          <p style="margin:0"><b>إلى/ ${esc(org.name)} — قسم توطين الرواتب</b></p>
          <p style="margin:0"><b>م/ تأييد توطين راتب وتفعيل الاستقطاع المباشر</b></p>
          <p style="margin:8px 0 0">يرجى تأييد توطين راتب السيد/ة <b>${esc(r.guarantor_name)}</b> الموظف في <b>${esc(r.employer)}</b> على الحساب <b class="num" dir="ltr">${esc(r.salary_account)}</b>،
          وتفعيل الاستقطاع المباشر بمبلغ <b>${iqd(r.installment)}</b> شهرياً (${esc(DD_MODE[r.dd_mode])}) لمدة <b class="num">${num(r.term_months || 0)}</b> شهراً لصالح <b>${esc(r.bank_name)}</b>،
          بصفته كفيلاً للمقترض <b>${esc(r.borrower)}</b> في طلب التمويل <b class="num">${esc(r.app_code)}</b>.</p>
          <p class="small muted" style="margin:6px 0 0">صادر من: ${esc(r.created_by_title || '')} · ${dt(r.created_at)}${r.note ? ` · ملاحظة: ${esc(r.note)}` : ''}</p></div>
        <div class="card mb"><h3>البيانات</h3><dl class="kv">
          <dt>الراتب المصرَّح به</dt><dd>${r.declared_salary ? iqd(r.declared_salary) : '—'}</dd>
          ${r.net_salary ? `<dt>الراتب الصافي الموطَّن</dt><dd>${iqd(r.net_salary)}</dd>` : ''}
          ${r.mandate_no ? `<dt>رقم تخويل الاستقطاع</dt><dd class="num">${esc(r.mandate_no)}</dd><dt>يبدأ الاستقطاع</dt><dd class="num">${esc(r.start_date)}</dd>` : ''}
          <dt>مرحلة الطلب لدى المصرف المُقرض</dt><dd><span class="num">${r.app_stage}</span>${r.app_stage < 19 ? ' — التفعيل بعد موافقة الإدارة العليا (المرحلة 19)' : ''}</dd>
          ${r.decided_by_title ? `<dt>آخر إجراء</dt><dd>${esc(r.decided_by_title)} · ${dt(r.decided_at)}</dd>` : ''}</dl>
          ${docs.length ? `<div class="doc-row">${docs.map(d => `<div data-doc="${d.id}">${docThumb(d, DOC_LABEL[d.kind] || 'مستند')}</div>`).join('')}</div>` : ''}</div>
      </div><div class="df"><div class="row"></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;
    dr.querySelectorAll('[data-doc]').forEach(x => x.onclick = () => viewDoc(sb, x.dataset.doc));
    const row = dr.querySelector('.df .row');
    const btn = (l, k, fn) => { const b = el(`<button class="btn ${k}">${l}</button>`); b.onclick = fn; row.appendChild(b); };
    if (r.status === 'pending') btn('تأييد توطين الراتب', 'ok', () => confirmDlg(r));
    if (r.status === 'confirmed') {
      if (r.app_stage >= 19) btn('تفعيل الاستقطاع المباشر', 'ok', () => activateDlg(r, dk));
      else row.insertAdjacentHTML('beforeend', '<span class="small muted">التأييد مسجَّل. يُفعَّل الاستقطاع بعد موافقة الإدارة العليا للمصرف المُقرض.</span><span class="sp"></span>');
    }
    if (['pending', 'confirmed'].includes(r.status)) btn('رفض مسبب مع دليل', 'bad', () => rejectDlg(r));
    if (!row.children.length) dr.querySelector('.df').innerHTML = '<p class="muted small" style="margin:0">لا إجراء مطلوب على هذه المفاتحة.</p>';
  }

  const done = msg => { closeDrawer(); toast(msg, 'ok'); ctx.refresh(); };

  function confirmDlg(r) {
    const m = modal(`<h3>تأييد توطين راتب ${esc(r.guarantor_name)}</h3>
      <div class="field"><label>الراتب الصافي الموطَّن (د.ع)</label><input class="input" data-net inputmode="numeric" dir="ltr"></div>
      <div class="field"><label>ملاحظة (الاستقطاعات القائمة إن وجدت)</label><textarea class="input" rows="2" data-n></textarea></div>
      <p class="small muted">مبلغ الاستقطاع المطلوب ${iqd(r.installment)}. إن كان الراتب لا يغطيه فارفض المفاتحة مسبباً.</p>
      <div class="row mt"><span class="sp"></span><button class="btn ok" data-go>تأييد وإشعار المصرف المُقرض</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'payroll_action', { p_ref: r.id, p_action: 'confirm', p_data: { net_salary: m.el.querySelector('[data-net]').value.replace(/\D/g, ''), note: m.el.querySelector('[data-n]').value } }); m.close(); done('تأيَّد التوطين وأُشعر المصرف المُقرض'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }

  function activateDlg(r, dk) {
    const got = { dd_auth: dk('dd_auth') || null, dd_letter: dk('dd_letter') || null };
    const LB = { dd_auth: 'نموذج تخويل الاستقطاع الموقّع من الكفيل', dd_letter: 'كتاب تفعيل الاستقطاع المباشر الصادر من مصرفكم' };
    const m = modal(`<h3>تفعيل الاستقطاع المباشر — ${esc(r.guarantor_name)}</h3>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>رقم تخويل الاستقطاع (Mandate)</label><input class="input" data-k="mandate_no" dir="ltr"></div>
        <div class="field"><label>تاريخ بدء الاستقطاع</label><input class="input" type="date" data-k="start_date"></div>
      </div>
      ${Object.keys(LB).map(k => `<div class="field"><label>${LB[k]}</label><div class="doc-row" data-box="${k}">${docThumb(got[k], got[k] ? 'مرفق' : 'لم يُرفق بعد')}</div><button type="button" class="btn sm" data-cap="${k}">📷 تصوير أو إرفاق ملف</button></div>`).join('')}
      <div class="field"><label>ملاحظة</label><textarea class="input" rows="2" data-k="note"></textarea></div>
      <div class="row mt"><span class="sp"></span><button class="btn ok" data-go>تفعيل وإشعار المصرف المُقرض</button></div>`, { wide: true });
    m.el.querySelectorAll('[data-cap]').forEach(b => b.onclick = async () => {
      const k = b.dataset.cap;
      const shot = await cameraCapture({ title: LB[k], ratio: 0.72, allowFile: true });
      if (!shot) return;
      try {
        await rpc(sb, 'payroll_add_doc', { p_ref: r.id, p_kind: k, p_data: shot.data, p_source: shot.meta.live ? 'camera' : 'file', p_meta: shot.meta });
        got[k] = { ...shot, source: shot.meta.live ? 'camera' : 'file' };
        m.el.querySelector(`[data-box="${k}"]`).innerHTML = docThumb(got[k], 'مرفق');
      } catch (e) { toast(cleanErr(e), 'bad'); }
    });
    m.el.querySelector('[data-go]').onclick = async e => {
      const v = k => m.el.querySelector(`[data-k="${k}"]`).value.trim();
      if (!got.dd_auth || !got.dd_letter) return toast('أرفق نموذج التخويل وكتاب التفعيل', 'bad');
      e.target.disabled = true;
      try { await rpc(sb, 'payroll_action', { p_ref: r.id, p_action: 'activate', p_data: { mandate_no: v('mandate_no'), start_date: v('start_date'), note: v('note') } }); m.close(); done('فُعِّل الاستقطاع المباشر وأُشعر المصرف المُقرض'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }

  async function rejectDlg(r) {
    const reasons = (await sb.from('rejection_reasons').select('*').eq('ctx', 'payroll').order('sort')).data || [];
    let ev = null;
    const m = modal(`<h3>رفض المفاتحة ${esc(r.code)}</h3>
      <div class="field"><label>السبب</label><select class="input" data-r><option value="">اختر السبب</option>${reasons.map(x => `<option value="${x.code}">${esc(x.label)}</option>`).join('')}</select></div>
      <div class="field"><label>التفصيل</label><textarea class="input" rows="3" data-n></textarea></div>
      <div class="field"><label>ما يثبت السبب (كشف الحساب أو الاستقطاعات)</label><div data-ev class="doc-row">${docThumb(null, 'لم يُرفق دليل')}</div><button type="button" class="btn sm" data-cap>📷 تصوير أو إرفاق ملف</button></div>
      <div class="row mt"><span class="sp"></span><button class="btn bad" data-go>تأكيد الرفض وإشعار المصرف المُقرض</button></div>`, { wide: true });
    m.el.querySelector('[data-cap]').onclick = async () => {
      const shot = await cameraCapture({ title: 'ما يثبت سبب الرفض', ratio: 0.72, allowFile: true });
      if (!shot) return;
      try { ev = await rpc(sb, 'payroll_add_doc', { p_ref: r.id, p_kind: 'evidence', p_data: shot.data, p_source: shot.meta.live ? 'camera' : 'file', p_meta: shot.meta });
        m.el.querySelector('[data-ev]').innerHTML = docThumb({ ...shot, source: shot.meta.live ? 'camera' : 'file' }, 'الدليل المرفق'); }
      catch (e) { toast(cleanErr(e), 'bad'); }
    };
    m.el.querySelector('[data-go]').onclick = async e => {
      const reason = m.el.querySelector('[data-r]').value;
      if (!reason) return toast('اختر السبب', 'bad');
      if (!ev) return toast('أرفق ما يثبت السبب', 'bad');
      e.target.disabled = true;
      try { await rpc(sb, 'payroll_action', { p_ref: r.id, p_action: 'reject', p_data: { reason, note: m.el.querySelector('[data-n]').value, evidence: ev } }); m.close(); done('رُفضت المفاتحة وأُشعر المصرف المُقرض بالسبب'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }
}
