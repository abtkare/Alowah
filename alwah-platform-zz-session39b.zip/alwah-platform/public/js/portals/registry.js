// بوابة التسجيل العقاري — إحالات الرهن فقط: الخلو، المطابقة، التأشير، الفك
import { esc, el, iqd, num, kpi, badge, REF_STATUS, PROP_STATUS, dt, ago, rpc, toast, cleanErr, closeDrawer, eventsList, tabs, modal, viewDoc } from '../core.js';
import { cameraCapture, docThumb } from '../capture.js';

const NEXT = {
  pending: [{ a: 'check', l: 'استعلام الخلو', k: 'cyan' }],
  clear: [{ a: 'match', l: 'مطابقة السند وهوية المالك', k: 'ok' }],
  matched: [{ a: 'annotate', l: 'تأشير الرهن (رقم الإشارة + كتاب الرهن + صورة الإشارة)', k: 'ok' }],
  annotated: [{ a: 'release', l: 'فك الرهن (بعد براءة الذمة)', k: 'warn' }],
  encumbered: [],
};
const REJ = { a: 'reject', l: 'رفض التأشير مع السبب والدليل', k: 'bad' };

export async function render(ctx) {
  const { sb, root, orgs } = ctx;
  const [refs, props] = await Promise.all([
    sb.from('mortgage_referrals').select('*, properties(*), applications(code,citizen_name,bank_id)').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('properties').select('*').order('governorate').then(r => r.data || []),
  ]);
  const bank = id => orgs.find(o => o.id === id)?.name || '—';
  const open = refs.filter(r => ['pending', 'clear', 'matched', 'encumbered'].includes(r.status));

  root.innerHTML = `
    <div class="page-head"><div><h1>دائرة التسجيل العقاري</h1><p>ترى إحالات الرهن فقط — دون الراتب أو تفاصيل التمويل الأخرى.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('إحالات تنتظر إجراء', `<span class="num">${open.length}</span>`, 'من المصارف المشاركة', true)}
      ${kpi('رهون مؤشَّرة', `<span class="num">${refs.filter(r => r.status === 'annotated').length}</span>`)}
      ${kpi('رهون مفكوكة', `<span class="num">${refs.filter(r => r.status === 'released').length}</span>`)}
      ${kpi('عقارات في السجل', `<span class="num">${props.length}</span>`, `${props.filter(p => p.status !== 'free').length} عليها إشارة`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [{ key: 'refs', label: 'إحالات الرهن', count: open.length }, { key: 'lookup', label: 'استعلام عن عقار' }, { key: 'props', label: 'سجل العقارات' }];
  ctx.regTab = ctx.regTab || 'refs';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.regTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.regTab));

  function show(k) {
    if (k === 'refs') {
      body.innerHTML = refs.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
        <th>رقم الطلب</th><th>المصرف</th><th>رقم السند</th><th>المالك</th><th>الموقع</th><th>مبلغ الدين</th><th>الحالة</th><th>وردت</th></tr></thead><tbody>
        ${refs.map((r, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(r.applications?.code)}</b></td><td>${esc(bank(r.bank_id))}</td>
          <td><b>${esc(r.properties?.deed_no)}</b></td><td>${esc(r.properties?.owner_name)}</td><td>${esc(r.properties?.governorate)} — ${esc(r.properties?.district)}</td>
          <td>${iqd(r.debt_amount)}</td><td>${badge(REF_STATUS[r.status])}</td><td class="muted small">${ago(r.created_at)}</td></tr>`).join('')}
        </tbody></table></div></div>` : '<div class="card empty">لا توجد إحالات رهن حالياً.</div>';
      body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openRef(refs[+tr.dataset.i]));
    }
    if (k === 'lookup') {
      body.innerHTML = `<div class="card" style="max-width:640px"><h3>استعلام الخلو برقم السند</h3>
        <div class="row"><input class="input" id="q" placeholder="مثال: 1452/87 الكرادة" style="flex:1"><button class="btn" id="go">استعلام</button></div><div id="res" class="mt"></div></div>`;
      const go = () => {
        const q = body.querySelector('#q').value.trim();
        const p = props.find(x => x.deed_no.includes(q) && q);
        body.querySelector('#res').innerHTML = p ? propCard(p) : `<p class="muted">${q ? 'لا يوجد عقار بهذا الرقم في السجل.' : ''}</p>`;
      };
      body.querySelector('#go').onclick = go; body.querySelector('#q').onkeydown = e => e.key === 'Enter' && go();
    }
    if (k === 'props') {
      body.innerHTML = `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم السند</th><th>المالك</th><th>المحافظة</th><th>المنطقة</th><th>الاستعمال</th><th>المساحة</th><th>الحالة</th></tr></thead><tbody>
        ${props.map(p => `<tr><td><b>${esc(p.deed_no)}</b></td><td>${esc(p.owner_name)}</td><td>${esc(p.governorate)}</td><td>${esc(p.district)} — ${esc(p.zone || '')}</td><td>${esc(p.use_type)}</td>
        <td><span class="num">${num(p.land_area)}</span> م²</td><td>${badge(PROP_STATUS[p.status])}</td></tr>`).join('')}</tbody></table></div></div>`;
    }
  }
  show(ctx.regTab);

  function propCard(p) {
    return `<dl class="kv"><dt>رقم السند</dt><dd>${esc(p.deed_no)}</dd><dt>المالك</dt><dd>${esc(p.owner_name)}</dd>
      <dt>الموقع</dt><dd>${esc(p.governorate)} — ${esc(p.district)} — ${esc(p.zone || '')}</dd><dt>الاستعمال</dt><dd>${esc(p.use_type)}</dd>
      <dt>مساحة الأرض / البناء</dt><dd><span class="num">${num(p.land_area)} / ${num(p.build_area)}</span> م²</dd>
      <dt>عدد الشركاء</dt><dd><span class="num">${p.shares}</span>${p.shares > 1 ? ' — يلزم موافقة كل الشركاء' : ''}</dd>
      <dt>الحالة</dt><dd>${badge(PROP_STATUS[p.status])}</dd></dl>`;
  }

  async function openRef(r) {
    closeDrawer();
    const [events, sigs, dos] = await Promise.all([
      sb.from('application_events').select('*').eq('application_id', r.application_id).order('id').then(x => x.data || []),
      sb.from('event_signatures').select('event_id,actor_code,seal').eq('application_id', r.application_id).then(x => x.data || []),
      rpc(sb, 'referral_dossier', { p_ref: r.id }).catch(() => ({})),
    ]);
    const own = dos.ownership, docs = dos.docs || [];
    const dk = k => docs.find(d => d.kind === k);
    const regEvents = events.filter(e => /رهن|الخلو|مطابقة|تأشير|فك|الإحالة/.test(e.action));
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer"><div class="dh"><div><div class="small" style="color:#8FA3C0">إحالة رهن</div><h2>${esc(r.properties?.deed_no)}</h2></div><span class="sp"></span>${badge(REF_STATUS[r.status])}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">
        <div class="card mb"><h3>الإحالة</h3><dl class="kv"><dt>رقم الطلب</dt><dd class="num">${esc(r.applications?.code)}</dd><dt>المصرف المحيل</dt><dd>${esc(bank(r.bank_id))}</dd>
          <dt>المقترض</dt><dd>${esc(r.applications?.citizen_name)}</dd><dt>مبلغ الدين المطلوب تأشيره</dt><dd>${iqd(r.debt_amount)}</dd>
          ${r.annotation_no ? `<dt>رقم التأشير (إشارة الحجز)</dt><dd class="num">${esc(r.annotation_no)}</dd>` : ''}
          ${r.letter_no ? `<dt>كتاب الرهن</dt><dd>رقم <b class="num">${esc(r.letter_no)}</b>${r.letter_date ? ` في <span class="num">${esc(r.letter_date)}</span>` : ''}</dd>` : ''}<dt>تاريخ الإحالة</dt><dd>${dt(r.created_at)}</dd></dl></div>
        <div class="card mb"><h3>العقار</h3>${propCard(r.properties || {})}
          ${r.properties?.owner_name !== r.applications?.citizen_name ? '<div class="notice warn mt">المالك غير المقترض: «كفيل عيني» — يلزم إقراره أمام الدائرة عند التأشير، ومسؤوليته في حدود العقار فقط.</div>' : ''}</div>
        <div class="card mb"><h3>ما قدّمه المقترض للمطابقة</h3>
          ${own ? `<dl class="kv"><dt>إقرار الملكية</dt><dd>${own.is_owner ? 'المقترض هو المالك' : 'المالك شخص آخر وافق برمز التحقق'}</dd><dt>المالك المُقر به</dt><dd>${esc(own.owner_name)}</dd>
            <dt>رقمه الوطني</dt><dd class="num">${esc(own.owner_national_id || '—')}</dd><dt>السند المُقر به</dt><dd>${esc(own.deed_no)}</dd>
            <dt>مطابقة المنصة</dt><dd>${own.match === 'matched' ? badge(['مطابق للسجل', 'ok']) : badge(['غير مسجل في المنصة — طابقه مع الصورة', 'warn'])}</dd></dl>` : '<p class="muted small">لا إقرار ملكية مسجل.</p>'}
          <div class="doc-row">${['deed', 'poa', 'owner_id_front'].filter(dk).map(k => `<div data-doc="${dk(k).id}">${docThumb(dk(k), { deed: 'صورة السند', poa: 'وكالة المالك بالرهن', owner_id_front: 'بطاقة المالك' }[k])}</div>`).join('') || '<span class="muted small">لا صور مرفقة</span>'}</div>
          ${own && r.properties && own.owner_national_id && r.properties.owner_national_id && own.owner_national_id !== r.properties.owner_national_id ? '<div class="notice warn">الرقم الوطني للمالك المُقر به يختلف عن المسجل في السند.</div>' : ''}</div>
        ${dk('mortgage_letter') || dk('annotation_mark') ? `<div class="card mb"><h3>مرفقات التأشير</h3><div class="doc-row">${['mortgage_letter', 'annotation_mark'].filter(dk).map(k => `<div data-doc="${dk(k).id}">${docThumb(dk(k), k === 'mortgage_letter' ? 'كتاب الرهن' : 'إشارة الحجز على السند')}</div>`).join('')}</div></div>` : ''}
        ${r.status === 'rejected' ? `<div class="card mb"><h3>قرار الرفض</h3><dl class="kv"><dt>السبب</dt><dd>${esc(dos.reason || '—')}</dd><dt>التفصيل</dt><dd>${esc(r.note || '—')}</dd>
          <dt>متخذ القرار</dt><dd>${esc(r.decided_by_title || '—')}</dd><dt>التاريخ</dt><dd>${dt(r.decided_at)}</dd></dl>
          <div class="doc-row">${dk('evidence') ? `<div data-doc="${dk('evidence').id}">${docThumb(dk('evidence'), 'الدليل المرفق')}</div>` : ''}</div></div>` : ''}
        <div class="card"><h3>إجراءات التسجيل العقاري على هذا الطلب</h3>${eventsList(regEvents, sigs)}</div>
      </div><div class="df"><div class="field" style="margin-bottom:10px"><textarea class="input" rows="2" placeholder="ملاحظة (تُحفظ في سجل التدقيق)"></textarea></div><div class="row"></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;
    const row = dr.querySelector('.df .row');
    dr.querySelectorAll('[data-doc]').forEach(x => x.onclick = () => viewDoc(sb, x.dataset.doc));
    const acts = [...(NEXT[r.status] || []), ...(['pending', 'clear', 'matched', 'encumbered'].includes(r.status) ? [REJ] : [])];
    if (!acts.length) dr.querySelector('.df').innerHTML = '<p class="muted small" style="margin:0">لا إجراء مطلوب على هذه الإحالة.</p>';
    acts.forEach(x => {
      const b = el(`<button class="btn ${x.k}">${x.l}</button>`);
      b.onclick = async () => {
        if (x.a === 'reject') return rejectDialog(r, dr.querySelector('textarea').value.trim());
        if (x.a === 'annotate') return annotateDialog(r, dr.querySelector('textarea').value.trim(), dos);
        b.disabled = true;
        try {
          const res = await rpc(sb, 'registry_action', { p_ref: r.id, p_action: x.a, p_note: dr.querySelector('textarea').value.trim() || null });
          toast(x.a === 'check' ? (res.status === 'clear' ? 'العقار خالٍ من الإشارات' : 'العقار عليه إشارة — لا يصلح للرهن') : 'تم الإجراء وأُشعر المصرف', res.status === 'encumbered' ? 'bad' : 'ok');
          closeDrawer(); ctx.refresh();
        } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
      };
      row.appendChild(b);
    });
  }

  // الجلسة 14: التأشير الإلكتروني لا يتم إلا مع رقم الإشارة وصورة كتاب الرهن وصورة إشارة الحجز على السند
  async function annotateDialog(r, note0, dos) {
    if ((dos?.stage || 0) < 19) return toast('التأشير النهائي بعد موافقة الإدارة العليا للمصرف (المرحلة 19)', 'bad');
    const got = { mortgage_letter: (dos.docs || []).find(d => d.kind === 'mortgage_letter') || null, annotation_mark: (dos.docs || []).find(d => d.kind === 'annotation_mark') || null };
    const LB = { mortgage_letter: 'صورة كتاب الرهن', annotation_mark: 'صورة إشارة الحجز على السند (صحيفة العقار)' };
    const today = new Date().toISOString().slice(0, 10);
    const m = modal(`<h3>تأشير الرهن — سند ${esc(r.properties?.deed_no)}</h3>
      <p class="small muted" style="margin-top:0">مبلغ الدين ${iqd(r.debt_amount)} لصالح ${esc(bank(r.bank_id))}. لا يكتمل التأشير الإلكتروني إلا بإرفاق الصورتين.</p>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>رقم تأشير الرهن (إشارة الحجز) كما في السجل</label><input class="input" data-k="annotation_no" placeholder="مثال: ره-2026-01452"></div>
        <div class="field"><label>رقم كتاب الرهن</label><input class="input" data-k="letter_no"></div>
        <div class="field"><label>تاريخ كتاب الرهن</label><input class="input" type="date" data-k="letter_date" max="${today}" value="${today}"></div>
      </div>
      ${Object.keys(LB).map(k => `<div class="field"><label>${LB[k]}</label><div class="doc-row" data-box="${k}">${docThumb(got[k], got[k] ? 'مرفق' : 'لم يُرفق بعد')}</div><button type="button" class="btn sm" data-cap="${k}">📷 تصوير أو إرفاق ملف</button></div>`).join('')}
      <div class="field"><label>ملاحظة</label><textarea class="input" rows="2" data-k="note">${esc(note0 || '')}</textarea></div>
      <p class="small muted">يُسجَّل التأشير باسم منصبك ورمزك الوظيفي وختم إلكتروني، ويطّلع على الصورتين المصرف والبنك المركزي وهيئة النزاهة.</p>
      <div class="row mt"><span class="sp"></span><button class="btn ok" data-go>تأشير الرهن وإشعار المصرف</button></div>`, { wide: true });
    m.el.querySelectorAll('[data-cap]').forEach(b => b.onclick = async () => {
      const k = b.dataset.cap;
      const shot = await cameraCapture({ title: LB[k], hint: k === 'mortgage_letter' ? 'الكتاب كاملاً مع الرقم والتاريخ والتوقيع' : 'صفحة السند أو صحيفة العقار وعليها إشارة الحجز ورقمها', ratio: 0.72, allowFile: true });
      if (!shot) return;
      try {
        await rpc(sb, 'add_document', { p_app: r.application_id, p_kind: k, p_data: shot.data, p_source: shot.meta.live ? 'camera' : 'file', p_meta: shot.meta, p_referral: r.id });
        got[k] = { ...shot, source: shot.meta.live ? 'camera' : 'file' };
        m.el.querySelector(`[data-box="${k}"]`).innerHTML = docThumb(got[k], 'مرفق');
      } catch (e) { toast(cleanErr(e), 'bad'); }
    });
    const go = m.el.querySelector('[data-go]');
    go.onclick = async () => {
      const v = k => m.el.querySelector(`[data-k="${k}"]`).value.trim();
      if (v('annotation_no').length < 3) return toast('اكتب رقم تأشير الرهن', 'bad');
      if (!v('letter_no')) return toast('اكتب رقم كتاب الرهن', 'bad');
      if (!got.mortgage_letter) return toast('أرفق صورة كتاب الرهن', 'bad');
      if (!got.annotation_mark) return toast('أرفق صورة إشارة الحجز على السند', 'bad');
      go.disabled = true;
      try {
        await rpc(sb, 'registry_annotate', { p_ref: r.id, p_data: { annotation_no: v('annotation_no'), letter_no: v('letter_no'), letter_date: v('letter_date'), note: v('note') } });
        m.close(); closeDrawer(); toast('أُشِّر الرهن وأُرفق الكتاب وصورة الإشارة — أُشعر المصرف', 'ok'); ctx.refresh();
      } catch (e) { toast(cleanErr(e), 'bad'); go.disabled = false; }
    };
  }

  // الرفض: سبب من القائمة + تفصيل + دليل (صورة بالكاميرا أو ملف من السجل)، ويُسجَّل منصب متخذ القرار وختمه
  async function rejectDialog(r, note0) {
    const reasons = (await sb.from('rejection_reasons').select('*').eq('ctx', 'registry').order('sort')).data || [];
    let ev = null;
    const m = modal(`<h3>رفض تأشير الرهن — سند ${esc(r.properties?.deed_no)}</h3>
      <div class="field"><label>سبب الرفض</label><select class="input" data-r><option value="">اختر السبب</option>${reasons.map(x => `<option value="${x.code}">${esc(x.label)}</option>`).join('')}</select></div>
      <div class="field"><label>التفصيل (رقم البيان، رقم الإشارة، الجهة، التاريخ…)</label><textarea class="input" rows="3" data-n>${esc(note0 || '')}</textarea></div>
      <div class="field"><label>ما يثبت سبب الرفض</label><div data-ev class="doc-row">${docThumb(null, 'لم يُرفق دليل')}</div><button type="button" class="btn sm" data-cap>📷 تصوير أو إرفاق ملف</button></div>
      <p class="small muted">يُسجَّل القرار باسم منصبك ورمزك الوظيفي وختم إلكتروني، ويطّلع عليه المصرف والبنك المركزي وهيئة النزاهة.</p>
      <div class="row mt"><span class="sp"></span><button class="btn bad" data-go>تأكيد الرفض وإشعار المصرف</button></div>`, { wide: true });
    m.el.querySelector('[data-cap]').onclick = async () => {
      const shot = await cameraCapture({ title: 'صوّر ما يثبت سبب الرفض', hint: 'صفحة السجل أو الإشارة أو البيان', ratio: 0.72, allowFile: true });
      if (!shot) return;
      try {
        ev = await rpc(sb, 'add_document', { p_app: r.application_id, p_kind: 'evidence', p_data: shot.data, p_source: shot.meta.live ? 'camera' : 'file', p_meta: shot.meta, p_referral: r.id });
        m.el.querySelector('[data-ev]').innerHTML = docThumb({ ...shot, source: shot.meta.live ? 'camera' : 'file' }, 'الدليل المرفق');
      } catch (e) { toast(cleanErr(e), 'bad'); }
    };
    const go = m.el.querySelector('[data-go]');
    go.onclick = async () => {
      const reason = m.el.querySelector('[data-r]').value, note = m.el.querySelector('[data-n]').value.trim();
      if (!reason) return toast('اختر سبب الرفض', 'bad');
      if (!ev) return toast('أرفق ما يثبت سبب الرفض', 'bad');
      go.disabled = true;
      try { await rpc(sb, 'registry_action', { p_ref: r.id, p_action: 'reject', p_note: note || null, p_reason: reason, p_evidence: ev }); m.close(); closeDrawer(); toast('رُفض التأشير وأُشعر المصرف بالسبب والدليل', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); go.disabled = false; }
    };
  }
}
