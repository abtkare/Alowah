// الجلسة 26: لوحة ديوان الرقابة المالية الاتحادي — جهة رقابية حكومية: اطلاع وتصدير فقط، لا كتابة على أي معاملة
// الموقف المالي للمبادرة · الصرف مقابل الإنجاز · مؤشرات التدقيق · الموردون والأسعار · التوزيع · الأداء · السداد · التقرير الرقابي
import { esc, num, iqd, mln, pct, dt, kpi, tabs, rpc, cleanErr, badge, appsTable, openApp, SECTORS, BATCH_STATUS, toast } from '../core.js';
import { perfView } from '../perf.js';
import { analyticsView } from '../cbi-extra.js';

const PERIODS = [['', 'منذ بدء المبادرة'], ['30', 'آخر 30 يوماً'], ['90', 'آخر 90 يوماً'], ['365', 'آخر سنة']];
const SEV = { high: ['عالية', '!'], medium: ['متوسطة', '◆'], low: ['منخفضة', 'i'] };
const RULES = {
  disb_no_install: 'صرف للمورد دون توثيق التركيب',
  late90: 'أقساط متأخرة أكثر من 90 يوماً',
  fees_missing: 'تجاوز مرحلة العمولات دون إيداع',
  price_high: 'سعر أعلى من الوسيط العام',
  dup_beneficiary: 'أكثر من تمويل للمستفيد نفسه',
  ledger_gap: 'فرق بين قيد الائتمان والمعاملات',
  exec_extended: 'تمديد مدة التنفيذ مرتين فأكثر',
  fz_rejected: 'رفض دراسة الجدوى مرتين فأكثر',
};
const ratio = (a, b) => b > 0 ? a / b * 100 : null;
const pctOr = v => v == null ? '—' : pct(v);
const sectorName = k => SECTORS[k]?.[0] || k;

// ───────── تصدير CSV يفتحه Excel بالعربية ─────────
function exportCsv(name, head, rows) {
  const cell = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = '﻿' + [head, ...rows].map(r => r.map(cell).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `${name}-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast('جُهّز ملف التصدير', 'ok');
}
const xBtn = key => `<button type="button" class="btn ghost sm" data-x="${key}">⬇️ تصدير Excel</button>`;

export async function render(ctx) {
  const { sb, root } = ctx;
  const F = ctx.fa ||= { days: '', bank: '', tab: 'fin' };
  const banks = ctx.orgs.filter(o => o.type === 'bank');
  root.innerHTML = `
    <div class="page-head"><div><h1>ديوان الرقابة المالية الاتحادي</h1><p>رقابة مالية على أموال المبادرة: من الائتمان المخصص للمصارف حتى الصرف للمورد والتحصيل من المقترض.</p></div></div>
    <div class="notice dark"><div>🏛️ صلاحية هذا الحساب <b>اطلاع وتصدير فقط</b> — لا كتابة على أي معاملة ولا تعديل ولا إيقاف. كل الأرقام تُحسب آلياً من قيود النظام وسجل التدقيق المتسلسل، ولا يُدخلها أحد.</div></div>
    <div class="row mb fa-filters" style="flex-wrap:wrap;gap:8px">
      <select class="input sm" data-days aria-label="الفترة">${PERIODS.map(([v, t]) => `<option value="${v}" ${v === F.days ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <select class="input sm" data-bank aria-label="المصرف"><option value="">كل المصارف</option>${banks.map(b => `<option value="${b.id}" ${b.id === F.bank ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select>
    </div>
    <div data-kpis><div class="card"><div class="spin"></div></div></div>
    <div id="tabs"></div><div id="body"></div>`;
  root.querySelector('[data-days]').onchange = e => { F.days = e.target.value; render(ctx); };
  root.querySelector('[data-bank]').onchange = e => { F.bank = e.target.value; render(ctx); };

  let d;
  try { d = await rpc(sb, 'audit_overview', { p_days: F.days ? +F.days : null, p_bank: F.bank || null }); }
  catch (e) { root.querySelector('[data-kpis]').innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  ctx.faData = d;
  const t = d.totals || {};
  const exN = (t.ex_high || 0) + (t.ex_medium || 0) + (t.ex_low || 0);
  root.querySelector('[data-kpis]').innerHTML = `<div class="grid g4 mb">
    ${kpi('الائتمان المخصص للمصارف', mln(t.allocated), `محجوز ${mln(t.reserved)} · مسترد ${mln(t.recovered)}`, true)}
    ${kpi('المصروف للموردين', mln(t.disbursed), `نسبة الاستخدام ${pctOr(ratio(t.ledger_disbursed, t.allocated))} من الائتمان`)}
    ${kpi('المعاملات لدى المصارف', `<span class="num">${num(t.apps)}</span>`, `${num(t.completed)} مكتملة · ${num(t.active)} قيد المعالجة · ${num(t.rejected)} مرفوضة`)}
    ${kpi('مؤشرات التدقيق', `<span class="num">${num(exN)}</span>`, `${num(t.ex_high)} عالية · ${num(t.ex_medium)} متوسطة · ${num(t.ex_low)} منخفضة`)}
    ${kpi('المبالغ المطلوبة', mln(t.requested), `الموافق عليها ${mln(t.approved)}`)}
    ${kpi('العمولات والرسوم المستوفاة', mln(t.fees), `منها عمولة البنك المركزي ${mln(t.cbi_fees)}`)}
    ${kpi('الأقساط المستحقة', mln(t.inst_due), `المسدد ${pctOr(ratio(t.inst_paid, t.inst_due))} · المتأخر ${mln(t.inst_late)}`)}
    ${kpi('القدرة المركّبة', `<span class="num">${num(t.kw)}</span> kW`, t.median_ppk ? `وسيط سعر الكيلوواط ${iqd(t.median_ppk)}` : '')}
  </div>`;

  const body = root.querySelector('#body');
  const defs = [
    { key: 'fin', label: 'الموقف المالي' }, { key: 'ex', label: 'مؤشرات التدقيق', count: t.ex_high || 0 },
    { key: 'sup', label: 'الموردون والأسعار' }, { key: 'dist', label: 'المحافظات والقطاعات' },
    { key: 'perf', label: 'الأداء والالتزام بالمدد' }, { key: 'stats', label: 'التحليل ونسب النمو' },
    { key: 'repay', label: 'السداد والمتأخرات' }, { key: 'apps', label: 'سجل المعاملات' }, { key: 'report', label: '🖨️ التقرير الرقابي' },
  ];
  tabs(root.querySelector('#tabs'), defs, k => { F.tab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === F.tab));

  let apps;
  const loadApps = async () => apps ||= (await sb.from('applications').select('*').not('bank_id', 'is', null).gte('stage', 6).order('updated_at', { ascending: false })).data || [];
  const openById = async id => { const a = (await loadApps()).find(x => x.id === id); a ? openApp(ctx, a, {}) : toast('تعذّر فتح المعاملة', 'bad'); };
  const wireX = (map) => body.querySelectorAll('[data-x]').forEach(b => b.onclick = () => map[b.dataset.x]?.());

  async function show(k) {
    if (k === 'fin') {
      body.innerHTML = `${banksCard(d.banks)}${batchesCard(d.batches)}${d.initiatives?.length ? initCard(d.initiatives) : ''}
        <p class="small muted">«المصروف للموردين» يُحسب من المعاملات التي تجاوزت مرحلة صرف المبلغ للمورد (35) أو اكتملت، والدفعات المصروفة في المشاريع البيطرية. «قيد الائتمان» هو الرقم المسجل على ائتمان المصرف لدى البنك المركزي، ويُقارن بالأول في مؤشرات التدقيق.</p>`;
      wireX({ banks: () => exportBanks(d), batches: () => exportBatches(d) });
    }
    if (k === 'ex') {
      body.innerHTML = exceptionsView(d.exceptions || [], F.rule);
      body.querySelectorAll('[data-app]').forEach(x => x.onclick = e => { e.preventDefault(); openById(x.dataset.app); });
      body.querySelectorAll('[data-rule]').forEach(c => c.onclick = () => { F.rule = F.rule === c.dataset.rule ? '' : c.dataset.rule; show('ex'); });
      wireX({ ex: () => exportEx(d) });
    }
    if (k === 'sup') { body.innerHTML = suppliersCard(d.suppliers || [], t.median_ppk); wireX({ sup: () => exportSup(d) }); }
    if (k === 'dist') { body.innerHTML = `<div class="grid g2">${govCard(d.govs || [])}${sectorCard(d.sectors || [])}</div>`; wireX({ gov: () => exportGov(d), sec: () => exportSec(d) }); }
    if (k === 'perf') return perfView(ctx, body, { mode: 'oversight' });
    if (k === 'stats') return analyticsView(ctx, body);
    if (k === 'repay') return import('../repay-ui.js').then(m => m.oversightRepayView(ctx, body));
    if (k === 'apps') {
      body.innerHTML = '<div class="card"><div class="spin"></div></div>';
      const list = (await loadApps()).filter(a => !F.bank || a.bank_id === F.bank);
      body.innerHTML = `<div class="card flush"><h3 style="padding:14px 14px 0">سجل المعاملات <span class="sp"></span>${xBtn('apps')}</h3>
        ${appsTable(list, ctx, { onOpen: a => openApp(ctx, a, {}), cols: ['code', 'name', 'gov', 'amount', 'bank', 'supplier', 'stage', 'status'] })}</div>
        <p class="small muted">افتح أي معاملة للاطلاع على مراحلها ومستنداتها وسجل التدقيق الموقّع لكل إجراء ومن نفّذه — دون أي زر تعديل.</p>`;
      wireX({ apps: () => exportApps(ctx, list) });
    }
    if (k === 'report') { body.innerHTML = reportView(ctx, d, F); body.querySelector('[data-print]').onclick = () => { const off = () => document.body.classList.remove('fa-print'); document.body.classList.add('fa-print'); window.addEventListener('afterprint', off, { once: true }); window.print(); setTimeout(off, 60000); }; }
  }
  show(F.tab);
}

export const shouldRefresh = ctx => !['perf', 'stats', 'report'].includes(ctx.fa?.tab);

// ───────── الموقف المالي ─────────
function banksCard(rows) {
  return `<div class="card flush mb"><h3 style="padding:14px 14px 0">الموقف المالي لكل مصرف <span class="sp"></span>${xBtn('banks')}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr>
    <th>المصرف</th><th>الائتمان المخصص</th><th>المحجوز</th><th>قيد الائتمان (المصروف)</th><th>نسبة الاستخدام</th><th>المصروف في المعاملات</th><th>المعاملات</th><th>العمولات المستوفاة</th><th>الأقساط: المستحق / المسدد / المتأخر</th><th>مؤشرات</th></tr></thead>
    <tbody>${rows.map(b => `<tr><td><b>${esc(b.name)}</b>${b.islamic ? ' <span class="badge info">إسلامي</span>' : ''}</td><td>${mln(b.allocated)}</td><td>${mln(b.reserved)}</td><td>${mln(b.ledger_disbursed)}</td>
      <td>${pctOr(ratio(b.ledger_disbursed, b.allocated))}</td><td>${mln(b.disbursed)}${Math.abs(b.ledger_disbursed - b.disbursed) > Math.max(1e6, b.ledger_disbursed * 0.01) ? ' ' + badge(['لا يطابق القيد', 'bad']) : ''}</td>
      <td class="num">${num(b.apps)} <span class="muted small">(${num(b.completed)} مكتملة)</span></td><td>${mln(b.fees)}</td>
      <td>${mln(b.inst_due)} / ${mln(b.inst_paid)} / <span style="color:${b.inst_late > 0 ? 'var(--bad)' : 'inherit'}">${mln(b.inst_late)}</span></td>
      <td>${b.exceptions ? badge([String(b.exceptions), 'warn']) : badge(['0', 'ok'])}</td></tr>`).join('') || '<tr><td colspan="10" class="empty">لا مصارف</td></tr>'}</tbody></table></div></div>`;
}

function batchesCard(rows) {
  return `<div class="card flush mb"><h3 style="padding:14px 14px 0">السلف التجميعية المسحوبة من ائتمان المصارف <span class="sp"></span>${xBtn('batches')}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr>
    <th>السلفة</th><th>المصرف</th><th>المبلغ</th><th>المعاملات</th><th>الحالة</th><th>وقّعها</th><th>القرار</th></tr></thead>
    <tbody>${rows.map(b => `<tr><td><b class="num">${esc(b.code)}</b>${b.letter ? `<div class="small muted">كتاب ${esc(b.letter)}</div>` : ''}</td><td>${esc(b.bank)}</td><td>${iqd(b.total)}</td><td class="num">${num(b.apps)}</td>
      <td>${badge(BATCH_STATUS[b.status] || [b.status, 'muted'])}</td><td class="small">${esc(b.signed_by || '—')}<div class="muted">${b.signed_at ? dt(b.signed_at) : ''}</div></td>
      <td class="small">${esc(b.decided_by || '—')}<div class="muted">${b.decided_at ? dt(b.decided_at) : ''}</div></td></tr>`).join('') || '<tr><td colspan="7" class="empty">لا سلف في هذه الفترة</td></tr>'}</tbody></table></div></div>`;
}

function initCard(rows) {
  return `<div class="card flush mb"><h3 style="padding:14px 14px 0">المبادرات المعلنة من البنك المركزي</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المبادرة</th><th>المبلغ المرصود</th><th>المدة</th><th>التعميم</th><th>المصارف</th></tr></thead>
    <tbody>${rows.map(i => `<tr><td><b>${esc(i.title)}</b> <span class="muted small num">${esc(i.code)}</span></td><td>${mln(i.budget)}</td><td class="small">${esc(i.start_on || '—')} ← ${esc(i.end_on || '—')}</td><td class="small">${esc(i.circular || '—')}</td><td class="num">${num(i.banks)}</td></tr>`).join('')}</tbody></table></div></div>`;
}

// ───────── مؤشرات التدقيق ─────────
function exceptionsView(list, rule) {
  const byRule = {}; list.forEach(x => (byRule[x.rule] ||= []).push(x));
  const shown = rule ? list.filter(x => x.rule === rule) : list;
  return `<div class="card mb"><h3>مؤشرات التدقيق الآلية <span class="sp"></span>${xBtn('ex')}</h3>
      <p class="small muted" style="margin-top:0">تُستخرج آلياً من بيانات المعاملات عند فتح اللوحة. المؤشر ليس اتهاماً، بل نقطة تستحق التدقيق. اضغط على نوع لتصفية القائمة.</p>
      <div class="chips">${Object.entries(RULES).map(([k, l]) => `<button type="button" class="chip ${rule === k ? 'on' : ''}" data-rule="${k}">${esc(l)} <span class="num muted">${(byRule[k] || []).length}</span></button>`).join('')}</div></div>
    ${shown.map(x => `<div class="alert ${x.sev}"><div class="ic">${SEV[x.sev][1]}</div><div style="flex:1"><div class="row"><h4>${esc(RULES[x.rule] || x.rule)}</h4><span class="sp"></span>${badge([`خطورة ${SEV[x.sev][0]}`, x.sev === 'high' ? 'bad' : x.sev === 'medium' ? 'warn' : 'info'])}</div>
      <p>${esc(x.detail)}</p><p class="small">المصرف: <b>${esc(x.bank || '—')}</b>${x.amount != null ? ` · المبلغ: ${iqd(x.amount)}` : ''}${x.app_id ? ` · <a href="#" data-app="${x.app_id}">فتح المعاملة <span class="num">${esc(x.code)}</span></a>` : ''}</p></div></div>`).join('')
      || '<div class="card empty">✓ لا مؤشرات تدقيق في هذا النطاق — الصرف موثّق، والعمولات مودعة، والأسعار ضمن المعدل، وقيود الائتمان تطابق المعاملات.</div>'}`;
}

// ───────── الموردون والأسعار ─────────
function suppliersCard(rows, median) {
  return `<div class="card flush mb"><h3 style="padding:14px 14px 0">الموردون: المبالغ والأسعار <span class="sp"></span>${xBtn('sup')}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr>
    <th>المورد</th><th>المعاملات</th><th>قيمة التمويل</th><th>المصروف له</th><th>القدرة</th><th>متوسط سعر الكيلوواط</th><th>الفرق عن الوسيط</th><th>مؤشرات</th></tr></thead>
    <tbody>${rows.map(s => { const dv = s.ppk && median ? (s.ppk / median - 1) * 100 : null;
      return `<tr><td><b>${esc(s.name)}</b></td><td class="num">${num(s.apps)} <span class="muted small">(${num(s.completed)} مكتملة)</span></td><td>${mln(s.amount)}</td><td>${mln(s.disbursed)}</td>
      <td class="num">${s.kw ? num(s.kw) + ' kW' : '—'}</td><td>${s.ppk ? iqd(s.ppk) : '<span class="muted small">مشاريع بيطرية</span>'}</td>
      <td>${dv == null ? '—' : `<span style="color:${dv > 25 ? 'var(--bad)' : dv > 10 ? 'var(--warn)' : 'inherit'}">${dv > 0 ? '+' : ''}${pct(dv)}</span>`}</td>
      <td>${(s.high_price || 0) + (s.no_install || 0) ? badge([`${s.high_price || 0} سعر · ${s.no_install || 0} توثيق`, 'warn']) : badge(['0', 'ok'])}</td></tr>`; }).join('') || '<tr><td colspan="8" class="empty">لا موردين</td></tr>'}</tbody></table></div>
    <p class="small muted" style="padding:0 14px 12px">وسيط سعر الكيلوواط العام: ${median ? iqd(median) : '—'}. يُعدّ السعر مؤشراً للتدقيق إذا زاد على الوسيط بأكثر من 25%.</p></div>`;
}

// ───────── المحافظات والقطاعات ─────────
function govCard(rows) {
  return `<div class="card flush"><h3 style="padding:14px 14px 0">حسب المحافظة <span class="sp"></span>${xBtn('gov')}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المحافظة</th><th>المعاملات</th><th>مكتملة</th><th>التمويل</th><th>المصروف</th></tr></thead>
    <tbody>${rows.map(g => `<tr><td>${esc(g.name)}</td><td class="num">${num(g.apps)}</td><td class="num">${num(g.completed)}</td><td>${mln(g.amount)}</td><td>${mln(g.disbursed)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">لا بيانات</td></tr>'}</tbody></table></div></div>`;
}
function sectorCard(rows) {
  const tot = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
  return `<div class="card flush"><h3 style="padding:14px 14px 0">حسب القطاع <span class="sp"></span>${xBtn('sec')}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القطاع</th><th>المعاملات</th><th>التمويل</th><th>الحصة</th><th>المصروف</th></tr></thead>
    <tbody>${rows.map(r => `<tr><td><i class="sw" style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${SECTORS[r.key]?.[1] || '#888'}"></i> ${esc(sectorName(r.key))}</td><td class="num">${num(r.apps)}</td><td>${mln(r.amount)}</td><td>${pctOr(ratio(r.amount, tot))}</td><td>${mln(r.disbursed)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">لا بيانات</td></tr>'}</tbody></table></div></div>`;
}

// ───────── التقرير الرقابي (للطباعة أو الحفظ PDF) ─────────
function reportView(ctx, d, F) {
  const t = d.totals || {};
  const bank = F.bank ? ctx.orgs.find(o => o.id === F.bank)?.name : 'كل المصارف';
  const period = PERIODS.find(p => p[0] === F.days)?.[1];
  const ex = d.exceptions || [];
  const exByRule = Object.entries(RULES).map(([k, l]) => [l, ex.filter(x => x.rule === k).length]).filter(x => x[1]);
  return `<div class="row mb no-print"><span class="sp"></span><button type="button" class="btn cyan" data-print>🖨️ طباعة / حفظ PDF</button></div>
  <article class="card fa-report">
    <header class="fa-rh"><img src="/alwah-logo/alwah-icon-128.webp" alt="" width="40" height="40"><div><b>ديوان الرقابة المالية الاتحادي</b><div class="small muted">تقرير رقابي آلي — منصة «ألواح» لحوكمة تمويل منظومات الطاقة الشمسية والمشاريع</div></div></header>
    <dl class="kv"><dt>النطاق</dt><dd>${esc(bank)} · ${esc(period)}</dd><dt>تاريخ الاستخراج</dt><dd>${dt(d.scope?.at)}</dd><dt>مستخرج التقرير</dt><dd>${esc(ctx.profile.full_name)} — ${esc(ctx.profile.staff_code || '')}</dd></dl>
    <h3>أولاً: الموقف المالي</h3>
    <dl class="kv"><dt>الائتمان المخصص للمصارف</dt><dd>${iqd(t.allocated)}</dd><dt>المسحوب على الائتمان (القيد)</dt><dd>${iqd(t.ledger_disbursed)} — نسبة الاستخدام ${pctOr(ratio(t.ledger_disbursed, t.allocated))}</dd>
      <dt>المصروف للموردين في المعاملات</dt><dd>${iqd(t.disbursed)}</dd><dt>المحجوز</dt><dd>${iqd(t.reserved)}</dd><dt>المسترد</dt><dd>${iqd(t.recovered)}</dd>
      <dt>المبالغ المطلوبة / الموافق عليها</dt><dd>${iqd(t.requested)} / ${iqd(t.approved)}</dd><dt>العمولات والرسوم المستوفاة</dt><dd>${iqd(t.fees)} (عمولة البنك المركزي ${iqd(t.cbi_fees)})</dd></dl>
    ${banksCard(d.banks || []).replace(xBtn('banks'), '')}
    <h3>ثانياً: المعاملات والإنجاز</h3>
    <p>عدد المعاملات لدى المصارف <b class="num">${num(t.apps)}</b>: مكتملة <b class="num">${num(t.completed)}</b>، قيد المعالجة <b class="num">${num(t.active)}</b>، مرفوضة <b class="num">${num(t.rejected)}</b>، ملغاة <b class="num">${num(t.cancelled)}</b>. القدرة المركّبة <b class="num">${num(t.kw)}</b> kW.</p>
    <h3>ثالثاً: السداد</h3>
    <p>الأقساط المستحقة ${iqd(t.inst_due)}، المسدد منها ${iqd(t.inst_paid)} (${pctOr(ratio(t.inst_paid, t.inst_due))})، والمتأخر ${iqd(t.inst_late)}.</p>
    <h3>رابعاً: مؤشرات التدقيق</h3>
    ${exByRule.length ? `<ul>${exByRule.map(([l, n]) => `<li>${esc(l)}: <b class="num">${n}</b></li>`).join('')}</ul>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>الخطورة</th><th>المؤشر</th><th>المعاملة</th><th>المصرف</th><th>المبلغ</th></tr></thead><tbody>
      ${ex.slice(0, 60).map(x => `<tr><td>${SEV[x.sev][0]}</td><td>${esc(x.detail)}</td><td class="num">${esc(x.code || '—')}</td><td>${esc(x.bank || '—')}</td><td>${iqd(x.amount)}</td></tr>`).join('')}</tbody></table></div>` : '<p>لا مؤشرات تدقيق في هذا النطاق.</p>'}
    <h3>خامساً: الموردون</h3>
    ${suppliersCard(d.suppliers || [], t.median_ppk).replace(xBtn('sup'), '')}
    <p class="small muted mt">استُخرج هذا التقرير آلياً من قيود المنصة وسجل التدقيق المتسلسل غير القابل للتعديل. صلاحية الديوان على المنصة اطلاع وتصدير فقط.</p>
  </article>`;
}

// ───────── ملفات التصدير ─────────
const M = v => Math.round(Number(v || 0));
function exportBanks(d) {
  exportCsv('الموقف-المالي-للمصارف', ['المصرف', 'الائتمان المخصص', 'المحجوز', 'قيد الائتمان (المصروف)', 'المسترد', 'المصروف في المعاملات', 'المعاملات', 'المكتملة', 'المبالغ المطلوبة', 'العمولات المستوفاة', 'الأقساط المستحقة', 'المسدد', 'المتأخر', 'مؤشرات التدقيق'],
    (d.banks || []).map(b => [b.name, M(b.allocated), M(b.reserved), M(b.ledger_disbursed), M(b.recovered), M(b.disbursed), b.apps, b.completed, M(b.requested), M(b.fees), M(b.inst_due), M(b.inst_paid), M(b.inst_late), b.exceptions]));
}
function exportBatches(d) {
  exportCsv('السلف-التجميعية', ['السلفة', 'كتاب', 'المصرف', 'المبلغ', 'المعاملات', 'الحالة', 'وقّعها', 'تاريخ التوقيع', 'تاريخ الإرسال', 'صاحب القرار', 'تاريخ القرار', 'ملاحظة'],
    (d.batches || []).map(b => [b.code, b.letter, b.bank, M(b.total), b.apps, (BATCH_STATUS[b.status] || [b.status])[0], b.signed_by, b.signed_at, b.sent_at, b.decided_by, b.decided_at, b.note]));
}
function exportEx(d) {
  exportCsv('مؤشرات-التدقيق', ['الخطورة', 'المؤشر', 'التفاصيل', 'رقم المعاملة', 'المصرف', 'المبلغ'],
    (d.exceptions || []).map(x => [SEV[x.sev][0], RULES[x.rule] || x.rule, x.detail, x.code, x.bank, M(x.amount)]));
}
function exportSup(d) {
  exportCsv('الموردون-والأسعار', ['المورد', 'المعاملات', 'المكتملة', 'قيمة التمويل', 'المصروف له', 'القدرة kW', 'متوسط سعر الكيلوواط', 'فرق السعر عن الوسيط %', 'مؤشرات السعر', 'مؤشرات التوثيق'],
    (d.suppliers || []).map(s => [s.name, s.apps, s.completed, M(s.amount), M(s.disbursed), s.kw, M(s.ppk), s.ppk && d.totals?.median_ppk ? Math.round((s.ppk / d.totals.median_ppk - 1) * 100) : '', s.high_price, s.no_install]));
}
function exportGov(d) {
  exportCsv('التوزيع-حسب-المحافظة', ['المحافظة', 'المعاملات', 'المكتملة', 'التمويل', 'المصروف', 'القدرة المركّبة kW'], (d.govs || []).map(g => [g.name, g.apps, g.completed, M(g.amount), M(g.disbursed), g.kw]));
}
function exportSec(d) {
  exportCsv('التوزيع-حسب-القطاع', ['القطاع', 'المعاملات', 'المكتملة', 'التمويل', 'المصروف'], (d.sectors || []).map(r => [sectorName(r.key), r.apps, r.completed, M(r.amount), M(r.disbursed)]));
}
function exportApps(ctx, list) {
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '';
  const st = n => ctx.stages.find(s => s.n === n)?.name || '';
  exportCsv('سجل-المعاملات', ['رقم الطلب', 'المقترض', 'المحافظة', 'المصرف', 'المورد', 'القدرة kW', 'السعر', 'مبلغ التمويل', 'القسط الشهري', 'المدة بالأشهر', 'المرحلة', 'اسم المرحلة', 'الحالة', 'تاريخ التقديم', 'آخر تحديث'],
    list.map(a => [a.code, a.citizen_name, a.governorate, org(a.bank_id), org(a.supplier_id), a.kw, M(a.price), M(a.amount), M(a.monthly_installment), a.term_months, a.stage, st(a.stage), a.status, a.submitted_at || a.created_at, a.updated_at]));
}
