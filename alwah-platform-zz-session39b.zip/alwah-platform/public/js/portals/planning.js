// الجلسة 28: بوابة وزارة التخطيط — خارطة طريق المبادرة ومؤشرات الأداء
// الوزارة تضع المراحل والأهداف، والنظام يقيس كل هدف آلياً ويحكم على حالته ويتوقع ويحلل الفجوات.
// لا كتابة على أي معاملة، ولا بيانات شخصية: أرقام مجمّعة فقط.
import { esc, num, pct, dt, kpi, tabs, rpc, cleanErr, badge, toast, modal, SECTORS, GOVS } from '../core.js';

const AXES = {
  finance: ['المال والإنجاز', '💰', '#06AFF2'],
  energy: ['الطاقة والبيئة', '⚡', '#FFB000'],
  equity: ['التوزيع العادل', '⚖️', '#1baf7a'],
  economy: ['الاقتصاد والتشغيل', '📈', '#6250d6'],
};
const ST = {
  achieved: ['متحقق', 'ok'], on_track: ['على المسار', 'info'], at_risk: ['معرّض للتأخر', 'warn'], behind: ['متأخر', 'bad'],
  missed: ['لم يتحقق', 'bad'], upcoming: ['لم تبدأ', 'muted'], nodata: ['لا بيانات بعد', 'muted'], lowdata: ['بيانات غير كافية', 'muted'],
};
const ST_ORDER = ['behind', 'missed', 'at_risk', 'on_track', 'achieved', 'lowdata', 'nodata', 'upcoming'];
// كيف يُحسب كل مؤشر — شفافية كاملة أمام الوزارة
const HOW = {
  amount_disbursed: 'مجموع مبالغ القروض التي بلغت مرحلة الصرف للمورد، وفي مبادرة الأطباء البيطريين الدفعات المصروفة فعلاً.',
  budget_use_pct: 'المبالغ المصروفة مقسومة على رصيد المبادرة المحدد في إعدادات الخارطة.',
  loans_completed: 'عدد القروض التي اكتملت دورتها وشُغّلت منظوماتها (المرحلة الأخيرة).',
  apps_submitted: 'عدد طلبات التمويل التي وصلت إلى المصارف.',
  kw_installed: 'مجموع قدرات المنظومات في القروض المكتملة.',
  mwh_year: 'القدرة المركّبة × الإنتاج السنوي لكل كيلوواط (من إعدادات الخارطة) ÷ 1000.',
  co2_t_year: 'الكهرباء المولّدة سنوياً × معامل الانبعاثات المتجنَّبة لكل ميغاواط ساعة.',
  diesel_kl_year: 'الكهرباء المولّدة سنوياً × لترات وقود المولّدات لكل كيلوواط ساعة ÷ 1000.',
  gov_covered: 'عدد المحافظات التي فيها قرض مكتمل واحد على الأقل، من أصل 18.',
  share_outside_baghdad_pct: 'المبالغ المصروفة خارج بغداد ÷ كل المبالغ المصروفة.',
  share_productive_pct: 'المبالغ المصروفة للمشاريع الزراعية والصناعية والتجارية والبيطرية ÷ كل المبالغ المصروفة.',
  share_agri_pct: 'المبالغ المصروفة للمشاريع الزراعية ÷ كل المبالغ المصروفة.',
  women_pct: 'المقترضات من النساء ÷ المقترضين المعروف جنسهم. لا يُحكم عليه إن كانت البيانات تغطي أقل من نصف المقترضين.',
  youth_pct: 'المقترضون دون 35 سنة عند التقديم ÷ المقترضين المعروف عمرهم. لا يُحكم عليه إن كانت البيانات تغطي أقل من نصف المقترضين.',
  jobs_expected: 'عدد المشاريع الإنتاجية المكتملة × فرص العمل لكل مشروع (من إعدادات الخارطة). السكني لا يُحتسب.',
  repay_on_time_pct: 'الأقساط المستحقة التي سُددت في موعدها أو قبله ÷ كل الأقساط المستحقة.',
  default_pct: 'القروض التي عليها قسط غير مسدد منذ أكثر من 90 يوماً ÷ القروض التي بدأ سدادها.',
  avg_days_complete: 'متوسط الأيام من تقديم الطلب للمصرف حتى تشغيل المنظومة، للقروض المكتملة.',
  sla_pct: 'مراحل المعاملات التي أُنجزت ضمن مدتها المحددة ÷ كل المراحل المنجزة.',
};
// روافع مقترحة عند التأخر (للاسترشاد — الوزارة لا تكتب على المعاملات)
const LEVER = {
  loans_completed: 'متابعة المصارف الأبطأ في الإنجاز مع البنك المركزي، وتسريع مراحل الكشف والتركيب.',
  amount_disbursed: 'مراجعة الطلبات المتوقفة قبل الصرف، وتوزيع ائتمان إضافي على المصارف الأسرع.',
  budget_use_pct: 'توسيع عدد المصارف الوسيطة وزيادة سقوف الائتمان للمصارف الأعلى إنجازاً.',
  kw_installed: 'تشجيع المنظومات الأكبر للمشاريع الإنتاجية، فكل مشروع زراعي يعادل عدة منظومات منزلية.',
  share_productive_pct: 'حملات تعريف في غرف التجارة واتحادات الفلاحين والصناعيين، واعتماد مكاتب دراسات الجدوى لتسهيل الطلبات الإنتاجية.',
  share_agri_pct: 'التنسيق مع وزارة الزراعة ومديرياتها لتعريف الفلاحين بالمبادرة، خصوصاً منظومات ضخ المياه.',
  share_outside_baghdad_pct: 'توجيه المصارف لتفعيل فروع المحافظات وتقليص التركّز في العاصمة.',
  gov_covered: 'التنسيق مع المحافظات غير المغطاة لتسمية مصرف وفرع ومورد معتمد فيها.',
  avg_days_complete: 'تحديد المرحلة التي تستهلك الوقت الأطول في لوحة الأداء، ومخاطبة الجهة المسؤولة عنها.',
  sla_pct: 'مراجعة المدد المحددة للمراحل مع المصارف، ومحاسبة التأخير المتكرر.',
  repay_on_time_pct: 'تعميم الاستقطاع المباشر من الراتب، وتذكير المقترضين قبل موعد القسط.',
  default_pct: 'معالجة القروض المتعثرة مبكراً، ومراجعة معايير الجدوى للقطاعات الأعلى تعثراً.',
  jobs_expected: 'رفع حصة المشاريع الإنتاجية، فهي مصدر فرص العمل في المبادرة.',
  women_pct: 'برامج تعريف موجهة للنساء ورائدات الأعمال بالتنسيق مع منظمات المجتمع المدني.',
  youth_pct: 'التنسيق مع وزارة الشباب والرياضة وحاضنات المشاريع لتعريف الشباب بالمبادرة.',
};

const sectorName = k => SECTORS[k]?.[0] || k;
const n1 = v => { v = Number(v); const a = Math.abs(v); return v.toLocaleString('en-US', { maximumFractionDigits: a > 0 && a < 0.1 ? 3 : a > 0 && a < 1 ? 2 : 1 }); };
// تنسيق القيمة حسب نوع المؤشر
function fmt(c, v, bare = false) {
  if (v == null || v === '') return '—';
  v = Number(v);
  const w = (n, u) => bare ? `${n} ${u}` : `<span class="num">${n}</span> ${u}`;
  switch (c?.fmt) {
    case 'iqd': return v >= 1e9 ? w(n1(v / 1e9), 'مليار د.ع') : v >= 1e6 ? w(n1(v / 1e6), 'مليون د.ع') : w(num(Math.round(v)), 'د.ع');
    case 'kw': return v >= 1000 ? w(n1(v / 1000), 'ميغاواط') : w(n1(v), 'كيلوواط');
    case 'pct': return bare ? `${n1(v)}%` : `<span class="num">${n1(v)}%</span>`;
    case 'days': return w(n1(v), 'يوم');
    default: return w(n1(v), c?.unit || '');
  }
}
const stBadge = s => badge(ST[s] || [s, 'muted']);
const ymd = s => s ? String(s).slice(0, 10) : '—';
const dShort = s => s ? new Date(s).toLocaleDateString('ar-IQ-u-nu-latn', { year: 'numeric', month: 'short', day: 'numeric' }) : '—';

function exportCsv(name, head, rows) {
  const cell = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = '﻿' + [head, ...rows].map(r => r.map(cell).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `${name}-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast('جُهّز ملف التصدير', 'ok');
}

// شريط الإنجاز مع علامة «المتوقع حسب الوقت»
function progBar(g) {
  const p = Math.max(0, Math.min(100, Number(g.progress) || 0));
  const showExp = ['on_track', 'at_risk', 'behind'].includes(g.status) && g.expected != null;
  return `<div class="pl-bar ${ST[g.status]?.[1] || 'muted'}"><i style="width:${p}%"></i>${showExp ? `<b style="inset-inline-start:${Math.min(100, g.expected)}%" title="المتوقع حسب الوقت المنقضي ${n1(g.expected)}%"></b>` : ''}</div>`;
}
// حلقة الإنجاز الكلي
function ring(v, size = 128, label = 'الإنجاز الموزون') {
  const r = 52, C = 2 * Math.PI * r, p = v == null ? 0 : Math.max(0, Math.min(100, v));
  const col = v == null ? '#5B6B86' : p >= 85 ? '#1baf7a' : p >= 60 ? '#FFB000' : '#e5484d';
  return `<svg class="pl-ring" viewBox="0 0 128 128" width="${size}" height="${size}" role="img" aria-label="${label} ${v == null ? '—' : n1(v) + '%'}">
    <circle cx="64" cy="64" r="${r}" fill="none" stroke="rgba(255,255,255,.12)" stroke-width="12"/>
    <circle cx="64" cy="64" r="${r}" fill="none" stroke="${col}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${C * p / 100} ${C}" transform="rotate(-90 64 64)"/>
    <text x="64" y="66" text-anchor="middle" font-size="26" font-weight="800" fill="#fff">${v == null ? '—' : Math.round(p) + '%'}</text>
    <text x="64" y="86" text-anchor="middle" font-size="10.5" fill="#9FB4D6">${label}</text></svg>`;
}

export async function render(ctx) {
  const { sb, root } = ctx;
  const F = ctx.pl ||= { tab: 'map', phase: null, axis: '' };
  root.innerHTML = `<div data-head><div class="card"><div class="spin"></div></div></div><div id="tabs"></div><div id="body"></div>`;
  let d;
  try { d = await rpc(sb, 'planning_overview'); }
  catch (e) { root.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  ctx.plData = d;
  d.cat = Object.fromEntries((d.catalog || []).map(c => [c.key, c]));
  d.phases ||= [];
  d.phases.forEach(p => (p.goals || []).forEach(g => { g._starts = p.starts; }));
  const cur = d.phases.find(p => p.id === d.current) || d.phases[0];
  if (!F.phase || !d.phases.some(p => p.id === F.phase)) F.phase = cur?.id || null;

  root.querySelector('[data-head]').innerHTML = headView(d, cur);
  const defs = [
    { key: 'map', label: 'خارطة الطريق' }, { key: 'kpi', label: 'مؤشرات الأداء' }, { key: 'axes', label: 'المحاور الأربعة' },
    { key: 'analysis', label: 'التحليل والفجوات' }, { key: 'dist', label: 'التوزيع والاتجاه' },
    ...(d.can_edit ? [{ key: 'edit', label: '✏️ إدارة الخارطة' }] : []),
    { key: 'log', label: 'سجل التعديلات' }, { key: 'report', label: '🖨️ التقرير' },
  ];
  if (!defs.some(x => x.key === F.tab)) F.tab = 'map';
  const tb = root.querySelector('#tabs'), body = root.querySelector('#body');
  tabs(tb, defs, k => { F.tab = k; show(k); });
  tb.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === F.tab));

  const show = k => {
    if (k === 'map') { body.innerHTML = mapView(d); wireGoals(body, d); }
    if (k === 'kpi') { body.innerHTML = kpiView(d, F); wireKpi(ctx, body, d, F); }
    if (k === 'axes') { body.innerHTML = axesView(d, cur); wireGoals(body, d); }
    if (k === 'analysis') { body.innerHTML = analysisView(d, cur); wireGoals(body, d); }
    if (k === 'dist') { body.innerHTML = distView(d); body.querySelector('[data-x=gov]').onclick = () => exportGov(d); }
    if (k === 'edit') { body.innerHTML = editView(d); wireEdit(ctx, body, d); }
    if (k === 'log') { body.innerHTML = logView(d); }
    if (k === 'report') {
      body.innerHTML = reportView(d, cur);
      body.querySelector('[data-print]').onclick = () => {
        const off = () => document.body.classList.remove('fa-print');
        document.body.classList.add('fa-print'); window.addEventListener('afterprint', off, { once: true }); window.print(); setTimeout(off, 1500);
      };
    }
  };
  show(F.tab);
}
export const shouldRefresh = ctx => !['edit', 'report', 'kpi'].includes(ctx.pl?.tab) && !document.querySelector('.mdl-bg');

// ───────── الرأس: المرحلة الحالية والإنجاز الكلي ─────────
function headView(d, cur) {
  const s = d.settings || {}, T = d.totals || {}, C = d.cat;
  const cnt = {}; (cur?.goals || []).forEach(g => { cnt[g.status] = (cnt[g.status] || 0) + 1; });
  const val = k => T[k]?.value;
  return `
  <div class="page-head"><div><h1>وزارة التخطيط — ${esc(s.title || 'خارطة الطريق')}</h1><p>${esc(s.vision || 'الوزارة تضع المراحل والأهداف، والنظام يقيس الإنجاز آلياً من بيانات المعاملات.')}</p></div></div>
  <div class="notice dark"><div>🗺️ تضع الوزارة <b>خارطة الطريق</b> وتعدّلها، ويقيس النظام كل هدف آلياً من قيود المعاملات. لا كتابة على أي معاملة، والأرقام مجمّعة دون بيانات شخصية. كل تعديل على الخارطة يُسجَّل بالاسم والتاريخ والسبب.</div></div>
  ${cur ? `<section class="pl-hero mb">
    <div class="pl-hero-ring">${ring(cur.score)}</div>
    <div class="pl-hero-t">
      <span class="pl-k">${cur.current && cur.elapsed > 0 && cur.elapsed < 100 ? 'المرحلة الجارية' : cur.elapsed >= 100 ? 'آخر مرحلة' : 'المرحلة القادمة'} · ${cur.status === 'approved' ? 'معتمدة' : 'مسودة'}</span>
      <h2>${esc(cur.title)}</h2>
      <p>${dShort(cur.starts)} ← ${dShort(cur.ends)} · مضى <b class="num">${n1(cur.elapsed)}%</b> من وقتها${cur.months_left > 0 ? ` · بقي <b class="num">${n1(cur.months_left)}</b> شهر` : ''}</p>
      <div class="pl-time"><i style="width:${Math.min(100, cur.elapsed)}%"></i></div>
      <div class="pl-counts">${ST_ORDER.filter(k => cnt[k]).map(k => `<span class="pl-c ${ST[k][1]}"><b class="num">${cnt[k]}</b> ${ST[k][0]}</span>`).join('')}</div>
    </div>
    <div class="pl-hero-ax">${Object.entries(AXES).map(([k, [t, ic, col]]) => {
      const v = cur.axes?.[k];
      return `<div><span>${ic} ${t}</span><div class="pl-axbar"><i style="width:${v == null ? 0 : Math.min(100, v)}%;background:${col}"></i></div><b class="num">${v == null ? '—' : Math.round(v) + '%'}</b></div>`;
    }).join('')}</div>
  </section>` : `<div class="card empty mb">لم تُضع خارطة بعد${d.can_edit ? ' — ابدأ من تبويب «إدارة الخارطة»' : ''}.</div>`}
  <div class="grid g4 mb pl-kpis">
    ${kpi('المصروف للمستفيدين', fmt(C.amount_disbursed, val('amount_disbursed')), `${fmt(C.budget_use_pct, val('budget_use_pct'))} من رصيد ${fmt(C.amount_disbursed, s.budget)}`, true)}
    ${kpi('القروض المنجزة', fmt({ fmt: 'num', unit: 'قرض' }, val('loans_completed')), `من ${num(val('apps_submitted'))} طلباً مقدَّماً · ${num(val('gov_covered'))} محافظة`)}
    ${kpi('القدرة المركّبة', fmt(C.kw_installed, val('kw_installed')), `تولّد ${fmt(C.mwh_year, val('mwh_year'))} سنوياً`)}
    ${kpi('أثر بيئي سنوي', fmt(C.co2_t_year, val('co2_t_year')), `كربون متجنَّب · ${fmt(C.diesel_kl_year, val('diesel_kl_year'))} وقود موفَّر`)}
  </div>`;
}

// ───────── الخارطة: المراحل على خط زمني ─────────
function goalRow(g, d) {
  const c = d.cat[g.metric];
  return `<button type="button" class="pl-goal" data-goal="${g.id}">
    <span class="pl-g-ax" style="background:${AXES[c?.axis]?.[2] || '#999'}" title="${esc(AXES[c?.axis]?.[0] || '')}"></span>
    <span class="pl-g-t"><b>${esc(g.title)}</b><small>${g.scope_gov ? esc(g.scope_gov) + ' · ' : ''}${g.scope_sector ? esc(sectorName(g.scope_sector)) + ' · ' : ''}المستهدف ${fmt(c, g.target)}</small></span>
    <span class="pl-g-v">${g.status === 'lowdata' ? `<small class="muted">تغطية ${n1(g.coverage || 0)}%</small>` : g.status === 'upcoming' ? `<small class="muted">الآن ${fmt(c, g.actual)}</small>` : fmt(c, g.actual)}</span>
    <span class="pl-g-p">${g.status === 'upcoming' ? `<small>تبدأ ${dShort(g._starts)}</small>` : `${progBar(g)}<small>${g.progress == null ? '' : `<span class="num">${n1(Math.min(g.progress, 999))}%</span>`}</small>`}</span>
    <span class="pl-g-s">${stBadge(g.status)}</span>
  </button>`;
}
function mapView(d) {
  if (!d.phases.length) return `<div class="card empty">لا توجد مراحل بعد.</div>`;
  return `<div class="pl-road">${d.phases.map((p, i) => `
    <article class="pl-phase ${p.current ? 'cur' : ''} ${p.elapsed >= 100 ? 'done' : ''}">
      <div class="pl-node"><span class="num">${i + 1}</span></div>
      <div class="card pl-ph">
        <header><div><h3>${esc(p.title)}</h3><p class="small muted">${dShort(p.starts)} ← ${dShort(p.ends)}${p.description ? ' · ' + esc(p.description) : ''}</p></div>
          <span class="sp"></span>${badge(p.status === 'approved' ? ['معتمدة', 'ok'] : ['مسودة', 'muted'])}
          ${p.score != null ? `<span class="pl-score" title="الإنجاز الموزون"><b class="num">${Math.round(p.score)}%</b><small>إنجاز</small></span>` : ''}</header>
        <div class="pl-time light"><i style="width:${Math.min(100, p.elapsed)}%"></i></div>
        <div class="small muted" style="margin:-4px 0 10px">${p.elapsed <= 0 ? 'لم تبدأ بعد' : p.elapsed >= 100 ? 'انتهت المرحلة' : `مضى <span class="num">${n1(p.elapsed)}%</span> من الوقت`}${p.approved_by ? ` · اعتمدها ${esc(p.approved_by)}` : ''}</div>
        <details class="pl-det" ${p.current ? 'open' : ''}><summary>${p.current ? 'الأهداف' : 'عرض الأهداف'} (<span class="num">${(p.goals || []).length}</span>)</summary>
        <div class="pl-goals">${(p.goals || []).map(g => goalRow(g, d)).join('') || '<div class="empty small">لا أهداف في هذه المرحلة.</div>'}</div></details>
      </div>
    </article>`).join('')}</div>
    <p class="small muted mt">الخط العمودي في شريط الإنجاز = ما كان يُفترض إنجازه حسب الوقت المنقضي من المرحلة. اضغط أي هدف لترى طريقة حسابه وتوقعه.</p>`;
}

function wireGoals(body, d) {
  body.querySelectorAll('[data-goal]').forEach(b => b.onclick = () => goalModal(d, b.dataset.goal));
}
function goalModal(d, id) {
  let g, ph;
  d.phases.forEach(p => (p.goals || []).forEach(x => { if (x.id === id) { g = x; ph = p; } }));
  if (!g) return;
  const c = d.cat[g.metric], ax = AXES[c?.axis];
  const flow = c?.kind === 'flow';
  modal(`<h3>${esc(g.title)}</h3>
    <p class="small muted">${ax ? `${ax[1]} ${ax[0]} · ` : ''}${esc(ph.title)}</p>
    <div class="pl-md-st">${stBadge(g.status)}</div>
    <div class="grid g3 mb pl-md">
      <div><small>المنجز</small><b>${fmt(c, g.actual)}</b></div>
      <div><small>المستهدف</small><b>${fmt(c, g.target)}</b></div>
      <div><small>خط الأساس</small><b>${fmt(c, g.base_used)}</b>${g.baseline == null && flow ? '<em>محسوب آلياً</em>' : ''}</div>
    </div>
    ${g.status === 'upcoming' ? `<p class="small">المرحلة تبدأ ${dShort(ph.starts)} — القيمة الحالية للمؤشر ${fmt(c, g.actual)}.</p>` : g.progress != null ? `${progBar(g)}<p class="small">نسبة الإنجاز <b class="num">${n1(g.progress)}%</b>${flow && ['on_track', 'at_risk', 'behind'].includes(g.status) ? ` · المفترض حسب الوقت <b class="num">${n1(g.expected)}%</b>` : ''}</p>` : ''}
    ${g.forecast != null && g.status !== 'achieved' ? `<p class="small">📈 بالوتيرة الحالية يصل إلى <b>${fmt(c, g.forecast)}</b> بنهاية المرحلة (${n1(g.forecast / g.target * 100)}% من المستهدف).</p>` : ''}
    ${g.need_per_month != null ? `<p class="small">🎯 المطلوب للوصول: <b>${fmt(c, g.need_per_month)}</b> كل شهر حتى ${dShort(ph.ends)}.</p>` : ''}
    ${g.coverage != null ? `<p class="small">البيانات متوفرة لـ <b class="num">${n1(g.coverage)}%</b> من المستفيدين. تُستكمل من قراءة البطاقة الوطنية عند التسجيل.</p>` : ''}
    <div class="notice"><div><b>طريقة الحساب:</b> ${esc(HOW[g.metric] || '')}<br>
      ${g.mode === 'phase' ? 'يُحسب خلال فترة المرحلة فقط.' : 'يُحسب تراكمياً منذ بدء المبادرة.'}
      ${g.scope_gov ? ` النطاق: محافظة ${esc(g.scope_gov)}.` : ''}${g.scope_sector ? ` القطاع: ${esc(sectorName(g.scope_sector))}.` : ''} الوزن في الإنجاز الكلي: <span class="num">${n1(g.weight)}</span>.</div></div>
    ${['behind', 'at_risk', 'missed'].includes(g.status) && LEVER[g.metric] ? `<div class="notice warn"><div><b>رافعة مقترحة:</b> ${esc(LEVER[g.metric])}</div></div>` : ''}
    ${g.note ? `<p class="small muted">ملاحظة الوزارة: ${esc(g.note)}</p>` : ''}`, { wide: true });
}

// ───────── مؤشرات الأداء: جدول أهداف المرحلة ─────────
function kpiView(d, F) {
  const ph = d.phases.find(p => p.id === F.phase);
  const goals = (ph?.goals || []).filter(g => !F.axis || d.cat[g.metric]?.axis === F.axis);
  return `<div class="row mb" style="gap:8px">
      <select class="input sm" data-ph aria-label="المرحلة">${d.phases.map(p => `<option value="${p.id}" ${p.id === F.phase ? 'selected' : ''}>${esc(p.title)}</option>`).join('')}</select>
      <select class="input sm" data-ax aria-label="المحور"><option value="">كل المحاور</option>${Object.entries(AXES).map(([k, [t]]) => `<option value="${k}" ${k === F.axis ? 'selected' : ''}>${t}</option>`).join('')}</select>
      <span class="sp"></span><button type="button" class="btn ghost sm" data-x>⬇️ تصدير Excel</button></div>
    <div class="card"><div class="tbl-wrap"><table class="tbl pl-tbl"><thead><tr><th>الهدف</th><th>المحور</th><th>المستهدف</th><th>المنجز</th><th style="min-width:150px">الإنجاز</th><th>الحالة</th><th>المتوقع بنهاية المرحلة</th><th>المطلوب شهرياً</th></tr></thead>
    <tbody>${goals.map(g => { const c = d.cat[g.metric]; return `<tr class="click" data-goal="${g.id}">
      <td><b>${esc(g.title)}</b>${g.scope_gov || g.scope_sector ? `<div class="small muted">${esc([g.scope_gov, g.scope_sector && sectorName(g.scope_sector)].filter(Boolean).join(' · '))}</div>` : ''}</td>
      <td class="small">${AXES[c?.axis]?.[0] || ''}</td><td>${fmt(c, g.target)}</td><td>${g.status === 'lowdata' ? '—' : fmt(c, g.actual)}</td>
      <td>${g.status === 'upcoming' ? '<span class="small muted">لم تبدأ</span>' : `${progBar(g)}<span class="small num">${g.progress == null ? '—' : n1(g.progress) + '%'}</span>`}</td>
      <td>${stBadge(g.status)}</td><td>${g.forecast != null && g.status !== 'achieved' ? fmt(c, g.forecast) : '—'}</td><td>${g.need_per_month != null ? fmt(c, g.need_per_month) : '—'}</td></tr>`; }).join('')
      || '<tr><td colspan="8" class="empty">لا أهداف.</td></tr>'}</tbody></table></div></div>`;
}
function wireKpi(ctx, body, d, F) {
  body.querySelector('[data-ph]').onchange = e => { F.phase = e.target.value; body.innerHTML = kpiView(d, F); wireKpi(ctx, body, d, F); };
  body.querySelector('[data-ax]').onchange = e => { F.axis = e.target.value; body.innerHTML = kpiView(d, F); wireKpi(ctx, body, d, F); };
  body.querySelectorAll('[data-goal]').forEach(b => b.onclick = () => goalModal(d, b.dataset.goal));
  body.querySelector('[data-x]').onclick = () => {
    const ph = d.phases.find(p => p.id === F.phase);
    exportCsv('أهداف-' + (ph?.title || ''), ['الهدف', 'المحور', 'المحافظة', 'القطاع', 'المستهدف', 'المنجز', 'خط الأساس', 'الإنجاز %', 'المفترض حسب الوقت %', 'الحالة', 'المتوقع بنهاية المرحلة', 'المطلوب شهرياً', 'الوزن'],
      (ph?.goals || []).map(g => { const c = d.cat[g.metric]; return [g.title, AXES[c?.axis]?.[0], g.scope_gov, g.scope_sector && sectorName(g.scope_sector), fmt(c, g.target, true), fmt(c, g.actual, true), fmt(c, g.base_used, true), g.progress, g.expected, ST[g.status]?.[0], g.forecast != null ? fmt(c, g.forecast, true) : '', g.need_per_month != null ? fmt(c, g.need_per_month, true) : '', g.weight]; }));
  };
}

// ───────── المحاور الأربعة: الأرقام الوطنية الآن ─────────
function axesView(d, cur) {
  const T = d.totals || {};
  return `<div class="grid g2">${Object.entries(AXES).map(([k, [t, ic, col]]) => {
    const ms = d.catalog.filter(c => c.axis === k);
    const gs = (cur?.goals || []).filter(g => d.cat[g.metric]?.axis === k);
    return `<div class="card pl-axis" style="--ax:${col}"><h3>${ic} ${t}<span class="sp"></span>${cur?.axes?.[k] != null ? `<span class="badge info">إنجاز المرحلة <span class="num">${Math.round(cur.axes[k])}%</span></span>` : ''}</h3>
      <div class="pl-mlist">${ms.map(c => { const v = T[c.key]; return `<div><span>${esc(c.label)}</span><b>${fmt(c, v?.value)}</b>${v?.coverage != null ? `<small>تغطية البيانات <span class="num">${n1(v.coverage)}%</span></small>` : ''}</div>`; }).join('')}</div>
      ${gs.length ? `<div class="pl-goals mt">${gs.map(g => goalRow(g, d)).join('')}</div>` : `<p class="small muted mt">لا أهداف لهذا المحور في المرحلة الحالية.</p>`}</div>`;
  }).join('')}</div><p class="small muted mt">الأرقام تراكمية منذ بدء المبادرة (${dShort(d.settings?.start_date)}). افتراضات الطاقة والوظائف تضبطها الوزارة من إعدادات الخارطة.</p>`;
}

// ───────── التحليل: قراءة آلية للفجوات ─────────
function insights(d, cur) {
  const out = [], C = d.cat;
  if (!cur) return out;
  const gs = cur.goals || [];
  const judged = gs.filter(g => !['nodata', 'lowdata', 'upcoming'].includes(g.status));
  if (cur.score != null && cur.elapsed > 0 && cur.elapsed < 100) {
    const gap = cur.score - cur.elapsed;
    out.push({ lv: gap >= -5 ? 'ok' : gap >= -20 ? 'warn' : 'bad', ic: '🧭', t: `الإنجاز الموزون للمرحلة ${n1(cur.score)}% مقابل ${n1(cur.elapsed)}% من وقتها`,
      d: gap >= -5 ? 'المرحلة تسير بوتيرة تكفي لبلوغ أهدافها في الموعد.' : `الإنجاز متأخر عن الوقت بـ ${n1(-gap)} نقطة. ${judged.filter(g => ['behind', 'at_risk'].includes(g.status)).length} من ${judged.length} أهداف تحتاج تدخلاً.` });
  }
  const rank = { behind: 0, missed: 0, at_risk: 1 };
  gs.filter(g => g.status in rank).sort((a, b) => rank[a.status] - rank[b.status] || a.progress - b.progress).forEach(g => {
    const c = C[g.metric];
    let t = `«${g.title}»: المنجز ${fmt(c, g.actual, true)} من ${fmt(c, g.target, true)}`, dd = '';
    if (c.kind === 'flow') {
      dd = `الإنجاز ${n1(g.progress)}% والمفترض حسب الوقت ${n1(g.expected)}%.`;
      if (g.forecast != null) dd += ` بالوتيرة الحالية يصل إلى ${fmt(c, g.forecast, true)} بنهاية المرحلة (${n1(g.forecast / g.target * 100)}% من المستهدف).`;
      if (g.need_per_month != null) dd += ` للّحاق يلزم ${fmt(c, g.need_per_month, true)} شهرياً.`;
    } else {
      dd = c.dir === 'down' ? `المستهدف ألا يتجاوز ${fmt(c, g.target, true)} والحالي ${fmt(c, g.actual, true)}.` : `الفجوة ${fmt(c, g.target - g.actual, true)} عن المستهدف.`;
    }
    out.push({ lv: g.status === 'at_risk' ? 'warn' : 'bad', ic: g.status === 'at_risk' ? '⚠️' : '⛔', t, d: dd, lever: LEVER[g.metric], goal: g.id });
  });
  gs.filter(g => g.status === 'lowdata').forEach(g => out.push({ lv: 'muted', ic: 'ℹ️', t: `«${g.title}»: لا يمكن الحكم بعد`, d: `البيانات متوفرة لـ ${n1(g.coverage || 0)}% فقط من المستفيدين. تُستكمل تلقائياً من قراءة البطاقة الوطنية للمقترضين الجدد.`, goal: g.id }));
  gs.filter(g => g.status === 'nodata').forEach(g => out.push({ lv: 'muted', ic: 'ℹ️', t: `«${g.title}»: لا توجد بيانات بعد`, d: 'يبدأ القياس عند وجود معاملات تخص هذا المؤشر (مثل استحقاق أول قسط).', goal: g.id }));
  // المحافظات غير المغطاة والتركّز
  const done = new Set((d.by_gov || []).filter(x => x.completed > 0).map(x => x.gov));
  const miss = GOVS.map(x => x[0]).filter(g => !done.has(g) && !(g === 'الديوانية' && done.has('القادسية')));
  if (miss.length) out.push({ lv: 'warn', ic: '🗺️', t: `${miss.length} محافظة دون أي قرض مكتمل`, d: miss.join('، ') + '.', lever: LEVER.gov_covered });
  const tot = (d.by_gov || []).reduce((s, x) => s + Number(x.amount || 0), 0);
  const top = (d.by_gov || [])[0];
  if (top && tot > 0 && top.amount / tot > 0.3) out.push({ lv: 'warn', ic: '📍', t: `تركّز في ${top.gov}: ${n1(top.amount / tot * 100)}% من المبالغ المصروفة`, d: 'نسبة مرتفعة لمحافظة واحدة قد تخلّ بالتوزيع العادل.' });
  // اتجاه آخر شهرين
  const mo = d.monthly || [];
  if (mo.length >= 3) {
    const a = mo[mo.length - 2], b = mo[mo.length - 3];
    if (b.completed > 0) {
      const ch = (a.completed - b.completed) / b.completed * 100;
      out.push({ lv: ch >= 0 ? 'ok' : 'warn', ic: ch >= 0 ? '📈' : '📉', t: `القروض المنجزة في ${monthName(a.m)}: ${a.completed} مقابل ${b.completed} في ${monthName(b.m)}`, d: `تغيّر بنسبة ${ch >= 0 ? '+' : ''}${n1(ch)}% (آخر شهر مكتمل).` });
    }
  }
  gs.filter(g => g.status === 'achieved').forEach(g => out.push({ lv: 'ok', ic: '✅', t: `«${g.title}» متحقق`, d: `المنجز ${fmt(C[g.metric], g.actual, true)} والمستهدف ${fmt(C[g.metric], g.target, true)}.`, goal: g.id }));
  return out;
}
const monthName = m => { const [y, mm] = m.split('-'); return new Date(+y, +mm - 1, 1).toLocaleDateString('ar-IQ-u-nu-latn', { month: 'long', year: 'numeric' }); };
function analysisView(d, cur) {
  const ins = insights(d, cur);
  return `<div class="card"><h3>قراءة النظام لنتائج ${esc(cur?.title || 'الخارطة')}<span class="sp"></span><span class="badge muted">تُحدَّث مع كل معاملة</span></h3>
    <div class="pl-ins">${ins.map(x => `<div class="pl-in ${x.lv}" ${x.goal ? `data-goal="${x.goal}" role="button" tabindex="0"` : ''}>
      <span class="ic">${x.ic}</span><div><b>${esc(x.t)}</b><p>${esc(x.d)}</p>${x.lever ? `<p class="lv">رافعة مقترحة: ${esc(x.lever)}</p>` : ''}</div></div>`).join('') || '<div class="empty">لا توجد ملاحظات.</div>'}</div></div>
    <p class="small muted mt">التحليل آلي ومحسوب من بيانات المعاملات. الروافع المقترحة للاسترشاد، والقرار للوزارة والجهات المختصة.</p>`;
}

// ───────── التوزيع والاتجاه الشهري ─────────
function barsSvg(rows, key, color, fmtV) {
  if (!rows.length) return '<div class="empty small">لا بيانات.</div>';
  const max = Math.max(1, ...rows.map(r => Number(r[key]) || 0)), W = 100 / rows.length;
  return `<div class="pl-cols">${rows.map(r => { const v = Number(r[key]) || 0; return `<div class="pl-col" style="width:${W}%" title="${monthName(r.m)}: ${fmtV(v)}">
    <small class="num">${v ? fmtV(v) : ''}</small><i style="height:${Math.max(v ? 3 : 0, v / max * 100)}%;background:${color}"></i><span>${monthName(r.m).replace(/\s*\d{4}$/, '')}</span></div>`; }).join('')}</div>`;
}
function distView(d) {
  const tot = (d.by_gov || []).reduce((s, x) => s + Number(x.amount || 0), 0);
  const totS = (d.by_sector || []).reduce((s, x) => s + Number(x.amount || 0), 0);
  const govRows = GOVS.map(([g]) => (d.by_gov || []).find(x => x.gov === g || (g === 'الديوانية' && x.gov === 'القادسية')) || { gov: g, apps: 0, completed: 0, amount: 0, kw: 0 })
    .sort((a, b) => (b.amount || 0) - (a.amount || 0) || b.apps - a.apps);
  const mo = d.monthly || [];
  return `<div class="grid g2 mb">
    <div class="card"><h3>القروض المنجزة شهرياً</h3>${barsSvg(mo, 'completed', '#06AFF2', v => num(v))}</div>
    <div class="card"><h3>المبالغ المصروفة شهرياً</h3>${barsSvg(mo, 'amount', '#FFB000', v => n1(v / 1e6) + 'م')}</div></div>
  <div class="grid g2">
    <div class="card"><h3>حسب المحافظة<span class="sp"></span><button type="button" class="btn ghost sm" data-x="gov">⬇️ تصدير Excel</button></h3>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>المحافظة</th><th>الطلبات</th><th>المنجزة</th><th>المصروف</th><th style="min-width:120px">الحصة</th></tr></thead>
      <tbody>${govRows.map(x => `<tr class="${x.completed ? '' : 'flag'}"><td>${esc(x.gov)}</td><td class="num">${num(x.apps)}</td><td class="num">${num(x.completed)}</td><td>${fmt({ fmt: 'iqd' }, x.amount || 0)}</td>
        <td><div class="bar"><i style="width:${tot ? (x.amount || 0) / tot * 100 : 0}%"></i></div><span class="small num">${tot ? n1((x.amount || 0) / tot * 100) : 0}%</span></td></tr>`).join('')}</tbody></table></div>
      <p class="small muted">الصفوف المظللة: محافظات دون قرض مكتمل.</p></div>
    <div class="card"><h3>حسب القطاع</h3>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>القطاع</th><th>الطلبات</th><th>المنجزة</th><th>القدرة</th><th style="min-width:120px">حصة المبالغ</th></tr></thead>
      <tbody>${(d.by_sector || []).map(x => `<tr><td><span class="pl-dot" style="background:${SECTORS[x.key]?.[1] || '#999'}"></span>${esc(sectorName(x.key))}</td><td class="num">${num(x.apps)}</td><td class="num">${num(x.completed)}</td>
        <td>${fmt({ fmt: 'kw' }, x.kw || 0)}</td><td><div class="bar"><i style="width:${totS ? (x.amount || 0) / totS * 100 : 0}%;background:${SECTORS[x.key]?.[1] || ''}"></i></div><span class="small num">${totS ? n1((x.amount || 0) / totS * 100) : 0}%</span></td></tr>`).join('')}</tbody></table></div></div>
  </div>`;
}
function exportGov(d) {
  exportCsv('توزيع-المحافظات', ['المحافظة', 'الطلبات', 'المنجزة', 'المصروف (دينار)', 'القدرة (كيلوواط)'], (d.by_gov || []).map(x => [x.gov, x.apps, x.completed, x.amount || 0, x.kw || 0]));
}

// ───────── إدارة الخارطة (وزارة التخطيط فقط) ─────────
function editView(d) {
  const s = d.settings || {};
  return `<div class="card mb"><h3>إعدادات الخارطة<span class="sp"></span><button type="button" class="btn ghost sm" data-set>تعديل</button></h3>
      <div class="chips"><span>العنوان: <b>${esc(s.title)}</b></span><span>بدء المبادرة: <b>${ymd(s.start_date)}</b></span><span>الرصيد: <b>${fmt({ fmt: 'iqd' }, s.budget, true)}</b></span>
      <span>إنتاج الكيلوواط سنوياً: <b class="num">${n1(s.yield_kwh_per_kw)}</b> ك.و.س</span><span>كربون لكل م.و.س: <b class="num">${n1(s.co2_t_per_mwh)}</b> طن</span>
      <span>وقود لكل ك.و.س: <b class="num">${n1(s.diesel_l_per_kwh)}</b> لتر</span><span>وظائف لكل مشروع إنتاجي: <b class="num">${n1(s.jobs_per_project)}</b></span></div></div>
    <div class="row mb"><h3 style="margin:0">المراحل والأهداف</h3><span class="sp"></span><button type="button" class="btn cyan sm" data-addph>+ مرحلة جديدة</button></div>
    ${d.phases.map(p => `<div class="card mb pl-edph">
      <h3>${esc(p.title)}<span class="sp"></span>${badge(p.status === 'approved' ? ['معتمدة', 'ok'] : ['مسودة', 'muted'])}</h3>
      <p class="small muted">${ymd(p.starts)} ← ${ymd(p.ends)}${p.description ? ' · ' + esc(p.description) : ''}</p>
      <div class="row" style="gap:6px;flex-wrap:wrap">
        <button type="button" class="btn ghost sm" data-edph="${p.id}">تعديل المرحلة</button>
        ${p.status === 'approved' ? `<button type="button" class="btn ghost sm" data-unap="${p.id}">إلغاء الاعتماد</button>` : `<button type="button" class="btn ok sm" data-ap="${p.id}">اعتماد المرحلة</button><button type="button" class="btn ghost sm" data-delph="${p.id}">حذف</button>`}
        <span class="sp"></span><button type="button" class="btn cyan sm" data-addg="${p.id}">+ هدف</button></div>
      <div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الهدف</th><th>المستهدف</th><th>خط الأساس</th><th>النطاق</th><th>الوزن</th><th></th></tr></thead><tbody>
      ${(p.goals || []).map(g => { const c = d.cat[g.metric]; return `<tr><td><b>${esc(g.title)}</b><div class="small muted">${AXES[c?.axis]?.[0] || ''} · ${g.mode === 'phase' ? 'خلال المرحلة' : 'تراكمي'}</div></td>
        <td>${fmt(c, g.target)}</td><td>${g.baseline == null ? '<span class="small muted">آلي</span>' : fmt(c, g.baseline)}</td>
        <td class="small">${esc([g.scope_gov, g.scope_sector && sectorName(g.scope_sector)].filter(Boolean).join(' · ') || 'وطني')}</td><td class="num">${n1(g.weight)}</td>
        <td style="white-space:nowrap"><button type="button" class="btn ghost sm" data-edg="${g.id}">تعديل</button> <button type="button" class="btn ghost sm" data-delg="${g.id}" aria-label="حذف الهدف">🗑</button></td></tr>`; }).join('') || '<tr><td colspan="6" class="empty">لا أهداف — أضف هدفاً.</td></tr>'}
      </tbody></table></div>
      ${p.status === 'approved' ? '<p class="small muted">المرحلة معتمدة: أي تعديل عليها يطلب سبباً مكتوباً ويُسجَّل.</p>' : ''}
    </div>`).join('') || '<div class="card empty">لا مراحل — أضف المرحلة الأولى.</div>'}`;
}

const reasonField = (need, label = 'سبب التعديل') => need ? `<div class="field"><label>${label} <span style="color:var(--bad)">*</span></label><textarea class="input" name="reason" rows="2" required placeholder="يُسجَّل في سجل التعديلات"></textarea></div>` : '';
function formModal(html, onSave) {
  const m = modal(`<form>${html}<div class="err"></div><div class="row mt"><span class="sp"></span><button type="submit" class="btn cyan">حفظ</button></div></form>`, { wide: true });
  const f = m.el.querySelector('form'), err = m.el.querySelector('.err');
  f.onsubmit = async e => {
    e.preventDefault(); err.classList.remove('on');
    const btn = f.querySelector('[type=submit]'); btn.disabled = true;
    try { await onSave(Object.fromEntries(new FormData(f))); m.close(); }
    catch (er) { err.textContent = cleanErr(er); err.classList.add('on'); btn.disabled = false; }
  };
  return m;
}

function wireEdit(ctx, body, d) {
  const sb = ctx.sb, reload = msg => { toast(msg, 'ok'); render(ctx); };
  const phOf = id => d.phases.find(p => p.id === id);
  body.querySelector('[data-set]').onclick = () => {
    const s = d.settings;
    formModal(`<h3>إعدادات الخارطة</h3>
      <div class="field"><label>عنوان الخارطة</label><input class="input" name="title" value="${esc(s.title)}" required></div>
      <div class="field"><label>الرؤية (سطر واحد يظهر أعلى اللوحة)</label><textarea class="input" name="vision" rows="2">${esc(s.vision || '')}</textarea></div>
      <div class="grid g2"><div class="field"><label>تاريخ بدء المبادرة</label><input class="input" type="date" name="start_date" value="${ymd(s.start_date)}" required></div>
      <div class="field"><label>رصيد المبادرة (دينار)</label><input class="input" type="number" name="budget" min="1" step="1" value="${s.budget}" dir="ltr" required></div></div>
      <p class="small muted">افتراضات حساب الأثر — تضعها الوزارة حسب مصادرها الرسمية:</p>
      <div class="grid g2">
        <div class="field"><label>الإنتاج السنوي لكل كيلوواط (كيلوواط ساعة)</label><input class="input" type="number" step="any" min="0.01" name="yield_kwh_per_kw" value="${s.yield_kwh_per_kw}" dir="ltr"></div>
        <div class="field"><label>الكربون المتجنَّب لكل ميغاواط ساعة (طن)</label><input class="input" type="number" step="any" min="0" name="co2_t_per_mwh" value="${s.co2_t_per_mwh}" dir="ltr"></div>
        <div class="field"><label>وقود المولّدات لكل كيلوواط ساعة (لتر)</label><input class="input" type="number" step="any" min="0" name="diesel_l_per_kwh" value="${s.diesel_l_per_kwh}" dir="ltr"></div>
        <div class="field"><label>فرص العمل لكل مشروع إنتاجي</label><input class="input" type="number" step="any" min="0" name="jobs_per_project" value="${s.jobs_per_project}" dir="ltr"></div></div>
      ${reasonField(true, 'سبب التعديل')}`,
      async v => { const { reason, ...p } = v; await rpc(sb, 'planning_save_settings', { p, p_reason: reason }); reload('حُفظت الإعدادات'); });
  };
  const phaseForm = p => {
    const need = p?.status === 'approved';
    formModal(`<h3>${p ? 'تعديل المرحلة' : 'مرحلة جديدة'}</h3>
      <div class="field"><label>اسم المرحلة</label><input class="input" name="title" value="${esc(p?.title || '')}" required placeholder="مثال: المرحلة الرابعة — الاستدامة"></div>
      <div class="field"><label>وصف مختصر</label><textarea class="input" name="description" rows="2">${esc(p?.description || '')}</textarea></div>
      <div class="grid g3"><div class="field"><label>تبدأ</label><input class="input" type="date" name="starts" value="${ymd(p?.starts || '')}" required></div>
      <div class="field"><label>تنتهي</label><input class="input" type="date" name="ends" value="${ymd(p?.ends || '')}" required></div>
      <div class="field"><label>الترتيب</label><input class="input" type="number" name="ord" min="1" value="${p?.ord || d.phases.length + 1}" dir="ltr"></div></div>
      ${reasonField(need)}`,
      async v => { const { reason, ...x } = v; await rpc(sb, 'planning_save_phase', { p: { ...x, id: p?.id || null }, p_reason: reason || null }); reload('حُفظت المرحلة'); });
  };
  const goalForm = (phaseId, g) => {
    const ph = phOf(g?.phase_id || phaseId) || phOf(phaseId);
    const need = ph?.status === 'approved';
    const byAx = Object.entries(AXES).map(([k, [t]]) => `<optgroup label="${t}">${d.catalog.filter(c => c.axis === k).map(c => `<option value="${c.key}" ${c.key === g?.metric ? 'selected' : ''}>${esc(c.label)} (${esc(c.unit)})</option>`).join('')}</optgroup>`).join('');
    const m = formModal(`<h3>${g ? 'تعديل الهدف' : 'هدف جديد'}</h3>
      <div class="field"><label>المرحلة</label><select class="input" name="phase_id">${d.phases.map(p => `<option value="${p.id}" ${p.id === (g ? phaseId : phaseId) ? 'selected' : ''}>${esc(p.title)}</option>`).join('')}</select></div>
      <div class="field"><label>المؤشر</label><select class="input" name="metric" required>${byAx}</select><p class="small muted" data-how></p></div>
      <div class="field"><label>اسم الهدف (اختياري — يُستخدم اسم المؤشر إن تُرك فارغاً)</label><input class="input" name="title" value="${esc(g?.title && g.title !== d.cat[g.metric]?.label ? g.title : '')}"></div>
      <div class="grid g3">
        <div class="field"><label>القيمة المستهدفة <span data-unit class="muted"></span></label><input class="input" type="number" step="any" min="0" name="target" value="${g?.target ?? ''}" required dir="ltr"></div>
        <div class="field"><label>خط الأساس (فارغ = آلي)</label><input class="input" type="number" step="any" min="0" name="baseline" value="${g?.baseline ?? ''}" dir="ltr"></div>
        <div class="field"><label>الوزن (1–5)</label><input class="input" type="number" step="any" min="0.1" max="10" name="weight" value="${g?.weight ?? 1}" dir="ltr"></div></div>
      <div class="grid g3">
        <div class="field"><label>طريقة القياس</label><select class="input" name="mode"><option value="cumulative" ${g?.mode !== 'phase' ? 'selected' : ''}>تراكمي منذ بدء المبادرة</option><option value="phase" ${g?.mode === 'phase' ? 'selected' : ''}>خلال المرحلة فقط</option></select></div>
        <div class="field"><label>المحافظة</label><select class="input" name="scope_gov"><option value="">كل المحافظات</option>${GOVS.map(([x]) => `<option ${x === g?.scope_gov ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
        <div class="field"><label>القطاع</label><select class="input" name="scope_sector"><option value="">كل القطاعات</option>${Object.entries(SECTORS).map(([k, [t]]) => `<option value="${k}" ${k === g?.scope_sector ? 'selected' : ''}>${t}</option>`).join('')}</select></div></div>
      <div class="field"><label>ملاحظة</label><input class="input" name="note" value="${esc(g?.note || '')}"></div>
      <div data-rsn>${reasonField(need)}</div>`,
      async v => { const { reason, ...x } = v; await rpc(sb, 'planning_save_goal', { p: { ...x, id: g?.id || null }, p_reason: reason || null }); reload('حُفظ الهدف'); });
    const sel = m.el.querySelector('[name=metric]'), phSel = m.el.querySelector('[name=phase_id]');
    const upd = () => { const c = d.cat[sel.value]; m.el.querySelector('[data-how]').textContent = HOW[sel.value] || ''; m.el.querySelector('[data-unit]').textContent = c ? `(${c.unit})` : ''; };
    sel.onchange = upd; upd();
    phSel.onchange = () => { const np = phOf(phSel.value); m.el.querySelector('[data-rsn]').innerHTML = reasonField(need || np?.status === 'approved'); };
  };
  const askReason = (title, required, fn) => formModal(`<h3>${title}</h3>${required ? reasonField(true, 'السبب') : '<div class="field"><label>ملاحظة (اختياري)</label><textarea class="input" name="reason" rows="2"></textarea></div>'}`, v => fn(v.reason));

  body.querySelector('[data-addph]').onclick = () => phaseForm(null);
  body.querySelectorAll('[data-edph]').forEach(b => b.onclick = () => phaseForm(phOf(b.dataset.edph)));
  body.querySelectorAll('[data-ap]').forEach(b => b.onclick = () => askReason('اعتماد المرحلة — تصبح أهدافها رسمية وأي تعديل لاحق يطلب سبباً', false,
    async r => { await rpc(sb, 'planning_set_phase_status', { p_id: b.dataset.ap, p_status: 'approved', p_reason: r || null }); reload('اعتُمدت المرحلة'); }));
  body.querySelectorAll('[data-unap]').forEach(b => b.onclick = () => askReason('إلغاء اعتماد المرحلة', true,
    async r => { await rpc(sb, 'planning_set_phase_status', { p_id: b.dataset.unap, p_status: 'draft', p_reason: r }); reload('أُلغي الاعتماد'); }));
  body.querySelectorAll('[data-delph]').forEach(b => b.onclick = () => askReason(`حذف «${esc(phOf(b.dataset.delph)?.title)}» وكل أهدافها`, false,
    async r => { await rpc(sb, 'planning_delete_phase', { p_id: b.dataset.delph, p_reason: r || null }); reload('حُذفت المرحلة'); }));
  body.querySelectorAll('[data-addg]').forEach(b => b.onclick = () => goalForm(b.dataset.addg, null));
  const goalOf = id => { let r; d.phases.forEach(p => (p.goals || []).forEach(g => { if (g.id === id) r = { ...g, phase_id: p.id }; })); return r; };
  body.querySelectorAll('[data-edg]').forEach(b => b.onclick = () => { const g = goalOf(b.dataset.edg); goalForm(g.phase_id, g); });
  body.querySelectorAll('[data-delg]').forEach(b => b.onclick = () => { const g = goalOf(b.dataset.delg);
    askReason(`حذف الهدف «${esc(g.title)}»`, phOf(g.phase_id)?.status === 'approved', async r => { await rpc(sb, 'planning_delete_goal', { p_id: g.id, p_reason: r || null }); reload('حُذف الهدف'); }); });
}

// ───────── سجل التعديلات ─────────
const FIELD = { target: 'المستهدف', baseline: 'خط الأساس', title: 'الاسم', starts: 'البداية', ends: 'النهاية', status: 'الحالة', weight: 'الوزن', metric: 'المؤشر',
  scope_gov: 'المحافظة', scope_sector: 'القطاع', mode: 'طريقة القياس', budget: 'الرصيد', start_date: 'بدء المبادرة', description: 'الوصف', vision: 'الرؤية',
  yield_kwh_per_kw: 'الإنتاج لكل كيلوواط', co2_t_per_mwh: 'معامل الكربون', diesel_l_per_kwh: 'معامل الوقود', jobs_per_project: 'وظائف لكل مشروع', note: 'الملاحظة', phase_id: 'المرحلة', ord: 'الترتيب' };
function diff(b, a) {
  if (!b || !a) return '';
  return Object.keys(FIELD).filter(k => k in a && JSON.stringify(b[k]) !== JSON.stringify(a[k]))
    .map(k => `${FIELD[k]}: ${esc(String(b[k] ?? '—'))} ← ${esc(String(a[k] ?? '—'))}`).join(' · ');
}
function logView(d) {
  return `<div class="card"><h3>سجل تعديلات الخارطة<span class="sp"></span><span class="badge muted">لا يُحذف ولا يُعدَّل</span></h3>
    <div class="tbl-wrap"><table class="tbl"><thead><tr><th>التاريخ</th><th>الإجراء</th><th>على</th><th>التغيير</th><th>السبب</th><th>بواسطة</th></tr></thead>
    <tbody>${(d.log || []).map(l => `<tr><td class="small">${dt(l.at)}</td><td><b>${esc(l.action)}</b></td><td class="small">${esc(l.target || '')}</td>
      <td class="small">${diff(l.before, l.after) || (l.after && !l.before ? 'إضافة' : l.before && !l.after ? 'حذف' : '—')}</td><td class="small">${esc(l.reason || '—')}</td>
      <td class="small">${esc(l.by_name || '')}${l.by_code ? ` <span class="muted num">${esc(l.by_code)}</span>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا تعديلات.</td></tr>'}</tbody></table></div></div>`;
}

// ───────── التقرير للطباعة ─────────
function reportView(d, cur) {
  const ins = insights(d, cur).filter(x => x.lv !== 'ok').slice(0, 10);
  const T = d.totals || {}, C = d.cat;
  return `<div class="row mb no-print"><span class="sp"></span><button type="button" class="btn cyan" data-print>🖨️ طباعة / حفظ PDF</button></div>
  <article class="card fa-report pl-report">
    <header class="pl-rh"><img src="/alwah-logo/alwah-icon-420.webp" alt="" width="54" height="54"><div><small>وزارة التخطيط · تقرير متابعة خارطة الطريق</small><h2>${esc(d.settings?.title || '')}</h2>
      <p class="small muted">أُعدّ آلياً من منصة «ألواح» في ${dt(new Date().toISOString())}</p></div></header>
    <h3>الموقف العام</h3>
    <table class="tbl"><tbody>
      ${['amount_disbursed', 'budget_use_pct', 'loans_completed', 'kw_installed', 'mwh_year', 'co2_t_year', 'gov_covered', 'share_productive_pct', 'avg_days_complete'].map(k => `<tr><td>${esc(C[k]?.label)}</td><td><b>${fmt(C[k], T[k]?.value)}</b></td></tr>`).join('')}
    </tbody></table>
    ${d.phases.map(p => `<h3 class="mt">${esc(p.title)} — ${p.status === 'approved' ? 'معتمدة' : 'مسودة'}</h3>
      <p class="small">${ymd(p.starts)} ← ${ymd(p.ends)} · مضى ${n1(p.elapsed)}% من الوقت${p.score != null ? ` · الإنجاز الموزون ${n1(p.score)}%` : ''}</p>
      <table class="tbl"><thead><tr><th>الهدف</th><th>المستهدف</th><th>المنجز</th><th>الإنجاز</th><th>الحالة</th><th>المتوقع بنهاية المرحلة</th></tr></thead><tbody>
      ${(p.goals || []).map(g => { const c = C[g.metric]; return `<tr><td>${esc(g.title)}${g.scope_gov ? ` (${esc(g.scope_gov)})` : ''}</td><td>${fmt(c, g.target)}</td><td>${fmt(c, g.actual)}</td><td class="num">${g.progress == null ? '—' : n1(g.progress) + '%'}</td><td>${ST[g.status]?.[0] || ''}</td><td>${g.forecast != null && g.status !== 'achieved' ? fmt(c, g.forecast) : '—'}</td></tr>`; }).join('')}
      </tbody></table>`).join('')}
    <h3 class="mt">أبرز الفجوات وما يقترحه التحليل</h3>
    <ol class="pl-rl">${ins.map(x => `<li><b>${esc(x.t)}</b> — ${esc(x.d)}${x.lever ? ` <i>رافعة مقترحة: ${esc(x.lever)}</i>` : ''}</li>`).join('') || '<li>لا فجوات تستدعي التدخل.</li>'}</ol>
    <p class="small muted mt">طريقة الحساب لكل مؤشر موضحة في البوابة. الأرقام مجمّعة ولا تتضمن بيانات شخصية.</p>
  </article>`;
}
