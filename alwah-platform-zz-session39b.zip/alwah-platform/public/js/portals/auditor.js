// الجلسة 37: بوابة شركات التدقيق الهندسي
// مدير الشركة: يستلم أوامر الكشف، يوزّع البنود على مهندسيه حسب التخصص، يعتمد التقرير أو يعيد بنداً، ويحدد تخصصات فريقه.
// المهندس: يرى بنوده، يثبّت زيارته بالـGPS في الموقع، ويحكم على كل بند: مطابق / غير مطابق (سبب + صورة) / أخرى (نوع + ملاحظة).
import { esc, dt, badge, rpc, toast, cleanErr, modal, kpi, mapsLink, fmtM, el, resultScreen, VET_TYPES } from '../core.js';
import { getGps, gpsDialog } from '../geo.js';
import { ENG_RESULT, ITEM_RES, engPhoto } from '../eng-ui.js';

const SPEC_IC = { pv: '☀️', electrical: '⚡', civil: '🏗', medical: '🩺', production: '🏭' };
const OTHER_KINDS = ['مطابق مع ملاحظة', 'تعذّر الفحص', 'يحتاج فحصاً مختبرياً', 'الكمية ناقصة', 'أخرى'];
const ST = { new: 'info', assigned: 'info', in_progress: 'warn', review: 'warn', done: 'ok', cancelled: 'muted' };

let D;   // بيانات الصندوق

export const shouldRefresh = () => !document.querySelector('.mdl-bg,.cam,.rs-bg,.eng-sheet');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'eng_inbox');
  if (ctx.engOpen) {
    if (D.orders.some(o => o.id === ctx.engOpen) || D.me.manager) return detail(ctx, ctx.engOpen);
    ctx.engOpen = null;
  }
  const mgr = D.me.manager;
  const open = D.orders.filter(o => o.status !== 'done');
  const done = D.orders.filter(o => o.status === 'done');
  const late = open.filter(o => o.late).length;
  const myLeft = D.orders.reduce((s, o) => s + (o.mine_left || 0), 0);
  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(D.org?.name || 'شركة التدقيق الهندسي')}</h1>
      <p>${mgr ? 'مدير الشركة — وزّع البنود على مهندسيك حسب التخصص واعتمد التقارير' : `${esc(D.me.name)} — ${(D.me.specialties || []).map(s => `${SPEC_IC[s] || ''} ${esc(spec(s))}`).join(' · ') || 'لم يحدد المدير تخصصك بعد'}`}</p></div></div>
    <div class="grid g4 mb">
      ${mgr ? kpi('أوامر جديدة', `<span class="num">${open.filter(o => o.status === 'new').length}</span>`, 'بانتظار التوزيع', true) : kpi('بنودي المتبقية', `<span class="num">${myLeft}</span>`, 'احكم عليها في الموقع', true)}
      ${kpi('قيد الفحص', `<span class="num">${open.filter(o => ['assigned', 'in_progress'].includes(o.status)).length}</span>`, late ? `<span style="color:var(--bad)">${late} متأخر عن المهلة</span>` : 'ضمن المهلة')}
      ${kpi('بانتظار الاعتماد', `<span class="num">${open.filter(o => o.status === 'review').length}</span>`, mgr ? 'اكتمل فحصها' : 'لدى المدير')}
      ${kpi('منجزة (60 يوماً)', `<span class="num">${done.length}</span>`, `${done.filter(o => o.result === 'non_conforming').length} غير مطابق`)}
    </div>
    <div class="eng-tabs seg" role="tablist">${[['open', mgr ? `أوامر الكشف (${open.length})` : `مهامي (${open.length})`], ['done', `المنجزة (${done.length})`], ...(mgr ? [['team', 'الفريق والتخصصات']] : [])]
      .map(([k, t]) => `<label class="${(ctx.engTab || 'open') === k ? 'on' : ''}"><input type="radio" name="et" value="${k}" ${(ctx.engTab || 'open') === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
    <div data-body></div>`;
  root.querySelectorAll('input[name=et]').forEach(r => r.onchange = () => { ctx.engTab = r.value; render(ctx); });
  const body = root.querySelector('[data-body]');
  const tab = ctx.engTab || 'open';
  if (tab === 'team' && mgr) return teamView(ctx, body);
  const list = tab === 'done' ? done : open;
  body.innerHTML = list.length ? `<div class="eng-cards">${list.map(o => card(o, mgr)).join('')}</div>`
    : `<div class="card empty">${tab === 'done' ? 'لا تقارير منجزة بعد' : mgr ? 'لا أوامر كشف مفتوحة — تصل آلياً عند وصول أي طلب إلى مرحلة الكشف، أو بطلب من البنك المركزي' : 'لا بنود مسندة إليك الآن'}</div>`;
  body.querySelectorAll('[data-open]').forEach(b => b.onclick = () => { ctx.engOpen = b.dataset.open; window.scrollTo(0, 0); render(ctx); });
}

const spec = k => (D?.specs || []).find(s => s.k === k)?.label || k;
const proj = a => a.vet_type ? `🩺 ${esc(VET_TYPES[a.vet_type] || 'مشروع بيطري')}${a.vet_title ? ` — ${esc(a.vet_title)}` : ''}` : `☀️ منظومة شمسية <span class="num">${a.kw ?? '—'}</span> kW`;

function card(o, mgr) {
  const p = o.total ? Math.round(o.checked / o.total * 100) : 0;
  return `<button type="button" class="eng-card ${o.late ? 'late' : ''} ${o.status}" data-open="${o.id}">
    <div class="row"><b class="num">${esc(o.code)}</b>${o.purpose === 'sample' ? '<span class="tag">رقابي</span>' : '<span class="tag acc">استلام</span>'}${o.round > 1 ? `<span class="tag">جولة ${o.round}</span>` : ''}<span class="sp"></span>
      ${o.status === 'done' ? badge(ENG_RESULT[o.result]) : badge([o.status_label, ST[o.status]])}</div>
    <div class="eng-proj">${proj(o.app)}</div>
    <div class="small muted">📍 ${esc(o.app.governorate || '')}${o.app.city && o.app.city !== o.app.governorate ? ` · ${esc(o.app.city)}` : ''} · الطلب <span class="num">${esc(o.app.code)}</span> · ${esc(o.app.supplier || '')}</div>
    <div class="eng-prog"><i style="width:${p}%"></i></div>
    <div class="row small"><span><span class="num">${o.checked}/${o.total}</span> بند مفحوص${o.fail ? ` · <b style="color:var(--bad)">${o.fail} غير مطابق</b>` : ''}</span><span class="sp"></span>
      ${mgr ? (o.status === 'new' ? `<b style="color:var(--info)">${o.total - o.assigned} بند بلا مهندس</b>` : '') : (o.mine_left ? `<b style="color:var(--warn)">${o.mine_left} من بنودك متبقية</b>` : o.mine ? '<span style="color:var(--ok)">✓ أنهيت بنودك</span>' : '')}
      ${o.status !== 'done' ? `<span class="${o.late ? 'bad-t' : 'muted'}">${o.late ? '⚠ تجاوز المهلة' : `المهلة ${dt(o.due_at)}`}</span>` : `<span class="muted">${dt(o.decided_at)}</span>`}</div>
  </button>`;
}

// ───────── ملف الأمر ─────────
async function detail(ctx, id) {
  const { sb, root } = ctx;
  let I;
  try { I = await rpc(sb, 'eng_inspection', { p_id: id }); }
  catch (e) { ctx.engOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const mgr = D.me.manager, s = I.site || {};
  const ref = I.ref_geo || s.install_geo || s.site_geo || s.approx;
  const myVisit = (I.visit_list || []).filter(v => v.mine).slice(-1)[0];
  const mine = I.items.filter(x => x.mine);
  const p = I.total ? Math.round(I.checked / I.total * 100) : 0;
  const groups = {};
  I.items.forEach(x => (groups[x.spec] ||= []).push(x));

  root.innerHTML = `
    <button type="button" class="linkbtn eng-back" data-back>→ كل الأوامر</button>
    <div class="card mb eng-head">
      <div class="row"><h2 class="num" style="margin:0">${esc(I.code)}</h2>${I.purpose === 'sample' ? '<span class="tag">كشف رقابي بالعيّنة</span>' : `<span class="tag acc">كشف الاستلام${I.round > 1 ? ` — الجولة ${I.round}` : ''}</span>`}<span class="sp"></span>
        ${I.status === 'done' ? badge(ENG_RESULT[I.result]) : badge([I.status_label, ST[I.status]])}</div>
      <div class="eng-proj big">${proj(I.app)}</div>
      <dl class="kv sm">
        <dt>الطلب</dt><dd><span class="num">${esc(I.app.code)}</span> · ${esc(s.bank || '')}</dd>
        <dt>المورد</dt><dd>${esc(s.supplier || '—')}</dd>
        <dt>صاحب المشروع</dt><dd>${esc(s.borrower || '—')}${s.phone ? ` · <a href="tel:${esc(s.phone)}" class="num">📞 ${esc(s.phone)}</a>` : ''}</dd>
        <dt>العنوان</dt><dd>${esc(s.governorate || '')}${s.address ? ` — ${esc(s.address)}` : ''}${ref ? `<div>📍 <a href="${mapsLink(ref)}" target="_blank" rel="noopener">${I.ref_geo?.src === 'install' || (!I.ref_geo && s.install_geo) ? 'موقع التركيب (فني المورد)' : I.ref_geo?.src === 'site' || (!I.ref_geo && s.site_geo) ? 'عنوان المقترض بالـGPS' : I.ref_geo?.src === 'first_visit' ? 'نقطة أول زيارة' : 'موقع تقريبي'} — افتح الخريطة للوصول</a></div>` : ''}</dd>
        ${I.order_note ? `<dt>سبب الأمر</dt><dd>${esc(I.order_note)}<div class="small muted">${esc(I.ordered_by || '')}</div></dd>` : ''}
        ${s.quote_no ? `<dt>عرض السعر</dt><dd class="num">${esc(s.quote_no)}</dd>` : ''}
        <dt>المهلة</dt><dd class="${I.late ? 'bad-t' : ''}">${dt(I.due_at)}${I.late ? ' — متأخر' : ''}</dd>
      </dl>
      <div class="eng-prog big"><i style="width:${p}%"></i></div>
      <div class="row small"><span><span class="num">${I.checked}/${I.total}</span> بند مفحوص</span><span class="sp"></span>
        <span class="ok-t">✓ ${I.items.filter(x => x.result === 'pass').length}</span><span class="bad-t">✗ ${I.fail}</span><span class="warn-t">… ${I.other}</span></div>
    </div>

    ${I.can.visit ? `<div class="card mb eng-visit ${myVisit ? 'ok' : ''}">${myVisit
      ? `<div class="row"><span class="eng-pin">📍</span><div><b>زيارتك مثبّتة</b><div class="small muted">${dt(myVisit.at)} · دقة ±<span class="num">${Math.round(myVisit.acc)}</span> م${myVisit.dist_m != null ? ` · ${fmtM(myVisit.dist_m)} عن الموقع` : ' · صارت الموقع المرجعي'}</div></div><span class="sp"></span><button class="btn ghost sm" data-visit>إعادة التثبيت</button></div>`
      : `<b>١. ثبّت زيارتك وأنت في الموقع</b><p class="small muted" style="margin:4px 0 10px">لا تُقبل أحكامك على البنود قبل تثبيت الزيارة. الدقة المطلوبة ±${D.settings.acc} م، وعلى بعد ${D.settings.dist} م أو أقل من موقع المشروع.</p><button class="btn cyan big-btn" data-visit>📍 ثبّت زيارتي الآن</button>`}</div>` : ''}

    ${I.can.assign ? assignPanel(I) : ''}
    ${I.can.finalize ? finalPanel(I) : ''}
    ${I.status === 'done' ? donePanel(I) : ''}

    <h3 class="eng-sec">${I.can.visit ? (myVisit ? '٢. احكم على بنودك' : 'البنود') : 'البنود'} <span class="small muted">${mine.length && !mgr ? `· بنودك ${mine.length}` : ''}</span></h3>
    ${Object.entries(groups).map(([k, xs]) => `<div class="eng-grp"><div class="eng-gh">${SPEC_IC[k] || ''} ${esc(spec(k))}</div>${xs.map(x => itemCard(I, x, !!myVisit)).join('')}</div>`).join('')}

    ${(I.visit_list || []).length ? `<div class="card mb"><h3>الزيارات</h3>${I.visit_list.map(v => `<div class="row small eng-vrow"><span>📍 <a href="${mapsLink(v)}" target="_blank" rel="noopener">${esc(v.name)}</a> <span class="num muted">${esc(v.code || '')}</span></span><span class="sp"></span><span class="muted">${dt(v.at)} · ±<span class="num">${Math.round(v.acc)}</span> م</span></div>`).join('')}</div>` : ''}
    ${mgr && (I.log || []).length ? `<details class="card mb"><summary><b>سجل الأمر</b> <span class="small muted">(${I.log.length})</span></summary>${I.log.map(l => `<div class="eng-log"><b>${esc(l.action)}</b>${l.note ? ` — ${esc(l.note)}` : ''}<div class="small muted">${esc(l.by || '')} <span class="num">${esc(l.code || '')}</span> · ${dt(l.at)}</div></div>`).join('')}</details>` : ''}`;

  root.querySelector('[data-back]').onclick = () => { ctx.engOpen = null; render(ctx); };
  root.querySelectorAll('[data-ph]').forEach(b => b.onclick = () => engPhoto(sb, b.dataset.ph));
  const vb = root.querySelector('[data-visit]');
  if (vb) vb.onclick = () => doVisit(ctx, I);
  root.querySelectorAll('[data-judge]').forEach(b => b.onclick = () => judge(ctx, I, I.items.find(x => x.id === b.dataset.item), b.dataset.judge));
  if (I.can.assign) wireAssign(ctx, I);
  if (I.can.finalize) wireFinal(ctx, I);
}

function itemCard(I, x, visited) {
  const r = ITEM_RES[x.result];
  const act = x.mine && ['assigned', 'in_progress'].includes(I.status);
  return `<div class="eng-item ${x.result || ''} ${x.mine ? 'mine' : ''}" id="it-${x.id}">
    <div class="eng-item-h"><span class="eng-n num">${x.n}</span><div style="flex:1"><b>${esc(x.label)}</b><div class="small muted">${esc(x.detail || '')}</div></div>${r ? `<span class="eng-res ${x.result}">${r[2]} ${r[0]}</span>` : ''}</div>
    ${x.returned_note ? `<div class="notice warn small" style="margin:8px 0 0">أعاده المدير: ${esc(x.returned_note)}</div>` : ''}
    ${x.result ? `<div class="small eng-why">${x.other_kind ? `<b>${esc(x.other_kind)}</b> — ` : ''}${x.reason ? `<span class="bad-t">${esc(x.reason)}</span>` : ''}${x.note ? ` ${esc(x.note)}` : ''}
      <div class="muted">${esc(x.checked_by || '')} <span class="num">${esc(x.checked_code || '')}</span> · ${dt(x.checked_at)}${x.dist_m != null ? ` · ${fmtM(x.dist_m)} من نقطة الزيارة` : ''}${x.photo_id ? ` · <button type="button" class="linkbtn" data-ph="${x.photo_id}">📷 الصورة</button>` : ''}</div></div>`
      : `<div class="small muted">${x.assignee_name ? `👷 ${esc(x.assignee_name)}` : '<span class="warn-t">بلا مهندس بعد</span>'}</div>`}
    ${act ? `<div class="eng-judge ${visited ? '' : 'locked'}">
      <button type="button" class="j pass ${x.result === 'pass' ? 'on' : ''}" data-judge="pass" data-item="${x.id}" ${visited ? '' : 'disabled'}><i>✓</i>مطابق</button>
      <button type="button" class="j fail ${x.result === 'fail' ? 'on' : ''}" data-judge="fail" data-item="${x.id}" ${visited ? '' : 'disabled'}><i>✗</i>غير مطابق</button>
      <button type="button" class="j other ${x.result === 'other' ? 'on' : ''}" data-judge="other" data-item="${x.id}" ${visited ? '' : 'disabled'}><i>…</i>أخرى</button>
    </div>${visited ? '' : '<div class="small muted" style="margin-top:6px">ثبّت زيارتك أولاً</div>'}` : ''}
  </div>`;
}

async function doVisit(ctx, I) {
  const g = await gpsDialog({ title: 'تثبيت زيارة الموقع', hint: `قف داخل موقع المشروع أو بجانب المنظومة. الدقة المطلوبة ±${D.settings.acc} م.`, want: 25, accMax: D.settings.acc });
  if (!g) return;
  try {
    const r = await rpc(ctx.sb, 'eng_checkin', { p_id: I.id, p_gps: g });
    await resultScreen({ ok: true, title: 'ثُبّتت زيارتك للموقع', ref: I.code,
      msg: r.ref === 'first_visit' ? 'لا يوجد موقع سابق للمشروع، فصارت زيارتك هي الموقع المرجعي في التقرير.' : 'الآن احكم على بنودك وأنت في الموقع.',
      rows: [['الدقة', `±<span class="num">${Math.round(r.acc)}</span> م`], ...(r.dist_m != null ? [['البعد عن الموقع', fmtM(r.dist_m)]] : [])], btn: 'ابدأ الفحص' });
  } catch (e) { await resultScreen({ ok: false, title: 'لم تُثبَّت الزيارة', msg: cleanErr(e), ref: I.code, onRetry: () => doVisit(ctx, I) }); }
  render(ctx);
}

// ───────── الحكم على بند: ورقة سفلية ─────────
function judge(ctx, I, x, res) {
  const lbl = { pass: '✓ مطابق', fail: '✗ غير مطابق', other: '… أخرى' }[res];
  let photo = null;
  const m = modal(`<div class="eng-sheet ${res}">
    <div class="small muted">البند <span class="num">${x.n}</span> · ${esc(x.spec_label)}</div>
    <h3 style="margin:2px 0 4px">${esc(x.label)}</h3><div class="small muted">${esc(x.detail || '')}</div>
    <div class="eng-verdict ${res}">${lbl}</div>
    ${res === 'other' ? `<label class="lbl">نوع الحالة</label><div class="chips" data-kinds>${OTHER_KINDS.map(k => `<label class="chip"><input type="radio" name="ok" value="${esc(k)}">${esc(k)}</label>`).join('')}</div>` : ''}
    ${res === 'fail' ? '<div class="field"><label>سبب عدم المطابقة <b class="bad-t">*</b></label><textarea class="input" rows="2" data-reason placeholder="مثال: الألواح من ماركة غير المذكورة في العرض"></textarea></div>' : ''}
    <div class="field"><label>${res === 'other' ? 'الملاحظة *' : 'ملاحظة (اختيارية)'}</label><textarea class="input" rows="2" data-note></textarea></div>
    <div class="eng-photo" data-phbox><button type="button" class="btn ${res === 'fail' ? 'cyan' : 'ghost'} block" data-cam>📷 ${res === 'fail' ? 'صوّر البند (إلزامي)' : 'أضف صورة (اختياري)'}</button></div>
    <button class="btn ${res === 'fail' ? 'bad' : res === 'other' ? 'warn' : 'ok'} block big-btn" data-save>حفظ: ${lbl}</button>
    <p class="small muted" style="text-align:center;margin:8px 0 0">يُحفظ الحكم بموقعك الآن واسمك ورمزك الوظيفي</p>
  </div>`);
  m.el.querySelectorAll('[data-kinds] input').forEach(r => r.onchange = () => m.el.querySelectorAll('[data-kinds] .chip').forEach(c => c.classList.toggle('on', c.querySelector('input').checked)));
  m.el.querySelector('[data-cam]').onclick = async () => {
    const { cameraCapture } = await import('../capture.js');
    const c = await cameraCapture({ title: `صورة البند ${x.n}`, hint: x.label, ratio: 0.75 });
    if (!c) return;
    if (!c.meta?.live) return toast('تُلتقط الصورة بالكاميرا مباشرة', 'bad');
    photo = c;
    m.el.querySelector('[data-phbox]').innerHTML = `<div class="eng-thumb"><img src="${c.data}" alt=""><span>✓ الصورة جاهزة</span><button type="button" class="linkbtn" data-recam>إعادة</button></div>`;
    m.el.querySelector('[data-recam]').onclick = () => { photo = null; m.close(); judge(ctx, I, x, res); };
  };
  m.el.querySelector('[data-save]').onclick = async e => {
    const reason = m.el.querySelector('[data-reason]')?.value.trim() || '';
    const note = m.el.querySelector('[data-note]').value.trim();
    const kind = m.el.querySelector('[data-kinds] input:checked')?.value || '';
    if (res === 'fail' && reason.length < 3) return toast('اكتب سبب عدم المطابقة', 'bad');
    if (res === 'fail' && !photo && !x.photo_id) return toast('صوّر البند — الصورة دليل إلزامي', 'bad');
    if (res === 'other' && (!kind || note.length < 3)) return toast('اختر نوع الحالة واكتب ملاحظة', 'bad');
    const b = e.target; b.disabled = true; b.textContent = '📍 جارِ قراءة موقعك…';
    let g;
    try { g = await getGps({ want: 30, maxMs: 12000 }); }
    catch (er) { b.disabled = false; b.textContent = `حفظ: ${lbl}`; return toast(er.message || 'تعذّر قراءة الموقع', 'bad'); }
    b.textContent = 'جارِ الحفظ…';
    try {
      const r = await rpc(ctx.sb, 'eng_item_set', { p_item: x.id, p: { result: res, reason, note, other_kind: kind, gps: g, ...(photo ? { photo: photo.data, photo_live: true } : {}) } });
      m.close();
      if (r.left === 0) {
        await resultScreen({ ok: true, title: 'اكتمل فحص كل البنود', ref: I.code, msg: D.me.manager ? 'التقرير جاهز لاعتمادك.' : 'وصل التقرير لمدير الشركة للاعتماد — شكراً لك.' });
      } else if (r.mine_left === 0) {
        await resultScreen({ ok: true, title: 'أنهيت كل بنودك في هذا الأمر', ref: I.code, msg: `بقي ${r.left} بند لدى زملائك. يصل التقرير للمدير حين يكتمل.` });
      } else toast(`حُفظ البند ${x.n}: ${lbl} — بقي لك ${r.mine_left}`, 'ok');
      await render(ctx);
      const n = document.getElementById(`it-${x.id}`); if (n) { n.classList.add('flash'); n.nextElementSibling?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    } catch (er) { b.disabled = false; b.textContent = `حفظ: ${lbl}`; resultScreen({ ok: false, title: 'لم يُحفظ الحكم', msg: cleanErr(er), ref: `${I.code} · البند ${x.n}` }); }
  };
}

// ───────── المدير: التوزيع ─────────
function assignPanel(I) {
  const free = I.items.filter(x => !x.assignee).length;
  return `<div class="card mb eng-assign"><h3>توزيع البنود على المهندسين <span class="sp"></span>${free ? badge([`${free} بلا مهندس`, 'warn']) : badge(['موزّعة كلها', 'ok'])}</h3>
    <p class="small muted" style="margin-top:0">لكل بند تخصص، ولا يُسند إلا لمهندس يحمله. التوزيع الآلي يختار صاحب التخصص الأساسي الأقل انشغالاً، ويجمع بنود الأمر عند أقل عدد من المهندسين.</p>
    <button class="btn cyan" data-auto>⚡ توزيع آلي حسب التخصص</button>
    <details class="mt" ${free && free < I.items.length ? 'open' : ''}><summary class="small"><b>أو وزّع يدوياً</b></summary>
      ${I.items.map(x => { const ok = (I.engineers || []).filter(e => (e.specialties || []).includes(x.spec));
        return `<div class="eng-arow"><span class="num">${x.n}</span><span class="eng-al">${esc(x.label)}<small>${SPEC_IC[x.spec] || ''} ${esc(x.spec_label)}</small></span>
          ${x.result ? `<span class="small muted">${esc(x.assignee_name || '')} ✓</span>` : `<select class="input sm" data-asg="${x.id}"><option value="">—</option>${ok.map(e => `<option value="${e.id}" ${e.id === x.assignee ? 'selected' : ''}>${esc(e.name)} (${e.open})</option>`).join('')}</select>`}
          ${!x.result && !ok.length ? '<span class="small bad-t">لا مهندس بهذا التخصص</span>' : ''}</div>`; }).join('')}
      <button class="btn ghost mt" data-save-asg>حفظ التوزيع</button></details></div>`;
}
function wireAssign(ctx, I) {
  const { root, sb } = ctx;
  const after = async (r, title) => {
    const who = [...new Set(I.items.map(x => x.assignee).filter(Boolean))];
    await resultScreen({ ok: true, title, ref: I.code, msg: r.left ? `بقي ${r.left} بند بلا مهندس${r.missing?.length ? ` — لا يوجد في فريقك تخصص: ${r.missing.join('، ')}. أضفه من «الفريق والتخصصات».` : '.'}` : 'وصل كل مهندس إشعار ببنوده. يثبّت زيارته في الموقع ثم يحكم عليها.',
      rows: [['البنود الموزّعة', `<span class="num">${r.assigned}</span>`]] });
    render(ctx); return who;
  };
  root.querySelector('[data-auto]').onclick = async e => {
    e.target.disabled = true;
    try { await after(await rpc(sb, 'eng_assign', { p_id: I.id, p: { auto: true } }), 'وُزّعت البنود حسب التخصص'); }
    catch (er) { resultScreen({ ok: false, title: 'لم يُوزَّع', msg: cleanErr(er) }); e.target.disabled = false; }
  };
  const sv = root.querySelector('[data-save-asg]');
  if (sv) sv.onclick = async e => {
    const items = {}; root.querySelectorAll('[data-asg]').forEach(s => { items[s.dataset.asg] = s.value; });
    e.target.disabled = true;
    try { await after(await rpc(sb, 'eng_assign', { p_id: I.id, p: { items } }), 'حُفظ التوزيع'); }
    catch (er) { resultScreen({ ok: false, title: 'لم يُحفظ التوزيع', msg: cleanErr(er) }); e.target.disabled = false; }
  };
}

// ───────── المدير: الاعتماد ─────────
const calcResult = I => I.items.some(x => x.result === 'fail') ? 'non_conforming' : I.items.some(x => x.result === 'other') ? 'conditional' : 'conforming';
function finalPanel(I) {
  const r = calcResult(I);
  return `<div class="card mb eng-final ${r}"><h3>اعتماد التقرير</h3>
    <div class="eng-big ${r}"><span>${{ conforming: '✓', conditional: '!', non_conforming: '✗' }[r]}</span><div><small>النتيجة المحتسبة آلياً</small><b>${ENG_RESULT[r][0]}</b></div></div>
    <p class="small muted">${r === 'non_conforming' ? 'بند واحد غير مطابق يجعل التقرير «غير مطابق».' : r === 'conditional' ? 'لا بنود غير مطابقة، وفيه بنود «أخرى» — يصدر «مطابق بملاحظات».' : 'كل البنود مطابقة.'} لا تغيّر الحكم بنفسك — أعد البند لمهندسه إن رأيت خطأً.</p>
    ${I.items.filter(x => x.result !== 'pass').map(x => `<div class="eng-arow"><span class="num">${x.n}</span><span class="eng-al">${esc(x.label)}<small>${ITEM_RES[x.result][2]} ${ITEM_RES[x.result][0]}${x.reason ? ` — ${esc(x.reason)}` : x.note ? ` — ${esc(x.note)}` : ''}</small></span><button class="btn ghost sm" data-ret="${x.id}">إعادة للمهندس</button></div>`).join('')}
    <div class="field mt"><label>ملاحظة المدير (تظهر في التقرير)</label><textarea class="input" rows="2" data-fnote></textarea></div>
    <div class="field"><label>للتأكيد اكتب: <b>أعتمد التقرير</b></label><input class="input" data-fconf><button type="button" class="btn ghost sm" style="margin-top:6px" data-fill>✍ أعتمد التقرير</button></div>
    <button class="btn cyan block big-btn" data-approve>اعتماد التقرير وإرساله للجهات</button></div>`;
}
function wireFinal(ctx, I) {
  const { root, sb } = ctx;
  root.querySelector('[data-fill]').onclick = () => { root.querySelector('[data-fconf]').value = 'أعتمد التقرير'; };
  root.querySelector('[data-approve]').onclick = async e => {
    e.target.disabled = true;
    try {
      const r = await rpc(sb, 'eng_finalize', { p_id: I.id, p: { action: 'approve', confirm: root.querySelector('[data-fconf]').value.trim(), note: root.querySelector('[data-fnote]').value.trim() } });
      await resultScreen({ ok: r.result !== 'non_conforming', title: `اعتُمد التقرير: ${r.label}`, ref: `${r.code} · ${r.app}`,
        msg: r.result === 'non_conforming' ? (I.purpose === 'acceptance' ? 'التقرير «غير مطابق»: لا يُستلم المشروع حتى يصلح المورد البنود ويُعاد الكشف. أُبلغت هيئة النزاهة آلياً.' : 'وصلت البنود غير المطابقة إلى المصرف والمورد والبنك المركزي، وأُبلغت هيئة النزاهة آلياً.') : 'خُتم التقرير بالبصمة وظهرت النتيجة على خريطة البنك المركزي.',
        rows: [['مطابق', `<span class="num">${r.summary.pass}</span>`], ['غير مطابق', `<span class="num">${r.summary.fail}</span>`], ['أخرى', `<span class="num">${r.summary.other}</span>`]],
        chips: r.sent, seal: r.seal, btn: 'تم' });
      ctx.engOpen = null; render(ctx);
    } catch (er) { resultScreen({ ok: false, title: 'لم يُعتمد التقرير', msg: cleanErr(er), ref: I.code }); e.target.disabled = false; }
  };
  root.querySelectorAll('[data-ret]').forEach(b => b.onclick = () => {
    const x = I.items.find(i => i.id === b.dataset.ret);
    const m = modal(`<h3>إعادة البند ${x.n} للمهندس</h3><p class="small muted">${esc(x.label)} — ${esc(x.checked_by || '')}</p><div class="field"><label>السبب</label><textarea class="input" rows="2" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>تراجع</button><button class="btn warn" data-y>إعادة</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-y]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'eng_finalize', { p_id: I.id, p: { action: 'return', item: x.id, note: m.el.querySelector('[data-n]').value.trim() } }); m.close(); toast(`أُعيد البند ${x.n} إلى ${x.checked_by || 'المهندس'}`, 'ok'); render(ctx); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  });
}
function donePanel(I) {
  return `<div class="card mb eng-final ${I.result}"><div class="eng-big ${I.result}"><span>${{ conforming: '✓', conditional: '!', non_conforming: '✗' }[I.result]}</span><div><small>نتيجة التقرير المعتمد</small><b>${ENG_RESULT[I.result][0]}</b></div></div>
    <dl class="kv sm"><dt>اعتمده</dt><dd>${esc(I.decided_by || '')} <span class="num">${esc(I.decided_code || '')}</span> · ${dt(I.decided_at)}</dd>
    ${I.decision_note ? `<dt>ملاحظة</dt><dd>${esc(I.decision_note)}</dd>` : ''}
    ${I.seal ? `<dt>البصمة</dt><dd class="num small" dir="ltr" style="word-break:break-all">${esc(I.seal)}</dd>` : ''}</dl></div>`;
}

// ───────── المدير: الفريق والتخصصات ─────────
function teamView(ctx, body) {
  const { sb } = ctx;
  body.innerHTML = `<div class="card mb"><p class="small muted" style="margin:0">أضف حسابات مهندسيك من <a href="#team">«فريقي»</a> (الدور: مهندس فاحص)، ثم حدد هنا تخصص كل منهم ورقم هويته النقابية. لا يُسند بند لمهندس خارج تخصصه.</p></div>
    <div class="eng-team">${(D.team || []).map(u => `<div class="card eng-mem ${u.disabled ? 'off' : ''}" data-u="${u.id}">
      <div class="row"><div class="av">${esc(u.name.trim()[0])}</div><div><b>${esc(u.name)}</b><div class="small muted">${u.role === 'auditor_admin' ? 'مدير الشركة' : 'مهندس فاحص'} · <span class="num" dir="ltr">${esc(u.username)}</span> · <span class="num">${esc(u.code || '')}</span></div></div><span class="sp"></span>
        <span class="small muted">مفتوح <b class="num">${u.open}</b> · أنجز <b class="num">${u.done}</b></span></div>
      <div class="chips mt">${D.specs.map(s => `<label class="chip ${(u.specialties || []).includes(s.k) ? 'on' : ''}"><input type="checkbox" value="${s.k}" ${(u.specialties || []).includes(s.k) ? 'checked' : ''}>${SPEC_IC[s.k] || ''} ${esc(s.label)}</label>`).join('')}</div>
      <div class="row mt" style="gap:8px"><input class="input sm" data-lic placeholder="رقم الهوية النقابية" value="${esc(u.license_no || '')}" style="max-width:220px" dir="ltr"><span class="sp"></span><button class="btn ghost sm" data-save>حفظ</button></div>
      <p class="small muted" style="margin:6px 0 0">التخصص الأول المختار هو التخصص الأساسي في التوزيع الآلي.</p>
    </div>`).join('')}</div>`;
  body.querySelectorAll('.eng-mem').forEach(c => {
    const order = [...(D.team.find(u => u.id === c.dataset.u)?.specialties || [])];
    c.querySelectorAll('.chip input').forEach(i => i.onchange = () => {
      i.closest('.chip').classList.toggle('on', i.checked);
      if (i.checked) order.push(i.value); else order.splice(order.indexOf(i.value), 1);
    });
    c.querySelector('[data-save]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(sb, 'eng_staff_set', { p_user: c.dataset.u, p: { specialties: order.filter((v, k, a) => a.indexOf(v) === k), license_no: c.querySelector('[data-lic]').value.trim() } }); toast('حُفظت التخصصات', 'ok'); D = await rpc(sb, 'eng_inbox'); }
      catch (er) { toast(cleanErr(er), 'bad'); }
      e.target.disabled = false;
    };
  });
}
