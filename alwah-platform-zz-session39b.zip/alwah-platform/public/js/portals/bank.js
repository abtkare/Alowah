// بوابة المصرف — دورة الطلب مطابقة لإجراء تمويل المبادرة: الفرع ← قسم المبادرات ← الإدارة العليا ← البنك المركزي ← التنفيذ
// فصل مهام كامل: كل مرحلة لدور واحد، ومراحل الفرع لموظفي الفرع نفسه
import { ROLE_LABELS, esc, iqd, mln, pct, num, kpi, appsTable, openApp, stageActions, rpc, badge, REF_STATUS, BATCH_STATUS, SREF_STATUS, DD_MODE, tabs, dt, toast, cleanErr, modal, enrichVet, isVet } from '../core.js';
import { perfView, myPerf, canSeePerf } from '../perf.js';
import { assignAllows } from '../team.js';
import { loadIntake, bankIntakeCard, bindIntake } from '../intake-ui.js';
import { loadFix, bankFixCard, bindBankFix, siteConfirmCard, bindSiteConfirm, bankSettings, bankOpt } from '../journey22.js';
import { loadGuarantee, bankGuaranteeCard, bindBankGuarantee, ministryRejected } from '../guarantee31.js';

const UNIT_HINT = {
  bank_cs: 'خدمة الزبائن في الفرع: قائمة التدقيق عند الاستقبال (الرفض الفوري لإكمال النواقص) وإحالة دراسات الجدوى إلى الخبير المعتمد، تدقيق المستمسكات والاستعلام الائتماني، الضمان الأولي، الإضبارة والوعد بالشراء، توقيع العقد، تسليم جدول الأقساط وحفظ العقود.',
  bank_compliance: 'التحقق من وجود حساب للزبون أو فتحه، وفحص الامتثال. لا تعدّل البيانات.',
  bank_branch_mgr: 'الموافقة المبدئية، قرار اللجنة الائتمانية في الفرع، تدقيق العقد والكمبيالة، وتدقيق قيد الصرف.',
  bank_initiatives: 'استلام الإضبارة وقائمة التدقيق، استكمال الضمان النهائي، وتجميع الطلبات في سلفة تجميعية للبنك المركزي.',
  bank_credit: 'مسؤول شعبة ائتمان المبادرات: التحقق من النواقص، الدراسة الائتمانية والتوصية، إبلاغ الفرع بعد تعزيز السلفة من ائتمان المصرف، وطلب التنفيذ.',
  bank_inspection: 'لجنة الكشف الموقعي: الكشف قبل الدراسة، ثم الكشف على التركيب واستلام البضاعة.',
  bank_initiatives_mgr: 'قرار قسم المبادرات على الدراسة، والتحقق من مطابقة طلب التنفيذ للسياسة.',
  bank_legal: 'القرار القانوني على الإضبارة والضمانات. لا يغيّر شروط القرار الائتماني.',
  bank_md: 'الموافقة ضمن الصلاحيات، توقيع كتاب السلفة التجميعية، واعتماد طلب التنفيذ.',
  bank_admin: 'إرسال كتاب السلفة التجميعية الموقّع إلى البنك المركزي للسحب من ائتمان المصرف، وإعادة محاولة التعزيز إن لم يكفِ الائتمان.',
  bank_ops: 'تسجيل طلب التنفيذ وأمر الشراء من المورد، ثم تنفيذ التمويل وإصدار جدول الأقساط.',
  bank_teller: 'صرف المبلغ للمورد وتوقيع القيد. لا يقرر ولا يعدّل العقد.',
  bank_collection: 'الاستقطاع الشهري والمتأخرات ومطالبة الكفيل أو التأمين. لا إعفاء دون قرار.',
  bank_committee: 'اللجنة الائتمانية العليا: تُعرض عليها الاستثناءات من السياسة بغض النظر عن قيمة التمويل.',
  bank_risk: 'ترى ولا تنفذ: مؤشرات الأداء والتأخير واستخدام الحصة.',
  bank_payroll: 'توطين الرواتب: تأييد توطين راتب الكفيل وتفعيل الاستقطاع المباشر بطلب من المصرف المُقرض.',
  bank_islamic_products: 'المنتجات الإسلامية: تعريف المنتج وكتابة عقده وتقديمه للهيئة الشرعية، والرد على تعليقاتها ورفع النسخ المعدّلة.',
};

export async function render(ctx) {
  const { sb, profile, org, stages, root } = ctx;
  // الجلسة 14: موظف توطين الرواتب يرى صندوق مفاتحات الاستقطاع المباشر فقط
  if (profile.role === 'bank_payroll') return (await import('./payroll.js')).render(ctx);
  // الجلسة 39: مسؤول المنتجات الإسلامية يرى منتجات مصرفه وعقودها ودورة اعتمادها لدى الهيئة الشرعية
  if (profile.role === 'bank_islamic_products') return (await import('./islamic.js')).render(ctx);
  const [apps, alloc, refs, terms, batches, branches, srefs] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
    sb.from('mortgage_referrals').select('*').then(r => r.data || []),
    sb.from('bank_terms').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
    sb.from('cbi_batches').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('branches').select('*').then(r => r.data || []),
    sb.from('salary_referrals').select('*').eq('bank_id', org.id).order('created_at').then(r => r.data || []).catch(() => []),
  ]);
  const banks = (ctx.orgs || []).filter(o => o.type === 'bank');
  await enrichVet(sb, apps);
  // المشاريع البيطرية: دفعات مستحقة للمورد بانتظار أمين الصندوق (توريد ← تركيب ← تشغيل وإجازة)
  const vetIds = apps.filter(a => isVet(a) && a.stage >= 31 && a.stage <= 35 && a.status === 'active').map(a => a.id);
  const due = vetIds.length ? ((await sb.from('vet_tranches').select('application_id,n,amount').eq('status', 'ready').in('application_id', vetIds)).data || []) : [];
  const reasons = Object.fromEntries((((await sb.from('rejection_reasons').select('code,label')).data) || []).map(x => [x.code, x.label]));
  ctx.branches = branches;
  const myBranch = branches.find(b => b.id === profile.branch_id);
  const myStages = stages.filter(s => s.owner_role === profile.role).map(s => s.n);
  const live = a => ['active', 'returned'].includes(a.status);
  // الجلسة 11: المرحلة المسندة لموظف بعينه تظهر في صندوقه وحده (وصندوق بديله حين يغيب)
  const rules = await sb.rpc('my_assignment_rules').then(r => r.data || []).catch(() => []);
  const inbox = apps.filter(a => (myStages.includes(a.stage) && live(a) && !stages.find(s => s.n === a.stage)?.batch_only && assignAllows(rules, a, profile))
    || (profile.role === 'bank_teller' && due.some(d => d.application_id === a.id) && (!profile.branch_id || a.branch_id === profile.branch_id)));
  inbox.sort((x, y) => (y.priority === 'urgent') - (x.priority === 'urgent'));
  const urgent = inbox.filter(a => a.priority === 'urgent').length;
  const active = apps.filter(live);
  const completed = apps.filter(a => a.status === 'completed');
  const toBatch = apps.filter(a => a.stage === 20 && a.status === 'active');
  const batchInbox = batches.filter(b => (profile.role === 'bank_md' && b.status === 'draft') || (profile.role === 'bank_admin' && ['signed', 'sent'].includes(b.status)) || (profile.role === 'bank_initiatives' && b.status === 'draft'));
  const used = alloc ? (alloc.reserved + alloc.disbursed) / alloc.allocated * 100 : 0;
  const avail = alloc ? alloc.allocated - alloc.reserved - alloc.disbursed : 0;
  const isRisk = profile.role === 'bank_risk';
  const batchRole = ['bank_initiatives', 'bank_md', 'bank_admin'].includes(profile.role);
  const batchCount = profile.role === 'bank_initiatives' ? toBatch.length : batchInbox.length;

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}${org.is_islamic ? ' <span class="badge ok">مصرف إسلامي — مسار المرابحة</span>' : ''}</h1>
      <p>${esc(ROLE_LABELS[profile.role])}${myBranch ? ` — <b>${esc(myBranch.name)}</b>` : ' — الإدارة العامة'}. ${esc(UNIT_HINT[profile.role] || '')}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('في صندوق وحدتي', `<span class="num">${inbox.length + (batchRole ? batchCount : 0)}</span>`, 'معاملات تنتظر إجراءك', true)}
      ${kpi('قيد المعالجة', `<span class="num">${active.length}</span>`, myBranch ? 'في فرعك' : 'في كل الفروع')}
      ${kpi('مكتملة', `<span class="num">${completed.length}</span>`, `صُرف لها ${mln(completed.reduce((s, a) => s + a.amount, 0))} دينار`)}
      ${kpi('المتاح من الحصة', mln(avail), `استخدام ${pct(used)} من المخصص`)}
    </div>
    ${used >= 80 ? `<div class="notice warn">⚠ استخدام الحصة بلغ ${pct(used)} — ${used >= 95 ? 'أُوقفت العروض الجديدة لحين التعزيز' : used >= 90 ? 'مؤشر أحمر لدى البنك المركزي' : 'يُنصح برفع طلب تعزيز إلى البنك المركزي'}.</div>` : ''}
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [
    ...(isRisk ? [] : [{ key: 'inbox', label: 'صندوق وحدتي', count: inbox.length }]),
    ...(batchRole ? [{ key: 'batch', label: 'السلف التجميعية', count: batchCount }] : []),
    { key: 'all', label: myBranch ? 'طلبات الفرع' : 'كل طلبات المصرف' },
    ...(canSeePerf(profile.role) ? [{ key: 'perf', label: 'تحليل الأداء' }] : [{ key: 'me', label: 'أدائي' }]),
    ...(['bank_collection', 'bank_risk', 'bank_md', 'bank_branch_mgr', 'bank_teller', 'bank_ops'].includes(profile.role) ? [{ key: 'collect', label: 'الأقساط والتحصيل' }] : []),
    { key: 'quota', label: 'دفتر الحصة والشروط' },
    { key: 'initiatives', label: '📣 مبادرات البنك المركزي' },
    ...(['bank_cs', 'bank_initiatives', 'bank_legal', 'bank_risk'].includes(profile.role) ? [{ key: 'mortgage', label: 'إحالات الرهن' }] : []),
    ...(['bank_md', 'bank_admin', 'bank_branch_mgr'].includes(profile.role) ? [{ key: 'settings', label: '⚙ إعدادات المصرف' }] : []),
  ];
  ctx.bankTab = defs.find(d => d.key === ctx.bankTab) ? ctx.bankTab : defs[0].key;
  tabs(root.querySelector('#tabs'), defs, k => { ctx.bankTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.bankTab));

  const open = async a => {
    const mine = inbox.includes(a) && myStages.includes(a.stage);
    const ref = refs.filter(r => r.application_id === a.id).sort((x, y) => y.created_at.localeCompare(x.created_at))[0];
    let actions = mine ? stageActions(ctx, a) : [];
    const canRefer = a.guarantee_type === 'mortgage' && (!ref || ['rejected', 'released', 'encumbered'].includes(ref.status))
      && ((profile.role === 'bank_cs' && a.stage === 9) || (profile.role === 'bank_initiatives' && a.stage === 19));
    if (mine && canRefer) {
      actions = [{ label: 'إحالة الرهن إلى التسجيل العقاري', kind: 'cyan', done: 'أُحيل الرهن إلى دائرة التسجيل العقاري', run: n => rpc(sb, 'refer_mortgage', { p_app: a.id, p_note: n }) }, ...actions];
    }
    const extra = a.guarantee_type === 'mortgage' ? `<div class="card mb"><h3>رهن العقار</h3>${ref
      ? `<div class="row">حالة الإحالة: ${badge(REF_STATUS[ref.status])}${ref.annotation_no ? `<span class="muted small">رقم التأشير: <b class="num">${esc(ref.annotation_no)}</b></span>` : ''}</div>
        ${ref.letter_no ? `<p class="small" style="margin:6px 0 0">كتاب الرهن رقم <b class="num">${esc(ref.letter_no)}</b>${ref.letter_date ? ` في <span class="num">${esc(ref.letter_date)}</span>` : ''} — صورة الكتاب وصورة إشارة الحجز في «المستندات»</p>` : ''}
        ${ref.status === 'rejected' ? `<div class="notice warn mt"><b>رفضت دائرة التسجيل العقاري التأشير:</b> ${esc(reasons[ref.reject_reason] || '—')}${ref.note ? ` — ${esc(ref.note)}` : ''}<br><span class="small">القرار: ${esc(ref.decided_by_title || '')} · ${dt(ref.decided_at)} · الدليل مرفق في «المستندات»</span></div>` : ''}`
      : '<p class="muted small" style="margin:0">لم يُحَل الرهن بعد.</p>'}
      <p class="small muted" style="margin:8px 0 0">الإجراء الأولي (الخلو والمطابقة) من الفرع في المرحلة 9، والإجراء النهائي (التأشير) بعد موافقة الإدارة العليا في المرحلة 19.</p></div>` : '';
    const sx = salaryCard(a, mine);
    // الجلسة 31: تأييد وزارة التجارة لرواتب الكفلاء، رهن الذهب، وإعادة الطلب للمقترض لاستبدال الضمان
    const gs = isVet(a) ? null : await loadGuarantee(sb, a);
    const gCan = !!gs && live(a) && a.stage >= 6 && a.stage <= 19 && ['bank_cs', 'bank_initiatives', 'bank_branch_mgr'].includes(profile.role) && (!profile.branch_id || !a.branch_id || profile.branch_id === a.branch_id);
    const srefRej = srefs.some(r => r.application_id === a.id && r.status === 'rejected');
    if (gCan && mine && (ministryRejected(a, gs).length || srefRej)) {
      actions = [{ label: 'إعادة للمقترض لاستبدال الضمان', kind: 'warn', done: 'أُعيد الطلب للمقترض — يختار كفيلاً آخر أو ذهباً أو عقاراً من هاتفه',
        run: note => rpc(sb, 'guarantee_return', { p_app: a.id, p_note: note }) }, ...actions];
    }
    const g31 = gs ? bankGuaranteeCard(a, gs, { can: gCan, srefRejected: srefRej }) : '';
    // الجلسة 16: قائمة التدقيق في الاستقبال، و«رفض فوري» لإكمال النواقص، ودراسة الجدوى لدى الخبير المعتمد
    const ik = isVet(a) ? null : await loadIntake(sb, a).catch(() => null);
    if (ik?.ck?.applies && mine && a.stage === 6) {
      actions = actions.filter(x => x.label !== 'إعادة للاستكمال' && (ik.ck.can_accept || !x.needConfirm));
      actions.splice(ik.ck.can_accept ? 1 : 0, 0, { label: 'رفض فوري — إرجاع للمقترض لإكمال النواقص', kind: 'warn', done: 'أُعيد الطلب للمقترض مع قائمة النواقص — يبقى رقمه وبياناته',
        run: note => rpc(sb, 'intake_return', { p_app: a.id, p_note: note }) });
    }
    const ix = ik ? bankIntakeCard(a, ik, { mine, role: profile.role }) : '';
    // الجلسة 22: نواقص يصلحها المقترض من هاتفه (المقترح 10)، تأكيد الدبوس اليدوي في الكشف (8)، واستلام الجدول من الهاتف (11)
    const fixes = isVet(a) ? [] : await loadFix(sb, a.id).catch(() => []);
    const canAsk = live(a) && a.stage >= 6 && a.stage <= 36 && (mine || ['bank_cs', 'bank_branch_mgr'].includes(profile.role)) && (!profile.branch_id || !a.branch_id || profile.branch_id === a.branch_id);
    const s22 = bankFixCard(a, fixes, { canAsk }) + siteConfirmCard(a, { mine, role: profile.role })
      + (a.schedule_ack ? `<div class="card mb"><h3>استلام جدول الأقساط ${badge(['من هاتف المقترض برمز تحقق', 'ok'])}</h3><p class="small muted" style="margin:0">${dt(a.schedule_ack.at)} · <span class="num">${a.schedule_ack.count}</span> قسطاً · أول استحقاق <span class="num">${esc(a.schedule_ack.first_due || '')}</span></p></div>`
        : a.stage === 34 && bankOpt(org, 'opt_phone_schedule') ? '<div class="notice mb"><span>📱</span><span class="small">خيار المصرف مفعّل: يستطيع المقترض استلام جدول أقساطه والتوقيع على الاستلام من هاتفه برمز تحقق — ينتقل الطلب آلياً إلى المرحلة 35. يبقى التسليم في الفرع متاحاً.</span></div>' : '');
    // الجلسة 15: التوقيع الإلكتروني للعقد (المرحلة 25 وما بعدها)
    const ex = a.stage >= 25 ? '<div data-esign-box></div>' : '';
    openApp(ctx, a, { actions, extra: ix + g31 + s22 + ex + extra + sx }).then(() => {
      const dr = document.querySelector('.drawer');
      bindBankFix(sb, a, dr, { refresh: () => ctx.refresh() });
      bindSiteConfirm(sb, a, dr, { accMax: ctx.settings?.site_gps_accuracy_m || 100, refresh: () => ctx.refresh() });
      bindSalary(a);
      if (gs) bindBankGuarantee(ctx, a, gs, dr);
      if (ik) bindIntake(ctx, a, ik, document.querySelector('.drawer'));
      if (ex) import('../esign-ui.js').then(m => m.mountEsignBank(ctx, a, mine, document.querySelector('.drawer [data-esign-box]')));
    });
  };

  // ───────── الجلسة 14: كفالة الراتب — مفاتحة المصرف الموطَّن لتفعيل الاستقطاع المباشر ─────────
  const isSalary = a => ['single_salary', 'multi_salary'].includes(a.guarantee_type);
  // الجلسة 31: المفاتحة متاحة من الاستقبال (6) — لا تنتظر المرحلة 9
  const canSalaryRefer = a => live(a) && a.stage >= 6 && a.stage <= 19 && ['bank_cs', 'bank_initiatives'].includes(profile.role) && (!profile.branch_id || !a.branch_id || profile.branch_id === a.branch_id);
  function salaryRows(a) {
    const gs = a.guarantee?.guarantors || [];
    const need = Math.max(a.guarantee_type === 'single_salary' ? 1 : 2, gs.length);
    return Array.from({ length: need }, (_, i) => ({ i, g: gs[i] || null, ref: srefs.filter(r => r.application_id === a.id && r.g_index === i).slice(-1)[0] || null }));
  }
  function salaryCard(a, mine) {
    if (!isSalary(a)) return '';
    const rows = salaryRows(a), can = canSalaryRefer(a);
    return `<div class="card mb"><h3>كفالة الراتب — الاستقطاع المباشر</h3>
      ${rows.map(({ i, g, ref }) => `<div class="row" style="padding:8px 0;border-bottom:1px solid var(--line);flex-wrap:wrap;gap:6px">
        <div><b>الكفيل ${i + 1}:</b> ${esc(ref?.guarantor_name || g?.name || 'لم تُدخل بياناته')}${(ref?.employer || g?.employer) ? ` <span class="muted small">· ${esc(ref?.employer || g?.employer)}</span>` : ''}
          ${ref ? `<div class="small muted">${esc(banks.find(b => b.id === ref.salary_bank_id)?.name || '')} · حساب <span class="num" dir="ltr">${esc(ref.salary_account || '')}</span> · <span class="num">${esc(ref.code)}</span>${ref.mandate_no ? ` · تخويل <b class="num">${esc(ref.mandate_no)}</b> يبدأ <span class="num">${esc(ref.start_date)}</span>` : ''}</div>` : ''}</div>
        <span class="sp"></span>${ref ? badge(SREF_STATUS[ref.status]) : badge(['لم يُفاتَح المصرف الموطَّن', 'warn'])}
        ${can && (!ref || ['rejected', 'cancelled'].includes(ref.status)) ? `<button type="button" class="btn cyan sm" data-sref="${i}">مفاتحة المصرف الموطَّن</button>` : ''}
        ${mine && ref && ['pending', 'confirmed'].includes(ref.status) && ['bank_cs', 'bank_initiatives'].includes(profile.role) ? `<button type="button" class="linkbtn" data-scancel="${ref.id}">إلغاء</button>` : ''}
        ${ref?.status === 'rejected' ? `<div class="notice warn" style="width:100%;margin:4px 0 0">رفض المصرف الموطَّن: ${esc(ref.note || '')} <span class="small">(${esc(ref.decided_by_title || '')} · ${dt(ref.decided_at)})</span></div>` : ''}
      </div>`).join('')}
      <p class="small muted" style="margin:8px 0 0">الإجراء الأولي (المرحلة 9): تفاتح خدمة الزبائن المصرف الموطَّن لراتب كل كفيل ويؤيد التوطين. الإجراء النهائي (المرحلة 19): يفعّل المصرف الموطَّن الاستقطاع المباشر بعد موافقة الإدارة العليا ويرفق نموذج التخويل وكتاب التفعيل.</p></div>`;
  }
  function bindSalary(a) {
    const dr = document.querySelector('.drawer'); if (!dr) return;
    dr.querySelectorAll('[data-sref]').forEach(b => b.onclick = () => referDialog(a, Number(b.dataset.sref)));
    dr.querySelectorAll('[data-scancel]').forEach(b => b.onclick = async () => {
      const m = modal(`<h3>إلغاء المفاتحة</h3><div class="field"><label>سبب الإلغاء</label><textarea class="input" rows="2" data-n></textarea></div><div class="row mt"><span class="sp"></span><button class="btn bad" data-go>إلغاء المفاتحة</button></div>`);
      m.el.querySelector('[data-go]').onclick = async e => {
        e.target.disabled = true;
        try { await rpc(sb, 'cancel_salary_referral', { p_ref: b.dataset.scancel, p_note: m.el.querySelector('[data-n]').value }); m.close(); toast('أُلغيت المفاتحة', 'ok'); ctx.refresh(); }
        catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
      };
    });
  }
  function referDialog(a, i) {
    const g = (a.guarantee?.guarantors || [])[i] || {};
    const m = modal(`<h3>مفاتحة المصرف الموطَّن لراتب الكفيل ${i + 1}</h3>
      <p class="small muted" style="margin-top:0">تُرسل المفاتحة إلكترونياً إلى موظف توطين الرواتب في المصرف الذي يُصرف عليه راتب الكفيل، ليؤيد التوطين ثم يفعّل الاستقطاع المباشر بمبلغ ${iqd(a.monthly_installment || 0)} شهرياً.</p>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>اسم الكفيل الثلاثي</label><input class="input" data-k="guarantor_name" value="${esc(g.name || '')}"></div>
        <div class="field"><label>جهة العمل (دائرة التمويل)</label><input class="input" data-k="employer" value="${esc(g.employer || '')}"></div>
        <div class="field"><label>الراتب المصرَّح به (د.ع)</label><input class="input" data-k="declared_salary" inputmode="numeric" dir="ltr" value="${esc(g.salary || '')}"></div>
        <div class="field"><label>هاتف الكفيل</label><input class="input" data-k="guarantor_phone" dir="ltr" value="${esc(g.phone || '')}"></div>
        <div class="field"><label>المصرف الموطَّن لديه الراتب</label><select class="input" data-k="salary_bank_id"><option value="">اختر المصرف</option>${banks.map(b => `<option value="${b.id}" ${g.salary_bank_id === b.id ? 'selected' : ''}>${esc(b.name)}</option>`).join('')}</select></div>
        <div class="field"><label>رقم حساب الراتب أو IBAN</label><input class="input" data-k="salary_account" dir="ltr" value="${esc(g.salary_account || '')}"></div>
        <div class="field"><label>نوع الاستقطاع</label><select class="input" data-k="dd_mode">${Object.entries(DD_MODE).map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select></div>
      </div>
      <div class="field"><label>ملاحظة</label><textarea class="input" rows="2" data-k="note"></textarea></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>إرسال المفاتحة</button></div>`, { wide: true });
    m.el.querySelector('[data-go]').onclick = async e => {
      const d = { g_index: i };
      m.el.querySelectorAll('[data-k]').forEach(x => d[x.dataset.k] = x.value.trim());
      d.declared_salary = String(d.declared_salary || '').replace(/\D/g, '');
      if (!d.salary_bank_id) return toast('اختر المصرف الموطَّن لديه راتب الكفيل', 'bad');
      e.target.disabled = true;
      try { const r = await rpc(sb, 'refer_salary', { p_app: a.id, p_data: d }); m.close(); toast(`أُرسلت المفاتحة ${r.code}`, 'ok'); ctx.refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  }

  function show(k) {
    if (k === 'inbox') body.innerHTML = `${urgent ? `<div class="notice warn">⚠ <b class="num">${urgent}</b> معاملة مُرجعة بأولوية <b>مستعجل</b> في أعلى الصندوق — افتحها لترى النقص المطلوب.</div>` : ''}${profile.role === 'bank_teller' && due.length ? `<div class="notice">⚕ <b class="num">${due.length}</b> دفعة مستحقة لموردي المشاريع البيطرية بمبلغ ${iqd(due.reduce((t, d) => t + Number(d.amount), 0))} — افتح الطلب واصرف الدفعة من قسم «التوريد والصرف للمورد على دفعات».</div>` : ''}
      <div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'kw', 'amount', 'guarantee', 'stage', 'status', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'gov', 'kw', 'amount', 'stage', 'status', 'updated'] })}</div>`;
    if (k === 'mortgage') body.innerHTML = `<div class="card flush">${appsTable(apps.filter(a => a.guarantee_type === 'mortgage'), ctx, { onOpen: open, cols: ['code', 'name', 'branch', 'amount', 'stage', 'status'] })}</div>`;
    if (k === 'perf') perfView(ctx, body, { mode: 'bank' });
    if (k === 'me') myPerf(ctx, body);
    if (k === 'initiatives') import('../cbi-extra.js').then(m => m.bankInitiatives(ctx, body));
    if (k === 'batch') showBatches();
    if (k === 'settings') bankSettings(ctx, body, org);
    if (k === 'collect') import('../repay-ui.js').then(m => m.collectionView(ctx, body, open, apps));
    if (k === 'quota') {
      const a = alloc || { allocated: 0, reserved: 0, disbursed: 0 };
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      body.innerHTML = `<div class="grid g2">
        <div class="card"><h3>دفتر حصة المصرف</h3>
          <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
          <div class="legend"><span><i style="background:var(--indigo)"></i>مصروف</span><span><i style="background:var(--sun)"></i>محجوز</span><span><i style="background:#E8EDF5"></i>متاح</span></div>
          <dl class="kv mt"><dt>ائتمان المصرف لدى البنك المركزي</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز بسلف معزَّزة</dt><dd>${iqd(a.reserved)}</dd>
          <dt>المصروف للموردين</dt><dd>${iqd(a.disbursed)}</dd><dt>المتاح</dt><dd>${iqd(avail)}</dd></dl>
          <p class="small muted mt">يُحجز المبلغ من ائتمان المصرف لحظة تعزيز السلفة التجميعية (آلياً عند إرسال كتابها إن كان الائتمان كافياً)، ويتحول إلى «مصروف» عند صرف أمين الصندوق للمورد. يجب التنفيذ خلال شهر من التعزيز، وبعد 3 أشهر تُفرض الغرامة.</p></div>
        <div class="card"><h3>شروط التمويل المعلنة</h3>
          <dl class="kv"><dt>عوائد المصرف السنوية</dt><dd>${pct(terms?.margin)} متناقصة</dd><dt>رسم دراسة الملف</dt><dd>${iqd(terms?.file_fee)}</dd>
          <dt>عمولة المصرف (يدفعها المقترض قبل الإرسال)</dt><dd>${pct(terms?.commission_pct ?? 1)} من مبلغ التمويل</dd>
          <dt>أقصى مدة</dt><dd><span class="num">${num(terms?.max_term_months)}</span> شهراً شاملة السماح</dd><dt>مدة المعالجة المعلنة</dt><dd><span class="num">${num(terms?.processing_days)}</span> أيام</dd>
          <dt>سقف الموافقة الأحادية</dt><dd>${iqd(terms?.single_approval_cap)}</dd></dl>
          <p class="small muted mt">عمولة البنك المركزي تُستوفى لمرة واحدة ولا تُسترجع. الاستثناءات من السياسة تُعرض على اللجنة الائتمانية العليا.</p></div></div>`;
    }
  }

  // السلف التجميعية: إداري المبادرات يجمع ← الإدارة العليا توقّع ← قسم الإدارة يرسل ← تُعزَّز آلياً من ائتمان المصرف لدى البنك المركزي
  function showBatches() {
    const cap = 200000000;
    const pickable = profile.role === 'bank_initiatives' ? toBatch : [];
    body.innerHTML = `
      ${pickable.length ? `<div class="card flush mb"><h3>طلبات جاهزة للتجميع <span class="sp"></span><span class="small muted">سقف السلفة الواحدة ${mln(cap)} دينار</span></h3>
        <div class="tbl-wrap"><table class="tbl batch-pick"><thead><tr><th></th><th>رقم الطلب</th><th>المتقدم</th><th>الفرع</th><th>المبلغ</th><th>الضمان</th></tr></thead><tbody>
        ${pickable.map(a => `<tr><td><input type="checkbox" data-pick="${a.id}" data-amt="${a.amount}" checked></td><td><b class="num">${esc(a.code)}</b></td><td>${esc(a.citizen_name)}</td><td>${esc(branches.find(b => b.id === a.branch_id)?.name || '—')}</td><td>${iqd(a.amount)}</td><td class="small">${esc(a.guarantee_type === 'mortgage' ? 'رهن عقار' : a.guarantee_type === 'gold' ? 'رهن ذهب' : 'كفالة راتب')}</td></tr>`).join('')}
        </tbody></table></div>
        <div class="sumbar"><span>المجموع: <b data-sum></b></span><span class="sp"></span><button class="btn cyan" data-make>إنشاء السلفة التجميعية</button></div></div>`
        : profile.role === 'bank_initiatives' ? '<div class="notice">لا طلبات في مرحلة التجميع الآن (المرحلة 20).</div>' : ''}
      <div class="card flush"><h3>سجل السلف التجميعية</h3>${batches.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>السلفة</th><th>الطلبات</th><th>المبلغ</th><th>الحالة</th><th>الكتاب</th><th>التواريخ</th><th></th></tr></thead><tbody>
        ${batches.map(b => {
          const act = (profile.role === 'bank_md' && b.status === 'draft') ? ['sign', 'توقيع الكتاب', 'ok'] : (profile.role === 'bank_admin' && b.status === 'signed') ? ['send', 'إرسال وتعزيز من ائتمان المصرف', 'cyan'] : (profile.role === 'bank_admin' && b.status === 'sent') ? ['fund', 'إعادة محاولة التعزيز', 'warn'] : (profile.role === 'bank_initiatives' && b.status === 'draft') ? ['dissolve', 'فك السلفة', 'ghost'] : null;
          return `<tr><td><b class="num">${esc(b.code)}</b></td><td class="num">${b.apps_count}</td><td>${iqd(b.total)}</td><td>${badge(BATCH_STATUS[b.status])}</td><td class="num small">${esc(b.letter_ref || '—')}</td>
          <td class="small muted">أُنشئت ${dt(b.created_at)}${b.signed_at ? `<br>وُقّعت ${dt(b.signed_at)}` : ''}${b.sent_at ? `<br>أُرسلت ${dt(b.sent_at)}` : ''}${b.decided_at ? `<br>${b.status === 'approved' ? 'عُزّزت' : 'القرار'} ${dt(b.decided_at)}` : ''}${b.status === 'rejected' && b.decision_note ? `<br>${esc(b.decision_note)}` : ''}${(b.oversight_notes || []).map(o => `<br><span style="color:var(--warn)">تدخل رقابي من البنك المركزي ${dt(o.at)}: ${esc(o.note)}</span>`).join('')}</td>
          <td>${act ? `<button class="btn sm ${act[2]}" data-act="${act[0]}" data-b="${b.id}">${act[1]}</button>` : ''}</td></tr>`;
        }).join('')}</tbody></table></div>` : '<div class="empty">لا سلف بعد.</div>'}</div>`;
    const sumEl = body.querySelector('[data-sum]');
    const recalc = () => {
      if (!sumEl) return;
      const t = [...body.querySelectorAll('[data-pick]:checked')].reduce((s, x) => s + Number(x.dataset.amt), 0);
      sumEl.innerHTML = `${iqd(t)} ${t > cap ? '<span class="badge bad">يتجاوز السقف</span>' : ''}`;
    };
    body.querySelectorAll('[data-pick]').forEach(x => x.onchange = recalc); recalc();
    const mk = body.querySelector('[data-make]');
    if (mk) mk.onclick = async () => {
      const ids = [...body.querySelectorAll('[data-pick]:checked')].map(x => x.dataset.pick);
      mk.disabled = true;
      try { const b = await rpc(sb, 'batch_create', { p_apps: ids }); toast(`أُنشئت السلفة ${b.code} — بانتظار توقيع الإدارة العليا`, 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); mk.disabled = false; }
    };
    body.querySelectorAll('[data-act]').forEach(btn => btn.onclick = async () => {
      btn.disabled = true;
      try { await rpc(sb, 'batch_action', { p_batch: btn.dataset.b, p_action: btn.dataset.act }); toast('تم', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); btn.disabled = false; }
    });
  }

  show(ctx.bankTab);
}

// لا يُعاد رسم الشاشة أثناء العمل على لوحة الأداء أو اختيار طلبات السلفة
export const shouldRefresh = ctx => ctx.bankTab !== 'perf' && !document.querySelector('.mdl-bg,.ip-ed,.rs-bg');
