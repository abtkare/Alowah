// الجلسة 39: «المنتجات الإسلامية» في بوابة المصرف الإسلامي — لدور مسؤول المنتجات الإسلامية (bank_islamic_products)
// يعرّف المنتج ويكتب نموذج عقده بنداً بنداً، ويقدّمه للهيئة الشرعية، ويرى تعليقاتها على كل بند ويرد عليها، ويرفع نسخة معدّلة.
// لا يظهر أي منتج للمقترض قبل قرار اعتماد نافذ من الهيئة.
import { esc, dt, rpc, toast, cleanErr, modal, kpi, resultScreen } from '../core.js';
import { shBadge, SECTORS, SUBSECTORS, GUARANTEES, ATTACHMENTS, contractHtml, resolutionHtml, shortSha } from '../sharia-ui.js';

let D;
export const shouldRefresh = () => !document.querySelector('.mdl-bg,.rs-bg,.ip-ed');

export async function render(ctx) {
  const { sb, root } = ctx;
  D = await rpc(sb, 'islamic_my_products');
  if (ctx.ipOpen) {
    if (D.products.some(p => p.id === ctx.ipOpen)) return detail(ctx, ctx.ipOpen);
    ctx.ipOpen = null;
  }
  const P = D.products;
  const todo = P.filter(p => ['draft', 'returned'].includes(p.status) || (p.status === 'deliberation' && p.comments_open));
  root.innerHTML = `
    <div class="page-head"><div><h1>المنتجات الإسلامية — ${esc(D.bank)}</h1>
      <p>عرّف المنتج واكتب عقده، وقدّمه إلى <b>${esc(D.board.name)}</b>. الصيغ على ${esc(D.board.madhhab_label)}.</p></div><span class="sp"></span>
      <button class="btn cyan" data-new>+ منتج جديد</button></div>
    <div class="grid g4 mb">
      ${kpi('المطلوب منك الآن', `<span class="num">${todo.length}</span>`, 'مسودات أو إعادات أو تعليقات مفتوحة', true)}
      ${kpi('لدى الهيئة', `<span class="num">${P.filter(p => ['submitted', 'deliberation'].includes(p.status)).length}</span>`, 'تحقق أو مداولة')}
      ${kpi('معتمدة نافذة', `<span class="num">${P.filter(p => ['approved', 'conditional'].includes(p.status)).length}</span>`, 'تظهر للمقترضين الآن')}
      ${kpi('كل المنتجات', `<span class="num">${P.length}</span>`, '')}
    </div>
    ${P.length ? `<div class="eng-cards">${P.map(card).join('')}</div>` : '<div class="card empty">لا منتجات بعد — ابدأ بـ«منتج جديد»</div>'}`;
  root.querySelector('[data-new]').onclick = () => productForm(ctx, null);
  root.querySelectorAll('[data-open]').forEach(x => x.onclick = () => { ctx.ipOpen = x.dataset.open; window.scrollTo(0, 0); render(ctx); });
}

function card(p) {
  const need = p.status === 'draft' ? 'أكمل العقد وقدّمه للهيئة' : p.status === 'returned' ? 'أعادته الهيئة — عدّل وقدّم من جديد'
    : p.status === 'deliberation' && p.comments_open ? `${p.comments_open} تعليق من الهيئة — ردّ أو ارفع نسخة معدّلة` : '';
  return `<button type="button" class="eng-card sh-card ${p.status}" data-open="${p.id}">
    <div class="row"><b class="num">${esc(p.code)}</b><span class="tag">${esc(p.type)}</span><span class="sp"></span>${shBadge(p.status)}</div>
    <div class="eng-proj">${(SECTORS[p.sector] || ['•'])[0]} ${esc(p.name)}</div>
    <div class="small muted">${esc(p.type_name)} · ${esc(p.sector_label)} · النسخة <span class="num">${p.version ?? '—'}</span></div>
    ${p.resolution ? `<div class="small mt">قرار <b class="num">${esc(p.resolution.code)}</b> — ${esc(p.resolution.decision_label)}</div>` : ''}
    ${need ? `<div class="sh-need">← ${esc(need)}</div>` : ''}
  </button>`;
}

async function detail(ctx, id) {
  const { sb, root } = ctx;
  let P;
  try { P = await rpc(sb, 'sharia_product', { p_id: id }); }
  catch (e) { ctx.ipOpen = null; toast(cleanErr(e), 'bad'); return render(ctx); }
  const editable = ['draft', 'returned'].includes(P.status), delib = P.status === 'deliberation';
  ctx.ipDiff = ctx.ipDiff ?? !!P.previous;
  const reload = () => detail(ctx, id);
  root.innerHTML = `
    <button class="btn ghost sm eng-back" data-back>→ منتجاتي</button>
    <div class="card sh-head">
      <div class="row"><b class="num">${esc(P.code)}</b><span class="tag">${esc(P.type)}</span><span class="sp"></span>${shBadge(P.status)}</div>
      <h2>${(SECTORS[P.sector] || ['•'])[0]} ${esc(P.name)}</h2><p class="muted" style="margin:2px 0 8px">${esc(P.line || '')}</p>
      <dl class="kv sm"><dt>الصيغة</dt><dd>${esc(P.type_name)}</dd><dt>القطاع</dt><dd>${esc(P.sector_label)}</dd>
        <dt>نسبة الربح</dt><dd>${P.pricing?.profit_min != null ? `<span class="num">${P.pricing.profit_min}%</span> – <span class="num">${P.pricing.profit_max}%</span>` : '—'} · المدة حتى <span class="num">${P.pricing?.term_max ?? '—'}</span> شهراً</dd>
        <dt>الملحقات</dt><dd>${(P.attachments || []).map(esc).join('، ') || '<span class="warn-t">لا ملحقات</span>'}</dd>
        <dt>البصمة</dt><dd>${shortSha(P.current?.sha256)}</dd></dl>
      ${P.status_note ? `<div class="notice ${P.status === 'returned' ? 'warn' : ''} mt"><span>${P.status === 'returned' ? '⚠' : 'ℹ'}</span><span class="small" style="white-space:pre-line">${esc(P.status_note)}</span></div>` : ''}
    </div>
    <div class="card sh-now ${editable || delib ? '' : 'calm'}">
      ${editable ? `<h3>المطلوب منك الآن: ${P.status === 'returned' ? 'عدّل ما طلبته الهيئة ثم قدّم من جديد' : 'أكمل المنتج وقدّمه للهيئة'}</h3>
        <ul class="sh-check">${P.checklist.map(c => `<li class="${c.ok ? 'ok' : 'no'}"><i>${c.ok ? '✓' : '✗'}</i>${esc(c.label)}</li>`).join('')}</ul>
        <div class="row mt" style="flex-wrap:wrap"><button class="btn ghost" data-edit>تعديل بيانات المنتج</button><button class="btn ghost" data-text>تعديل نص العقد</button><span class="sp"></span><button class="btn cyan" data-submit>تقديم للهيئة ←</button></div>`
      : delib ? `<h3>قيد المداولة لدى الهيئة</h3><p class="small muted">ردّ على التعليقات تحت كل بند، أو ارفع نسخة معدّلة. النسخة الجديدة تُلغي الأصوات السابقة وتُعرض فروقها على الأعضاء.</p>
        <div class="row"><span class="sp"></span><button class="btn cyan" data-text>رفع نسخة معدّلة</button></div>`
      : P.status === 'submitted' ? '<h3>لدى أمين سر الهيئة</h3><p class="small muted">يتحقق من اكتمال الملف ثم يحيله للأعضاء. يصلك إشعار بأي تعليق أو قرار.</p>'
      : ['approved', 'conditional'].includes(P.status) ? '<h3>معتمد ويظهر للمقترضين</h3><p class="small muted">يوقّع المقترض النص المعتمد حرفياً. أي تعديل في النص يحتاج اعتماداً جديداً من الهيئة.</p>'
      : `<h3>${esc(P.status_label)}</h3>`}
    </div>
    <div class="row sh-ctl"><h3 class="sh-sec" style="margin:0">نص العقد — النسخة <span class="num">${P.current?.n ?? '—'}</span></h3><span class="sp"></span>
      ${P.previous ? `<label class="sh-sw"><input type="checkbox" data-diff ${ctx.ipDiff ? 'checked' : ''}> الفروق عن النسخة <span class="num">${P.previous.n}</span></label>` : ''}</div>
    ${P.current ? contractHtml(P, { showDiff: ctx.ipDiff, canReply: delib || editable }) : '<div class="card empty">لم يُكتب نص العقد بعد</div>'}
    ${P.resolutions_list.length ? `<h3 class="sh-sec">قرارات الهيئة</h3>${P.resolutions_list.map(resolutionHtml).join('')}` : ''}
    <details class="card mt"><summary><b>السجل الزمني</b></summary><ul class="sh-log">${P.log.map(l => `<li><span class="muted small">${dt(l.at)}</span> <b>${esc(l.who || '')}</b> — ${esc(l.action)}${l.note ? `<div class="small muted">${esc(l.note)}</div>` : ''}</li>`).join('')}</ul></details>`;
  root.querySelector('[data-back]').onclick = () => { ctx.ipOpen = null; render(ctx); };
  const dsw = root.querySelector('[data-diff]'); if (dsw) dsw.onchange = () => { ctx.ipDiff = dsw.checked; reload(); };
  const ed = root.querySelector('[data-edit]'); if (ed) ed.onclick = () => productForm(ctx, P, reload);
  root.querySelectorAll('[data-text]').forEach(x => x.onclick = () => clauseEditor(ctx, P, reload));
  const sbm = root.querySelector('[data-submit]');
  if (sbm) sbm.onclick = async e => {
    e.target.disabled = true;
    try { await rpc(sb, 'islamic_product_submit', { p_id: P.id });
      await resultScreen({ title: 'قُدّم المنتج للهيئة', msg: 'يتحقق أمين السر من اكتمال الملف ثم يحيله للأعضاء.', chips: [D.board.name] }); reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  root.querySelectorAll('[data-reply]').forEach(x => x.onclick = () => {
    const m = modal(`<h3>الرد على تعليق الهيئة</h3><div class="field"><textarea class="input" rows="4" data-t placeholder="مثال: عُدّل في النسخة التالية"></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>إرسال</button></div>`);
    m.el.querySelector('[data-x]').onclick = m.close;
    m.el.querySelector('[data-ok]').onclick = async () => {
      try { await rpc(sb, 'islamic_product_reply', { p_review: x.dataset.reply, p_body: m.el.querySelector('[data-t]').value }); m.close(); toast('أُرسل ردّك للهيئة', 'ok'); reload(); }
      catch (er) { toast(cleanErr(er), 'bad'); }
    };
  });
}

// بيانات المنتج: الاسم والقطاع والصيغة وسطر المقترض والتسعير والضمانات والملحقات
function productForm(ctx, P, reload) {
  const s = P || { sector: 'pv', subsector: 'individuals', contract_type: '', pricing: {}, guarantees: [], attachments: [] };
  let sector = s.sector;
  const types = () => D.types.filter(t => t.sectors.includes(sector));
  const m = modal(`<h3>${P ? 'بيانات المنتج' : 'منتج إسلامي جديد'}</h3><form data-f class="grid" style="gap:10px">
    <div class="field"><label>اسم المنتج كما يراه المقترض ★</label><input class="input" name="name" value="${esc(s.name || '')}" placeholder="مثال: منظومتي بالمرابحة" required></div>
    <div class="grid g2" style="gap:10px"><div class="field"><label>القطاع ★</label><select class="input" name="sector">${Object.entries(SECTORS).map(([k, [i, t]]) => `<option value="${k}" ${k === sector ? 'selected' : ''}>${i} ${t}</option>`).join('')}</select></div>
      <div class="field"><label>الفئة</label><select class="input" name="subsector" data-sub></select></div></div>
    <div class="field"><label>الصيغة من مكتبة الهيئة ★</label><select class="input" name="contract_type" data-types></select><small class="muted" data-tline></small></div>
    <div class="field"><label>سطر واحد يشرح الصيغة للمقترض</label><input class="input" name="line" value="${esc(s.line || '')}" maxlength="140"></div>
    <div class="grid g2" style="gap:10px">
      <div class="field"><label>الربح الأدنى % سنوياً</label><input class="input" name="profit_min" type="number" step="0.25" dir="ltr" value="${s.pricing?.profit_min ?? ''}"></div>
      <div class="field"><label>الربح الأعلى % سنوياً</label><input class="input" name="profit_max" type="number" step="0.25" dir="ltr" value="${s.pricing?.profit_max ?? ''}"></div>
      <div class="field"><label>أقل مدة (شهر)</label><input class="input" name="term_min" type="number" dir="ltr" value="${s.pricing?.term_min ?? 12}"></div>
      <div class="field"><label>أقصى مدة (شهر)</label><input class="input" name="term_max" type="number" dir="ltr" value="${s.pricing?.term_max ?? 60}"></div></div>
    <label class="lbl">الضمانات المسموحة</label><div class="chips">${GUARANTEES.map(([k, t]) => `<label class="chip ${s.guarantees.includes(k) ? 'on' : ''}"><input type="checkbox" name="g" value="${k}" ${s.guarantees.includes(k) ? 'checked' : ''}>${t}</label>`).join('')}</div>
    <label class="lbl">الملحقات المرفقة بنموذج العقد</label><div class="chips">${ATTACHMENTS.map(t => `<label class="chip ${s.attachments.includes(t) ? 'on' : ''}"><input type="checkbox" name="a" value="${esc(t)}" ${s.attachments.includes(t) ? 'checked' : ''}>${esc(t)}</label>`).join('')}</div>
    <div class="row"><span class="sp"></span><button type="button" class="btn ghost" data-x>إلغاء</button><button class="btn cyan">${P ? 'حفظ' : 'إنشاء المنتج'}</button></div></form>`, { wide: true });
  const f = m.el.querySelector('[data-f]');
  const fill = () => {
    f.subsector.innerHTML = (SUBSECTORS[sector] || []).map(([k, t]) => `<option value="${k}" ${k === s.subsector ? 'selected' : ''}>${t}</option>`).join('');
    const ts = types();
    f.contract_type.innerHTML = ts.map(t => `<option value="${t.code}" ${t.code === s.contract_type ? 'selected' : ''}>${t.code} — ${esc(t.name)}</option>`).join('');
    line();
  };
  const line = () => { const t = D.types.find(x => x.code === f.contract_type.value); m.el.querySelector('[data-tline]').textContent = t ? t.essence : ''; if (!f.line.value && t) f.line.placeholder = t.borrower_line; };
  f.sector.onchange = () => { sector = f.sector.value; fill(); };
  f.contract_type.onchange = line;
  f.querySelectorAll('.chip input').forEach(i => i.onchange = () => i.parentElement.classList.toggle('on', i.checked));
  fill();
  m.el.querySelector('[data-x]').onclick = m.close;
  f.onsubmit = async e => {
    e.preventDefault();
    const n = k => f[k].value === '' ? undefined : Number(f[k].value);
    const p = { name: f.name.value, sector: f.sector.value, subsector: f.subsector.value, contract_type: f.contract_type.value, line: f.line.value,
      pricing: { profit_min: n('profit_min'), profit_max: n('profit_max'), term_min: n('term_min'), term_max: n('term_max') },
      guarantees: [...f.querySelectorAll('input[name=g]:checked')].map(i => i.value), attachments: [...f.querySelectorAll('input[name=a]:checked')].map(i => i.value) };
    try { const r = await rpc(ctx.sb, 'islamic_product_save', { p_id: P?.id || null, p }); m.close(); toast(P ? 'حُفظت بيانات المنتج' : 'أُنشئ المنتج — اكتب نص عقده', 'ok');
      if (!P) { ctx.ipOpen = r.id; render(ctx); } else reload(); }
    catch (er) { toast(cleanErr(er), 'bad'); }
  };
}

// محرر نص العقد: بنود بعنوان ونص، المتغيرات بين {{…}}
const VARS = [['borrower_name', 'اسم المقترض'], ['bank_name', 'اسم المصرف'], ['asset', 'المنظومة أو الأصل'], ['supplier', 'المورد'], ['place', 'مكان التركيب'], ['cost', 'الكلفة'],
  ['profit', 'الربح'], ['price_total', 'الثمن الكلي'], ['installment', 'القسط أو الأجرة'], ['term', 'عدد الأشهر'], ['residual', 'الثمن الرمزي'], ['madhhab', 'المذهب'], ['board', 'اسم الهيئة'], ['resolution', 'رقم القرار']];
function clauseEditor(ctx, P, reload) {
  let cl = (P.current?.clauses || []).map(c => ({ title: c.title, text: c.text }));
  if (!cl.length) cl = [{ title: 'الأطراف', text: '' }];
  const delib = P.status === 'deliberation', newVer = P.current && P.current.status !== 'draft';
  const bg = document.createElement('div'); bg.className = 'mdl-bg on ip-ed';
  bg.innerHTML = `<div class="mdl wide" role="dialog" aria-modal="true"><button class="mdl-x" aria-label="إغلاق">×</button><div class="mdl-b">
    <h3>نص العقد — ${esc(P.name)}</h3>
    <p class="small muted">${newVer ? `الحفظ يُنشئ <b>النسخة ${(P.version_list[0]?.n || 0) + 1}</b> ببصمة جديدة.` : 'المسودة تُحفظ في مكانها حتى تقدّمها.'} اكتب المتغيرات بين قوسين مزدوجين فتُملأ ببيانات كل مقترض:
      ${VARS.map(([k, t]) => `<button type="button" class="ip-var" data-var="${k}" title="${t}">{{${k}}}</button>`).join(' ')}</p>
    <div data-list></div>
    <button type="button" class="btn ghost sm" data-add>+ بند جديد</button>
    ${newVer ? `<div class="field mt"><label>ما الذي عدّلته؟ ${delib ? '★ (يراه الأعضاء)' : ''}</label><input class="input" data-note placeholder="مثال: عُدّل البند 3 استجابة لتعليق الهيئة"></div>` : ''}
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-ok>${newVer ? 'حفظ نسخة جديدة' : 'حفظ'}</button></div></div></div>`;
  document.body.appendChild(bg);
  const close = () => bg.remove();
  bg.querySelector('.mdl-x').onclick = close; bg.querySelector('[data-x]').onclick = close;
  let focus = null;
  const list = bg.querySelector('[data-list]');
  const sync = () => list.querySelectorAll('.ip-cl').forEach((d, i) => { cl[i].title = d.querySelector('[data-ti]').value; cl[i].text = d.querySelector('[data-tx]').value; });
  const draw = () => {
    list.innerHTML = cl.map((c, i) => `<div class="ip-cl"><div class="row"><span class="sh-n num">${i + 1}</span><input class="input" data-ti value="${esc(c.title)}" placeholder="عنوان البند">
      <button type="button" class="btn ghost sm" data-up="${i}" ${i ? '' : 'disabled'} aria-label="أعلى">↑</button><button type="button" class="btn ghost sm" data-dn="${i}" ${i < cl.length - 1 ? '' : 'disabled'} aria-label="أسفل">↓</button>
      <button type="button" class="btn ghost sm" data-del="${i}" aria-label="حذف" style="color:var(--bad)">✕</button></div>
      <textarea class="input" data-tx rows="3" placeholder="نص البند">${esc(c.text)}</textarea></div>`).join('');
    list.querySelectorAll('[data-tx]').forEach(t => t.onfocus = () => { focus = t; });
    list.querySelectorAll('[data-up]').forEach(b => b.onclick = () => { sync(); const i = +b.dataset.up; [cl[i - 1], cl[i]] = [cl[i], cl[i - 1]]; draw(); });
    list.querySelectorAll('[data-dn]').forEach(b => b.onclick = () => { sync(); const i = +b.dataset.dn; [cl[i + 1], cl[i]] = [cl[i], cl[i + 1]]; draw(); });
    list.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { sync(); cl.splice(+b.dataset.del, 1); draw(); });
  };
  draw();
  bg.querySelectorAll('[data-var]').forEach(b => b.onclick = () => {
    if (!focus) return toast('اضغط داخل نص البند أولاً', 'bad');
    const v = `{{${b.dataset.var}}}`, s = focus.selectionStart ?? focus.value.length;
    focus.value = focus.value.slice(0, s) + v + focus.value.slice(focus.selectionEnd ?? s); focus.focus(); focus.selectionStart = focus.selectionEnd = s + v.length;
  });
  bg.querySelector('[data-add]').onclick = () => { sync(); cl.push({ title: '', text: '' }); draw(); list.lastElementChild?.querySelector('[data-ti]').focus(); };
  bg.querySelector('[data-ok]').onclick = async e => {
    sync(); e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'islamic_version_save', { p_id: P.id, p: { clauses: cl, change_note: bg.querySelector('[data-note]')?.value || '' } });
      close(); toast(`حُفظ نص العقد — النسخة ${r.n}${delib ? ' وصلت الهيئة' : ''}`, 'ok'); reload();
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}
