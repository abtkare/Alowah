// ألواح — خدمة الرسائل النصية (الجلسة 23). بلا حزم خارجية.
// تسحب الرسائل من الصندوق الصادر في قاعدة البيانات وترسلها عبر المزوّد المضبوط في Render، ثم تسجّل النتيجة.
//   رموز التحقق تُرسل فوراً، وإشعارات المقترض لا تُرسل ليلاً (من 10 مساءً إلى 8 صباحاً بتوقيت بغداد).
// المسارات:
//   GET|POST /api/sms/kick    تنبيه الخدمة لوجود رسائل جديدة (تستدعيه الصفحات بعد كل عملية)
//   GET      /api/sms/health  حالة الربط (دون أسرار)
//
// المزوّدون (يُختار بالمتغير SMS_PROVIDER، أو تلقائياً حسب المفاتيح الموجودة):
//   smsgate  — هاتف أندرويد بشريحة عراقية وتطبيق «SMS Gateway» (sms-gate.app): SMSGATE_USER, SMSGATE_PASS [, SMSGATE_URL]
//   otpiq    — مزوّد عراقي (otpiq.com): OTPIQ_API_KEY [, OTPIQ_SENDER_ID للإشعارات]
//   twilio   — TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM (رقم أو اسم مرسل أو MG… لخدمة المراسلة)
//   infobip  — INFOBIP_BASE_URL, INFOBIP_API_KEY [, INFOBIP_FROM]
//   webhook  — أي بوابة أخرى: SMS_WEBHOOK_URL [, SMS_WEBHOOK_TOKEN] — يُرسل إليها JSON {to, text, kind, code}

module.exports = function sms({ SUPABASE_URL, SUPABASE_ANON_KEY, DB_SECRET, PUBLIC_URL, env = process.env }) {
  const E = k => String(env[k] || '').trim();
  const PROVIDERS = {
    smsgate: { ok: () => E('SMSGATE_USER') && E('SMSGATE_PASS'), send: sendSmsGate },
    otpiq: { ok: () => E('OTPIQ_API_KEY'), send: sendOtpiq },
    twilio: { ok: () => E('TWILIO_SID') && E('TWILIO_TOKEN') && E('TWILIO_FROM'), send: sendTwilio },
    infobip: { ok: () => E('INFOBIP_BASE_URL') && E('INFOBIP_API_KEY'), send: sendInfobip },
    webhook: { ok: () => E('SMS_WEBHOOK_URL'), send: sendWebhook },
  };
  let NAME = E('SMS_PROVIDER').toLowerCase();
  if (!NAME) NAME = Object.keys(PROVIDERS).find(k => PROVIDERS[k].ok()) || '';
  const P = PROVIDERS[NAME] && PROVIDERS[NAME].ok() ? PROVIDERS[NAME] : null;
  const ST = { provider: P ? NAME : null, enabled: !!(P && DB_SECRET), sent: 0, failed: 0, last_ok: null, last_error: null, hello: null };
  if (NAME && !P) ST.last_error = `المزوّد «${NAME}» ينقصه بعض المتغيرات في Render`;
  if (!DB_SECRET) ST.last_error = 'لم يُضَف ESIGN_DB_SECRET إلى إعدادات الخادم — لا يمكن قراءة الصندوق الصادر';

  // ───────── الاتصال بقاعدة البيانات ─────────
  async function rpc(fn, args) {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: 'POST', headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(args), signal: AbortSignal.timeout(20_000),
    });
    const t = await r.text(); let j; try { j = t ? JSON.parse(t) : null; } catch { j = t; }
    if (!r.ok) throw new Error((j && (j.message || j.error)) || `rpc ${fn} ${r.status}`);
    return j;
  }

  // ───────── المزوّدون ─────────
  const e164 = p => '+964' + String(p).replace(/^0/, '');           // 07XXXXXXXXX ← +9647XXXXXXXXX
  async function post(url, { headers = {}, json, form }) {
    const r = await fetch(url, {
      method: 'POST', signal: AbortSignal.timeout(15_000),
      headers: { ...(json ? { 'Content-Type': 'application/json' } : {}), ...(form ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}), ...headers },
      body: json ? JSON.stringify(json) : form ? new URLSearchParams(form).toString() : undefined,
    });
    const t = await r.text(); let j; try { j = t ? JSON.parse(t) : {}; } catch { j = { raw: t.slice(0, 300) }; }
    if (!r.ok) throw new Error(`${r.status} ${(j && (j.message || j.error || j.raw)) || ''}`.slice(0, 300));
    return j;
  }
  async function sendSmsGate(m) {
    const base = (E('SMSGATE_URL') || 'https://api.sms-gate.app/3rdparty/v1').replace(/\/+$/, '');
    const auth = 'Basic ' + Buffer.from(`${E('SMSGATE_USER')}:${E('SMSGATE_PASS')}`).toString('base64');
    const j = await post(`${base}/messages`, { headers: { Authorization: auth }, json: { textMessage: { text: m.body }, phoneNumbers: [e164(m.phone)], ttl: m.kind === 'otp' ? 600 : 86400 } });
    return j.id || '';
  }
  async function sendOtpiq(m) {
    const H = { Authorization: `Bearer ${E('OTPIQ_API_KEY')}` }, to = e164(m.phone).slice(1);
    let body;
    if (m.kind === 'otp' && m.code) body = { phoneNumber: to, smsType: 'verification', verificationCode: String(m.code), provider: E('OTPIQ_CHANNEL') || 'sms' };
    else {
      if (!E('OTPIQ_SENDER_ID')) throw new Error('OTPIQ: الإشعارات تحتاج اسم مرسل معتمد (OTPIQ_SENDER_ID)');
      body = { phoneNumber: to, smsType: 'custom', customMessage: m.body, senderId: E('OTPIQ_SENDER_ID'), provider: 'sms' };
    }
    const j = await post('https://api.otpiq.com/api/sms', { headers: H, json: body });
    return j.smsId || '';
  }
  async function sendTwilio(m) {
    const sid = E('TWILIO_SID'), from = E('TWILIO_FROM');
    const form = { To: e164(m.phone), Body: m.body, ...(from.startsWith('MG') ? { MessagingServiceSid: from } : { From: from }) };
    const j = await post(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, { headers: { Authorization: 'Basic ' + Buffer.from(`${sid}:${E('TWILIO_TOKEN')}`).toString('base64') }, form });
    return j.sid || '';
  }
  async function sendInfobip(m) {
    const base = E('INFOBIP_BASE_URL').replace(/\/+$/, '').replace(/^(?!https?:\/\/)/, 'https://');
    const j = await post(`${base}/sms/2/text/advanced`, { headers: { Authorization: `App ${E('INFOBIP_API_KEY')}` },
      json: { messages: [{ destinations: [{ to: e164(m.phone).slice(1) }], text: m.body, ...(E('INFOBIP_FROM') ? { from: E('INFOBIP_FROM') } : {}) }] } });
    return (j.messages && j.messages[0] && j.messages[0].messageId) || '';
  }
  async function sendWebhook(m) {
    const j = await post(E('SMS_WEBHOOK_URL'), { headers: E('SMS_WEBHOOK_TOKEN') ? { Authorization: `Bearer ${E('SMS_WEBHOOK_TOKEN')}` } : {},
      json: { to: e164(m.phone), phone: m.phone, text: m.body, kind: m.kind, code: m.kind === 'otp' ? m.code : undefined } });
    return String(j.id || j.messageId || '');
  }

  // ───────── الحلقة ─────────
  let running = false, again = false;
  async function drain() {
    if (!ST.enabled) return;
    if (running) { again = true; return; }
    running = true;
    try {
      for (let round = 0; round < 10; round++) {
        const list = await rpc('sms_claim', { p_secret: DB_SECRET, p_limit: 20 });
        if (!Array.isArray(list) || !list.length) break;
        for (const m of list) {
          try {
            const id = await P.send(m);
            ST.sent++; ST.last_ok = new Date().toISOString();
            await rpc('sms_mark', { p_secret: DB_SECRET, p_id: m.id, p_ok: true, p_provider: NAME, p_provider_id: String(id || ''), p_error: null });
          } catch (e) {
            ST.failed++; ST.last_error = String(e.message || e).slice(0, 300);
            console.error('[sms] فشل الإرسال', m.id, ST.last_error);
            await rpc('sms_mark', { p_secret: DB_SECRET, p_id: m.id, p_ok: false, p_provider: NAME, p_provider_id: null, p_error: ST.last_error }).catch(() => {});
          }
        }
      }
    } catch (e) { ST.last_error = String(e.message || e).slice(0, 300); console.error('[sms]', ST.last_error); }
    running = false;
    if (again) { again = false; setTimeout(drain, 200); }
  }
  async function hello() {
    if (!DB_SECRET) return;
    try { await rpc('sms_hello', { p_secret: DB_SECRET, p_provider: ST.enabled ? NAME : '', p_public_url: PUBLIC_URL || '' }); ST.hello = new Date().toISOString(); }
    catch (e) { ST.last_error = 'sms_hello: ' + String(e.message || e).slice(0, 200); }
  }
  async function sweep() { if (ST.enabled) { try { await rpc('sms_sweep', { p_secret: DB_SECRET }); } catch (e) { console.error('[sms] sweep', e.message); } drain(); } }

  function start() {
    console.log('[sms]', ST.enabled ? `المزوّد: ${NAME}` : `غير مفعّل${ST.last_error ? ' — ' + ST.last_error : ' (لا مزوّد في Render)'}`);
    hello().then(() => { drain(); sweep(); });
    setInterval(drain, 15_000).unref();
    setInterval(hello, 6 * 3600_000).unref();
    setInterval(sweep, 3600_000).unref();
  }

  let lastKick = 0;
  function handle(req, res, p) {
    if (p === '/api/sms/kick') {
      if (Date.now() - lastKick > 1000) { lastKick = Date.now(); setTimeout(drain, 300); }
      res.writeHead(204, { 'Cache-Control': 'no-store' }); res.end(); return true;
    }
    if (p === '/api/sms/health') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(ST)); return true;
    }
    return false;
  }
  return { start, handle, drain, state: ST };
};
