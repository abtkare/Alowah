// تصوير البطاقة الوطنية وقراءتها تلقائياً عبر خدمة loan-ocr (على سيرفر المنصة الخاص)
// الكاميرا تملأ الشاشة، ولا التقاط إلا بعد اكتشاف البطاقة نفسها داخل المستطيل، ثم أوضح إطار خلال ≤5 ثوانٍ:
// وجه البطاقة ← «اقلب البطاقة» ← ظهرها ← القراءة. لا يُقبل اختيار صورة من المعرض.
import { esc, GOVS } from './core.js';

const OCR = () => ((window.ALWAH_CONFIG || {}).ocr || '').replace(/\/+$/, '');
export const ocrEnabled = () => !!OCR();

const CARD = 1.586;        // نسبة عرض البطاقة إلى ارتفاعها
const PAD = 0.06;          // هامش حول الإطار تُكتشف فيه حواف البطاقة
const TARGET_MS = 15000;   // زمن القراءة المتوقع
const HARD_MS = 45000;     // أقصى انتظار قبل طلب إعادة المحاولة
const TICK = 100;            // تحليل 10 إطارات في الثانية
// قواعد الالتقاط (الجلسة 8):
// ١) لا شيء يُلتقط ما لم تُكتشف البطاقة نفسها داخل الإطار (حواف مستقيمة + تباين مع الخلفية + كتابة)
// ٢) بعد اكتشافها نجمع الإطارات ونختار أوضحها، والالتقاط يتم بين ثانيتين و5 ثوانٍ من ظهورها
// ٣) إن لم تكن الصورة واضحة يقترح النظام إعادة الالتقاط
const PRESENT_MS = 1500;    // يجب أن تبقى البطاقة مكتشفة هذه المدة على الأقل قبل الالتقاط
const COLLECT_MS = 2200;    // نافذة اختيار أوضح إطار بعد ظهور البطاقة
const MAX_MS = 5000;        // أقصى مدة من ظهور البطاقة إلى الالتقاط
const LOST_MS = 600;        // إن غابت البطاقة أكثر من هذا يبدأ العد من جديد
const MANUAL_AFTER = 6000;  // الزر اليدوي يظهر بعدها، ولا يعمل إلا والبطاقة داخل الإطار
const MIN_SHARP_HI = 40;    // أدنى حدة لحواف الكتابة في الصورة النهائية (مقياس 0–1020)، وإلا يُقترح إعادة الالتقاط

// ───────── تحليل إطار الفيديو (دالة نقية تُختبر خارج المتصفح) ─────────
// g: تدرج رمادي Uint8 بطول w*h لمنطقة الإطار مع الهامش. pad: الهامش بالبكسل
export function analyzeFrame(g, w, h, pad, side = 'front') {
  const at = (x, y) => g[y * w + x];
  pad = Math.max(3, Math.round(pad));
  let sum = 0, glare = 0;
  for (let i = 0; i < g.length; i++) { sum += g[i]; if (g[i] >= 250) glare++; }
  const mean = sum / g.length, glareFrac = glare / g.length;
  // ── وجود البطاقة ──
  // حافة البطاقة خط مستقيم متصل يمتد على طول الجانب. نبحث في شريط حول حافة الإطار
  // عن عمود (أو صف) يتغير فيه السطوع بالاتجاه نفسه في أغلب نقاطه.
  // الأرضية والجدار والقماش تعطي تدرجات متفرقة لا تُكوّن خطاً، فلا تُحتسب.
  const band = Math.max(4, Math.round(pad * 2.2));
  const GT = 16;
  // يتحمل ميلاً حتى ~8 درجات: نأخذ في كل صف أقوى تغيّر داخل الشريط، ثم نبحث عن خط مستقيم يمر بأكثرها
  const fitLine = pts => { if (pts.length < 6) return { c: 0, at: -1 };
    let best = 0, bat = -1;
    for (let sl = -0.15; sl <= 0.151; sl += 0.01) {
      const vals = pts.map(([t, u]) => u - sl * t).sort((a, b) => a - b);
      for (let i = 0, j = 0; i < vals.length; i++) { while (vals[i] - vals[j] > 3) j++; if (i - j + 1 > best) { best = i - j + 1; bat = Math.round(vals[j] + sl * pts[pts.length >> 1][0]); } }
    }
    return { c: best, at: bat }; };
  const edgeLine = (vertical, u0, u1) => {
    const ts = [], pos = [], neg = [];
    const tA = Math.round((vertical ? h : w) * .12), tB = (vertical ? h : w) * .88;
    let n = 0;
    for (let t = tA; t < tB; t += 2) { n++; let bp = 0, bpu = -1, bn = 0, bnu = -1;
      for (let u = Math.max(2, u0); u < Math.min((vertical ? w : h) - 2, u1); u++) {
        const d = vertical ? at(u + 1, t) + at(u + 2, t) - at(u - 1, t) - at(u - 2, t) : at(t, u + 1) + at(t, u + 2) - at(t, u - 1) - at(t, u - 2);
        if (d > bp) { bp = d; bpu = u; } if (-d > bn) { bn = -d; bnu = u; } }
      if (bp > GT * 2) pos.push([t, bpu]); if (bn > GT * 2) neg.push([t, bnu]); }
    const a = fitLine(pos), b = fitLine(neg), r = a.c >= b.c ? a : b;
    return { c: n ? r.c / n : 0, at: r.at };
  };
  const lineCol = (x0, x1) => edgeLine(true, x0, x1);
  const lineRow = (y0, y1) => edgeLine(false, y0, y1);
  const L = [lineCol(0, band), lineCol(w - band, w), lineRow(0, band), lineRow(h - band, h)];
  const edges = L.map(e => e.c), edgeCount = edges.filter(c => c >= 0.55).length;
  // تباين داخل/خارج: متوسط الشريط الخارجي (خارج خط الحافة) مقابل الشريط الداخلي
  const meanRect = (x0, y0, x1, y1) => { let s = 0, n = 0; x0 = Math.max(0, x0 | 0); y0 = Math.max(0, y0 | 0); x1 = Math.min(w, x1 | 0); y1 = Math.min(h, y1 | 0);
    for (let y = y0; y < y1; y += 2) for (let x = x0; x < x1; x += 2) { s += at(x, y); n++; } return n ? s / n : 0; };
  const k = 3;
  // [خارج, داخل] لكل جانب
  const io = [
    L[0].at > k ? [meanRect(0, h * .2, L[0].at - 1, h * .8), meanRect(L[0].at + 2, h * .2, L[0].at + 2 + band, h * .8)] : [0, 0],
    L[1].at > 0 && L[1].at < w - k ? [meanRect(L[1].at + 2, h * .2, w, h * .8), meanRect(L[1].at - 1 - band, h * .2, L[1].at - 1, h * .8)] : [0, 0],
    L[2].at > k ? [meanRect(w * .2, 0, w * .8, L[2].at - 1), meanRect(w * .2, L[2].at + 2, w * .8, L[2].at + 2 + band)] : [0, 0],
    L[3].at > 0 && L[3].at < h - k ? [meanRect(w * .2, L[3].at + 2, w * .8, h), meanRect(w * .2, L[3].at - 1 - band, w * .8, L[3].at - 1)] : [0, 0],
  ];
  const contrast = io.map(([o, i]) => Math.abs(o - i));
  // البطاقة الوطنية فاتحة اللون: الشريط الداخلي المجاور لكل حافة يجب أن يكون من أفتح ما في الصورة.
  // هذا يرفض كتاباً أو حافظة أو سطحاً داكناً يملأ الإطار وبداخله بطاقة صغيرة بعيدة.
  const hist = new Uint32Array(256); for (let i = 0; i < g.length; i += 3) hist[g[i]]++;
  let acc = 0, p90 = 255; const lim = (g.length / 3) * 0.9; for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= lim) { p90 = v; break; } }
  const sidesOk = edges.map((c, i) => c >= 0.55 && contrast[i] >= 10 && io[i][1] >= Math.max(90, p90 * 0.6));
  const strongSides = sidesOk.filter(Boolean).length;
  // الحواف المتقابلة يجب أن تكون موجودة معاً (يمين+يسار أو أعلى+أسفل) — وإلا فالجسم خارج الإطار جزئياً
  const pairs = (sidesOk[0] && sidesOk[1]) + (sidesOk[2] && sidesOk[3]);
  // محتوى البطاقة: كتابة وصورة ⇐ تباين داخلي معتدل وتدرجات كثيرة صغيرة الحجم
  let s2 = 0, s1 = 0, n2 = 0, lap = 0, txt = 0;
  for (let y = band + 2; y < h - band - 2; y += 2) for (let x = band + 2; x < w - band - 2; x += 2) {
    const v = at(x, y); s1 += v; s2 += v * v; n2++;
    const l = Math.abs(4 * v - at(x - 1, y) - at(x + 1, y) - at(x, y - 1) - at(x, y + 1)); lap += l; if (l > 40) txt++;
  }
  const inMean = n2 ? s1 / n2 : 0, std = n2 ? Math.sqrt(Math.max(0, s2 / n2 - inMean * inMean)) : 0;
  const sharp = n2 ? lap / n2 : 0, textFrac = n2 ? txt / n2 : 0;
  const content = std >= 18 && textFrac <= 0.45;   // الوثيقة كاملة الكتابة (صفحة) لا تُعدّ بطاقة
  const present = strongSides >= 3 && pairs >= 1 && content;
  // الظهر: شريط الأحرف السفلي يعطي طاقة نصية عالية في الثلث الأسفل
  let mrz = 0;
  if (side === 'back') { let s = 0, n = 0; for (let y = Math.round(h * .62); y < h - band; y++) for (let x = band; x < w - band - 1; x += 2) { s += Math.abs(at(x + 1, y) - at(x, y)); n++; } mrz = n ? s / n : 0; }
  let msg = '', ok = false;
  if (mean < 50) msg = 'الإضاءة ضعيفة — انتقل إلى مكان أكثر إضاءة';
  else if (!present) msg = strongSides >= 2 ? 'اجعل البطاقة مستقيمة وقرّبها حتى تملأ الإطار وتظهر حوافها الأربع' : 'لا توجد بطاقة داخل الإطار — ضع البطاقة داخل المستطيل';
  else if (glareFrac > 0.08) msg = 'يوجد انعكاس ضوء على البطاقة — أمِلها قليلاً أو ابتعد عن الضوء المباشر';
  else if (sharp < 5 || textFrac < 0.015) msg = 'الصورة غير واضحة — قرّب الهاتف قليلاً أو أبعده حتى تتضح الكتابة';
  else if (side === 'back' && mrz < 7) msg = 'اقلب البطاقة: نحتاج الوجه الخلفي مع الشريط السفلي';
  else { ok = true; msg = 'البطاقة داخل الإطار — ثبّت يدك…'; }
  return { ok, present, msg, mean, glareFrac, edges, contrast, edgeCount, strongSides, pairs, std, textFrac, sharp, mrz };
}

// حدة صورة كاملة (للتحقق من الصورة النهائية عالية الدقة):
// متوسط أعلى 2% من قيم لابلاس — يقيس حدّة حواف الكتابة ولا يتأثر بتشويش الكاميرا
export function sharpness(g, w, h) {
  const hist = new Uint32Array(1021); let n = 0; const m = Math.round(Math.min(w, h) * 0.08);
  for (let y = m; y < h - m; y += 2) for (let x = m; x < w - m; x += 2) { const i = y * w + x; hist[Math.min(1020, Math.abs(4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]))]++; n++; }
  let need = Math.max(1, Math.round(n * 0.02)), s = 0, c = 0;
  for (let v = 1020; v >= 0 && c < need; v--) { const t = Math.min(hist[v], need - c); s += t * v; c += t; }
  return c ? s / c : 0;
}

const diff = (a, b) => { if (!a || a.length !== b.length) return 255; let s = 0; for (let i = 0; i < a.length; i += 3) s += Math.abs(a[i] - b[i]); return s / (a.length / 3); };

// ───────── قراءة البيانات من الخادم ─────────
const VAL = f => k => { const x = f[k]; return x && typeof x === 'object' ? (x.value ?? '') : (x ?? ''); };
const pick = (v, ...ks) => { for (const k of ks) { const s = String(v(k) || '').trim(); if (s) return s; } return ''; };
const isoDate = s => { s = String(s || '').trim().replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  let m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; return ''; };
const normAr = s => String(s || '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ').trim();

// مطابقة مكان الولادة مع قائمة المحافظات («النجف-النجف»، «بغداد / الكرخ»…)
export function matchGov(place) {
  if (!place) return '';
  const p = normAr(place);
  const hit = GOVS.find(([g]) => { const n = normAr(g); return p.includes(n) || p.includes(n.replace(/^ال/, '')); });
  if (hit) return hit[0];
  const alias = [['قادسيه', 'الديوانية'], ['ناصريه', 'ذي قار'], ['موصل', 'نينوى'], ['رمادي', 'الأنبار'], ['حله', 'بابل'], ['كوت', 'واسط'], ['عماره', 'ميسان'], ['سماوه', 'المثنى'], ['بعقوبه', 'ديالى'], ['تكريت', 'صلاح الدين'], ['اربيل', 'أربيل'], ['سليمانيه', 'السليمانية']];
  const a = alias.find(([k]) => p.includes(k)); return a ? a[1] : '';
}

// تقسيم الاسم إلى: الاسم، الأب، الجد، اللقب (الأسماء المركبة «عبد …» و«… الدين» تبقى كلمة واحدة)
export function splitName(full) {
  const raw = String(full || '').replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
  const t = [];
  for (let i = 0; i < raw.length; i++) {
    const w = raw[i];
    if (/^(عبد|عبدال|ابو|أبو)$/.test(w) && raw[i + 1]) { t.push(w + ' ' + raw[++i]); continue; }
    if (/^(الدين|الله)$/.test(w) && t.length && !/^(عبد|ابو|أبو)\s/.test(t[t.length - 1])) { t[t.length - 1] += ' ' + w; continue; }
    t.push(w);
  }
  const r = { first: t[0] || '', father: t[1] || '', grand: '', fourth: '', surname: '' };
  if (t.length === 3) { if (/^ال/.test(t[2])) r.surname = t[2]; else r.grand = t[2]; }
  else if (t.length === 4) { r.grand = t[2]; r.surname = t[3]; }
  else if (t.length >= 5) { r.grand = t[2]; r.fourth = t.slice(3, -1).join(' '); r.surname = t[t.length - 1]; }
  return r;
}

// اسم الأم: البطاقة تحمل «الأم» و«الجد» (والدها)؛ الجزء الثالث (جدها) يُكتب يدوياً
function motherParts(v, f) {
  const full = pick(v, 'mother_full_name', 'mother_name_full');
  let m1 = pick(v, 'mother_name', 'mother_first_name', 'mother');
  let m2 = pick(v, 'mother_father_name', 'mother_father', 'maternal_grandfather', 'mother_grandfather_name', 'mother_grand_father', 'mother_grandfather');
  let m3 = pick(v, 'mother_grandfather_name2', 'mother_great_grandfather', 'mother_surname');
  // إن جاء الاسم مركباً في حقل واحد نقسّمه (مع إبقاء «عبد …» كلمة واحدة)
  const src = full || (m1 && !m2 && m1.trim().split(/\s+/).length > 1 ? m1 : '');
  if (src) { const t = splitName(src); m1 = t.first; m2 = t.father || m2; m3 = t.grand || t.surname || m3; }
  return { mother: [m1, m2, m3].filter(Boolean).join(' '), motherParts: { m1, m2, m3 } };
}

// ───────── التحقق المتقاطع مع الشريط السفلي (MRZ) ─────────
// نحوّل الاسم العربي واللاتيني إلى «هيكل ساكن» ونقارن؛ يكشف حقلاً قرأه الخادم من سطر خاطئ
const AR_MAP = { 'ب': 'b', 'ت': 't', 'ث': 't', 'ط': 't', 'ج': 'j', 'ح': 'h', 'خ': 'k', 'ه': 'h', 'د': 'd', 'ذ': 'd', 'ض': 'd', 'ظ': 'd', 'ر': 'r', 'ز': 'z', 'س': 's', 'ش': 's', 'ص': 's', 'غ': 'g', 'ف': 'f', 'ق': 'k', 'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n' };
export const skelAr = s => [...String(s || '').replace(/\s+/g, '')].map(c => AR_MAP[c] || '').join('').replace(/(.)\1+/g, '$1');
export const skelLat = s => String(s || '').toLowerCase().replace(/[^a-z]/g, '').replace(/ah$/, 'a').replace(/kh/g, 'k').replace(/gh/g, 'g').replace(/sh/g, 's').replace(/th/g, 't').replace(/dh/g, 'd')
  .replace(/q/g, 'k').replace(/c/g, 'k').replace(/[aeiouyw]/g, '').replace(/(.)\1+/g, '$1');
const lev = (a, b) => { const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; };
const near = (a, b) => a && b && (a === b || (Math.min(a.length, b.length) >= 3 && lev(a, b) <= 1));
// يعيد { حقل: سبب } للحقول المشكوك فيها، و latinFirst (الاسم الأول في الشريط) للمساعدة
export function crossCheck(parts, latin, warnings = []) {
  const flags = {};
  const toks = String(latin || '').toUpperCase().split(/[^A-Z]+/).filter(t => t.length >= 2);
  const sk = toks.map(skelLat);
  const used = new Set();
  const match = k => { const a = skelAr(parts[k].replace(/^ال/, '')); const sa = skelAr(parts[k]);
    const i = sk.findIndex((x, n) => !used.has(n) && (near(x, a) || near(x, sa))); if (i >= 0) used.add(i); return i >= 0; };
  if (toks.length >= 3) {
    for (const k of ['surname', 'grand', 'father', 'first']) if (parts[k] && !match(k)) flags[k] = 'لا يطابق الاسم في الشريط السفلي للبطاقة';
    const left = toks.filter((_, n) => !used.has(n));
    if (flags.first && left.length) flags.first += ` (فيه: ${left.join(' ')})`;
  }
  // اسمان متطابقان متتاليان نادر جداً — غالباً قُرئ السطر نفسه مرتين
  if (parts.first && parts.first === parts.father && !flags.first) flags.first = 'مطابق لاسم الأب — تأكد أنه قُرئ من سطر «الاسم»';
  const lab = { 'الاسم': 'first', 'الأب': 'father', 'اسم الأب': 'father', 'الجد': 'grand', 'اسم الجد': 'grand', 'اللقب': 'surname', 'الأم': 'm1', 'اسم الأم': 'm1' };
  for (const w of warnings) { const m = String(w).match(/\(([^)]+)\)/); const k = m && lab[m[1].trim()]; if (k && !flags[k]) flags[k] = 'لم يُقرأ بوضوح من البطاقة'; }
  return flags;
}

export function parseIdResponse(data) {
  const f = data.fields || data.data || {}; const v = VAL(f);
  const full = pick(v, 'full_name', 'name_ar', 'name');
  const parts = splitName(full);
  const first = pick(v, 'first_name', 'given_name'), father = pick(v, 'father_name'), grand = pick(v, 'grandfather_name', 'grand_father_name');
  const surname = pick(v, 'surname', 'family_name', 'last_name', 'tribe', 'laqab', 'title_name');
  if (first) parts.first = first; if (father) parts.father = father; if (grand) parts.grand = grand; if (surname) parts.surname = surname;
  const nid = String(pick(v, 'national_id_number', 'national_id', 'personal_number')).replace(/\D/g, '');
  const place = pick(v, 'place_of_birth', 'birth_place', 'pob');
  const g = pick(v, 'gender', 'sex').toLowerCase();
  const conf = k => { const x = f[k]; return x && typeof x === 'object' ? Number(x.confidence ?? 1) : 1; };
  return {
    parts, name: full,
    nid: nid.length === 12 ? nid : '',
    bd: isoDate(pick(v, 'date_of_birth', 'birth_date', 'dob')),
    place, gov: matchGov(place),
    ...motherParts(v, f),
    gender: /^(m|male|ذكر)/.test(g) ? 'male' : /^(f|female|انثى|أنثى)/.test(g) ? 'female' : '',
    cardNo: pick(v, 'card_number', 'document_number'), expiry: isoDate(pick(v, 'expiry_date', 'date_of_expiry')),
    issue: isoDate(pick(v, 'issue_date', 'date_of_issue')), issuer: pick(v, 'issuer', 'issuing_authority'),
    family: pick(v, 'family_number', 'family_no'), blood: pick(v, 'blood_type', 'blood_group'), latin: pick(v, 'name_latin', 'name_en', 'mrz_name'),
    warnings: data.warnings || [], verified: !!data.mrz_verified,
    weak: [['full_name', 'الاسم'], ['national_id_number', 'الرقم الوطني'], ['date_of_birth', 'تاريخ الميلاد']].filter(([k]) => f[k] && v(k) && conf(k) < 0.8).map(([, l]) => l),
    keys: Object.keys(f),
  };
}
export function parseAndCheck(data) { const r = parseIdResponse(data); r.flags = crossCheck(r.parts, r.latin, r.warnings); return r; }

export async function readNationalId(front, back, onSlow) {
  const body = new FormData();
  if (front) body.append('front', front, 'front.jpg');
  if (back) body.append('back', back, 'back.jpg');
  const ctl = new AbortController();
  const slow = setTimeout(() => onSlow && onSlow(), TARGET_MS);
  const t = setTimeout(() => ctl.abort(), HARD_MS);
  let res;
  try { res = await fetch(OCR() + '/api/v1/documents/national-id', { method: 'POST', body, signal: ctl.signal }); }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'استغرقت القراءة وقتاً طويلاً — أعد المحاولة' : 'تعذر الاتصال بخدمة قراءة البطاقة، تحقق من الإنترنت'); }
  finally { clearTimeout(t); clearTimeout(slow); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data.error && data.error.message) || 'تعذرت قراءة البطاقة');
  return parseAndCheck(data);
}

// ───────── الكاميرا الكاملة بالالتقاط التلقائي ─────────
// تعيد { front, back } (Blob لكل وجه) أو null عند الإغلاق
function autoCapture() {
  return new Promise(resolve => {
    const bg = document.createElement('div');
    bg.className = 'cam idcam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <div class="cam-frame"><i></i><i></i><i></i><i></i><b class="cam-prog"></b></div>
      <div class="cam-top"><button type="button" class="cam-x" aria-label="إغلاق">✕</button><span class="cam-step"></span></div>
      <p class="cam-hint"><span data-t></span><small data-s></small></p>
      <div class="cam-flip" hidden><div class="flipcard"><i></i></div><b>✓ تم تصوير وجه البطاقة</b><span>اقلب البطاقة الآن على الوجه الخلفي</span></div>
      <div class="cam-review" hidden><img alt=""><b data-rt></b><span data-rs></span><div class="row"><button type="button" class="btn cyan" data-retake>إعادة الالتقاط</button><button type="button" class="btn ghost" data-use>استخدام الصورة</button></div></div>
      <div class="cam-bar"><button type="button" class="cam-shoot" hidden aria-label="التقاط يدوي"></button></div>`;
    document.body.appendChild(bg);
    document.documentElement.classList.add('noscroll');
    const video = bg.querySelector('video'), frame = bg.querySelector('.cam-frame'), prog = bg.querySelector('.cam-prog');
    const T = bg.querySelector('[data-t]'), Sm = bg.querySelector('[data-s]'), stepEl = bg.querySelector('.cam-step'), shoot = bg.querySelector('.cam-shoot');
    const work = document.createElement('canvas'), wctx = work.getContext('2d', { willReadFrequently: true });
    const shots = {}; let side = 'front', stream = null, timer = 0, prev = null, sideAt = 0, closed = false, busy = false;
    // الالتقاط الذكي: يبدأ العدّ فقط حين تُكتشف البطاقة نفسها داخل الإطار، ثم نختار أوضح إطار خلال ثانيتين تقريباً (حد أقصى 5 ثوانٍ)
    let seenAt = 0, lastSeen = 0, goodN = 0, best = null, lastA = null; const hiA = document.createElement('canvas'), hiB = document.createElement('canvas');
    const review = bg.querySelector('.cam-review');
    const finish = v => { if (closed) return; closed = true; clearInterval(timer); stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); document.documentElement.classList.remove('noscroll'); resolve(v); };
    bg.querySelector('.cam-x').onclick = () => finish(null);

    const setSide = s => {
      side = s; prev = null; sideAt = Date.now(); seenAt = 0; lastSeen = 0; goodN = 0; best = null; lastA = null; shoot.hidden = true; prog.style.width = '0%';
      stepEl.textContent = s === 'front' ? '١ من ٢ — وجه البطاقة' : '٢ من ٢ — ظهر البطاقة';
      T.textContent = s === 'front' ? 'ضع وجه البطاقة (الصورة والاسم) داخل الإطار' : 'ضع ظهر البطاقة داخل الإطار والشريط السفلي ظاهر';
      Sm.textContent = 'تُلتقط وحدها خلال ثوانٍ حين نكتشفها داخل المستطيل. ضعها على سطح داكن وأخرجها من الغلاف';
    };
    // منطقة الإطار في إحداثيات الفيديو
    const region = (padK = PAD) => {
      const VW = video.videoWidth, VH = video.videoHeight; if (!VW) return null;
      const vr = video.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      const k = Math.max(vr.width / VW, vr.height / VH);
      const x0 = vr.left + (vr.width - VW * k) / 2, y0 = vr.top + (vr.height - VH * k) / 2, p = padK * fr.width;
      let sx = (fr.left - p - x0) / k, sy = (fr.top - p - y0) / k, sw = (fr.width + 2 * p) / k, sh = (fr.height + 2 * p) / k;
      sx = Math.max(0, sx); sy = Math.max(0, sy); sw = Math.min(VW - sx, sw); sh = Math.min(VH - sy, sh);
      return { sx, sy, sw, sh, padPx: p / k };
    };
    // نسخة عالية الدقة من الإطار الحالي (بلا ضغط) — تُضغط مرة واحدة عند الالتقاط
    const grabHi = c => {
      const R = region(0.03); if (!R) return false;
      const s = Math.min(1, 2000 / R.sw);
      c.width = Math.round(R.sw * s); c.height = Math.round(R.sh * s);
      c.getContext('2d').drawImage(video, R.sx, R.sy, R.sw, R.sh, 0, 0, c.width, c.height);
      return true;
    };
    // فحص الصورة النهائية عالية الدقة: إن لم تكن واضحة يُقترح إعادة الالتقاط
    const hiCheck = c => {
      const W = 640, H = Math.round(W * c.height / c.width), t = document.createElement('canvas'); t.width = W; t.height = H;
      const x = t.getContext('2d', { willReadFrequently: true }); x.drawImage(c, 0, 0, W, H);
      const px = x.getImageData(0, 0, W, H).data, g = new Uint8Array(W * H);
      for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = (px[i] * 77 + px[i + 1] * 150 + px[i + 2] * 29) >> 8;
      return sharpness(g, W, H);
    };
    const advance = () => {
      if (side === 'front') {
        const fl = bg.querySelector('.cam-flip'); fl.hidden = false;
        setTimeout(() => { if (closed) return; fl.hidden = true; setSide('back'); timer = setInterval(tick, TICK); }, 1600);
      } else finish(shots);
    };
    const take = async canvas => {
      if (busy || !canvas) return; busy = true; clearInterval(timer);
      const sh = hiCheck(canvas);
      const b = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.93)); busy = false;
      if (!b) { timer = setInterval(tick, TICK); return; }
      if (navigator.vibrate) navigator.vibrate(60);
      frame.classList.add('snap'); setTimeout(() => frame.classList.remove('snap'), 350);
      if (sh < MIN_SHARP_HI) {
        // الصورة غير واضحة بما يكفي لقراءة البيانات — نقترح الإعادة ونعرضها
        review.hidden = false; review.querySelector('img').src = URL.createObjectURL(b);
        review.querySelector('[data-rt]').textContent = 'الصورة غير واضحة بما يكفي';
        review.querySelector('[data-rs]').textContent = 'نقترح إعادة الالتقاط: ثبّت الهاتف وأبعد البطاقة عن الضوء المباشر حتى تتضح الكتابة.';
        review.querySelector('[data-retake]').onclick = () => { review.hidden = true; setSide(side); timer = setInterval(tick, TICK); };
        review.querySelector('[data-use]').onclick = () => { review.hidden = true; shots[side] = b; shots[side + 'Sharp'] = sh; advance(); };
        return;
      }
      shots[side] = b; shots[side + 'Sharp'] = sh; advance();
    };
    // الزر اليدوي لا يلتقط إلا إذا كانت البطاقة مكتشفة الآن داخل الإطار
    shoot.onclick = () => {
      if (!lastA || !lastA.present || Date.now() - lastSeen > 300) { T.textContent = 'لا توجد بطاقة داخل الإطار — ضعها داخل المستطيل أولاً'; return; }
      if (best) return take(best.c);
      if (grabHi(hiA)) take(hiA);
    };
    const tick = () => {
      if (busy || !video.videoWidth) return;
      const R = region(); if (!R) return;
      const W = 320, H = Math.round(W * R.sh / R.sw);
      work.width = W; work.height = H;
      wctx.drawImage(video, R.sx, R.sy, R.sw, R.sh, 0, 0, W, H);
      const px = wctx.getImageData(0, 0, W, H).data, gray = new Uint8Array(W * H);
      for (let i = 0, j = 0; j < gray.length; i += 4, j++) gray[j] = (px[i] * 77 + px[i + 1] * 150 + px[i + 2] * 29) >> 8;
      const a = analyzeFrame(gray, W, H, R.padPx * W / R.sw, side); lastA = a;
      const motion = diff(prev, gray); prev = gray;
      const now = Date.now();
      // ١) وجود البطاقة: بدونها لا عدّ ولا التقاط مهما طال الوقت
      if (a.present) { if (!seenAt || now - lastSeen > LOST_MS) { seenAt = now; goodN = 0; best = null; } lastSeen = now; }
      else if (seenAt && now - lastSeen > LOST_MS) { seenAt = 0; goodN = 0; best = null; }
      const ok = a.ok && motion < 22;
      // ٢) أثناء وجودها: نحتفظ بأوضح إطار عالي الدقة
      if (seenAt && ok) {
        goodN++;
        const score = a.sharp - motion * 0.35 - a.glareFrac * 100;
        if (!best || score > best.score) { const c = best && best.c === hiA ? hiB : hiA; if (grabHi(c)) best = { c, score, sharp: a.sharp }; }
      }
      const el = seenAt ? now - seenAt : 0;
      T.textContent = !a.present ? a.msg : !a.ok ? a.msg : motion >= 22 ? 'ثبّت يدك قليلاً' : 'البطاقة داخل الإطار — جارِ اختيار أوضح صورة…';
      frame.classList.toggle('good', a.present && ok);
      prog.style.width = (seenAt ? Math.min(100, el / COLLECT_MS * 100) : 0) + '%';
      // ٣) الالتقاط: بعد ثبوت وجودها ونافذة الاختيار، أو عند بلوغ 5 ثوانٍ بأفضل ما جُمع
      if (seenAt && best && el >= PRESENT_MS && ((el >= COLLECT_MS && goodN >= 6) || el >= MAX_MS)) { take(best.c); return; }
      if (seenAt && el >= MAX_MS && !best) { T.textContent = 'البطاقة ظاهرة لكن الصورة غير واضحة — ' + a.msg; Sm.textContent = 'حسّن الإضاءة أو ثبّت الهاتف، والالتقاط يتم وحده حين تتضح.'; }
      if (now - sideAt > MANUAL_AFTER && shoot.hidden) { shoot.hidden = false; Sm.textContent = 'يمكنك الضغط على الزر — يعمل فقط حين تكون البطاقة داخل المستطيل'; }
    };
    const fit = () => { const w = Math.min(innerWidth * 0.92, innerHeight * 0.5 * CARD, 620); frame.style.width = w + 'px'; frame.style.height = w / CARD + 'px'; };
    fit(); addEventListener('resize', fit);
    setSide('front');
    (navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      ? navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 2560 }, height: { ideal: 1440 } }, audio: false })
      : Promise.reject())
      .then(st => {
        stream = st; video.srcObject = st;
        const tr = st.getVideoTracks()[0];
        try { tr.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {}); } catch { /* غير مدعوم */ }
        timer = setInterval(tick, TICK);
      })
      .catch(() => { T.textContent = 'تعذر فتح الكاميرا'; Sm.textContent = 'اسمح للموقع باستخدام الكاميرا من إعدادات المتصفح ثم أعد المحاولة. لا يُقبل اختيار صورة من المعرض حمايةً لبياناتك.'; });
  });
}

// ───────── واجهة الخطوة ─────────
export function mountIdScan(root, { onResult, onSkip, onBack, errBox }) {
  root.innerHTML = `<h2>صوّر بطاقتك الوطنية</h2>
    <p class="sub">نقرأ بياناتك ونتحقق منها تلقائياً لفتح حسابك المصرفي. تفتح الكاميرا على كامل الشاشة وتلتقط البطاقة وحدها حين تكون واضحة.</p>
    ${errBox('')}
    <ol class="idhow"><li><b>وجه البطاقة</b><span>ضعه داخل المستطيل — يُلتقط وحده خلال ثوانٍ حين نكتشفه</span></li><li><b>اقلب البطاقة</b><span>نلتقط الظهر مع الشريط السفلي</span></li><li><b>القراءة والتحقق</b><span>خلال ثوانٍ تُملأ بياناتك</span></li></ol>
    <div class="idtips small muted">• أخرج البطاقة من الغلاف البلاستيكي &nbsp;• ضعها على سطح داكن &nbsp;• تجنّب الشمس المباشرة والانعكاس</div>
    <div class="idbusy" hidden><i></i><span data-busy>جارِ قراءة البطاقة والتحقق منها…</span></div>
    <div class="idprev" hidden></div>
    <button class="btn cyan block" type="button" data-start>ابدأ تصوير البطاقة</button>
    <div class="row mt"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button type="button" class="linkbtn" data-skip>الإدخال يدوياً بدلاً من ذلك</button></div>`;
  const btn = root.querySelector('[data-start]'), busy = root.querySelector('.idbusy'), busyT = root.querySelector('[data-busy]'), prevBox = root.querySelector('.idprev');
  const showErr = m => { const e = root.querySelector('.err'); e.textContent = m; e.classList.toggle('on', !!m); if (m) e.scrollIntoView({ block: 'nearest' }); };
  root.querySelector('[data-skip]').onclick = onSkip;
  root.querySelector('[data-back]').onclick = onBack;
  btn.onclick = async () => {
    showErr(''); root.querySelector('.idretry')?.remove();
    const shots = await autoCapture();
    if (!shots) return;
    prevBox.hidden = false;
    prevBox.innerHTML = ['front', 'back'].map(k => `<figure><img alt="" src="${URL.createObjectURL(shots[k])}"><figcaption>${k === 'front' ? 'الوجه' : 'الظهر'}</figcaption></figure>`).join('');
    btn.disabled = true; btn.textContent = 'جارِ القراءة…'; busy.hidden = false; busyT.textContent = 'جارِ قراءة البطاقة والتحقق منها…';
    const t0 = Date.now();
    try {
      const r = await readNationalId(shots.front, shots.back, () => { busyT.textContent = 'القراءة أبطأ من المعتاد — لحظات من فضلك…'; });
      if (!r.parts.first && !r.nid) throw new Error('لم نتمكن من قراءة البيانات من الصورة — أعد التصوير بإضاءة أفضل');
      r.ms = Date.now() - t0; r.shots = shots;
      // جودة القراءة: لا تُملأ الحقول تلقائياً إن كانت القراءة ناقصة أو غير مطابقة — نقترح إعادة الالتقاط أولاً
      const miss = [['الاسم', r.parts.first], ['اسم الأب', r.parts.father], ['الرقم الوطني', r.nid], ['تاريخ الميلاد', r.bd], ['اسم الأم', r.motherParts && r.motherParts.m1]].filter(([, v]) => !v).map(([l]) => l);
      const nFlags = Object.keys(r.flags || {}).length;
      if (miss.length || nFlags >= 2 || (r.weak && r.weak.length >= 2)) {
        const why = [miss.length ? 'لم يُقرأ: ' + miss.join('، ') : '', nFlags >= 2 ? `${nFlags} حقول لا تطابق الشريط السفلي للبطاقة` : '', r.weak && r.weak.length >= 2 ? 'قراءة ضعيفة لـ: ' + r.weak.join('، ') : ''].filter(Boolean).join(' · ');
        prevBox.insertAdjacentHTML('afterend', `<div class="idretry"><b>الصورة لم تكفِ لقراءة كل البيانات بدقة</b><span>${esc(why)}</span><div class="row"><button type="button" class="btn cyan" data-again>إعادة الالتقاط (مقترح)</button><button type="button" class="btn ghost" data-go>المتابعة وإكمال الناقص يدوياً</button></div></div>`);
        const box = root.querySelector('.idretry');
        box.querySelector('[data-again]').onclick = () => { box.remove(); btn.click(); };
        box.querySelector('[data-go]').onclick = () => { box.remove(); onResult(r); };
        btn.disabled = false; btn.textContent = 'إعادة تصوير البطاقة';
        return;
      }
      onResult(r);
    } catch (e) {
      showErr(e.message); btn.disabled = false; btn.textContent = 'إعادة تصوير البطاقة';
    } finally { busy.hidden = true; }
  };
}

export const scanNote = r => `<div class="idnote ${r.verified ? 'ok' : ''}">${r.verified ? '✓ قُرئت بياناتك وتحققنا منها بالشريط السفلي للبطاقة' : '✓ قُرئت البيانات من بطاقتك تلقائياً'} — راجعها قبل الإرسال${r.ms ? ` · خلال <span class="num">${(r.ms / 1000).toFixed(1)}</span> ثانية` : ''}${r.weak && r.weak.length ? `<small>• تأكد خاصةً من: ${esc(r.weak.join('، '))}</small>` : ''}${!r.bd ? '<small>• لم يُقرأ تاريخ الميلاد — اختره يدوياً</small>' : ''}${(r.warnings || []).map(w => `<small>• ${esc(w)}</small>`).join('')}</div>`;
