"""Run: FACE_SERVICE_TOKEN=t pytest -q  (needs models/ and tests/fixtures/*.jpg)"""
import base64
import os

import cv2
import numpy as np
import pytest

os.environ.setdefault("FACE_SERVICE_TOKEN", "test-token")
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

FIX = os.path.join(os.path.dirname(__file__), "fixtures")
H = {"X-Internal-Token": os.environ["FACE_SERVICE_TOKEN"]}
client = TestClient(app)


def b64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def b64img(img):
    ok, buf = cv2.imencode(".jpg", img)
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


@pytest.fixture(scope="module")
def ref():
    r = client.post("/v1/reference", json={"image": b64(f"{FIX}/person_a.jpg")}, headers=H).json()
    assert r["ok"], r
    return r["embedding"]


def test_requires_token():
    r = client.post("/v1/reference", json={"image": "x"})
    assert r.status_code == 401


def test_bad_image():
    r = client.post("/v1/reference", json={"image": base64.b64encode(b"nope").decode()}, headers=H).json()
    assert r["ok"] is False and r["code"] == "bad_image"


def test_no_face():
    blank = np.full((400, 400, 3), 128, np.uint8)
    r = client.post("/v1/reference", json={"image": b64img(blank)}, headers=H).json()
    assert r["ok"] is False and r["code"] == "no_face"


def test_reference_embedding_size(ref):
    assert len(base64.b64decode(ref)) == 128 * 4


def test_same_person_matches(ref):
    # Same photo, slightly rescaled + re-encoded = same person
    img = cv2.imread(f"{FIX}/person_a.jpg")
    img = cv2.resize(img, None, fx=0.9, fy=0.9)
    r = client.post("/v1/analyze", json={"image": b64img(img), "reference_embedding": ref, "step": "center"},
                    headers=H).json()
    assert r["ok"], r
    assert r["match"]["score"] > 0.6


def test_other_person_rejected(ref):
    r = client.post("/v1/analyze", json={"image": b64(f"{FIX}/person_b.jpg"), "reference_embedding": ref,
                                         "step": "center"}, headers=H).json()
    if r["ok"]:
        assert r["step_passed"] is False
        assert r["match"]["score"] < 0.363


def test_turn_requires_baseline(ref):
    r = client.post("/v1/analyze", json={"image": b64(f"{FIX}/person_a.jpg"), "reference_embedding": ref,
                                         "step": "left"}, headers=H).json()
    assert r["ok"] is False and r["code"] == "missing_baseline"


def test_turn_not_passed_without_movement(ref):
    # Same frame as baseline: pose did not change, step must not pass
    first = client.post("/v1/analyze", json={"image": b64(f"{FIX}/person_a.jpg"), "reference_embedding": ref,
                                             "step": "center"}, headers=H).json()
    base = first["pose"]
    for step in ("left", "right", "up"):
        r = client.post("/v1/analyze", json={"image": b64(f"{FIX}/person_a.jpg"), "reference_embedding": ref,
                                             "step": step, "baseline": base}, headers=H).json()
        assert r["step_passed"] is False, step


def test_mirrored_frame_changes_yaw_sign(ref):
    # Horizontal flip mirrors head yaw - validates the sign convention used for left/right
    img = cv2.imread(f"{FIX}/person_a.jpg")
    a = client.post("/v1/analyze", json={"image": b64img(img), "reference_embedding": ref, "step": "center"},
                    headers=H).json()
    b = client.post("/v1/analyze", json={"image": b64img(cv2.flip(img, 1)), "reference_embedding": ref,
                                         "step": "center"}, headers=H).json()
    assert a["pose"]["yaw"] * b["pose"]["yaw"] < 0
