"""
Face verification & liveness micro-service (internal network only).

Endpoints
  GET  /health
  POST /v1/reference  -> computes a face embedding from the KYC reference photo
  POST /v1/analyze    -> analyses ONE live camera frame against the reference and
                         the expected liveness challenge step

The service is stateless and never persists images or embeddings. The signing
API owns the challenge state machine and decides when liveness is complete.
"""
from __future__ import annotations

import hmac
import logging
import os
from typing import Literal, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from .engine import FaceEngine, FaceError

log = logging.getLogger("face-service")
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))

TOKEN = os.environ.get("FACE_SERVICE_TOKEN", "")
MATCH_THRESHOLD = float(os.environ.get("FACE_MATCH_THRESHOLD", "0.40"))         # frontal frame vs reference
TURN_MATCH_THRESHOLD = float(os.environ.get("FACE_TURN_MATCH_THRESHOLD", "0.30"))  # turned frames vs reference
CENTER_MAX_YAW = float(os.environ.get("FACE_CENTER_MAX_YAW", "0.25"))
TURN_DELTA = float(os.environ.get("FACE_TURN_DELTA", "0.28"))
UP_DELTA = float(os.environ.get("FACE_UP_DELTA", "0.12"))
MIN_SHARPNESS = float(os.environ.get("FACE_MIN_SHARPNESS", "15"))
MIN_BRIGHTNESS = float(os.environ.get("FACE_MIN_BRIGHTNESS", "40"))

app = FastAPI(title="esign-face-service", docs_url=None, redoc_url=None, openapi_url=None)
engine = FaceEngine()


def require_token(x_internal_token: str = Header(default="")) -> None:
    if not TOKEN or not hmac.compare_digest(x_internal_token.encode(), TOKEN.encode()):
        raise HTTPException(status_code=401, detail="unauthorized")


class ReferenceIn(BaseModel):
    image: str = Field(..., max_length=4_000_000)


class Baseline(BaseModel):
    yaw: float
    pitch: float


class AnalyzeIn(BaseModel):
    image: str = Field(..., max_length=4_000_000)
    reference_embedding: str = Field(..., max_length=2000)
    step: Literal["center", "left", "right", "up"]
    baseline: Optional[Baseline] = None


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/v1/reference", dependencies=[Depends(require_token)])
async def reference(body: ReferenceIn):
    def work():
        img = engine.decode(body.image)
        obs = engine.observe(img)
        del img
        if abs(obs.yaw) > 0.35:
            raise FaceError("reference_not_frontal", "Reference photo must be frontal")
        return {
            "ok": True,
            "embedding": engine.embedding_to_b64(obs.embedding),
            "quality": {"det_score": round(obs.det_score, 3), "sharpness": round(obs.sharpness, 1),
                        "brightness": round(obs.brightness, 1)},
        }

    try:
        return await run_in_threadpool(work)
    except FaceError as e:
        return {"ok": False, "code": e.code, "message": e.message}


@app.post("/v1/analyze", dependencies=[Depends(require_token)])
async def analyze(body: AnalyzeIn):
    def work():
        ref = engine.embedding_from_b64(body.reference_embedding)
        img = engine.decode(body.image)
        obs = engine.observe(img)
        del img
        score = engine.similarity(ref, obs.embedding)
        quality_ok = obs.sharpness >= MIN_SHARPNESS and obs.brightness >= MIN_BRIGHTNESS
        res = {
            "ok": True,
            "pose": {"yaw": round(obs.yaw, 3), "pitch": round(obs.pitch, 3)},
            "match": {"score": round(score, 4)},
            "quality": {"det_score": round(obs.det_score, 3), "sharpness": round(obs.sharpness, 1),
                        "brightness": round(obs.brightness, 1), "ok": quality_ok},
            "step_passed": False,
            "hint": None,
        }
        if not quality_ok:
            res["hint"] = "low_quality"
            return res

        step = body.step
        if step == "center":
            match_ok = score >= MATCH_THRESHOLD
            res["match"]["passed"] = match_ok
            if abs(obs.yaw) > CENTER_MAX_YAW:
                res["hint"] = "look_straight"
            elif not match_ok:
                res["hint"] = "no_match"
            else:
                res["step_passed"] = True
            return res

        match_ok = score >= TURN_MATCH_THRESHOLD
        res["match"]["passed"] = match_ok
        if body.baseline is None:
            raise FaceError("missing_baseline", "Baseline pose required")
        b = body.baseline
        if step == "left":
            pose_ok = (obs.yaw - b.yaw) >= TURN_DELTA
        elif step == "right":
            pose_ok = (b.yaw - obs.yaw) >= TURN_DELTA
        else:  # up
            pose_ok = (b.pitch - obs.pitch) >= UP_DELTA
        if not match_ok:
            res["hint"] = "no_match"
        elif not pose_ok:
            res["hint"] = "keep_turning"
        else:
            res["step_passed"] = True
        return res

    try:
        return await run_in_threadpool(work)
    except FaceError as e:
        return {"ok": False, "code": e.code, "message": e.message, "step_passed": False}
