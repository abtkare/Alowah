"""
Face engine: detection (YuNet), recognition (SFace) and head-pose estimation.

Nothing in this module writes images or templates to disk. Images are decoded
in memory, analysed, and dropped when the request ends.
"""
from __future__ import annotations

import base64
import os
import threading
from dataclasses import dataclass

import cv2
import numpy as np

MODELS_DIR = os.environ.get("FACE_MODELS_DIR", os.path.join(os.path.dirname(__file__), "..", "models"))

# Limits that protect the service from oversized / malicious payloads
MAX_IMAGE_BYTES = int(os.environ.get("FACE_MAX_IMAGE_BYTES", str(2_500_000)))
MAX_SIDE = 1280  # images bigger than this are downscaled before analysis
MIN_FACE_PX = int(os.environ.get("FACE_MIN_FACE_PX", "80"))
DET_SCORE = float(os.environ.get("FACE_DET_SCORE", "0.85"))


class FaceError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass
class FaceObservation:
    count: int
    det_score: float
    box: tuple[int, int, int, int]
    yaw: float      # >0 : subject turned to THEIR left  | <0 : turned to THEIR right
    pitch: float    # nose-below-eyes ratio; smaller = head tilted up
    sharpness: float
    brightness: float
    embedding: np.ndarray


class FaceEngine:
    """Thread-safe wrapper. OpenCV DNN objects are not re-entrant, so each
    worker thread gets its own detector/recognizer instance."""

    def __init__(self) -> None:
        self._local = threading.local()
        det = os.path.join(MODELS_DIR, "yunet.onnx")
        rec = os.path.join(MODELS_DIR, "sface.onnx")
        if not (os.path.isfile(det) and os.path.isfile(rec)):
            raise RuntimeError(f"Face models missing in {MODELS_DIR}")
        self._det_path, self._rec_path = det, rec

    def _models(self):
        if not hasattr(self._local, "det"):
            self._local.det = cv2.FaceDetectorYN.create(self._det_path, "", (320, 320), DET_SCORE, 0.3, 5000)
            self._local.rec = cv2.FaceRecognizerSF.create(self._rec_path, "")
        return self._local.det, self._local.rec

    # ------------------------------------------------------------------ utils
    @staticmethod
    def decode(image_b64: str) -> np.ndarray:
        if "," in image_b64[:64]:  # strip data:image/jpeg;base64,
            image_b64 = image_b64.split(",", 1)[1]
        try:
            raw = base64.b64decode(image_b64, validate=True)
        except Exception as exc:  # noqa: BLE001
            raise FaceError("bad_image", "Image is not valid base64") from exc
        if len(raw) > MAX_IMAGE_BYTES:
            raise FaceError("image_too_large", "Image exceeds size limit")
        buf = np.frombuffer(raw, dtype=np.uint8)
        img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        del raw, buf
        if img is None:
            raise FaceError("bad_image", "Image could not be decoded")
        h, w = img.shape[:2]
        scale = MAX_SIDE / max(h, w)
        if scale < 1:
            img = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
        return img

    @staticmethod
    def embedding_to_b64(emb: np.ndarray) -> str:
        return base64.b64encode(emb.astype(np.float32).tobytes()).decode()

    @staticmethod
    def embedding_from_b64(data: str) -> np.ndarray:
        try:
            arr = np.frombuffer(base64.b64decode(data, validate=True), dtype=np.float32)
        except Exception as exc:  # noqa: BLE001
            raise FaceError("bad_reference", "Reference embedding invalid") from exc
        if arr.size != 128:
            raise FaceError("bad_reference", "Reference embedding has wrong size")
        return arr.reshape(1, 128)

    # --------------------------------------------------------------- analysis
    def observe(self, img: np.ndarray) -> FaceObservation:
        det, rec = self._models()
        h, w = img.shape[:2]
        det.setInputSize((w, h))
        _, faces = det.detect(img)
        if faces is None or len(faces) == 0:
            raise FaceError("no_face", "No face detected")
        faces = faces[faces[:, 14] >= DET_SCORE]
        if len(faces) == 0:
            raise FaceError("no_face", "No face detected")
        if len(faces) > 1:
            # A second clearly visible face is a red flag (someone helping / photo held up)
            areas = faces[:, 2] * faces[:, 3]
            order = np.argsort(-areas)
            if areas[order[1]] > 0.25 * areas[order[0]]:
                raise FaceError("multiple_faces", "More than one face in frame")
            faces = faces[order[:1]]
        f = faces[0]
        x, y, fw, fh = (int(v) for v in f[:4])
        if min(fw, fh) < MIN_FACE_PX:
            raise FaceError("face_too_small", "Face too far from camera")

        lm = f[4:14].reshape(5, 2)  # r-eye, l-eye, nose, r-mouth, l-mouth (image coords)
        eye_mid = (lm[0] + lm[1]) / 2.0
        eye_dist = float(np.linalg.norm(lm[1] - lm[0])) or 1.0
        yaw = float((lm[2][0] - eye_mid[0]) / eye_dist)
        mouth_mid = (lm[3] + lm[4]) / 2.0
        # Nose position between eye line (0) and mouth line (1); tilting up moves nose toward eyes
        denom = float(mouth_mid[1] - eye_mid[1]) or 1.0
        pitch = float((lm[2][1] - eye_mid[1]) / denom)

        x0, y0 = max(x, 0), max(y, 0)
        crop = cv2.cvtColor(img[y0:y0 + fh, x0:x0 + fw], cv2.COLOR_BGR2GRAY)
        sharp = float(cv2.Laplacian(crop, cv2.CV_64F).var()) if crop.size else 0.0
        bright = float(crop.mean()) if crop.size else 0.0

        aligned = rec.alignCrop(img, f)
        emb = rec.feature(aligned).astype(np.float32)
        return FaceObservation(len(faces), float(f[14]), (x, y, fw, fh), yaw, pitch, sharp, bright, emb)

    def similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        _, rec = self._models()
        return float(rec.match(a, b, cv2.FaceRecognizerSF_FR_COSINE))
