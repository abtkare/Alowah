# Security, privacy & compliance notes

## Signing flow (all checks server-side)

```mermaid
sequenceDiagram
  participant A as Alwah backend
  participant S as signing-api
  participant F as face-service (internal)
  participant U as Customer phone
  A->>S: POST /v1/sessions (PDF, signer, KYC photo)
  S->>F: reference photo -> embedding (photo discarded)
  S-->>A: signing_url
  A->>U: SMS / app notification with link
  U->>S: open link, read every page (tracked)
  U->>S: explicit consent (versioned text, device bound)
  loop random head-pose challenge
    U->>S: camera frame
    S->>F: analyse frame vs reference + expected pose
  end
  U->>S: WebAuthn assertion (fingerprint/Face ID on device) over document-bound challenge
  S->>S: issue one-shot certificate, render evidence page, PAdES-sign, timestamp
  S-->>A: webhook signature.completed (HMAC)
  U->>S: download signed PDF
```

A signature is produced **only** when all of these are true on the server: every page viewed → consent recorded for the same document hash → face match + liveness passed → WebAuthn assertion with user-verification verified against a stored public key and the document-bound challenge → session active and not expired. Any failure leaves the contract unsigned.

## Biometrics — what is and is not stored

| Data | Stored? |
|---|---|
| Fingerprint / Face ID of the phone | **Never leaves the phone.** WebAuthn returns only a signature; we store the device public key. |
| KYC reference photo | No. Converted to an embedding in memory. |
| Reference face embedding | Encrypted (AES-256-GCM), only while the session is active; wiped on completion, expiry, cancel or manual review. |
| Camera frames | No. Analysed in memory and dropped. Not logged. |
| Face result | Match score, steps, frame count, duration (no image). |

## Controls implemented

- TLS via Caddy (or your reverse proxy), HSTS, strict CSP, `frame-ancestors 'none'`, `Referrer-Policy: no-referrer`, camera/WebAuthn permissions policy.
- API keys stored as SHA-256 hashes; optional IP allow-list per client.
- Signing tokens: 256-bit random, stored hashed, never logged (masked in logs).
- CSRF token per page load; device cookie (`HttpOnly; Secure; SameSite=Strict`) bound at consent — another device cannot continue.
- Rate limiting (Redis-backed): global 300/min/IP, frames 8/s per session, WebAuthn 10–20/min.
- Idempotency keys on session creation; one active session per loan; optimistic locking on face steps; Redis lock on finalisation; WebAuthn challenges single-use (replay protection) and signature counter tracked.
- Encryption at rest (AES-256-GCM, HKDF purpose-separated keys from `MASTER_KEY`): signer PII, documents, signed PDFs, CA private key, webhook secrets, face embeddings.
- Audit log: append-only (DB triggers block UPDATE/DELETE/TRUNCATE) and SHA-256 hash-chained; `GET /v1/audit/verify` detects any tampering.
- Face-service is internal-only, token-protected, read-only container, size-limited inputs.
- One-shot signer keys: generated per signature in memory, used once, discarded.
- Retention job purges unsigned contracts after `RETENTION_UNSIGNED_DAYS`.

## Honest limitations (read before production)

1. **Legal qualification.** Law No. 78 of 2012 requires certificates from a licensed certification-service provider. `CA_PROVIDER=local-dev` is a self-hosted development CA and every evidence page states so. Production requires implementing `RemoteCA` (`signing-api/src/providers/ca.ts`) against the licensed provider and a trusted TSA (`TSA_PROVIDER=rfc3161`). This is an interface swap, not a redesign. Legal review by the bank's counsel is still required.
2. **Liveness strength.** The self-hosted liveness is *active* (random head-pose challenge + continuous identity match + quality checks). It stops printed photos and static images and most replayed videos (random order, timed). It is **not** certified (ISO 30107-3) and is weaker than commercial liveness against deepfakes injected through a virtual camera. Mitigation: the second factor (device biometric WebAuthn) cannot be injected. For high-value loans, add a certified liveness vendor by implementing `FaceProvider` (`src/providers/face.ts`).
3. **Face threshold tuning.** Default SFace cosine thresholds: 0.40 (frontal) / 0.30 (turned). Calibrate on a sample of real Iraqi ID photos vs. selfies before go-live (`FACE_MATCH_THRESHOLD`, `FACE_TURN_MATCH_THRESHOLD`).
4. **First-device enrolment** relies on the face match: the first passkey is enrolled only after face verification in the same session (logged as `webauthn.device_enrolled`).

## Tests

| Suite | Command | Covers |
|---|---|---|
| Face unit tests | `cd face-service && pytest -q` | auth, bad input, no face, match / non-match, static image cannot pass turns, yaw sign |
| Face integration | `node test/face-integration.mjs` | real face-service through the API: wrong person rejected, static photo blocked at turn step, passkey locked until liveness |
| End-to-end | `node test/e2e.mjs` | partner API (401, 422, idempotency, 409), full browser flow with virtual passkey + fake camera, other-device block, PDF signature valid (pdfsig), PAdES subfilter, hash match, full audit trail, chain verify, DB blocks audit UPDATE, biometrics wiped, post-completion calls rejected, webhook HMAC, no console errors |

## Acceptance criteria (all verified by the tests above)

- [x] No final signature without consent + WebAuthn + face liveness + server verification.
- [x] No raw fingerprint or face image stored in the database.
- [x] Every successful or failed attempt has an audit entry.
- [x] Signed document is bound to its hash and to a signature certificate + timestamp.
- [x] Unit, integration and security tests exist.
- [x] Safe failure path (retry, attempts limit, manual in-branch route) with clear Arabic messages.
- [x] No claim of legal qualification without a licensed CA (dev CA is labelled on every certificate page).
