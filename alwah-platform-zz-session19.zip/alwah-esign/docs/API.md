# Alwah E-Sign — API reference

Base URL: `https://<ESIGN_DOMAIN>`

There are two audiences:

| Who | Auth | Prefix |
|---|---|---|
| **Alwah backend** (server-to-server) | `Authorization: Bearer <API key>` (+ optional IP allow-list) | `/v1/...` |
| **Signer's browser** (signing page) | one-time token in the link + CSRF header + device cookie | `/api/sign/:token/...` |

Errors are always JSON: `{ "error": "<code>" }` with a proper HTTP status.

---

## 1. Server-to-server (Alwah → E-Sign)

### `POST /v1/sessions` — create a signing session

Headers: `Authorization: Bearer esk_...`, `Content-Type: application/json`, optional `Idempotency-Key: <uuid>` (safe retries; the same key + same body returns the same session, header `idempotent-replay: true`).

```json
{
  "loan_reference": "LN-2026-000123",
  "document": {
    "title": "عقد قرض مشروع صغير",
    "filename": "contract.pdf",
    "content_base64": "<PDF, max 15 MB>"
  },
  "signer": {
    "external_id": "CUST-1001",
    "full_name": "زكريا يحيى الربيعي",
    "phone": "0770xxxxxxx",
    "national_id": "1990xxxxxxxx"
  },
  "reference_face_base64": "<JPEG/PNG of the customer's verified KYC photo>",
  "summary": { "مبلغ القرض": "25,000,000 دينار", "مدة السداد": "36 شهراً" },
  "expires_in_minutes": 1440,
  "callback_url": "https://alwah.iq/api/esign/webhook"
}
```

`201 Created`
```json
{
  "session_id": "d78ad0a5-4a63-4240-a51b-e3529ce55544",
  "status": "created",
  "signing_url": "https://sign.alwah.iq/s/<token>",
  "expires_at": "2026-11-02T12:00:00.000Z",
  "document_sha256": "18bd6e83..."
}
```

Send `signing_url` to the customer (SMS / app notification). The token is shown only once and is stored hashed.

Errors: `401 unauthorized`, `409 active_session_exists_for_loan`, `413 document_too_large`, `422 document_not_pdf | document_encrypted | reference_face_no_face | reference_face_multiple_faces | reference_face_face_too_small | reference_face_reference_not_frontal | idempotency_key_reused`.

The reference photo is converted to a 128-number face embedding, encrypted, kept only while the session is active and wiped when it ends. The photo itself is never stored.

### `GET /v1/sessions/:id` — status + evidence

Returns `status` (`created | opened | consented | face_verified | completed | expired | cancelled | manual_review | failed`), the timeline, each verification (face score, WebAuthn results) and certificate details.

### `GET /v1/sessions/:id/signed-document`
The signed PDF (original pages + Arabic evidence certificate pages, PAdES signature). Header `x-document-sha256`.

### `GET /v1/sessions/:id/audit`
All audit-log entries of the session with their hash-chain values.

### `POST /v1/sessions/:id/cancel`
Cancels an active session (wipes biometric material, fires `session.cancelled`).

### `POST /v1/signers/:externalId/revoke-devices`
Revokes every passkey a customer registered (lost phone). Next signature requires face verification + new device enrolment.

### `GET /v1/audit/verify`
Recomputes the whole audit hash chain: `{ "ok": true, "count": 1234, "head": "<hash>" }`.

---

## 2. Webhooks (E-Sign → Alwah)

`POST` to `callback_url` (per session) or the client's default webhook URL. Retries with exponential back-off (up to 12 attempts).

Headers:
```
x-esign-event: signature.completed
x-esign-delivery: <uuid>
x-esign-timestamp: 1793535927
x-esign-signature: sha256=<hex HMAC-SHA256(webhook_secret, timestamp + "." + raw_body)>
```

Verify the signature and reject timestamps older than 5 minutes. Events:

| event | when |
|---|---|
| `signature.completed` | contract signed; includes `signed_document_sha256`, `certificate_serial`, `qualified_certificate` |
| `session.expired` | link expired before signing |
| `session.cancelled` | cancelled by Alwah |
| `session.manual_review` | customer asked for in-branch signing (safe fallback) |

Body example:
```json
{
  "id": "…", "event": "signature.completed", "created_at": "2026-11-01T12:00:00Z",
  "data": {
    "session_id": "…", "loan_reference": "LN-2026-000123", "status": "completed",
    "completed_at": "…", "document_sha256": "…", "signed_document_sha256": "…",
    "certificate_serial": "…", "qualified_certificate": false
  }
}
```

---

## 3. Signer browser API (used by the bundled page)

| Method | Path | Purpose | Requires |
|---|---|---|---|
| GET | `/s/:token` | signing page (HTML) | — |
| GET | `/api/sign/:token/bootstrap` | session info, CSRF token, sets device cookie | token |
| GET | `/api/sign/:token/document` | contract PDF | token, device |
| POST | `/api/sign/:token/viewed` | `{pages_viewed}` — must equal page count | CSRF |
| POST | `/api/sign/:token/consent` | `{accepted:true, consent_version, document_sha256}` — binds the session to this device | CSRF |
| POST | `/api/sign/:token/face/start` | random liveness challenge (center + 2 of left/right/up) | consented |
| POST | `/api/sign/:token/face/frame` | `{image: dataURL JPEG}` → `{done, step, hint, progress}` (max 8/s) | consented |
| POST | `/api/sign/:token/webauthn/options` | authentication options (challenge bound to document hash) or `{mode:"register"}` | face_verified |
| POST | `/api/sign/:token/webauthn/register/options` | passkey enrolment options (platform authenticator, UV required) | face_verified |
| POST | `/api/sign/:token/webauthn/register` | registration response → returns authentication options | face_verified |
| POST | `/api/sign/:token/webauthn/authenticate` | assertion → server verifies → **finalizes signature** | face_verified |
| GET | `/api/sign/:token/signed-document` | signed PDF (for 7 days) | completed, device |
| POST | `/api/sign/:token/manual` | switch to documented in-branch signing | active |

The document-bound challenge is
`base64url(SHA-256("ESIGN-v1|" + session_id + "|" + document_sha256 + "|" + nonce))`,
so the passkey signature in the evidence proves the device owner approved *this exact document*.
