#!/usr/bin/env bash
# تثبيت/تحديث خدمة التوقيع الإلكتروني على الـVPS وربطها بمنصة ألواح — بأمر واحد.
# يُشغَّل من داخل مجلد alwah-esign المفكوك (أو عبر الأمر الجاهز في ملف التسليم):
#   PAIR=<رمز الربط> bash deploy-vps.sh
# ما يفعله:
#   1) ينسخ الكود إلى /opt/alwah-esign (ويحافظ على .env القديم إن وُجد — فيه مفاتيح التشفير)
#   2) يختار نطاق اختبار تلقائياً: esign.<IP>.sslip.io (يشير إلى الخادم دون أي إعداد DNS)
#   3) يبني ويشغّل الحاويات (install.sh) على منفذ محلي غير مستخدم
#   4) يضيف موقعاً في nginx الموجود + شهادة HTTPS مجانية (certbot) — دون المساس بالمواقع الأخرى
#   5) يسجّل رابط الخدمة ومفاتيحها في منصة ألواح تلقائياً (برمز الربط PAIR)
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIR="${INSTALL_DIR:-/opt/alwah-esign}"
SUPABASE_URL="${SUPABASE_URL:-https://chjeqtjyywomtcenizxp.supabase.co}"
SUPABASE_ANON_KEY="${SUPABASE_ANON_KEY:-sb_publishable_yewCPqcDPAFW8RPqeJgrow_QTx57Ixy}"
ALWAH_URL="${ALWAH_URL:-https://alwah-platform.onrender.com}"
ACME_EMAIL="${ACME_EMAIL:-abtkare87@gmail.com}"

say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "شغّل الأمر بصلاحية root"

# ---------- 1) الكود
say "نسخ الكود إلى $DIR"
mkdir -p "$DIR"
if [ "$SRC" != "$DIR" ]; then
  tar -C "$SRC" --exclude='.env' --exclude='node_modules' -cf - . | tar -C "$DIR" -xf -
fi
cd "$DIR"

# ---------- 2) النطاق
if [ -f .env ] && grep -q '^ESIGN_DOMAIN=' .env; then
  ESIGN_DOMAIN="$(grep '^ESIGN_DOMAIN=' .env | cut -d= -f2-)"
else
  IP="$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
  [[ "$IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "تعذّر معرفة IP الخادم"
  ESIGN_DOMAIN="${ESIGN_DOMAIN:-esign.${IP//./-}.sslip.io}"
fi
say "نطاق الاختبار: $ESIGN_DOMAIN"

# ---------- 3) منفذ محلي غير مستخدم (8085 أو التالي)
if [ -f .env ] && grep -q '^API_PORT=' .env; then
  API_PORT="$(grep '^API_PORT=' .env | cut -d= -f2-)"
else
  API_PORT=8085
  while ss -ltn "( sport = :$API_PORT )" | grep -q LISTEN; do API_PORT=$((API_PORT+1)); done
fi
export ESIGN_DOMAIN ACME_EMAIL API_PORT ALWAH_WEBHOOK_URL="$ALWAH_URL/api/esign/webhook"

say "البناء والتشغيل (أول مرة قد يستغرق 5–10 دقائق)"
bash install.sh </dev/null
set -a; . ./.env; set +a

# ---------- 4) nginx + HTTPS
if command -v nginx >/dev/null 2>&1 && [ -d /etc/nginx ]; then
  CONF_DIR=/etc/nginx/sites-available; [ -d "$CONF_DIR" ] || CONF_DIR=/etc/nginx/conf.d
  CONF="$CONF_DIR/alwah-esign.conf"
  if [ ! -f "$CONF" ] || ! grep -q "$ESIGN_DOMAIN" "$CONF"; then
    say "إضافة موقع $ESIGN_DOMAIN إلى nginx"
    cat > "$CONF" <<NGINX
server {
  listen 80;
  server_name ${ESIGN_DOMAIN};
  client_max_body_size 30m;
  location / {
    proxy_pass http://127.0.0.1:${API_PORT};
    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-For \$remote_addr;
    proxy_set_header X-Forwarded-Proto https;
    proxy_read_timeout 120s;
  }
}
NGINX
    [ "$CONF_DIR" = /etc/nginx/sites-available ] && ln -sf "$CONF" /etc/nginx/sites-enabled/alwah-esign.conf
  fi
  nginx -t && systemctl reload nginx
  if ! grep -q "ssl_certificate" "$CONF"; then
    say "إصدار شهادة HTTPS"
    command -v certbot >/dev/null 2>&1 || { apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq certbot python3-certbot-nginx; }
    certbot --nginx -d "$ESIGN_DOMAIN" --non-interactive --agree-tos -m "$ACME_EMAIL" --redirect \
      || die "فشل إصدار الشهادة — أرسل لقطة من هذه الشاشة"
  fi
else
  echo "!! nginx غير مثبّت على المضيف — إن كان المنفذان 80/443 فارغين فقد شغّل install.sh خادم Caddy تلقائياً."
fi

# ---------- 5) فحص + ربط المنصة
say "فحص الخدمة عبر الإنترنت"
ok=0
for i in $(seq 1 20); do curl -fsS --max-time 8 "https://${ESIGN_DOMAIN}/health" >/dev/null 2>&1 && { ok=1; break; }; sleep 3; done
[ "$ok" = 1 ] || die "الخدمة لا تستجيب على https://${ESIGN_DOMAIN}/health"

if [ -n "${PAIR:-}" ]; then
  say "ربط الخدمة بمنصة ألواح"
  BODY=$(printf '{"p_pair":"%s","p_base_url":"https://%s","p_api_key":"%s","p_webhook_secret":"%s"}' \
    "$PAIR" "$ESIGN_DOMAIN" "$BOOTSTRAP_CLIENT_API_KEY" "$BOOTSTRAP_CLIENT_WEBHOOK_SECRET")
  R=$(curl -sS --max-time 20 -X POST "$SUPABASE_URL/rest/v1/rpc/esign_register" \
    -H "apikey: $SUPABASE_ANON_KEY" -H "Authorization: Bearer $SUPABASE_ANON_KEY" -H "Content-Type: application/json" -d "$BODY")
  echo "$R" | grep -q '"ok"' || die "فشل الربط مع المنصة: $R"
  echo "✓ تم الربط"
fi

cat <<OUT

════════════════════════════════════════════════════
 ✓ خدمة التوقيع الإلكتروني تعمل
   الرابط:  https://${ESIGN_DOMAIN}/health
   الربط مع ألواح: ${PAIR:+تم تلقائياً}${PAIR:-لم يُطلب (لا يوجد PAIR)}
   انسخ احتياطياً: ${DIR}/.env  (فيه مفاتيح التشفير)
════════════════════════════════════════════════════
OUT
