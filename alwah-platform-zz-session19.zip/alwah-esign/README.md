# خدمة التوقيع الإلكتروني — منصة ألواح

خدمة مستقلة تعمل على الـVPS الخاص بك وتُدمج مع منصة ألواح عبر API. تتيح للعميل توقيع عقد القرض من هاتفه بثلاثة عوامل يتحقق منها الخادم معاً:

1. **موافقة صريحة** بعد استعراض كل صفحات العقد.
2. **التحقق من الوجه مع كشف الحيوية**: مطابقة مع صورة الهوية (KYC) + حركات رأس عشوائية تمنع استخدام صورة أو فيديو مسجَّل.
3. **بصمة الجهاز (بصمة الإصبع أو Face ID)** عبر WebAuthn، والبصمة لا تغادر الهاتف إطلاقاً، ويُوقَّع بها تحدٍّ مشتق من بصمة العقد نفسه.

بعدها تُصدَر شهادة توقيع، ويُلحق بالعقد **شهادة إتمام توقيع بالعربية**، ويُوقَّع الملف رقمياً (PAdES) ويُختم زمنياً، ثم يُرسل إشعار موقَّع (Webhook) إلى ألواح.

## المكوّنات

| الخدمة | التقنية | الدور |
|---|---|---|
| `signing-api` | Node.js 22 + TypeScript + Fastify | الـAPI، صفحة التوقيع، WebAuthn، توقيع PDF، سجل التدقيق |
| `face-service` | Python + OpenCV (YuNet + SFace) | مطابقة الوجه وكشف الحيوية — داخلية فقط ولا تحفظ أي صورة |
| `postgres` | PostgreSQL 16 | البيانات (الحساسة منها مشفّرة AES-256) |
| `redis` | Redis 7 | تحديد المعدّل والأقفال |
| `caddy` | Caddy 2 | HTTPS تلقائي (يُشغَّل فقط إذا كان المنفذان 80/443 فارغين) |

لماذا Node.js + Fastify: من أسرع أطر Node في الاستجابة تحت الضغط، والتحقق البيومتري الثقيل معزول في خدمة Python منفصلة يمكن زيادة عمّالها (`FACE_WORKERS`) دون التأثير على الـAPI.

## التثبيت على الـVPS (من الهاتف)

1. افتح لوحة Hostinger ← VPS ← **Browser terminal**.
2. أنشئ سجلّ DNS من نوع **A** للنطاق الفرعي (مثلاً `sign.alwah.iq`) يشير إلى IP الخادم.
3. نفّذ:

```bash
git clone https://github.com/abtkare/alwah-esign.git /opt/alwah-esign
cd /opt/alwah-esign && sudo bash install.sh
```

سيسألك عن النطاق والبريد ورابط Webhook في ألواح، ثم يولّد كل المفاتيح السرية، ويبني الحاويات ويشغّلها، ويطبع **مفتاح API** و**سر Webhook** لإدخالهما في ألواح.

> إذا كان على الخادم مشاريع أخرى تستخدم المنفذين 80/443، لن يُشغَّل Caddy، وسيطبع السكربت إعداد nginx جاهزاً لتوجيه النطاق إلى `127.0.0.1:8085`.

**احتفظ بنسخة احتياطية من الملف `/opt/alwah-esign/.env`** — فقدان `MASTER_KEY` يعني فقدان كل البيانات المشفّرة.

## الدمج مع ألواح

### 1) إنشاء جلسة توقيع (من خادم ألواح)

```js
const res = await fetch('https://sign.alwah.iq/v1/sessions', {
  method: 'POST',
  headers: {
    Authorization: `Bearer ${process.env.ESIGN_API_KEY}`,
    'Content-Type': 'application/json',
    'Idempotency-Key': `loan-${loan.id}-v1`,
  },
  body: JSON.stringify({
    loan_reference: loan.reference,
    document: { title: 'عقد قرض مشروع صغير', filename: 'contract.pdf', content_base64: pdfBuffer.toString('base64') },
    signer: { external_id: customer.id, full_name: customer.fullName, phone: customer.phone, national_id: customer.nationalId },
    reference_face_base64: kycPhotoBuffer.toString('base64'),
    summary: { 'مبلغ القرض': '25,000,000 دينار', 'مدة السداد': '36 شهراً' },
  }),
});
const { session_id, signing_url } = await res.json();
// أرسل signing_url للعميل برسالة SMS أو إشعار
```

### 2) استقبال الإشعار عند اكتمال التوقيع

```js
import crypto from 'node:crypto';
app.post('/api/esign/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const ts = req.header('x-esign-timestamp');
  const expected = 'sha256=' + crypto.createHmac('sha256', process.env.ESIGN_WEBHOOK_SECRET).update(`${ts}.${req.body}`).digest('hex');
  if (expected !== req.header('x-esign-signature') || Date.now() / 1000 - Number(ts) > 300) return res.sendStatus(401);
  const evt = JSON.parse(req.body);
  if (evt.event === 'signature.completed') {
    // حدّث حالة القرض ونزّل العقد الموقّع: GET /v1/sessions/:id/signed-document
  }
  res.sendStatus(200);
});
```

التوثيق الكامل للـAPI: [`docs/API.md`](docs/API.md) — الأمان والامتثال والاختبارات: [`docs/SECURITY.md`](docs/SECURITY.md).

## قبل الاستخدام القانوني الفعلي

- الشهادة الحالية صادرة من **جهة تصديق تجريبية** تابعة للخدمة، ومكتوب ذلك بوضوح على كل شهادة توقيع. الحجية القانونية وفق القانون رقم 78 لسنة 2012 تتطلب ربط جهة تصديق إلكتروني **مرخّصة** — الربط جاهز كواجهة قابلة للاستبدال في `signing-api/src/providers/ca.ts`، ويُكمَل عند توفر توثيق API الجهة المرخّصة.
- مراجعة قانونية لنص الموافقة (`signing-api/src/context.ts`) من مستشار المصرف.
- معايرة عتبة مطابقة الوجه على عيّنة من صور هويات حقيقية.

## التطوير والاختبارات

```bash
cd face-service && pip install -r requirements.txt pytest httpx && pytest -q
cd signing-api && npm ci && npm run build
node test/e2e.mjs               # تدفق كامل في المتصفح (passkey افتراضي + كاميرا وهمية)
node test/face-integration.mjs  # مع خدمة الوجه الحقيقية
```

أوامر الإدارة داخل الحاوية:

```bash
docker compose exec signing-api node dist/cli.js create-client <name> [webhook_url]
docker compose exec signing-api node dist/cli.js verify-audit
```
