import type { Redis } from 'ioredis';
import type { Config } from './config.js';
import type { Vault } from './crypto.js';
import type { Db } from './db.js';
import type { PdfRenderer } from './pdf.js';
import type { CertificateAuthority } from './providers/ca.js';
import type { FaceProvider } from './providers/face.js';
import type { TimestampProvider } from './providers/tsa.js';
import type { FileStore } from './storage.js';

export interface Ctx {
  cfg: Config;
  db: Db;
  redis: Redis;
  pii: Vault;        // signer personal data
  bio: Vault;        // reference face embeddings (short-lived)
  secrets: Vault;    // webhook secrets
  store: FileStore;
  face: FaceProvider;
  ca: CertificateAuthority;
  tsa: TimestampProvider;
  renderer: PdfRenderer;
}

export const CONSENT = {
  version: 'ar-v1-2026-11',
  text:
    'أُقرّ أنا الموقِّع أدناه بأنني اطّلعت على عقد القرض المعروض بكامل صفحاته وفهمت شروطه والتزاماته المالية، ' +
    'وأوافق موافقةً صريحة وبإرادتي الحرة على توقيعه إلكترونياً، وأقبل استخدام التحقق من الوجه وكشف الحيوية والتحقق البيومتري ' +
    'على جهازي لإثبات هويتي لأغراض هذا التوقيع فقط، وأعلم أنه لا يتم حفظ صور وجهي أو بصمتي، وأن التوقيع الإلكتروني ' +
    'المستوفي للشروط القانونية له ذات الحجية القانونية للتوقيع الخطي وفق قانون التوقيع الإلكتروني والمعاملات الإلكترونية رقم 78 لسنة 2012.',
};
