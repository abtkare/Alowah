import type { Db, Tx } from './db.js';
import { canonical, sha256hex } from './crypto.js';

export interface AuditEntry {
  clientId?: string | null;
  sessionId?: string | null;
  actor: string;
  event: string;
  outcome: 'success' | 'failure' | 'info';
  ip?: string | null;
  userAgent?: string | null;
  deviceHash?: string | null;
  data?: Record<string, unknown>;
}

const GENESIS = '0'.repeat(64);
const LOCK = 7347002;

function entryHash(prev: string, at: string, e: AuditEntry) {
  return sha256hex(
    prev +
      '|' +
      canonical({
        at,
        client_id: e.clientId ?? null,
        session_id: e.sessionId ?? null,
        actor: e.actor,
        event: e.event,
        outcome: e.outcome,
        ip: e.ip ?? null,
        user_agent: e.userAgent ?? null,
        device_hash: e.deviceHash ?? null,
        data: e.data ?? {},
      }),
  );
}

/**
 * Appends to the hash chain. Must run inside a transaction so the chain head
 * read + insert are serialised (transaction-scoped advisory lock).
 */
export async function auditTx(tx: Tx, e: AuditEntry) {
  await tx.query('SELECT pg_advisory_xact_lock($1)', [LOCK]);
  const last = await tx.query('SELECT hash FROM audit_logs ORDER BY seq DESC LIMIT 1');
  const prev: string = last.rows[0]?.hash ?? GENESIS;
  const at = new Date().toISOString();
  const hash = entryHash(prev, at, e);
  await tx.query(
    `INSERT INTO audit_logs (at, client_id, session_id, actor, event, outcome, ip, user_agent, device_hash, data, prev_hash, hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
    [at, e.clientId ?? null, e.sessionId ?? null, e.actor, e.event, e.outcome, e.ip ?? null, e.userAgent ?? null,
      e.deviceHash ?? null, e.data ?? {}, prev, hash],
  );
  return hash;
}

export async function audit(db: Db, e: AuditEntry) {
  const tx = await db.connect();
  try {
    await tx.query('BEGIN');
    const h = await auditTx(tx, e);
    await tx.query('COMMIT');
    return h;
  } catch (err) {
    await tx.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    tx.release();
  }
}

/** Re-computes the whole chain. Returns the first broken sequence number, if any. */
export async function verifyChain(db: Db) {
  let prev = GENESIS;
  let count = 0;
  let lastSeq = 0;
  const batch = 5000;
  for (;;) {
    const { rows } = await db.query(
      `SELECT seq, at, client_id, session_id, actor, event, outcome, host(ip) AS ip, user_agent, device_hash, data, prev_hash, hash
       FROM audit_logs WHERE seq > $1 ORDER BY seq LIMIT $2`,
      [lastSeq, batch],
    );
    if (!rows.length) break;
    for (const r of rows) {
      const expect = entryHash(prev, new Date(r.at).toISOString(), {
        clientId: r.client_id, sessionId: r.session_id, actor: r.actor, event: r.event, outcome: r.outcome,
        ip: r.ip, userAgent: r.user_agent, deviceHash: r.device_hash, data: r.data,
      });
      if (r.prev_hash !== prev || r.hash !== expect) return { ok: false, count, brokenAt: Number(r.seq) };
      prev = r.hash;
      lastSeq = Number(r.seq);
      count++;
    }
  }
  return { ok: true, count, head: prev };
}
