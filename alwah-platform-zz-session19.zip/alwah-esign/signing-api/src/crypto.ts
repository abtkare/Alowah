import crypto from 'node:crypto';

/** AES-256-GCM envelope: [1 byte version][12 byte iv][16 byte tag][ciphertext] */
export class Vault {
  private key: Buffer;
  constructor(masterKeyB64: string, purpose = 'data') {
    const master = Buffer.from(masterKeyB64, 'base64');
    // Derive a purpose-specific key so the same master key is never used directly twice
    this.key = Buffer.from(crypto.hkdfSync('sha256', master, Buffer.alloc(0), `esign:${purpose}`, 32));
  }
  encrypt(plain: Buffer | string, aad?: string): Buffer {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', this.key, iv);
    if (aad) c.setAAD(Buffer.from(aad));
    const body = Buffer.concat([c.update(typeof plain === 'string' ? Buffer.from(plain) : plain), c.final()]);
    return Buffer.concat([Buffer.from([1]), iv, c.getAuthTag(), body]);
  }
  decrypt(blob: Buffer, aad?: string): Buffer {
    if (blob[0] !== 1) throw new Error('Unknown vault version');
    const iv = blob.subarray(1, 13);
    const tag = blob.subarray(13, 29);
    const d = crypto.createDecipheriv('aes-256-gcm', this.key, iv);
    if (aad) d.setAAD(Buffer.from(aad));
    d.setAuthTag(tag);
    return Buffer.concat([d.update(blob.subarray(29)), d.final()]);
  }
  encryptJson(v: unknown, aad?: string) {
    return this.encrypt(JSON.stringify(v), aad);
  }
  decryptJson<T>(b: Buffer, aad?: string): T {
    return JSON.parse(this.decrypt(b, aad).toString('utf8')) as T;
  }
}

export const sha256 = (d: Buffer | string) => crypto.createHash('sha256').update(d).digest();
export const sha256hex = (d: Buffer | string) => sha256(d).toString('hex');
export const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
export const hmacHex = (secret: string, data: string) => crypto.createHmac('sha256', secret).update(data).digest('hex');

export function safeEqual(a: Buffer | string, b: Buffer | string) {
  const x = Buffer.isBuffer(a) ? a : Buffer.from(a);
  const y = Buffer.isBuffer(b) ? b : Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/** Canonical JSON (sorted keys) - used so audit hashes are reproducible */
export function canonical(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v ?? null);
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  const o = v as Record<string, unknown>;
  return `{${Object.keys(o)
    .filter((k) => o[k] !== undefined)
    .sort()
    .map((k) => `${JSON.stringify(k)}:${canonical(o[k])}`)
    .join(',')}}`;
}

export function maskId(v?: string | null) {
  if (!v) return null;
  return v.length <= 4 ? '****' : `${'*'.repeat(Math.max(4, v.length - 4))}${v.slice(-4)}`;
}
