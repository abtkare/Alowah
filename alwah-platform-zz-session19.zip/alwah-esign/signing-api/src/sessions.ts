import crypto from 'node:crypto';
import { auditTx } from './audit.js';
import { CONSENT, type Ctx } from './context.js';
import { maskId, sha256, sha256hex } from './crypto.js';
import { withTx } from './db.js';
import { assembleAndSign, evidenceHtml } from './pdf.js';
import { enqueueWebhook } from './webhooks.js';

export const ACTIVE = ['created', 'opened', 'consented', 'face_verified'] as const;

export interface SignerPii {
  full_name: string;
  phone?: string | null;
  national_id?: string | null;
}

export class HttpError extends Error {
  constructor(public status: number, public code: string, message?: string) {
    super(message ?? code);
  }
}

export interface ReqMeta {
  ip: string;
  userAgent: string;
  deviceHash: string | null;
}

const fmtBaghdad = (d: Date | string | null | undefined) =>
  d
    ? new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Baghdad', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
      }).format(new Date(d))
    : '—';

/** Challenge that commits the passkey assertion to this exact document + session. */
export function documentBoundChallenge(sessionId: string, docSha256: string, nonce: string) {
  return sha256(`ESIGN-v1|${sessionId}|${docSha256}|${nonce}`).toString('base64url');
}

/** Removes short-lived biometric material the moment a session leaves the active states. */
export const WIPE_BIOMETRICS = 'reference_embedding_enc = NULL, face_state = NULL, webauthn_state = NULL';

export async function expireSessions(ctx: Ctx) {
  const { rows } = await ctx.db.query(
    `SELECT id, client_id, loan_reference, callback_url FROM signing_sessions
     WHERE status = ANY($1::session_status[]) AND expires_at < now() LIMIT 200`,
    [ACTIVE],
  );
  for (const s of rows) {
    await withTx(ctx.db, async (tx) => {
      const u = await tx.query(
        `UPDATE signing_sessions SET status='expired', ${WIPE_BIOMETRICS}, updated_at=now()
         WHERE id=$1 AND status = ANY($2::session_status[]) RETURNING id`,
        [s.id, ACTIVE],
      );
      if (!u.rowCount) return;
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'system', event: 'session.expired', outcome: 'info' });
      await enqueueWebhook(tx, ctx, {
        clientId: s.client_id, sessionId: s.id, event: 'session.expired', urlOverride: s.callback_url,
        payload: { session_id: s.id, loan_reference: s.loan_reference, status: 'expired' },
      });
    });
  }
  return rows.length;
}

/**
 * Produces the final signed contract. Preconditions are re-checked on the server:
 * consent + face liveness + passkey assertion (bound to the document hash).
 */
export async function finalizeSignature(
  ctx: Ctx,
  sessionId: string,
  webauthn: { credentialId: string; newDevice: boolean; userVerified: boolean; deviceType: string; evidence: Record<string, unknown> },
  meta: ReqMeta,
) {
  const lockKey = `finalize:${sessionId}`;
  const got = await ctx.redis.set(lockKey, '1', 'EX', 120, 'NX');
  if (!got) throw new HttpError(409, 'finalize_in_progress');
  try {
    const { rows } = await ctx.db.query(
      `SELECT s.*, d.sha256 AS doc_sha, d.storage_key, d.title, d.page_count, d.id AS doc_id,
              sg.pii_enc, sg.external_id, sg.id AS sg_id, c.name AS client_name
       FROM signing_sessions s JOIN documents d ON d.id=s.document_id JOIN signers sg ON sg.id=s.signer_id
       JOIN api_clients c ON c.id=s.client_id WHERE s.id=$1`,
      [sessionId],
    );
    const s = rows[0];
    if (!s) throw new HttpError(404, 'not_found');
    if (s.status !== 'face_verified') throw new HttpError(409, 'invalid_state');
    if (!s.consented_at || !s.face_verified_at) throw new HttpError(409, 'missing_factors');
    if (new Date(s.expires_at) < new Date()) throw new HttpError(410, 'expired');

    const consent = await ctx.db.query(
      'SELECT * FROM consent_records WHERE session_id=$1 AND accepted ORDER BY created_at DESC LIMIT 1',
      [sessionId],
    );
    const face = await ctx.db.query(
      `SELECT * FROM biometric_verifications WHERE session_id=$1 AND kind='face_liveness' AND result='pass' ORDER BY created_at DESC LIMIT 1`,
      [sessionId],
    );
    if (!consent.rowCount || !face.rowCount) throw new HttpError(409, 'missing_factors');
    if (consent.rows[0].document_sha256 !== s.doc_sha) throw new HttpError(409, 'document_mismatch');

    const original = await ctx.store.get(s.storage_key);
    if (sha256hex(original) !== s.doc_sha) throw new HttpError(500, 'document_integrity_failure');

    const pii = ctx.pii.decryptJson<SignerPii>(s.pii_enc, `signer:${s.sg_id}`);
    const now = new Date();
    const issued = await ctx.ca.issueSigner({
      fullName: pii.full_name,
      externalId: s.external_id,
      nationalIdMasked: maskId(pii.national_id),
      organization: s.client_name,
      sessionId,
    });
    let signed: Buffer;
    try {
      const fd = face.rows[0];
      const html = evidenceHtml({
        title: s.title,
        loanReference: s.loan_reference,
        summary: s.summary ?? {},
        signerName: pii.full_name,
        signerExternalId: s.external_id,
        nationalIdMasked: maskId(pii.national_id),
        sessionId,
        documentSha256: s.doc_sha,
        pageCount: s.page_count,
        consentText: CONSENT.text,
        consentVersion: consent.rows[0].consent_version,
        timeline: [
          { label: 'إنشاء جلسة التوقيع', at: fmtBaghdad(s.created_at) },
          { label: 'فتح رابط التوقيع', at: fmtBaghdad(s.opened_at) },
          { label: 'استعراض العقد', at: fmtBaghdad(s.document_viewed_at), detail: `${s.pages_viewed} صفحة` },
          { label: 'تسجيل الموافقة الصريحة', at: fmtBaghdad(s.consented_at) },
          { label: 'نجاح التحقق من الوجه والحيوية', at: fmtBaghdad(s.face_verified_at) },
          { label: 'نجاح التحقق البيومتري على الجهاز', at: fmtBaghdad(now) },
          { label: 'إتمام التوقيع وإصدار الشهادة', at: fmtBaghdad(now) },
        ],
        face: { provider: fd.provider, score: Number(fd.score), steps: fd.details?.steps ?? [] },
        passkey: {
          credentialIdShort: `${webauthn.credentialId.slice(0, 10)}…${webauthn.credentialId.slice(-6)}`,
          deviceType: webauthn.deviceType,
          userVerified: webauthn.userVerified,
          newDevice: webauthn.newDevice,
        },
        certificate: { ...issued.certificate, provider: ctx.ca.name, qualified: issued.qualified },
        ip: meta.ip,
        deviceIdShort: meta.deviceHash ? meta.deviceHash.slice(0, 16) : '—',
        userAgent: meta.userAgent.slice(0, 160),
      });
      const evidencePdf = await ctx.renderer.htmlToPdf(html);
      signed = await assembleAndSign({
        original,
        evidencePdf,
        signer: issued.signer,
        signerName: pii.full_name,
        reason: `توقيع عقد القرض ${s.loan_reference}`,
        location: 'Iraq',
        contact: s.client_name,
        signingTime: now,
      });
    } finally {
      issued.dispose();
    }

    const signedSha = sha256(signed);
    const ts = await ctx.tsa.stamp(signedSha);
    const signedKey = await ctx.store.put('signed', signed);
    const downloadUntil = new Date(Date.now() + ctx.cfg.SIGNED_DOWNLOAD_DAYS * 86400_000);

    await withTx(ctx.db, async (tx) => {
      const u = await tx.query(
        `UPDATE signing_sessions SET status='completed', webauthn_verified_at=$2, completed_at=$2,
           signed_download_until=$3, ${WIPE_BIOMETRICS}, updated_at=now()
         WHERE id=$1 AND status='face_verified' RETURNING id`,
        [sessionId, now, downloadUntil],
      );
      if (!u.rowCount) throw new HttpError(409, 'invalid_state');
      await tx.query('UPDATE documents SET signed_storage_key=$2, signed_sha256=$3 WHERE id=$1', [s.doc_id, signedKey, signedSha.toString('hex')]);
      await tx.query(
        `INSERT INTO signature_certificates (session_id, ca_provider, certificate_serial, subject, issuer, certificate_pem,
           not_before, not_after, original_sha256, signed_sha256, tsa_provider, timestamp_token, timestamp_time, webauthn_evidence)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
        [sessionId, ctx.ca.name, issued.certificate.serial, issued.certificate.subject, issued.certificate.issuer,
          issued.certificate.pem, issued.certificate.notBefore, issued.certificate.notAfter, s.doc_sha,
          signedSha.toString('hex'), ts.provider, ts.token, ts.time, webauthn.evidence],
      );
      await auditTx(tx, {
        clientId: s.client_id, sessionId, actor: 'signer', event: 'signature.completed', outcome: 'success',
        ip: meta.ip, userAgent: meta.userAgent, deviceHash: meta.deviceHash,
        data: {
          original_sha256: s.doc_sha, signed_sha256: signedSha.toString('hex'), certificate_serial: issued.certificate.serial,
          ca: ctx.ca.name, qualified: issued.qualified, tsa: ts.provider, timestamp: ts.time.toISOString(),
          credential_id: webauthn.credentialId,
        },
      });
      await enqueueWebhook(tx, ctx, {
        clientId: s.client_id, sessionId, event: 'signature.completed', urlOverride: s.callback_url,
        payload: {
          session_id: sessionId, loan_reference: s.loan_reference, status: 'completed', completed_at: now.toISOString(),
          document_sha256: s.doc_sha, signed_document_sha256: signedSha.toString('hex'),
          certificate_serial: issued.certificate.serial, qualified_certificate: issued.qualified,
        },
      });
    });
    return { completedAt: now, signedSha256: signedSha.toString('hex') };
  } finally {
    await ctx.redis.del(lockKey);
  }
}

export function newNonce() {
  return crypto.randomBytes(16).toString('base64url');
}
