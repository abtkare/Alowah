/**
 * Trusted timestamp adapter.
 *  - LocalTsa   : platform-sealed timestamp (dev / pilot)
 *  - Rfc3161Tsa : any RFC 3161 Time-Stamp Authority (use the licensed CA's TSA in production)
 */
import crypto from 'node:crypto';
import forge from 'node-forge';
import type { CertificateAuthority } from './ca.js';

export interface TimestampResult {
  provider: string;
  time: Date;
  token: Buffer;
}

export interface TimestampProvider {
  readonly name: string;
  stamp(sha256: Buffer): Promise<TimestampResult>;
}

export class LocalTsa implements TimestampProvider {
  readonly name = 'local-sealed-timestamp';
  constructor(private ca: CertificateAuthority) {}
  async stamp(hash: Buffer): Promise<TimestampResult> {
    if (!this.ca.sealSign) throw new Error('CA cannot seal');
    const time = new Date();
    const payload = Buffer.from(JSON.stringify({ alg: 'sha256', hash: hash.toString('hex'), time: time.toISOString(), nonce: crypto.randomBytes(8).toString('hex') }));
    const { signature } = await this.ca.sealSign(payload);
    const token = Buffer.from(JSON.stringify({ payload: payload.toString('base64'), signature: signature.toString('base64'), alg: 'RS256' }));
    return { provider: this.name, time, token };
  }
}

export class Rfc3161Tsa implements TimestampProvider {
  readonly name: string;
  constructor(private url: string) {
    this.name = `rfc3161:${new URL(url).host}`;
  }

  private request(hash: Buffer) {
    const a = forge.asn1;
    const nonce = crypto.randomBytes(8);
    nonce[0] &= 0x7f;
    const req = a.create(a.Class.UNIVERSAL, a.Type.SEQUENCE, true, [
      a.create(a.Class.UNIVERSAL, a.Type.INTEGER, false, a.integerToDer(1).getBytes()),
      a.create(a.Class.UNIVERSAL, a.Type.SEQUENCE, true, [
        a.create(a.Class.UNIVERSAL, a.Type.SEQUENCE, true, [
          a.create(a.Class.UNIVERSAL, a.Type.OID, false, a.oidToDer(forge.pki.oids.sha256).getBytes()),
          a.create(a.Class.UNIVERSAL, a.Type.NULL, false, ''),
        ]),
        a.create(a.Class.UNIVERSAL, a.Type.OCTETSTRING, false, hash.toString('binary')),
      ]),
      a.create(a.Class.UNIVERSAL, a.Type.INTEGER, false, nonce.toString('binary')),
      a.create(a.Class.UNIVERSAL, a.Type.BOOLEAN, false, String.fromCharCode(0xff)),
    ]);
    return Buffer.from(a.toDer(req).getBytes(), 'binary');
  }

  async stamp(hash: Buffer): Promise<TimestampResult> {
    const res = await fetch(this.url, {
      method: 'POST',
      headers: { 'content-type': 'application/timestamp-query' },
      body: this.request(hash),
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) throw new Error(`TSA HTTP ${res.status}`);
    const body = Buffer.from(await res.arrayBuffer());
    const resp = forge.asn1.fromDer(body.toString('binary'));
    const statusSeq = (resp.value as forge.asn1.Asn1[])[0];
    const status = forge.asn1.derToInteger((statusSeq.value as forge.asn1.Asn1[])[0].value as string);
    if (status !== 0 && status !== 1) throw new Error(`TSA rejected request (status ${status})`);
    return { provider: this.name, time: new Date(), token: body };
  }
}
