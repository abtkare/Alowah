/**
 * Face verification provider adapter.
 *  - LocalFaceProvider : the bundled self-hosted face-service (YuNet + SFace, active liveness)
 *  - MockFaceProvider  : TEST ONLY (refused in production by config)
 * A licensed/certified liveness vendor can be added by implementing FaceProvider.
 */
export type ChallengeStep = 'center' | 'left' | 'right' | 'up';

export interface ReferenceResult {
  ok: boolean;
  code?: string;
  embedding?: string; // base64 float32[128]; encrypted before storage, deleted at session end
  quality?: Record<string, number>;
}

export interface FrameResult {
  ok: boolean;
  code?: string;
  step_passed: boolean;
  hint?: string | null;
  pose?: { yaw: number; pitch: number };
  match?: { score: number; passed?: boolean };
  quality?: Record<string, unknown>;
}

export interface FaceProvider {
  readonly name: string;
  reference(imageB64: string): Promise<ReferenceResult>;
  analyze(input: { image: string; reference: string; step: ChallengeStep; baseline?: { yaw: number; pitch: number } }): Promise<FrameResult>;
}

export class LocalFaceProvider implements FaceProvider {
  readonly name = 'self-hosted:yunet+sface/active-liveness-v1';
  constructor(private url: string, private token: string) {}

  private async post<T>(path: string, body: unknown): Promise<T> {
    const ctrl = AbortSignal.timeout(10_000);
    const res = await fetch(`${this.url}${path}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-internal-token': this.token },
      body: JSON.stringify(body),
      signal: ctrl,
    });
    if (!res.ok) throw new Error(`face-service ${path} HTTP ${res.status}`);
    return (await res.json()) as T;
  }

  reference(image: string) {
    return this.post<ReferenceResult>('/v1/reference', { image });
  }

  analyze(i: { image: string; reference: string; step: ChallengeStep; baseline?: { yaw: number; pitch: number } }) {
    return this.post<FrameResult>('/v1/analyze', {
      image: i.image,
      reference_embedding: i.reference,
      step: i.step,
      baseline: i.baseline,
    });
  }
}

/** Deterministic fake used by automated tests only. Image content "FAIL" -> no match. */
export class MockFaceProvider implements FaceProvider {
  readonly name = 'mock';
  async reference(image: string) {
    if (image === 'NOFACE') return { ok: false, code: 'no_face' };
    return { ok: true, embedding: Buffer.alloc(512, 1).toString('base64') };
  }
  async analyze(i: { image: string; step: ChallengeStep }) {
    if (i.image === 'FAIL') return { ok: true, step_passed: false, hint: 'no_match', match: { score: 0.1 } };
    return { ok: true, step_passed: true, pose: { yaw: 0, pitch: 0.5 }, match: { score: 0.8 } };
  }
}
