/**
 * Certification Authority adapter.
 *
 * Iraqi Law No. 78 of 2012 requires the signature certificate to come from a
 * licensed certification-service provider. That provider is plugged in here.
 *
 *  - LocalDevCA : self-hosted CA for development / pilots. Issues a one-shot
 *                 X.509 certificate per signature; the signer key is generated
 *                 in memory, used once and discarded. NOT legally qualified.
 *  - RemoteCA   : template for the licensed provider's remote-signing API.
 */
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import forge from 'node-forge';
import { Signer } from '@signpdf/utils';
import type { Vault } from '../crypto.js';

export interface SignerIdentity {
  fullName: string;
  externalId: string;
  nationalIdMasked?: string | null;
  organization: string;
  sessionId: string;
}

export interface IssuedSigner {
  /** @signpdf Signer used to produce the CMS/PAdES signature */
  signer: Signer;
  certificate: { serial: string; subject: string; issuer: string; pem: string; notBefore: Date; notAfter: Date };
  /** true when the certificate comes from a licensed CA (legally qualified) */
  qualified: boolean;
  dispose(): void;
}

export interface CertificateAuthority {
  readonly name: string;
  readonly qualified: boolean;
  issueSigner(identity: SignerIdentity): Promise<IssuedSigner>;
  /** Signs arbitrary data with the platform seal (used by the local TSA) */
  sealSign?(data: Buffer): Promise<{ signature: Buffer; certPem: string }>;
}

const rsaKeyPair = (bits: number) =>
  new Promise<{ privateKey: string; publicKey: string }>((resolve, reject) =>
    crypto.generateKeyPair(
      'rsa',
      { modulusLength: bits, publicKeyEncoding: { type: 'spki', format: 'pem' }, privateKeyEncoding: { type: 'pkcs8', format: 'pem' } },
      (err, publicKey, privateKey) => (err ? reject(err) : resolve({ publicKey, privateKey })),
    ),
  );

/** CMS detached signer (adbe/ETSI) holding the one-shot key in memory only. */
export class ForgeKeySigner extends Signer {
  constructor(private key: forge.pki.PrivateKey | null, private cert: forge.pki.Certificate, private chain: forge.pki.Certificate[]) {
    super();
  }
  async sign(pdf: Buffer, signingTime?: Date): Promise<Buffer> {
    if (!this.key) throw new Error('signer key already disposed');
    const p7 = forge.pkcs7.createSignedData();
    p7.content = forge.util.createBuffer(pdf.toString('binary'));
    p7.addCertificate(this.cert);
    this.chain.forEach((c) => p7.addCertificate(c));
    p7.addSigner({
      key: this.key as never,
      certificate: this.cert,
      digestAlgorithm: forge.pki.oids.sha256,
      authenticatedAttributes: [
        { type: forge.pki.oids.contentType, value: forge.pki.oids.data },
        { type: forge.pki.oids.signingTime, value: (signingTime ?? new Date()) as never },
        { type: forge.pki.oids.messageDigest },
      ],
    });
    p7.sign({ detached: true });
    return Buffer.from(forge.asn1.toDer(p7.toAsn1()).getBytes(), 'binary');
  }
  dispose() {
    this.key = null;
  }
}

const serialHex = () => {
  const b = crypto.randomBytes(16);
  b[0] &= 0x7f; // positive
  return b.toString('hex');
};

export class LocalDevCA implements CertificateAuthority {
  readonly name = 'local-dev-ca';
  readonly qualified = false;
  private rootCert!: forge.pki.Certificate;
  private rootKey!: forge.pki.rsa.PrivateKey;
  private rootKeyPem!: string;

  constructor(private dataDir: string, private vault: Vault, private orgName = 'Alwah E-Signature (DEV)') {}

  async init() {
    const dir = path.join(this.dataDir, 'ca');
    await fs.mkdir(dir, { recursive: true, mode: 0o700 });
    const certPath = path.join(dir, 'root.crt');
    const keyPath = path.join(dir, 'root.key.enc');
    try {
      const pem = await fs.readFile(certPath, 'utf8');
      this.rootKeyPem = this.vault.decrypt(await fs.readFile(keyPath), 'ca-root').toString('utf8');
      this.rootCert = forge.pki.certificateFromPem(pem);
    } catch {
      const kp = await rsaKeyPair(3072);
      const cert = forge.pki.createCertificate();
      cert.publicKey = forge.pki.publicKeyFromPem(kp.publicKey);
      cert.serialNumber = serialHex();
      cert.validity.notBefore = new Date(Date.now() - 60_000);
      cert.validity.notAfter = new Date(Date.now() + 10 * 365 * 24 * 3600_000);
      const attrs = [
        { name: 'commonName', value: `${this.orgName} Root CA` },
        { name: 'organizationName', value: this.orgName },
        { name: 'countryName', value: 'IQ' },
      ];
      cert.setSubject(attrs);
      cert.setIssuer(attrs);
      cert.setExtensions([
        { name: 'basicConstraints', cA: true, critical: true },
        { name: 'keyUsage', keyCertSign: true, cRLSign: true, digitalSignature: true, critical: true },
        { name: 'subjectKeyIdentifier' },
      ]);
      cert.sign(forge.pki.privateKeyFromPem(kp.privateKey) as forge.pki.rsa.PrivateKey, forge.md.sha256.create());
      await fs.writeFile(certPath, forge.pki.certificateToPem(cert), { mode: 0o600 });
      await fs.writeFile(keyPath, this.vault.encrypt(kp.privateKey, 'ca-root'), { mode: 0o600 });
      this.rootKeyPem = kp.privateKey;
      this.rootCert = cert;
    }
    this.rootKey = forge.pki.privateKeyFromPem(this.rootKeyPem) as forge.pki.rsa.PrivateKey;
    return this;
  }

  get rootPem() {
    return forge.pki.certificateToPem(this.rootCert);
  }

  async issueSigner(id: SignerIdentity): Promise<IssuedSigner> {
    const kp = await rsaKeyPair(2048);
    const cert = forge.pki.createCertificate();
    cert.publicKey = forge.pki.publicKeyFromPem(kp.publicKey);
    cert.serialNumber = serialHex();
    cert.validity.notBefore = new Date(Date.now() - 60_000);
    cert.validity.notAfter = new Date(Date.now() + 365 * 24 * 3600_000);
    cert.setSubject([
      { name: 'commonName', value: id.fullName, valueTagClass: forge.asn1.Type.UTF8 as never },
      { name: 'serialNumber', value: id.externalId.replace(/[^A-Za-z0-9 \-]/g, '') },
      { name: 'organizationName', value: id.organization, valueTagClass: forge.asn1.Type.UTF8 as never },
      { name: 'countryName', value: 'IQ' },
    ]);
    cert.setIssuer(this.rootCert.subject.attributes);
    cert.setExtensions([
      { name: 'basicConstraints', cA: false, critical: true },
      { name: 'keyUsage', digitalSignature: true, nonRepudiation: true, critical: true },
      { name: 'extKeyUsage', emailProtection: true },
      { name: 'subjectKeyIdentifier' },
    ]);
    cert.sign(this.rootKey, forge.md.sha256.create());

    const signer = new ForgeKeySigner(forge.pki.privateKeyFromPem(kp.privateKey), cert, [this.rootCert]);

    const dn = (c: forge.pki.Certificate['subject']) =>
      c.attributes.map((a) => `${a.shortName ?? a.name ?? a.type}=${a.value}`).join(', ');
    return {
      signer,
      qualified: false,
      certificate: {
        serial: cert.serialNumber,
        subject: dn(cert.subject),
        issuer: dn(cert.issuer),
        pem: forge.pki.certificateToPem(cert),
        notBefore: cert.validity.notBefore,
        notAfter: cert.validity.notAfter,
      },
      dispose() {
        // one-shot key: drop the only reference so it is garbage collected
        signer.dispose();
      },
    };
  }

  async sealSign(data: Buffer) {
    const s = crypto.createSign('sha256');
    s.update(data);
    return { signature: s.sign(this.rootKeyPem), certPem: this.rootPem };
  }
}

/**
 * Template for the licensed Iraqi certification-service provider.
 * Typical remote-signing flow:
 *   1. POST /certificates   {identity}      -> one-shot certificate (+ chain)
 *   2. POST /sign           {digest, certId} -> raw signature over the CMS signed attributes
 * Fill in the HTTP calls once the provider's API documentation is available.
 */
export class RemoteCA implements CertificateAuthority {
  readonly name = 'remote-licensed-ca';
  readonly qualified = true;
  constructor(private url: string, private apiKey?: string) {}
  async issueSigner(_id: SignerIdentity): Promise<IssuedSigner> {
    void this.url;
    void this.apiKey;
    throw new Error('RemoteCA not configured: implement the licensed provider API in src/providers/ca.ts');
  }
}
