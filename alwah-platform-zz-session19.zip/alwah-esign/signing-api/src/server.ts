import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cookie from '@fastify/cookie';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import fstatic from '@fastify/static';
import Fastify from 'fastify';
import { ZodError } from 'zod';
import type { Ctx } from './context.js';
import { partnerRoutes } from './routes/partner.js';
import { signerRoutes } from './routes/signer.js';
import { HttpError } from './sessions.js';

const here = path.dirname(fileURLToPath(import.meta.url));
// Never let signing tokens reach the logs
const maskUrl = (u: string) => u.replace(/\/(s|api\/sign)\/[A-Za-z0-9_-]{8,}/, '/$1/[token]');

export async function buildServer(ctx: Ctx) {
  const app = Fastify({
    trustProxy: ctx.cfg.TRUST_PROXY,
    bodyLimit: 1024 * 1024,
    logger: {
      level: ctx.cfg.LOG_LEVEL,
      redact: ['req.headers.authorization', 'req.headers.cookie', 'req.headers["x-csrf-token"]'],
      serializers: {
        req: (r) => ({ method: r.method, url: maskUrl(r.url), ip: r.ip }),
      },
    },
  });

  await app.register(cookie);
  await app.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'wasm-unsafe-eval'"],
        styleSrc: ["'self'"],
        styleSrcAttr: ["'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        mediaSrc: ["'self'", 'blob:'],
        workerSrc: ["'self'", 'blob:'],
        connectSrc: ["'self'"],
        frameAncestors: ["'none'"],
        formAction: ["'none'"],
        baseUri: ["'none'"],
        objectSrc: ["'none'"],
      },
    },
    referrerPolicy: { policy: 'no-referrer' },
    strictTransportSecurity: { maxAge: 63072000, includeSubDomains: true },
    crossOriginEmbedderPolicy: false,
  });
  app.addHook('onSend', async (_req, reply) => {
    reply.header('permissions-policy', 'camera=(self), publickey-credentials-get=(self), publickey-credentials-create=(self), microphone=(), geolocation=()');
  });

  await app.register(rateLimit, {
    global: true,
    max: 300,
    timeWindow: 60_000,
    redis: ctx.redis,
    nameSpace: 'esign-rl:',
    skipOnError: false,
  });

  app.setErrorHandler((err, req, reply) => {
    if (err instanceof HttpError) return reply.code(err.status).send({ error: err.code });
    if (err instanceof ZodError) return reply.code(400).send({ error: 'validation_error', details: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })) });
    const e = err as { statusCode?: number; code?: string; message: string };
    if (e.statusCode === 429) return reply.code(429).send({ error: 'rate_limited' });
    if (e.statusCode && e.statusCode < 500) return reply.code(e.statusCode).send({ error: e.code ?? 'bad_request' });
    req.log.error({ err: e.message, url: maskUrl(req.url) }, 'unhandled error');
    return reply.code(500).send({ error: 'internal_error' });
  });

  app.get('/health', async () => {
    await ctx.db.query('SELECT 1');
    await ctx.redis.ping();
    return { ok: true, ca: ctx.ca.name, qualified: ctx.ca.qualified, face: ctx.face.name, tsa: ctx.tsa.name };
  });

  await app.register(async (a) => partnerRoutes(a, ctx));
  await app.register(async (a) => signerRoutes(a, ctx));

  // Static signing UI
  const webDir = path.join(here, '..', 'web-dist');
  await app.register(fstatic, { root: webDir, prefix: '/assets/', decorateReply: true, cacheControl: true, maxAge: '1h', immutable: false, index: false });
  app.get<{ Params: { token: string } }>('/s/:token', async (_req, reply) =>
    reply.header('cache-control', 'no-store').sendFile('index.html', webDir),
  );

  return app;
}
