-- e-signature service schema v1
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE api_clients (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name               text NOT NULL UNIQUE,
  key_hash           bytea NOT NULL UNIQUE,          -- sha256(api key); the key itself is never stored
  webhook_url        text,
  webhook_secret_enc bytea,
  ip_allowlist       text[] NOT NULL DEFAULT '{}',
  active             boolean NOT NULL DEFAULT true,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE signers (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id   uuid NOT NULL REFERENCES api_clients(id),
  external_id text NOT NULL,                         -- the customer id inside Alwah
  pii_enc     bytea NOT NULL,                        -- AES-GCM {full_name, phone, national_id}
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (client_id, external_id)
);

CREATE TABLE documents (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id          uuid NOT NULL REFERENCES api_clients(id),
  title              text NOT NULL,
  filename           text NOT NULL,
  size_bytes         integer NOT NULL,
  page_count         integer NOT NULL,
  sha256             text NOT NULL,                   -- hash of the exact bytes shown to the signer
  storage_key        text NOT NULL,
  signed_storage_key text,
  signed_sha256      text,
  purged_at          timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TYPE session_status AS ENUM (
  'created', 'opened', 'consented', 'face_verified', 'completed',
  'failed', 'expired', 'cancelled', 'manual_review'
);

CREATE TABLE signing_sessions (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id                 uuid NOT NULL REFERENCES api_clients(id),
  signer_id                 uuid NOT NULL REFERENCES signers(id),
  document_id               uuid NOT NULL REFERENCES documents(id),
  loan_reference            text NOT NULL,
  summary                   jsonb NOT NULL DEFAULT '{}',
  status                    session_status NOT NULL DEFAULT 'created',
  token_hash                bytea NOT NULL UNIQUE,        -- sha256 of the signing-link token
  csrf_hash                 bytea,
  device_hash               bytea,                        -- device cookie bound at consent time
  callback_url              text,
  expires_at                timestamptz NOT NULL,
  opened_at                 timestamptz,
  document_viewed_at        timestamptz,
  pages_viewed              integer NOT NULL DEFAULT 0,
  consented_at              timestamptz,
  face_verified_at          timestamptz,
  webauthn_verified_at      timestamptz,
  completed_at              timestamptz,
  failure_reason            text,
  reference_embedding_enc   bytea,                        -- deleted as soon as the session ends
  face_state                jsonb,
  face_attempts             integer NOT NULL DEFAULT 0,
  webauthn_state            jsonb,
  signed_download_until     timestamptz,
  created_at                timestamptz NOT NULL DEFAULT now(),
  updated_at                timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX signing_sessions_status_exp ON signing_sessions (status, expires_at);
CREATE INDEX signing_sessions_signer ON signing_sessions (signer_id);
CREATE UNIQUE INDEX signing_sessions_one_active_per_loan ON signing_sessions (client_id, loan_reference)
  WHERE status IN ('created', 'opened', 'consented', 'face_verified');

CREATE TABLE consent_records (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id           uuid NOT NULL REFERENCES signing_sessions(id),
  signer_id            uuid NOT NULL REFERENCES signers(id),
  consent_version      text NOT NULL,
  consent_text_sha256  text NOT NULL,
  document_sha256      text NOT NULL,
  accepted             boolean NOT NULL,
  ip                   inet,
  user_agent           text,
  device_hash          bytea,
  created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE biometric_verifications (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id    uuid NOT NULL REFERENCES signing_sessions(id),
  kind          text NOT NULL CHECK (kind IN ('face_liveness', 'webauthn_registration', 'webauthn_assertion')),
  result        text NOT NULL CHECK (result IN ('pass', 'fail')),
  score         numeric,
  provider      text NOT NULL,
  details       jsonb NOT NULL DEFAULT '{}',          -- never contains images or templates
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX biometric_verifications_session ON biometric_verifications (session_id);

CREATE TABLE webauthn_credentials (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  signer_id             uuid NOT NULL REFERENCES signers(id),
  credential_id         text NOT NULL UNIQUE,
  public_key            bytea NOT NULL,
  counter               bigint NOT NULL DEFAULT 0,
  transports            text[] NOT NULL DEFAULT '{}',
  aaguid                text,
  device_type           text,
  backed_up             boolean,
  registered_in_session uuid REFERENCES signing_sessions(id),
  revoked_at            timestamptz,
  last_used_at          timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX webauthn_credentials_signer ON webauthn_credentials (signer_id) WHERE revoked_at IS NULL;

CREATE TABLE signature_certificates (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id              uuid NOT NULL UNIQUE REFERENCES signing_sessions(id),
  ca_provider             text NOT NULL,
  certificate_serial      text NOT NULL,
  subject                 text NOT NULL,
  issuer                  text NOT NULL,
  certificate_pem         text NOT NULL,
  not_before              timestamptz NOT NULL,
  not_after               timestamptz NOT NULL,
  original_sha256         text NOT NULL,
  signed_sha256           text NOT NULL,
  tsa_provider            text NOT NULL,
  timestamp_token         bytea,
  timestamp_time          timestamptz NOT NULL,
  webauthn_evidence       jsonb NOT NULL,             -- clientDataJSON/authenticatorData/signature over doc-bound challenge
  created_at              timestamptz NOT NULL DEFAULT now()
);

-- Append-only, hash-chained audit trail
CREATE TABLE audit_logs (
  seq         bigserial PRIMARY KEY,
  id          uuid NOT NULL DEFAULT gen_random_uuid(),
  at          timestamptz NOT NULL,
  client_id   uuid,
  session_id  uuid,
  actor       text NOT NULL,          -- 'signer' | 'client:<name>' | 'system'
  event       text NOT NULL,
  outcome     text NOT NULL,          -- 'success' | 'failure' | 'info'
  ip          inet,
  user_agent  text,
  device_hash text,
  data        jsonb NOT NULL DEFAULT '{}',
  prev_hash   text NOT NULL,
  hash        text NOT NULL UNIQUE
);
CREATE INDEX audit_logs_session ON audit_logs (session_id, seq);

CREATE FUNCTION audit_logs_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs is append-only';
END $$;
CREATE TRIGGER audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION audit_logs_immutable();
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs
  FOR EACH STATEMENT EXECUTE FUNCTION audit_logs_immutable();

CREATE TABLE idempotency_keys (
  client_id     uuid NOT NULL REFERENCES api_clients(id),
  key           text NOT NULL,
  request_hash  text NOT NULL,
  status_code   integer,
  response      jsonb,
  created_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (client_id, key)
);

CREATE TABLE webhook_deliveries (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id       uuid NOT NULL REFERENCES api_clients(id),
  session_id      uuid,
  url             text NOT NULL,
  event           text NOT NULL,
  payload         jsonb NOT NULL,
  attempts        integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  delivered_at    timestamptz,
  last_error      text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX webhook_deliveries_pending ON webhook_deliveries (next_attempt_at) WHERE delivered_at IS NULL;
