/**
 * Admin CLI (run inside the container):
 *   node dist/cli.js migrate
 *   node dist/cli.js create-client <name> [webhook_url]   -> prints a new API key + webhook secret once
 *   node dist/cli.js verify-audit
 */
import crypto from 'node:crypto';
import { verifyChain } from './audit.js';
import { loadConfig } from './config.js';
import { sha256, Vault } from './crypto.js';
import { createPool, migrate } from './db.js';

const cfg = loadConfig();
const db = createPool(cfg.DATABASE_URL);
const [cmd, ...args] = process.argv.slice(2);

try {
  if (cmd === 'migrate') {
    await migrate(db);
  } else if (cmd === 'create-client') {
    const [name, webhook] = args;
    if (!name) throw new Error('usage: create-client <name> [webhook_url]');
    await migrate(db, () => undefined);
    const key = `esk_${crypto.randomBytes(32).toString('base64url')}`;
    const secret = `whs_${crypto.randomBytes(24).toString('base64url')}`;
    const vault = new Vault(cfg.MASTER_KEY, 'secrets');
    await db.query(
      `INSERT INTO api_clients (name, key_hash, webhook_url, webhook_secret_enc) VALUES ($1,$2,$3,$4)
       ON CONFLICT (name) DO UPDATE SET key_hash=EXCLUDED.key_hash, webhook_url=EXCLUDED.webhook_url, webhook_secret_enc=EXCLUDED.webhook_secret_enc`,
      [name, sha256(key), webhook ?? null, vault.encrypt(secret, 'webhook')],
    );
    console.log(JSON.stringify({ client: name, api_key: key, webhook_secret: secret, note: 'Shown once. Store securely.' }, null, 2));
  } else if (cmd === 'verify-audit') {
    console.log(JSON.stringify(await verifyChain(db), null, 2));
  } else {
    console.log('commands: migrate | create-client <name> [webhook_url] | verify-audit');
  }
} finally {
  await db.end();
}
