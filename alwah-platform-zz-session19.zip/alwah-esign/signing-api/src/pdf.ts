/**
 * PDF pipeline:
 *  1. Render the Arabic "signature evidence certificate" page (HTML -> PDF, Chromium; proper Arabic shaping)
 *  2. Append it to the original contract (original pages are copied unchanged)
 *  3. Add a PAdES (ETSI.CAdES.detached) signature placeholder and sign with the CA-issued signer
 */
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { PDFDocument } from 'pdf-lib';
import { pdflibAddPlaceholder } from '@signpdf/placeholder-pdf-lib';
import { SUBFILTER_ETSI_CADES_DETACHED } from '@signpdf/utils';
import { SignPdf } from '@signpdf/signpdf';
import { chromium, type Browser } from 'playwright-core';
import type { Signer } from '@signpdf/utils';

const require = createRequire(import.meta.url);

const fontB64 = (weight: '400Regular' | '700Bold') =>
  fs
    .readFileSync(require.resolve(`@expo-google-fonts/noto-naskh-arabic/${weight}/NotoNaskhArabic_${weight}.ttf`))
    .toString('base64');

let FONTS: { regular: string; bold: string } | null = null;
const fonts = () => (FONTS ??= { regular: fontB64('400Regular'), bold: fontB64('700Bold') });

export async function inspectPdf(buf: Buffer) {
  if (buf.subarray(0, 5).toString('latin1') !== '%PDF-') throw new Error('not_pdf');
  const doc = await PDFDocument.load(buf, { updateMetadata: false });
  if (doc.isEncrypted) throw new Error('encrypted_pdf');
  return { pageCount: doc.getPageCount() };
}

// ---------------------------------------------------------------- renderer
export class PdfRenderer {
  private browser: Promise<Browser> | null = null;
  private active = 0;
  private queue: Array<() => void> = [];
  constructor(private executablePath: string, private maxConcurrent = 4) {}

  private getBrowser() {
    if (!this.browser) {
      this.browser = chromium
        .launch({ executablePath: this.executablePath, args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'] })
        .then((b) => {
          b.on('disconnected', () => (this.browser = null));
          return b;
        })
        .catch((e) => {
          this.browser = null;
          throw e;
        });
    }
    return this.browser;
  }

  private async slot() {
    if (this.active >= this.maxConcurrent) await new Promise<void>((r) => this.queue.push(r));
    this.active++;
  }
  private release() {
    this.active--;
    this.queue.shift()?.();
  }

  async htmlToPdf(html: string): Promise<Buffer> {
    await this.slot();
    try {
      const b = await this.getBrowser();
      const ctx = await b.newContext({ javaScriptEnabled: false });
      try {
        const page = await ctx.newPage();
        // Block all network: the evidence page is fully self-contained
        await page.route('**/*', (r) => r.abort());
        await page.setContent(html, { waitUntil: 'load' });
        return await page.pdf({ format: 'A4', printBackground: true, margin: { top: '14mm', bottom: '14mm', left: '14mm', right: '14mm' } });
      } finally {
        await ctx.close();
      }
    } finally {
      this.release();
    }
  }

  async close() {
    const b = await this.browser?.catch(() => null);
    await b?.close();
  }
}

// Partner-supplied HTML contract: embed the Arabic font (the renderer blocks all network access)
export function withContractFonts(html: string) {
  const f = fonts();
  const css = `<style>@font-face{font-family:Naskh;src:url(data:font/ttf;base64,${f.regular});font-weight:400}
@font-face{font-family:Naskh;src:url(data:font/ttf;base64,${f.bold});font-weight:700}
body{font-family:Naskh,serif}</style>`;
  return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => m + css) : css + html;
}

// ---------------------------------------------------------- evidence page
export interface Evidence {
  title: string;
  loanReference: string;
  summary: Record<string, string | number>;
  signerName: string;
  signerExternalId: string;
  nationalIdMasked: string | null;
  sessionId: string;
  documentSha256: string;
  pageCount: number;
  consentText: string;
  consentVersion: string;
  timeline: Array<{ label: string; at: string; detail?: string }>;
  face: { provider: string; score: number; steps: string[] };
  passkey: { credentialIdShort: string; deviceType: string; userVerified: boolean; newDevice: boolean };
  certificate: { serial: string; subject: string; issuer: string; provider: string; qualified: boolean };
  ip: string;
  deviceIdShort: string;
  userAgent: string;
}

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

const STEP_AR: Record<string, string> = { center: 'النظر للأمام', left: 'الالتفات لليسار', right: 'الالتفات لليمين', up: 'رفع الرأس' };

export function evidenceHtml(e: Evidence) {
  const f = fonts();
  const row = (k: string, v: unknown, ltr = false) =>
    `<tr><th>${esc(k)}</th><td${ltr ? ' class="ltr"' : ''}>${esc(v)}</td></tr>`;
  const summaryRows = Object.entries(e.summary)
    .slice(0, 12)
    .map(([k, v]) => row(k, v))
    .join('');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
@font-face{font-family:Naskh;src:url(data:font/ttf;base64,${f.regular});font-weight:400}
@font-face{font-family:Naskh;src:url(data:font/ttf;base64,${f.bold});font-weight:700}
*{box-sizing:border-box}body{font-family:Naskh,serif;color:#111;font-size:10.5pt;line-height:1.55;margin:0}
h1{font-size:17pt;margin:0 0 2px}h2{font-size:12pt;margin:14px 0 6px;border-bottom:1.5px solid #0f3d3e;color:#0f3d3e;padding-bottom:2px}
.head{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #0f3d3e;padding-bottom:8px;margin-bottom:6px}
.muted{color:#555;font-size:9pt}table{width:100%;border-collapse:collapse}th,td{text-align:right;padding:3px 6px;border-bottom:1px solid #e3e3e3;vertical-align:top}
th{width:34%;font-weight:700;color:#333;background:#f6f8f8}.ltr{direction:ltr;text-align:left;font-family:monospace;font-size:8.5pt;word-break:break-all}
.ok{color:#0a7a3d;font-weight:700}.warn{border:1.5px solid #b45309;background:#fff7ed;color:#7c2d12;padding:6px 10px;border-radius:6px;margin:8px 0;font-size:9.5pt}
.consent{background:#f6f8f8;padding:8px 10px;border-radius:6px;font-size:9.5pt}
</style></head><body>
<div class="head"><div><h1>شهادة إتمام التوقيع الإلكتروني</h1><div class="muted">ملحق إثبات مرفق بالعقد — يُعدّ جزءاً لا يتجزأ منه</div></div>
<div class="muted ltr" style="text-align:left">Session<br>${esc(e.sessionId)}</div></div>
${e.certificate.qualified ? '' : `<div class="warn">تنبيه: تم إصدار شهادة هذا التوقيع من جهة تصديق تجريبية تابعة للمنصة (وضع التطوير). لا يُعدّ التوقيع معتمداً قانونياً وفق قانون التوقيع الإلكتروني والمعاملات الإلكترونية رقم 78 لسنة 2012 إلا بعد الربط بجهة تصديق إلكتروني مرخصة.</div>`}
<h2>بيانات العقد</h2><table>
${row('عنوان المستند', e.title)}${row('رقم مرجع القرض', e.loanReference)}${row('عدد صفحات العقد الأصلي', e.pageCount)}
${row('بصمة المستند الأصلي SHA-256', e.documentSha256, true)}${summaryRows}</table>
<h2>بيانات الموقِّع</h2><table>
${row('الاسم الكامل', e.signerName)}${row('رقم العميل في المنصة', e.signerExternalId)}${e.nationalIdMasked ? row('رقم الهوية (مُقنَّع)', e.nationalIdMasked, true) : ''}</table>
<h2>عوامل التحقق</h2><table>
<tr><th>الموافقة الصريحة</th><td class="ok">تمت — نسخة النص ${esc(e.consentVersion)}</td></tr>
<tr><th>التحقق من الوجه وكشف الحيوية</th><td class="ok">ناجح — نسبة التطابق ${(e.face.score * 100).toFixed(1)}٪ — الخطوات: ${e.face.steps.map((s) => STEP_AR[s] ?? s).join('، ')}</td></tr>
<tr><th>مزوّد التحقق من الوجه</th><td class="ltr">${esc(e.face.provider)}</td></tr>
<tr><th>التحقق البيومتري على الجهاز (WebAuthn)</th><td class="ok">ناجح — ${e.passkey.userVerified ? 'بصمة/وجه الجهاز مؤكَّد' : '—'}${e.passkey.newDevice ? ' — تسجيل جهاز جديد بعد التحقق من الوجه' : ''}</td></tr>
${row('معرّف مفتاح الجهاز', e.passkey.credentialIdShort, true)}
<tr><th>ربط التوقيع بالمستند</th><td>تم توقيع تحدٍّ مشتق من بصمة المستند بمفتاح الجهاز الآمن</td></tr></table>
<h2>شهادة التوقيع</h2><table>
${row('الجهة المُصدِرة', e.certificate.issuer, true)}${row('صاحب الشهادة', e.certificate.subject, true)}
${row('الرقم التسلسلي', e.certificate.serial, true)}${row('مزوّد التصديق', e.certificate.provider, true)}</table>
<h2>السجل الزمني (توقيت بغداد)</h2><table>${e.timeline.map((t) => row(t.label, t.at + (t.detail ? ` — ${t.detail}` : ''))).join('')}
${row('عنوان IP', e.ip, true)}${row('معرّف الجهاز', e.deviceIdShort, true)}${row('المتصفح', e.userAgent, true)}</table>
<h2>نص الموافقة المسجَّل</h2><div class="consent">${esc(e.consentText)}</div>
<p class="muted">يمكن التحقق من سلامة هذا المستند بمقارنة التوقيع الرقمي المضمَّن في الملف، وبسجل التدقيق غير القابل للتعديل لدى المنصة.</p>
</body></html>`;
}

// ------------------------------------------------------------- assemble
export async function assembleAndSign(opts: {
  original: Buffer;
  evidencePdf: Buffer;
  signer: Signer;
  signerName: string;
  reason: string;
  location: string;
  contact: string;
  signingTime: Date;
}) {
  const doc = await PDFDocument.load(opts.original, { updateMetadata: false });
  const ev = await PDFDocument.load(opts.evidencePdf);
  const pages = await doc.copyPages(ev, ev.getPageIndices());
  pages.forEach((p) => doc.addPage(p));
  doc.setModificationDate(opts.signingTime);

  pdflibAddPlaceholder({
    pdfDoc: doc,
    reason: opts.reason,
    contactInfo: opts.contact,
    name: opts.signerName,
    location: opts.location,
    signingTime: opts.signingTime,
    signatureLength: 16384,
    subFilter: SUBFILTER_ETSI_CADES_DETACHED,
    appName: 'Alwah E-Sign',
  });
  const withPlaceholder = Buffer.from(await doc.save({ useObjectStreams: false }));
  return new SignPdf().sign(withPlaceholder, opts.signer, opts.signingTime);
}
