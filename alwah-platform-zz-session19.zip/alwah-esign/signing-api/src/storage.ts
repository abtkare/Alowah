import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import type { Vault } from './crypto.js';

/** Encrypted-at-rest file store on the VPS data volume. */
export class FileStore {
  constructor(private root: string, private vault: Vault) {}

  private file(key: string) {
    if (!/^[a-z0-9/_-]+$/i.test(key)) throw new Error('bad storage key');
    return path.join(this.root, 'files', `${key}.bin`);
  }

  async put(prefix: string, data: Buffer) {
    const key = `${prefix}/${new Date().toISOString().slice(0, 7)}/${crypto.randomUUID()}`;
    const f = this.file(key);
    await fs.mkdir(path.dirname(f), { recursive: true, mode: 0o700 });
    await fs.writeFile(f, this.vault.encrypt(data, key), { mode: 0o600 });
    return key;
  }

  async get(key: string) {
    return this.vault.decrypt(await fs.readFile(this.file(key)), key);
  }

  async remove(key: string) {
    await fs.rm(this.file(key), { force: true });
  }
}
