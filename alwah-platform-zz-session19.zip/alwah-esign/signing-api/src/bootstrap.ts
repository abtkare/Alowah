import { Redis } from 'ioredis';
import { loadConfig, type Config } from './config.js';
import type { Ctx } from './context.js';
import { sha256, Vault } from './crypto.js';
import { createPool, migrate } from './db.js';
import { PdfRenderer } from './pdf.js';
import { LocalDevCA, RemoteCA, type CertificateAuthority } from './providers/ca.js';
import { LocalFaceProvider, MockFaceProvider } from './providers/face.js';
import { LocalTsa, Rfc3161Tsa } from './providers/tsa.js';
import { FileStore } from './storage.js';

export async function createContext(cfg: Config = loadConfig()): Promise<Ctx> {
  const db = createPool(cfg.DATABASE_URL);
  await migrate(db);
  const redis = new Redis(cfg.REDIS_URL, { maxRetriesPerRequest: 3, enableOfflineQueue: true });
  const vault = (p: string) => new Vault(cfg.MASTER_KEY, p);

  let ca: CertificateAuthority;
  if (cfg.CA_PROVIDER === 'remote') ca = new RemoteCA(cfg.CA_REMOTE_URL!, cfg.CA_REMOTE_API_KEY);
  else ca = await new LocalDevCA(cfg.DATA_DIR, vault('ca'), 'Alwah E-Signature (DEV)').init();

  const ctx: Ctx = {
    cfg,
    db,
    redis,
    pii: vault('pii'),
    bio: vault('biometric'),
    secrets: vault('secrets'),
    store: new FileStore(cfg.DATA_DIR, vault('files')),
    face: cfg.FACE_PROVIDER === 'mock' ? new MockFaceProvider() : new LocalFaceProvider(cfg.FACE_SERVICE_URL, cfg.FACE_SERVICE_TOKEN),
    ca,
    tsa: cfg.TSA_PROVIDER === 'rfc3161' ? new Rfc3161Tsa(cfg.TSA_URL!) : new LocalTsa(ca),
    renderer: new PdfRenderer(cfg.CHROMIUM_PATH),
  };
  await bootstrapClient(ctx);
  return ctx;
}

/** Creates/updates the Alwah API client from env so a fresh VPS install works in one step. */
async function bootstrapClient(ctx: Ctx) {
  const c = ctx.cfg;
  if (!c.BOOTSTRAP_CLIENT_API_KEY) return;
  if (c.BOOTSTRAP_CLIENT_API_KEY.length < 32) throw new Error('BOOTSTRAP_CLIENT_API_KEY must be at least 32 chars');
  await ctx.db.query(
    `INSERT INTO api_clients (name, key_hash, webhook_url, webhook_secret_enc) VALUES ($1,$2,$3,$4)
     ON CONFLICT (name) DO UPDATE SET key_hash=EXCLUDED.key_hash, webhook_url=EXCLUDED.webhook_url, webhook_secret_enc=EXCLUDED.webhook_secret_enc`,
    [
      c.BOOTSTRAP_CLIENT_NAME,
      sha256(c.BOOTSTRAP_CLIENT_API_KEY),
      c.BOOTSTRAP_CLIENT_WEBHOOK_URL || null,
      c.BOOTSTRAP_CLIENT_WEBHOOK_SECRET ? ctx.secrets.encrypt(c.BOOTSTRAP_CLIENT_WEBHOOK_SECRET, 'webhook') : null,
    ],
  );
}
