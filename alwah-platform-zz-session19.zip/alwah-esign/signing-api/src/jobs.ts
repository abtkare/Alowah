import { audit } from './audit.js';
import type { Ctx } from './context.js';
import { expireSessions } from './sessions.js';
import { deliverDueWebhooks } from './webhooks.js';

/** Background jobs. Each tick takes a short Redis lock so only one replica runs it. */
export function startJobs(ctx: Ctx, log: { info: (m: string) => void; error: (o: unknown, m: string) => void }) {
  const run = (name: string, everyMs: number, fn: () => Promise<unknown>) => {
    const tick = async () => {
      const ok = await ctx.redis.set(`job:${name}`, '1', 'PX', Math.max(everyMs - 500, 1000), 'NX').catch(() => null);
      if (!ok) return;
      try {
        await fn();
      } catch (e) {
        log.error({ err: (e as Error).message }, `job ${name} failed`);
      }
    };
    const t = setInterval(tick, everyMs);
    t.unref();
    return t;
  };

  const timers = [
    run('expire', 60_000, () => expireSessions(ctx)),
    run('webhooks', 5_000, () => deliverDueWebhooks(ctx, log.info)),
    run('retention', 6 * 3600_000, () => retention(ctx)),
  ];
  return () => timers.forEach(clearInterval);
}

/** Data minimisation: purge contract files of sessions that never got signed; drop old idempotency keys. */
export async function retention(ctx: Ctx) {
  const { rows } = await ctx.db.query(
    `SELECT d.id, d.storage_key FROM documents d JOIN signing_sessions s ON s.document_id=d.id
     WHERE d.purged_at IS NULL AND s.status IN ('expired','cancelled','failed','manual_review')
       AND s.updated_at < now() - ($1 || ' days')::interval LIMIT 500`,
    [String(ctx.cfg.RETENTION_UNSIGNED_DAYS)],
  );
  for (const d of rows) {
    await ctx.store.remove(d.storage_key);
    await ctx.db.query('UPDATE documents SET purged_at=now() WHERE id=$1', [d.id]);
  }
  await ctx.db.query(`DELETE FROM idempotency_keys WHERE created_at < now() - interval '2 days'`);
  if (rows.length) await audit(ctx.db, { actor: 'system', event: 'retention.purged_unsigned_documents', outcome: 'info', data: { count: rows.length } });
}
