/**
 * Browser API used by the signing page. Access = the one-time signing token in the URL,
 * plus a CSRF token, plus (after consent) the device cookie that recorded the consent.
 */
import {
  generateAuthenticationOptions,
  generateRegistrationOptions,
  verifyAuthenticationResponse,
  verifyRegistrationResponse,
  type AuthenticationResponseJSON,
  type RegistrationResponseJSON,
} from '@simplewebauthn/server';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { audit, auditTx } from '../audit.js';
import { CONSENT, type Ctx } from '../context.js';
import { randomToken, safeEqual, sha256, sha256hex } from '../crypto.js';
import { withTx } from '../db.js';
import type { ChallengeStep } from '../providers/face.js';
import {
  ACTIVE,
  documentBoundChallenge,
  finalizeSignature,
  HttpError,
  newNonce,
  WIPE_BIOMETRICS,
  type ReqMeta,
  type SignerPii,
} from '../sessions.js';
import { enqueueWebhook } from '../webhooks.js';

type P = { Params: { token: string } };
const DEVICE_COOKIE = 'esd';

interface FaceState {
  attempt: number;
  steps: ChallengeStep[];
  idx: number;
  baseline: { yaw: number; pitch: number } | null;
  started_at: number;
  frames: number;
  scores: number[];
}

const shuffle = <T>(a: T[]) => {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor((crypto.getRandomValues(new Uint32Array(1))[0] / 2 ** 32) * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
};

export async function signerRoutes(app: FastifyInstance, ctx: Ctx) {
  const cfg = ctx.cfg;
  const secure = cfg.PUBLIC_ORIGIN.startsWith('https://');

  const deviceHash = (req: FastifyRequest) => {
    const v = req.cookies[DEVICE_COOKIE];
    return v ? sha256hex(`device:${v}`) : null;
  };
  const meta = (req: FastifyRequest): ReqMeta => ({
    ip: req.ip,
    userAgent: String(req.headers['user-agent'] ?? '').slice(0, 300),
    deviceHash: deviceHash(req),
  });

  async function load(req: FastifyRequest<P>, opts: { csrf?: boolean; device?: boolean } = {}) {
    const t = req.params.token;
    if (!/^[A-Za-z0-9_-]{30,60}$/.test(t)) throw new HttpError(404, 'not_found');
    const r = await ctx.db.query(
      `SELECT s.*, d.sha256 AS doc_sha, d.title, d.page_count, d.storage_key, d.signed_storage_key, sg.pii_enc, sg.external_id, sg.id AS sg_id
       FROM signing_sessions s JOIN documents d ON d.id=s.document_id JOIN signers sg ON sg.id=s.signer_id
       WHERE s.token_hash=$1`,
      [sha256(t)],
    );
    const s = r.rows[0];
    if (!s) throw new HttpError(404, 'not_found');
    if ((ACTIVE as readonly string[]).includes(s.status) && new Date(s.expires_at) < new Date()) throw new HttpError(410, 'expired');
    if (opts.csrf) {
      const h = String(req.headers['x-csrf-token'] ?? '');
      if (!s.csrf_hash || !h || !safeEqual(sha256(h), s.csrf_hash)) throw new HttpError(403, 'csrf');
    }
    if (opts.device && s.device_hash) {
      const d = deviceHash(req);
      if (!d || !safeEqual(Buffer.from(d), s.device_hash)) throw new HttpError(403, 'other_device');
    }
    return s;
  }

  const requireStatus = (s: { status: string }, ...st: string[]) => {
    if (!st.includes(s.status)) throw new HttpError(409, 'invalid_state', s.status);
  };

  const logEvent = (s: { id: string; client_id: string }, req: FastifyRequest, event: string, outcome: 'success' | 'failure' | 'info', data?: Record<string, unknown>) =>
    audit(ctx.db, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event, outcome, ...meta(req), data });

  // ---------------------------------------------------------------- bootstrap
  app.get<P>('/api/sign/:token/bootstrap', async (req, reply) => {
    let s;
    try {
      s = await load(req);
    } catch (e) {
      if (e instanceof HttpError && e.code === 'expired') return reply.code(410).send({ status: 'expired' });
      throw e;
    }
    if (!req.cookies[DEVICE_COOKIE]) {
      const v = randomToken(24);
      reply.setCookie(DEVICE_COOKIE, v, { httpOnly: true, secure, sameSite: 'strict', path: '/', maxAge: 60 * 60 * 24 * 400 });
      req.cookies[DEVICE_COOKIE] = v;
    }
    const dh = deviceHash(req)!;
    const deviceOk = !s.device_hash || safeEqual(Buffer.from(dh), s.device_hash);
    let csrf: string | null = null;
    if (deviceOk && (ACTIVE as readonly string[]).includes(s.status)) {
      csrf = randomToken(24);
      await ctx.db.query(
        `UPDATE signing_sessions SET csrf_hash=$2, opened_at=COALESCE(opened_at, now()),
           status=CASE WHEN status='created' THEN 'opened'::session_status ELSE status END, updated_at=now() WHERE id=$1`,
        [s.id, sha256(csrf)],
      );
      if (!s.opened_at) await logEvent(s, req, 'session.opened', 'info');
    }
    const pii = ctx.pii.decryptJson<SignerPii>(s.pii_enc, `signer:${s.sg_id}`);
    const fs = s.face_state as FaceState | null;
    return {
      session_id: s.id,
      status: s.status === 'created' ? 'opened' : s.status,
      csrf,
      device_ok: deviceOk,
      signer_name: pii.full_name,
      loan_reference: s.loan_reference,
      document: { title: s.title, pages: s.page_count, sha256: s.doc_sha },
      summary: s.summary,
      consent: { version: CONSENT.version, text: CONSENT.text },
      document_viewed: !!s.document_viewed_at,
      face: {
        attempts_left: Math.max(0, cfg.FACE_MAX_ATTEMPTS - s.face_attempts),
        in_progress: fs ? { steps: fs.steps, idx: fs.idx } : null,
      },
      expires_at: s.expires_at,
      completed_at: s.completed_at,
      can_download: s.status === 'completed' && deviceOk && s.signed_download_until && new Date(s.signed_download_until) > new Date(),
    };
  });

  // ----------------------------------------------------------------- document
  app.get<P>('/api/sign/:token/document', async (req, reply) => {
    const s = await load(req, { device: true });
    requireStatus(s, ...ACTIVE);
    const pdf = await ctx.store.get(s.storage_key);
    return reply.header('content-type', 'application/pdf').header('cache-control', 'no-store').header('x-document-sha256', s.doc_sha).send(pdf);
  });

  app.post<P>('/api/sign/:token/viewed', async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'opened', 'created');
    const { pages_viewed } = z.object({ pages_viewed: z.number().int().min(0).max(10_000) }).parse(req.body);
    if (pages_viewed < s.page_count) throw new HttpError(422, 'document_not_fully_viewed');
    await ctx.db.query('UPDATE signing_sessions SET document_viewed_at=COALESCE(document_viewed_at, now()), pages_viewed=$2 WHERE id=$1', [s.id, pages_viewed]);
    await logEvent(s, req, 'document.viewed', 'success', { pages_viewed, document_sha256: s.doc_sha });
    return { ok: true };
  });

  // ------------------------------------------------------------------ consent
  app.post<P>('/api/sign/:token/consent', async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'opened');
    const b = z.object({ accepted: z.literal(true), consent_version: z.string(), document_sha256: z.string() }).parse(req.body);
    if (!s.document_viewed_at) throw new HttpError(409, 'document_not_viewed');
    if (b.consent_version !== CONSENT.version) throw new HttpError(409, 'consent_version_changed');
    if (b.document_sha256 !== s.doc_sha) throw new HttpError(409, 'document_mismatch');
    const m = meta(req);
    await withTx(ctx.db, async (tx) => {
      const u = await tx.query(
        `UPDATE signing_sessions SET status='consented', consented_at=now(), device_hash=$2, updated_at=now() WHERE id=$1 AND status='opened' RETURNING id`,
        [s.id, Buffer.from(m.deviceHash!)],
      );
      if (!u.rowCount) throw new HttpError(409, 'invalid_state');
      await tx.query(
        `INSERT INTO consent_records (session_id, signer_id, consent_version, consent_text_sha256, document_sha256, accepted, ip, user_agent, device_hash)
         VALUES ($1,$2,$3,$4,$5,true,$6,$7,$8)`,
        [s.id, s.sg_id, CONSENT.version, sha256hex(CONSENT.text), s.doc_sha, m.ip, m.userAgent, Buffer.from(m.deviceHash!)],
      );
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event: 'consent.recorded', outcome: 'success', ...m,
        data: { consent_version: CONSENT.version, consent_text_sha256: sha256hex(CONSENT.text), document_sha256: s.doc_sha } });
    });
    return { ok: true, status: 'consented' };
  });

  // --------------------------------------------------------------------- face
  app.post<P>('/api/sign/:token/face/start', async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'consented');
    if (s.face_attempts >= cfg.FACE_MAX_ATTEMPTS) throw new HttpError(429, 'face_attempts_exhausted');
    const state: FaceState = {
      attempt: s.face_attempts + 1,
      steps: ['center', ...shuffle<ChallengeStep>(['left', 'right', 'up']).slice(0, 2)],
      idx: 0,
      baseline: null,
      started_at: Date.now(),
      frames: 0,
      scores: [],
    };
    await ctx.db.query('UPDATE signing_sessions SET face_state=$2, face_attempts=face_attempts+1, updated_at=now() WHERE id=$1', [s.id, state]);
    await logEvent(s, req, 'face.challenge_started', 'info', { attempt: state.attempt, steps: state.steps });
    return { steps: state.steps, step: state.steps[0], timeout_seconds: cfg.FACE_TIMEOUT_SECONDS, attempts_left: cfg.FACE_MAX_ATTEMPTS - state.attempt };
  });

  const failFace = async (s: { id: string; client_id: string; face_attempts: number }, req: FastifyRequest, st: FaceState, reason: string) => {
    await withTx(ctx.db, async (tx) => {
      await tx.query('UPDATE signing_sessions SET face_state=NULL, updated_at=now() WHERE id=$1', [s.id]);
      await tx.query(
        `INSERT INTO biometric_verifications (session_id, kind, result, score, provider, details) VALUES ($1,'face_liveness','fail',$2,$3,$4)`,
        [s.id, st.scores.length ? Math.min(...st.scores) : null, ctx.face.name, { reason, attempt: st.attempt, steps: st.steps, completed_steps: st.idx, frames: st.frames }],
      );
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event: 'face.failed', outcome: 'failure', ...meta(req),
        data: { reason, attempt: st.attempt, completed_steps: st.idx } });
    });
    return { done: false, failed: true, reason, attempts_left: Math.max(0, cfg.FACE_MAX_ATTEMPTS - st.attempt) };
  };

  app.post<P>('/api/sign/:token/face/frame', { bodyLimit: 3 * 1024 * 1024, config: { rateLimit: { max: 8, timeWindow: 1000, keyGenerator: (r: FastifyRequest) => `frame:${(r.params as { token: string }).token}` } } }, async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'consented');
    const st = s.face_state as FaceState | null;
    if (!st) throw new HttpError(409, 'face_not_started');
    const { image } = z.object({ image: z.string().min(100).max(3_000_000) }).parse(req.body);

    if (Date.now() - st.started_at > cfg.FACE_TIMEOUT_SECONDS * 1000) return failFace(s, req, st, 'timeout');
    if (st.frames >= 200) return failFace(s, req, st, 'too_many_frames');
    if (!s.reference_embedding_enc) throw new HttpError(409, 'reference_missing');

    const reference = ctx.bio.decrypt(s.reference_embedding_enc, `ref:${s.id}`).toString();
    const step = st.steps[st.idx];
    let r;
    try {
      r = await ctx.face.analyze({ image, reference, step, baseline: st.baseline ?? undefined });
    } catch (e) {
      req.log.error({ err: (e as Error).message }, 'face provider error');
      throw new HttpError(503, 'face_service_unavailable');
    }

    const next: FaceState = { ...st, frames: st.frames + 1 };
    if (r.ok && r.step_passed) {
      if (step === 'center' && r.pose) next.baseline = r.pose;
      if (r.match) next.scores = [...st.scores, r.match.score];
      next.idx = st.idx + 1;
    }
    // Optimistic concurrency: only one frame may advance a given step
    const u = await ctx.db.query(
      `UPDATE signing_sessions SET face_state=$2, updated_at=now() WHERE id=$1 AND status='consented' AND (face_state->>'idx')::int=$3 AND (face_state->>'attempt')::int=$4 RETURNING id`,
      [s.id, next, st.idx, st.attempt],
    );
    if (!u.rowCount) return { done: false, step: st.steps[st.idx], hint: 'busy', progress: st.idx };

    if (next.idx < next.steps.length) {
      return { done: false, step: next.steps[next.idx], hint: r.ok ? r.hint ?? null : r.code, progress: next.idx, total: next.steps.length };
    }

    // all steps passed
    const score = Math.min(...next.scores);
    await withTx(ctx.db, async (tx) => {
      const v = await tx.query(
        `UPDATE signing_sessions SET status='face_verified', face_verified_at=now(), face_state=NULL, updated_at=now() WHERE id=$1 AND status='consented' RETURNING id`,
        [s.id],
      );
      if (!v.rowCount) throw new HttpError(409, 'invalid_state');
      await tx.query(
        `INSERT INTO biometric_verifications (session_id, kind, result, score, provider, details) VALUES ($1,'face_liveness','pass',$2,$3,$4)`,
        [s.id, score, ctx.face.name, { attempt: next.attempt, steps: next.steps, frames: next.frames, duration_ms: Date.now() - next.started_at, scores: next.scores }],
      );
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event: 'face.verified', outcome: 'success', ...meta(req),
        data: { score, steps: next.steps, frames: next.frames, provider: ctx.face.name } });
    });
    return { done: true, status: 'face_verified', progress: next.steps.length, total: next.steps.length };
  });

  // ----------------------------------------------------------------- webauthn
  const rpOrigin = cfg.PUBLIC_ORIGIN;
  const userIdFor = (signerId: string) => sha256(`webauthn-user:${signerId}`).subarray(0, 32);

  const authOptions = async (s: { id: string; doc_sha: string; sg_id: string }) => {
    const creds = await ctx.db.query('SELECT credential_id, transports FROM webauthn_credentials WHERE signer_id=$1 AND revoked_at IS NULL', [s.sg_id]);
    if (!creds.rowCount) return null;
    const nonce = newNonce();
    const challenge = documentBoundChallenge(s.id, s.doc_sha, nonce);
    const opts = await generateAuthenticationOptions({
      rpID: cfg.RP_ID,
      challenge: Buffer.from(challenge, 'base64url'),
      userVerification: 'required',
      timeout: 120_000,
      allowCredentials: creds.rows.map((c) => ({ id: c.credential_id, transports: c.transports })),
    });
    return { opts, nonce, challenge: opts.challenge };
  };

  app.post<P>('/api/sign/:token/webauthn/options', { config: { rateLimit: { max: 20, timeWindow: 60_000 } } }, async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'face_verified');
    const a = await authOptions(s);
    const state: Record<string, unknown> = { ...(s.webauthn_state ?? {}) };
    if (a) {
      state.auth = { challenge: a.challenge, nonce: a.nonce, at: Date.now() };
      await ctx.db.query('UPDATE signing_sessions SET webauthn_state=$2 WHERE id=$1', [s.id, state]);
      return { mode: 'authenticate', options: a.opts, can_register_new_device: true };
    }
    return { mode: 'register' };
  });

  app.post<P>('/api/sign/:token/webauthn/register/options', { config: { rateLimit: { max: 10, timeWindow: 60_000 } } }, async (req) => {
    const s = await load(req, { csrf: true, device: true });
    // Enrolling a passkey is only possible right after a successful face match in THIS session
    requireStatus(s, 'face_verified');
    const pii = ctx.pii.decryptJson<SignerPii>(s.pii_enc, `signer:${s.sg_id}`);
    const existing = await ctx.db.query('SELECT credential_id, transports FROM webauthn_credentials WHERE signer_id=$1 AND revoked_at IS NULL', [s.sg_id]);
    const opts = await generateRegistrationOptions({
      rpName: cfg.RP_NAME,
      rpID: cfg.RP_ID,
      userName: s.external_id,
      userDisplayName: pii.full_name,
      userID: userIdFor(s.sg_id),
      attestationType: 'none',
      timeout: 120_000,
      excludeCredentials: existing.rows.map((c) => ({ id: c.credential_id, transports: c.transports })),
      authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'preferred' },
      supportedAlgorithmIDs: [-7, -257],
    });
    const state = { ...(s.webauthn_state ?? {}), reg: { challenge: opts.challenge, at: Date.now() } };
    await ctx.db.query('UPDATE signing_sessions SET webauthn_state=$2 WHERE id=$1', [s.id, state]);
    return { options: opts };
  });

  app.post<P>('/api/sign/:token/webauthn/register', { config: { rateLimit: { max: 10, timeWindow: 60_000 } } }, async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'face_verified');
    const reg = s.webauthn_state?.reg as { challenge: string; at: number } | undefined;
    if (!reg || Date.now() - reg.at > 180_000) throw new HttpError(409, 'challenge_expired');
    const response = req.body as RegistrationResponseJSON;
    let v;
    try {
      v = await verifyRegistrationResponse({
        response, expectedChallenge: reg.challenge, expectedOrigin: rpOrigin, expectedRPID: cfg.RP_ID, requireUserVerification: true,
      });
    } catch (e) {
      await logEvent(s, req, 'webauthn.registration_failed', 'failure', { error: (e as Error).message.slice(0, 200) });
      throw new HttpError(400, 'webauthn_registration_failed');
    }
    if (!v.verified) throw new HttpError(400, 'webauthn_registration_failed');
    const info = v.registrationInfo;
    await withTx(ctx.db, async (tx) => {
      await tx.query(
        `INSERT INTO webauthn_credentials (signer_id, credential_id, public_key, counter, transports, aaguid, device_type, backed_up, registered_in_session)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [s.sg_id, info.credential.id, Buffer.from(info.credential.publicKey), info.credential.counter, info.credential.transports ?? [],
          info.aaguid, info.credentialDeviceType, info.credentialBackedUp, s.id],
      );
      await tx.query(
        `UPDATE signing_sessions SET webauthn_state = (COALESCE(webauthn_state,'{}'::jsonb) - 'reg') || jsonb_build_object('new_device', $2::text) WHERE id=$1`,
        [s.id, info.credential.id],
      );
      await tx.query(
        `INSERT INTO biometric_verifications (session_id, kind, result, provider, details) VALUES ($1,'webauthn_registration','pass','webauthn',$2)`,
        [s.id, { credential_id: info.credential.id, aaguid: info.aaguid, device_type: info.credentialDeviceType, user_verified: info.userVerified }],
      );
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event: 'webauthn.device_enrolled', outcome: 'success', ...meta(req),
        data: { credential_id: info.credential.id, aaguid: info.aaguid, after: 'face_verified' } });
    });
    const s2 = await load(req, { csrf: true, device: true });
    const a = await authOptions(s2);
    await ctx.db.query('UPDATE signing_sessions SET webauthn_state = COALESCE(webauthn_state,\'{}\'::jsonb) || jsonb_build_object(\'auth\', $2::jsonb) WHERE id=$1', [
      s.id, { challenge: a!.challenge, nonce: a!.nonce, at: Date.now() },
    ]);
    return { mode: 'authenticate', options: a!.opts };
  });

  app.post<P>('/api/sign/:token/webauthn/authenticate', { config: { rateLimit: { max: 10, timeWindow: 60_000 } } }, async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, 'face_verified');
    const auth = s.webauthn_state?.auth as { challenge: string; nonce: string; at: number } | undefined;
    if (!auth || Date.now() - auth.at > 180_000) throw new HttpError(409, 'challenge_expired');
    // Re-derive: the challenge must commit to this session + exact document hash
    if (auth.challenge !== documentBoundChallenge(s.id, s.doc_sha, auth.nonce)) throw new HttpError(409, 'challenge_mismatch');
    const response = req.body as AuthenticationResponseJSON;
    const c = await ctx.db.query('SELECT * FROM webauthn_credentials WHERE credential_id=$1 AND signer_id=$2 AND revoked_at IS NULL', [response?.id, s.sg_id]);
    if (!c.rowCount) throw new HttpError(400, 'unknown_credential');
    const cred = c.rows[0];
    let v;
    try {
      v = await verifyAuthenticationResponse({
        response, expectedChallenge: auth.challenge, expectedOrigin: rpOrigin, expectedRPID: cfg.RP_ID, requireUserVerification: true,
        credential: { id: cred.credential_id, publicKey: new Uint8Array(cred.public_key), counter: Number(cred.counter), transports: cred.transports },
      });
    } catch (e) {
      v = null;
      req.log.warn({ err: (e as Error).message }, 'webauthn assertion failed');
    }
    if (!v?.verified || !v.authenticationInfo.userVerified) {
      await ctx.db.query(
        `INSERT INTO biometric_verifications (session_id, kind, result, provider, details) VALUES ($1,'webauthn_assertion','fail','webauthn',$2)`,
        [s.id, { credential_id: cred.credential_id }],
      );
      await logEvent(s, req, 'webauthn.assertion_failed', 'failure', { credential_id: cred.credential_id });
      throw new HttpError(400, 'webauthn_failed');
    }
    // Consume challenge (no replay) and bump counter
    const consumed = await ctx.db.query(
      `UPDATE signing_sessions SET webauthn_state = webauthn_state - 'auth' WHERE id=$1 AND webauthn_state->'auth'->>'challenge'=$2 RETURNING id`,
      [s.id, auth.challenge],
    );
    if (!consumed.rowCount) throw new HttpError(409, 'challenge_replayed');
    await ctx.db.query('UPDATE webauthn_credentials SET counter=$2, last_used_at=now() WHERE id=$1', [cred.id, v.authenticationInfo.newCounter]);
    await ctx.db.query(
      `INSERT INTO biometric_verifications (session_id, kind, result, provider, details) VALUES ($1,'webauthn_assertion','pass','webauthn',$2)`,
      [s.id, { credential_id: cred.credential_id, user_verified: true, counter: v.authenticationInfo.newCounter, document_bound: true }],
    );
    await logEvent(s, req, 'webauthn.assertion_verified', 'success', { credential_id: cred.credential_id, document_sha256: s.doc_sha });

    try {
      const r = await finalizeSignature(
        ctx,
        s.id,
        {
          credentialId: cred.credential_id,
          newDevice: s.webauthn_state?.new_device === cred.credential_id,
          userVerified: true,
          deviceType: v.authenticationInfo.credentialDeviceType,
          evidence: {
            credential_id: cred.credential_id,
            challenge: auth.challenge,
            challenge_derivation: 'base64url(sha256("ESIGN-v1|" + session_id + "|" + document_sha256 + "|" + nonce))',
            nonce: auth.nonce,
            client_data_json: response.response.clientDataJSON,
            authenticator_data: response.response.authenticatorData,
            signature: response.response.signature,
            public_key_cose_b64: Buffer.from(cred.public_key).toString('base64'),
          },
        },
        meta(req),
      );
      return { status: 'completed', completed_at: r.completedAt, signed_document_sha256: r.signedSha256 };
    } catch (e) {
      await logEvent(s, req, 'signature.finalize_failed', 'failure', { error: (e as Error).message.slice(0, 200) });
      throw e instanceof HttpError ? e : new HttpError(503, 'signing_failed');
    }
  });

  // ----------------------------------------------------------- after signing
  app.get<P>('/api/sign/:token/signed-document', async (req, reply: FastifyReply) => {
    const s = await load(req, { device: true });
    requireStatus(s, 'completed');
    if (!s.signed_download_until || new Date(s.signed_download_until) < new Date()) throw new HttpError(410, 'download_expired');
    const pdf = await ctx.store.get(s.signed_storage_key);
    await logEvent(s, req, 'signed_document.downloaded', 'info');
    return reply
      .header('content-type', 'application/pdf')
      .header('cache-control', 'no-store')
      .header('content-disposition', `attachment; filename="signed-contract-${s.loan_reference.replace(/[^\w.-]/g, '_')}.pdf"`)
      .send(pdf);
  });

  // Safe fallback: hand the case to a bank officer for documented in-branch signing
  app.post<P>('/api/sign/:token/manual', async (req) => {
    const s = await load(req, { csrf: true, device: true });
    requireStatus(s, ...ACTIVE);
    const { reason } = z.object({ reason: z.string().max(300).default('') }).parse(req.body ?? {});
    await withTx(ctx.db, async (tx) => {
      await tx.query(`UPDATE signing_sessions SET status='manual_review', failure_reason=$2, ${WIPE_BIOMETRICS}, updated_at=now() WHERE id=$1`, [s.id, reason || 'signer_requested']);
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: 'signer', event: 'session.manual_review_requested', outcome: 'info', ...meta(req), data: { reason } });
      await enqueueWebhook(tx, ctx, {
        clientId: s.client_id, sessionId: s.id, event: 'session.manual_review', urlOverride: s.callback_url,
        payload: { session_id: s.id, loan_reference: s.loan_reference, status: 'manual_review', reason: reason || 'signer_requested' },
      });
    });
    return { status: 'manual_review' };
  });
}
