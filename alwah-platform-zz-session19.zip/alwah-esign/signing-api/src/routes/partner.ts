/**
 * Server-to-server API used by the Alwah platform (Bearer API key).
 */
import crypto from 'node:crypto';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { auditTx, verifyChain } from '../audit.js';
import type { Ctx } from '../context.js';
import { canonical, maskId, randomToken, sha256, sha256hex } from '../crypto.js';
import { withTx } from '../db.js';
import { inspectPdf, withContractFonts } from '../pdf.js';
import { ACTIVE, HttpError, WIPE_BIOMETRICS, type SignerPii } from '../sessions.js';
import { enqueueWebhook } from '../webhooks.js';

interface Client {
  id: string;
  name: string;
  ip_allowlist: string[];
}
declare module 'fastify' {
  interface FastifyRequest {
    client?: Client;
  }
}

const createSchema = z.object({
  loan_reference: z.string().min(1).max(100),
  document: z.object({
    title: z.string().min(1).max(200),
    filename: z.string().min(1).max(200).default('contract.pdf'),
    // Either a ready PDF (base64) or an Arabic HTML contract rendered here with Chromium (fonts embedded, no network).
    content_base64: z.string().min(100).optional(),
    content_html: z.string().min(50).max(3_000_000).optional(),
  }).refine((d) => !!d.content_base64 !== !!d.content_html, { message: 'content_base64_or_content_html_required' }),
  signer: z.object({
    external_id: z.string().min(1).max(100),
    full_name: z.string().min(3).max(200),
    phone: z.string().max(30).optional().nullable(),
    national_id: z.string().max(40).optional().nullable(),
  }),
  // KYC reference photo of the customer (verified ID photo or branch selfie). Used to compute a
  // temporary face embedding, then discarded. The image itself is never stored.
  reference_face_base64: z.string().min(100),
  summary: z.record(z.string().max(80), z.union([z.string().max(300), z.number()])).default({}),
  expires_in_minutes: z.number().int().min(10).max(60 * 24 * 14).optional(),
  callback_url: z.string().url().optional(),
});

export async function partnerRoutes(app: FastifyInstance, ctx: Ctx) {
  const cache = new Map<string, { c: Client | null; at: number }>();

  app.addHook('onRequest', async (req: FastifyRequest) => {
    const h = req.headers.authorization ?? '';
    const key = h.startsWith('Bearer ') ? h.slice(7).trim() : '';
    if (key.length < 20) throw new HttpError(401, 'unauthorized');
    const kh = sha256hex(key);
    let hit = cache.get(kh);
    if (!hit || Date.now() - hit.at > 60_000) {
      const r = await ctx.db.query('SELECT id, name, ip_allowlist FROM api_clients WHERE key_hash=$1 AND active', [sha256(key)]);
      hit = { c: r.rows[0] ?? null, at: Date.now() };
      cache.set(kh, hit);
    }
    if (!hit.c) throw new HttpError(401, 'unauthorized');
    if (hit.c.ip_allowlist.length && !hit.c.ip_allowlist.includes(req.ip)) throw new HttpError(403, 'ip_not_allowed');
    req.client = hit.c;
  });

  const meta = (req: FastifyRequest) => ({ ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '').slice(0, 300) });

  // ------------------------------------------------------------ create session
  app.post('/v1/sessions', { bodyLimit: (ctx.cfg.MAX_DOCUMENT_MB * 1.4 + 6) * 1024 * 1024 }, async (req, reply) => {
    const client = req.client!;
    const body = createSchema.parse(req.body);
    const idemKey = String(req.headers['idempotency-key'] ?? '').slice(0, 100);
    const reqHash = sha256hex(canonical(body));

    if (idemKey) {
      const ins = await ctx.db.query(
        `INSERT INTO idempotency_keys (client_id, key, request_hash) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING key`,
        [client.id, idemKey, reqHash],
      );
      if (!ins.rowCount) {
        const prev = await ctx.db.query('SELECT * FROM idempotency_keys WHERE client_id=$1 AND key=$2', [client.id, idemKey]);
        const p = prev.rows[0];
        if (p.request_hash !== reqHash) throw new HttpError(422, 'idempotency_key_reused');
        if (!p.response) throw new HttpError(409, 'request_in_progress');
        return reply.code(p.status_code).header('idempotent-replay', 'true').send(p.response);
      }
    }

    try {
      const doc = body.document.content_html
        ? await ctx.renderer.htmlToPdf(withContractFonts(body.document.content_html))
        : Buffer.from(body.document.content_base64!, 'base64');
      if (doc.length > ctx.cfg.MAX_DOCUMENT_MB * 1024 * 1024) throw new HttpError(413, 'document_too_large');
      let pageCount: number;
      try {
        ({ pageCount } = await inspectPdf(doc));
      } catch (e) {
        throw new HttpError(422, (e as Error).message === 'encrypted_pdf' ? 'document_encrypted' : 'document_not_pdf');
      }

      const ref = await ctx.face.reference(body.reference_face_base64);
      if (!ref.ok || !ref.embedding) throw new HttpError(422, `reference_face_${ref.code ?? 'invalid'}`);

      const docSha = sha256hex(doc);
      const storageKey = await ctx.store.put('original', doc);
      const token = randomToken(32);
      const ttl = body.expires_in_minutes ?? ctx.cfg.SESSION_DEFAULT_TTL_MINUTES;
      const expiresAt = new Date(Date.now() + ttl * 60_000);

      const result = await withTx(ctx.db, async (tx) => {
        const sg = await tx.query(
          `INSERT INTO signers (client_id, external_id, pii_enc) VALUES ($1,$2,'\\x00')
           ON CONFLICT (client_id, external_id) DO UPDATE SET updated_at=now() RETURNING id`,
          [client.id, body.signer.external_id],
        );
        const signerId: string = sg.rows[0].id;
        const pii: SignerPii = { full_name: body.signer.full_name, phone: body.signer.phone ?? null, national_id: body.signer.national_id ?? null };
        await tx.query('UPDATE signers SET pii_enc=$2 WHERE id=$1', [signerId, ctx.pii.encryptJson(pii, `signer:${signerId}`)]);

        const d = await tx.query(
          `INSERT INTO documents (client_id, title, filename, size_bytes, page_count, sha256, storage_key)
           VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
          [client.id, body.document.title, body.document.filename, doc.length, pageCount, docSha, storageKey],
        );
        const sessionId = crypto.randomUUID();
        try {
          await tx.query(
            `INSERT INTO signing_sessions (id, client_id, signer_id, document_id, loan_reference, summary, token_hash, expires_at,
               callback_url, reference_embedding_enc)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [sessionId, client.id, signerId, d.rows[0].id, body.loan_reference, body.summary, sha256(token), expiresAt,
              body.callback_url ?? null, ctx.bio.encrypt(ref.embedding!, `ref:${sessionId}`)],
          );
        } catch (e) {
          if ((e as { code?: string }).code === '23505') throw new HttpError(409, 'active_session_exists_for_loan');
          throw e;
        }
        await auditTx(tx, {
          clientId: client.id, sessionId, actor: `client:${client.name}`, event: 'session.created', outcome: 'success', ...meta(req),
          data: { loan_reference: body.loan_reference, document_sha256: docSha, pages: pageCount, signer_external_id: body.signer.external_id,
            national_id: maskId(body.signer.national_id), expires_at: expiresAt.toISOString(), reference_quality: ref.quality ?? null },
        });
        return { sessionId };
      });

      const response = {
        session_id: result.sessionId,
        status: 'created',
        signing_url: `${ctx.cfg.PUBLIC_ORIGIN}/s/${token}`,
        expires_at: expiresAt.toISOString(),
        document_sha256: docSha,
      };
      if (idemKey) {
        await ctx.db.query('UPDATE idempotency_keys SET status_code=201, response=$3 WHERE client_id=$1 AND key=$2', [client.id, idemKey, response]);
      }
      return reply.code(201).send(response);
    } catch (e) {
      if (idemKey) await ctx.db.query('DELETE FROM idempotency_keys WHERE client_id=$1 AND key=$2', [client.id, idemKey]);
      throw e;
    }
  });

  // ---------------------------------------------------------------- status
  const loadOwned = async (req: FastifyRequest, id: string) => {
    if (!/^[0-9a-f-]{36}$/i.test(id)) throw new HttpError(404, 'not_found');
    const r = await ctx.db.query(
      `SELECT s.*, d.sha256 AS doc_sha, d.signed_sha256, d.signed_storage_key, d.title, sg.external_id
       FROM signing_sessions s JOIN documents d ON d.id=s.document_id JOIN signers sg ON sg.id=s.signer_id
       WHERE s.id=$1 AND s.client_id=$2`,
      [id, req.client!.id],
    );
    if (!r.rowCount) throw new HttpError(404, 'not_found');
    return r.rows[0];
  };

  app.get<{ Params: { id: string } }>('/v1/sessions/:id', async (req) => {
    const s = await loadOwned(req, req.params.id);
    const bio = await ctx.db.query(
      'SELECT kind, result, score, provider, details, created_at FROM biometric_verifications WHERE session_id=$1 ORDER BY created_at',
      [s.id],
    );
    const cert = await ctx.db.query(
      'SELECT ca_provider, certificate_serial, subject, issuer, not_before, not_after, tsa_provider, timestamp_time FROM signature_certificates WHERE session_id=$1',
      [s.id],
    );
    return {
      session_id: s.id,
      loan_reference: s.loan_reference,
      status: s.status,
      failure_reason: s.failure_reason,
      signer_external_id: s.external_id,
      document: { title: s.title, sha256: s.doc_sha, signed_sha256: s.signed_sha256 },
      timeline: {
        created_at: s.created_at, opened_at: s.opened_at, document_viewed_at: s.document_viewed_at, consented_at: s.consented_at,
        face_verified_at: s.face_verified_at, webauthn_verified_at: s.webauthn_verified_at, completed_at: s.completed_at, expires_at: s.expires_at,
      },
      face_attempts: s.face_attempts,
      verifications: bio.rows,
      certificate: cert.rows[0] ?? null,
    };
  });

  app.get<{ Params: { id: string } }>('/v1/sessions/:id/signed-document', async (req, reply) => {
    const s = await loadOwned(req, req.params.id);
    if (s.status !== 'completed' || !s.signed_storage_key) throw new HttpError(409, 'not_signed');
    const pdf = await ctx.store.get(s.signed_storage_key);
    return reply
      .header('content-type', 'application/pdf')
      .header('content-disposition', `attachment; filename="signed-${s.loan_reference.replace(/[^\w.-]/g, '_')}.pdf"`)
      .header('x-document-sha256', s.signed_sha256)
      .send(pdf);
  });

  app.get<{ Params: { id: string } }>('/v1/sessions/:id/audit', async (req) => {
    const s = await loadOwned(req, req.params.id);
    const r = await ctx.db.query(
      `SELECT seq, at, actor, event, outcome, host(ip) AS ip, user_agent, device_hash, data, prev_hash, hash
       FROM audit_logs WHERE session_id=$1 ORDER BY seq`,
      [s.id],
    );
    return { session_id: s.id, entries: r.rows };
  });

  app.post<{ Params: { id: string } }>('/v1/sessions/:id/cancel', async (req) => {
    const s = await loadOwned(req, req.params.id);
    await withTx(ctx.db, async (tx) => {
      const u = await tx.query(
        `UPDATE signing_sessions SET status='cancelled', ${WIPE_BIOMETRICS}, updated_at=now()
         WHERE id=$1 AND status = ANY($2::session_status[]) RETURNING id`,
        [s.id, ACTIVE],
      );
      if (!u.rowCount) throw new HttpError(409, 'not_cancellable');
      await auditTx(tx, { clientId: s.client_id, sessionId: s.id, actor: `client:${req.client!.name}`, event: 'session.cancelled', outcome: 'info', ...meta(req) });
      await enqueueWebhook(tx, ctx, {
        clientId: s.client_id, sessionId: s.id, event: 'session.cancelled', urlOverride: s.callback_url,
        payload: { session_id: s.id, loan_reference: s.loan_reference, status: 'cancelled' },
      });
    });
    return { session_id: s.id, status: 'cancelled' };
  });

  app.post<{ Params: { externalId: string } }>('/v1/signers/:externalId/revoke-devices', async (req) => {
    const r = await withTx(ctx.db, async (tx) => {
      const u = await tx.query(
        `UPDATE webauthn_credentials w SET revoked_at=now() FROM signers s
         WHERE w.signer_id=s.id AND s.client_id=$1 AND s.external_id=$2 AND w.revoked_at IS NULL RETURNING w.id`,
        [req.client!.id, req.params.externalId],
      );
      await auditTx(tx, { clientId: req.client!.id, actor: `client:${req.client!.name}`, event: 'signer.devices_revoked', outcome: 'info',
        ...meta(req), data: { signer_external_id: req.params.externalId, count: u.rowCount } });
      return u.rowCount;
    });
    return { revoked: r };
  });

  app.get('/v1/audit/verify', async () => verifyChain(ctx.db));
}
