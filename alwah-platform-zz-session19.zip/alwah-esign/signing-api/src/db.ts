import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

export type Db = pg.Pool;
export type Tx = pg.PoolClient;

export function createPool(url: string): Db {
  const pool = new pg.Pool({ connectionString: url, max: Number(process.env.DB_POOL_MAX ?? 20), idleTimeoutMillis: 30_000 });
  pool.on('error', (e) => console.error('pg pool error', e.message));
  return pool;
}

export async function withTx<T>(db: Db, fn: (tx: Tx) => Promise<T>): Promise<T> {
  const tx = await db.connect();
  try {
    await tx.query('BEGIN');
    const r = await fn(tx);
    await tx.query('COMMIT');
    return r;
  } catch (e) {
    await tx.query('ROLLBACK').catch(() => undefined);
    throw e;
  } finally {
    tx.release();
  }
}

const migrationsDir = () => {
  const here = path.dirname(fileURLToPath(import.meta.url));
  return path.join(here, 'migrations');
};

export async function migrate(db: Db, log: (m: string) => void = console.log) {
  await db.query('SELECT pg_advisory_lock(7347001)');
  try {
    await db.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
    const done = new Set((await db.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name as string));
    const files = (await fs.readdir(migrationsDir())).filter((f) => f.endsWith('.sql')).sort();
    for (const f of files) {
      if (done.has(f)) continue;
      const sql = await fs.readFile(path.join(migrationsDir(), f), 'utf8');
      await withTx(db, async (tx) => {
        await tx.query(sql);
        await tx.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
      });
      log(`migration applied: ${f}`);
    }
  } finally {
    await db.query('SELECT pg_advisory_unlock(7347001)');
  }
}
