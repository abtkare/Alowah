import type { Ctx } from './context.js';
import type { Tx } from './db.js';
import { hmacHex } from './crypto.js';

export async function enqueueWebhook(
  tx: Tx,
  ctx: Ctx,
  o: { clientId: string; sessionId: string; event: string; payload: Record<string, unknown>; urlOverride?: string | null },
) {
  const c = await tx.query('SELECT webhook_url FROM api_clients WHERE id=$1', [o.clientId]);
  const url = o.urlOverride || c.rows[0]?.webhook_url;
  if (!url) return;
  await tx.query(
    `INSERT INTO webhook_deliveries (client_id, session_id, url, event, payload) VALUES ($1,$2,$3,$4,$5)`,
    [o.clientId, o.sessionId, url, o.event, { event: o.event, created_at: new Date().toISOString(), data: o.payload }],
  );
  void ctx;
}

/** Delivers due webhooks. Safe to run on several replicas (SKIP LOCKED). */
export async function deliverDueWebhooks(ctx: Ctx, log: (m: string) => void) {
  const tx = await ctx.db.connect();
  try {
    await tx.query('BEGIN');
    const { rows } = await tx.query(
      `SELECT d.*, c.webhook_secret_enc FROM webhook_deliveries d JOIN api_clients c ON c.id=d.client_id
       WHERE d.delivered_at IS NULL AND d.attempts < 12 AND d.next_attempt_at <= now()
       ORDER BY d.next_attempt_at LIMIT 20 FOR UPDATE OF d SKIP LOCKED`,
    );
    for (const d of rows) {
      const body = JSON.stringify({ id: d.id, ...d.payload });
      const ts = Math.floor(Date.now() / 1000).toString();
      const secret = d.webhook_secret_enc ? ctx.secrets.decrypt(d.webhook_secret_enc, 'webhook').toString() : '';
      let err: string | null = null;
      try {
        const res = await fetch(d.url, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-esign-event': d.event,
            'x-esign-delivery': d.id,
            'x-esign-timestamp': ts,
            'x-esign-signature': `sha256=${hmacHex(secret, `${ts}.${body}`)}`,
          },
          body,
          signal: AbortSignal.timeout(10_000),
        });
        if (!res.ok) err = `HTTP ${res.status}`;
      } catch (e) {
        err = (e as Error).message;
      }
      if (err) {
        const delayMin = Math.min(2 ** d.attempts, 360);
        await tx.query(
          `UPDATE webhook_deliveries SET attempts=attempts+1, last_error=$2, next_attempt_at=now() + ($3 || ' minutes')::interval WHERE id=$1`,
          [d.id, err.slice(0, 500), String(delayMin)],
        );
        log(`webhook ${d.event} -> ${d.url} failed: ${err}`);
      } else {
        await tx.query('UPDATE webhook_deliveries SET attempts=attempts+1, delivered_at=now(), last_error=NULL WHERE id=$1', [d.id]);
      }
    }
    await tx.query('COMMIT');
  } catch (e) {
    await tx.query('ROLLBACK').catch(() => undefined);
    throw e;
  } finally {
    tx.release();
  }
}
