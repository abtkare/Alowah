import { z } from 'zod';

const bool = z
  .string()
  .optional()
  .transform((v) => v === 'true' || v === '1');

const schema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('production'),
  PORT: z.coerce.number().default(8080),
  HOST: z.string().default('0.0.0.0'),
  LOG_LEVEL: z.string().default('info'),

  // Public URL where signers open the signing page, e.g. https://sign.alwah.iq
  PUBLIC_ORIGIN: z.string().url(),
  // WebAuthn relying-party id = the bare domain of PUBLIC_ORIGIN (e.g. sign.alwah.iq or alwah.iq)
  RP_ID: z.string().min(3),
  RP_NAME: z.string().default('منصة ألواح - التوقيع الإلكتروني'),

  DATABASE_URL: z.string().min(10),
  REDIS_URL: z.string().min(5),

  // 32-byte key, base64. Encrypts PII, documents at rest, CA key, reference face embeddings.
  MASTER_KEY: z.string().refine((v) => Buffer.from(v, 'base64').length === 32, 'MASTER_KEY must be 32 bytes base64'),

  FACE_SERVICE_URL: z.string().url().default('http://face-service:8001'),
  FACE_SERVICE_TOKEN: z.string().min(16),
  FACE_PROVIDER: z.enum(['local', 'mock']).default('local'),
  FACE_MAX_ATTEMPTS: z.coerce.number().default(3),
  FACE_TIMEOUT_SECONDS: z.coerce.number().default(90),

  CA_PROVIDER: z.enum(['local-dev', 'remote']).default('local-dev'),
  CA_REMOTE_URL: z.string().optional(),
  CA_REMOTE_API_KEY: z.string().optional(),
  TSA_PROVIDER: z.enum(['local', 'rfc3161']).default('local'),
  TSA_URL: z.string().optional(),

  DATA_DIR: z.string().default('/data'),
  CHROMIUM_PATH: z.string().default('/usr/bin/chromium'),

  SESSION_DEFAULT_TTL_MINUTES: z.coerce.number().default(60 * 24),
  SIGNED_DOWNLOAD_DAYS: z.coerce.number().default(7),
  RETENTION_UNSIGNED_DAYS: z.coerce.number().default(30),
  MAX_DOCUMENT_MB: z.coerce.number().default(15),

  // Bootstrap the Alwah API client on start (optional; can also use `npm run create-client`)
  BOOTSTRAP_CLIENT_NAME: z.string().default('alwah'),
  BOOTSTRAP_CLIENT_API_KEY: z.string().optional(),
  BOOTSTRAP_CLIENT_WEBHOOK_URL: z.string().optional(),
  BOOTSTRAP_CLIENT_WEBHOOK_SECRET: z.string().optional(),

  TRUST_PROXY: bool,
});

export type Config = z.infer<typeof schema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const parsed = schema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Invalid configuration:\n${issues}`);
  }
  const c = parsed.data;
  if (c.NODE_ENV === 'production' && c.FACE_PROVIDER === 'mock') {
    throw new Error('FACE_PROVIDER=mock is forbidden in production');
  }
  if (c.CA_PROVIDER === 'remote' && !c.CA_REMOTE_URL) throw new Error('CA_REMOTE_URL required for remote CA');
  if (c.TSA_PROVIDER === 'rfc3161' && !c.TSA_URL) throw new Error('TSA_URL required for rfc3161 TSA');
  return c;
}
