import { createContext } from './bootstrap.js';
import { startJobs } from './jobs.js';
import { buildServer } from './server.js';

const ctx = await createContext();
const app = await buildServer(ctx);
const stopJobs = startJobs(ctx, { info: (m) => app.log.info(m), error: (o, m) => app.log.error(o, m) });

await app.listen({ port: ctx.cfg.PORT, host: ctx.cfg.HOST });
app.log.info(`e-sign service ready | CA=${ctx.ca.name} qualified=${ctx.ca.qualified} | face=${ctx.face.name} | tsa=${ctx.tsa.name}`);
if (!ctx.ca.qualified) app.log.warn('Running with a NON-licensed development CA. Signatures are not legally qualified until a licensed CA is connected.');

const shutdown = async (sig: string) => {
  app.log.info(`${sig} received, shutting down`);
  stopJobs();
  await app.close();
  await ctx.renderer.close();
  await ctx.db.end();
  ctx.redis.disconnect();
  process.exit(0);
};
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
