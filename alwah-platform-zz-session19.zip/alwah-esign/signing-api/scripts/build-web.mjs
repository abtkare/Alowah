// Bundles the signing page and copies pdf.js runtime assets + fonts into web-dist/
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';

const out = 'web-dist';
await fs.rm(out, { recursive: true, force: true });
await fs.mkdir(`${out}/fonts`, { recursive: true });

await build({
  entryPoints: ['web/app.ts'],
  bundle: true,
  format: 'esm',
  target: ['es2020', 'safari15', 'chrome90'],
  minify: true,
  outfile: `${out}/app.js`,
  legalComments: 'external',
  logLevel: 'warning',
});

await fs.copyFile('web/index.html', `${out}/index.html`);
await fs.copyFile('web/styles.css', `${out}/styles.css`);

const pdfjs = 'node_modules/pdfjs-dist';
await fs.mkdir(`${out}/pdfjs`, { recursive: true });
await fs.copyFile(`${pdfjs}/legacy/build/pdf.worker.min.mjs`, `${out}/pdfjs/pdf.worker.min.mjs`);
for (const d of ['cmaps', 'standard_fonts', 'wasm']) await fs.cp(`${pdfjs}/${d}`, `${out}/pdfjs/${d}`, { recursive: true });

const f = 'node_modules/@fontsource/ibm-plex-sans-arabic/files';
const fonts = {
  'plex-ar-400.woff2': 'ibm-plex-sans-arabic-arabic-400-normal.woff2',
  'plex-ar-500.woff2': 'ibm-plex-sans-arabic-arabic-500-normal.woff2',
  'plex-ar-700.woff2': 'ibm-plex-sans-arabic-arabic-700-normal.woff2',
  'plex-latin-400.woff2': 'ibm-plex-sans-arabic-latin-400-normal.woff2',
  'plex-latin-700.woff2': 'ibm-plex-sans-arabic-latin-700-normal.woff2',
};
for (const [to, from] of Object.entries(fonts)) await fs.copyFile(path.join(f, from), `${out}/fonts/${to}`);
console.log('web build ok');
