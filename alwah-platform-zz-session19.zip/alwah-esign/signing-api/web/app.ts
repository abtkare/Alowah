/* Signing page — Arabic RTL, mobile first. All decisions are verified server-side;
   this page only guides the user and forwards evidence. */
import {
  browserSupportsWebAuthn,
  platformAuthenticatorIsAvailable,
  startAuthentication,
  startRegistration,
} from '@simplewebauthn/browser';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';

pdfjs.GlobalWorkerOptions.workerSrc = '/assets/pdfjs/pdf.worker.min.mjs';

type Status = 'opened' | 'consented' | 'face_verified' | 'completed' | 'failed' | 'expired' | 'cancelled' | 'manual_review';
interface Boot {
  status: Status;
  csrf: string | null;
  device_ok: boolean;
  signer_name: string;
  loan_reference: string;
  document: { title: string; pages: number; sha256: string };
  summary: Record<string, string | number>;
  consent: { version: string; text: string };
  document_viewed: boolean;
  face: { attempts_left: number; in_progress: unknown };
  expires_at: string;
  completed_at: string | null;
  can_download: boolean;
  session_id: string;
}

const token = location.pathname.split('/').filter(Boolean)[1] ?? '';
const api = (p: string) => `/api/sign/${token}${p}`;
const app = document.getElementById('app')!;
let boot: Boot;

// ------------------------------------------------------------------ helpers
const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

class ApiError extends Error {
  constructor(public status: number, public code: string) {
    super(code);
  }
}

async function call<T = any>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(api(path), {
    method: body === undefined ? 'GET' : 'POST',
    credentials: 'same-origin',
    headers: body === undefined ? {} : { 'content-type': 'application/json', 'x-csrf-token': boot?.csrf ?? '' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, data.error ?? `http_${res.status}`);
  return data as T;
}

const ERR: Record<string, string> = {
  expired: 'انتهت صلاحية رابط التوقيع. يرجى طلب رابط جديد من الجهة المموِّلة.',
  other_device: 'بدأت التوقيع على جهاز آخر. يرجى إكماله من الجهاز نفسه.',
  csrf: 'انتهت صلاحية الصفحة. سيتم إعادة تحميلها.',
  rate_limited: 'محاولات كثيرة متتالية. انتظر قليلاً ثم أعد المحاولة.',
  face_attempts_exhausted: 'استُنفدت محاولات التحقق من الوجه.',
  face_service_unavailable: 'خدمة التحقق من الوجه غير متاحة حالياً. أعد المحاولة بعد قليل.',
  webauthn_failed: 'تعذّر التحقق من بصمة الجهاز. أعد المحاولة.',
  webauthn_registration_failed: 'تعذّر تسجيل هذا الجهاز. أعد المحاولة.',
  challenge_expired: 'انتهت مهلة الطلب. أعد المحاولة.',
  signing_failed: 'تعذّر إصدار التوقيع الآن. لم يتم توقيع العقد — أعد المحاولة بعد قليل.',
  document_not_fully_viewed: 'يجب استعراض جميع صفحات العقد أولاً.',
  invalid_state: 'تغيّرت حالة الجلسة. سيتم تحديث الصفحة.',
  not_found: 'رابط التوقيع غير صحيح.',
};
const msg = (e: unknown) => (e instanceof ApiError ? ERR[e.code] ?? `حدث خطأ (${e.code}).` : 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وأعد المحاولة.');

function notice(kind: 'err' | 'ok' | 'info', text: string) {
  return `<div class="notice ${kind}" role="${kind === 'err' ? 'alert' : 'status'}">${esc(text)}</div>`;
}

function busy(btn: HTMLButtonElement, on: boolean, label?: string) {
  btn.disabled = on;
  if (on) {
    btn.dataset.label = btn.innerHTML;
    btn.innerHTML = `<span class="spinner"></span>${esc(label ?? 'يرجى الانتظار…')}`;
  } else if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
}

const STEPS = ['مراجعة العقد', 'الموافقة', 'التحقق من الوجه', 'بصمة الجهاز', 'تم التوقيع'];
function stepper(current: number) {
  return `<ol class="stepper" aria-label="مراحل التوقيع">${STEPS.map(
    (s, i) => `<li class="${i < current ? 'done' : i === current ? 'current' : ''}" ${i === current ? 'aria-current="step"' : ''}><div class="bar"></div><span>${s}</span></li>`,
  ).join('')}</ol>`;
}

function render(html: string) {
  app.innerHTML = html;
  window.scrollTo({ top: 0 });
}

function handleFatal(e: unknown) {
  if (e instanceof ApiError && (e.code === 'csrf' || e.code === 'invalid_state')) {
    setTimeout(() => location.reload(), 1200);
  }
}

// ------------------------------------------------------------------- router
async function start() {
  try {
    const res = await fetch(api('/bootstrap'), { credentials: 'same-origin' });
    if (res.status === 410) return terminal('expired');
    if (!res.ok) throw new ApiError(res.status, (await res.json().catch(() => ({}))).error ?? 'not_found');
    boot = await res.json();
  } catch (e) {
    return render(`<div class="card">${notice('err', msg(e))}</div>`);
  }
  if (!boot.device_ok && boot.status !== 'completed') return terminal('other_device');
  switch (boot.status) {
    case 'opened':
      return boot.document_viewed ? stepConsent() : stepDocument();
    case 'consented':
      return stepFace();
    case 'face_verified':
      return stepPasskey();
    case 'completed':
      return stepDone();
    default:
      return terminal(boot.status);
  }
}

function terminal(kind: string) {
  const t: Record<string, [string, string]> = {
    expired: ['انتهت صلاحية الرابط', 'يرجى التواصل مع الجهة المموِّلة لإرسال رابط توقيع جديد.'],
    cancelled: ['تم إلغاء طلب التوقيع', 'ألغت الجهة المموِّلة هذا الطلب. لا يلزم أي إجراء منك.'],
    manual_review: ['تم تحويل طلبك للتوقيع اليدوي', 'سيتواصل معك موظف الفرع لإكمال التوقيع بشكل حضوري موثَّق.'],
    failed: ['تعذّر إكمال التوقيع', 'يرجى التواصل مع الجهة المموِّلة.'],
    other_device: ['يرجى المتابعة من الجهاز الأصلي', 'لأسباب أمنية، يجب إكمال التوقيع على الجهاز الذي سُجِّلت منه الموافقة.'],
  };
  const [h, p] = t[kind] ?? t.failed;
  render(`<div class="card center"><h1>${h}</h1><p class="lead">${p}</p></div>`);
}

function summaryCard() {
  const rows = Object.entries(boot.summary ?? {})
    .map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`)
    .join('');
  return `<div class="card">
    <h1>${esc(boot.document.title)}</h1>
    <p class="lead">مرحباً ${esc(boot.signer_name)}، يرجى مراجعة العقد بعناية قبل التوقيع.</p>
    <dl class="kv"><dt>رقم مرجع القرض</dt><dd>${esc(boot.loan_reference)}</dd>${rows}
    <dt>عدد الصفحات</dt><dd>${boot.document.pages}</dd></dl></div>`;
}

// --------------------------------------------------------- 1. document view
async function stepDocument() {
  render(`${stepper(0)}${summaryCard()}
  <div class="card">
    <h2>نص العقد</h2>
    <div class="viewer" id="viewer" tabindex="0" aria-label="عارض العقد"><div class="loading"><div class="spinner"></div>جارٍ تحميل العقد…</div></div>
    <div class="page-meter"><span id="pm">0 / ${boot.document.pages}</span><div class="meter"><i id="pmi"></i></div></div>
    <div id="msg"></div>
    <button class="btn" id="next" disabled>اطّلعت على العقد كاملاً — متابعة</button>
    <p class="mono" style="margin-top:12px">SHA-256: ${esc(boot.document.sha256)}</p>
  </div>`);

  const viewer = document.getElementById('viewer')!;
  const next = document.getElementById('next') as HTMLButtonElement;
  const seen = new Set<number>();
  const update = () => {
    if (!document.getElementById('pm')) return; // user already moved on
    document.getElementById('pm')!.textContent = `${seen.size} / ${boot.document.pages}`;
    (document.getElementById('pmi') as HTMLElement).style.width = `${(seen.size / boot.document.pages) * 100}%`;
    next.disabled = seen.size < boot.document.pages;
  };

  try {
    const data = await fetch(api('/document'), { credentials: 'same-origin' }).then((r) => {
      if (!r.ok) throw new ApiError(r.status, 'document');
      return r.arrayBuffer();
    });
    const pdf = await pdfjs.getDocument({
      data,
      isEvalSupported: false,
      cMapUrl: '/assets/pdfjs/cmaps/',
      cMapPacked: true,
      standardFontDataUrl: '/assets/pdfjs/standard_fonts/',
      wasmUrl: '/assets/pdfjs/wasm/',
    }).promise;
    viewer.innerHTML = '';
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting && en.intersectionRatio > 0.35) seen.add(Number((en.target as HTMLElement).dataset.page));
        });
        update();
      },
      { root: viewer, threshold: [0.35, 0.6] },
    );
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const base = page.getViewport({ scale: 1 });
      const scale = ((viewer.clientWidth - 20) / base.width) * dpr;
      const vp = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = vp.width;
      canvas.height = vp.height;
      canvas.dataset.page = String(i);
      canvas.setAttribute('aria-label', `الصفحة ${i}`);
      viewer.appendChild(canvas);
      await page.render({ canvas, canvasContext: canvas.getContext('2d')!, viewport: vp }).promise;
      io.observe(canvas);
    }
  } catch (e) {
    viewer.innerHTML = notice('err', 'تعذّر عرض العقد. أعد تحميل الصفحة.');
    return;
  }

  next.onclick = async () => {
    busy(next, true);
    try {
      await call('/viewed', { pages_viewed: seen.size });
      stepConsent();
    } catch (e) {
      document.getElementById('msg')!.innerHTML = notice('err', msg(e));
      busy(next, false);
      handleFatal(e);
    }
  };
}

// --------------------------------------------------------------- 2. consent
function stepConsent() {
  render(`${stepper(1)}
  <div class="card">
    <h1>الموافقة الصريحة على التوقيع</h1>
    <p class="lead">اقرأ الإقرار التالي. سيُسجَّل وقت موافقتك وبيانات جهازك ضمن سجل التوقيع.</p>
    <div class="consent-text">${esc(boot.consent.text)}</div>
    <label class="check"><input type="checkbox" id="agree"> <span>قرأت الإقرار أعلاه وأوافق على توقيع عقد القرض رقم ${esc(boot.loan_reference)} إلكترونياً.</span></label>
    <div id="msg"></div>
    <button class="btn" id="next" disabled>أوافق وأتابع إلى التحقق من الهوية</button>
    <button class="btn link" id="back">العودة لمراجعة العقد</button>
  </div>`);
  const agree = document.getElementById('agree') as HTMLInputElement;
  const next = document.getElementById('next') as HTMLButtonElement;
  agree.onchange = () => (next.disabled = !agree.checked);
  document.getElementById('back')!.onclick = () => stepDocument();
  next.onclick = async () => {
    busy(next, true);
    try {
      await call('/consent', { accepted: true, consent_version: boot.consent.version, document_sha256: boot.document.sha256 });
      stepFace();
    } catch (e) {
      document.getElementById('msg')!.innerHTML = notice('err', msg(e));
      busy(next, false);
      handleFatal(e);
    }
  };
}

// ------------------------------------------------------------------ 3. face
const CUE: Record<string, { text: string; arrow: string; dx?: string; dy?: string; side?: 'left' | 'right' }> = {
  center: { text: 'انظر مباشرة إلى الكاميرا', arrow: '' },
  left: { text: 'أدِر رأسك ببطء إلى يسارك', arrow: '←', dx: '-10px', side: 'left' },
  right: { text: 'أدِر رأسك ببطء إلى يمينك', arrow: '→', dx: '10px', side: 'right' },
  up: { text: 'ارفع رأسك قليلاً إلى الأعلى', arrow: '↑', dy: '-10px' },
};
const HINT: Record<string, string> = {
  no_face: 'ضع وجهك داخل الإطار',
  multiple_faces: 'يجب أن يظهر وجه واحد فقط',
  face_too_small: 'اقترب من الكاميرا قليلاً',
  low_quality: 'حسّن الإضاءة وثبّت الهاتف',
  look_straight: 'انظر مباشرة إلى الكاميرا',
  no_match: 'لم تتم مطابقة الوجه بعد — ثبّت وجهك',
  keep_turning: 'أكمل الحركة ببطء',
  bad_image: 'تعذّرت قراءة الصورة',
};

let stream: MediaStream | null = null;
const stopCamera = () => {
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
};

function stepFace(info?: string) {
  stopCamera();
  const left = boot.face.attempts_left;
  render(`${stepper(2)}
  <div class="card">
    <h1>التحقق من الوجه</h1>
    <p class="lead">سنطابق وجهك مع صورة الهوية المسجَّلة لدى الجهة المموِّلة، ونتأكد أنك شخص حقيقي حاضر الآن.</p>
    <ul class="steps-list">
      <li><b>1</b>اجلس في مكان جيد الإضاءة وأزِل النظارة الشمسية أو الكمامة.</li>
      <li><b>2</b>امسك الهاتف بمستوى وجهك.</li>
      <li><b>3</b>اتبع التعليمات التي تظهر على الشاشة (حركات عشوائية للرأس).</li>
    </ul>
    ${info ? notice('info', info) : ''}
    <div id="msg"></div>
    ${left > 0 ? `<button class="btn" id="go">تشغيل الكاميرا والبدء</button><p class="timer">المحاولات المتبقية: ${left}</p>` : notice('err', 'استُنفدت محاولات التحقق من الوجه.')}
    <button class="btn link" id="manual">لا أستطيع إكمال التحقق — أطلب التوقيع في الفرع</button>
  </div>`);
  document.getElementById('manual')!.onclick = requestManual;
  const go = document.getElementById('go') as HTMLButtonElement | null;
  if (go) go.onclick = () => runFace(go);
}

async function runFace(go: HTMLButtonElement) {
  busy(go, true, 'جارٍ تشغيل الكاميرا…');
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
      audio: false,
    });
  } catch {
    busy(go, false);
    document.getElementById('msg')!.innerHTML = notice('err', 'لم يتم السماح باستخدام الكاميرا. فعّل إذن الكاميرا لهذا الموقع من إعدادات المتصفح ثم أعد المحاولة.');
    return;
  }
  let challenge: { steps: string[]; step: string; timeout_seconds: number; attempts_left: number };
  try {
    challenge = await call('/face/start', {});
    boot.face.attempts_left = challenge.attempts_left;
  } catch (e) {
    stopCamera();
    busy(go, false);
    document.getElementById('msg')!.innerHTML = notice('err', msg(e));
    handleFatal(e);
    return;
  }

  render(`${stepper(2)}
  <div class="card">
    <div class="cam"><video id="v" playsinline autoplay muted></video><div class="oval" id="oval"></div>
      <div class="arrow" id="arrow"></div><div class="cue" id="cue"></div></div>
    <div class="dots" id="dots">${challenge.steps.map(() => '<i></i>').join('')}</div>
    <p class="center" id="hint" style="min-height:1.6em;color:var(--ink-2)"></p>
    <p class="timer" id="timer"></p>
    <button class="btn secondary" id="cancel">إلغاء</button>
  </div>`);

  const video = document.getElementById('v') as HTMLVideoElement;
  video.srcObject = stream;
  await video.play().catch(() => undefined);

  let step = challenge.step;
  let progress = 0;
  let stopped = false;
  const deadline = Date.now() + challenge.timeout_seconds * 1000;
  const canvas = document.createElement('canvas');

  const show = () => {
    const c = CUE[step] ?? CUE.center;
    document.getElementById('cue')!.textContent = c.text;
    const a = document.getElementById('arrow')!;
    a.textContent = c.arrow;
    a.style.setProperty('--dx', c.dx ?? '0');
    a.style.setProperty('--dy', c.dy ?? '0');
    // The preview is mirrored, so the user's left is on the screen's left
    a.style.left = c.side === 'left' ? '6%' : c.side === 'right' ? '' : '46%';
    a.style.right = c.side === 'right' ? '6%' : '';
    a.style.top = step === 'up' ? '6%' : '42%';
    document.querySelectorAll('#dots i').forEach((d, i) => d.classList.toggle('on', i < progress));
  };
  show();

  document.getElementById('cancel')!.onclick = () => {
    stopped = true;
    stopCamera();
    stepFace();
  };

  const tick = setInterval(() => {
    const s = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    const t = document.getElementById('timer');
    if (t) t.textContent = `الوقت المتبقي: ${s} ثانية`;
  }, 500);

  const grab = () => {
    const w = video.videoWidth;
    const h = video.videoHeight;
    if (!w || !h) return null;
    const scale = Math.min(1, 640 / Math.max(w, h));
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    canvas.getContext('2d')!.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.82);
  };

  try {
    while (!stopped) {
      const t0 = Date.now();
      const img = grab();
      if (img) {
        const r = await call<{ done: boolean; failed?: boolean; reason?: string; step?: string; hint?: string; progress?: number; attempts_left?: number }>('/face/frame', { image: img });
        if (r.done) {
          stopped = true;
          progress = challenge.steps.length;
          show();
          document.getElementById('oval')!.classList.add('good');
          document.getElementById('cue')!.textContent = 'تم التحقق ✓';
          await new Promise((res) => setTimeout(res, 700));
          stopCamera();
          return stepPasskey();
        }
        if (r.failed) {
          stopped = true;
          stopCamera();
          boot.face.attempts_left = r.attempts_left ?? 0;
          return stepFace(r.reason === 'timeout' ? 'انتهى الوقت قبل إكمال الحركات. حاول مرة أخرى بإضاءة جيدة.' : 'لم يكتمل التحقق. حاول مرة أخرى.');
        }
        if (r.step && r.step !== step) {
          step = r.step;
          progress = r.progress ?? progress;
          if (navigator.vibrate) navigator.vibrate(40);
          show();
        }
        document.getElementById('oval')!.classList.toggle('good', !r.hint);
        document.getElementById('hint')!.textContent = r.hint && r.hint !== 'busy' ? HINT[r.hint] ?? '' : '';
      }
      const wait = 350 - (Date.now() - t0);
      if (wait > 0) await new Promise((res) => setTimeout(res, wait));
    }
  } catch (e) {
    stopCamera();
    stepFace(msg(e));
    handleFatal(e);
  } finally {
    clearInterval(tick);
  }
}

// ------------------------------------------------------------ 4. passkey
async function stepPasskey(info?: string) {
  const supported = browserSupportsWebAuthn() && (await platformAuthenticatorIsAvailable().catch(() => false));
  render(`${stepper(3)}
  <div class="card">
    <h1>التوقيع ببصمة جهازك</h1>
    <p class="lead">سيطلب منك هاتفك بصمة الإصبع أو بصمة الوجه (Face ID) أو رمز القفل. تتم المطابقة داخل جهازك فقط، ويُوقَّع بها تحدٍّ مرتبط ببصمة العقد نفسه.</p>
    <dl class="kv"><dt>العقد</dt><dd>${esc(boot.document.title)}</dd><dt>رقم المرجع</dt><dd>${esc(boot.loan_reference)}</dd></dl>
    ${info ? notice('info', info) : ''}
    <div id="msg">${supported ? '' : notice('err', 'هذا المتصفح أو الجهاز لا يدعم التحقق البيومتري. استخدم Chrome أو Safari بإصدار حديث على هاتف مفعَّل فيه قفل الشاشة.')}</div>
    <button class="btn" id="sign" ${supported ? '' : 'disabled'} style="margin-top:14px">
      <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M17.8 4.5A10 10 0 0 0 12 3a10 10 0 0 0-5.8 1.5l-.8-1.2A11.5 11.5 0 0 1 12 1.5c2.4 0 4.6.7 6.6 1.8zM12 5c4.1 0 7.5 3.2 7.5 7.2V13h-1.5v-.8c0-3.2-2.7-5.7-6-5.7s-6 2.5-6 5.7v1.6c0 2 .6 3.9 1.7 5.5l-1.2.9A11 11 0 0 1 4.5 13.8v-1.6C4.5 8.2 7.9 5 12 5m0 3.3c2.3 0 4.2 1.8 4.2 4V14c0 2.4.9 4.6 2.5 6.3l-1.1 1A10.6 10.6 0 0 1 14.7 14v-1.7a2.7 2.7 0 0 0-5.4 0V14c0 3.3 1.5 6.3 4 8.3l-.9 1.2a12 12 0 0 1-4.6-9.5v-1.7c0-2.2 1.9-4 4.2-4m-.8 3.9h1.5V14c0 2.2 1 4.3 2.7 5.6l-.9 1.2a8.6 8.6 0 0 1-3.3-6.8z"/></svg>
      وقِّع العقد الآن</button>
    <button class="btn link" id="manual">أطلب التوقيع في الفرع بدلاً من ذلك</button>
  </div>`);
  document.getElementById('manual')!.onclick = requestManual;
  const btn = document.getElementById('sign') as HTMLButtonElement;
  btn.onclick = () => doPasskey(btn);
}

async function doPasskey(btn: HTMLButtonElement, forceRegister = false) {
  const box = document.getElementById('msg')!;
  box.innerHTML = '';
  busy(btn, true, 'بانتظار تأكيد البصمة…');
  try {
    let authOpts: any;
    let mode = 'register';
    if (!forceRegister) {
      const o = await call<{ mode: string; options?: any }>('/webauthn/options', {});
      mode = o.mode;
      authOpts = o.options;
    }
    if (mode === 'register') {
      const { options } = await call('/webauthn/register/options', {});
      const att = await startRegistration({ optionsJSON: options });
      const r = await call<{ options: any }>('/webauthn/register', att);
      authOpts = r.options;
    }
    const assertion = await startAuthentication({ optionsJSON: authOpts });
    busy(btn, true, 'جارٍ إصدار التوقيع والشهادة…');
    await call('/webauthn/authenticate', assertion);
    boot.status = 'completed';
    boot.can_download = true;
    stepDone();
  } catch (e) {
    busy(btn, false);
    const name = (e as { name?: string })?.name;
    if (name === 'NotAllowedError' || name === 'AbortError') {
      box.innerHTML =
        notice('info', 'لم يكتمل التحقق بالبصمة (أُلغي أو انتهت المهلة). إذا كان هذا جهازاً جديداً لم يُستخدم سابقاً للتوقيع، سجّله أولاً.') +
        '<button class="btn secondary" id="reg">تسجيل هذا الجهاز ثم التوقيع</button>';
      document.getElementById('reg')!.onclick = () => doPasskey(btn, true);
    } else if (name === 'InvalidStateError') {
      box.innerHTML = notice('info', 'هذا الجهاز مسجَّل مسبقاً. اضغط «وقِّع العقد الآن».');
    } else {
      box.innerHTML = notice('err', msg(e));
      handleFatal(e);
    }
  }
}

// ----------------------------------------------------------------- 5. done
function stepDone() {
  render(`${stepper(4)}
  <div class="card center">
    <div class="success-icon"><svg viewBox="0 0 24 24" width="40" height="40"><path fill="currentColor" d="m9.5 16.2-4.2-4.2-1.4 1.4 5.6 5.6 11-11-1.4-1.4z"/></svg></div>
    <h1>تم توقيع العقد بنجاح</h1>
    <p class="lead">أُرسل إشعار التوقيع إلى الجهة المموِّلة. احتفظ بنسخة العقد الموقَّعة.</p>
    <dl class="kv" style="text-align:right;margin-bottom:16px"><dt>رقم المرجع</dt><dd>${esc(boot.loan_reference)}</dd>
      <dt>رقم المعاملة</dt><dd class="mono">${esc(boot.session_id)}</dd></dl>
    ${boot.can_download ? `<a class="btn" href="${api('/signed-document')}" download>تنزيل العقد الموقَّع (PDF)</a>` : notice('info', 'انتهت فترة التنزيل من هذا الرابط. اطلب النسخة من الجهة المموِّلة.')}
  </div>`);
}

async function requestManual() {
  if (!confirm('سيتم إيقاف التوقيع الإلكتروني وتحويل طلبك لموظف الفرع لإكماله حضورياً. هل تريد المتابعة؟')) return;
  try {
    stopCamera();
    await call('/manual', { reason: 'signer_requested' });
    terminal('manual_review');
  } catch (e) {
    alert(msg(e));
  }
}

start();
