// End-to-end test: partner API -> browser signing flow (virtual passkey + fake camera) -> signed PDF.
// Usage: node test/e2e.mjs   (server must be running; env from .env.test)
import { createRequire } from 'node:module';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import { execFileSync } from 'node:child_process';
import pg from 'pg';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const BASE = process.env.PUBLIC_ORIGIN;
const KEY = process.env.BOOTSTRAP_CLIENT_API_KEY;
const OUT = process.env.E2E_OUT || '/tmp/e2e';
fs.mkdirSync(OUT, { recursive: true });
let failures = 0;
const ok = (cond, name) => { console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}`); if (!cond) failures++; };

// --- webhook receiver
const hooks = [];
const hookSrv = http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    const ts = req.headers['x-esign-timestamp'];
    const expect = 'sha256=' + crypto.createHmac('sha256', process.env.BOOTSTRAP_CLIENT_WEBHOOK_SECRET).update(`${ts}.${b}`).digest('hex');
    hooks.push({ event: req.headers['x-esign-event'], valid: expect === req.headers['x-esign-signature'], body: JSON.parse(b) });
    res.end('ok');
  });
}).listen(9099);

const browser = await chromium.launch({ args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });

// --- build an Arabic sample contract (3 pages)
const gen = await browser.newPage();
await gen.setContent(`<html dir="rtl"><body style="font-family:sans-serif;font-size:15px;line-height:2">
${[1, 2, 3].map((p) => `<section style="page-break-after:always"><h1>عقد قرض لمشروع صغير — صفحة ${p}</h1><p>${'يلتزم المقترض بسداد الأقساط الشهرية في مواعيدها المحددة وفق جدول السداد المرفق. '.repeat(18)}</p></section>`).join('')}
</body></html>`);
const contract = await gen.pdf({ format: 'A4' });
await gen.close();
const refFace = fs.readFileSync(process.env.REF_FACE || new URL('../../face-service/tests/fixtures/person_a.jpg', import.meta.url));

const api = (path, body, headers = {}) => fetch(`${BASE}${path}`, {
  method: body ? 'POST' : 'GET',
  headers: { authorization: `Bearer ${KEY}`, 'content-type': 'application/json', ...headers },
  body: body ? JSON.stringify(body) : undefined,
});

const loanRef = `LN-E2E-${Date.now()}`;
const payload = {
  loan_reference: loanRef,
  document: { title: 'عقد قرض مشروع صغير', filename: 'contract.pdf', content_base64: contract.toString('base64') },
  signer: { external_id: `CUST-${Date.now()}`, full_name: 'زكريا يحيى الربيعي', phone: '07700000000', national_id: '199012345678' },
  reference_face_base64: refFace.toString('base64'),
  summary: { 'مبلغ القرض': '25,000,000 دينار عراقي', 'مدة السداد': '36 شهراً', 'القسط الشهري': '780,000 دينار' },
};

// --- partner API checks
ok((await fetch(`${BASE}/v1/sessions`, { method: 'POST' })).status === 401, 'rejects missing API key');
ok((await api('/v1/sessions', { ...payload, document: { ...payload.document, content_base64: Buffer.from('x'.repeat(200)).toString('base64') } })).status === 422, 'rejects non-PDF document');
const idem = crypto.randomUUID();
const r1 = await api('/v1/sessions', payload, { 'idempotency-key': idem });
const s = await r1.json();
ok(r1.status === 201 && s.signing_url, `creates session (${r1.status})`);
const r2 = await api('/v1/sessions', payload, { 'idempotency-key': idem });
ok(r2.headers.get('idempotent-replay') === 'true' && (await r2.json()).session_id === s.session_id, 'idempotent replay returns same session');
ok((await api('/v1/sessions', payload)).status === 409, 'one active session per loan');

// --- signer flow
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar-IQ', acceptDownloads: true });
await context.grantPermissions(['camera'], { origin: BASE });
const page = await context.newPage();
const cdp = await context.newCDPSession(page);
await cdp.send('WebAuthn.enable');
await cdp.send('WebAuthn.addVirtualAuthenticator', { options: { protocol: 'ctap2', transport: 'internal', hasResidentKey: true, hasUserVerification: true, isUserVerified: true, automaticPresenceSimulation: true } });
const consoleErrors = [];
page.on('console', (m) => m.type() === 'error' && !/status of 403/.test(m.text()) && consoleErrors.push(m.text()));
page.on('pageerror', (e) => consoleErrors.push(e.message));

await page.goto(s.signing_url);
await page.waitForSelector('#viewer canvas[data-page="3"]', { timeout: 20000 });
await page.screenshot({ path: `${OUT}/1-document.png`, fullPage: true });
ok(await page.locator('#next').isDisabled(), 'continue disabled until all pages viewed');
for (let i = 0; i < 12; i++) { await page.locator('#viewer').evaluate((v) => v.scrollBy(0, 400)); await page.waitForTimeout(120); }
await page.locator('#next').click();
await page.waitForSelector('#agree');
await page.screenshot({ path: `${OUT}/2-consent.png`, fullPage: true });
await page.locator('#agree').check();
await page.locator('#next').click();
await page.waitForSelector('#go');
await page.screenshot({ path: `${OUT}/3-face-intro.png`, fullPage: true });

// another device must not be able to continue after consent
const other = await browser.newContext();
const op = await other.newPage();
await op.goto(s.signing_url);
await op.waitForSelector('h1');
ok((await op.locator('h1').innerText()).includes('الجهاز الأصلي'), 'other device blocked after consent');
await other.close();

await page.locator('#go').click();
await page.waitForSelector('.cam video');
await page.waitForTimeout(400);
await page.screenshot({ path: `${OUT}/4-face-camera.png` });
await page.waitForSelector('#sign', { timeout: 30000 });
await page.screenshot({ path: `${OUT}/5-passkey.png`, fullPage: true });
await page.locator('#sign').click();
await page.waitForSelector('.success-icon', { timeout: 30000 });
await page.screenshot({ path: `${OUT}/6-done.png`, fullPage: true });
ok(true, 'signer flow completed in browser');

const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('a.btn').click()]);
await dl.saveAs(`${OUT}/signed-by-signer.pdf`);

// --- results
const st = await (await api(`/v1/sessions/${s.session_id}`)).json();
ok(st.status === 'completed', 'status completed');
ok(st.verifications.some((v) => v.kind === 'face_liveness' && v.result === 'pass'), 'face verification recorded');
ok(st.verifications.some((v) => v.kind === 'webauthn_registration'), 'passkey enrolment recorded');
ok(st.verifications.some((v) => v.kind === 'webauthn_assertion' && v.result === 'pass' && v.details.document_bound), 'document-bound passkey assertion recorded');
const pdfRes = await api(`/v1/sessions/${s.session_id}/signed-document`);
const signed = Buffer.from(await pdfRes.arrayBuffer());
fs.writeFileSync(`${OUT}/signed.pdf`, signed);
ok(crypto.createHash('sha256').update(signed).digest('hex') === st.document.signed_sha256, 'signed PDF hash matches record');
const sig = execFileSync('pdfsig', [`${OUT}/signed.pdf`]).toString();
ok(/Signature is Valid/.test(sig), 'PDF signature cryptographically valid');
ok(/ETSI.CAdES.detached/.test(sig), 'PAdES subfilter');
const audit = await (await api(`/v1/sessions/${s.session_id}/audit`)).json();
const events = audit.entries.map((e) => e.event);
console.log('      audit:', events.join(' > '));
ok(['session.created', 'session.opened', 'document.viewed', 'consent.recorded', 'face.verified', 'webauthn.device_enrolled', 'webauthn.assertion_verified', 'signature.completed'].every((e) => events.includes(e)), 'full audit trail');
ok((await (await api('/v1/audit/verify')).json()).ok, 'audit hash chain verifies');

// immutability
const db = new pg.Client({ connectionString: process.env.DATABASE_URL });
await db.connect();
let blocked = false;
try { await db.query("UPDATE audit_logs SET event='x' WHERE seq=1"); } catch { blocked = true; }
ok(blocked, 'audit log UPDATE blocked by database');
const row = (await db.query('SELECT reference_embedding_enc, face_state, webauthn_state FROM signing_sessions WHERE id=$1', [s.session_id])).rows[0];
ok(row.reference_embedding_enc === null && row.face_state === null, 'biometric material wiped after completion');
await db.end();

// replay: completed session cannot be signed again
ok((await page.evaluate(async (u) => (await fetch(u, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })).status, `${new URL(s.signing_url).origin}/api/sign/${s.signing_url.split('/s/')[1]}/webauthn/authenticate`)) === 403, 'post-completion calls rejected');

await new Promise((r) => setTimeout(r, 7000));
const done = hooks.find((h) => h.event === 'signature.completed');
ok(done && done.valid, 'webhook delivered with valid HMAC signature');
ok(consoleErrors.length === 0, `no browser console errors ${consoleErrors.join(' | ')}`);

await browser.close();
hookSrv.close();
console.log(failures ? `\n${failures} FAILED` : '\nALL PASSED');
process.exit(failures ? 1 : 0);
