// Integration test against the real self-hosted face-service (no browser).
// Drives the signer API directly: reference -> consent -> face frames.
import fs from 'node:fs';
const BASE = process.env.PUBLIC_ORIGIN, KEY = process.env.BOOTSTRAP_CLIENT_API_KEY;
const FIX = new URL('../../face-service/tests/fixtures/', import.meta.url);
const A = fs.readFileSync(new URL('person_a.jpg', FIX)).toString('base64');
const B = fs.readFileSync(new URL('person_b.jpg', FIX)).toString('base64');
let fail = 0; const ok = (c, n) => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}`); if (!c) fail++; };
const { PDFDocument } = await import('pdf-lib');
const d = await PDFDocument.create(); d.addPage(); const pdf = Buffer.from(await d.save()).toString('base64');
const mk = (face) => fetch(`${BASE}/v1/sessions`, { method: 'POST', headers: { authorization: `Bearer ${KEY}`, 'content-type': 'application/json' },
  body: JSON.stringify({ loan_reference: `LN-F-${Math.random()}`, document: { title: 't', content_base64: pdf + ''.padEnd(0) },
    signer: { external_id: 'C-F', full_name: 'Test User' }, reference_face_base64: face }) });

const bad = await mk(Buffer.alloc(3000, 0).toString('base64'));
ok(bad.status === 422, `invalid reference photo rejected (${(await bad.json()).error})`);
const s = await (await mk(A)).json();
ok(!!s.signing_url, 'session created with real face embedding');
const token = s.signing_url.split('/s/')[1];
let cookie = '', csrf = '';
const call = async (p, body) => {
  const r = await fetch(`${BASE}/api/sign/${token}${p}`, { method: body ? 'POST' : 'GET', headers: { cookie, 'x-csrf-token': csrf, 'content-type': 'application/json' }, body: body && JSON.stringify(body) });
  const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
  return { status: r.status, body: await r.json().catch(() => ({})) };
};
const b = (await call('/bootstrap')).body; csrf = b.csrf;
ok((await call('/viewed', { pages_viewed: 1 })).status === 200, 'document viewed');
ok((await call('/consent', { accepted: true, consent_version: b.consent.version, document_sha256: b.document.sha256 })).status === 200, 'consent');
const st = (await call('/face/start', {})).body;
ok(st.steps[0] === 'center' && st.steps.length === 3, `random challenge ${st.steps.join(',')}`);
const wrong = (await call('/face/frame', { image: B })).body;
ok(wrong.done === false && wrong.progress === 0, `different person does not pass (hint=${wrong.hint})`);
const right = (await call('/face/frame', { image: A })).body;
ok(right.progress === 1, `same person passes center step (next=${right.step})`);
const still = (await call('/face/frame', { image: A })).body;
ok(still.progress === 1 && still.hint === 'keep_turning', 'static photo cannot pass head-turn step (liveness)');
const sig = (await call('/webauthn/options', {}));
ok(sig.status === 409, 'passkey step locked until liveness completes');
console.log(fail ? `${fail} FAILED` : 'ALL PASSED'); process.exit(fail ? 1 : 0);
