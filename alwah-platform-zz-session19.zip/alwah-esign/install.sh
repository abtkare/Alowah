#!/usr/bin/env bash
# One-command installer for the Alwah e-signature service on an Ubuntu/Debian VPS.
#   curl -fsSL https://raw.githubusercontent.com/<owner>/alwah-esign/main/install.sh | sudo bash
# or, from a cloned repo:  sudo bash install.sh
set -euo pipefail

REPO_URL="${REPO_URL:-https://github.com/abtkare/alwah-esign.git}"
DIR="${INSTALL_DIR:-/opt/alwah-esign}"

say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m!! %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "Run as root (sudo bash install.sh)"

# 1) Docker
if ! command -v docker >/dev/null 2>&1; then
  say "Installing Docker"
  curl -fsSL https://get.docker.com | sh
fi
docker compose version >/dev/null 2>&1 || die "docker compose plugin missing"

# 2) Code
if [ -f "./docker-compose.yml" ] && [ -d "./signing-api" ]; then
  DIR="$(pwd)"
elif [ ! -d "$DIR/.git" ]; then
  say "Cloning into $DIR"
  command -v git >/dev/null || (apt-get update && apt-get install -y git)
  git clone "$REPO_URL" "$DIR"
fi
cd "$DIR"

# 3) Settings
rand() { local s; s="$(head -c "$1" /dev/urandom | base64 -w0 | tr -d '=+/')"; printf '%s' "${s:0:$2}"; }
if [ ! -f .env ]; then
  ESIGN_DOMAIN="${ESIGN_DOMAIN:-}"; ACME_EMAIL="${ACME_EMAIL:-}"; ALWAH_WEBHOOK_URL="${ALWAH_WEBHOOK_URL:-}"
  [ -n "$ESIGN_DOMAIN" ] || read -rp "Signing domain (e.g. sign.alwah.iq): " ESIGN_DOMAIN </dev/tty
  [ -n "$ACME_EMAIL" ] || read -rp "Email for the TLS certificate: " ACME_EMAIL </dev/tty
  [ -n "$ALWAH_WEBHOOK_URL" ] || read -rp "Alwah webhook URL (Enter to skip): " ALWAH_WEBHOOK_URL </dev/tty || true
  API_KEY="esk_$(rand 48 48)"; WH_SECRET="whs_$(rand 36 36)"
  umask 077
  cat > .env <<ENV
# ---- generated $(date -u +%FT%TZ) — BACK THIS FILE UP. Losing MASTER_KEY = losing all encrypted data.
ESIGN_DOMAIN=$ESIGN_DOMAIN
ACME_EMAIL=$ACME_EMAIL
NODE_ENV=production
MASTER_KEY=$(head -c 32 /dev/urandom | base64)
POSTGRES_PASSWORD=$(rand 48 32)
REDIS_PASSWORD=$(rand 48 32)
FACE_SERVICE_TOKEN=$(rand 48 40)
FACE_PROVIDER=local
FACE_WORKERS=2
CA_PROVIDER=local-dev
TSA_PROVIDER=local
BOOTSTRAP_CLIENT_NAME=alwah
BOOTSTRAP_CLIENT_API_KEY=$API_KEY
BOOTSTRAP_CLIENT_WEBHOOK_URL=$ALWAH_WEBHOOK_URL
BOOTSTRAP_CLIENT_WEBHOOK_SECRET=$WH_SECRET
API_PORT=${API_PORT:-8085}
LOG_LEVEL=info
ENV
  say "Created .env"
fi
set -a; . ./.env; set +a

# 4) Reverse proxy: use bundled Caddy only if 80/443 are free
PROFILE=""
if ss -ltn '( sport = :80 or sport = :443 )' | grep -q LISTEN; then
  say "Ports 80/443 are already used by another service on this VPS — Caddy will NOT be started."
  echo "Point your existing reverse proxy for ${ESIGN_DOMAIN} to http://127.0.0.1:${API_PORT}"
  echo "nginx example:"
  cat <<NGINX
  server {
    server_name ${ESIGN_DOMAIN};
    client_max_body_size 30m;
    location / {
      proxy_pass http://127.0.0.1:${API_PORT};
      proxy_set_header Host \$host;
      proxy_set_header X-Forwarded-For \$remote_addr;
      proxy_set_header X-Forwarded-Proto https;
    }
    # + your existing TLS (certbot --nginx -d ${ESIGN_DOMAIN})
  }
NGINX
else
  PROFILE="--profile caddy"
fi

# 5) Start
say "Building and starting containers (first build takes a few minutes)"
docker compose $PROFILE up -d --build

say "Waiting for the service to become healthy"
for i in $(seq 1 60); do
  if curl -fs "http://127.0.0.1:${API_PORT}/health" >/dev/null; then break; fi; sleep 3
done
curl -fs "http://127.0.0.1:${API_PORT}/health" && echo || die "Service not healthy: docker compose logs signing-api"

say "Done"
cat <<OUT
Signing service:   https://${ESIGN_DOMAIN}
API key (Alwah):   ${BOOTSTRAP_CLIENT_API_KEY}
Webhook secret:    ${BOOTSTRAP_CLIENT_WEBHOOK_SECRET}
Back up:           ${DIR}/.env  and the docker volumes esign_data + pg_data
NOTE: CA_PROVIDER=local-dev is NOT a licensed CA. Connect the licensed Iraqi CA before legal production use.
OUT
