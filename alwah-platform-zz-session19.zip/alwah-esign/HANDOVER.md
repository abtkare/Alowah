# تسليم مشروع: خدمة التوقيع الإلكتروني — منصة ألواح

> هذا الملف مكتوب ليُسلَّم إلى محادثة Claude أخرى (أو مطوّر) تتولى التشغيل والربط.
> المالك: زكريا يحيى الربيعي (سناب) — يعمل من الهاتف، ويفضّل أن يُنفّذ عنه كل ما يمكن تنفيذه، وأن تُعطى له روابط مباشرة وخطوات واضحة لما لا بد أن ينفّذه بنفسه.

---

## 1. البرومبت الجاهز للمحادثة الجديدة (انسخه كما هو مع ملف الزيب)

```text
أرفقت لك ملف alwah-esign.zip: خدمة توقيع إلكتروني جاهزة ومُختبرة لمنصة ألواح (منصة إدارة تمويل القروض المصرفية للمشاريع الصغيرة والمتوسطة).
اقرأ أولاً HANDOVER.md ثم README.md وdocs/API.md وdocs/SECURITY.md داخل الزيب.
مهمتك: تشغيل الخدمة على الـVPS الخاص بي (Hostinger) وربطها بمنصة ألواح.
الكود مكتمل ومُختبر — لا تُعِد كتابته؛ عدّل فقط ما يلزم للتشغيل والربط.
أعمل من الهاتف: نفّذ بنفسك كل ما تستطيع، وما يجب أن أنفذه أنا أعطني له رابطاً مباشراً وخطوات مرقّمة.
```

---

## 2. ما هو المشروع

خدمة مستقلة تعمل على VPS بـDocker، تُدمج مع ألواح عبر REST API + Webhook. العميل يوقّع عقد القرض من هاتفه بثلاثة عوامل يتحقق منها الخادم معاً:

1. استعراض كل صفحات العقد + **موافقة صريحة** مُسجّلة (الجلسة تُربط بالجهاز).
2. **التحقق من الوجه + كشف الحيوية**: مطابقة مع صورة KYC + حركات رأس عشوائية (center ثم 2 من left/right/up).
3. **بصمة الجهاز / Face ID** عبر WebAuthn (passkey)، والتحدي مشتق من hash العقد.

ثم: شهادة X.509 لمرة واحدة → صفحتا "شهادة إتمام التوقيع" بالعربية تُلحقان بالعقد → توقيع PAdES → ختم زمني → Webhook موقَّع HMAC إلى ألواح → تنزيل للعميل.

| المكوّن | التقنية | المسار |
|---|---|---|
| signing-api | Node.js 22 + TypeScript + Fastify، PostgreSQL، Redis، Chromium (لرسم صفحة الإثبات العربية) | `signing-api/` |
| face-service | Python 3.12 + FastAPI + OpenCV (YuNet + SFace)، داخلي فقط، لا يحفظ صوراً | `face-service/` |
| التشغيل | docker-compose + Caddy (اختياري) + `install.sh` | الجذر |

## 3. الحالة الحالية

**مُختبر وناجح (في بيئة التطوير):**
- `face-service`: 9 اختبارات pytest ناجحة.
- `test/face-integration.mjs`: مع خدمة الوجه الحقيقية — رفض شخص آخر، الصورة الثابتة لا تجتاز خطوة الالتفات، البصمة مقفلة حتى تكتمل الحيوية.
- `test/e2e.mjs` (22 فحصاً ناجحاً): API الشريك (401/422/idempotency/409)، التدفق كاملاً في Chromium مع passkey افتراضي وكاميرا وهمية، منع جهاز آخر، توقيع PDF صحيح عبر `pdfsig`، PAdES، سجل تدقيق كامل وسلسلة hash سليمة، قاعدة البيانات تمنع تعديل السجل، مسح البيانات البيومترية، Webhook بتوقيع HMAC صحيح، لا أخطاء في المتصفح.

**لم يُختبر بعد:**
- **بناء صور Docker** — لم يكن Docker متاحاً في بيئة التطوير. أول `docker compose up --build` على الـVPS هو أول بناء فعلي؛ راقب السجلات.
- **التحقق من الوجه بكاميرا وإنسان حقيقي** — جُرّب بصور ثابتة فقط. قد تحتاج عتبات الحركة ضبطاً بعد أول تجربة على هاتف حقيقي (متغيرات `FACE_TURN_DELTA`, `FACE_UP_DELTA`, `FACE_CENTER_MAX_YAW`, `FACE_MATCH_THRESHOLD` في `face-service/app/main.py`). اتجاه يسار/يمين: yaw>0 = المستخدم التفت إلى يساره (الصورة غير معكوسة؛ المعاينة في الواجهة معكوسة).

**مستودع GitHub (خاص):** `abtkare/alwah-esign` فرع `main` — نفس محتوى هذا الزيب.

## 4. خطوات التشغيل على الـVPS

المتطلبات: Ubuntu/Debian، 2 vCPU و4GB RAM على الأقل، ومشاريع أخرى تعمل على نفس الخادم (لذلك قد يكون المنفذان 80/443 مشغولين — `install.sh` يكتشف ذلك تلقائياً).

1. **DNS:** سجل `A` للنطاق الفرعي (مثل `sign.alwah.iq`) → IP الـVPS. (النطاق النهائي لم يُحدد بعد — اسأل المالك.)
2. **رفع الكود** إلى `/opt/alwah-esign`: إما فك هذا الزيب هناك، أو `git clone` من المستودع الخاص (يحتاج token قراءة).
3. من داخل المجلد: `bash install.sh` — يسأل عن النطاق والبريد ورابط Webhook ألواح، يولّد كل الأسرار في `.env`، يبني ويشغّل، ويطبع **API key** و**Webhook secret**.
   - إن كان 80/443 مشغولاً: لا يشغّل Caddy ويطبع إعداد nginx لتوجيه النطاق إلى `127.0.0.1:8085` (أضِفه ثم `certbot --nginx -d <domain>`).
4. التحقق: `curl -s http://127.0.0.1:8085/health` ثم فتح `https://<domain>/health`.
5. **نسخ احتياطي إلزامي:** ملف `.env` (فيه `MASTER_KEY` — فقدانه = فقدان كل البيانات المشفّرة) + وحدتا التخزين `esign_data` و`pg_data`.

أوامر مفيدة:
```bash
docker compose logs -f signing-api face-service
docker compose exec signing-api node dist/cli.js verify-audit
docker compose exec signing-api node dist/cli.js create-client <name> [webhook_url]
```

## 5. الربط مع منصة ألواح

لم نطّلع على كود ألواح ولا تقنيتها بعد — اطلب من المالك الوصول إلى مستودعها/استضافتها. ما يلزم إضافته في ألواح:

1. متغيرات بيئة: `ESIGN_BASE_URL`, `ESIGN_API_KEY`, `ESIGN_WEBHOOK_SECRET`.
2. عند جاهزية العقد: `POST /v1/sessions` (PDF + بيانات العميل + **صورة KYC للوجه** + ملخص القرض) مع `Idempotency-Key` → إرسال `signing_url` للعميل (SMS/إشعار).
3. Endpoint لاستقبال Webhook يتحقق من HMAC (`x-esign-signature` = `sha256=HMAC(secret, timestamp + "." + raw_body)`) ويرفض الطوابع الأقدم من 5 دقائق.
4. عند `signature.completed`: تنزيل `GET /v1/sessions/:id/signed-document` وحفظه مع القرض وتحديث الحالة.
5. التعامل مع `session.expired` / `session.cancelled` / `session.manual_review` (توقيع حضوري في الفرع).
6. زر "إلغاء طلب التوقيع" → `POST /v1/sessions/:id/cancel`، و"إلغاء أجهزة العميل" عند فقدان الهاتف → `POST /v1/signers/:externalId/revoke-devices`.

أمثلة كود جاهزة في `README.md`، والعقود الكاملة في `docs/API.md`.

**شرط تقني مهم:** صورة KYC المرجعية يجب أن تكون صورة وجه أمامية واضحة (صورة الهوية الموثّقة أو صورة يلتقطها موظف الفرع). بدونها لا يمكن إنشاء جلسة.

## 6. قرارات معلّقة لدى المالك

| البند | الوضع |
|---|---|
| النطاق الفرعي لصفحة التوقيع | لم يُحدد |
| جهة التصديق الإلكتروني المرخّصة (القانون 78 لسنة 2012) | لم تُحدد — الخدمة تعمل الآن بـCA تجريبي ومكتوب ذلك على كل شهادة توقيع. الربط: تنفيذ `RemoteCA` في `signing-api/src/providers/ca.ts` ثم `CA_PROVIDER=remote`، و`TSA_PROVIDER=rfc3161` مع `TSA_URL` |
| مراجعة قانونية لنص الموافقة | النص في `signing-api/src/context.ts` (`CONSENT`) — غيّر `version` عند أي تعديل |
| مزود حيوية معتمد (اختياري للقروض الكبيرة) | الحيوية الحالية ذاتية وغير معتمدة ISO 30107-3؛ يمكن إضافة مزود عبر `FaceProvider` في `signing-api/src/providers/face.ts` |

## 7. ملاحظات أمنية للمستلم

- لا تضع `FACE_PROVIDER=mock` في الإنتاج (الكود يرفض ذلك عند `NODE_ENV=production`).
- لا تكشف منفذ face-service أو Postgres أو Redis للإنترنت.
- مفتاح GitHub (token) الذي استُخدم سابقاً ظهر في محادثة — يُنصح المالك بحذفه من https://github.com/settings/personal-access-tokens وإنشاء غيره عند الحاجة.

## 8. هيكل الملفات

```
alwah-esign/
├── HANDOVER.md            ← هذا الملف
├── README.md              ← دليل التثبيت والدمج (عربي)
├── docs/API.md            ← عقود الـAPI والـWebhook
├── docs/SECURITY.md       ← الضوابط، القيود، الاختبارات، معايير القبول
├── install.sh             ← مثبّت بأمر واحد
├── docker-compose.yml, Caddyfile, .env.example
├── face-service/          ← خدمة الوجه (Python) + اختبارات
└── signing-api/
    ├── src/               ← الخادم (TypeScript)
    │   ├── routes/partner.ts   (API ألواح)
    │   ├── routes/signer.ts    (صفحة التوقيع)
    │   ├── sessions.ts         (إتمام التوقيع)
    │   ├── providers/          (ca / face / tsa — قابلة للاستبدال)
    │   └── migrations/001_init.sql
    ├── web/               ← واجهة التوقيع العربية
    └── test/              ← e2e + face-integration
```

## 9. سجل ما تم حتى الآن (آخر تحديث: 2 نوفمبر 2026)

1. بُني الكود كاملاً واختُبر (القسم 3).
2. أُنشئ المستودع الخاص `abtkare/alwah-esign` ورُفع إليه الكود على فرع `main` (نفس محتوى هذا الزيب).
3. أُنشئ مفتاح GitHub بصلاحية **قراءة فقط** لهذا المستودع (اسمه `vps-esign`، ينتهي 31 يناير 2027). ظهر المفتاح في المحادثة، فيجب **حذفه وإنشاء بديل** قبل استخدامه: https://github.com/settings/personal-access-tokens
4. **لم يُثبَّت شيء على الـVPS بعد.**
5. معلومات الخادم من وكيل Hostinger:
   - رقم الـVPS: **1921287** (Hostinger).
   - حاويات تعمل حالياً ولا يجوز المساس بها: `loan-ocr-app-1` (مشروع OCR للقروض) و`scalper-bot`.
   - **nginx** يشغل المنفذين 80/443، لذلك لن يشغّل `install.sh` Caddy. يجب إضافة server block في nginx للنطاق يوجّه إلى `http://127.0.0.1:8085`، ثم `certbot --nginx -d <domain>` و`client_max_body_size 30m`.
6. حاول المالك التثبيت عبر وكيل Hostinger (Agent) فلم ينفّذ الأوامر، بل عرض الخطة فقط وطلب تأكيداً.
7. النطاق الفرعي لصفحة التوقيع **لم يُحدد بعد** (المقترح: `sign.alwah.iq`). يجب التأكد من ملكية النطاق ومكان إدارة DNS قبل التثبيت.

### تشغيل غير تفاعلي (مناسب للوكلاء)
`install.sh` يقبل القيم كمتغيرات بيئة فلا يسأل:
```bash
cd /opt/alwah-esign && ESIGN_DOMAIN=sign.example.iq ACME_EMAIL=appshoplive@gmail.com ALWAH_WEBHOOK_URL= \
  nohup bash install.sh > /root/esign-install.log 2>&1 < /dev/null &
tail -f /root/esign-install.log
```
آخر سطور السجل تحتوي **API key** و**Webhook secret** لإدخالهما في منصة ألواح.
