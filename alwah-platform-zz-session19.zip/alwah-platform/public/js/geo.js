// الجلسة 17: تحديد الموقع بالـGPS وتصوير الفيديو المباشر — أدوات مشتركة
import { esc, toast, modal } from './core.js';

// يقرأ الموقع لعدة ثوانٍ ويحتفظ بأدق قراءة. يعيد { lat, lng, acc, at } أو يرمي خطأً مفهوماً
export function getGps({ want = 30, maxMs = 20000, onProgress } = {}) {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('الهاتف أو المتصفح لا يدعم تحديد الموقع'));
    let best = null, done = false;
    const finish = () => {
      if (done) return; done = true; navigator.geolocation.clearWatch(id); clearTimeout(t);
      best ? resolve(best) : reject(new Error('تعذّر تحديد الموقع — فعّل خدمة الموقع (GPS) واسمح للمنصة باستخدامه، ثم أعد المحاولة في مكان مكشوف'));
    };
    const id = navigator.geolocation.watchPosition(p => {
      const r = { lat: +p.coords.latitude.toFixed(6), lng: +p.coords.longitude.toFixed(6), acc: Math.round(p.coords.accuracy * 10) / 10, at: new Date(p.timestamp).toISOString() };
      if (!best || r.acc < best.acc) best = r;
      onProgress && onProgress(best);
      if (best.acc <= want) finish();
    }, err => {
      if (err.code === 1) { done = true; navigator.geolocation.clearWatch(id); clearTimeout(t); reject(new Error('رفضت السماح بالموقع — اسمح للمنصة باستخدام الموقع من إعدادات المتصفح ثم أعد المحاولة')); }
    }, { enableHighAccuracy: true, maximumAge: 0, timeout: maxMs });
    const t = setTimeout(finish, maxMs);
  });
}

// نافذة تحديد الموقع مع عرض الدقة لحظياً — تعيد { lat, lng, acc, at } أو null عند الإلغاء
export function gpsDialog({ title = 'تحديد الموقع بالـGPS', hint = '', want = 30 } = {}) {
  return new Promise(resolve => {
    let best = null, settled = false;
    const end = v => { if (settled) return; settled = true; resolve(v); };
    const m = modal(`<h3>${esc(title)}</h3><p class="small muted">${esc(hint || 'قف في موقع المنظومة نفسه وفي مكان مكشوف. يقرأ الهاتف الموقع لثوانٍ ويحتفظ بأدق قراءة.')}</p>
      <div class="gps-live"><span class="gps-dot"></span><span data-s>جارِ تحديد الموقع…</span></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok disabled>اعتماد هذا الموقع</button></div>`, { onClose: () => end(null) });
    const s = m.el.querySelector('[data-s]'), ok = m.el.querySelector('[data-ok]');
    ok.onclick = () => { const v = best; end(v); m.close(); };
    getGps({ want, onProgress: b => { best = b; s.innerHTML = `دقة القراءة الحالية ±<b class="num">${Math.round(b.acc)}</b> م${b.acc > want ? ' — انتظر قليلاً لتحسين الدقة…' : ' ✓'}`; ok.disabled = false; } })
      .then(b => { best = b; s.innerHTML = `✓ الموقع جاهز — دقة ±<b class="num">${Math.round(b.acc)}</b> م`; ok.disabled = false; })
      .catch(e => { if (!best) { s.textContent = e.message; s.style.color = 'var(--bad)'; } });
  });
}

// تصوير فيديو مباشر بكاميرا الهاتف (لا معرض) — يعيد { data, duration, mime } أو null
export function recordVideo({ title = 'فيديو التشغيل', hint = '', maxSec = 20, minSec = 5 } = {}) {
  return new Promise(resolve => {
    if (!window.MediaRecorder || !navigator.mediaDevices?.getUserMedia) { toast('هذا المتصفح لا يدعم تصوير الفيديو — استخدم Chrome أو Safari حديث', 'bad'); return resolve(null); }
    const bg = document.createElement('div');
    bg.className = 'cam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <p class="cam-hint">${esc(title)}<small>${esc(hint || `صوّر الألواح والعاكس وشاشة التشغيل وهي تعمل — من ${minSec} إلى ${maxSec} ثانية`)}</small><small class="rec-t" data-t></small></p>
      <div class="cam-bar"><button type="button" class="cam-x" aria-label="إغلاق">✕</button><button type="button" class="cam-shoot rec" aria-label="تسجيل"></button><span class="cam-gal" style="visibility:hidden">—</span></div>`;
    document.body.appendChild(bg);
    const video = bg.querySelector('video'), btn = bg.querySelector('.cam-shoot'), tEl = bg.querySelector('[data-t]');
    let stream, rec, chunks = [], t0 = 0, tick, stopT, cancelled = false;
    const cleanup = () => { clearInterval(tick); clearTimeout(stopT); stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); };
    bg.querySelector('.cam-x').onclick = () => { cancelled = true; if (rec && rec.state === 'recording') rec.stop(); cleanup(); resolve(null); };
    const types = ['video/mp4', 'video/webm;codecs=vp8', 'video/webm'];
    const type = types.find(t => MediaRecorder.isTypeSupported?.(t)) || '';
    const base = type.startsWith('video/mp4') ? 'video/mp4' : 'video/webm';
    btn.onclick = () => {
      if (!stream) return;
      if (rec && rec.state === 'recording') {
        if ((Date.now() - t0) / 1000 < minSec) return toast(`استمر في التصوير — ${minSec} ثوانٍ على الأقل`, 'bad');
        return rec.stop();
      }
      chunks = [];
      rec = new MediaRecorder(stream, { ...(type ? { mimeType: type } : {}), videoBitsPerSecond: 900000 });
      rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      rec.onstop = () => {
        if (cancelled) return;
        const duration = Math.round((Date.now() - t0) / 100) / 10;
        const blob = new Blob(chunks, { type: base });
        cleanup();
        if (blob.size > 8.5e6) { toast('الفيديو أكبر من المسموح — صوّر مقطعاً أقصر', 'bad'); return resolve(null); }
        const r = new FileReader();
        r.onload = () => resolve({ data: String(r.result).replace(/^data:[^;,]+(;[^,]*)?;base64,/, `data:${base};base64,`), duration, mime: base });
        r.readAsDataURL(blob);
      };
      rec.start(500); t0 = Date.now(); btn.classList.add('on');
      tick = setInterval(() => { tEl.textContent = `● تسجيل ${Math.floor((Date.now() - t0) / 1000)} / ${maxSec} ث`; }, 250);
      stopT = setTimeout(() => rec.state === 'recording' && rec.stop(), maxSec * 1000);
    };
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 960 }, height: { ideal: 540 } }, audio: false })
      .then(st => { stream = st; video.srcObject = st; })
      .catch(() => { bg.querySelector('.cam-hint').innerHTML = 'تعذر فتح الكاميرا — اسمح للمنصة باستخدام الكاميرا من إعدادات المتصفح'; btn.disabled = true; });
  });
}
