// الجلسة 17: البنك المركزي — خريطة بالفلاتر، التحليل ونسب النمو، إعلان المبادرات، حسابات هيئة النزاهة
import { esc, num, mln, pct, dt, badge, rpc, toast, cleanErr, modal, kpi, SECTORS, sectorOf, VET_TYPES, isVet, mapsLink, purposeText } from './core.js';

const coordOf = a => a.install_geo ? [a.install_geo.lat, a.install_geo.lng, 'install'] : a.site_geo ? [a.site_geo.lat, a.site_geo.lng, 'site'] : a.lat ? [a.lat, a.lng, 'approx'] : null;

// ───────── الخريطة بالفلاتر ─────────
export async function mapView(ctx, body, apps, loadLeaflet) {
  const F = ctx.mapF ||= { group: 'all', sectors: [], status: 'all', vet: '' };
  const live = apps.filter(a => !['rejected', 'cancelled'].includes(a.status));
  const pass = a => {
    const s = sectorOf(a);
    if (F.group === 'residential' && s !== 'residential') return false;
    if (F.group === 'project' && s === 'residential') return false;
    if (F.sectors.length && !F.sectors.includes(s)) return false;
    if (F.vet && !(isVet(a) && a.vet_type === F.vet)) return false;
    if (F.status === 'done' && a.status !== 'completed') return false;
    if (F.status === 'live' && a.status === 'completed') return false;
    return true;
  };
  const count = s => live.filter(a => sectorOf(a) === s).length;
  const projSectors = Object.keys(SECTORS).filter(k => k !== 'residential');
  body.innerHTML = `<div class="map-filters card">
      <div class="seg sm">${[['all', 'الكل'], ['residential', '🏠 سكني'], ['project', '🏭 مشاريع']].map(([k, t]) => `<label class="${F.group === k ? 'on' : ''}"><input type="radio" name="mg" value="${k}" ${F.group === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
      <div class="chips">${(F.group === 'residential' ? ['residential'] : F.group === 'project' ? projSectors : Object.keys(SECTORS)).map(k => `<label class="chip ${F.sectors.includes(k) ? 'on' : ''}"><input type="checkbox" value="${k}" data-sec ${F.sectors.includes(k) ? 'checked' : ''}><i class="sw" style="background:${SECTORS[k][1]}"></i>${esc(SECTORS[k][0])} <span class="num muted">${count(k)}</span></label>`).join('')}</div>
      ${F.sectors.includes('vet_program') || F.group === 'project' ? `<select class="input sm" data-vt><option value="">كل المشاريع البيطرية (المبادرة)</option>${Object.entries(VET_TYPES).map(([k, t]) => `<option value="${k}" ${F.vet === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>` : ''}
      <div class="seg sm">${[['all', 'كل الحالات'], ['done', 'مركّبة'], ['live', 'قيد التنفيذ']].map(([k, t]) => `<label class="${F.status === k ? 'on' : ''}"><input type="radio" name="ms" value="${k}" ${F.status === k ? 'checked' : ''}>${t}</label>`).join('')}</div>
    </div>
    <div class="grid g-side"><div class="card"><h3>خريطة المنظومات والمشاريع <span class="sp"></span><span class="small muted" data-cnt></span></h3><div id="map"></div>
      <p class="small muted" style="margin:8px 0 0">● ممتلئة = مركّبة ومدققة · ○ حلقة = قيد التنفيذ. اللون حسب القطاع. الموقع: موقع التركيب الذي ثبّته فني المورد، أو عنوان المقترض بالـGPS، أو تقريبي للطلبات القديمة.</p></div>
      <div class="card flush"><h3>حسب المحافظة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المحافظة</th><th>الطلبات</th><th>مركّبة</th><th>kW</th></tr></thead><tbody data-gov></tbody></table></div></div></div>`;
  const rerender = () => mapView(ctx, body, apps, loadLeaflet);
  body.querySelectorAll('input[name=mg]').forEach(r => r.onchange = () => { F.group = r.value; F.sectors = []; F.vet = ''; rerender(); });
  body.querySelectorAll('input[name=ms]').forEach(r => r.onchange = () => { F.status = r.value; rerender(); });
  body.querySelectorAll('[data-sec]').forEach(c => c.onchange = () => { F.sectors = [...body.querySelectorAll('[data-sec]:checked')].map(x => x.value); if (!F.sectors.includes('vet_program') && F.group !== 'project') F.vet = ''; rerender(); });
  const vt = body.querySelector('[data-vt]'); if (vt) vt.onchange = () => { F.vet = vt.value; rerender(); };
  const shown = live.filter(pass);
  body.querySelector('[data-cnt]').innerHTML = `<span class="num">${shown.length}</span> من <span class="num">${live.length}</span>`;
  const byGov = {};
  shown.forEach(a => { const g = byGov[a.governorate] ||= { n: 0, done: 0, kw: 0 }; g.n++; if (a.status === 'completed') { g.done++; g.kw += Number(a.kw || 0); } });
  body.querySelector('[data-gov]').innerHTML = Object.entries(byGov).sort((a, b) => b[1].n - a[1].n).map(([g, v]) => `<tr><td>${esc(g)}</td><td class="num">${v.n}</td><td class="num">${v.done}</td><td class="num">${num(v.kw)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">لا نتائج لهذا الفلتر</td></tr>';
  try {
    const L = await loadLeaflet();
    const m = L.map('map', { zoomControl: true }).setView([33.2, 43.7], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 18 }).addTo(m);
    const pts = [];
    shown.forEach(a => {
      const c = coordOf(a); if (!c) return;
      const s = sectorOf(a), col = SECTORS[s][1], done = a.status === 'completed';
      pts.push([c[0], c[1]]);
      L.circleMarker([c[0], c[1]], { radius: isVet(a) ? 8 : Math.min(14, 5 + Number(a.kw || 0) / 2), color: '#fff', weight: 2, fillColor: col, fillOpacity: done ? 0.9 : 0.15, ...(done ? {} : { color: col, weight: 3 }) })
        .bindPopup(`<div dir="rtl" style="font-family:Cairo;min-width:180px"><b>${esc(a.code)}</b> — ${esc(SECTORS[s][0])}<br>${esc(a.governorate)} · ${isVet(a) ? esc(VET_TYPES[a.vet_type] || 'مشروع بيطري') : `${num(a.kw)} kW · ${esc(purposeText(a))}`}<br>${done ? 'مركّبة ومدققة' : 'المرحلة ' + a.stage}
          <br><small>${c[2] === 'install' ? '📍 موقع التركيب (فني المورد)' : c[2] === 'site' ? '📍 عنوان المقترض (GPS)' : 'موقع تقريبي — طلب قديم'}</small> · <a href="${mapsLink({ lat: c[0], lng: c[1] })}" target="_blank" rel="noopener">خرائط</a></div>`).addTo(m);
    });
    if (pts.length > 1 && F.group !== 'all') m.fitBounds(pts, { padding: [30, 30], maxZoom: 12 });
  } catch { body.querySelector('#map').innerHTML = '<div class="empty">تعذّر تحميل الخريطة</div>'; }
}

// ───────── التحليل ونسب النمو ─────────
const growth = (cur, prev) => prev > 0 ? (cur - prev) / prev * 100 : cur > 0 ? null : 0;
const gTxt = g => g === null ? '<span class="g up">جديد</span>' : `<span class="g ${g > 0 ? 'up' : g < 0 ? 'down' : ''}">${g > 0 ? '▲' : g < 0 ? '▼' : '■'} <span class="num">${Math.abs(g).toLocaleString('en-US', { maximumFractionDigits: 1 })}%</span></span>`;
const MON = ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];
const monName = m => `${MON[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`;

function bars(rows, key, { title, fmt = v => num(v), unit = '' } = {}) {
  const W = 720, H = 210, pad = 28, bw = (W - pad * 2) / rows.length, max = Math.max(1, ...rows.map(r => Number(r[key]) || 0));
  const top = rows.reduce((b, r) => (Number(r[key]) > Number(b[key]) ? r : b), rows[0]);
  return `<figure class="chart"><figcaption>${esc(title)}</figcaption><svg viewBox="0 0 ${W} ${H + 34}" role="img" aria-label="${esc(title)}">
    <line x1="${pad}" x2="${W - pad}" y1="${H}" y2="${H}" class="ax"/>
    ${rows.map((r, i) => { const v = Number(r[key]) || 0, h = v / max * (H - 30), x = pad + i * bw + 2, w = Math.max(2, bw - 4), y = H - h, last = i === rows.length - 1;
      return `<g class="bar${last ? ' cur' : ''}"><rect x="${pad + i * bw}" y="0" width="${bw}" height="${H}" fill="transparent"><title>${monName(r.m)}: ${fmt(v).replace(/<[^>]+>/g, '')}${unit}</title></rect>
        ${v ? `<path d="M${x},${H} V${y + 4} q0,-4 4,-4 h${w - 8} q4,0 4,4 V${H} z"><title>${monName(r.m)}: ${fmt(v).replace(/<[^>]+>/g, '')}${unit}</title></path>` : ''}
        ${r === top && v ? `<text x="${x + w / 2}" y="${y - 6}" text-anchor="middle" class="vl">${fmt(v).replace(/<[^>]+>/g, '')}</text>` : ''}
        <text x="${x + w / 2}" y="${H + 16}" text-anchor="middle" class="tk">${r.m.slice(5, 7)}</text>${i === 0 || r.m.endsWith('-01') ? `<text x="${x + w / 2}" y="${H + 30}" text-anchor="middle" class="tk">${r.m.slice(0, 4)}</text>` : ''}</g>`; }).join('')}
  </svg></figure>`;
}

export async function analyticsView(ctx, body) {
  const { orgs } = ctx;
  body.innerHTML = '<div class="card"><div class="spin"></div></div>';
  let d;
  try { d = await rpc(ctx.sb, 'cbi_analytics', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  const M = d.months || [], cur = M.at(-1) || {}, prev = M.at(-2) || {};
  const sum = (arr, k) => arr.reduce((t, r) => t + Number(r[k] || 0), 0);
  const q1 = M.slice(-3), q0 = M.slice(-6, -3);
  const tot = d.sectors.reduce((t, s) => t + s.n, 0) || 1;
  const bank = id => orgs.find(o => o.id === id)?.name || '—';
  body.innerHTML = `<div class="notice">نسبة النمو تقارن الشهر الحالي بالشهر السابق، وآخر 3 أشهر بالثلاثة التي قبلها. الشهر الحالي غير مكتمل بعد، فمقارنة الأشهر الثلاثة أدق.</div>
    <div class="grid g4 mb">
      ${kpi('طلبات جديدة هذا الشهر', `<span class="num">${num(cur.created)}</span> ${gTxt(growth(cur.created, prev.created))}`, `آخر 3 أشهر: ${num(sum(q1, 'created'))} ${gTxt(growth(sum(q1, 'created'), sum(q0, 'created')))}`, true)}
      ${kpi('تمويل معزَّز هذا الشهر', `${mln(cur.funded_amt)} ${gTxt(growth(cur.funded_amt, prev.funded_amt))}`, `آخر 3 أشهر: ${mln(sum(q1, 'funded_amt'))} ${gTxt(growth(sum(q1, 'funded_amt'), sum(q0, 'funded_amt')))}`)}
      ${kpi('منظومات مكتملة هذا الشهر', `<span class="num">${num(cur.completed)}</span> ${gTxt(growth(cur.completed, prev.completed))}`, `آخر 3 أشهر: ${num(sum(q1, 'completed'))} ${gTxt(growth(sum(q1, 'completed'), sum(q0, 'completed')))}`)}
      ${kpi('قدرة مركّبة — 12 شهراً', `<span class="num">${num(Math.round(sum(M, 'kw')))}</span> kW`, `${num(sum(M, 'completed'))} منظومة · ${mln(sum(M, 'completed_amt'))} دينار`)}
    </div>
    <div class="grid g2">
      <div class="card">${bars(M, 'created', { title: 'الطلبات الجديدة شهرياً — آخر 12 شهراً' })}</div>
      <div class="card">${bars(M, 'funded_amt', { title: 'التمويل المعزَّز من ائتمانات المصارف شهرياً (مليون دينار)', fmt: v => (v / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 }) })}</div>
    </div>
    <div class="grid g2 mt">
      <div class="card flush"><h3>حسب القطاع</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القطاع</th><th>الطلبات</th><th>الحصة</th><th>لدى المصارف</th><th>مكتملة</th><th>التمويل المعزَّز</th></tr></thead><tbody>
        ${d.sectors.map(s => `<tr><td><i class="sw" style="background:${SECTORS[s.k]?.[1] || '#888'}"></i> ${esc(SECTORS[s.k]?.[0] || s.k)}</td><td class="num">${s.n}</td>
          <td><div class="share"><i style="width:${(s.n / tot * 100).toFixed(1)}%"></i></div><span class="num small">${(s.n / tot * 100).toFixed(1)}%</span></td><td class="num">${s.live}</td><td class="num">${s.done}</td><td>${mln(s.amt)}</td></tr>`).join('')}
      </tbody></table></div></div>
      <div class="card flush"><h3>حسب المصرف</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>وصلته</th><th>معزَّزة</th><th>مكتملة</th><th>التمويل</th><th>متوسط المدة</th></tr></thead><tbody>
        ${d.banks.map(b => `<tr><td>${esc(bank(b.id))}</td><td class="num">${b.n}</td><td class="num">${b.funded}</td><td class="num">${b.done}</td><td>${mln(b.amt)}</td><td class="small">${b.days != null ? `<span class="num">${num(b.days)}</span> يوم` : '—'}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا بيانات</td></tr>'}
      </tbody></table></div></div>
    </div>
    <details class="card mt"><summary><b>جدول الأشهر</b> — الأرقام الكاملة خلف الرسمين</summary><div class="tbl-wrap mt"><table class="tbl"><thead><tr><th>الشهر</th><th>جديدة</th><th>أُرسلت للمصارف</th><th>معزَّزة</th><th>التمويل المعزَّز</th><th>مكتملة</th><th>kW</th></tr></thead><tbody>
      ${M.slice().reverse().map(r => `<tr><td>${monName(r.m)}</td><td class="num">${r.created}</td><td class="num">${r.submitted}</td><td class="num">${r.funded}</td><td>${mln(r.funded_amt)}</td><td class="num">${r.completed}</td><td class="num">${num(r.kw)}</td></tr>`).join('')}
    </tbody></table></div></details>`;
}

// ───────── إعلان المبادرات للمصارف ─────────
const SECTOR_OPTS = ['residential', 'industrial', 'project', 'agricultural', 'vet', 'other', 'vet_program'];
const RESP = { join: ['يشارك', 'ok'], decline: ['اعتذر', 'bad'] };
export async function initiativesView(ctx, body) {
  const { sb, orgs } = ctx;
  const [inis, rows] = await Promise.all([
    sb.from('initiatives').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('initiative_banks').select('*').then(r => r.data || []),
  ]);
  const banks = orgs.filter(o => o.type === 'bank');
  const bank = id => orgs.find(o => o.id === id)?.name || '—';
  body.innerHTML = `<div class="row mb"><p class="muted" style="margin:0;flex:1">أعلن مبادرة جديدة فيصل إشعار فوري لكل مصرف مختار، ويظهر هنا من اطّلع ومن أعلن المشاركة أو اعتذر.</p><button class="btn cyan" data-new>📣 إعلان مبادرة جديدة</button></div>
    ${inis.map(i => { const rs = rows.filter(r => r.initiative_id === i.id), seen = rs.filter(r => r.seen_at).length, join = rs.filter(r => r.response === 'join').length;
      return `<div class="card mb ${i.status === 'withdrawn' ? 'muted-card' : ''}"><div class="row" style="flex-wrap:wrap;gap:8px"><h3 style="margin:0">${esc(i.title)}</h3><span class="num small muted">${esc(i.code)}</span><span class="sp"></span>
          ${i.status === 'withdrawn' ? badge(['مسحوبة', 'muted']) : badge(['منشورة', 'ok'])} <span class="small">اطّلع <b class="num">${seen}</b>/<span class="num">${rs.length}</span> · يشارك <b class="num">${join}</b></span></div>
        <p style="margin:8px 0">${esc(i.summary)}</p>
        <div class="small muted">يبدأ ${esc(i.start_on)}${i.end_on ? ` · ينتهي ${esc(i.end_on)}` : ''}${i.budget ? ` · المخصص ${mln(i.budget)} دينار` : ''}${i.circular_no ? ` · تعميم <span class="num">${esc(i.circular_no)}</span>` : ''}${i.sectors?.length ? ` · ${i.sectors.map(s => esc(SECTORS[s]?.[0] || s)).join('، ')}` : ''}</div>
        <details class="mt"><summary class="small">المصارف (${rs.length})</summary><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المصرف</th><th>الاطلاع</th><th>الرد</th></tr></thead><tbody>
          ${rs.map(r => `<tr><td>${esc(bank(r.bank_id))}</td><td class="small">${r.seen_at ? `${dt(r.seen_at)}<div class="muted">${esc(r.seen_by_title || '')}</div>` : '<span class="muted">لم يطّلع</span>'}</td>
            <td class="small">${r.response ? `${badge(RESP[r.response])} ${dt(r.responded_at)}${r.response_note ? `<div class="muted">${esc(r.response_note)}</div>` : ''}` : '—'}</td></tr>`).join('')}</tbody></table></div></details>
        ${i.status === 'published' && ctx.profile.role === 'cbi_admin' ? `<div class="row mt"><span class="sp"></span><button class="btn ghost sm" data-wd="${i.id}">سحب المبادرة</button></div>` : ''}${i.withdraw_note ? `<p class="small muted">سُحبت: ${esc(i.withdraw_note)}</p>` : ''}</div>`; }).join('') || '<div class="card empty">لم تُعلَن مبادرات بعد.</div>'}`;
  body.querySelectorAll('[data-wd]').forEach(b => b.onclick = () => {
    const m = modal(`<h3>سحب المبادرة</h3><div class="field"><label>سبب السحب — يصل للمصارف</label><textarea class="input" rows="2" data-n></textarea></div><div class="row"><span class="sp"></span><button class="btn bad" data-go>سحب</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => { e.target.disabled = true; try { await rpc(sb, 'cbi_withdraw_initiative', { p_id: b.dataset.wd, p_note: m.el.querySelector('[data-n]').value }); m.close(); toast('سُحبت المبادرة وأُبلغت المصارف', 'ok'); initiativesView(ctx, body); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; } };
  });
  body.querySelector('[data-new]').onclick = () => {
    const today = new Date().toISOString().slice(0, 10);
    const m = modal(`<h3>إعلان مبادرة جديدة للمصارف</h3>
      <div class="field"><label>عنوان المبادرة</label><input class="input" data-k="title" placeholder="مثال: مبادرة تمويل منظومات الطاقة الشمسية للمعامل الصغيرة"></div>
      <div class="field"><label>الملخص (يظهر في الإشعار)</label><textarea class="input" rows="2" data-k="summary"></textarea></div>
      <div class="field"><label>التفاصيل والضوابط</label><textarea class="input" rows="5" data-k="details" placeholder="الفئة المستهدفة، السقوف، المدة، الضمانات، نسبة الفائدة…"></textarea></div>
      <div class="grid g2" style="gap:10px"><div class="field"><label>تاريخ البدء</label><input class="input" type="date" data-k="start_on" value="${today}"></div><div class="field"><label>تاريخ الانتهاء (اختياري)</label><input class="input" type="date" data-k="end_on"></div>
        <div class="field"><label>المخصص بالدينار (اختياري)</label><input class="input" data-k="budget" inputmode="numeric" dir="ltr"></div><div class="field"><label>رقم التعميم (اختياري)</label><input class="input" data-k="circular_no"></div></div>
      <label class="lbl">القطاعات المشمولة</label><div class="chips">${SECTOR_OPTS.map(k => `<label class="chip"><input type="checkbox" data-s value="${k}">${esc(SECTORS[k][0])}</label>`).join('')}</div>
      <label class="lbl mt">المصارف <span class="small muted">(بلا اختيار = كل المصارف)</span></label><div class="chips">${banks.map(b => `<label class="chip"><input type="checkbox" data-b value="${b.id}">${esc(b.name)}</label>`).join('')}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>نشر وإبلاغ المصارف</button></div>`, { wide: true });
    m.el.querySelectorAll('.chip input').forEach(c => c.onchange = () => c.closest('.chip').classList.toggle('on', c.checked));
    m.el.querySelector('[data-go]').onclick = async e => {
      const p = {}; m.el.querySelectorAll('[data-k]').forEach(x => p[x.dataset.k] = x.value.trim());
      p.sectors = [...m.el.querySelectorAll('[data-s]:checked')].map(x => x.value); p.banks = [...m.el.querySelectorAll('[data-b]:checked')].map(x => x.value);
      e.target.disabled = true;
      try { const r = await rpc(sb, 'cbi_publish_initiative', { p }); m.close(); toast(`نُشرت المبادرة ${r.code} وأُبلغت المصارف`, 'ok'); initiativesView(ctx, body); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

// ───────── المصرف: مبادرات البنك المركزي ─────────
export async function bankInitiatives(ctx, body) {
  const { sb, profile } = ctx;
  const [inis, rows] = await Promise.all([
    sb.from('initiatives').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('initiative_banks').select('*').eq('bank_id', profile.org_id).then(r => r.data || []),
  ]);
  const canReply = ['bank_md', 'bank_initiatives_mgr'].includes(profile.role);
  body.innerHTML = inis.map(i => { const r = rows.find(x => x.initiative_id === i.id) || {};
    return `<div class="card mb ${i.status === 'withdrawn' ? 'muted-card' : ''}"><div class="row" style="flex-wrap:wrap;gap:8px">${r.seen_at ? '' : '<span class="badge info">جديدة</span>'}<h3 style="margin:0">📣 ${esc(i.title)}</h3><span class="num small muted">${esc(i.code)}</span><span class="sp"></span>
        ${i.status === 'withdrawn' ? badge(['سحبها البنك المركزي', 'muted']) : r.response ? badge(RESP[r.response]) : badge(['بانتظار رد المصرف', 'warn'])}</div>
      <p style="margin:8px 0"><b>${esc(i.summary)}</b></p>${i.details ? `<div class="letter-body small">${esc(i.details)}</div>` : ''}
      <div class="small muted mt">من ${esc(i.created_by_title || 'البنك المركزي')} · ${dt(i.created_at)} · يبدأ ${esc(i.start_on)}${i.end_on ? ` · ينتهي ${esc(i.end_on)}` : ''}${i.budget ? ` · المخصص ${mln(i.budget)} دينار` : ''}${i.circular_no ? ` · تعميم <span class="num">${esc(i.circular_no)}</span>` : ''}</div>
      ${i.sectors?.length ? `<div class="chips mt">${i.sectors.map(s => `<span class="chip on"><i class="sw" style="background:${SECTORS[s]?.[1]}"></i>${esc(SECTORS[s]?.[0] || s)}</span>`).join('')}</div>` : ''}
      ${r.response_note ? `<p class="small">ردّكم: ${esc(r.response_note)} — ${esc(r.responded_by_title || '')}</p>` : ''}
      ${i.withdraw_note ? `<p class="small muted">سبب السحب: ${esc(i.withdraw_note)}</p>` : ''}
      ${canReply && i.status === 'published' && !r.response ? `<div class="row mt"><span class="sp"></span><button class="btn ghost sm" data-dec="${i.id}">اعتذار مسبّب</button><button class="btn ok sm" data-join="${i.id}">إعلان المشاركة</button></div>` : ''}</div>`; }).join('') || '<div class="card empty">لا مبادرات من البنك المركزي بعد.</div>';
  rows.filter(r => !r.seen_at).forEach(r => sb.rpc('bank_initiative_seen', { p_id: r.initiative_id }));
  const reply = (id, resp) => {
    const m = modal(`<h3>${resp === 'join' ? 'إعلان المشاركة في المبادرة' : 'الاعتذار عن المبادرة'}</h3><div class="field"><label>${resp === 'join' ? 'ملاحظة (اختيارية)' : 'سبب الاعتذار'}</label><textarea class="input" rows="3" data-n></textarea></div>
      <div class="row"><span class="sp"></span><button class="btn ${resp === 'join' ? 'ok' : 'bad'}" data-go>إرسال للبنك المركزي</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => { e.target.disabled = true; try { await rpc(sb, 'bank_initiative_respond', { p_id: id, p_response: resp, p_note: m.el.querySelector('[data-n]').value.trim() || null }); m.close(); toast('أُرسل ردّكم للبنك المركزي', 'ok'); bankInitiatives(ctx, body); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; } };
  };
  body.querySelectorAll('[data-join]').forEach(b => b.onclick = () => reply(b.dataset.join, 'join'));
  body.querySelectorAll('[data-dec]').forEach(b => b.onclick = () => reply(b.dataset.dec, 'decline'));
}

// ───────── حسابات هيئة النزاهة (يضيفها البنك المركزي) ─────────
export async function integrityUsersView(ctx, body) {
  const { sb, profile } = ctx;
  body.innerHTML = '<div class="card"><div class="spin"></div></div>';
  let list;
  try { list = await rpc(sb, 'cbi_integrity_users', {}); } catch (e) { body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; return; }
  const can = profile.role === 'cbi_admin';
  body.innerHTML = `<div class="notice">حسابات مدققي <b>هيئة النزاهة</b> يضيفها البنك المركزي وحده — لا يضيفها مشغّل النظام. صلاحيتها قراءة ورقابة، والمخاطبات بين الجهتين في تبويب «المخاطبات السرية».</div>
    <div class="card flush"><h3>مدققو هيئة النزاهة <span class="sp"></span>${can ? '<button class="btn cyan sm" data-add>إضافة حساب</button>' : ''}</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الرمز الوظيفي</th><th>الهاتف</th><th>الحالة</th><th></th></tr></thead><tbody>
    ${list.map(u => `<tr><td>${esc(u.full_name)}</td><td class="num" dir="ltr">${esc(u.username)}</td><td class="num">${esc(u.staff_code || '')}</td><td class="num" dir="ltr">${esc(u.phone || '—')}</td>
      <td>${u.disabled ? badge(['موقوف', 'bad']) : u.must_change_password ? badge(['بانتظار أول دخول', 'warn']) : badge(['فعّال', 'ok'])}</td>
      <td>${can ? `<div class="row" style="gap:6px"><button class="btn sm ghost" data-pw="${u.id}">كلمة مرور مؤقتة</button><button class="btn sm ${u.disabled ? 'ok' : 'ghost'}" data-dis="${u.id}" data-v="${u.disabled ? '0' : '1'}">${u.disabled ? 'تفعيل' : 'إيقاف'}</button></div>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">لا حسابات بعد.</td></tr>'}
    </tbody></table></div></div>`;
  const reload = () => integrityUsersView(ctx, body);
  body.querySelectorAll('[data-dis]').forEach(b => b.onclick = async () => { b.disabled = true; try { await rpc(sb, 'cbi_set_integrity_user', { p_user: b.dataset.dis, p: { disabled: b.dataset.v === '1' } }); toast('حُدّث الحساب', 'ok'); reload(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; } });
  body.querySelectorAll('[data-pw]').forEach(b => b.onclick = () => {
    const m = modal(`<h3>كلمة مرور مؤقتة</h3><p class="small muted">يُطلب من المدقق تغييرها عند أول دخول.</p><div class="field"><input class="input" data-p dir="ltr" placeholder="8 أحرف وأرقام على الأقل"></div><div class="row"><span class="sp"></span><button class="btn cyan" data-go>حفظ</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => { e.target.disabled = true; try { await rpc(sb, 'cbi_set_integrity_user', { p_user: b.dataset.pw, p: { password: m.el.querySelector('[data-p]').value } }); m.close(); toast('حُفظت كلمة المرور المؤقتة', 'ok'); reload(); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; } };
  });
  const add = body.querySelector('[data-add]');
  if (add) add.onclick = () => {
    const m = modal(`<h3>إضافة حساب مدقق في هيئة النزاهة</h3>
      <div class="field"><label>الاسم الكامل</label><input class="input" data-k="full_name"></div>
      <div class="field"><label>اسم المستخدم (حروف إنجليزية صغيرة)</label><input class="input" data-k="username" dir="ltr" placeholder="nz.ahmed"></div>
      <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" dir="ltr" inputmode="tel" placeholder="07xxxxxxxxx"></div>
      <div class="field"><label>كلمة مرور مؤقتة</label><input class="input" data-k="password" dir="ltr" placeholder="8 أحرف وأرقام على الأقل"></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-go>إنشاء الحساب</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      const d = {}; m.el.querySelectorAll('[data-k]').forEach(x => d[x.dataset.k] = x.value.trim());
      e.target.disabled = true;
      try { const r = await rpc(sb, 'cbi_create_integrity_user', { p: d }); m.close(); toast(`أُنشئ الحساب ${r.username} (${r.staff_code})`, 'ok'); reload(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}
