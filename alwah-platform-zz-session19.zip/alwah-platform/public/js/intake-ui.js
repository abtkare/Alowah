// الجلسة 16: قائمة التدقيق (النجوم الحمراء) ودراسة الجدوى وإحالة الخبير — مشتركة بين بوابة المصرف وبوابة المقترض
import { esc, badge, dt, rpc, toast, cleanErr, modal, viewDoc, PURPOSE, SPECIALTY, PURPOSE_SPEC, XREF_STATUS, wdTxt } from './core.js';

// تحميل كل ما يلزم لطلب واحد
export async function loadIntake(sb, app) {
  if (app.program === 'vet') return null;
  const [ck, refs, docs] = await Promise.all([
    rpc(sb, 'intake_checklist', { p_app: app.id }).catch(() => null),
    rpc(sb, 'app_expert_refs', { p_app: app.id }).catch(() => []),
    sb.from('app_documents').select('id,kind,mime,source,meta,created_at,uploaded_by_title').eq('application_id', app.id)
      .in('kind', ['quote', 'feasibility', 'expert_report']).order('created_at').then(r => r.data || []),
  ]);
  return { ck, refs: refs || [], docs };
}

const FIX_LABEL = { 1: 'الخطوة 1 — الهوية', 2: 'الخطوة 2 — «أور»', 3: 'الخطوة 3 — المصرف والمنظومة والمستندات', 4: 'الخطوة 4 — الضمان', 5: 'الخطوة 5 — الدفع والتوقيع', profile: 'ملفي الشخصي' };

// قائمة التدقيق مجمّعة: ✓ للمكتمل و★ حمراء للناقص
export function checklistHtml(ck, { borrower = false, skip = [] } = {}) {
  if (!ck?.items?.length) return '';
  const items = ck.items.filter(i => !skip.includes(i.key));
  const groups = [...new Set(items.map(i => i.group))];
  return `<div class="ck">${groups.map(g => `<div class="ck-g"><div class="ck-h">${esc(g)}</div>
    ${items.filter(i => i.group === g).map(i => `<div class="ck-i ${i.ok ? 'ok' : 'miss'}"><span class="ck-m">${i.ok ? '✓' : '★'}</span><span>${esc(i.label)}</span>
      ${!i.ok && borrower && i.fix ? `<span class="sp"></span><button type="button" class="linkbtn small" data-fix="${esc(i.fix)}">أكمل في ${esc(FIX_LABEL[i.fix] || 'الخطوة')}</button>` : ''}</div>`).join('')}</div>`).join('')}</div>`;
}

// إصدارات دراسة الجدوى: السابقة محفوظة، والحديثة بعلامة «محدّثة»
export function studiesHtml(docs, refs = []) {
  const fz = docs.filter(d => d.kind === 'feasibility').sort((a, b) => (b.meta?.version || 0) - (a.meta?.version || 0));
  const q = docs.filter(d => d.kind === 'quote').slice(-1)[0];
  const decided = id => refs.filter(r => r.feasibility_doc === id && ['conforming', 'non_conforming'].includes(r.status)).slice(-1)[0];
  return `<div class="studies">
    ${q ? `<div class="st-row"><span>📄 <b>عرض المورد المقدَّم</b> <span class="muted small">${dt(q.created_at)}</span></span><span class="sp"></span><button type="button" class="btn ghost sm" data-doc="${q.id}">عرض</button></div>` : ''}
    ${fz.map((d, i) => { const r = decided(d.id);
      return `<div class="st-row ${i === 0 ? 'cur' : 'old'}"><span>📊 <b>دراسة الجدوى — الإصدار <span class="num">${d.meta?.version || 1}</span></b>
        ${i === 0 && d.meta?.updated ? badge(['محدّثة', 'ok']) : ''}${i > 0 ? badge(['سابقة — محفوظة', 'muted']) : ''}${r ? ` ${badge([`قرار الخبير: ${XREF_STATUS[r.status][0]}`, XREF_STATUS[r.status][1]])}` : ''}
        <span class="muted small">${dt(d.created_at)}</span></span><span class="sp"></span><button type="button" class="btn ghost sm" data-doc="${d.id}">عرض</button></div>`; }).join('')}
    ${!q && !fz.length ? '<p class="muted small" style="margin:0">لا مستندات بعد.</p>' : ''}</div>`;
}

// سجل إحالات الخبراء
export function refsHtml(refs, { named = true } = {}) {
  if (!refs.length) return '';
  return `<div class="xrefs">${refs.slice().reverse().map(r => `<div class="xref ${r.status}">
    <div class="row" style="flex-wrap:wrap;gap:6px"><b>الجولة <span class="num">${r.round}</span></b><span class="num small muted">${esc(r.code)}</span>
      <span class="small">اختصاص ${esc(r.specialty_label || SPECIALTY[r.specialty])}</span><span class="sp"></span>${badge(XREF_STATUS[r.status] || [r.status, 'muted'])}</div>
    ${named && r.expert_name ? `<div class="small muted">الخبير: <b style="color:var(--text)">${esc(r.expert_name)}</b> · الرمز <code>${esc(r.expert_code || '')}</code> · اعتماد <span class="num">${esc(r.license_no || '')}</span> — ${esc(r.accreditor || '')}</div>` : ''}
    <div class="small muted">أُحيلت ${dt(r.created_at)}${r.received_at ? ` · استُلمت ${dt(r.received_at)}` : ''}${r.decided_at ? ` · القرار ${dt(r.decided_at)}` : ''} · المدة ${wdTxt(r.work_days)} من <span class="num">${r.sla_days}</span> أيام</div>
    ${r.decision_text ? `<div class="xdec"><b>القرار:</b> ${esc(r.decision_text)}${r.notes ? `<br><b>الملاحظة:</b> ${esc(r.notes)}` : ''}</div>` : ''}
    ${r.report_doc ? `<button type="button" class="btn ghost sm" data-doc="${r.report_doc}">تقرير الخبير</button>` : ''}
    ${r.cancel_note ? `<div class="small muted">سبب الإلغاء: ${esc(r.cancel_note)}</div>` : ''}</div>`).join('')}</div>`;
}

// بطاقة المصرف: قائمة التدقيق + دراسة الجدوى والخبير
export function bankIntakeCard(app, d, { mine, role }) {
  if (!d?.ck?.applies) return '';
  const { ck, refs, docs } = d, ex = ck.expert || {};
  const atIntake = app.stage === 6;
  const canRefer = mine && atIntake && role === 'bank_cs' && ['none', 'stale'].includes(ex.state);
  const open = refs.find(r => ['pending', 'received'].includes(r.status));
  return `<div class="card mb intake">
    <h3>قائمة التدقيق ${atIntake ? '— الاستقبال' : ''}<span class="sp"></span>${badge([`الغرض: ${PURPOSE[ck.purpose] || 'منزلي'}`, ck.purpose === 'household' ? 'info' : 'warn'])}</h3>
    ${ck.feasibility_rejections ? `<div class="notice warn" style="margin:0 0 8px"><span>⚠</span><span><b>مرفوض سابقاً بسبب دراسة الجدوى</b> (<span class="num">${ck.feasibility_rejections}</span> مرة) — أُعيد إرساله بنفس رقمه وبياناته مع دراسة محدّثة.</span></div>` : ''}
    ${atIntake ? `<div class="ck-sum ${ck.missing ? 'bad' : 'ok'}">${ck.missing ? `★ <b class="num">${ck.missing}</b> نواقص — لا يقبلها النظام. اضغط «رفض فوري — إرجاع للمقترض» ليُكمل النقص.` : '✓ الحساب والطلب مكتملا البيانات — يقبله النظام.'}</div>` : ''}
    ${checklistHtml(ck)}
    ${ex.required ? `<h3 class="mt">دراسة الجدوى والخبير المعتمد</h3>
      <div class="ck-sum ${ex.ok ? 'ok' : 'warn'}">${ex.ok ? '✓' : '…'} ${esc(ex.msg)}</div>
      ${studiesHtml(docs, refs)}
      ${refsHtml(refs)}
      <div class="row mt" style="gap:8px;flex-wrap:wrap">
        ${canRefer ? `<button type="button" class="btn cyan" data-xrefer>إحالة دراسة الجدوى إلى خبير معتمد</button>` : ''}
        ${mine && atIntake && role === 'bank_cs' && open ? `<button type="button" class="linkbtn" data-xcancel="${open.id}">إلغاء الإحالة ${esc(open.code)}</button>` : ''}
      </div>
      <p class="small muted" style="margin:8px 0 0">طلبات الأغراض الزراعية والصناعية والمشاريع: يحيل موظف الاستقبال دراسة الجدوى إلى خبير معتمد مختص من خارج المصرف. لا قبول قبل قرار «مطابق». القرار «غير مطابق» يرفض الطلب ويعيده للمقترض لرفع دراسة حقيقية محدّثة.</p>`
      : docs.length ? `<h3 class="mt">المستندات</h3>${studiesHtml(docs, refs)}` : ''}
  </div>`;
}

export function bindIntake(ctx, app, d, root) {
  if (!root) return;
  root.querySelectorAll('.intake [data-doc]').forEach(b => b.onclick = () => viewDoc(ctx.sb, b.dataset.doc));
  const rb = root.querySelector('[data-xrefer]'); if (rb) rb.onclick = () => referDialog(ctx, app, d);
  const cb = root.querySelector('[data-xcancel]'); if (cb) cb.onclick = () => {
    const m = modal(`<h3>إلغاء إحالة الخبير</h3><div class="field"><label>سبب الإلغاء</label><textarea class="input" rows="2" data-n></textarea></div><div class="row mt"><span class="sp"></span><button class="btn bad" data-go>إلغاء الإحالة</button></div>`);
    m.el.querySelector('[data-go]').onclick = async e => {
      e.target.disabled = true;
      try { await rpc(ctx.sb, 'cancel_expert_referral', { p_ref: cb.dataset.xcancel, p_note: m.el.querySelector('[data-n]').value }); m.close(); toast('أُلغيت الإحالة', 'ok'); document.querySelector('.drawer [data-close]')?.click(); ctx.refresh(); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
}

async function referDialog(ctx, app, d) {
  let experts = [];
  try { experts = await rpc(ctx.sb, 'experts_for', { p_app: app.id }); } catch (e) { return toast(cleanErr(e), 'bad'); }
  let spec = PURPOSE_SPEC[d.ck.purpose] || 'economic';
  const m = modal(`<h3>إحالة دراسة الجدوى إلى خبير معتمد</h3>
    <p class="small muted">الطلب <b class="num">${esc(app.code)}</b> · الغرض: ${esc(PURPOSE[d.ck.purpose])}${d.ck.feasibility_rejections ? ` · ${badge(['مرفوض سابقاً بسبب دراسة الجدوى', 'bad'])}` : ''}. يرى الخبير دراسة الجدوى وعرض المورد وملخص المشروع فقط — لا يرى اسم المقترض.</p>
    <div class="field"><label>اختصاص الخبير</label><select class="input" data-spec>${Object.entries(SPECIALTY).map(([k, t]) => `<option value="${k}" ${k === spec ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
    <div class="field"><label>الخبير المعتمد</label><div data-list class="xpick"></div></div>
    <div class="field"><label>ملاحظة للخبير (اختيارية)</label><textarea class="input" rows="2" data-n placeholder="مثال: التحقق من واقعية الإيرادات وكلفة التشغيل"></textarea></div>
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-go>إحالة</button></div>`, { wide: true });
  let sel = null;
  const paint = () => {
    const list = experts.filter(x => (x.specialties || []).includes(spec));
    if (!list.some(x => x.id === sel)) sel = list[0]?.id || null;
    m.el.querySelector('[data-list]').innerHTML = list.length ? list.map(x => `<label class="xp ${x.id === sel ? 'on' : ''}"><input type="radio" name="xp" value="${x.id}" ${x.id === sel ? 'checked' : ''}>
      <div><b>${esc(x.name)}</b> <code class="small">${esc(x.code || '')}</code><div class="small muted">${esc(x.qualification || '')}</div>
      <div class="small muted">اعتماد <span class="num">${esc(x.license_no)}</span> — ${esc(x.accreditor)} · ${esc(x.governorate || '')}${x.same_gov ? ' ' + badge(['نفس المحافظة', 'ok']) : ''}</div></div>
      <span class="sp"></span><span class="small">قيد الدراسة <b class="num">${x.open}</b><br>أنجز <b class="num">${x.done}</b></span></label>`).join('')
      : '<div class="notice warn">لا يوجد خبير معتمد متاح في هذا الاختصاص — اطلب من مشغّل النظام إضافته.</div>';
    m.el.querySelectorAll('input[name=xp]').forEach(r => r.onchange = () => { sel = r.value; paint(); });
  };
  m.el.querySelector('[data-spec]').onchange = e => { spec = e.target.value; paint(); };
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-go]').onclick = async e => {
    if (!sel) return toast('اختر الخبير', 'bad');
    e.target.disabled = true;
    try {
      const r = await rpc(ctx.sb, 'refer_expert', { p_app: app.id, p_expert: sel, p_specialty: spec, p_note: m.el.querySelector('[data-n]').value });
      m.close(); toast(`أُحيلت دراسة الجدوى إلى الخبير — ${r.code}`, 'ok'); document.querySelector('.drawer [data-close]')?.click(); ctx.refresh();
    } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  paint();
}

// اختيار ملف PDF أو صورة (الصور تُضغط)، يعيد { data, meta } أو null
export function pickFile({ maxMB = 3 } = {}) {
  return new Promise(resolve => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'application/pdf,image/jpeg,image/png'; inp.style.display = 'none';
    document.body.appendChild(inp);
    inp.onchange = () => {
      const f = inp.files[0]; inp.remove();
      if (!f) return resolve(null);
      if (f.size > maxMB * 1e6) { toast(`حجم الملف أكبر من ${maxMB} ميغابايت`, 'bad'); return resolve(null); }
      const rd = new FileReader();
      rd.onload = () => {
        if (f.type === 'application/pdf') return resolve({ data: rd.result, meta: { live: false, name: f.name, type: f.type, size: f.size } });
        const img = new Image();
        img.onload = () => {
          const s = Math.min(1, 1800 / Math.max(img.naturalWidth, img.naturalHeight)), c = document.createElement('canvas');
          c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve({ data: c.toDataURL('image/jpeg', 0.85), meta: { live: false, name: f.name, type: 'image/jpeg' } });
        };
        img.onerror = () => { toast('تعذّر قراءة الصورة', 'bad'); resolve(null); };
        img.src = rd.result;
      };
      rd.readAsDataURL(f);
    };
    inp.click();
  });
}
