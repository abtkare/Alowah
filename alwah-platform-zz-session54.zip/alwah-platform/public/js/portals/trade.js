// بوابة المقترض — برامج المصارف (الجلسة 47): قروض المصدّرين، القروض التجارية، قروض التجارة الإلكترونية
// الخطوات: الهوية ← نشاطك ← التمويل والمستندات ← الضمان ← الدفع والإرسال
import { cameraCapture } from '../capture.js';
import { wizHead, wireWizHead } from '../wizard-ui.js';
import { esc, num, iqd, dt, ago, badge, GUARANTEE, rpc, toast, cleanErr, GOVS, govOptions, installment, modal, askOtp, digits, PAY_METHODS, PAY_LABEL,
  TRADE_KINDS, TRADE_SHORT, TRADE_DOCS, IND_CATS } from '../core.js';

let A;
const T = {};                // البرامج المطلقة، برنامج الطلب الحالي، مستنداته
export function initTrade(api) { A = api; }
const C = () => A.C();
const set = () => A.S.ref.set;
export const TRADE_STEPS = ['التحقق من الهوية', 'نشاطك', 'التمويل والمستندات', 'الضمان', 'الدفع والإرسال'];
const KIND_IC = { export: '🚢', commercial: '🏪', ecommerce: '🛒', industrial: '🏭' };
const G_TXT = { single_salary: ['👤', 'كفيل موظف', 'موظف حكومي أو قطاع خاص براتب ثابت'], multi_salary: ['👥', 'كفيلان موظفان', 'لمبالغ أكبر'], mortgage: ['🏠', 'رهن عقار', 'سند عقار باسمك أو بوكالة'], gold: ['🪙', 'رهن ذهب', 'يُسلَّم للفرع ويُوزن ويُقيَّم'] };
const DISB = { supplier: 'يُصرف للموردين مباشرة بفواتير', account: 'يُصرف إلى حسابك في المصرف', mixed: 'للموردين بفواتير والباقي إلى حسابك' };
const mlnT = n => `<span class="num">${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`;
const bankOf = id => C().orgs.find(o => o.id === id);

export async function loadTrade() {
  const { sb } = C(), active = A.S.active;
  const [progs, docs] = await Promise.all([
    sb.from('bank_programs').select('*').in('status', ['active', 'paused', 'closed']).order('created_at').then(r => r.data || []),
    active && TRADE_KINDS[active.program] ? sb.from('app_documents').select('id,kind,data,source,mime,meta').eq('application_id', active.id).then(r => r.data || []) : [],
  ]);
  T.progs = progs; T.docs = docs;
}
const progOf = app => T.progs?.find(p => p.id === app?.program_id);
const liveProgs = () => (T.progs || []).filter(p => p.status === 'active' && bankOf(p.bank_id)?.meta?.accepting !== false);

// بطاقة البرامج في الصفحة الرئيسية للمقترض
export function tradeBanner() {
  return `<a class="card mb vet-banner" href="#biz"><div class="vb-ic">🚢</div><div><span class="pill">برامج المصارف</span>
    <h2>صناعي أو تاجر أو مصدّر أو صاحب متجر إلكتروني؟</h2><p>القروض الصناعية، وقروض المصدّرين، والقروض التجارية، وتمويل المتاجر الإلكترونية — كل مصرف يطلق برامجه بشروطها، قارن وقدّم من هاتفك.</p></div><span class="go">اعرض البرامج ←</span></a>`;
}

// ───────── صفحة البرامج وبدء الطلب ─────────
export async function pageBizStart(body) {
  await loadTrade();
  const active = A.S.active, p = C().profile;
  const F = C().bizF = C().bizF || { kind: '' };
  const list = liveProgs().filter(x => !F.kind || x.kind === F.kind);
  body.innerHTML = `
    <section class="cz-hero vet-hero"><div><span class="pill">برامج المصارف</span>
      <h1>موّل تجارتك أو صادراتك أو متجرك الإلكتروني</h1>
      <p>كل مصرف يحدد شروط برنامجه: المبلغ والمدة والفائدة والضمان والمستندات. اختر البرنامج الأنسب، وقدّم بخمس خطوات من هاتفك.</p></div>
      <ol class="how">${TRADE_STEPS.map((t, i) => `<li><i>${i + 1}</i>${t}</li>`).join('')}</ol></section>
    ${active ? `<div class="notice warn mb">${TRADE_KINDS[active.program] && active.stage <= 5 ? `لديك طلب قائم <b class="num">${esc(active.code)}</b> — <a href="#apply">أكمله</a>.` : `لديك طلب قائم (<b class="num">${esc(active.code)}</b>). طلب واحد قائم لكل مقترض — تابعه من «طلبي».`}</div>` : ''}
    <div class="seg mb" data-kf style="flex-wrap:wrap;max-width:100%"><button type="button" data-k="" class="${!F.kind ? 'on' : ''}">الكل</button>${Object.keys(TRADE_KINDS).map(k => `<button type="button" data-k="${k}" class="${F.kind === k ? 'on' : ''}">${KIND_IC[k]} ${TRADE_SHORT[k]}</button>`).join('')}</div>
    ${list.length ? `<div class="grid g2" style="gap:12px">${list.map(x => { const b = bankOf(x.bank_id), q = x.params || {};
      return `<div class="card" style="margin:0"><div class="row"><i class="bdot" style="background:${esc(b?.meta?.color || '#4356A3')}"></i><b>${esc(b?.name || '')}</b><span class="sp"></span><span class="badge info">${KIND_IC[x.kind]} ${esc(TRADE_SHORT[x.kind])}</span></div>
        <h3 style="margin:8px 0 4px">${esc(x.name)}</h3>${x.summary ? `<p class="small muted" style="margin:0 0 6px">${esc(x.summary)}</p>` : ''}
        <dl class="kv small"><dt>المبلغ</dt><dd>${mlnT(q.min_amount)} — ${mlnT(q.max_amount)} د.ع</dd><dt>المدة</dt><dd>حتى <span class="num">${q.max_term}</span> شهراً${q.grace_max ? `، سماح حتى <span class="num">${q.grace_max}</span>` : ''}</dd>
          <dt>الفائدة السنوية</dt><dd><b class="num">${q.rate}%</b> · عمولة <span class="num">${q.commission_pct}%</span></dd><dt>الضمان</dt><dd>${(q.guarantees || []).map(g => G_TXT[g][1]).join('، ')}</dd>
          <dt>الصرف</dt><dd>${DISB[q.disburse] || ''}</dd>${q.min_activity_months ? `<dt>الشرط</dt><dd>نشاط قائم منذ <span class="num">${q.min_activity_months}</span> شهراً على الأقل</dd>` : ''}
          ${(q.governorates || []).length ? `<dt>المحافظات</dt><dd>${esc(q.governorates.join('، '))}</dd>` : ''}</dl>
        <details class="small mt"><summary>المستندات المطلوبة (<span class="num">${(q.docs || []).length}</span>)</summary><ul style="margin:6px 0">${(q.docs || []).map(k => `<li>${esc(TRADE_DOCS[k] || k)}</li>`).join('')}</ul>${q.conditions ? `<p class="muted">${esc(q.conditions)}</p>` : ''}</details>
        ${active ? '' : `<div class="row mt"><span class="sp"></span><button type="button" class="btn cyan" data-go="${x.id}">قدّم على هذا البرنامج ←</button></div>`}</div>`; }).join('')}</div>`
      : '<div class="card empty">لا توجد برامج مطلقة من هذا النوع حالياً — تطلقها الإدارات العليا للمصارف تباعاً.</div>'}`;
  body.querySelectorAll('[data-kf] [data-k]').forEach(b => b.onclick = () => { F.kind = b.dataset.k; pageBizStart(body); });
  body.querySelectorAll('[data-go]').forEach(b => b.onclick = () => {
    const x = T.progs.find(y => y.id === b.dataset.go), govs = x.params?.governorates || [];
    const m = modal(`<h3>${KIND_IC[x.kind]} ${esc(x.name)}</h3><p class="small muted">${esc(bankOf(x.bank_id)?.name || '')}</p>
      <div class="field"><label>محافظة نشاطك</label><select class="input" data-gv>${govs.length ? `<option value="">اختر المحافظة</option>${govs.map(g => `<option ${g === p.governorate ? 'selected' : ''}>${esc(g)}</option>`).join('')}` : govOptions(p.governorate || '')}</select></div>
      <div class="field"><label>المدينة / الحي</label><input class="input" data-ct value="${esc(p.city || '')}"></div>
      ${x.params?.conditions ? `<div class="notice"><span>ℹ</span><span class="small">${esc(x.params.conditions)}</span></div>` : ''}
      <div class="row"><span class="small muted">يُحفظ تقدمك تلقائياً.</span><span class="sp"></span><button class="btn cyan" data-s>ابدأ الطلب ←</button></div>`);
    m.el.querySelector('[data-s]').onclick = async e => {
      const gov = m.el.querySelector('[data-gv]').value; if (!gov) return toast('اختر المحافظة', 'bad');
      e.target.disabled = true;
      try {
        await rpc(C().sb, 'start_trade_application', { p_program: x.id, p_governorate: gov, p_city: m.el.querySelector('[data-ct]').value.trim() || null });
        m.close(); await A.load(); C().czStep = null; location.hash = '#apply'; toast('بدأ طلبك — الخطوة الأولى: التحقق من الهوية', 'ok');
      } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  });
}

// ───────── «طلبي»: المسودة والمتابعة ─────────
export async function homeDraftTrade(body, app, first) {
  await loadTrade();
  const x = progOf(app), b = app.biz || {};
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>طلبك محفوظ — أكمل الخطوات وأرسله للمصرف.</p></div></div>
    <div class="card mb draft"><div class="draft-b" style="flex:1">
      <div class="row"><span class="badge info"><i class="dot"></i>مسودة</span><b class="num">${esc(app.code)}</b><span class="sp"></span><span class="small muted">بدأ ${ago(app.created_at)}</span></div>
      <h2 style="font-size:21px;margin:8px 0 2px">${esc(b.business_name || x?.name || TRADE_KINDS[app.program])}</h2>
      <div class="muted">${esc(x?.name || '')} · ${esc(bankOf(x?.bank_id)?.name || '')}${app.amount ? ` · ${iqd(app.amount)}` : ''}</div>
      ${x && x.status !== 'active' ? '<div class="notice warn mt">أوقف المصرف هذا البرنامج حالياً — لا يمكن إرسال الطلب حتى يعيد تشغيله، أو ألغِ الطلب واختر برنامجاً آخر.</div>' : ''}
      <div class="prog"><i style="width:${(app.stage - 1) * 20}%"></i></div>
      <div class="small muted">أنجزت <b class="num">${app.stage - 1}</b> من 5 خطوات — التالية: <b style="color:var(--text)">${esc(TRADE_STEPS[app.stage - 1])}</b></div>
      <div class="row mt"><a class="btn cyan" href="#apply">أكمل طلبك</a><button class="btn ghost" data-cancel>إلغاء الطلب</button></div>
    </div></div>`;
  body.querySelector('[data-cancel]').onclick = () => A.cancelApp(app);
}

export async function tradeTrackCard(app) {
  await loadTrade();
  const x = progOf(app), b = app.biz || {};
  return `<div class="card"><h3>${KIND_IC[app.program] || ''} ${esc(TRADE_KINDS[app.program])}</h3><dl class="kv"><dt>البرنامج</dt><dd>${esc(x?.name || '')}</dd>
    <dt>النشاط</dt><dd>${esc(b.business_name || '')}<div class="small muted">${esc(b.activity || '')}</div></dd><dt>الغرض</dt><dd>${esc(b.purpose || '')}</dd>
    <dt>التمويل</dt><dd><b>${iqd(app.amount)}</b></dd><dt>المصرف</dt><dd>${esc(bankOf(app.bank_id)?.name || '—')}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd>
    <dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً منها <span class="num">${app.grace_months || 0}</span> سماح</dd><dt>الصرف</dt><dd>${DISB[x?.params?.disburse] || ''}</dd></dl>${app.program === 'industrial' ? '<div data-union-box></div>' : ''}</div>`;
}
// الجلسة 52: صندوق اتحاد الصناعات في بطاقة المتابعة
export function mountTrackUnion(root, app) {
  const box = root.querySelector('[data-union-box]');
  if (box) import('../union-ui.js').then(m => m.mountUnionReport(C(), app, box)).catch(() => {});
}

// ───────── المعالج ─────────
export async function pageApplyTrade(body, app) {
  await loadTrade();
  const step = Math.min(C().czStep || app.stage, app.stage), x = progOf(app);
  const sub = ['التحقق بالسيلفي', 'بيانات النشاط', 'المبلغ والمدة والمستندات', 'الكفلاء أو الذهب أو العقار', 'العمولة والتوقيع'];
  body.innerHTML = `
    ${wizHead({ title: x?.name || TRADE_KINDS[app.program], sub: `رقم <b class="num">${esc(app.code)}</b> · ${esc(bankOf(x?.bank_id)?.name || '')}${app.amount ? ` · ${iqd(app.amount)}` : ''}`, steps: TRADE_STEPS.map((t, i) => [t, sub[i]]), cur: step - 1, done: app.stage - 1, reach: app.stage - 1 })}
    <div class="card wiz-body" id="wb"></div>`;
  wireWizHead(body, i => { C().czStep = i + 1; pageApplyTrade(body, app); });
  const wb = body.querySelector('#wb'), done = step < app.stage;
  if (!x) { wb.innerHTML = '<div class="notice warn">برنامج الطلب غير متاح.</div>'; return; }
  if (step === 1) return A.step1(wb, app, done);
  if (step === 2) return x.kind === 'industrial' ? istep2(wb, app, x, done) : tstep2(wb, app, x, done);
  if (step === 3) return tstep3(wb, app, x, done);
  if (step === 4) return A.step4(wb, app, done);
  return tstep5(wb, app, x);
}
const nextBtn = (wb, again) => {
  wb.querySelector('[data-edit]').onclick = again;
  wb.querySelector('[data-next]').onclick = () => { C().czStep = null; A.pageApply(C().root.querySelector('#cz')); };
};
const doneRow = '<div class="row mt"><button class="btn ghost" data-edit>تعديل هذه الخطوة</button><span class="sp"></span><button class="btn cyan" data-next>الخطوة التالية ←</button></div>';

// 2) النشاط
function tstep2(wb, app, x, done, edit) {
  const b = app.biz || {}, k = x.kind;
  if (done && !edit) {
    wb.innerHTML = `<div class="done-box"><span class="ok-ic">✓</span><div><b>${esc(b.business_name || '')}</b><dl class="kv mt"><dt>النشاط</dt><dd>${esc(b.activity || '')}</dd><dt>السجل</dt><dd class="num">${esc(b.reg_no || '')}</dd>
      <dt>منذ</dt><dd><span class="num">${b.activity_months ?? ''}</span> شهراً</dd>${k === 'export' ? `<dt>التصدير</dt><dd>${esc(b.goods || '')} ← ${esc(b.destination || '')}</dd>` : ''}${k === 'ecommerce' ? `<dt>المتجر</dt><dd dir="ltr">${esc(b.store_url || '')}</dd>` : ''}</dl></div></div>${doneRow}`;
    return nextBtn(wb, () => tstep2(wb, app, x, done, true));
  }
  const f = (key, label, ph = '', attrs = '') => `<div class="field"><label>${label}</label><input class="input" data-k="${key}" value="${esc(b[key] ?? '')}" placeholder="${esc(ph)}" ${attrs}></div>`;
  const govs = x.params?.governorates || [];
  wb.innerHTML = `<h2>نشاطك</h2><p class="muted">بيانات النشاط كما في سجلك التجاري. يراها المصرف عند دراسة طلبك.</p>
    <div class="card soft mb"><div class="grid g2" style="gap:12px">
      ${f('business_name', 'اسم النشاط أو الشركة أو المتجر', 'مثال: شركة النخلة للتجارة')}${f('activity', 'نوع النشاط', 'مثال: تجارة مواد غذائية')}
      <div class="field"><label>الصفة</label><div class="seg" style="margin:0"><button type="button" data-lf="individual" class="${b.legal_form !== 'company' ? 'on' : ''}">نشاط فردي</button><button type="button" data-lf="company" class="${b.legal_form === 'company' ? 'on' : ''}">شركة</button></div></div>
      ${f('reg_no', 'رقم السجل التجاري أو هوية غرفة التجارة', '', 'dir="ltr"')}
      <div class="field"><label>محافظة النشاط</label><select class="input" data-k="governorate">${govs.length ? govs.map(g => `<option ${g === (b.governorate || app.governorate) ? 'selected' : ''}>${esc(g)}</option>`).join('') : govOptions(b.governorate || app.governorate || '')}</select></div>
      ${f('city', 'المدينة / الحي')}<div class="field" style="grid-column:1/-1"><label>العنوان</label><input class="input" data-k="address" value="${esc(b.address || '')}" placeholder="الشارع، أقرب نقطة دالة"></div>
      ${f('start_year', 'سنة بدء النشاط', '2020', 'inputmode="numeric" maxlength="4" dir="ltr"')}${f('start_month', 'شهر بدء النشاط', '1–12', 'inputmode="numeric" maxlength="2" dir="ltr"')}
      ${f('employees', 'عدد العاملين (اختياري)', '', 'inputmode="numeric" dir="ltr"')}${f('monthly_sales', 'المبيعات الشهرية التقريبية (د.ع، اختياري)', '', 'inputmode="numeric" dir="ltr"')}
    </div>${x.params?.min_activity_months ? `<p class="small muted" style="margin:8px 0 0">يشترط البرنامج نشاطاً قائماً منذ <b class="num">${x.params.min_activity_months}</b> شهراً على الأقل.</p>` : ''}</div>
    ${k === 'export' ? `<div class="card soft mb"><h3>🚢 التصدير</h3><div class="grid g2" style="gap:12px">${f('export_license_no', 'رقم إجازة التصدير', '', 'dir="ltr"')}${f('goods', 'البضاعة المصدَّرة', 'مثال: تمور')}
      ${f('destination', 'بلد التصدير', 'مثال: الإمارات')}${f('importer', 'اسم المستورد')}${f('contract_value', 'قيمة العقد أو الطلبية (د.ع، اختياري)', '', 'inputmode="numeric" dir="ltr"')}</div></div>` : ''}
    ${k === 'ecommerce' ? `<div class="card soft mb"><h3>🛒 المتجر الإلكتروني</h3><div class="grid g2" style="gap:12px">${f('store_url', 'رابط المتجر أو صفحته', 'example.iq', 'dir="ltr"')}${f('platforms', 'منصات البيع (اختياري)', 'إنستغرام، فيسبوك…')}
      ${f('emerchant_license_no', 'رقم إجازة التجارة الإلكترونية — وزارة التجارة (منصة التاجر الإلكتروني)', '', 'dir="ltr"')}${f('daman_no', 'رقم التسجيل في منصة «ضمان»', '', 'dir="ltr"')}</div>
      <p class="small muted" style="margin:8px 0 0">التسجيل في «ضمان» وإجازة التجارة الإلكترونية من وزارة التجارة شرطان لهذا التمويل.</p></div>` : ''}
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>حفظ ومتابعة ←</button></div>`;
  let lf = b.legal_form || 'individual';
  wb.querySelectorAll('[data-lf]').forEach(btn => btn.onclick = () => { lf = btn.dataset.lf; wb.querySelectorAll('[data-lf]').forEach(z => z.classList.toggle('on', z === btn)); });
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = { legal_form: lf }; wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    ['start_year', 'start_month', 'employees', 'monthly_sales', 'contract_value'].forEach(z => { if (d[z] != null) d[z] = digits(d[z]); });
    e.target.disabled = true;
    try { await A.saveStep(app, 2, d, 'حُفظت بيانات النشاط'); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 3) التمويل والمستندات والضمان
function tstep3(wb, app, x, done, edit) {
  const q = x.params || {};
  if (done && !edit) {
    wb.innerHTML = `<div class="done-box"><span class="ok-ic">✓</span><div><b>${iqd(app.amount)}</b><dl class="kv mt"><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً منها <span class="num">${app.grace_months || 0}</span> سماح</dd>
      <dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd><dt>الغرض</dt><dd>${esc(app.biz?.purpose || '')}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type] || '')}</dd>
      <dt>المستندات</dt><dd><span class="num">${(q.docs || []).filter(k => T.docs.some(d => d.kind === k)).length}</span> من <span class="num">${(q.docs || []).length}</span></dd></dl></div></div>${doneRow}`;
    return nextBtn(wb, () => tstep3(wb, app, x, done, true));
  }
  const st = { amount: app.amount || '', term: app.term_months || Math.min(36, q.max_term), grace: app.grace_months || 0, purpose: app.biz?.purpose || '', g: app.guarantee_type || (q.guarantees || [])[0] };
  const paint = () => {
    const amt = Number(digits(st.amount)) || 0, inst = amt ? installment(amt, Number(q.rate), Math.max(1, st.term - st.grace)) : 0;
    const errs = [];
    if (amt && (amt < q.min_amount || amt > q.max_amount)) errs.push(`المبلغ بين ${num(q.min_amount)} و${num(q.max_amount)} د.ع`);
    const have = k => T.docs.find(d => d.kind === k);
    const feas = x.kind === 'industrial' && Number(q.feasibility_from || 0) > 0 && amt >= Number(q.feasibility_from);   // الجلسة 52
    const docs = feas && !(q.docs || []).includes('ind_feasibility') ? [...(q.docs || []), 'ind_feasibility'] : (q.docs || []);
    wb.innerHTML = `<h2>التمويل والمستندات</h2>
      <div class="card soft mb"><h3>1. المبلغ والمدة</h3>
        <div class="field"><label>مبلغ التمويل (د.ع) — من ${num(q.min_amount)} إلى ${num(q.max_amount)}</label><input class="input num" dir="ltr" inputmode="numeric" data-v="amount" value="${esc(st.amount ? num(digits(st.amount)) : '')}"></div>
        <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${st.term}</span> شهراً</b></div>
        <input type="range" class="range" data-r="term" min="${q.min_term}" max="${q.max_term}" step="1" value="${st.term}" aria-label="مدة السداد">
        ${q.grace_max ? `<div class="row"><span class="small">مدة السماح (داخل المدة)</span><span class="sp"></span><b><span class="num">${st.grace}</span> شهراً</b></div>
        <input type="range" class="range" data-r="grace" min="0" max="${q.grace_max}" step="1" value="${st.grace}" aria-label="مدة السماح">` : ''}
        <div class="review"><dl class="kv"><dt>الفائدة السنوية</dt><dd class="num">${q.rate}%</dd><dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(inst)} × <span class="num">${st.term - st.grace}</span> شهراً</dd></dl>
          ${errs.map(z => `<div class="small" style="color:var(--bad)">• ${esc(z)}</div>`).join('')}</div>
        <div class="field mt"><label>غرض التمويل</label>${(q.purposes || []).length ? `<select class="input" data-v="purpose"><option value="">اختر الغرض</option>${q.purposes.map(z => `<option ${z === st.purpose ? 'selected' : ''}>${esc(z)}</option>`).join('')}</select>`
          : `<input class="input" data-v="purpose" value="${esc(st.purpose)}" placeholder="مثال: شراء بضاعة">`}</div></div>
      <div class="card soft mb"><h3>2. الضمان الذي تقدّمه</h3><div class="gpick" role="radiogroup">${(q.guarantees || []).map(k => `<button type="button" role="radio" aria-checked="${k === st.g}" data-gk="${k}" class="${k === st.g ? 'on' : ''}"><i>${G_TXT[k][0]}</i><span><b>${G_TXT[k][1]}</b><small>${G_TXT[k][2]}</small></span></button>`).join('')}</div>
        <p class="small muted" style="margin:6px 0 0">تكتب بيانات الضمان في الخطوة التالية.</p></div>
      <div class="card soft mb"><h3>3. المستندات</h3><p class="small muted" style="margin-top:0">صوّرها بالكاميرا أو ارفعها ملفاً (صورة أو PDF حتى 3 ميغابايت).</p>
        ${x.kind === 'industrial' ? `<div class="notice info mb small">🏭 بعد الحفظ يصل طلبك آلياً إلى <b>اتحاد الصناعات العراقي</b> ليكشف مهندسه على معملك ويؤيد طلبك للمصرف. ${Number(q.feasibility_from) ? `القرض من ${num(q.feasibility_from)} د.ع فأكثر يحتاج دراسة جدوى.` : ''}</div>` : ''}
        ${docs.map(k => `<div class="row" style="gap:10px;margin-bottom:10px;align-items:center"><span style="font-size:22px">${have(k) ? (String(have(k).data || '').startsWith('data:application/pdf') ? '📄' : '🖼') : '📎'}</span><div style="flex:1"><b class="small">${esc(TRADE_DOCS[k] || k)}</b><div>${have(k) ? badge(['مرفق', 'ok']) : badge(['مطلوب', 'warn'])}</div></div>
          <button type="button" class="btn sm ${have(k) ? 'ghost' : 'cyan'}" data-doc="${k}">${have(k) ? 'استبدال' : '📷 إرفاق'}</button></div>`).join('')}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>حفظ ومتابعة ←</button></div>`;
    wb.querySelector('[data-v=amount]').onchange = e => { st.amount = digits(e.target.value); paint(); };
    wb.querySelector('[data-v=purpose]').onchange = wb.querySelector('[data-v=purpose]').oninput = e => { st.purpose = e.target.value; };
    wb.querySelectorAll('[data-r]').forEach(r => r.oninput = () => { st[r.dataset.r] = Number(r.value); if (st.grace > st.term - 3) st.grace = Math.max(0, st.term - 3); paint(); wb.querySelector(`[data-r=${r.dataset.r}]`)?.focus(); });
    wb.querySelectorAll('[data-gk]').forEach(b => b.onclick = () => { st.g = b.dataset.gk; paint(); });
    wb.querySelectorAll('[data-doc]').forEach(b => b.onclick = async () => {
      const k = b.dataset.doc, shot = await cameraCapture({ title: `صوّر: ${TRADE_DOCS[k]}`, allowFile: true });
      if (!shot) return;
      try { await rpc(C().sb, 'trade_doc_add', { p_app: app.id, p_kind: k, p_data: shot.data, p_source: shot.meta?.live ? 'camera' : 'file', p_meta: shot.meta || {} });
        T.docs = T.docs.filter(d => d.kind !== k).concat({ kind: k, data: shot.data, meta: shot.meta, source: shot.meta?.live ? 'camera' : 'file' }); toast('حُفظ المستند', 'ok'); paint(); }
      catch (e) { toast(cleanErr(e), 'bad'); }
    });
    wb.querySelector('[data-ok]').onclick = async e => {
      const amt = Number(digits(st.amount)) || 0;
      if (!amt) return toast('اكتب مبلغ التمويل', 'bad');
      if (errs.length) return toast(errs[0], 'bad');
      if (!st.purpose.trim()) return toast('اختر غرض التمويل', 'bad');
      const miss = docs.filter(k => !have(k));
      if (miss.length) return toast(`أرفق: ${TRADE_DOCS[miss[0]]}${miss.length > 1 ? ` و${miss.length - 1} غيره` : ''}`, 'bad');
      e.target.disabled = true;
      try { await A.saveStep(app, 3, { amount: String(amt), term_months: st.term, grace_months: st.grace, purpose: st.purpose.trim(), guarantee_type: st.g }, 'حُفظ التمويل والمستندات'); }
      catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
    };
  };
  paint();
}

// 5) الدفع والتوقيع والإرسال
function tstep5(wb, app, x) {
  if (x.kind === 'industrial' && !wb.dataset.un) return unionGate(wb, app, x);
  delete wb.dataset.un;
  const q = x.params || {}, bk = bankOf(x.bank_id);
  const f = [['عمولة المصرف', Math.round(app.amount * Number(q.commission_pct || 0) / 100), true], ['رسم دراسة الملف', Number(q.file_fee || 0)], ['أجور الكشف الموقعي', Number(set().inspection_fee || 0)], ['عمولة المنصة', Number(set().platform_fee || 0)]];
  if (T.unFee) f.push([T.unFee[0], T.unFee[1]]);   // الجلسة 52: أجور كشف الاتحاد (وبدل الانتماء للعضو الجديد)
  const tot = f.reduce((t, z) => t + z[1], 0);
  let paid = null, method = 'zaincash';
  C().sb.from('payments').select('*').eq('application_id', app.id).then(r => { paid = r.data || []; paint(); });
  const paint = () => {
    if (!paid || !wb.isConnected) return;
    const pay = paid.find(z => z.bank_id === bk.id && z.status === 'paid'), off = x.status !== 'active';
    wb.innerHTML = `<h2>دفع العمولة وإرسال الطلب</h2><p class="muted">يُرسل طلبك إلى ${esc(bk?.name || '')} بعد دفع العمولة والرسوم، ثم توقيعك الإلكتروني.</p>
      ${off ? '<div class="notice warn">أوقف المصرف هذا البرنامج حالياً — لا يمكن الإرسال حتى يعيد تشغيله.</div>' : ''}
      <div class="review"><h3>ملخص الطلب</h3><dl class="kv"><dt>البرنامج</dt><dd>${esc(x.name)}</dd><dt>النشاط</dt><dd>${esc(app.biz?.business_name || '')}</dd><dt>التمويل</dt><dd>${iqd(app.amount)}</dd>
        <dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])} ${badge(['مؤكد', 'ok'])}</dd><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً منها <span class="num">${app.grace_months || 0}</span> سماح</dd>
        <dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(app.monthly_installment)}</dd><dt>الصرف</dt><dd>${DISB[q.disburse] || ''}</dd></dl></div>
      <div class="review pay ${pay ? 'done' : ''}"><h3>1. العمولة والرسوم ${pay ? '<span class="badge ok">مدفوعة</span>' : ''}</h3>
        <dl class="kv">${f.map(([l, v, cm]) => `<dt>${cm ? `<b class="cm">${esc(l)} (<span class="num">${q.commission_pct}%</span>)</b>` : esc(l)}</dt><dd>${iqd(v)}</dd>`).join('')}<dt><b>المجموع</b></dt><dd><b>${iqd(tot)}</b></dd></dl>
        ${pay ? `<p class="small muted" style="margin:6px 0 0">رقم العملية <b class="num">${esc(pay.ref)}</b> · ${esc(PAY_LABEL[pay.method] || pay.method)} · ${dt(pay.paid_at)}</p>` : `
        <div class="paygrid">${PAY_METHODS.map(([k, t, col]) => `<button type="button" data-m="${k}" class="${k === method ? 'on' : ''}"><i style="background:${col}">${esc(t.split(' ')[0])}</i>${esc(t)}</button>`).join('')}</div>`}</div>
      <div class="review"><h3>2. الإقرار والتوقيع الإلكتروني</h3>
        <label class="check"><input type="checkbox" data-ack> أقرّ بصحة بيانات نشاطي ومستنداتي، وأوافق على شروط البرنامج وعلى استقطاع القسط${app.grace_months ? ' بعد مدة السماح' : ''}.</label></div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok ${off ? 'disabled' : ''}>${pay ? 'التوقيع وإرسال الطلب' : `ادفع ${iqd(tot)} ووقّع وأرسل الطلب`}</button></div>`;
    wb.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { method = b.dataset.m; wb.querySelectorAll('[data-m]').forEach(z => z.classList.toggle('on', z === b)); });
    const doPay = async () => !!(await askOtp({ kind: 'pay', title: `تأكيد الدفع عبر ${PAY_LABEL[method]}`, phone: C().profile.phone, purpose: `دفع ${num(tot)} د.ع (عمولة ${bk.name} والرسوم)`,
      verify: async c2 => { const y = await rpc(C().sb, 'pay_application_fees', { p_app: app.id, p_bank: bk.id, p_method: method, p_otp: c2 }); paid = paid.filter(z => z.id !== y.id).concat(y); } }));
    wb.querySelector('[data-ok]').onclick = async () => {
      if (!wb.querySelector('[data-ack]')?.checked) return toast('ضع علامة ✓ على الإقرار أولاً', 'bad');
      if (!paid.find(z => z.bank_id === bk.id && z.status === 'paid')) { if (!(await doPay())) return; toast('تم الدفع — بقي التوقيع', 'ok'); paint(); wb.querySelector('[data-ack]').checked = true; }
      const code = await askOtp({ kind: 'sign', title: 'التوقيع الإلكتروني', phone: C().profile.phone, purpose: `توقيع طلب تمويل ${num(app.amount)} د.ع لدى ${bk.name}`,
        verify: c2 => rpc(C().sb, 'citizen_step', { p_app: app.id, p_step: 5, p_data: { otp: c2 } }) });
      if (!code) return;
      await A.load(); C().czStep = null;
      const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h2>أُرسل طلبك إلى ${esc(bk.name)}</h2>
        <p class="muted">رقم الطلب <b class="num">${esc(app.code)}</b> — الآن لدى <b>خدمة الزبائن في الفرع</b>. تتابع كل مرحلة من «طلبي».</p><a class="btn cyan" href="#home" data-x>متابعة طلبي</a></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      location.hash = '#home';
    };
  };
  paint();
}

// ───────── الجلسة 52: القرض الصناعي ─────────
// 2) المعمل والهوية الصناعية
function istep2(wb, app, x, done, edit) {
  const b = app.biz || {};
  if (done && !edit) {
    wb.innerHTML = `<div class="done-box"><span class="ok-ic">✓</span><div><b>🏭 ${esc(b.business_name || '')}</b><dl class="kv mt">
      <dt>الهوية الصناعية</dt><dd>${b.union_no ? `<b class="num">${esc(b.union_no)}</b>` : 'يُدرس انتماؤك للاتحاد مع القرض'}</dd><dt>الصنف</dt><dd>${esc(b.category_label || '')}</dd>
      <dt>المنتجات</dt><dd>${esc(b.products || '')}</dd><dt>إجازة التنمية الصناعية</dt><dd><span class="num">${esc(b.dev_license_no || '')}</span> · ${b.dev_license_kind === 'complete' ? 'كاملة التأسيس' : 'تحت التأسيس'}</dd>
      <dt>منذ</dt><dd><span class="num">${b.activity_months ?? ''}</span> شهراً</dd></dl></div></div>${doneRow}`;
    return nextBtn(wb, () => istep2(wb, app, x, done, true));
  }
  const f = (key, label, ph = '', attrs = '') => `<div class="field"><label>${label}</label><input class="input" data-k="${key}" value="${esc(b[key] ?? '')}" placeholder="${esc(ph)}" ${attrs}></div>`;
  const govs = x.params?.governorates || [];
  const st = { mode: b.union_mode || 'member', lf: b.legal_form || 'individual', dk: b.dev_license_kind || 'complete' };
  wb.innerHTML = `<h2>معملك والهوية الصناعية</h2><p class="muted">يتحقق اتحاد الصناعات العراقي من هويتك ويكشف على معملك قبل أن يصل طلبك للمصرف.</p>
    <div class="card soft mb"><h3>1. هل أنت عضو في اتحاد الصناعات العراقي؟</h3>
      <div class="seg mb" data-um><button type="button" data-v="member" class="${st.mode === 'member' ? 'on' : ''}">نعم، عندي هوية صناعية</button><button type="button" data-v="new" class="${st.mode === 'new' ? 'on' : ''}">لست عضواً بعد</button></div>
      <div data-umf></div></div>
    <div class="card soft mb"><h3>2. المعمل</h3><div class="grid g2" style="gap:12px">
      ${f('factory_name', 'اسم المعمل أو المصنع', 'مثال: معمل الرافدين للصناعات البلاستيكية')}
      <div class="field"><label>صنف الصناعة</label><select class="input" data-k="category"><option value="">اختر الصنف</option>${Object.entries(IND_CATS).map(([k, t]) => `<option value="${k}" ${b.category === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
      ${f('products', 'المنتجات', 'مثال: أنابيب بلاستيكية للري')}${f('capacity', 'الطاقة الإنتاجية (اختياري)', 'مثال: 600 طن سنوياً')}
      ${f('dev_license_no', 'رقم إجازة التأسيس — المديرية العامة للتنمية الصناعية', '', 'dir="ltr"')}
      <div class="field"><label>نوع الإجازة</label><div class="seg" style="margin:0" data-dk><button type="button" data-v="complete" class="${st.dk === 'complete' ? 'on' : ''}">كاملة التأسيس</button><button type="button" data-v="under" class="${st.dk === 'under' ? 'on' : ''}">تحت التأسيس</button></div></div>
      ${f('trade_name_no', 'رقم تسجيل الاسم التجاري لدى غرفة الصناعة', '', 'dir="ltr"')}
      <div class="field"><label>الصفة</label><div class="seg" style="margin:0" data-lfs><button type="button" data-v="individual" class="${st.lf !== 'company' ? 'on' : ''}">صناعي فرد</button><button type="button" data-v="company" class="${st.lf === 'company' ? 'on' : ''}">شركة</button></div></div>
      <div class="field"><label>محافظة المعمل</label><select class="input" data-k="governorate">${govs.length ? govs.map(g => `<option ${g === (b.governorate || app.governorate) ? 'selected' : ''}>${esc(g)}</option>`).join('') : govOptions(b.governorate || app.governorate || '')}</select></div>
      ${f('city', 'المدينة / المنطقة الصناعية')}<div class="field" style="grid-column:1/-1"><label>عنوان المعمل</label><input class="input" data-k="address" value="${esc(b.address || '')}" placeholder="الشارع، أقرب نقطة دالة — يصل منه مهندس الاتحاد"></div>
      ${f('start_year', 'سنة بدء التشغيل', '2020', 'inputmode="numeric" maxlength="4" dir="ltr"')}${f('start_month', 'شهر بدء التشغيل', '1–12', 'inputmode="numeric" maxlength="2" dir="ltr"')}
      ${f('workers', 'عدد العاملين', '', 'inputmode="numeric" dir="ltr"')}${f('monthly_sales', 'المبيعات الشهرية التقريبية (د.ع، اختياري)', '', 'inputmode="numeric" dir="ltr"')}
    </div>${x.params?.min_activity_months ? `<p class="small muted" style="margin:8px 0 0">يشترط البرنامج نشاطاً قائماً منذ <b class="num">${x.params.min_activity_months}</b> شهراً على الأقل.</p>` : ''}</div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>حفظ ومتابعة ←</button></div>`;
  const paintMode = () => {
    wb.querySelector('[data-umf]').innerHTML = st.mode === 'member'
      ? `<div class="field"><label>رقم الهوية الصناعية</label><input class="input num" dir="ltr" data-k="union_no" value="${esc(b.union_no || '')}" placeholder="IFI-2026-00001"></div><p class="small muted" style="margin:0">يُتحقق منها إلكترونياً من سجل الاتحاد. إن كانت منتهية جدّدها من صفحة <a href="/industry">بوابة الصناعيين</a>.</p>`
      : `<div class="notice info small">لا بأس — يُدرس انتماؤك للاتحاد مع طلب القرض بكشف واحد على معملك، وتُضاف أجور الانتماء (${'سنوية'}) إلى رسوم الطلب. تصلك الهوية الصناعية مع كتاب التأييد.</div>`;
  };
  paintMode();
  const seg = (sel, key) => wb.querySelectorAll(`[${sel}] button`).forEach(btn => btn.onclick = () => { st[key] = btn.dataset.v; wb.querySelectorAll(`[${sel}] button`).forEach(z => z.classList.toggle('on', z === btn)); if (key === 'mode') paintMode(); });
  seg('data-um', 'mode'); seg('data-dk', 'dk'); seg('data-lfs', 'lf');
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = { union_mode: st.mode, legal_form: st.lf, dev_license_kind: st.dk };
    wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    ['start_year', 'start_month', 'workers', 'monthly_sales'].forEach(z => { if (d[z] != null) d[z] = digits(d[z]); });
    if (st.mode === 'member' && !d.union_no) return toast('اكتب رقم هويتك الصناعية، أو اختر «لست عضواً بعد»', 'bad');
    if (!d.category) return toast('اختر صنف الصناعة', 'bad');
    e.target.disabled = true;
    try { await A.saveStep(app, 2, d, 'حُفظت بيانات المعمل'); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 5) قبل الدفع: كتاب تأييد الاتحاد
async function unionGate(wb, app, x) {
  wb.innerHTML = '<div class="card empty">جارٍ التحقق من تأييد اتحاد الصناعات…</div>';
  let R;
  try { R = await rpc(C().sb, 'union_app_report', { p_app: app.id }); } catch (e) { wb.innerHTML = `<div class="notice bad">${esc(cleanErr(e))}</div>`; return; }
  const U = await import('../union-ui.js');
  const f = [...(R.files || [])].reverse().find(z => z.kind === 'endorse' && z.status !== 'cancelled');
  if (R.letter_ok) {
    T.unFee = f && f.fee && !f.fee_paid_at ? ['أجور كشف وتأييد اتحاد الصناعات' + (app.biz?.new_member ? ' وبدل الانتماء' : ''), Number(f.fee)] : null;
    wb.dataset.un = '1';
    return tstep5(wb, app, x);
  }
  T.unFee = null;
  const st = f?.status || 'new';
  wb.innerHTML = `<h2>🏭 بانتظار تأييد اتحاد الصناعات العراقي</h2>
    <p class="muted">لا يُرسل القرض الصناعي للمصرف قبل أن يكشف مهندس الاتحاد على معملك ويصدر الأمين العام كتاب التأييد. يصلك إشعار فور صدوره، ثم تعود هنا للدفع والتوقيع.</p>
    <div class="card soft mb"><div class="row"><b class="num">${esc(f?.code || '—')}</b><span class="sp"></span>${U.ufBadge(st)}</div>
      ${f ? U.stepsBar(f) : ''}
      ${st === 'returned' ? `<div class="notice warn mt">أعاد الاتحاد طلبك للاستكمال. صحّح ما طُلب في خطوة «التمويل والمستندات» أو «معملك» ثم احفظها — تعود المعاملة للاتحاد آلياً.</div>` : ''}
      ${st === 'rejected' ? `<div class="notice bad mt"><b>لم يؤيد الاتحاد الطلب:</b> ${esc(f.reason || '')}<div class="small mt">يمكنك الاعتراض من صفحة <a href="/industry">بوابة الصناعيين</a> خلال ${30} يوماً.</div></div>` : ''}
      ${f?.engineer && st === 'inspection' ? `<p class="small mt">📍 المهندس <b>${esc(f.engineer)}</b> سيزور معملك — احرص أن يكون مفتوحاً.</p>` : ''}
      ${f?.late ? '<p class="small bad-t">تأخرت المعاملة عن المهلة — نُبّه الاتحاد.</p>' : ''}</div>
    ${!f ? '<div class="notice warn">لم تُفتح معاملة بعد — احفظ خطوة «التمويل والمستندات» مرة أخرى.</div>' : ''}
    <div class="row"><a class="btn ghost" href="/industry">بوابة الصناعيين</a><span class="sp"></span><button class="btn cyan" data-rf>تحديث</button></div>`;
  wb.querySelector('[data-rf]').onclick = () => unionGate(wb, app, x);
}
