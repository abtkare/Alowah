// بوابة التسجيل العقاري — إحالات الرهن فقط: الخلو، المطابقة، التأشير، الفك
import { esc, el, iqd, num, kpi, badge, REF_STATUS, PROP_STATUS, dt, ago, rpc, toast, cleanErr, closeDrawer, eventsList, tabs } from '../core.js';

const NEXT = {
  pending: [{ a: 'check', l: 'استعلام الخلو', k: 'cyan' }],
  clear: [{ a: 'match', l: 'مطابقة السند وهوية المالك', k: 'ok' }],
  matched: [{ a: 'annotate', l: 'تأشير الرهن على السند', k: 'ok' }],
  annotated: [{ a: 'release', l: 'فك الرهن (بعد براءة الذمة)', k: 'warn' }],
  encumbered: [{ a: 'reject', l: 'رفض الإحالة وإشعار المصرف', k: 'bad' }],
};

export async function render(ctx) {
  const { sb, root, orgs } = ctx;
  const [refs, props] = await Promise.all([
    sb.from('mortgage_referrals').select('*, properties(*), applications(code,citizen_name,bank_id)').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('properties').select('*').order('governorate').then(r => r.data || []),
  ]);
  const bank = id => orgs.find(o => o.id === id)?.name || '—';
  const open = refs.filter(r => ['pending', 'clear', 'matched', 'encumbered'].includes(r.status));

  root.innerHTML = `
    <div class="page-head"><div><h1>دائرة التسجيل العقاري</h1><p>ترى إحالات الرهن فقط — دون الراتب أو تفاصيل التمويل الأخرى.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('إحالات تنتظر إجراء', `<span class="num">${open.length}</span>`, 'من المصارف المشاركة', true)}
      ${kpi('رهون مؤشَّرة', `<span class="num">${refs.filter(r => r.status === 'annotated').length}</span>`)}
      ${kpi('رهون مفكوكة', `<span class="num">${refs.filter(r => r.status === 'released').length}</span>`)}
      ${kpi('عقارات في السجل', `<span class="num">${props.length}</span>`, `${props.filter(p => p.status !== 'free').length} عليها إشارة`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [{ key: 'refs', label: 'إحالات الرهن', count: open.length }, { key: 'lookup', label: 'استعلام عن عقار' }, { key: 'props', label: 'سجل العقارات' }];
  ctx.regTab = ctx.regTab || 'refs';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.regTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.regTab));

  function show(k) {
    if (k === 'refs') {
      body.innerHTML = refs.length ? `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr>
        <th>رقم الطلب</th><th>المصرف</th><th>رقم السند</th><th>المالك</th><th>الموقع</th><th>مبلغ الدين</th><th>الحالة</th><th>وردت</th></tr></thead><tbody>
        ${refs.map((r, i) => `<tr class="click" data-i="${i}"><td><b class="num">${esc(r.applications?.code)}</b></td><td>${esc(bank(r.bank_id))}</td>
          <td><b>${esc(r.properties?.deed_no)}</b></td><td>${esc(r.properties?.owner_name)}</td><td>${esc(r.properties?.governorate)} — ${esc(r.properties?.district)}</td>
          <td>${iqd(r.debt_amount)}</td><td>${badge(REF_STATUS[r.status])}</td><td class="muted small">${ago(r.created_at)}</td></tr>`).join('')}
        </tbody></table></div></div>` : '<div class="card empty">لا توجد إحالات رهن حالياً.</div>';
      body.querySelectorAll('tr[data-i]').forEach(tr => tr.onclick = () => openRef(refs[+tr.dataset.i]));
    }
    if (k === 'lookup') {
      body.innerHTML = `<div class="card" style="max-width:640px"><h3>استعلام الخلو برقم السند</h3>
        <div class="row"><input class="input" id="q" placeholder="مثال: 1452/87 الكرادة" style="flex:1"><button class="btn" id="go">استعلام</button></div><div id="res" class="mt"></div></div>`;
      const go = () => {
        const q = body.querySelector('#q').value.trim();
        const p = props.find(x => x.deed_no.includes(q) && q);
        body.querySelector('#res').innerHTML = p ? propCard(p) : `<p class="muted">${q ? 'لا يوجد عقار بهذا الرقم في السجل.' : ''}</p>`;
      };
      body.querySelector('#go').onclick = go; body.querySelector('#q').onkeydown = e => e.key === 'Enter' && go();
    }
    if (k === 'props') {
      body.innerHTML = `<div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم السند</th><th>المالك</th><th>المحافظة</th><th>المنطقة</th><th>الاستعمال</th><th>المساحة</th><th>الحالة</th></tr></thead><tbody>
        ${props.map(p => `<tr><td><b>${esc(p.deed_no)}</b></td><td>${esc(p.owner_name)}</td><td>${esc(p.governorate)}</td><td>${esc(p.district)} — ${esc(p.zone || '')}</td><td>${esc(p.use_type)}</td>
        <td><span class="num">${num(p.land_area)}</span> م²</td><td>${badge(PROP_STATUS[p.status])}</td></tr>`).join('')}</tbody></table></div></div>`;
    }
  }
  show(ctx.regTab);

  function propCard(p) {
    return `<dl class="kv"><dt>رقم السند</dt><dd>${esc(p.deed_no)}</dd><dt>المالك</dt><dd>${esc(p.owner_name)}</dd>
      <dt>الموقع</dt><dd>${esc(p.governorate)} — ${esc(p.district)} — ${esc(p.zone || '')}</dd><dt>الاستعمال</dt><dd>${esc(p.use_type)}</dd>
      <dt>مساحة الأرض / البناء</dt><dd><span class="num">${num(p.land_area)} / ${num(p.build_area)}</span> م²</dd>
      <dt>عدد الشركاء</dt><dd><span class="num">${p.shares}</span>${p.shares > 1 ? ' — يلزم موافقة كل الشركاء' : ''}</dd>
      <dt>الحالة</dt><dd>${badge(PROP_STATUS[p.status])}</dd></dl>`;
  }

  async function openRef(r) {
    closeDrawer();
    const events = (await sb.from('application_events').select('*').eq('application_id', r.application_id).order('id')).data || [];
    const regEvents = events.filter(e => /رهن|الخلو|مطابقة|تأشير|فك|الإحالة/.test(e.action));
    const bg = el('<div class="drawer-bg"></div>');
    const dr = el(`<aside class="drawer"><div class="dh"><div><div class="small" style="color:#8FA3C0">إحالة رهن</div><h2>${esc(r.properties?.deed_no)}</h2></div><span class="sp"></span>${badge(REF_STATUS[r.status])}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
      <div class="db">
        <div class="card mb"><h3>الإحالة</h3><dl class="kv"><dt>رقم الطلب</dt><dd class="num">${esc(r.applications?.code)}</dd><dt>المصرف المحيل</dt><dd>${esc(bank(r.bank_id))}</dd>
          <dt>المقترض</dt><dd>${esc(r.applications?.citizen_name)}</dd><dt>مبلغ الدين المطلوب تأشيره</dt><dd>${iqd(r.debt_amount)}</dd>
          ${r.annotation_no ? `<dt>رقم التأشير</dt><dd class="num">${esc(r.annotation_no)}</dd>` : ''}<dt>تاريخ الإحالة</dt><dd>${dt(r.created_at)}</dd></dl></div>
        <div class="card mb"><h3>العقار</h3>${propCard(r.properties || {})}
          ${r.properties?.owner_name !== r.applications?.citizen_name ? '<div class="notice warn mt">المالك غير المقترض: «كفيل عيني» — يلزم إقراره أمام الدائرة عند التأشير، ومسؤوليته في حدود العقار فقط.</div>' : ''}</div>
        <div class="card"><h3>إجراءات التسجيل العقاري على هذا الطلب</h3>${eventsList(regEvents)}</div>
      </div><div class="df"><div class="field" style="margin-bottom:10px"><textarea class="input" rows="2" placeholder="ملاحظة (تُحفظ في سجل التدقيق)"></textarea></div><div class="row"></div></div></aside>`);
    document.body.append(bg, dr);
    requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
    bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;
    const row = dr.querySelector('.df .row');
    const acts = NEXT[r.status] || [];
    if (!acts.length) dr.querySelector('.df').innerHTML = '<p class="muted small" style="margin:0">لا إجراء مطلوب على هذه الإحالة.</p>';
    acts.forEach(x => {
      const b = el(`<button class="btn ${x.k}">${x.l}</button>`);
      b.onclick = async () => {
        b.disabled = true;
        try {
          const res = await rpc(sb, 'registry_action', { p_ref: r.id, p_action: x.a, p_note: dr.querySelector('textarea').value.trim() || null });
          toast(x.a === 'check' ? (res.status === 'clear' ? 'العقار خالٍ من الإشارات' : 'العقار عليه إشارة — لا يصلح للرهن') : 'تم الإجراء وأُشعر المصرف', res.status === 'encumbered' ? 'bad' : 'ok');
          closeDrawer(); ctx.refresh();
        } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
      };
      row.appendChild(b);
    });
  }
}
