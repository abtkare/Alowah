// لوحة البنك المركزي — الحصص، التعاميم، السيولة، خريطة المنظومات
import { esc, iqd, mln, pct, num, kpi, appsTable, openApp, stageActions, dt, tabs } from '../core.js';

let leafletReady;
function loadLeaflet() {
  if (leafletReady) return leafletReady;
  leafletReady = new Promise((res, rej) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = rej; document.head.appendChild(s);
  });
  return leafletReady;
}

export async function render(ctx) {
  const { sb, root, orgs } = ctx;
  const [apps, allocs, circ, settings] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').then(r => r.data || []),
    sb.from('circulars').select('*').order('issued_on', { ascending: false }).then(r => r.data || []),
    sb.from('settings').select('*').then(r => r.data || []),
  ]);
  const done = apps.filter(a => a.status === 'completed');
  const live = apps.filter(a => ['active', 'returned'].includes(a.status));
  const inbox = live.filter(a => a.stage === 13);
  const mw = done.reduce((s, a) => s + Number(a.kw), 0) / 1000;
  const byGov = {};
  apps.forEach(a => { const g = byGov[a.governorate] ||= { n: 0, done: 0, kw: 0, amt: 0 }; g.n++; if (a.status === 'completed') { g.done++; g.kw += Number(a.kw); g.amt += a.amount; } });

  root.innerHTML = `
    <div class="page-head"><div><h1>البنك المركزي العراقي</h1><p>مبادرة تمويل منظومات الطاقة الشمسية — الإشراف الكامل دون تعديل الطلبات الفردية.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('القدرة المركّبة', mw >= 1 ? `<span class="num">${mw.toLocaleString('en-US', { maximumFractionDigits: 2 })}</span> MW` : `<span class="num">${num(mw * 1000)}</span> kW`, `${done.length} منظومة موثقة ومدققة`, true)}
      ${kpi('إجمالي التمويل المصروف', mln(done.reduce((s, a) => s + a.amount, 0)), 'دينار عراقي')}
      ${kpi('طلبات قيد المعالجة', `<span class="num">${live.length}</span>`, `${inbox.length} تنتظر إطلاق السيولة`)}
      ${kpi('المصارف المشاركة', `<span class="num">${allocs.length}</span>`, `مخصصات ${mln(allocs.reduce((s, a) => s + a.allocated, 0))}`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [{ key: 'map', label: 'الخريطة والمحافظات' }, { key: 'liq', label: 'إطلاق السيولة', count: inbox.length }, { key: 'quota', label: 'حصص المصارف' }, { key: 'circ', label: 'التعاميم والإعدادات' }, { key: 'all', label: 'كل الطلبات' }];
  ctx.cbiTab = ctx.cbiTab || 'map';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.cbiTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.cbiTab));
  const open = a => openApp(ctx, a, { actions: a.stage === 13 && a.status === 'active' ? stageActions(ctx, a).slice(0, 2) : [] });

  async function show(k) {
    if (k === 'map') {
      const rows = Object.entries(byGov).sort((a, b) => b[1].kw - a[1].kw);
      body.innerHTML = `<div class="grid g-side"><div class="card"><h3>خريطة المنظومات <span class="sp"></span><span class="legend" style="margin:0"><span><i style="background:#0E9F6E"></i>مركّبة</span><span><i style="background:#FFB000"></i>قيد التنفيذ</span></span></h3><div id="map"></div></div>
        <div class="card flush"><h3>حسب المحافظة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المحافظة</th><th>الطلبات</th><th>مركّبة</th><th>kW</th></tr></thead><tbody>
        ${rows.map(([g, v]) => `<tr><td>${esc(g)}</td><td class="num">${v.n}</td><td class="num">${v.done}</td><td class="num">${num(v.kw)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
      try {
        const L = await loadLeaflet();
        const m = L.map('map', { zoomControl: true }).setView([33.2, 43.7], 6);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 18 }).addTo(m);
        apps.filter(a => a.lat && a.status !== 'rejected').forEach(a => {
          const c = a.status === 'completed' ? '#0E9F6E' : '#FFB000';
          L.circleMarker([a.lat, a.lng], { radius: 5 + Number(a.kw) / 2, color: c, fillColor: c, fillOpacity: .55, weight: 2 })
            .bindPopup(`<div dir="rtl" style="font-family:Cairo"><b>${esc(a.code)}</b><br>${esc(a.governorate)} — ${num(a.kw)} kW<br>${a.status === 'completed' ? 'مركّبة ومدققة' : 'المرحلة ' + a.stage}</div>`).addTo(m);
        });
      } catch { body.querySelector('#map').innerHTML = '<div class="empty">تعذّر تحميل الخريطة</div>'; }
    }
    if (k === 'liq') body.innerHTML = `<div class="notice">طلبات أكملت التركيب والتشغيل الموثق وحصلت على تقرير تدقيق هندسي «مطابق». إطلاق السيولة يحوّل صافي التمويل للمصرف وعمولة المنصة لحساب الشركة المشغلة.</div>
      <div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'supplier', 'updated'] })}</div>`;
    if (k === 'quota') body.innerHTML = `<div class="grid g3">${allocs.map(a => {
      const b = orgs.find(o => o.id === a.bank_id); const u = (a.reserved + a.disbursed) / a.allocated * 100;
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      return `<div class="card"><h3>${esc(b?.name)} <span class="sp"></span>${u >= 90 ? '<span class="badge bad">أحمر</span>' : u >= 80 ? '<span class="badge warn">تنبيه</span>' : '<span class="badge ok">سليم</span>'}</h3>
        <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
        <dl class="kv mt"><dt>المخصص</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز</dt><dd>${iqd(a.reserved)}</dd><dt>المصروف</dt><dd>${iqd(a.disbursed)}</dd><dt>الاستخدام</dt><dd>${pct(u)}</dd></dl></div>`;
    }).join('')}</div>`;
    if (k === 'circ') body.innerHTML = `<div class="grid g2"><div class="card"><h3>سجل التعاميم</h3>${circ.map(c => `<div class="alert low"><div class="ic">ت</div><div><h4>${esc(c.title)}</h4><p>رقم <b class="num">${esc(c.number)}</b> · صدر ${dt(c.issued_on).split('،')[0]} · يسري من ${dt(c.effective_on).split('،')[0]}</p><p>${esc(c.summary)}</p></div></div>`).join('')}</div>
      <div class="card flush"><h3>القواعد المالية النافذة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القاعدة</th><th>القيمة</th><th>التعميم</th></tr></thead><tbody>
      ${settings.map(s => `<tr><td>${esc(s.label)}</td><td><b class="num">${num(s.value)}</b></td><td class="num muted">${esc(s.circular_no)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'stage', 'status'] })}</div>`;
  }
  show(ctx.cbiTab);
}
