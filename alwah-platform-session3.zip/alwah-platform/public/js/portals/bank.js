// بوابة المصرف — سبع وحدات تنفيذية + المخاطر، وفصل مهام كامل
import { ROLE_LABELS, esc, el, iqd, mln, pct, num, kpi, appsTable, openApp, stageActions, rpc, badge, REF_STATUS, tabs } from '../core.js';

const UNIT_HINT = {
  bank_cs: 'تستلم الملف وتطابق رقم «أور». لا تملك القرار.',
  bank_compliance: 'eKYC وقوائم الحظر والأشخاص المعرضون سياسياً وفتح الحساب. لا تعدّل البيانات.',
  bank_credit: 'الاستعلام الائتماني والقدرة على السداد والضمان والرهن، وتكتب التوصية. لا توافق فوق صلاحيتها.',
  bank_committee: 'موافقة أو رفض مسبب، وتحجز المبلغ من حصة المصرف. لا تصرف.',
  bank_legal: 'العقد أو المرابحة والكفالات والرهن. لا تغيّر شروط القرار.',
  bank_ops: 'القيد والصرف للمورد واستقطاع عمولة المورد. لا تقرر ولا تعدّل العقد.',
  bank_collection: 'الاستقطاع الشهري والمتأخرات ومطالبة الكفيل أو التأمين. لا إعفاء دون قرار.',
  bank_risk: 'ترى ولا تنفذ: مؤشرات التعثر واستخدام الحصة وعينات التدقيق.',
};

export async function render(ctx) {
  const { sb, profile, org, stages, root } = ctx;
  const [apps, alloc, refs, terms] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
    sb.from('mortgage_referrals').select('*').then(r => r.data || []),
    sb.from('bank_terms').select('*').eq('bank_id', org.id).maybeSingle().then(r => r.data),
  ]);
  const myStages = stages.filter(s => s.owner_role === profile.role).map(s => s.n);
  const inbox = apps.filter(a => myStages.includes(a.stage) && ['active', 'returned'].includes(a.status));
  const active = apps.filter(a => ['active', 'returned'].includes(a.status));
  const completed = apps.filter(a => a.status === 'completed');
  const used = alloc ? (alloc.reserved + alloc.disbursed) / alloc.allocated * 100 : 0;
  const avail = alloc ? alloc.allocated - alloc.reserved - alloc.disbursed : 0;

  root.innerHTML = `
    <div class="page-head"><div><h1>${esc(org.name)}${org.is_islamic ? ' <span class="badge ok">مصرف إسلامي — مسار المرابحة</span>' : ''}</h1>
      <p>وحدة: <b>${esc(ROLE_LABELS[profile.role])}</b> — ${esc(UNIT_HINT[profile.role] || '')}</p></div></div>
    <div class="grid g4 mb">
      ${kpi('في صندوق وحدتي', `<span class="num">${inbox.length}</span>`, 'طلبات تنتظر إجراءك', true)}
      ${kpi('طلبات قيد المعالجة', `<span class="num">${active.length}</span>`, 'في كل وحدات المصرف')}
      ${kpi('طلبات مكتملة', `<span class="num">${completed.length}</span>`, `صُرف لها ${mln(completed.reduce((s, a) => s + a.amount, 0))} دينار`)}
      ${kpi('المتاح من الحصة', mln(avail), `استخدام ${pct(used)} من المخصص`)}
    </div>
    ${used >= 80 ? `<div class="notice warn">⚠ استخدام الحصة بلغ ${pct(used)} — ${used >= 95 ? 'أُوقفت العروض الجديدة لحين التعزيز' : used >= 90 ? 'مؤشر أحمر لدى البنك المركزي' : 'يُنصح برفع طلب تعزيز إلى البنك المركزي'}.</div>` : ''}
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const isRisk = profile.role === 'bank_risk';
  const defs = [
    ...(isRisk ? [] : [{ key: 'inbox', label: 'صندوق وحدتي', count: inbox.length }]),
    { key: 'all', label: 'كل طلبات المصرف' },
    { key: 'quota', label: 'دفتر الحصة والتسعير' },
    ...(['bank_credit', 'bank_legal', 'bank_risk'].includes(profile.role) ? [{ key: 'mortgage', label: 'إحالات الرهن' }] : []),
  ];
  ctx.bankTab = defs.find(d => d.key === ctx.bankTab) ? ctx.bankTab : defs[0].key;
  tabs(root.querySelector('#tabs'), defs.map(d => ({ ...d })), k => { ctx.bankTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.bankTab));

  const open = a => {
    const mine = myStages.includes(a.stage) && ['active', 'returned'].includes(a.status);
    const ref = refs.filter(r => r.application_id === a.id).sort((x, y) => y.created_at.localeCompare(x.created_at))[0];
    let actions = mine ? stageActions(ctx, a) : [];
    if (mine && a.guarantee_type === 'mortgage' && !ref && ['bank_credit', 'bank_legal'].includes(profile.role)) {
      actions = [{ label: 'إحالة الرهن إلى التسجيل العقاري', kind: 'cyan', done: 'أُحيل الرهن إلى دائرة التسجيل العقاري', run: n => rpc(sb, 'refer_mortgage', { p_app: a.id, p_note: n }) }, ...actions];
    }
    const extra = a.guarantee_type === 'mortgage' ? `<div class="card mb"><h3>رهن العقار</h3>${ref
      ? `<div class="row">حالة الإحالة: ${badge(REF_STATUS[ref.status])}${ref.annotation_no ? `<span class="muted small">رقم التأشير: <b class="num">${esc(ref.annotation_no)}</b></span>` : ''}</div>`
      : '<p class="muted small" style="margin:0">لم يُحَل الرهن بعد. الإحالة من وحدة الائتمان، ولا يُنتقل للقرار قبل تأكيد الخلو.</p>'}</div>` : '';
    openApp(ctx, a, { actions, extra });
  };

  function show(k) {
    if (k === 'inbox') body.innerHTML = `<div class="card flush">${appsTable(inbox, ctx, { onOpen: open, cols: ['code', 'name', 'kw', 'amount', 'guarantee', 'stage', 'status', 'updated'] })}</div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'supplier', 'stage', 'status'] })}</div>`;
    if (k === 'mortgage') {
      const rows = apps.filter(a => a.guarantee_type === 'mortgage');
      body.innerHTML = `<div class="card flush">${appsTable(rows, ctx, { onOpen: open, cols: ['code', 'name', 'amount', 'stage', 'status'] })}</div>`;
    }
    if (k === 'quota') {
      const a = alloc || { allocated: 0, reserved: 0, disbursed: 0 };
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      body.innerHTML = `<div class="grid g2">
        <div class="card"><h3>دفتر حصة المصرف</h3>
          <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
          <div class="legend"><span><i style="background:var(--indigo)"></i>مصروف</span><span><i style="background:var(--sun)"></i>محجوز</span><span><i style="background:#E8EDF5"></i>متاح</span></div>
          <dl class="kv mt"><dt>المخصص من البنك المركزي</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز بقرارات ائتمانية</dt><dd>${iqd(a.reserved)}</dd>
          <dt>المصروف للموردين</dt><dd>${iqd(a.disbursed)}</dd><dt>المتاح</dt><dd>${iqd(avail)}</dd></dl>
          <p class="small muted mt">المتاح = المخصص − المحجوز − المصروف. الحجز لحظة القرار الائتماني لا لحظة الصرف. تنبيه عند 80% و90%، ووقف العروض الجديدة عند 95%.</p></div>
        <div class="card"><h3>شروط التمويل المعلنة</h3>
          <dl class="kv"><dt>الهامش السنوي</dt><dd>${pct(terms?.margin)} فوق ${pct(0.5)} للمركزي</dd><dt>رسم دراسة الملف</dt><dd>${iqd(terms?.file_fee)}</dd>
          <dt>أقصى مدة</dt><dd><span class="num">${num(terms?.max_term_months)}</span> شهراً</dd><dt>مدة المعالجة المعلنة</dt><dd><span class="num">${num(terms?.processing_days)}</span> أيام</dd>
          <dt>سقف الموافقة الأحادية</dt><dd>${iqd(terms?.single_approval_cap)}</dd></dl>
          <p class="small muted mt">كل قاعدة مربوطة بتعميم البنك المركزي النافذ، وأي تعديل يسري على الطلبات الجديدة فقط.</p></div></div>`;
    }
  }
  show(ctx.bankTab);
}
