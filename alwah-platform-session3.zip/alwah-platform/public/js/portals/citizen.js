// بوابة المواطن — طلبي، كتالوج المنظومات، تفاصيل المنظومة وتقييماتها، معالج طلب التمويل (المراحل 1–5)، الملف الشخصي
import {
  esc, num, iqd, dt, ago, badge, statusBadge, stageBar, stageList, eventsList, GUARANTEE, ADVANCE_LABEL, rpc, toast, cleanErr,
  GOVS, govOptions, installment, maskPhone, maskId, stars, modal, askOtp, serverOtp, normPhone, validPhone, digits, el
} from '../core.js';

const S = { ref: null };   // بيانات مرجعية تُحمَّل مرة واحدة
let C;                     // سياق البوابة

const route = () => { const [r, id] = location.hash.slice(1).split('/'); return { r: r || 'home', id }; };
// التحديث اللحظي يعيد رسم «طلبي» فقط، فلا تضيع مدخلات النماذج
export const shouldRefresh = () => route().r === 'home';

export async function render(ctx) {
  C = ctx;
  if (!ctx.czInit) { ctx.czInit = true; window.addEventListener('hashchange', () => { window.scrollTo(0, 0); go(); }); }
  await load();
  await go();
}

// ───────── البيانات ─────────
async function load(force) {
  const { sb } = C;
  if (!S.ref || force) {
    const [tiers, offers, terms, settings] = await Promise.all([
      sb.from('capacity_tiers').select('*').order('sort').then(r => r.data || []),
      sb.from('supplier_offers').select('*').eq('status', 'published').order('price').then(r => r.data || []),
      sb.from('bank_terms').select('*').then(r => r.data || []),
      sb.from('settings').select('*').then(r => r.data || []),
    ]);
    S.ref = { tiers, offers, terms, set: Object.fromEntries(settings.map(s => [s.key, Number(s.value)])) };
  }
  const [apps, reviews, me] = await Promise.all([
    sb.from('applications').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('offer_reviews').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
    sb.from('profiles').select('*').eq('id', C.profile.id).maybeSingle().then(r => r.data),
  ]);
  if (me) C.profile = me;
  S.apps = apps; S.reviews = reviews;
  const set = S.ref.set;
  const banks = C.orgs.filter(o => o.type === 'bank').map(b => ({ ...b, terms: S.ref.terms.find(t => t.bank_id === b.id), open: b.meta?.accepting !== false }));
  S.banks = banks;
  const bestRate = Math.min(...banks.filter(b => b.open && b.terms).map(b => b.terms.margin)) + set.cbi_rate;
  S.offers = S.ref.offers.map(o => {
    const tier = S.ref.tiers.find(t => t.id === o.tier_id), sup = C.orgs.find(x => x.id === o.supplier_id);
    const rs = reviews.filter(r => r.offer_id === o.id);
    const avg = k => rs.length ? rs.reduce((s, r) => s + (r[k] || 0), 0) / rs.length : 0;
    const dist = [5, 4, 3, 2, 1].map(n => rs.filter(r => r.rating === n).length);
    return { ...o, tier, kw: Number(tier?.kw), sup, rs, rating: avg('rating'), q: avg('quality'), ins: avg('install'), srv: avg('service'), dist,
      from: installment(o.price, bestRate, Math.min(84, set.term_max_months || 84)), panels: o.components?.find(c => c.item === 'ألواح')?.qty };
  });
  // شارات: الأقل سعراً والأعلى تقييماً في كل فئة
  S.ref.tiers.forEach(t => {
    const os = S.offers.filter(o => o.tier_id === t.id); if (!os.length) return;
    os.reduce((a, b) => a.price <= b.price ? a : b).cheap = true;
    os.reduce((a, b) => a.rating >= b.rating ? a : b).top = true;
  });
  S.active = apps.find(a => ['active', 'returned'].includes(a.status));
}
const offerById = id => S.offers.find(o => o.id === id);
const guaranteeFor = price => price <= S.ref.set.guarantee_t1 ? 'single_salary' : price <= S.ref.set.guarantee_t2 ? 'multi_salary' : 'mortgage';
const G_HINT = { single_salary: 'كفيل واحد موظف', multi_salary: 'كفيلان موظفان', mortgage: 'رهن عقار' };

// ───────── الهيكل والتنقل ─────────
async function go() {
  const { r, id } = route();
  const { root } = C;
  if (!root.querySelector('.cz-shell')) {
    root.innerHTML = `<div class="cz-shell"><nav class="cz-nav" aria-label="أقسام بوابة المواطن">
      <a href="#home" data-n="home"><i>☀</i><span>طلبي</span></a>
      <a href="#catalog" data-n="catalog"><i>▦</i><span>كتالوج المنظومات</span></a>
      <a href="#profile" data-n="profile"><i>☺</i><span>ملفي</span></a></nav><div id="cz"></div></div>`;
  }
  const navKey = { offer: 'catalog', apply: 'home' }[r] || r;
  root.querySelectorAll('.cz-nav a').forEach(a => a.classList.toggle('on', a.dataset.n === navKey));
  const body = root.querySelector('#cz');
  try {
    if (r === 'catalog') pageCatalog(body);
    else if (r === 'offer') pageOffer(body, id);
    else if (r === 'apply') pageApply(body);
    else if (r === 'profile') pageProfile(body);
    else await pageHome(body);
  } catch (e) { console.error(e); body.innerHTML = `<div class="card empty">${esc(cleanErr(e))}</div>`; }
}
const refreshAll = async () => { await load(); await go(); };

// ───────── الرئيسية: طلبي ─────────
async function pageHome(body) {
  const app = S.active || S.apps.find(a => a.status !== 'cancelled');
  const first = C.profile.full_name.split(' ')[0];
  if (!app || app.status === 'cancelled') return homeEmpty(body, first);
  if (['active', 'returned'].includes(app.status) && app.stage <= 5) return homeDraft(body, app, first);
  const { sb, stages } = C;
  const cur = stages.find(s => s.n === app.stage);
  const days = Math.max(0, Math.round((Date.now() - new Date(app.updated_at)) / 864e5));
  const events = (await sb.from('application_events').select('*').eq('application_id', app.id).order('id')).data || [];
  const o = offerById(app.offer_id), bank = C.orgs.find(x => x.id === app.bank_id);
  const lastNote = events.slice().reverse().find(e => e.note && ['إعادة للاستكمال', 'رفض مسبب'].includes(e.action));
  const canReview = (app.status === 'completed' || app.stage >= 12) && !S.reviews.some(r => r.application_id === app.id);
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>تابع طلب تمويل منظومتك، وكل جهة تمسكه، وكم مضى عليه.</p></div></div>
    ${app.status === 'returned' ? `<div class="notice warn"><b>أُعيد طلبك للاستكمال:</b> ${esc(lastNote?.note || 'راجع المصرف')}</div>` : ''}
    ${app.status === 'rejected' ? `<div class="notice" style="background:var(--bad-bg);color:var(--bad)"><b>رُفض الطلب:</b> ${esc(lastNote?.note || '')}</div>` : ''}
    ${canReview ? `<div class="card mb rate-cta"><div><h3>رُكّبت منظومتك — كيف كانت التجربة؟</h3><p class="muted small">تقييمك يظهر للمواطنين في الكتالوج ويساعدهم على الاختيار.</p></div><span class="sp"></span><button class="btn warn" data-rate>قيّم المنظومة</button></div>` : ''}
    <div class="card mb hero-track">
      <div class="row"><div><div class="small" style="color:#9FB4D6">رقم الطلب</div><h2 class="num" style="font-size:26px">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}</div>
      ${stageBar(app)}
      <div class="row mt"><div><div class="small" style="color:#9FB4D6">المرحلة الحالية</div><b style="font-size:18px">${app.stage}. ${esc(cur?.name)}</b></div><span class="sp"></span>
      <div><div class="small" style="color:#9FB4D6">الطلب الآن لدى</div><b style="color:var(--cyan)">${esc(app.status === 'completed' ? 'مكتمل' : cur?.owner_label)}</b></div>
      <div><div class="small" style="color:#9FB4D6">منذ</div><b><span class="num">${days}</span> يوم</b></div></div>
    </div>
    <div class="grid g3">
      <div class="card">${o ? `<img class="mini-img" src="${esc(o.image_url)}" alt="" loading="lazy">` : ''}<h3>منظومتي</h3><dl class="kv"><dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd><dt>المورد</dt><dd>${esc(C.orgs.find(x => x.id === app.supplier_id)?.name)}</dd>
        <dt>السعر</dt><dd>${iqd(app.price)}</dd><dt>المصرف</dt><dd>${esc(bank?.name || '—')}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])}</dd>
        <dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)}</dd><dt>المدة</dt><dd><span class="num">${app.term_months}</span> شهراً</dd></dl>
        ${o ? `<a class="btn ghost sm mt" href="#offer/${o.id}">تفاصيل المنظومة</a>` : ''}</div>
      <div class="card"><h3>المراحل الأربع عشرة</h3>${stageList(app, stages)}</div>
      <div class="card"><h3>كل ما حدث على طلبي</h3>${eventsList(events)}</div>
    </div>
    ${pastApps(app.id)}`;
  const rb = body.querySelector('[data-rate]'); if (rb) rb.onclick = () => rateDialog(app);
}

function homeEmpty(body, first) {
  const top = S.offers.slice().sort((a, b) => b.rating - a.rating).slice(0, 3);
  body.innerHTML = `
    <section class="cz-hero">
      <div><span class="pill">مبادرة تمويل الطاقة الشمسية</span><h1>أهلاً ${esc(first)} — موّل منظومتك الشمسية بقسط شهري</h1>
        <p>اختر القدرة التي تناسب منزلك، قارن عروض الموردين بالسعر والتقييم، واعرف قسطك وضمانك قبل أن تقدّم.</p>
        <div class="row"><a class="btn cyan" href="#catalog">تصفّح المنظومات</a><button class="btn btn-dark" data-help>ساعدني أختار القدرة</button></div></div>
      <ol class="how">${['تحقق من هويتك بالسيلفي', 'اربط رقم «أور»', 'اختر المنظومة', 'أضف الضمان والكفلاء', 'اختر المصرف ووقّع إلكترونياً'].map((s, i) => `<li><i>${i + 1}</i>${s}</li>`).join('')}</ol>
    </section>
    <div class="row" style="margin:6px 0 12px"><h2 style="font-size:19px">الأعلى تقييماً من المواطنين</h2><span class="sp"></span><a href="#catalog" class="small">كل المنظومات ←</a></div>
    <div class="offers">${top.map(offerCard).join('')}</div>
    ${pastApps()}`;
  body.querySelector('[data-help]').onclick = helpChoose;
  wireCards(body);
}

function homeDraft(body, app, first) {
  const o = offerById(app.offer_id);
  const steps = ['التحقق من الهوية', 'رقم «أور»', 'تثبيت العرض', 'الضمان والكفلاء', 'المصرف والتوقيع'];
  body.innerHTML = `
    <div class="page-head"><div><h1>أهلاً ${esc(first)}</h1><p>طلبك محفوظ — أكمل الخطوات المتبقية وأرسله للمصرف.</p></div></div>
    <div class="card mb draft">
      ${o ? `<img src="${esc(o.image_url)}" alt="" class="draft-img">` : ''}
      <div class="draft-b">
        <div class="row"><span class="badge info"><i class="dot"></i>مسودة</span><b class="num">${esc(app.code)}</b><span class="sp"></span><span class="small muted">بدأ ${ago(app.created_at)}</span></div>
        <h2 style="font-size:21px;margin:8px 0 2px">${esc(o?.title || '')}</h2>
        <div class="muted">${iqd(app.price)} · الضمان: ${esc(GUARANTEE[app.guarantee_type])}</div>
        <div class="prog"><i style="width:${(app.stage - 1) * 20}%"></i></div>
        <div class="small muted">أنجزت <b class="num">${app.stage - 1}</b> من 5 خطوات — التالية: <b style="color:var(--text)">${esc(steps[app.stage - 1])}</b></div>
        <div class="row mt"><a class="btn cyan" href="#apply">أكمل طلبك</a><button class="btn ghost" data-cancel>إلغاء الطلب</button></div>
      </div>
    </div>
    ${pastApps(app.id)}`;
  body.querySelector('[data-cancel]').onclick = () => cancelApp(app);
}

function pastApps(exceptId) {
  const list = S.apps.filter(a => a.id !== exceptId);
  if (!list.length) return '';
  return `<div class="card mt"><h3>طلباتي السابقة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المبلغ</th><th>الحالة</th><th>التاريخ</th></tr></thead><tbody>
    ${list.map(a => `<tr><td><b class="num">${esc(a.code)}</b></td><td><span class="num">${num(a.kw)}</span> kW</td><td>${iqd(a.amount)}</td><td>${statusBadge(a.status)}</td><td class="small muted">${dt(a.created_at)}</td></tr>`).join('')}</tbody></table></div></div>`;
}

async function cancelApp(app) {
  const m = modal(`<h3>إلغاء الطلب ${esc(app.code)}</h3><p class="muted">يمكنك تقديم طلب جديد بعد الإلغاء. هذا الإجراء يُسجَّل في سجل التدقيق.</p>
    <div class="field"><label>سبب الإلغاء (اختياري)</label><select class="input" data-r><option>أريد اختيار منظومة أخرى</option><option>غيّرت رأيي</option><option>لا أملك ضماناً مناسباً</option><option>سبب آخر</option></select></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-no>تراجع</button><button class="btn bad" data-yes>إلغاء الطلب</button></div>`);
  m.el.querySelector('[data-no]').onclick = m.close;
  m.el.querySelector('[data-yes]').onclick = async () => {
    try { await rpc(C.sb, 'cancel_my_application', { p_app: app.id, p_reason: m.el.querySelector('[data-r]').value }); m.close(); toast('أُلغي الطلب', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الكتالوج ─────────
function offerCard(o) {
  const g = guaranteeFor(o.price);
  return `<article class="ocard" data-id="${o.id}">
    <div class="media" data-play="${o.id}" role="button" tabindex="0" aria-label="تشغيل فيديو شرح المنظومة">
      <img src="${esc(o.image_url)}" alt="منظومة ${num(o.kw)} kW من ${esc(o.sup?.name)}" loading="lazy">
      <span class="play"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></span>
      <span class="dur">فيديو 0:40</span>
      <div class="flags">${o.cheap ? '<span class="badge ok">الأقل سعراً</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
    </div>
    <div class="ob">
      <div class="row" style="gap:6px"><span class="kw num">${num(o.kw)} kW</span><span class="muted small">${esc(o.sup?.name)}</span></div>
      <div class="row" style="gap:6px">${stars(o.rating)}<b class="num small">${o.rating.toFixed(1)}</b><span class="muted small">(<span class="num">${o.rs.length}</span> تقييم)</span></div>
      <div class="price">${iqd(o.price)}</div>
      <div class="small muted">قسط يبدأ من <b style="color:var(--text)">${iqd(o.from)}</b> شهرياً</div>
      <div class="chips"><span><b class="num">${num(o.panels)}</b> لوح</span><span>بطاريات <b class="num">${num(o.battery_kwh)}</b> kWh</span><span>~<b class="num">${num(o.tier?.daily_kwh)}</b> kWh/يوم</span></div>
      <div class="small">الضمان المطلوب: <b>${G_HINT[g]}</b></div>
      <div class="row mt" style="gap:8px"><a class="btn ghost sm" href="#offer/${o.id}">التفاصيل والتقييمات</a><span class="sp"></span><button class="btn cyan sm" data-apply="${o.id}">اطلب التمويل</button></div>
    </div></article>`;
}
function wireCards(root) {
  root.querySelectorAll('[data-play]').forEach(m => { m.onclick = () => playVideo(offerById(m.dataset.play)); m.onkeydown = e => { if (e.key === 'Enter') m.click(); }; });
  root.querySelectorAll('[data-apply]').forEach(b => b.onclick = () => startFlow(offerById(b.dataset.apply)));
}
function playVideo(o) {
  const m = modal(`<div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls autoplay playsinline preload="metadata"></video></div>
    <div class="row mt"><div><b>${esc(o.title)}</b><div class="small muted">فيديو شرح المنظومة · أقل من دقيقة</div></div><span class="sp"></span><a class="btn ghost sm" href="#offer/${o.id}" data-x>التفاصيل</a><button class="btn cyan sm" data-a>اطلب التمويل</button></div>`, { wide: true });
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-a]').onclick = () => { m.close(); startFlow(o); };
}

function pageCatalog(body) {
  C.czCat = C.czCat || { kw: 'all', sort: 'price' };
  const st = C.czCat;
  body.innerHTML = `
    <div class="page-head"><div><h1>كتالوج المنظومات</h1><p>كل عرض بصورته وفيديو شرح قصير وتقييمات المواطنين الذين ركّبوه فعلاً.</p></div><span class="sp"></span><button class="btn ghost" data-help>ساعدني أختار القدرة</button></div>
    <div class="filters">
      <div class="seg sm">${[['all', 'الكل'], ...S.ref.tiers.map(t => [String(Number(t.kw)), `${num(t.kw)} kW`])].map(([k, l]) => `<button class="${st.kw === k ? 'on' : ''}" data-kw="${k}">${l}</button>`).join('')}</div>
      <span class="sp"></span>
      <label class="small muted" for="srt">الترتيب</label>
      <select class="input sm" id="srt"><option value="price">الأقل سعراً</option><option value="rating">الأعلى تقييماً</option><option value="speed">الأسرع تركيباً</option><option value="reviews">الأكثر تقييماً</option></select>
    </div>
    <div data-tier></div>
    <div class="offers" data-list></div>
    <p class="small muted mt">الأسعار تشمل النقل والتركيب والهيكل. القسط التقديري بأقل هامش متاح ولأطول مدة؛ القسط النهائي يحدده المصرف الذي تختاره. التقييمات في نسخة العرض تجريبية.</p>`;
  const sel = body.querySelector('#srt'); sel.value = st.sort;
  sel.onchange = () => { st.sort = sel.value; paint(); };
  body.querySelectorAll('[data-kw]').forEach(b => b.onclick = () => { st.kw = b.dataset.kw; body.querySelectorAll('[data-kw]').forEach(x => x.classList.toggle('on', x === b)); paint(); });
  body.querySelector('[data-help]').onclick = helpChoose;
  paint();
  function paint() {
    let list = S.offers.filter(o => st.kw === 'all' || String(o.kw) === st.kw);
    const key = { price: (a, b) => a.price - b.price, rating: (a, b) => b.rating - a.rating, speed: (a, b) => (a.sup?.meta?.avg_days || 99) - (b.sup?.meta?.avg_days || 99), reviews: (a, b) => b.rs.length - a.rs.length }[st.sort];
    list.sort((a, b) => key(a, b) || a.kw - b.kw);
    const t = st.kw !== 'all' && S.ref.tiers.find(x => String(Number(x.kw)) === st.kw);
    body.querySelector('[data-tier]').innerHTML = t ? `<div class="notice dark tier-note"><b class="num">${num(t.kw)} kW</b> — إنتاج يومي ~<b class="num">${num(t.daily_kwh)}</b> kWh · تشغّل: ${esc(t.loads)} · سقف السعر ${iqd(t.price_cap)} · الضمان: <b>${G_HINT[guaranteeFor(t.price_cap)]}</b> أو حسب السعر</div>` : '';
    const L = body.querySelector('[data-list]'); L.innerHTML = list.map(offerCard).join('') || '<div class="card empty">لا عروض</div>';
    wireCards(L);
  }
}

function helpChoose() {
  const items = [['ac', 'مكيف 1.5 طن', 9.6, 0], ['cooler', 'مبردة هواء', 2.5, 1], ['fridge', 'ثلاجة', 1.6, 1], ['freezer', 'مجمدة', 1.4, 0], ['washer', 'غسالة', 0.8, 1], ['pump', 'مضخة ماء', 1.5, 0]];
  const m = modal(`<h3>ما الأجهزة التي تريد تشغيلها؟</h3><p class="muted small">نحسب الاستهلاك اليومي ونقترح أصغر قدرة تكفيه (الإنارة والتلفاز والشحن محسوبة دائماً).</p>
    <div class="counters">${items.map(([k, l, , d]) => `<div class="ctr"><span>${l}</span><span class="sp"></span><button type="button" data-d="${k}">−</button><b class="num" data-v="${k}">${d}</b><button type="button" data-i="${k}">+</button></div>`).join('')}</div>
    <div class="card mt" style="background:var(--surface-2);box-shadow:none" data-res></div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-go>اعرض المنظومات المناسبة</button></div>`);
  const v = Object.fromEntries(items.map(i => [i[0], i[3]]));
  let pick;
  const calc = () => {
    const need = 2.5 + items.reduce((s, [k, , kwh]) => s + v[k] * kwh, 0);
    pick = S.ref.tiers.find(t => Number(t.daily_kwh) >= need * 1.1) || S.ref.tiers[S.ref.tiers.length - 1];
    m.el.querySelector('[data-res]').innerHTML = `استهلاكك اليومي التقديري <b class="num">${need.toFixed(1)}</b> kWh — القدرة المقترحة: <b class="num" style="color:var(--indigo);font-size:20px">${num(pick.kw)} kW</b> (إنتاج ~<span class="num">${num(pick.daily_kwh)}</span> kWh)`;
  };
  m.el.querySelectorAll('[data-i],[data-d]').forEach(b => b.onclick = () => { const k = b.dataset.i || b.dataset.d; v[k] = Math.max(0, Math.min(6, v[k] + (b.dataset.i ? 1 : -1))); m.el.querySelector(`[data-v="${k}"]`).textContent = v[k]; calc(); });
  calc();
  m.el.querySelector('[data-go]').onclick = () => { C.czCat = { ...(C.czCat || { sort: 'price' }), kw: String(Number(pick.kw)) }; m.close(); if (route().r === 'catalog') go(); else location.hash = '#catalog'; };
}

// ───────── تفاصيل المنظومة ─────────
function pageOffer(body, id) {
  const o = offerById(id);
  if (!o) { body.innerHTML = '<div class="card empty">العرض غير موجود. <a href="#catalog">العودة للكتالوج</a></div>'; return; }
  const set = S.ref.set, g = guaranteeFor(o.price), meta = o.sup?.meta || {};
  const siblings = S.offers.filter(x => x.tier_id === o.tier_id).sort((a, b) => a.price - b.price);
  body.innerHTML = `
    <a href="#catalog" class="back">→ العودة للكتالوج</a>
    <div class="od">
      <div class="od-media card flush">
        <div class="vid"><video src="${esc(o.video_url)}" poster="${esc(o.image_url)}" controls playsinline preload="none"></video></div>
        <div class="od-thumbs"><span>فيديو شرح المنظومة · <span class="num">0:40</span></span><span class="sp"></span><a href="${esc(o.image_url)}" target="_blank" rel="noopener" class="small">فتح الصورة</a></div>
      </div>
      <div class="od-sum card">
        <div class="row"><span class="kw num">${num(o.kw)} kW</span>${o.cheap ? '<span class="badge ok">الأقل سعراً في فئته</span>' : ''}${o.top ? '<span class="badge warn">الأعلى تقييماً</span>' : ''}</div>
        <h1 style="font-size:24px;margin:8px 0 2px">منظومة هجينة <span class="num">${num(o.kw)} kW</span></h1>
        <div class="muted">${esc(o.sup?.name)}</div>
        <a href="#rv" class="row" style="gap:6px;margin-top:6px;color:inherit">${stars(o.rating, 18)}<b class="num">${o.rating.toFixed(1)}</b><span class="muted small">من <span class="num">${o.rs.length}</span> مواطن ركّبها</span></a>
        <div class="price big">${iqd(o.price)}</div>
        <div class="small muted">يشمل النقل والتركيب والهيكل المجلفن · سقف الفئة ${iqd(o.tier?.price_cap)}</div>
        <dl class="kv mt"><dt>الإنتاج اليومي</dt><dd>~<span class="num">${num(o.tier?.daily_kwh)}</span> kWh</dd><dt>تشغّل</dt><dd>${esc(o.tier?.loads)}</dd>
          <dt>البطاريات</dt><dd><span class="num">${num(o.battery_kwh)}</span> kWh</dd><dt>الضمان المطلوب</dt><dd>${G_HINT[g]}</dd></dl>
        <div class="row mt"><button class="btn cyan" data-apply="${o.id}" style="flex:1">اطلب تمويل هذه المنظومة</button></div>
      </div>
    </div>
    <div class="grid g-side mt">
      <div>
        <div class="card mb"><h3>المكونات</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المكوّن</th><th>العلامة</th><th>الطراز</th><th>العدد</th></tr></thead><tbody>
          ${(o.components || []).map(c => `<tr><td>${esc(c.item)}</td><td><span class="num">${esc(c.brand)}</span></td><td><span class="num">${esc(c.model)}</span></td><td class="num">${num(c.qty)}</td></tr>`).join('')}</tbody></table></div>
          <p class="small muted" style="margin:10px 0 0">${esc(o.description || '')}</p></div>
        <div class="card mb"><h3>الضمان والصيانة</h3><ul class="ticks">${(o.warranty || '').split('،').map(w => `<li>${esc(w.trim())}</li>`).join('')}</ul></div>
        <div class="card mb" id="calc"></div>
        <div class="card" id="rv"></div>
      </div>
      <div>
        <div class="card mb"><h3>عن المورد</h3><b>${esc(o.sup?.name)}</b>
          <div class="grid g2 mt" style="gap:10px">
            <div class="stat"><b class="num">${num(meta.installs)}</b><span>منظومة مركّبة</span></div>
            <div class="stat"><b class="num">${num(meta.avg_days)}</b><span>يوماً متوسط التركيب</span></div>
            <div class="stat"><b class="num">${num(meta.match_rate)}%</b><span>مطابقة التدقيق الهندسي</span></div>
            <div class="stat"><b>${meta.legacy ? 'مسجّل' : 'جديد'}</b><span>${meta.legacy ? 'منذ المرحلة الأولى' : 'في المبادرة'}</span></div>
          </div></div>
        <div class="card"><h3>عروض أخرى بنفس القدرة</h3>
          ${siblings.map(s => `<a class="sib ${s.id === o.id ? 'on' : ''}" href="#offer/${s.id}"><img src="${esc(s.image_url)}" alt=""><div><b>${esc(s.sup?.name)}</b><div class="small">${stars(s.rating, 12)} <span class="num">${s.rating.toFixed(1)}</span></div></div><span class="sp"></span><b class="small">${iqd(s.price)}</b></a>`).join('')}
        </div>
      </div>
    </div>`;
  body.querySelector('[data-apply]').onclick = () => startFlow(o);
  // حاسبة القسط
  const calc = body.querySelector('#calc'); let term = 60;
  const drawCalc = () => {
    calc.innerHTML = `<h3>احسب قسطك<span class="sp"></span><span class="small muted">مدة السداد <b class="num">${term}</b> شهراً</span></h3>
      <input type="range" min="12" max="${set.term_max_months || 84}" step="6" value="${term}" class="range" aria-label="مدة السداد">
      <div class="banks">${S.banks.map(b => { if (!b.terms) return ''; const rate = set.cbi_rate + Number(b.terms.margin); const ins = installment(o.price, rate, Math.min(term, b.terms.max_term_months));
        return `<div class="bk ${b.open ? '' : 'off'}"><i style="background:${esc(b.meta?.color || '#4356A3')}"></i><div><b>${esc(b.name)}</b><div class="small muted">${b.is_islamic ? 'مرابحة' : 'تجاري'} · <span class="num">${rate.toFixed(2)}%</span> سنوياً</div></div><span class="sp"></span><div style="text-align:left">${b.open ? `<b>${iqd(ins)}</b><div class="small muted">شهرياً</div>` : '<span class="small muted">لا يستقبل طلبات حالياً</span>'}</div></div>`; }).join('')}</div>
      <p class="small muted" style="margin:8px 0 0">النسبة = فائدة البنك المركزي <span class="num">${set.cbi_rate}%</span> + هامش المصرف (بحد أعلى <span class="num">${set.margin_max}%</span>) حسب التعميم النافذ.</p>`;
    calc.querySelector('.range').oninput = e => { term = Number(e.target.value); drawCalc(); calc.querySelector('.range').focus(); };
  };
  drawCalc();
  drawReviews(body.querySelector('#rv'), o);
}

function drawReviews(box, o, filter = 0, all = false) {
  const n = o.rs.length, list = o.rs.filter(r => !filter || r.rating === filter), shown = all ? list : list.slice(0, 5);
  box.innerHTML = `<h3>تقييمات المواطنين<span class="sp"></span><span class="badge muted">من ركّبوا المنظومة فقط</span></h3>
    <div class="rv-top">
      <div class="rv-avg"><b class="num">${o.rating.toFixed(1)}</b>${stars(o.rating, 18)}<span class="small muted"><span class="num">${n}</span> تقييم</span></div>
      <div class="rv-dist">${[5, 4, 3, 2, 1].map((s, i) => `<button class="rv-row ${filter === s ? 'on' : ''}" data-f="${s}"><span class="num">${s}</span>★<span class="bar"><i style="width:${n ? o.dist[i] / n * 100 : 0}%"></i></span><span class="num small muted">${o.dist[i]}</span></button>`).join('')}</div>
      <div class="rv-sub">${[['جودة المنظومة', o.q], ['التركيب', o.ins], ['خدمة المورد', o.srv]].map(([l, v]) => `<div><span class="small">${l}</span><span class="bar"><i style="width:${v / 5 * 100}%"></i></span><b class="num small">${v.toFixed(1)}</b></div>`).join('')}</div>
    </div>
    ${filter ? `<div class="small mb">تعرض تقييمات <b class="num">${filter}</b> نجوم فقط — <button class="linkbtn" data-f="0">عرض الكل</button></div>` : ''}
    <ul class="rv-list">${shown.map(r => `<li><div class="row" style="gap:8px"><span class="av sm">${esc(r.author_name.trim()[0])}</span><div><b>${esc(shortName(r.author_name))}</b><div class="small muted">${esc(r.governorate || '')} · ${ago(r.created_at)}</div></div><span class="sp"></span>${stars(r.rating, 14)}</div>
      ${r.comment ? `<p>${esc(r.comment)}</p>` : ''}${r.verified ? '<span class="badge ok sm">تركيب موثّق عبر المنصة</span>' : ''}</li>`).join('') || '<li class="muted">لا تقييمات بهذا العدد من النجوم.</li>'}</ul>
    ${!all && list.length > 5 ? `<button class="btn ghost block" data-all>عرض كل التقييمات (<span class="num">${list.length}</span>)</button>` : ''}`;
  box.querySelectorAll('[data-f]').forEach(b => b.onclick = () => drawReviews(box, o, Number(b.dataset.f) === filter ? 0 : Number(b.dataset.f)));
  const a = box.querySelector('[data-all]'); if (a) a.onclick = () => drawReviews(box, o, filter, true);
}
const shortName = n => { const p = n.trim().split(/\s+/); return p.length > 1 ? `${p[0]} ${p[1][0]}.` : p[0]; };

// ───────── بدء الطلب ─────────
async function startFlow(o) {
  if (S.active) {
    if (S.active.stage <= 5) {
      const m = modal(`<h3>لديك طلب لم يكتمل</h3><p class="muted">طلبك <b class="num">${esc(S.active.code)}</b> محفوظ. يمكنك تغيير المنظومة من خطوة «تثبيت العرض» داخل الطلب نفسه.</p>
        <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إغلاق</button><button class="btn cyan" data-go>متابعة طلبي</button></div>`);
      m.el.querySelector('[data-x]').onclick = m.close; m.el.querySelector('[data-go]').onclick = () => { m.close(); location.hash = '#apply'; };
    } else toast('لديك طلب قائم لدى المصرف — تابعه من «طلبي»', 'bad');
    return;
  }
  const p = C.profile, g = guaranteeFor(o.price);
  const m = modal(`<h3>بدء طلب تمويل</h3>
    <div class="pick"><img src="${esc(o.image_url)}" alt=""><div><b>${esc(o.title)}</b><div>${iqd(o.price)}</div><div class="small muted">الضمان المطلوب: ${G_HINT[g]}</div></div></div>
    <div class="grid g2 mt" style="gap:12px">
      <div class="field"><label>محافظة موقع التركيب</label><select class="input" data-gv>${govOptions(p.governorate || '')}</select></div>
      <div class="field"><label>المدينة / الحي</label><input class="input" data-ct value="${esc(p.city || '')}" placeholder="مثال: الكرادة"></div>
    </div>
    <p class="small muted">ستمر بخمس خطوات قصيرة: الهوية، «أور»، العرض، الضمان، ثم المصرف والتوقيع. يُحفظ تقدمك تلقائياً.</p>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn cyan" data-go>ابدأ الطلب</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-go]').onclick = async e => {
    const gov = m.el.querySelector('[data-gv]').value; if (!gov) return toast('اختر المحافظة', 'bad');
    const c = GOVS.find(x => x[0] === gov), j = () => (Math.random() - .5) * .3;
    e.target.disabled = true;
    try {
      await rpc(C.sb, 'start_application', { p_offer: o.id, p_governorate: gov, p_city: m.el.querySelector('[data-ct]').value.trim() || null, p_lat: c ? +(c[1] + j()).toFixed(4) : null, p_lng: c ? +(c[2] + j()).toFixed(4) : null });
      m.close(); await load(); C.czStep = null; location.hash = '#apply'; if (route().r === 'apply') go();
      toast('بدأ طلبك — الخطوة الأولى: التحقق من الهوية', 'ok');
    } catch (err) { toast(cleanErr(err), 'bad'); e.target.disabled = false; }
  };
}

// ───────── معالج الطلب: المراحل 1–5 ─────────
const STEPS = [['الهوية', 'التحقق بالسيلفي'], ['«أور»', 'ربط الرقم'], ['العرض', 'تثبيت المنظومة'], ['الضمان', 'الكفلاء أو العقار'], ['المصرف', 'الاختيار والتوقيع']];
function pageApply(body) {
  const app = S.active;
  if (!app || app.stage > 5) { location.hash = app ? '#home' : '#catalog'; return; }
  const step = Math.min(C.czStep || app.stage, app.stage);
  body.innerHTML = `
    <div class="page-head"><div><h1>طلب تمويل <span class="num">${esc(app.code)}</span></h1><p>${esc(offerById(app.offer_id)?.title || '')} · ${iqd(app.amount)}</p></div><span class="sp"></span><a href="#home" class="btn ghost sm">حفظ والعودة لاحقاً</a></div>
    <ol class="wiz">${STEPS.map(([t, s], i) => { const n = i + 1, done = n < app.stage, cur = n === step;
      return `<li class="${done ? 'done' : ''} ${cur ? 'cur' : ''} ${n <= app.stage ? 'go' : ''}" data-s="${n}"><i>${done ? '✓' : n}</i><div><b>${t}</b><small>${s}</small></div></li>`; }).join('')}</ol>
    <div class="card wiz-body" id="wb"></div>`;
  body.querySelectorAll('.wiz li.go').forEach(li => li.onclick = () => { C.czStep = Number(li.dataset.s); pageApply(body); });
  const wb = body.querySelector('#wb');
  const done = step < app.stage;
  [step1, step2, step3, step4, step5][step - 1](wb, app, done);
}
async function saveStep(app, n, data, msg) {
  await rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: n, p_data: data });
  await load();
  C.czStep = null;
  toast(msg || 'تم الحفظ', 'ok');
  if (S.active?.stage > 5) { location.hash = '#home'; return; }
  pageApply(C.root.querySelector('#cz'));
}
const doneBox = (title, rows, onEdit) => {
  const d = el(`<div><div class="done-box"><span class="ok-ic">✓</span><div><b>${title}</b><dl class="kv mt">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl></div></div>
    <div class="row mt"><button class="btn ghost" data-edit>تعديل هذه الخطوة</button><span class="sp"></span><button class="btn cyan" data-next>الخطوة التالية ←</button></div></div>`);
  d.querySelector('[data-edit]').onclick = onEdit;
  d.querySelector('[data-next]').onclick = () => { C.czStep = null; pageApply(C.root.querySelector('#cz')); };
  return d;
};

// 1) التحقق من الهوية بالسيلفي (eKYC — محاكاة المطابقة)
function step1(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('تم التحقق من هويتك', [['رقم البطاقة', `<span class="num">${maskId(app.kyc?.national_id || C.profile.national_id)}</span>`], ['مطابقة الوجه', `<span class="num">${app.kyc?.match_score ?? '—'}%</span>`], ['فحص الحيوية', badge(['ناجح', 'ok'])]], () => step1(wb, app, done, true))); return; }
  const k = { live: false, score: 0 };
  wb.innerHTML = `<h2>التحقق من الهوية</h2><p class="muted">نطابق وجهك مع صورة بطاقتك الوطنية الموحدة ونتأكد أنك حاضر فعلاً (فحص الحيوية).</p>
    <div class="grid g2">
      <div>
        <div class="field"><label>رقم البطاقة الوطنية</label><input class="input" data-nid inputmode="numeric" maxlength="12" dir="ltr" value="${esc(C.profile.national_id || '')}" ${C.profile.national_id ? 'readonly' : ''}></div>
        <div class="grid g2" style="gap:10px">
          ${['الوجه الأمامي', 'الوجه الخلفي'].map((l, i) => `<label class="upl"><input type="file" accept="image/*" capture="environment" data-card="${i}" hidden><span class="ph" data-prev="${i}"><b>＋</b>${l}<small>صورة البطاقة</small></span></label>`).join('')}
        </div>
        <p class="small muted">في نسخة العرض صورة البطاقة اختيارية، والصور لا تُرفع إلى الخادم.</p>
      </div>
      <div class="selfie">
        <div class="cam"><video playsinline muted autoplay></video><canvas hidden></canvas><img hidden alt="الصورة الملتقطة"><div class="oval"></div><div class="hint">اضغط «بدء الفحص» وضع وجهك داخل الإطار</div></div>
        <div class="row mt"><button class="btn" data-cam>بدء الفحص بالكاميرا</button><button class="btn ghost" data-sim>محاكاة بدون كاميرا</button></div>
        <div class="kyc-res" hidden></div>
      </div>
    </div>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok disabled>${ADVANCE_LABEL[1]}</button></div>`;
  wb.querySelectorAll('[data-card]').forEach(inp => inp.onchange = () => {
    const f = inp.files[0]; if (!f) return; const u = URL.createObjectURL(f);
    wb.querySelector(`[data-prev="${inp.dataset.card}"]`).innerHTML = `<img src="${u}" alt=""><small>✓ تم إرفاق الصورة</small>`;
  });
  const v = wb.querySelector('video'), cv = wb.querySelector('canvas'), im = wb.querySelector('.cam img'), hint = wb.querySelector('.hint'), res = wb.querySelector('.kyc-res'), ok = wb.querySelector('[data-ok]');
  let stream;
  const stop = () => { stream?.getTracks().forEach(t => t.stop()); stream = null; };
  const sequence = async (withCam) => {
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => b.disabled = true);
    const cam = wb.querySelector('.cam'); cam.classList.add('scan');
    for (const h of ['انظر إلى الكاميرا مباشرة', 'ارمش بعينيك مرتين', 'أدر رأسك قليلاً إلى اليمين', 'ثبّت وجهك… جارِ الالتقاط']) { hint.textContent = h; await new Promise(r => setTimeout(r, 1100)); }
    if (withCam && v.videoWidth) { cv.width = v.videoWidth; cv.height = v.videoHeight; cv.getContext('2d').drawImage(v, 0, 0); im.src = cv.toDataURL('image/jpeg', .7); im.hidden = false; v.hidden = true; }
    stop(); cam.classList.remove('scan'); cam.classList.add('ok');
    hint.textContent = 'تم الالتقاط — جارِ المطابقة مع صورة البطاقة…';
    await new Promise(r => setTimeout(r, 1200));
    k.live = true; k.score = Math.round((92 + Math.random() * 7) * 10) / 10;
    hint.textContent = 'اكتمل الفحص';
    res.hidden = false; res.innerHTML = `<div class="row"><span class="ok-ic">✓</span><div><b>مطابقة الوجه <span class="num">${k.score}%</span></b><div class="small muted">فحص الحيوية ناجح · الحد الأدنى للقبول 80%</div></div></div>`;
    ok.disabled = false;
    wb.querySelectorAll('[data-cam],[data-sim]').forEach(b => { b.disabled = false; });
    wb.querySelector('[data-cam]').textContent = 'إعادة الفحص';
  };
  wb.querySelector('[data-cam]').onclick = async () => {
    im.hidden = true; v.hidden = false; wb.querySelector('.cam').classList.remove('ok');
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } }); v.srcObject = stream; await v.play().catch(() => {}); sequence(true); }
    catch { toast('تعذّر فتح الكاميرا — استخدم «محاكاة بدون كاميرا»', 'bad'); }
  };
  wb.querySelector('[data-sim]').onclick = () => { im.hidden = true; v.hidden = true; wb.querySelector('.cam').classList.add('sim'); sequence(false); };
  ok.onclick = async () => {
    const nid = digits(wb.querySelector('[data-nid]').value);
    if (!/^\d{12}$/.test(nid)) return toast('رقم البطاقة الوطنية 12 رقماً', 'bad');
    ok.disabled = true;
    try { await saveStep(app, 1, { national_id: nid, liveness: k.live, match_score: k.score, card_side: 'front+back' }, 'تم التحقق من هويتك'); }
    catch (e) { toast(cleanErr(e), 'bad'); ok.disabled = false; }
  };
  window.addEventListener('hashchange', stop, { once: true });
}

// 2) رقم «أور» برمز تحقق
function step2(wb, app, done, edit) {
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('رقم «أور» مربوط بطلبك', [['رقم «أور»', `<span class="num">${esc(app.ur_number)}</span>`], ['التحقق النهائي', 'يتحقق منه موظف خدمة العملاء في المصرف (المرحلة 7)']], () => step2(wb, app, done, true))); return; }
  wb.innerHTML = `<h2>ربط رقم «أور»</h2><p class="muted">رقمك في بوابة «أور» الحكومية يربط طلبك ببياناتك الرسمية. نرسل رمز تحقق إلى هاتفك المسجل في «أور».</p>
    <div class="field" style="max-width:420px"><label>رقم «أور» (10 أرقام)</label><input class="input" data-ur inputmode="numeric" maxlength="10" dir="ltr" placeholder="0000000000" value="${esc(app.ur_number || '')}"></div>
    <div class="notice"><span>ℹ</span><span>تجده في تطبيق «أور» ← الملف الشخصي. في نسخة العرض اكتب أي 10 أرقام.</span></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-ok>إرسال رمز التحقق</button></div>`;
  wb.querySelector('[data-ok]').onclick = async () => {
    const ur = digits(wb.querySelector('[data-ur]').value);
    if (!/^\d{10}$/.test(ur)) return toast('رقم «أور» 10 أرقام', 'bad');
    await askOtp({ title: 'رمز التحقق من «أور»', phone: C.profile.phone, purpose: 'لربط حسابك في «أور» بطلب التمويل', verify: c => saveStep(app, 2, { ur_number: ur, otp: c }, 'تم ربط رقم «أور»') });
  };
}

// 3) تثبيت العرض أو تغييره
function step3(wb, app, done, edit) {
  const o = offerById(app.offer_id);
  if (done && !edit) { wb.innerHTML = ''; wb.appendChild(doneBox('العرض مثبّت', [['المنظومة', esc(o?.title)], ['السعر', iqd(app.price)], ['الضمان المطلوب', esc(GUARANTEE[app.guarantee_type])]], () => step3(wb, app, done, true))); return; }
  wb.innerHTML = `<h2>تثبيت العرض</h2><p class="muted">راجع المنظومة التي اخترتها. تغيير القدرة قد يغيّر نوع الضمان المطلوب.</p>
    <div class="pick big"><img src="${esc(o?.image_url)}" alt=""><div><b style="font-size:18px">${esc(o?.title)}</b><div class="row" style="gap:6px">${stars(o?.rating)}<span class="num small">${o?.rating.toFixed(1)}</span></div>
      <div class="price">${iqd(o?.price)}</div><div class="small muted">الضمان المطلوب: <b>${G_HINT[guaranteeFor(o?.price)]}</b> · <a href="#offer/${o?.id}">التفاصيل</a></div></div></div>
    <div class="row mt"><button class="btn ghost" data-ch>تغيير المنظومة</button><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[3]}</button></div>`;
  wb.querySelector('[data-ok]').onclick = async e => { e.target.disabled = true; try { await saveStep(app, 3, {}, 'تم تثبيت العرض'); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; } };
  wb.querySelector('[data-ch]').onclick = () => {
    const m = modal(`<h3>اختر منظومة أخرى</h3><div class="pick-list">${S.ref.tiers.map(t => `<div class="pl-h"><b class="num">${num(t.kw)} kW</b> <span class="small muted">— ${esc(t.loads)}</span></div>
      ${S.offers.filter(x => x.tier_id === t.id).map(x => `<label class="pl ${x.id === o?.id ? 'on' : ''}"><input type="radio" name="of" value="${x.id}" ${x.id === o?.id ? 'checked' : ''}><img src="${esc(x.image_url)}" alt=""><div><b>${esc(x.sup?.name)}</b><div class="small">${stars(x.rating, 12)} <span class="num">${x.rating.toFixed(1)}</span> · ${G_HINT[guaranteeFor(x.price)]}</div></div><span class="sp"></span><b class="small">${iqd(x.price)}</b></label>`).join('')}`).join('')}</div>
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-s>اعتماد المنظومة المختارة</button></div>`, { wide: true });
    m.el.querySelector('[data-s]').onclick = async () => {
      const id = m.el.querySelector('input[name=of]:checked')?.value;
      if (!id || id === o?.id) return m.close();
      try { m.close(); await saveStep(app, 3, { offer_id: id }, 'تم تغيير المنظومة'); } catch (e) { toast(cleanErr(e), 'bad'); }
    };
  };
}

// 4) الضمان: كفلاء بموافقة OTP أو رهن عقار
function step4(wb, app, done, edit) {
  const set = S.ref.set, gt = app.guarantee_type;
  const est = installment(app.amount, set.cbi_rate + set.margin_max, 60), need = Math.ceil(est * set.salary_safety);
  if (done && !edit) {
    const g = app.guarantee || {};
    const rows = gt === 'mortgage' ? [['نوع الضمان', 'رهن عقار'], ['السند', `<span class="num">${esc(g.deed_no)}</span>`], ['القيمة المرجعية', iqd(g.ref_value)], ['نسبة التمويل للقيمة', `<span class="num">${g.ltv}%</span>`]]
      : [['نوع الضمان', esc(GUARANTEE[gt])], ...(g.guarantors || []).map((x, i) => [`الكفيل ${i + 1}`, `${esc(x.name)} · ${esc(x.employer)} · ${badge(['وافق برمز التحقق', 'ok'])}`]), ['مجموع الرواتب', iqd(g.total_salary)]];
    wb.innerHTML = ''; wb.appendChild(doneBox('الضمان مؤكد', rows, () => step4(wb, app, done, true))); return;
  }
  const rules = `<div class="rules">${[['single_salary', `حتى ${num(set.guarantee_t1 / 1e6)} مليون`, 'كفيل واحد موظف'], ['multi_salary', `حتى ${num(set.guarantee_t2 / 1e6)} مليون`, 'كفيلان موظفان'], ['mortgage', `أكثر من ${num(set.guarantee_t2 / 1e6)} مليون`, 'رهن عقار']].map(([k, a, b]) => `<div class="${k === gt ? 'on' : ''}"><small>${a}</small><b>${b}</b></div>`).join('')}</div>`;
  if (gt === 'mortgage') return step4Mortgage(wb, app, rules);
  const min = gt === 'single_salary' ? 1 : 2;
  const list = (app.guarantee?.guarantors || []).map(g => ({ ...g, otp: null }));
  while (list.length < min) list.push({ name: '', phone: '', employer: '', salary: '', relation: 'قريب', otp: null });
  wb.innerHTML = `<h2>الضمان وموافقة الكفلاء</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب <b>${G_HINT[gt]}</b>. كل كفيل يوافق برمز تحقق يصله على هاتفه.</p>${rules}
    <div data-gs></div>
    <div class="cover"><div class="row"><span class="small">مجموع رواتب الكفلاء مقابل المطلوب (القسط التقديري ${iqd(est)} × <span class="num">${set.salary_safety}</span>)</span><span class="sp"></span><b data-sum></b></div><div class="bar"><i data-bar></i></div></div>
    <div class="row mt"><button class="btn ghost" data-add>＋ إضافة كفيل</button><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const gs = wb.querySelector('[data-gs]');
  const paint = () => {
    gs.innerHTML = list.map((g, i) => `<fieldset class="gcard ${g.otp ? 'ok' : ''}" data-i="${i}"><legend>الكفيل ${i + 1} ${g.otp ? badge(['وافق', 'ok']) : badge(['بانتظار الموافقة', 'warn'])}</legend>
      <div class="grid g2" style="gap:10px">
        <div class="field"><label>الاسم الثلاثي</label><input class="input" data-k="name" value="${esc(g.name)}"></div>
        <div class="field"><label>رقم الهاتف</label><input class="input" data-k="phone" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(g.phone)}"></div>
        <div class="field"><label>جهة العمل (دائرة حكومية أو شركة)</label><input class="input" data-k="employer" value="${esc(g.employer)}"></div>
        <div class="field"><label>الراتب الشهري (د.ع)</label><input class="input" data-k="salary" inputmode="numeric" dir="ltr" value="${esc(g.salary)}"></div>
        <div class="field"><label>صلة القرابة</label><select class="input" data-k="relation">${['قريب', 'زميل عمل', 'صديق', 'جار'].map(r => `<option ${r === g.relation ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
        <div class="field" style="justify-content:flex-end"><div class="row">${g.otp ? '<span class="ok-ic sm">✓</span><span class="small">وافق الكفيل على الكفالة</span>' : `<button type="button" class="btn sm" data-consent="${i}">إرسال رمز الموافقة للكفيل</button>`}${list.length > min ? `<span class="sp"></span><button type="button" class="linkbtn" data-rm="${i}">حذف</button>` : ''}</div></div>
      </div></fieldset>`).join('');
    gs.querySelectorAll('[data-k]').forEach(inp => inp.oninput = inp.onchange = () => {
      const i = Number(inp.closest('[data-i]').dataset.i), k = inp.dataset.k;
      const old = list[i][k]; list[i][k] = inp.value;
      if (k === 'phone' && list[i].otp && normPhone(old) !== normPhone(inp.value)) { list[i].otp = null; paint(); }
      sum();
    });
    gs.querySelectorAll('[data-consent]').forEach(b => b.onclick = async () => {
      const g = list[Number(b.dataset.consent)];
      const ph = normPhone(g.phone);
      if (g.name.trim().split(/\s+/).length < 3) return toast('اكتب الاسم الثلاثي للكفيل', 'bad');
      if (!validPhone(ph)) return toast('رقم هاتف الكفيل غير صحيح', 'bad');
      if (ph === C.profile.phone) return toast('لا يكفل المتقدم نفسه', 'bad');
      if (list.some(x => x !== g && normPhone(x.phone) === ph)) return toast('رقم هاتف مكرر بين الكفلاء', 'bad');
      const c = await askOtp({ title: `موافقة الكفيل ${g.name.split(' ')[0]}`, phone: ph, purpose: `يوافق على كفالة ${C.profile.full_name} في تمويل ${num(app.amount)} د.ع`, verify: serverOtp(C.sb, ph, 'guarantor') });
      if (c) { g.phone = ph; g.otp = c; paint(); toast('سُجّلت موافقة الكفيل', 'ok'); }
    });
    gs.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { list.splice(Number(b.dataset.rm), 1); paint(); });
    wb.querySelector('[data-add]').hidden = list.length >= 3;
    sum();
  };
  const sum = () => {
    const t = list.reduce((s, g) => s + (Number(digits(g.salary)) || 0), 0);
    wb.querySelector('[data-sum]').innerHTML = `${iqd(t)} / ${iqd(need)}`;
    const b = wb.querySelector('[data-bar]'); b.style.width = Math.min(100, t / need * 100) + '%'; b.style.background = t >= need ? 'var(--ok)' : 'var(--sun)';
  };
  wb.querySelector('[data-add]').onclick = () => { list.push({ name: '', phone: '', employer: '', salary: '', relation: 'زميل عمل', otp: null }); paint(); };
  wb.querySelector('[data-ok]').onclick = async e => {
    if (list.some(g => !g.otp)) return toast('يلزم أن يوافق كل كفيل برمز التحقق', 'bad');
    e.target.disabled = true;
    try { await saveStep(app, 4, { guarantors: list.map(g => ({ name: g.name.trim(), phone: normPhone(g.phone), employer: g.employer.trim(), salary: Number(digits(g.salary)), relation: g.relation, otp: g.otp })) }, 'تم تأكيد الضمان'); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
  paint();
}
function step4Mortgage(wb, app, rules) {
  const set = S.ref.set, g = app.guarantee || {};
  wb.innerHTML = `<h2>الضمان: رهن عقار</h2><p class="muted">مبلغ التمويل ${iqd(app.amount)} يتطلب رهن عقار. بعد إرسال الطلب يحيله المصرف إلكترونياً إلى دائرة التسجيل العقاري للتحقق من خلوه من الإشارات ثم تأشير الرهن.</p>${rules}
    <div class="grid g2" style="gap:12px">
      <div class="field"><label>رقم السند العقاري (القطعة/المقاطعة)</label><input class="input" data-k="deed_no" value="${esc(g.deed_no || '')}" placeholder="مثال: 1452/87 الكرادة"></div>
      <div class="field"><label>المحافظة</label><select class="input" data-k="governorate">${govOptions(app.governorate)}</select></div>
      <div class="field"><label>المنطقة أو المقاطعة</label><input class="input" data-k="district" value=""></div>
      <div class="field"><label>نوع الاستعمال</label><select class="input" data-k="use_type"><option>سكني</option><option>تجاري</option><option>زراعي</option></select></div>
      <div class="field"><label>مساحة الأرض (م²)</label><input class="input" data-k="land_area" inputmode="numeric" dir="ltr"></div>
      <div class="field"><label>القيمة التقديرية (د.ع)</label><input class="input" data-k="estimated_value" inputmode="numeric" dir="ltr" value="${esc(g.ref_value || '')}"></div>
    </div>
    <div class="cover"><div class="row"><span class="small">نسبة التمويل إلى قيمة العقار (الحد الأعلى <span class="num">${set.ltv_max}%</span>)</span><span class="sp"></span><b data-ltv>—</b></div><div class="bar"><i data-bar></i></div></div>
    <p class="small muted">إن كان السند مسجلاً مسبقاً في المنصة تُستخدم بياناته المسجلة وقيمته المرجعية.</p>
    <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok>${ADVANCE_LABEL[4]}</button></div>`;
  const val = () => Number(digits(wb.querySelector('[data-k=estimated_value]').value));
  const upd = () => { const v = val(), r = v ? app.amount / v * 100 : 0, b = wb.querySelector('[data-bar]');
    wb.querySelector('[data-ltv]').innerHTML = v ? `<span class="num">${r.toFixed(1)}%</span>` : '—'; b.style.width = Math.min(100, r / set.ltv_max * 100) + '%'; b.style.background = r <= set.ltv_max ? 'var(--ok)' : 'var(--bad)'; };
  wb.querySelector('[data-k=estimated_value]').oninput = upd; upd();
  wb.querySelector('[data-ok]').onclick = async e => {
    const d = {}; wb.querySelectorAll('[data-k]').forEach(i => d[i.dataset.k] = i.value.trim());
    d.estimated_value = String(val()); d.land_area = digits(d.land_area);
    if (!d.deed_no) return toast('اكتب رقم السند العقاري', 'bad');
    e.target.disabled = true;
    try { await saveStep(app, 4, d, 'تم تأكيد ضمان الرهن'); } catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// 5) مقارنة المصارف واختيار المدة ثم التوقيع الإلكتروني برمز OTP
function step5(wb, app) {
  const set = S.ref.set, o = offerById(app.offer_id);
  const banks = S.banks.filter(b => b.terms);
  let term = Math.min(app.term_months || 60, set.term_max_months), sel = app.bank_id || banks.find(b => b.open)?.id;
  const calc = b => { const rate = set.cbi_rate + Number(b.terms.margin), t = Math.min(term, b.terms.max_term_months), ins = installment(app.amount, rate, t); return { rate, t, ins, total: ins * t, profit: ins * t - app.amount }; };
  const paint = () => {
    const best = banks.filter(b => b.open).reduce((a, b) => calc(a).total <= calc(b).total ? a : b);
    const sb_ = banks.find(b => b.id === sel), c = sb_ && calc(sb_);
    wb.innerHTML = `<h2>اختيار المصرف والتوقيع</h2><p class="muted">قارن الكلفة الكاملة لكل مصرف للمدة التي تختارها. كل المصارف ملزمة بسقف الهامش في تعميم البنك المركزي.</p>
      <div class="row"><span class="small">مدة السداد</span><span class="sp"></span><b><span class="num">${term}</span> شهراً (<span class="num">${(term / 12).toFixed(1)}</span> سنة)</b></div>
      <input type="range" class="range" min="12" max="${set.term_max_months}" step="6" value="${term}" aria-label="مدة السداد">
      <div class="bcards">${banks.map(b => { const k = calc(b); return `<label class="bcard ${b.id === sel ? 'on' : ''} ${b.open ? '' : 'off'}">
        <input type="radio" name="bk" value="${b.id}" ${b.id === sel ? 'checked' : ''} ${b.open ? '' : 'disabled'}>
        <div class="row"><i class="bdot" style="background:${esc(b.meta?.color || '#4356A3')}"></i><b>${esc(b.name)}</b><span class="sp"></span>${b.id === best.id && b.open ? '<span class="badge ok">الأقل كلفة</span>' : ''}${b.is_islamic ? '<span class="badge info">مرابحة</span>' : ''}</div>
        ${b.open ? `<div class="bk-i">${iqd(k.ins)}<small>شهرياً</small></div>
        <dl class="kv small"><dt>${b.is_islamic ? 'نسبة الربح' : 'النسبة السنوية'}</dt><dd class="num">${k.rate.toFixed(2)}%</dd><dt>رسوم الملف</dt><dd>${iqd(b.terms.file_fee)}</dd><dt>إجمالي السداد</dt><dd>${iqd(k.total)}</dd><dt>${b.is_islamic ? 'ربح المصرف' : 'إجمالي الفوائد'}</dt><dd>${iqd(k.profit)}</dd><dt>مدة الدراسة</dt><dd><span class="num">${b.terms.processing_days}</span> أيام عمل</dd></dl>
        ${k.t < term ? `<div class="small" style="color:var(--warn)">أقصى مدة لدى المصرف <span class="num">${b.terms.max_term_months}</span> شهراً</div>` : ''}` : '<div class="small muted mt">لا يستقبل طلبات عبر المنصة حالياً</div>'}
      </label>`; }).join('')}</div>
      ${c ? `<div class="review"><h3>ملخص طلبك قبل التوقيع</h3><dl class="kv">
        <dt>المنظومة</dt><dd>${esc(o?.title)}</dd><dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type])}</dd>
        <dt>المصرف</dt><dd>${esc(sb_.name)}</dd><dt>المدة</dt><dd><span class="num">${c.t}</span> شهراً</dd><dt>القسط الشهري</dt><dd style="color:var(--indigo);font-size:17px">${iqd(c.ins)}</dd>
        <dt>أول قسط</dt><dd>بعد شهر من صرف المبلغ للمورد</dd></dl>
        <label class="check mt"><input type="checkbox" data-ack> أقرّ بصحة البيانات، وأفوّض المصرف بالاستعلام عن الضمان، وأوافق على استقطاع القسط الشهري.</label></div>` : ''}
      <div class="row mt"><span class="sp"></span><button class="btn cyan" data-ok ${c ? '' : 'disabled'}>التوقيع الإلكتروني وإرسال الطلب</button></div>`;
    wb.querySelector('.range').oninput = e => { term = Number(e.target.value); paint(); wb.querySelector('.range').focus(); };
    wb.querySelectorAll('input[name=bk]').forEach(r => r.onchange = () => { sel = r.value; paint(); });
    const ok = wb.querySelector('[data-ok]');
    ok.onclick = async () => {
      if (!wb.querySelector('[data-ack]')?.checked) return toast('يلزم الإقرار قبل التوقيع', 'bad');
      const code = await askOtp({ title: 'التوقيع الإلكتروني', phone: C.profile.phone, purpose: `توقيع طلب تمويل ${num(app.amount)} د.ع لدى ${sb_.name}`,
        verify: c2 => rpc(C.sb, 'citizen_step', { p_app: app.id, p_step: 5, p_data: { bank_id: sel, term_months: c.t, otp: c2 } }) });
      if (!code) return;
      await load(); C.czStep = null;
      const m = modal(`<div style="text-align:center"><div class="big-ok">✓</div><h2>أُرسل طلبك إلى ${esc(sb_.name)}</h2>
        <p class="muted">رقم الطلب <b class="num">${esc(app.code)}</b> — الآن لدى <b>وحدة الامتثال</b> لفتح الحساب. ستتابع كل مرحلة لحظة بلحظة من «طلبي».</p>
        <a class="btn cyan" href="#home" data-x>متابعة طلبي</a></div>`);
      m.el.querySelector('[data-x]').onclick = m.close;
      location.hash = '#home';
    };
  };
  paint();
}

// ───────── التقييم بعد التركيب ─────────
function rateDialog(app) {
  const v = { rating: 0, quality: 0, install: 0, service: 0 };
  const row = (k, l) => `<div class="rate-row"><span>${l}</span><span class="sp"></span><span class="rate" data-r="${k}">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-n="${n}" aria-label="${n}">★</button>`).join('')}</span></div>`;
  const m = modal(`<h3>قيّم منظومتك</h3><p class="muted small">يظهر تقييمك باسمك المختصر ومحافظتك.</p>
    ${row('rating', '<b>التقييم العام</b>')}${row('quality', 'جودة المنظومة')}${row('install', 'التركيب')}${row('service', 'خدمة المورد')}
    <div class="field mt"><label>تعليقك (اختياري)</label><textarea class="input" rows="3" data-c maxlength="400" placeholder="كيف الأداء؟ هل كفت البطاريات الليل؟"></textarea></div>
    <div class="row"><span class="sp"></span><button class="btn cyan" data-s>نشر التقييم</button></div>`);
  m.el.querySelectorAll('[data-r]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => {
    v[g.dataset.r] = Number(b.dataset.n); g.querySelectorAll('button').forEach(x => x.classList.toggle('on', Number(x.dataset.n) <= v[g.dataset.r]));
  }));
  m.el.querySelector('[data-s]').onclick = async () => {
    if (!v.rating) return toast('اختر التقييم العام', 'bad');
    try { await rpc(C.sb, 'submit_review', { p_app: app.id, p_rating: v.rating, p_quality: v.quality || v.rating, p_install: v.install || v.rating, p_service: v.service || v.rating, p_comment: m.el.querySelector('[data-c]').value }); m.close(); toast('شكراً — نُشر تقييمك', 'ok'); await refreshAll(); }
    catch (e) { toast(cleanErr(e), 'bad'); }
  };
}

// ───────── الملف الشخصي للمقترض ─────────
function pageProfile(body) {
  const p = C.profile, set = S.ref.set;
  const fin = S.apps.find(a => a.bank_id && a.monthly_installment && !['cancelled', 'rejected'].includes(a.status));
  const age = p.birth_date ? Math.floor((Date.now() - new Date(p.birth_date)) / (365.25 * 864e5)) : null;
  const myReviews = S.reviews.filter(r => r.citizen_id === p.id);
  body.innerHTML = `
    <div class="prof-head card">
      <div class="av xl">${esc(p.full_name.trim()[0])}</div>
      <div><h1 style="font-size:22px">${esc(p.full_name)}</h1>
        <div class="row" style="gap:8px;margin-top:4px">${p.kyc_status === 'verified' ? badge(['هوية موثّقة بالسيلفي', 'ok']) : badge(['الهوية غير موثّقة بعد', 'warn'])}<span class="small" style="color:#9FB4D6">عضو منذ ${dt(p.created_at).split('،')[0]}</span></div></div>
      <span class="sp"></span>
      <div class="prof-kpis"><div><b class="num">${S.apps.length}</b><span>طلب</span></div><div><b>${fin ? iqd(fin.monthly_installment) : '—'}</b><span>القسط الشهري</span></div><div><b class="num">${myReviews.length}</b><span>تقييم</span></div></div>
    </div>
    <div class="grid g2 mt">
      <div class="card"><h3>البيانات الشخصية<span class="sp"></span><span class="badge muted">من البطاقة الوطنية</span></h3>
        <dl class="kv"><dt>الاسم</dt><dd>${esc(p.full_name)}</dd><dt>رقم البطاقة</dt><dd><span class="num">${esc(maskId(p.national_id))}</span></dd>
          <dt>تاريخ الميلاد</dt><dd>${p.birth_date ? `<span class="num">${esc(p.birth_date)}</span> (<span class="num">${age}</span> سنة)` : '—'}</dd>
          <dt>رقم الهاتف</dt><dd><span class="num">${esc(p.phone || '—')}</span> <button class="linkbtn" data-phone>تغيير</button></dd>
          <dt>اسم الدخول</dt><dd><span class="num">${esc(p.username)}</span></dd>
          <dt>التحقق</dt><dd>${p.kyc_at ? `${dt(p.kyc_at)}` : 'يتم في أول خطوة من طلب التمويل'}</dd></dl>
        <p class="small muted" style="margin:10px 0 0">الاسم ورقم البطاقة لا يُعدَّلان بعد التحقق من الهوية.</p></div>
      <form class="card" data-f="contact" novalidate><h3>العنوان والتواصل</h3>
        <div class="grid g2" style="gap:10px">
          <div class="field"><label>المحافظة</label><select class="input" name="governorate">${govOptions(p.governorate || '')}</select></div>
          <div class="field"><label>المدينة / القضاء</label><input class="input" name="city" value="${esc(p.city || '')}"></div>
        </div>
        <div class="field"><label>العنوان التفصيلي</label><input class="input" name="address" value="${esc(p.address || '')}" placeholder="المحلة، الزقاق، الدار"></div>
        <div class="field"><label>البريد الإلكتروني (اختياري)</label><input class="input" name="email" type="email" dir="ltr" value="${esc(p.email || '')}"></div>
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="work" novalidate><h3>العمل والدخل</h3>
        <div class="field"><label>جهة العمل</label><input class="input" name="employer" value="${esc(p.employer || '')}" placeholder="دائرة حكومية، شركة، عمل حر"></div>
        <div class="field"><label>الدخل الشهري (د.ع)</label><input class="input" name="monthly_salary" inputmode="numeric" dir="ltr" value="${esc(p.monthly_salary || '')}"></div>
        ${fin && p.monthly_salary ? `<div class="cover"><div class="row"><span class="small">القسط من دخلك</span><span class="sp"></span><b class="num">${(fin.monthly_installment / p.monthly_salary * 100).toFixed(1)}%</b></div><div class="bar"><i style="width:${Math.min(100, fin.monthly_installment / p.monthly_salary * 100)}%;background:${fin.monthly_installment / p.monthly_salary < .35 ? 'var(--ok)' : 'var(--sun)'}"></i></div></div>` : ''}
        <div class="row"><span class="sp"></span><button class="btn">حفظ</button></div></form>
      <form class="card" data-f="pw" novalidate><h3>الأمان — تغيير كلمة المرور</h3>
        <div class="field"><label>كلمة المرور الحالية</label><input class="input" name="old" type="password" dir="ltr" autocomplete="current-password"></div>
        <div class="field"><label>كلمة المرور الجديدة</label><input class="input" name="nw" type="password" dir="ltr" autocomplete="new-password"><small class="muted">8 أحرف على الأقل، حروف إنجليزية وأرقام</small></div>
        <div class="row"><span class="sp"></span><button class="btn">تغيير كلمة المرور</button></div></form>
    </div>
    <div class="card mt" id="sched"></div>
    <div class="card mt"><h3>طلباتي</h3>${S.apps.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>رقم الطلب</th><th>المنظومة</th><th>المصرف</th><th>المبلغ</th><th>المرحلة</th><th>الحالة</th></tr></thead><tbody>
      ${S.apps.map(a => `<tr class="click" data-go="${a.id}"><td><b class="num">${esc(a.code)}</b></td><td><span class="num">${num(a.kw)}</span> kW</td><td>${esc(C.orgs.find(x => x.id === a.bank_id)?.name || '—')}</td><td>${iqd(a.amount)}</td><td><span class="num">${a.stage}</span> / 14</td><td>${statusBadge(a.status)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">لا طلبات بعد. <a href="#catalog">ابدأ من الكتالوج</a></p>'}</div>
    ${myReviews.length ? `<div class="card mt"><h3>تقييماتي</h3><ul class="rv-list">${myReviews.map(r => `<li><div class="row">${stars(r.rating)}<span class="small muted">${ago(r.created_at)}</span></div>${r.comment ? `<p>${esc(r.comment)}</p>` : ''}</li>`).join('')}</ul></div>` : ''}
    <div class="row mt"><span class="sp"></span><button class="btn ghost" data-out>تسجيل الخروج</button></div>`;
  // جدول الأقساط
  const sc = body.querySelector('#sched');
  if (!fin) sc.innerHTML = `<h3>جدول الأقساط</h3><p class="muted">يظهر جدول أقساطك بعد اختيار المصرف وتوقيع الطلب.</p>`;
  else {
    const rate = set.cbi_rate + Number(fin.margin || 0), r = rate / 1200, n = fin.term_months, ins = fin.monthly_installment;
    const start = fin.status === 'completed' ? new Date(fin.updated_at) : null;
    const paid = start ? Math.max(0, Math.floor((Date.now() - start) / (30.44 * 864e5))) : 0;
    let bal = fin.amount; const rows = [];
    for (let i = 1; i <= n; i++) { const it = Math.round(bal * r), pr = Math.min(bal, ins - it); bal = Math.max(0, bal - pr); rows.push({ i, it, pr, bal, due: start ? new Date(start.getFullYear(), start.getMonth() + i, start.getDate()) : null }); }
    const all = C.czAllRows;
    sc.innerHTML = `<h3>جدول الأقساط<span class="sp"></span><span class="small muted">${esc(C.orgs.find(x => x.id === fin.bank_id)?.name)} · <span class="num">${rate.toFixed(2)}%</span></span></h3>
      <div class="grid g4" style="gap:10px;margin-bottom:12px">
        <div class="stat"><b>${iqd(fin.amount)}</b><span>مبلغ التمويل</span></div><div class="stat"><b>${iqd(ins)}</b><span>القسط الشهري</span></div>
        <div class="stat"><b>${iqd(ins * n)}</b><span>إجمالي السداد</span></div><div class="stat"><b><span class="num">${paid}</span> / <span class="num">${n}</span></b><span>أقساط مسددة</span></div></div>
      ${start ? '' : '<div class="notice"><span>ℹ</span><span>يبدأ أول قسط بعد شهر من صرف المبلغ للمورد (المرحلة 14). التواريخ تظهر عند الصرف.</span></div>'}
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>الاستحقاق</th><th>القسط</th><th>أصل</th><th>${fin.margin ? 'فائدة/ربح' : 'فائدة'}</th><th>المتبقي</th><th>الحالة</th></tr></thead><tbody>
      ${rows.slice(0, all ? n : 12).map(x => `<tr><td class="num">${x.i}</td><td class="small">${x.due ? x.due.toLocaleDateString('ar-IQ-u-nu-latn', { year: 'numeric', month: 'short' }) : `الشهر <span class="num">${x.i}</span>`}</td><td>${iqd(ins)}</td><td>${iqd(x.pr)}</td><td>${iqd(x.it)}</td><td>${iqd(x.bal)}</td><td>${x.i <= paid ? badge(['مسدد', 'ok']) : x.i === paid + 1 && start ? badge(['القادم', 'warn']) : badge(['مجدول', 'muted'])}</td></tr>`).join('')}</tbody></table></div>
      ${n > 12 ? `<button class="btn ghost block mt" data-rows>${all ? 'عرض أول 12 قسطاً' : `عرض كل الأقساط (<span class="num">${n}</span>)`}</button>` : ''}`;
    const rb = sc.querySelector('[data-rows]'); if (rb) rb.onclick = () => { C.czAllRows = !C.czAllRows; pageProfile(body); };
  }
  body.querySelectorAll('[data-go]').forEach(tr => tr.onclick = () => { location.hash = '#home'; });
  const save = async (f, keys) => {
    const d = {}; keys.forEach(k => d[k] = (f[k].value || '').trim());
    if ('monthly_salary' in d) d.monthly_salary = digits(d.monthly_salary);
    const b = f.querySelector('button'); b.disabled = true;
    try { C.profile = await rpc(C.sb, 'update_my_profile', { p: d }); toast('حُفظت التغييرات', 'ok'); pageProfile(body); }
    catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
  };
  body.querySelector('[data-f=contact]').onsubmit = e => { e.preventDefault(); save(e.target, ['governorate', 'city', 'address', 'email']); };
  body.querySelector('[data-f=work]').onsubmit = e => { e.preventDefault(); save(e.target, ['employer', 'monthly_salary']); };
  body.querySelector('[data-f=pw]').onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    if (f.nw.value.length < 8 || !/\d/.test(f.nw.value) || !/[A-Za-z]/.test(f.nw.value)) return toast('كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً', 'bad');
    try { await rpc(C.sb, 'change_my_password', { p_old: f.old.value, p_new: f.nw.value }); f.reset(); toast('تم تغيير كلمة المرور', 'ok'); } catch (er) { toast(cleanErr(er), 'bad'); }
  };
  body.querySelector('[data-phone]').onclick = () => {
    const m = modal(`<h3>تغيير رقم الهاتف</h3><p class="muted small">نرسل رمز تحقق إلى الرقم الجديد.${p.self_registered ? ' سيصبح الرقم الجديد اسم دخولك.' : ''}</p>
      <div class="field"><label>الرقم الجديد</label><input class="input" data-ph inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="row"><span class="sp"></span><button class="btn cyan" data-s>إرسال الرمز</button></div>`);
    m.el.querySelector('[data-s]').onclick = async () => {
      const ph = normPhone(m.el.querySelector('[data-ph]').value);
      if (!validPhone(ph)) return toast('رقم الهاتف غير صحيح', 'bad');
      m.close();
      const c = await askOtp({ title: 'تأكيد الرقم الجديد', phone: ph, verify: async code => { C.profile = await rpc(C.sb, 'change_my_phone', { p_new_phone: ph, p_otp: code }); } });
      if (c) { toast('تم تغيير رقم الهاتف', 'ok'); pageProfile(body); }
    };
  };
  body.querySelector('[data-out]').onclick = async () => { await C.sb.auth.signOut(); location.hash = ''; location.reload(); };
}
