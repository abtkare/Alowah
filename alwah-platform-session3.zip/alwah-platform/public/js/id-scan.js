// تصوير البطاقة الوطنية وقراءتها تلقائياً عبر خدمة loan-ocr (على سيرفر المنصة الخاص)
import { esc, GOVS } from './core.js';

const OCR = () => ((window.ALWAH_CONFIG || {}).ocr || '').replace(/\/+$/, '');
export const ocrEnabled = () => !!OCR();

// تصغير صورة الكاميرا قبل الرفع (صور الآيفون كبيرة جداً وتبطئ الرفع)
async function shrink(file, max = 1800) {
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    bmp.close && bmp.close();
    return await new Promise(r => c.toBlob(b => r(b || file), 'image/jpeg', 0.88));
  } catch { return file; }
}

// مطابقة مكان الولادة مع قائمة المحافظات
function matchGov(place) {
  if (!place) return '';
  const p = String(place).replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه');
  const hit = GOVS.find(([g]) => p.includes(g.replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/^ال/, '')));
  return hit ? hit[0] : '';
}

export async function readNationalId(front, back) {
  const body = new FormData();
  if (front) body.append('front', await shrink(front), 'front.jpg');
  if (back) body.append('back', await shrink(back), 'back.jpg');
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 120000);
  let res;
  try { res = await fetch(OCR() + '/api/v1/documents/national-id', { method: 'POST', body, signal: ctl.signal }); }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'استغرقت القراءة وقتاً طويلاً، حاول مرة أخرى' : 'تعذر الاتصال بخدمة قراءة البطاقة، تحقق من الإنترنت'); }
  finally { clearTimeout(t); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data.error && data.error.message) || 'تعذرت قراءة البطاقة');
  const f = data.fields || {}; const v = k => (f[k] && f[k].value) || '';
  const nid = String(v('national_id_number')).replace(/\D/g, '');
  return {
    name: String(v('full_name')).trim(),
    nid: nid.length === 12 ? nid : '',
    bd: String(v('date_of_birth')).slice(0, 10),
    gov: matchGov(v('place_of_birth')),
    mother: String(v('mother_name')).trim(),
    gender: v('gender'), cardNo: v('card_number'), expiry: v('expiry_date'),
    warnings: data.warnings || [], verified: !!data.mrz_verified,
    weak: [['full_name', 'الاسم'], ['national_id_number', 'الرقم الوطني'], ['date_of_birth', 'تاريخ الميلاد']]
      .filter(([k]) => f[k] && f[k].value && f[k].confidence < 0.8).map(([, l]) => l),
  };
}

// كاميرا حية بإطار على شكل البطاقة: تقصّ البطاقة وحدها ليرتفع دقة القراءة كثيراً
const CARD = 1.586; // نسبة عرض البطاقة إلى ارتفاعها
function openCamera(hint) {
  return new Promise(resolve => {
    const bg = document.createElement('div');
    bg.className = 'cam';
    bg.innerHTML = `<video playsinline autoplay muted></video>
      <div class="cam-frame"><i></i><i></i><i></i><i></i></div>
      <p class="cam-hint">${esc(hint)}<small>قرّب الهاتف حتى تملأ البطاقة الإطار، وتجنّب انعكاس الضوء</small></p>
      <div class="cam-bar">
        <button type="button" class="cam-x" aria-label="إغلاق">✕</button>
        <button type="button" class="cam-shoot" aria-label="التقاط"></button>
        <label class="cam-gal">المعرض<input type="file" accept="image/*" hidden></label>
      </div>`;
    document.body.appendChild(bg);
    const video = bg.querySelector('video'), frame = bg.querySelector('.cam-frame');
    let stream = null;
    const done = v => { stream && stream.getTracks().forEach(t => t.stop()); bg.remove(); resolve(v); };
    bg.querySelector('.cam-x').onclick = () => done(null);
    bg.querySelector('.cam-gal input').onchange = e => done(e.target.files[0] || null);
    bg.querySelector('.cam-shoot').onclick = () => {
      const VW = video.videoWidth, VH = video.videoHeight; if (!VW) return;
      const vr = video.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      const k = Math.max(vr.width / VW, vr.height / VH);
      const x0 = vr.left + (vr.width - VW * k) / 2, y0 = vr.top + (vr.height - VH * k) / 2;
      const pad = 0.05 * fr.width; // هامش صغير حول البطاقة لاكتشاف حوافها
      let sx = (fr.left - pad - x0) / k, sy = (fr.top - pad - y0) / k, sw = (fr.width + 2 * pad) / k, sh = (fr.height + 2 * pad) / k;
      sx = Math.max(0, sx); sy = Math.max(0, sy); sw = Math.min(VW - sx, sw); sh = Math.min(VH - sy, sh);
      const c = document.createElement('canvas'); const s = Math.min(1, 1800 / sw);
      c.width = Math.round(sw * s); c.height = Math.round(sh * s);
      c.getContext('2d').drawImage(video, sx, sy, sw, sh, 0, 0, c.width, c.height);
      c.toBlob(b => done(b), 'image/jpeg', 0.92);
    };
    const fit = () => { const w = Math.min(innerWidth * 0.9, (innerHeight * 0.5) * CARD, 560); frame.style.width = w + 'px'; frame.style.height = w / CARD + 'px'; };
    fit(); addEventListener('resize', fit, { once: true });
    (navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      ? navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false })
      : Promise.reject())
      .then(st => { stream = st; video.srcObject = st; })
      .catch(() => { bg.querySelector('.cam-hint').innerHTML = 'تعذر فتح الكاميرا — اسمح للموقع باستخدامها من إعدادات المتصفح، أو اختر صورة من «المعرض»'; bg.querySelector('.cam-shoot').disabled = true; });
  });
}

// واجهة الخطوة: صورة الوجه + صورة الظهر ثم القراءة
export function mountIdScan(root, { onResult, onSkip, onBack, errBox }) {
  const shots = { front: null, back: null };
  root.innerHTML = `<h2>صوّر بطاقتك الوطنية</h2>
    <p class="sub">نقرأ بياناتك من البطاقة ونملأ الحقول تلقائياً — ستفتح الكاميرا بإطار، ضع البطاقة داخله على سطح داكن وبإضاءة جيدة</p>
    ${errBox('')}
    <div class="idshots">
      ${['front', 'back'].map(k => `<button type="button" class="idshot" data-k="${k}">
        <span class="ph"><b>${k === 'front' ? '١' : '٢'}</b>${k === 'front' ? 'وجه البطاقة (الصورة والاسم)' : 'ظهر البطاقة (اختياري — يزيد الدقة)'}<small>اضغط للتصوير</small></span>
        <img alt="" hidden></button>`).join('')}
    </div>
    <div class="idbusy" hidden><i></i><span>جارِ قراءة البطاقة… قد تستغرق حتى دقيقة</span></div>
    <button class="btn cyan block" type="button" data-read disabled>قراءة البطاقة وتعبئة البيانات</button>
    <div class="row mt"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button type="button" class="linkbtn" data-skip>الإدخال يدوياً بدلاً من ذلك</button></div>`;
  const btn = root.querySelector('[data-read]'); const busy = root.querySelector('.idbusy');
  const showErr = m => { const e = root.querySelector('.err'); e.textContent = m; e.classList.toggle('on', !!m); };
  root.querySelectorAll('.idshot').forEach(box => {
    const img = box.querySelector('img');
    box.onclick = async () => {
      const file = await openCamera(box.dataset.k === 'front' ? 'ضع وجه البطاقة داخل الإطار' : 'ضع ظهر البطاقة داخل الإطار مع الشريط السفلي');
      if (!file) return;
      shots[box.dataset.k] = file;
      if (img.src) URL.revokeObjectURL(img.src);
      img.src = URL.createObjectURL(file); img.hidden = false; box.classList.add('has');
      btn.disabled = !shots.front; showErr('');
    };
  });
  root.querySelector('[data-skip]').onclick = onSkip;
  root.querySelector('[data-back]').onclick = onBack;
  btn.onclick = async () => {
    btn.disabled = true; busy.hidden = false; showErr('');
    try {
      const r = await readNationalId(shots.front, shots.back);
      if (!r.name && !r.nid) throw new Error('لم نتمكن من قراءة البيانات — أعد التصوير بوضوح أكبر أو أدخلها يدوياً');
      onResult(r);
    } catch (e) { showErr(e.message); btn.disabled = false; }
    finally { busy.hidden = true; }
  };
}

export const scanNote = r => `<div class="idnote ${r.verified ? 'ok' : ''}">${r.verified ? '✓ قُرئت البيانات من بطاقتك وتحققنا من الشريط السفلي' : '✓ قُرئت البيانات من بطاقتك تلقائياً'} — راجعها وصحّح أي خطأ قبل المتابعة${r.weak && r.weak.length ? `<small>• تأكد خاصةً من: ${esc(r.weak.join('، '))}</small>` : ''}${!r.bd ? '<small>• تاريخ الميلاد مكتوب في ظهر البطاقة — صوّره أو أدخل التاريخ يدوياً</small>' : ''}${(r.warnings || []).map(w => `<small>• ${esc(w)}</small>`).join('')}</div>`;
