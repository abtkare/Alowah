// ألواح — أدوات مشتركة لكل البوابات
export const PORTALS = {
  citizen:   { title: 'بوابة المواطن', short: 'المواطن', sub: 'قدّم طلب تمويل منظومتك الشمسية وتابع كل مراحله', points: ['اختر القدرة التوليدية من الكتالوج', 'قارن عروض الموردين بالسعر والتقييم', 'اعرف ضمانك وقسطك قبل التقديم', 'تابع طلبك لحظة بلحظة'] },
  bank:      { title: 'بوابة المصرف', short: 'المصرف', sub: 'دورة الطلب داخل المصرف في سبع وحدات منفصلة الصلاحيات', points: ['صندوق مستقل لكل وحدة', 'من يستلم لا يقرر، ومن يقرر لا يصرف', 'دفتر الحصة وتنبيه عند 80%', 'إحالة الرهن للتسجيل العقاري إلكترونياً'] },
  registry:  { title: 'بوابة التسجيل العقاري', short: 'التسجيل العقاري', sub: 'إحالات الرهن الواردة من المصارف', points: ['استعلام الخلو من الإشارات', 'مطابقة السند وهوية المالك', 'تأشير الرهن برقم موثق', 'فك الرهن بعد براءة الذمة'] },
  cbi:       { title: 'لوحة البنك المركزي العراقي', short: 'البنك المركزي', sub: 'الإشراف على المبادرة: الحصص والتعاميم والسيولة', points: ['خريطة المنظومات المركّبة', 'حصص المصارف وطلبات التعزيز', 'سجل التعاميم النافذة', 'إطلاق السيولة للطلبات المكتملة'] },
  supplier:  { title: 'بوابة المورد', short: 'المورد', sub: 'الكتالوج والطلبات والتركيب وتوثيق التشغيل', points: ['عروضك لكل فئة قدرة', 'الطلبات التي اختارك فيها المواطن', 'محضر التركيب بالأرقام التسلسلية', 'توثيق التشغيل بالكاميرا'] },
  integrity: { title: 'لوحة هيئة النزاهة', short: 'هيئة النزاهة', sub: 'قراءة كاملة وتنبيهات آلية — دون أي تعديل أو إيقاف', points: ['تنبيهات الأسعار والعمولات', 'كشف التكرار والتواطؤ', 'سجل تدقيق متسلسل لا يُمحى', 'تصدير ملف أي طلب'] },
};

export const ROLE_LABELS = {
  citizen: 'مواطن', bank_cs: 'خدمة العملاء', bank_compliance: 'الامتثال ومكافحة غسل الأموال', bank_credit: 'الائتمان',
  bank_committee: 'لجنة الائتمان', bank_legal: 'الشؤون القانونية', bank_ops: 'العمليات المصرفية', bank_collection: 'التحصيل والمتابعة',
  bank_risk: 'المخاطر والتدقيق الداخلي', registry_officer: 'موظف التسجيل العقاري', cbi_admin: 'البنك المركزي',
  supplier_admin: 'مدير حساب المورد', integrity_viewer: 'مدقق النزاهة'
};

export const GUARANTEE = { single_salary: 'راتب موظف واحد', multi_salary: 'رواتب عدة موظفين', mortgage: 'رهن عقار' };
export const STATUS = {
  active: ['قيد المعالجة', 'info'], returned: ['مُعاد للاستكمال', 'warn'], rejected: ['مرفوض', 'bad'],
  completed: ['مكتمل', 'ok'], court_hold: ['موقوف بأمر قضائي', 'bad'], cancelled: ['ملغى', 'muted']
};
export const REF_STATUS = {
  pending: ['بانتظار استعلام الخلو', 'warn'], clear: ['خالٍ — بانتظار المطابقة', 'info'], encumbered: ['عليه إشارة', 'bad'],
  matched: ['مطابق — بانتظار التأشير', 'info'], annotated: ['رهن مؤشَّر', 'ok'], released: ['مفكوك', 'muted'], rejected: ['مرفوض', 'bad']
};
export const PROP_STATUS = { free: ['خالٍ', 'ok'], mortgaged: ['مرهون', 'warn'], seized: ['محجوز', 'bad'], frozen: ['موقوف', 'bad'] };

// نص زر الإنجاز لكل مرحلة
export const ADVANCE_LABEL = {
  1: 'إكمال التحقق من الهوية', 2: 'تأكيد رقم «أور»', 3: 'تثبيت العرض المختار', 4: 'تأكيد الضمان', 5: 'تأكيد اختيار المصرف',
  6: 'قبول الامتثال وفتح الحساب', 7: 'استلام الملف والتحقق من «أور»', 8: 'رفع التوصية الائتمانية', 9: 'الموافقة وحجز المبلغ من الحصة',
  10: 'توقيع العقد وتفعيل التأمين', 11: 'اعتماد محضر التركيب', 12: 'رفع توثيق التشغيل وتقرير المدقق', 13: 'إطلاق السيولة', 14: 'الصرف للمورد وإغلاق الطلب'
};

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const num = n => n == null ? '—' : Number(n).toLocaleString('en-US');
export const iqd = n => n == null ? '—' : `<span class="num">${num(Math.round(n))}</span> د.ع`;
export const mln = n => `<span class="num">${(Number(n || 0) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 1 })}</span> مليون`;
export const pct = n => `<span class="num">${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 1 })}%</span>`;
export const dt = s => s ? new Date(s).toLocaleString('ar-IQ-u-nu-latn', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
export const ago = s => {
  const m = Math.round((Date.now() - new Date(s)) / 60000);
  if (m < 1) return 'الآن'; if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.round(m / 60); if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.round(h / 24)} يوم`;
};
export const badge = ([t, k]) => `<span class="badge ${k}"><i class="dot"></i>${esc(t)}</span>`;
export const statusBadge = s => badge(STATUS[s] || [s, 'muted']);

export function el(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }

let toastTimer;
export function toast(msg, kind = '') {
  let t = document.querySelector('.toast');
  if (!t) { t = el('<div class="toast"></div>'); document.body.appendChild(t); }
  t.className = 'toast ' + kind; t.textContent = msg;
  requestAnimationFrame(() => t.classList.add('on'));
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('on'), 3800);
}

// شريط المراحل الأربع عشرة
export function stageBar(app) {
  let out = '';
  for (let i = 1; i <= 14; i++) {
    let c = '';
    if (app.status === 'completed' || i < app.stage) c = 'done';
    else if (i === app.stage) c = app.status === 'rejected' ? 'bad' : 'cur';
    out += `<span class="s ${c}" title="${i}"></span>`;
  }
  return `<div class="stages">${out}</div>`;
}

export function stageList(app, stages) {
  return `<ol class="stage-list">${stages.map(s => {
    const done = app.status === 'completed' || s.n < app.stage;
    const cur = s.n === app.stage && app.status !== 'completed';
    return `<li class="${done ? 'done' : cur ? 'cur' : ''}"><span class="n">${done ? '✓' : s.n}</span><span>${esc(s.name)}</span><span class="who">${esc(s.owner_label)}</span></li>`;
  }).join('')}</ol>`;
}

export function eventsList(events) {
  if (!events.length) return '<p class="muted small">لا أحداث بعد.</p>';
  return `<ul class="events">${events.slice().reverse().map(e => `
    <li><div><b>${esc(e.action)}</b> — <span class="muted">${esc(e.actor_name || '')}</span></div>
    ${e.note ? `<div>${esc(e.note)}</div>` : ''}
    <div class="t">${dt(e.created_at)} · المرحلة ${e.stage} · <span class="h" title="${esc(e.hash)}">#${esc((e.hash || '').slice(0, 12))}</span></div></li>`).join('')}</ul>`;
}

// درج تفاصيل الطلب — مشترك لكل البوابات
export async function openApp(ctx, app, { actions = [], extra = '' } = {}) {
  const { sb, stages } = ctx;
  closeDrawer();
  const bg = el('<div class="drawer-bg"></div>');
  const dr = el(`<aside class="drawer" role="dialog" aria-label="تفاصيل الطلب">
    <div class="dh"><div><div class="small" style="color:#8FA3C0">طلب تمويل</div><h2 class="num">${esc(app.code)}</h2></div><span class="sp"></span>${statusBadge(app.status)}<button class="btn btn-dark sm" data-close>إغلاق</button></div>
    <div class="db"><div class="spin"></div></div>
    <div class="df" ${actions.length ? '' : 'hidden'}></div></aside>`);
  document.body.append(bg, dr);
  requestAnimationFrame(() => { bg.classList.add('on'); dr.classList.add('on'); });
  bg.onclick = closeDrawer; dr.querySelector('[data-close]').onclick = closeDrawer;

  const events = (await sb.from('application_events').select('*').eq('application_id', app.id).order('id')).data || [];
  const cur = stages.find(s => s.n === app.stage);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  dr.querySelector('.db').innerHTML = `
    <div class="card mb">
      <div class="row"><b>${esc(app.citizen_name)}</b><span class="sp"></span><span class="muted small">${esc(app.governorate)}</span></div>
      ${stageBar(app)}
      <div class="small muted">المرحلة الحالية: <b style="color:var(--text)">${app.stage}. ${esc(cur?.name)}</b> — لدى ${esc(cur?.owner_label)}</div>
    </div>
    ${extra}
    <div class="card mb"><h3>بيانات الطلب</h3>
      <dl class="kv">
        <dt>القدرة</dt><dd><span class="num">${num(app.kw)}</span> kW</dd>
        <dt>المورد</dt><dd>${esc(org(app.supplier_id))}</dd>
        ${ctx.hide?.includes('amount') ? '' : `<dt>مبلغ التمويل</dt><dd>${iqd(app.amount)}</dd><dt>القسط الشهري</dt><dd>${iqd(app.monthly_installment)} × <span class="num">${app.term_months}</span> شهراً</dd>`}
        ${ctx.hide?.includes('guarantee') ? '' : `<dt>الضمان</dt><dd>${esc(GUARANTEE[app.guarantee_type] || '—')}</dd>`}
        <dt>المصرف</dt><dd>${esc(org(app.bank_id))}</dd>
        <dt>رقم «أور»</dt><dd><span class="num">${esc(app.ur_number || '—')}</span> ${app.ur_verified ? badge(['متحقق منه', 'ok']) : badge(['بانتظار التحقق', 'warn'])}</dd>
        ${app.inspection_result ? `<dt>التدقيق الهندسي</dt><dd>${badge([app.inspection_result, 'ok'])}</dd>` : ''}
        <dt>تاريخ التقديم</dt><dd>${dt(app.created_at)}</dd>
      </dl>
    </div>
    <div class="grid g2">
      <div class="card"><h3>المراحل</h3>${stageList(app, stages)}</div>
      <div class="card"><h3>سجل التدقيق <span class="sp"></span><span class="badge muted">متسلسل بالبصمة</span></h3>${eventsList(events)}</div>
    </div>`;

  if (actions.length) {
    const f = dr.querySelector('.df');
    f.innerHTML = `<div class="field" style="margin-bottom:10px"><textarea class="input" rows="2" placeholder="ملاحظة أو سبب (يُحفظ في سجل التدقيق)"></textarea></div><div class="row"></div>`;
    const row = f.querySelector('.row');
    actions.forEach(a => {
      const b = el(`<button class="btn ${a.kind || ''}">${esc(a.label)}</button>`);
      b.onclick = async () => {
        const note = f.querySelector('textarea').value.trim() || null;
        if (a.needNote && !note) return toast('اكتب السبب أولاً', 'bad');
        row.querySelectorAll('button').forEach(x => x.disabled = true);
        try { await a.run(note); toast(a.done || 'تم تنفيذ الإجراء', 'ok'); closeDrawer(); ctx.refresh(); }
        catch (e) { toast(cleanErr(e), 'bad'); row.querySelectorAll('button').forEach(x => x.disabled = false); }
      };
      row.appendChild(b);
    });
  }
}

export function closeDrawer() {
  document.querySelectorAll('.drawer,.drawer-bg').forEach(n => { n.classList.remove('on'); setTimeout(() => n.remove(), 250); });
}

export const cleanErr = e => (e?.message || String(e)).replace(/^.*?ERROR:\s*/, '');

// إجراءات المسار العامة
export async function rpc(sb, fn, args) {
  const { data, error } = await sb.rpc(fn, args);
  if (error) throw error;
  return data;
}

export function stageActions(ctx, app) {
  const { sb } = ctx;
  return [
    { label: ADVANCE_LABEL[app.stage], kind: 'ok', done: 'تم إنجاز المرحلة ونُقل الطلب للمرحلة التالية', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'advance', p_note: note }) },
    { label: 'إعادة للاستكمال', kind: 'warn', needNote: true, done: 'أُعيد الطلب للاستكمال', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'return', p_note: note }) },
    { label: 'رفض مسبب', kind: 'bad', needNote: true, done: 'رُفض الطلب', run: note => rpc(sb, 'advance_application', { p_app: app.id, p_action: 'reject', p_note: note }) },
  ];
}

export function appsTable(apps, ctx, { onOpen, cols = ['code', 'name', 'kw', 'amount', 'stage', 'status', 'updated'] } = {}) {
  if (!apps.length) return `<div class="empty">لا توجد طلبات هنا الآن.</div>`;
  const st = n => ctx.stages.find(s => s.n === n);
  const org = id => ctx.orgs.find(o => o.id === id)?.name || '—';
  const C = {
    code: ['رقم الطلب', a => `<b class="num">${esc(a.code)}</b>`],
    name: ['المتقدم', a => esc(a.citizen_name)],
    gov: ['المحافظة', a => esc(a.governorate)],
    kw: ['القدرة', a => `<span class="num">${num(a.kw)}</span> kW`],
    amount: ['التمويل', a => iqd(a.amount)],
    guarantee: ['الضمان', a => esc(GUARANTEE[a.guarantee_type] || '—')],
    bank: ['المصرف', a => esc(org(a.bank_id))],
    supplier: ['المورد', a => esc(org(a.supplier_id))],
    stage: ['المرحلة', a => `<span class="num">${a.stage}</span>. ${esc(st(a.stage)?.name)}`],
    status: ['الحالة', a => statusBadge(a.status)],
    updated: ['آخر تحديث', a => `<span class="muted small">${ago(a.updated_at)}</span>`],
  };
  const id = 't' + Math.random().toString(36).slice(2);
  setTimeout(() => {
    document.querySelectorAll(`#${id} tbody tr`).forEach((tr, i) => tr.onclick = () => onOpen && onOpen(apps[i]));
  });
  return `<div class="tbl-wrap"><table class="tbl" id="${id}"><thead><tr>${cols.map(c => `<th>${C[c][0]}</th>`).join('')}</tr></thead>
    <tbody>${apps.map(a => `<tr class="${onOpen ? 'click' : ''}">${cols.map(c => `<td>${C[c][1](a)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

export function kpi(label, value, sub = '', accent = false) {
  return `<div class="card kpi ${accent ? 'accent' : ''}"><span class="l">${label}</span><span class="v">${value}</span>${sub ? `<span class="s">${sub}</span>` : ''}</div>`;
}

export function tabs(root, defs, onChange) {
  const bar = el('<div class="tabs" role="tablist"></div>');
  defs.forEach((d, i) => {
    const b = el(`<button class="tab ${i === 0 ? 'on' : ''}" role="tab">${esc(d.label)}${d.count ? `<span class="count">${d.count}</span>` : ''}</button>`);
    b.onclick = () => { bar.querySelectorAll('.tab').forEach(x => x.classList.remove('on')); b.classList.add('on'); onChange(d.key); };
    bar.appendChild(b);
  });
  root.appendChild(bar);
}

// ───────── الجلسة 2: أدوات مشتركة إضافية ─────────

// المحافظات الثماني عشرة وإحداثيات تقريبية لمركز كل منها (لخريطة البنك المركزي)
export const GOVS = [
  ['بغداد', 33.31, 44.36], ['البصرة', 30.51, 47.78], ['نينوى', 36.34, 43.13], ['أربيل', 36.19, 44.01], ['النجف', 32.0, 44.33],
  ['كربلاء', 32.6, 44.02], ['بابل', 32.47, 44.42], ['ذي قار', 31.05, 46.26], ['الأنبار', 33.42, 43.3], ['ديالى', 33.75, 44.6],
  ['واسط', 32.5, 45.82], ['ميسان', 31.84, 47.14], ['الديوانية', 31.99, 44.92], ['صلاح الدين', 34.6, 43.68], ['كركوك', 35.47, 44.39],
  ['المثنى', 31.31, 45.28], ['السليمانية', 35.56, 45.43], ['دهوك', 36.87, 42.99]
];
export const govOptions = (sel = '') => `<option value="">اختر المحافظة</option>` + GOVS.map(([g]) => `<option ${g === sel ? 'selected' : ''}>${g}</option>`).join('');

// القسط الشهري بطريقة التقسيط المتناقص
export function installment(amount, ratePct, months) {
  const r = ratePct / 1200;
  if (!r) return Math.round(amount / months);
  return Math.round(amount * r / (1 - Math.pow(1 + r, -months)));
}

export const maskPhone = p => p ? String(p).replace(/^(\d{4})\d{4}(\d{3})$/, '$1••••$2') : '—';
export const maskId = s => s ? '••••••••' + String(s).slice(-4) : '—';

// نجوم التقييم (تقبل كسوراً)
export const stars = (v, size = 15) => `<span class="stars" style="--v:${Number(v || 0).toFixed(2)};font-size:${size}px" aria-label="${Number(v || 0).toFixed(1)} من 5"><span>★★★★★</span></span>`;

// نافذة منبثقة عامة
export function modal(html, { wide = false, onClose } = {}) {
  const bg = el(`<div class="mdl-bg"><div class="mdl ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><button class="mdl-x" aria-label="إغلاق">×</button><div class="mdl-b"></div></div></div>`);
  bg.querySelector('.mdl-b').innerHTML = html;
  document.body.appendChild(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  const close = () => { bg.classList.remove('on'); setTimeout(() => bg.remove(), 200); onClose && onClose(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', esc_);
  bg.querySelector('.mdl-x').onclick = close;
  bg.addEventListener('click', e => { if (e.target === bg) close(); });
  return { el: bg.querySelector('.mdl-b'), close };
}

// نافذة رمز التحقق OTP — في وضع المطور الرمز 1234
// verify(code) تُستدعى للتحقق (من الخادم غالباً) وترمي خطأ إن فشل. تعيد Promise بالرمز أو null عند الإلغاء.
export function askOtp({ title = 'رمز التحقق', phone = '', purpose = '', verify } = {}) {
  return new Promise(resolve => {
    const dev = window.ALWAH_DEV || {};
    let done = false;
    const m = modal(`<div class="otp">
      <div class="otp-ic">✉</div>
      <h3>${esc(title)}</h3>
      <p class="muted">أرسلنا رمزاً من 4 أرقام برسالة نصية إلى <b class="num">${esc(maskPhone(phone))}</b>${purpose ? `<br><span class="small">${esc(purpose)}</span>` : ''}</p>
      ${dev.dev_mode ? `<button type="button" class="devchip" data-fill>وضع المطور — الرمز <b class="num">${esc(dev.dev_otp || '1234')}</b> · اضغط للتعبئة</button>` : ''}
      <div class="otp-in" dir="ltr">${[0, 1, 2, 3].map(i => `<input inputmode="numeric" maxlength="1" aria-label="الرقم ${i + 1}" autocomplete="${i === 0 ? 'one-time-code' : 'off'}">`).join('')}</div>
      <div class="err-line" hidden></div>
      <button class="btn cyan block" data-ok>تأكيد</button>
      <p class="small muted" style="margin-top:12px">لم يصلك الرمز؟ <button type="button" class="linkbtn" data-re disabled>إعادة الإرسال <span data-t>30</span></button></p>
    </div>`, { onClose: () => { if (!done) resolve(null); } });
    const ins = [...m.el.querySelectorAll('.otp-in input')], err = m.el.querySelector('.err-line'), ok = m.el.querySelector('[data-ok]');
    const code = () => ins.map(i => i.value).join('');
    ins.forEach((inp, i) => {
      inp.addEventListener('input', () => {
        inp.value = inp.value.replace(/\D/g, '').slice(-1);
        if (inp.value && i < 3) ins[i + 1].focus();
        if (code().length === 4) submit();
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Backspace' && !inp.value && i > 0) ins[i - 1].focus(); if (e.key === 'Enter') submit(); });
      inp.addEventListener('paste', e => {
        const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 4);
        if (d.length) { e.preventDefault(); d.split('').forEach((c, k) => ins[k] && (ins[k].value = c)); if (d.length === 4) submit(); }
      });
    });
    setTimeout(() => ins[0].focus(), 60);
    const fill = m.el.querySelector('[data-fill]');
    if (fill) fill.onclick = () => { (dev.dev_otp || '1234').split('').forEach((c, k) => ins[k].value = c); submit(); };
    let t = 30; const tEl = m.el.querySelector('[data-t]'), re = m.el.querySelector('[data-re]');
    const iv = setInterval(() => { t--; tEl.textContent = t; if (t <= 0) { clearInterval(iv); re.disabled = false; tEl.textContent = ''; } }, 1000);
    re.onclick = () => { toast('أُعيد إرسال الرمز', 'ok'); re.disabled = true; t = 30; tEl.textContent = t; };
    let busy = false;
    async function submit() {
      if (busy) return;
      const c = code();
      if (c.length !== 4) { err.hidden = false; err.textContent = 'اكتب الأرقام الأربعة'; return; }
      busy = true; ok.disabled = true; ok.textContent = 'جارِ التحقق…'; err.hidden = true;
      try {
        if (verify) await verify(c);
        done = true; clearInterval(iv); m.close(); resolve(c);
      } catch (e) {
        err.hidden = false; err.textContent = cleanErr(e);
        ins.forEach(i => i.value = ''); ins[0].focus();
        ok.disabled = false; ok.textContent = 'تأكيد'; busy = false;
      }
    }
    ok.onclick = submit;
  });
}

// تحقق موحّد من الرمز عبر الخادم (يرفض أي رمز غير صحيح)
export const serverOtp = (sb, phone, purpose) => async code => { await rpc(sb, 'verify_otp', { p_phone: phone, p_code: code, p_purpose: purpose }); };

export function normPhone(p) {
  let d = String(p || '').replace(/[^\d٠-٩]/g, '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
  if (d.startsWith('00964')) d = '0' + d.slice(5); else if (d.startsWith('964')) d = '0' + d.slice(3); else if (/^7\d{9}$/.test(d)) d = '0' + d;
  return d;
}
export const validPhone = p => /^07[3-9]\d{8}$/.test(normPhone(p));
export const digits = s => String(s || '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/\D/g, '');
