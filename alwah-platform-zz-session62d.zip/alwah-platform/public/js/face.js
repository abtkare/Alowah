// ألواح — الجلسة 49: التحقق بالوجه (Face ID) لموظفي الجهات
// • faceVerify(sb): نافذة واحدة بزر واحد — تسجيل بصمة الوجه أول مرة، ثم التحقق قبل الإجراء. الخادم يفحص التوقيع.
// • faceAccountCard(ctx): بطاقة «بصمة الوجه» في «حسابي».
// • paintFaceBadges(sb, root) و faceResetForm: حالة بصمة الوجه للموظفين في «فريقي» وعند مشغّل النظام، وإعادة ضبطها.
// • adminFacePanel(sb, box): التشغيل الحقيقي أو وضع المطور، وصلاحية التحقق.
import { esc, el, toast, cleanErr, rpc, modal, dt, ago, badge } from './core.js';

const FACE_ICON = `<svg viewBox="0 0 64 64" width="64" height="64" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <path d="M8 20V12a4 4 0 0 1 4-4h8M44 8h8a4 4 0 0 1 4 4v8M56 44v8a4 4 0 0 1-4 4h-8M20 56h-8a4 4 0 0 1-4-4v-8"/>
  <path d="M23 24v4M41 24v4M32 26v10h-3M24 43c5 4 11 4 16 0"/></svg>`;

const ab2b = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b2ab = s => { const t = atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4)); const u = new Uint8Array(t.length); for (let i = 0; i < t.length; i++) u[i] = t.charCodeAt(i); return u.buffer; };
const deviceName = () => { const u = navigator.userAgent; return /iPhone/.test(u) ? 'iPhone' : /iPad/.test(u) ? 'iPad' : /Android/.test(u) ? 'Android' : /Mac/.test(u) ? 'Mac' : /Windows/.test(u) ? 'Windows' : 'جهاز'; };
const isApple = () => /iPhone|iPad|Mac/.test(navigator.userAgent);
const faceWord = () => isApple() ? 'Face ID' : 'بصمة الوجه';
export const faceSupported = () => !!(window.PublicKeyCredential && navigator.credentials);

async function api(sb, path, body) {
  const { data: { session } } = await sb.auth.getSession();
  const r = await fetch(`/api/face/${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session?.access_token || ''}` }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || 'تعذّر التحقق'), { code: j.code });
  return j;
}

// خطوة واحدة على الجهاز: register أو verify
async function ceremony(sb, mode) {
  if (!faceSupported()) throw new Error('هذا المتصفح لا يدعم التحقق بالوجه — استخدم Safari أو Chrome حديثاً');
  const { publicKey: o } = await api(sb, 'options', { mode });
  let cred;
  try {
    if (mode === 'register') {
      cred = await navigator.credentials.create({ publicKey: { ...o, challenge: b2ab(o.challenge), user: { ...o.user, id: b2ab(o.user.id) },
        excludeCredentials: (o.excludeCredentials || []).map(c => ({ ...c, id: b2ab(c.id) })) } });
    } else {
      cred = await navigator.credentials.get({ publicKey: { ...o, challenge: b2ab(o.challenge), allowCredentials: (o.allowCredentials || []).map(c => ({ ...c, id: b2ab(c.id) })) } });
    }
  } catch (e) {
    if (e?.name === 'NotAllowedError') throw new Error('أُلغي التحقق أو انتهت مهلته — اضغط مرة أخرى');
    if (e?.name === 'InvalidStateError') throw new Error('هذا الجهاز مسجّل لحسابك مسبقاً');
    throw new Error('تعذّر التحقق على هذا الجهاز: ' + (e?.message || e));
  }
  if (!cred) throw new Error('أُلغي التحقق');
  const R = cred.response, body = { mode, challenge: o.challenge, id: cred.id, clientDataJSON: ab2b(R.clientDataJSON), device: deviceName() };
  if (mode === 'register') {
    if (!R.getPublicKey || !R.getAuthenticatorData) throw new Error('حدّث المتصفح لتسجيل بصمة الوجه (iOS 16 أو أحدث)');
    Object.assign(body, { authenticatorData: ab2b(R.getAuthenticatorData()), publicKey: ab2b(R.getPublicKey()), alg: R.getPublicKeyAlgorithm() });
  } else Object.assign(body, { authenticatorData: ab2b(R.authenticatorData), signature: ab2b(R.signature) });
  return api(sb, 'finish', body);
}

// ───────── النافذة: تُفتح حين يرفض الخادم إجراءً بـ FACE_REQUIRED ─────────
let pending = null;
export function faceVerify(sb, { reason } = {}) {
  if (pending) return pending;
  pending = new Promise(async resolve => {
    let F = {};
    try { F = await rpc(sb, 'my_face'); } catch { F = { devices: [] }; }
    if (F.live === false) { pending = null; return resolve(true); }   // وضع المطور
    const enroll = !(F.devices || []).length;
    let done = false;
    const m = modal(`<div class="fid">
      <div class="fid-ic">${FACE_ICON}</div>
      <h3>${enroll ? `سجّل ${faceWord()} لحسابك` : `تحقّق ${isApple() ? 'بـFace ID' : 'ببصمة الوجه'}`}</h3>
      <p class="small muted">${enroll
        ? 'كل إجراء على معاملة يُنفَّذ بعد التحقق من وجهك. سجّل وجهك على هذا الجهاز مرة واحدة.'
        : esc(reason || 'هذا الإجراء على المعاملة يُنفَّذ بعد التحقق من وجهك.')}</p>
      <div class="fid-err" hidden></div>
      <button class="btn cyan block fid-go">${enroll ? `تسجيل ${faceWord()}` : 'تحقّق الآن'}</button>
      <p class="small muted fid-note">${enroll ? 'يبقى وجهك على جهازك — لا تُرسل صورته. لتغيير الجهاز لاحقاً اطلب من مديرك إعادة الضبط.' : `تبقى صلاحية التحقق ${Number(F.window || 90)} ثانية لإكمال الإجراء.`}</p>
    </div>`, { onClose: () => { if (!done) { done = true; pending = null; resolve(false); } } });
    const go = m.el.querySelector('.fid-go'), err = m.el.querySelector('.fid-err');
    go.onclick = async () => {
      go.disabled = true; go.textContent = 'جارِ التحقق…'; err.hidden = true;
      try {
        await ceremony(sb, enroll ? 'register' : 'verify');
        done = true; pending = null; m.close(); toast(enroll ? `سُجّل ${faceWord()} — يُنفَّذ الإجراء الآن` : 'تم التحقق ✓', 'ok'); resolve(true);
      } catch (e) {
        err.textContent = cleanErr(e); err.hidden = false; go.disabled = false; go.textContent = 'أعد المحاولة';
      }
    };
  });
  return pending;
}

// يغلّف sb.rpc: إن رفض الخادم إجراءً لأنه يحتاج التحقق بالوجه، تُفتح النافذة ثم يُعاد الإجراء نفسه مرة واحدة
export function wrapFace(sb) {
  const orig = sb.rpc.bind(sb);
  sb.rpc = (fn, args, opts) => {
    const b = orig(fn, args, opts), t0 = b.then.bind(b);
    b.then = (ok, bad) => t0(async r => {
      if (r?.error && /FACE_REQUIRED/.test(r.error.message || '') && await faceVerify(sb)) return await orig(fn, args, opts);
      return r;
    }).then(ok, bad);
    return b;
  };
}

// ───────── «حسابي» ─────────
export async function faceAccountCard(ctx) {
  const box = el('<div class="card mb fid-card"></div>');
  const paint = async () => {
    let F;
    try { F = await rpc(ctx.sb, 'my_face'); } catch (e) { box.innerHTML = `<h3>بصمة الوجه</h3><p class="small muted">${esc(cleanErr(e))}</p>`; return; }
    const devs = F.devices || [];
    box.innerHTML = `<h3>${FACE_ICON.replace('width="64" height="64"', 'width="22" height="22"')} بصمة الوجه (${faceWord()})
        <span class="sp"></span>${!F.live ? badge(['وضع المطور — لا يُطلب', 'warn']) : devs.length ? badge(['مسجّلة', 'ok']) : badge(['غير مسجّلة', 'bad'])}</h3>
      <p class="small muted">أي إجراء على معاملة (إنجاز مرحلة، إعادة، اعتماد، صرف…) يُنفَّذ بعد التحقق من وجهك على جهازك.</p>
      ${devs.length ? `<ul class="fid-devs">${devs.map(d => `<li><b>${esc(d.device || 'جهاز')}</b> <span class="muted small">— سُجّل ${dt(d.created_at)}${d.last_used_at ? ` · آخر تحقق ${ago(d.last_used_at)}` : ''}</span></li>`).join('')}</ul>` : ''}
      <div class="row"><span class="sp"></span>
        ${devs.length ? `<button class="btn ghost sm" data-add>إضافة هذا الجهاز</button><button class="btn cyan sm" data-test>جرّب التحقق</button>` : `<button class="btn cyan sm" data-reg>تسجيل ${faceWord()} الآن</button>`}</div>
      ${faceSupported() ? '' : '<p class="small" style="color:var(--bad)">هذا المتصفح لا يدعم التحقق بالوجه.</p>'}`;
    const run = (b, steps, msg) => b.onclick = async () => {
      b.disabled = true;
      try { for (const s of steps) await ceremony(ctx.sb, s); toast(msg, 'ok'); paint(); } catch (e) { toast(cleanErr(e), 'bad'); b.disabled = false; }
    };
    const q = s => box.querySelector(s);
    if (q('[data-reg]')) run(q('[data-reg]'), ['register'], `سُجّل ${faceWord()} لحسابك`);
    if (q('[data-test]')) run(q('[data-test]'), ['verify'], 'تم التحقق ✓');
    if (q('[data-add]')) run(q('[data-add]'), ['verify', 'register'], 'أُضيف هذا الجهاز');
  };
  await paint();
  return box;
}

// ───────── «فريقي» ومشغّل النظام: الحالة لكل موظف ─────────
export async function paintFaceBadges(sb, root) {
  let F;
  try { F = await rpc(sb, 'team_face'); } catch { return; }
  const by = Object.fromEntries((F.users || []).map(u => [u.user_id, u]));
  root.querySelectorAll('[data-face]').forEach(s => {
    const u = by[s.dataset.face]; if (!u) return;
    s.innerHTML = !F.live ? '' : Number(u.devices) ? `<span class="badge ok sm" title="${u.last_verify ? 'آخر تحقق ' + esc(ago(u.last_verify)) : ''}">Face ID ✓</span>` : '<span class="badge warn sm" title="يُطلب منه التسجيل عند أول إجراء">بانتظار Face ID</span>';
  });
  return F;
}

export function faceResetForm(sb, u, onDone) {
  const m = modal(`<h3>إعادة ضبط بصمة الوجه — ${esc(u.full_name)}</h3>
    <p class="small muted">يُلغى تسجيل وجهه على كل أجهزته، ويُطلب منه التسجيل من جديد عند أول إجراء (جهاز جديد، فقدان الهاتف…). يُحفظ في سجل الإدارة.</p>
    <div class="field"><label>السبب</label><input class="input" data-r placeholder="هاتف جديد"></div>
    <div class="row"><span class="sp"></span><button class="btn ghost" data-x>إلغاء</button><button class="btn warn" data-s>إعادة الضبط</button></div>`);
  m.el.querySelector('[data-x]').onclick = m.close;
  m.el.querySelector('[data-s]').onclick = async e => {
    e.target.disabled = true;
    try { await rpc(sb, 'team_face_reset', { p_user: u.id, p_reason: m.el.querySelector('[data-r]').value.trim() }); m.close(); toast('أُعيد ضبط بصمة الوجه', 'ok'); onDone && onDone(); }
    catch (er) { toast(cleanErr(er), 'bad'); e.target.disabled = false; }
  };
}

// ───────── مشغّل النظام ← الإعدادات ─────────
export async function adminFacePanel(sb, box) {
  const paint = async (p = {}) => {
    let S;
    try { S = await rpc(sb, 'admin_face_settings', { p }); } catch (e) { if (Object.keys(p).length) { toast(cleanErr(e), 'bad'); return false; } box.innerHTML = `<div class="card"><h3>التحقق بالوجه</h3><p class="small muted">${esc(cleanErr(e))}</p></div>`; return false; }
    box.innerHTML = `<div class="card"><h3>التحقق بالوجه (Face ID) لموظفي الجهات<span class="sp"></span>${S.live ? badge(['تشغيل حقيقي', 'ok']) : badge(['وضع المطور — التحقق متخطّى', 'warn'])}</h3>
      <p class="small muted">كل موظف في المصارف والجهات والشركات يسجّل وجهه على جهازه، ولا يُنفَّذ إجراء على معاملة دون التحقق منه. في وضع المطور لا يُطلب التحقق.</p>
      <div class="og-stats"><span>سجّلوا وجوههم <b class="num">${S.enrolled}</b> من <b class="num">${S.staff}</b> موظف</span><span>تحققات اليوم <b class="num">${S.verifies_today}</b></span></div>
      <div class="row mt" style="gap:8px;flex-wrap:wrap">
        <button class="btn sm ${S.live ? 'warn' : 'ok'}" data-dev="${S.live ? 1 : 0}">${S.live ? 'تفعيل وضع المطور (تخطّي التحقق)' : 'تشغيل حقيقي — طلب التحقق بالوجه'}</button>
        <span class="sp"></span><label class="small muted">صلاحية التحقق (ثانية)</label>
        <input class="input sm" data-win inputmode="numeric" dir="ltr" value="${S.window}" style="max-width:90px"><button class="btn ghost sm" data-ws>حفظ</button></div></div>`;
    // الجلسة 62: كان «return true» قبل ربط الزرين فلا يستجيبان — نُقل إلى ما بعدهما
    box.querySelector('[data-dev]').onclick = async e => { e.target.disabled = true; if (await paint({ dev: Number(e.target.dataset.dev) }) !== false) toast('حُفظ — يسري فوراً', 'ok'); else e.target.disabled = false; };
    box.querySelector('[data-ws]').onclick = async () => { if (await paint({ window: Number(box.querySelector('[data-win]').value) }) !== false) toast('حُفظت صلاحية التحقق', 'ok'); };
    return true;
  };
  await paint();
}
