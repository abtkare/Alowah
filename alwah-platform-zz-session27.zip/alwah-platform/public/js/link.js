// الجلسة 22: صفحة الرابط لمرة واحدة (دون تسجيل)
//  (7) شخص في مكان المنظومة يحدد الموقع بضغطة   (9) الكفيل يوافق على الكفالة من هاتفه برمز تحقق
import { esc, iqd, num, dt, toast, cleanErr, askOtp, GLOSS, SITE_TYPE, setOtpClient } from './core.js';
import { gpsDialog } from './geo.js';
import { pinDialog, placeFromGeo } from './journey22.js';

const CFG = window.ALWAH_CONFIG || {};
const app = document.getElementById('app');
const token = decodeURIComponent(location.pathname.split('/')[2] || '');
const shell = inner => {
  app.innerHTML = `<div class="lk"><header class="lk-h"><a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ألواح</b><small>ألواح الشمس</small></span></a></header>
    <main class="card lk-b">${inner}</main><p class="small muted lk-f">رابط لمرة واحدة من منصة «ألواح» لتمويل منظومات الطاقة الشمسية. لا تشاركه مع غيرك.</p></div>`;
  return app.querySelector('.lk-b');
};
const STATE = {
  missing: ['الرابط غير صحيح', 'تأكد أنك فتحت الرابط كاملاً كما وصلك، أو اطلب من صاحب الطلب أن يرسله مرة أخرى.'],
  used: ['استُخدم هذا الرابط من قبل', 'سُجّل ما طلبناه — شكراً لك. لا تحتاج أن تفعل شيئاً آخر.'],
  expired: ['انتهت صلاحية الرابط', 'الرابط صالح 48 ساعة فقط. اطلب من صاحب الطلب أن يرسل لك رابطاً جديداً.'],
  revoked: ['هذا الرابط قديم', 'أرسل صاحب الطلب رابطاً أحدث — افتح الرابط الأخير الذي وصلك.'],
  closed: ['لم يعد الطلب يحتاج هذا الرابط', 'تقدّم الطلب إلى مرحلة أخرى — شكراً لك.'],
};
const ended = (k, extra = '') => { shell(`<div class="lk-state"><div class="lk-ic">${k === 'used' ? '✓' : '⚠'}</div><h2>${esc(STATE[k][0])}</h2><p class="muted">${esc(STATE[k][1])}</p>${extra}</div>`); };
const okScreen = (t, d) => shell(`<div class="lk-state"><div class="big-ok">✓</div><h2>${esc(t)}</h2><p class="muted">${d}</p><p class="small muted">يمكنك إغلاق هذه الصفحة.</p></div>`);

let sb;
try {
  const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm');
  sb = createClient(CFG.url, CFG.key, { auth: { persistSession: false, autoRefreshToken: false } });
  setOtpClient(sb);
  try { const { data } = await sb.rpc('public_config'); window.ALWAH_DEV = data || {}; } catch { window.ALWAH_DEV = {}; }
} catch (e) { console.error(e); }

const call = async (fn, args) => { const { data, error } = await sb.rpc(fn, args); if (error) throw error; return data; };

if (!sb) shell('<div class="notice warn">تعذّر الاتصال. تحقق من الإنترنت ثم أعد تحميل الصفحة.</div>');
else if (!token) ended('missing');
else {
  let info = null;
  try { info = await call('link_info', { p_token: token }); } catch (e) { shell(`<div class="notice warn">${esc(cleanErr(e))}</div>`); }
  if (info) {
    if (info.state !== 'ok') ended(STATE[info.state] ? info.state : 'missing');
    else if (info.kind === 'site') sitePage(info);
    else if (info.kind === 'guarantor') guarantorPage(info);
    else ended('missing');
  }
}

// (7) تحديد مكان المنظومة لشخص في المكان
function sitePage(info) {
  const b = shell(`<span class="pill">طلب <span class="num">${esc(info.code)}</span></span>
    <h1 class="lk-t">ساعد <b>${esc(info.borrower)}</b> في تحديد مكان منظومته الشمسية</h1>
    <p class="muted">مكان التركيب: <b>${esc(SITE_TYPE[info.site_type] || '')}${info.site_type === 'project' ? ' — ' + esc(info.purpose) : ''}</b>. سيصل المصرف ثم فني المورد إلى هذا المكان بالضبط.</p>
    <ol class="gps-steps"><li>قف <b>في مكان تركيب المنظومة نفسه</b> (السطح أو الساحة).</li><li>اضغط الزر الأزرق بالأسفل.</li><li>إن سألك الهاتف عن الموقع اضغط <b class="ok-t">«سماح»</b>.</li></ol>
    <div class="field"><label>أقرب نقطة دالة (اختياري)</label><input class="input" data-addr maxlength="160" placeholder="مثال: قرب جامع الرحمن — زقاق 12"></div>
    <button class="btn cyan big-btn" data-gps>📍 حدّد المكان الآن</button>
    ${info.manual_ok ? '<button class="btn ghost big-btn mt" data-pin>🗺 لم يعمل الموقع؟ ضع دبوساً على الخريطة</button>' : ''}
    <p class="small muted mt">ينتهي هذا الرابط في ${esc(dt(info.expires_at))}، ويُستخدم مرة واحدة. لا نطلب منك أي بيانات شخصية.</p>`);
  const send = async (p, how) => {
    const g = await placeFromGeo(p.lat, p.lng);
    try {
      await call('link_site_submit', { p_token: token, p: { ...p, address: b.querySelector('[data-addr]').value, geo_gov: g.gov, geo_city: g.city } });
      okScreen('شكراً لك — حُدد مكان المنظومة', `${how}${g.gov ? ` في <b>${esc(g.gov)}${g.city ? ' — ' + esc(g.city) : ''}</b>` : ''}. سيرى ${esc(info.borrower)} ذلك في طلبه فوراً.`);
    } catch (e) { toast(cleanErr(e), 'bad'); }
  };
  b.querySelector('[data-gps]').onclick = async () => {
    const r = await gpsDialog({ title: 'تحديد مكان المنظومة', hint: 'قف في مكان تركيب المنظومة نفسه.', want: Math.min(25, info.accuracy_m || 100), accMax: info.accuracy_m || 100 });
    if (r) send({ lat: r.lat, lng: r.lng, acc: r.acc, source: 'gps' }, 'حُدد المكان من هاتفك');
  };
  const pb = b.querySelector('[data-pin]');
  if (pb) pb.onclick = async () => { const p = await pinDialog({}); if (p) send({ lat: p.lat, lng: p.lng, source: 'manual' }, 'وُضع الدبوس على الخريطة'); };
}

// (9) موافقة الكفيل من هاتفه
function guarantorPage(info) {
  const g = info.guarantor;
  const b = shell(`<span class="pill">طلب كفالة · <span class="num">${esc(info.code)}</span></span>
    <h1 class="lk-t"><b>${esc(info.borrower)}</b> يطلب أن تكون كفيله</h1>
    <p class="muted">في تمويل منظومة طاقة شمسية من <b>${esc(g.bank || 'المصرف')}</b> عبر منصة «ألواح».</p>
    <div class="review"><dl class="kv"><dt>مبلغ التمويل</dt><dd>${iqd(g.amount)}</dd><dt>القسط الشهري ${g.months ? '(تقريباً)' : ''}</dt><dd><b>${iqd(g.installment)}</b> × <span class="num">${num(g.months)}</span> شهراً</dd>
      <dt>عدد الكفلاء المطلوب</dt><dd><span class="num">${g.guarantors_needed}</span></dd></dl></div>
    <div class="notice"><span>ℹ</span><span><b>ماذا تعني الكفالة؟</b> ${esc(GLOSS.guarantor[1])} لا تدفع شيئاً ما دام المقترض يسدد أقساطه.</span></div>
    <h3>بياناتك كما كتبها ${esc(info.borrower.split(' ')[0])}</h3>
    <div class="review"><dl class="kv"><dt>الاسم</dt><dd>${esc(g.name)}</dd><dt>جهة العمل</dt><dd>${esc(g.employer)}</dd><dt>الراتب الشهري</dt><dd>${iqd(g.salary)}</dd><dt>الهاتف</dt><dd><bdi dir="ltr" class="num">${esc(g.phone)}</bdi></dd></dl></div>
    <p class="small muted">إن كان فيها خطأ لا توافق — اطلب منه تصحيحها وإرسال رابط جديد. بعد موافقتك يذهب المصرف لاحقاً إلى مصرف راتبك لتوقيع «تخويل الاستقطاع».</p>
    <button class="btn cyan big-btn" data-yes>✓ أوافق على الكفالة</button>
    <button class="btn ghost big-btn mt" data-no>أعتذر عن الكفالة</button>
    <p class="small muted mt">سيصل رمز من 4 أرقام إلى هاتفك <bdi dir="ltr" class="num">${esc(g.phone)}</bdi> لتأكيد ردّك. ينتهي الرابط في ${esc(dt(info.expires_at))}.</p>`);
  const answer = async accept => {
    const c = await askOtp({ kind: 'guarantor', ref: token, title: accept ? 'تأكيد موافقتك على الكفالة' : 'تأكيد اعتذارك عن الكفالة', phone: g.phone, purpose: `${accept ? 'موافقة' : 'اعتذار'} عن كفالة ${info.borrower} في تمويل ${num(g.amount)} د.ع`,
      verify: code => call('link_guarantor_consent', { p_token: token, p_otp: code, p_accept: accept }) });
    if (!c) return;
    accept ? okScreen('شكراً لك — سُجّلت موافقتك', `وصلت موافقتك إلى ${esc(info.borrower)} فوراً، وهي محفوظة في سجل الطلب.`)
      : okScreen('سُجّل اعتذارك', `أبلغنا ${esc(info.borrower)} ليختار كفيلاً آخر. شكراً لك.`);
  };
  b.querySelector('[data-yes]').onclick = () => answer(true);
  b.querySelector('[data-no]').onclick = () => answer(false);
}
