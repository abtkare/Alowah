// ألواح — الجلسة 27: شاشة الدخول الموحّدة لكل البوابات
// شعار المنصة في الوسط تدور حوله خطوط الحماية، ثم شعار الجهة القطاعية (حسب البوابة) أو المصرف،
// وشريحة متحركة بمزايا البوابة، وأرقام حجم المشروع. الشعارات يرفعها مشغّل النظام من «الإعدادات».
import { esc, rpc } from './core.js';

// رموز افتراضية عامة لكل جهة — تُستبدل بالشعار الرسمي حين يرفعه مشغّل النظام
const I = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
export const EMBLEM = {
  audit: I('<path d="M14 3H6v18h6"/><path d="M14 3l4 4v5"/><path d="M14 3v4h4"/><path d="M9 9h3M9 13h2"/><circle cx="16.5" cy="16.5" r="3.3"/><path d="M19 19l2.5 2.5"/>'),
  integrity: I('<path d="M12 3v18M7 21h10M5 7h14"/><circle cx="12" cy="4.5" r="1.3"/><path d="M5 7l-3 6a3 3 0 006 0z"/><path d="M19 7l-3 6a3 3 0 006 0z"/>'),
  cbi: I('<path d="M3 9.5L12 4l9 5.5z"/><path d="M5 9.5V18M9.7 9.5V18M14.3 9.5V18M19 9.5V18"/><path d="M3 18h18M2 21h20"/>'),
  bank: I('<path d="M3 10L12 4.5 21 10z"/><path d="M6 10v7.5M10 10v7.5M14 10v7.5M18 10v7.5"/><path d="M3.5 17.5h17M2.5 20.5h19"/><circle cx="12" cy="7.8" r=".9"/>'),
  registry: I('<path d="M3 11l9-7 9 7"/><path d="M5.5 9.5V20h13V9.5"/><path d="M10 20v-5.5h4V20"/>'),
  syndicate: I('<circle cx="6.5" cy="9.5" r="1.7"/><circle cx="10" cy="5.8" r="1.7"/><circle cx="14" cy="5.8" r="1.7"/><circle cx="17.5" cy="9.5" r="1.7"/><path d="M12 11.5c-3 0-5.5 3.6-5.5 5.8 0 1.6 1.3 2.7 2.8 2.7 1 0 1.8-.6 2.7-.6s1.7.6 2.7.6c1.5 0 2.8-1.1 2.8-2.7 0-2.2-2.5-5.8-5.5-5.8z"/>'),
  vetdept: I('<path d="M5 20C5 11 10.5 5 20 4c0 9.5-6 15.5-15 16z"/><path d="M5 20l9-9"/>'),
  expert: I('<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 6-7"/><path d="M16 7h4v4"/>'),
  supplier: I('<path d="M4 14l2-9h12l2 9z"/><path d="M5 9.5h14M9.5 5l-1 9M14.5 5l1 9M12 14v5M8 20h8"/>'),
  citizen: I('<circle cx="12" cy="8" r="3"/><path d="M12 2v1.3M17.2 3.6l-.9.9M6.8 3.6l.9.9M3 21h18M5 21v-6l7-4 7 4v6"/>'),
  admin: I('<path d="M12 3l8 3v6c0 5-3.5 8.2-8 9.2C7.5 20.2 4 17 4 12V6z"/><path d="M8.8 12.2l2.2 2.2 4.3-4.6"/>'),
};
// اسم الجهة كما يظهر تحت الشعار
const ENTITY = {
  audit: 'ديوان الرقابة المالية الاتحادي', integrity: 'هيئة النزاهة', cbi: 'البنك المركزي العراقي', bank: 'المصارف المشاركة في المبادرة',
  registry: 'دائرة التسجيل العقاري', syndicate: 'نقابة الأطباء البيطريين', vetdept: 'دائرة البيطرة — وزارة الزراعة', expert: 'الخبراء المعتمدون',
  supplier: 'الموردون المعتمدون', citizen: 'بوابة المقترض', admin: 'مشغّل منصة ألواح',
};

const seal = (portal, logo) => logo
  ? `<img src="${esc(logo)}" alt="">`
  : `<i class="lx-emb">${EMBLEM[portal] || EMBLEM.admin}</i>`;
const monogram = name => esc(String(name || '').replace(/^مصرف\s+/, '').replace(/^ال/, '').trim()[0] || '؟');

const RINGS = `<svg class="lx-rings" viewBox="0 0 400 400" aria-hidden="true">
  <defs>
    <linearGradient id="lxA" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#05DBF3"/><stop offset=".55" stop-color="#06AFF2"/><stop offset="1" stop-color="#4356A3"/></linearGradient>
    <radialGradient id="lxC" cx="50%" cy="50%" r="50%"><stop offset=".45" stop-color="#FFB000" stop-opacity=".16"/><stop offset=".72" stop-color="#05DBF3" stop-opacity=".07"/><stop offset="1" stop-color="#05DBF3" stop-opacity="0"/></radialGradient>
  </defs>
  <circle cx="200" cy="200" r="198" fill="url(#lxC)"/>
  <g class="r r1">
    <circle cx="200" cy="200" r="188" fill="none" stroke="#05DBF3" stroke-opacity=".38" stroke-width="1.2" stroke-dasharray="2 7"/>
    ${[0, 90, 180, 270].map(a => `<g transform="rotate(${a} 200 200)"><rect x="191" y="3" width="18" height="18" rx="5" fill="#050810" stroke="#05DBF3" stroke-width="1.4"/><path d="M196.5 12.2v-2.4a3.5 3.5 0 017 0v2.4" fill="none" stroke="#05DBF3" stroke-width="1.3"/><rect x="195" y="12" width="10" height="6.5" rx="1.6" fill="#05DBF3"/></g>`).join('')}
  </g>
  <g class="r r2">
    <circle cx="200" cy="200" r="168" fill="none" stroke="url(#lxA)" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="118 58"/>
    <circle cx="200" cy="32" r="4.5" fill="#05DBF3" class="lx-node"/><circle cx="345.5" cy="284" r="3.5" fill="#06AFF2"/><circle cx="54.5" cy="284" r="3.5" fill="#4356A3"/>
  </g>
  <g class="r r3"><circle cx="200" cy="200" r="150" fill="none" stroke="#FFB000" stroke-opacity=".5" stroke-width="7" stroke-dasharray="1.3 6.55"/></g>
  <g class="r r4">
    <circle cx="200" cy="200" r="134" fill="none" stroke="#05DBF3" stroke-opacity=".28" stroke-width="1"/>
    <path d="M200 66a134 134 0 0 1 116 67" fill="none" stroke="#FFB000" stroke-width="2.4" stroke-linecap="round"/>
    <path d="M200 334a134 134 0 0 1-116-67" fill="none" stroke="#FFB000" stroke-width="2.4" stroke-linecap="round"/>
  </g>
  <polygon class="lx-hex" points="200,82 302,141 302,259 200,318 98,259 98,141" fill="none" stroke="#05DBF3" stroke-opacity=".32" stroke-width="1.2"/>
</svg>`;

// الهيكل الكامل لشاشة الدخول — formHTML هو محتوى بطاقة الدخول
export function loginShell(P, portal, formHTML) {
  const slides = [
    { k: P.short, h: P.title, p: P.sub },
    ...P.points.map((pt, i) => ({ k: `ما تقدّمه البوابة · ${i + 1}/${P.points.length}`, h: pt, p: '' })),
  ];
  return `<div class="lx" data-portal="${esc(portal)}">
    <section class="lx-hero">
      <div class="lx-bg" aria-hidden="true"><i class="g1"></i><i class="g2"></i><i class="g3"></i><div class="lx-mesh"></div></div>
      <header class="lx-top"><a class="lx-home" href="/">الصفحة الرئيسية</a><span class="lx-demo">نسخة العرض · بيانات تجريبية</span></header>

      <div class="lx-stage"><div class="lx-orbit">
        ${RINGS}<div class="lx-sweep" aria-hidden="true"></div><div class="lx-core" aria-hidden="true"></div>
        <img class="lx-logo" src="/alwah-logo/alwah-icon-420.webp" alt="ألواح" width="420" height="420">
      </div></div>

      <div class="lx-word"><b>ألواح</b><small>ALWAH · SOLAR FINANCE</small></div>
      <p class="lx-tag">منصة حوكمة تمويل منظومات الطاقة الشمسية للأفراد والمشاريع الزراعية والصناعية والقطاعات الأخرى</p>

      <div class="lx-entity">
        <span class="lx-seal" data-seal>${seal(portal)}</span>
        <span class="lx-link" aria-hidden="true"><i></i><b>🔒</b><i></i></span>
        <span class="lx-seal lx-seal-a"><img src="/alwah-logo/favicon/icon-192.png" alt=""></span>
        <span class="lx-ent-t"><small>البوابة الرسمية لـ</small><b data-ent>${esc(ENTITY[portal] || P.short)}</b></span>
      </div>
      <div class="lx-banks" data-banks hidden></div>

      <div class="lx-slides" data-slides>
        ${slides.map((s, i) => `<article class="lx-slide${i ? '' : ' on'}"><span class="lx-k">${esc(s.k)}</span>${i ? `<h2>${esc(s.h)}</h2>` : `<h1>${esc(s.h)}</h1>`}${s.p ? `<p>${esc(s.p)}</p>` : ''}</article>`).join('')}
      </div>
      <div class="lx-dots">${slides.map((_, i) => `<button type="button" class="${i ? '' : 'on'}" data-dot="${i}" aria-label="الشريحة ${i + 1}"></button>`).join('')}</div>

      <ul class="lx-stats">
        <li><b>1</b><span>ترليون دينار<br>رصيد المبادرة</span></li>
        <li><b data-s="banks">—</b><span>مصارف<br>وسيطة</span></li>
        <li><b data-s="gov">—</b><span>جهات حكومية<br>ورقابية</span></li>
        <li><b>18</b><span>محافظة<br>عراقية</span></li>
      </ul>
    </section>

    <section class="lx-panel">
      <div class="lx-card">
        <div class="lx-card-h"><span class="lx-mini" data-seal>${seal(portal)}</span><div><small>${esc(P.short)}</small><b data-ent>${esc(ENTITY[portal] || P.short)}</b></div></div>
        <div class="box">${formHTML}</div>
      </div>
      <p class="lx-secure"><span>🔒</span> اتصال مشفّر · كل دخول يُسجَّل في سجل التدقيق · لا يُطلب منك رمز سري عبر الهاتف</p>
    </section>
  </div>`;
}

// تشغيل الشريحة، وجلب الشعارات والأرقام، وتبديل شعار المصرف حسب اسم المستخدم
export function mountLogin(v, { sb, portal, P }) {
  // الشريحة المتحركة
  const slides = [...v.querySelectorAll('.lx-slide')], dots = [...v.querySelectorAll('[data-dot]')];
  let cur = 0, timer;
  const go = i => { cur = (i + slides.length) % slides.length; slides.forEach((s, j) => s.classList.toggle('on', j === cur)); dots.forEach((d, j) => d.classList.toggle('on', j === cur)); };
  const play = () => { clearInterval(timer); if (!matchMedia('(prefers-reduced-motion: reduce)').matches) timer = setInterval(() => { if (!document.body.contains(v)) return clearInterval(timer); go(cur + 1); }, 5200); };
  dots.forEach(d => d.onclick = () => { go(Number(d.dataset.dot)); play(); });
  let sx = null; const box = v.querySelector('[data-slides]');
  box.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
  box.addEventListener('touchend', e => { if (sx == null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 40) { go(cur + (dx > 0 ? 1 : -1)); play(); } sx = null; });
  play();

  if (!sb) return;
  const setSeal = (logo, key = portal) => v.querySelectorAll('[data-seal]').forEach(s => { s.innerHTML = seal(key, logo); s.classList.toggle('has-img', !!logo); });
  const setEnt = t => v.querySelectorAll('[data-ent]').forEach(s => { s.textContent = t; });

  rpc(sb, 'public_brand', { p_portal: portal }).then(b => {
    if (!b) return;
    if (b.logo) setSeal(b.logo);
    const st = b.stats || {};
    v.querySelectorAll('[data-s]').forEach(n => countUp(n, Number(st[n.dataset.s] || 0)));
    if (portal !== 'bank' || !b.banks?.length) return;
    // المصارف: شريط بشعارات كل المصارف، ويبرز مصرف المستخدم عند كتابة اسمه (snb. ← السنابل)
    const row = v.querySelector('[data-banks]'); row.hidden = false;
    row.innerHTML = `<small>المصارف المرتبطة بالمنصة</small><div>${b.banks.map(k => `<span class="lx-bank" data-bank="${esc(k.id)}" title="${esc(k.name)}">
      <i>${k.logo ? `<img src="${esc(k.logo)}" alt="">` : `<em>${monogram(k.name)}</em>`}</i><b>${esc(k.name)}</b>${k.islamic ? '<s>إسلامي</s>' : ''}</span>`).join('')}</div>`;
    const u = v.querySelector('input[name="username"]');
    if (!u) return;
    const pick = () => {
      const pre = u.value.trim().toLowerCase().split('.')[0];
      const k = u.value.includes('.') ? b.banks.find(x => x.prefix && x.prefix === pre) : null;
      row.querySelectorAll('[data-bank]').forEach(n => n.classList.toggle('on', n.dataset.bank === k?.id));
      v.classList.toggle('lx-picked', !!k);
      setEnt(k ? k.name : ENTITY.bank);
      if (k) v.querySelectorAll('[data-seal]').forEach(s => { s.innerHTML = k.logo ? `<img src="${esc(k.logo)}" alt="">` : `<em class="lx-mono">${monogram(k.name)}</em>`; s.classList.toggle('has-img', !!k.logo); });
      else setSeal(b.logo);
    };
    u.addEventListener('input', pick); pick();
  }).catch(() => {});
}

function countUp(n, to) {
  if (!to) { n.textContent = '—'; return; }
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { n.textContent = to; return; }
  const t0 = performance.now(), d = 900;
  const f = t => { const k = Math.min(1, (t - t0) / d); n.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(f); };
  requestAnimationFrame(f);
}
