// خادم «ألواح» — بلا حزم خارجية. يخدم الملفات الثابتة ويوجّه روابط البوابات.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://chjeqtjyywomtcenizxp.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_yewCPqcDPAFW8RPqeJgrow_QTx57Ixy';

// كل بوابة لها رابط دخول مستقل
const PORTALS = ['citizen', 'bank', 'registry', 'cbi', 'supplier', 'integrity'];

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json',
  '.ico': 'image/x-icon', '.mp4': 'video/mp4', '.webm': 'video/webm', '.vtt': 'text/vtt; charset=utf-8', '.woff2': 'font/woff2'
};
const SECURITY = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' };

function send(res, code, body, type, extra = {}) {
  res.writeHead(code, { 'Content-Type': type, ...SECURITY, ...extra });
  res.end(body);
}

// يدعم طلبات المدى (Range) — ضروري لتشغيل الفيديو على آيفون وسفاري
function serveFile(req, res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return serve404(res);
    const ext = path.extname(file).toLowerCase();
    const type = TYPES[ext] || 'application/octet-stream';
    const cache = ext === '.html' ? 'no-cache' : (ext === '.mp4' || ext === '.jpg' || ext === '.webm') ? 'public, max-age=86400' : 'public, max-age=300';
    const head = { 'Content-Type': type, 'Cache-Control': cache, 'Accept-Ranges': 'bytes', ...SECURITY };
    const range = req.headers.range;
    let start = 0, end = st.size - 1, code = 200;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (m) {
        if (m[1] === '' && m[2] !== '') { start = Math.max(0, st.size - Number(m[2])); }
        else { start = Number(m[1] || 0); if (m[2] !== '') end = Math.min(Number(m[2]), st.size - 1); }
        if (start > end || start >= st.size) {
          res.writeHead(416, { 'Content-Range': `bytes */${st.size}`, ...SECURITY }); return res.end();
        }
        code = 206; head['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
      }
    }
    head['Content-Length'] = end - start + 1;
    res.writeHead(code, head);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.end()).pipe(res);
  });
}

function serve404(res) {
  fs.readFile(path.join(PUB, '404.html'), (e, d) => send(res, 404, d || 'Not found', 'text/html; charset=utf-8'));
}

http.createServer((req, res) => {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { return serve404(res); }

  if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
  if (p === '/config.js') {
    const js = `window.ALWAH_CONFIG=${JSON.stringify({ url: SUPABASE_URL, key: SUPABASE_ANON_KEY })};`;
    return send(res, 200, js, TYPES['.js'], { 'Cache-Control': 'no-cache' });
  }

  const first = p.split('/')[1];
  if (p === '/' || p === '') return serveFile(req, res, path.join(PUB, 'index.html'));
  if (PORTALS.includes(first) && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'portal.html'));
  if (first === 'demo' && !path.extname(p)) return serveFile(req, res, path.join(PUB, 'demo.html'));

  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB)) return serve404(res);
  serveFile(req, res, file);
}).listen(PORT, () => console.log(`Alwah running on :${PORT}`));
