// بوابة المواطن — الدخول وإنشاء الحساب واستعادة كلمة المرور (كلها برمز تحقق OTP)
import { esc, el, toast, cleanErr, rpc, askOtp, serverOtp, govOptions, normPhone, validPhone, digits } from './core.js';

const PW_RULE = 'كلمة المرور 8 أحرف على الأقل وتحتوي حروفاً إنجليزية وأرقاماً';
const pwOk = p => p.length >= 8 && /\d/.test(p) && /[A-Za-z]/.test(p);
const emailOf = u => u.includes('@') ? u : `${u}@alwah.demo`;

export function mountCitizenAuth(box, { sb, onDone, err = '' }) {
  const dev = window.ALWAH_DEV || {};
  let mode = 'login';
  draw();

  function draw() {
    box.innerHTML = `
      <div class="seg" role="tablist">
        <button type="button" class="${mode === 'login' ? 'on' : ''}" data-m="login">تسجيل الدخول</button>
        <button type="button" class="${mode === 'register' ? 'on' : ''}" data-m="register">إنشاء حساب</button>
      </div>
      ${dev.dev_mode ? `<div class="devbar">وضع المطور مفعّل — أي شاشة تطلب رمز تحقق تقبل <b class="num">${esc(dev.dev_otp || '1234')}</b></div>` : ''}
      <div data-body></div>`;
    box.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { mode = b.dataset.m; err = ''; draw(); });
    const body = box.querySelector('[data-body]');
    ({ login, register, forgot }[mode])(body);
  }

  function errBox(msg) { return `<div class="err ${msg ? 'on' : ''}">${esc(msg)}</div>`; }
  function showErr(root, msg) { const e = root.querySelector('.err'); e.textContent = msg; e.classList.toggle('on', !!msg); if (msg) e.scrollIntoView({ block: 'nearest' }); }

  async function signIn(username, password) {
    const { error } = await sb.auth.signInWithPassword({ email: emailOf(username), password });
    if (error) throw new Error('رقم الهاتف أو كلمة المرور غير صحيحة');
  }

  function login(root) {
    root.innerHTML = `<form autocomplete="on" novalidate>
      <h2>أهلاً بعودتك</h2><p class="sub">ادخل برقم هاتفك أو اسم المستخدم</p>
      ${errBox(err)}
      <div class="field"><label for="u">رقم الهاتف أو اسم المستخدم</label><input class="input" id="u" name="username" autocomplete="username" dir="ltr" placeholder="07XXXXXXXXX" required></div>
      <div class="field"><label for="p">كلمة المرور</label><div class="pw"><input class="input" id="p" name="password" type="password" autocomplete="current-password" dir="ltr" required><button type="button" class="eye" aria-label="إظهار كلمة المرور">👁</button></div></div>
      <div class="row" style="margin:-4px 0 16px"><span class="sp"></span><button type="button" class="linkbtn" data-forgot>نسيت كلمة المرور؟</button></div>
      <button class="btn cyan block" type="submit">دخول</button>
      <p class="other">ليس لديك حساب؟ <button type="button" class="linkbtn" data-reg>أنشئ حساباً خلال دقيقتين</button></p>
      <p class="other" style="margin-top:6px"><a href="/">العودة إلى الصفحة الرئيسية</a></p>
    </form>`;
    const f = root.querySelector('form');
    eye(root);
    root.querySelector('[data-forgot]').onclick = () => { mode = 'forgot'; draw(); };
    root.querySelector('[data-reg]').onclick = () => { mode = 'register'; draw(); };
    f.onsubmit = async ev => {
      ev.preventDefault();
      let u = f.u.value.trim().toLowerCase();
      if (!u || !f.p.value) return showErr(root, 'اكتب رقم الهاتف وكلمة المرور');
      if (/^[\d\s+٠-٩]+$/.test(u)) u = normPhone(u);
      const btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'جارِ التحقق…'; showErr(root, '');
      try { await signIn(u, f.p.value); onDone(); }
      catch (e) { showErr(root, cleanErr(e)); btn.disabled = false; btn.textContent = 'دخول'; }
    };
  }

  function register(root) {
    const st = { step: 1, phone: '', otp: '' };
    paint();
    function paint() {
      root.innerHTML = `<div class="steps3">${['رقم الهاتف', 'البيانات', 'كلمة المرور'].map((s, i) => `<span class="${i + 1 < st.step ? 'done' : i + 1 === st.step ? 'cur' : ''}"><i>${i + 1 < st.step ? '✓' : i + 1}</i>${s}</span>`).join('')}</div>
        <form novalidate></form>`;
      const f = root.querySelector('form');
      if (st.step === 1) {
        f.innerHTML = `<h2>حساب جديد</h2><p class="sub">نتحقق من رقم هاتفك برسالة نصية</p>${errBox('')}
          <div class="field"><label for="ph">رقم الهاتف المحمول</label><input class="input" id="ph" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX" value="${esc(st.phone)}" autocomplete="tel"></div>
          <button class="btn cyan block" type="submit">إرسال رمز التحقق</button>
          <p class="other">لديك حساب؟ <button type="button" class="linkbtn" data-login>سجّل الدخول</button></p>`;
        f.querySelector('[data-login]').onclick = () => { mode = 'login'; draw(); };
        f.onsubmit = async ev => {
          ev.preventDefault();
          const ph = normPhone(f.ph.value);
          if (!validPhone(ph)) return showErr(root, 'رقم الهاتف غير صحيح — اكتبه بالصيغة 07XXXXXXXXX');
          const code = await askOtp({ title: 'تأكيد رقم الهاتف', phone: ph, purpose: 'لإنشاء حسابك في منصة ألواح', verify: serverOtp(sb, ph, 'register') });
          if (!code) return;
          st.phone = ph; st.otp = code; st.step = 2; paint();
        };
      } else if (st.step === 2) {
        f.innerHTML = `<h2>بياناتك الشخصية</h2><p class="sub">كما هي في البطاقة الوطنية الموحدة</p>${errBox('')}
          <div class="field"><label for="nm">الاسم الرباعي</label><input class="input" id="nm" value="${esc(st.name || '')}" autocomplete="name" placeholder="مثال: علي حسن محمد كاظم"></div>
          <div class="field"><label for="nid">رقم البطاقة الوطنية (12 رقماً)</label><input class="input" id="nid" inputmode="numeric" dir="ltr" maxlength="12" value="${esc(st.nid || '')}"></div>
          <div class="grid g2" style="gap:12px">
            <div class="field"><label for="bd">تاريخ الميلاد</label><input class="input" id="bd" type="date" dir="ltr" value="${esc(st.bd || '')}" max="${new Date(Date.now() - 18 * 365.25 * 864e5).toISOString().slice(0, 10)}"></div>
            <div class="field"><label for="gv">المحافظة</label><select class="input" id="gv">${govOptions(st.gov)}</select></div>
          </div>
          <div class="row"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button class="btn cyan" type="submit">التالي</button></div>`;
        f.querySelector('[data-back]').onclick = () => { st.step = 1; paint(); };
        f.onsubmit = ev => {
          ev.preventDefault();
          const name = f.nm.value.trim().replace(/\s+/g, ' '), nid = digits(f.nid.value);
          if (name.split(' ').length < 3) return showErr(root, 'اكتب الاسم الثلاثي على الأقل كما في البطاقة');
          if (!/^\d{12}$/.test(nid)) return showErr(root, 'رقم البطاقة الوطنية 12 رقماً');
          if (!f.bd.value) return showErr(root, 'اختر تاريخ الميلاد');
          if (new Date(f.bd.value) > new Date(Date.now() - 18 * 365.25 * 864e5)) return showErr(root, 'يجب أن يكون عمرك 18 سنة فأكثر');
          if (!f.gv.value) return showErr(root, 'اختر المحافظة');
          Object.assign(st, { name, nid, bd: f.bd.value, gov: f.gv.value, step: 3 }); paint();
        };
      } else {
        f.innerHTML = `<h2>كلمة المرور</h2><p class="sub">ستدخل لاحقاً برقم هاتفك <b class="num">${esc(st.phone)}</b> وكلمة المرور</p>${errBox('')}
          <div class="field"><label for="pw">كلمة المرور</label><div class="pw"><input class="input" id="pw" type="password" dir="ltr" autocomplete="new-password"><button type="button" class="eye" aria-label="إظهار">👁</button></div>
            <div class="pwm"><i></i></div><small class="muted">${PW_RULE}</small></div>
          <div class="field"><label for="pw2">تأكيد كلمة المرور</label><input class="input" id="pw2" type="password" dir="ltr" autocomplete="new-password"></div>
          <label class="check"><input type="checkbox" id="ok"> أوافق على شروط استخدام المنصة ومشاركة بياناتي مع المصرف الذي أختاره لدراسة طلبي</label>
          <div class="row mt"><button type="button" class="btn ghost" data-back>رجوع</button><span class="sp"></span><button class="btn cyan" type="submit">إنشاء الحساب</button></div>`;
        eye(root);
        const meter = f.querySelector('.pwm i');
        f.pw.oninput = () => { const p = f.pw.value; const s = (p.length >= 8) + /\d/.test(p) + /[A-Za-z]/.test(p) + /[^A-Za-z0-9]/.test(p) + (p.length >= 12); meter.style.width = s * 20 + '%'; meter.style.background = s < 3 ? 'var(--bad)' : s < 4 ? 'var(--sun)' : 'var(--ok)'; };
        f.querySelector('[data-back]').onclick = () => { st.step = 2; paint(); };
        f.onsubmit = async ev => {
          ev.preventDefault();
          if (!pwOk(f.pw.value)) return showErr(root, PW_RULE);
          if (f.pw.value !== f.pw2.value) return showErr(root, 'كلمتا المرور غير متطابقتين');
          if (!f.ok.checked) return showErr(root, 'يلزم الموافقة على شروط الاستخدام');
          const btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'جارِ الإنشاء…';
          try {
            const r = await rpc(sb, 'register_citizen', { p_phone: st.phone, p_otp: st.otp, p_full_name: st.name, p_national_id: st.nid, p_birth_date: st.bd, p_governorate: st.gov, p_password: f.pw.value });
            await signIn(r.username, f.pw.value);
            toast('أهلاً بك في ألواح — تم إنشاء حسابك', 'ok');
            onDone({ fresh: true });
          } catch (e) { showErr(root, cleanErr(e)); btn.disabled = false; btn.textContent = 'إنشاء الحساب'; }
        };
      }
    }
  }

  function forgot(root) {
    root.innerHTML = `<form novalidate><h2>استعادة كلمة المرور</h2><p class="sub">نرسل رمز تحقق إلى هاتفك المسجل</p>${errBox('')}
      <div class="field"><label for="ph">رقم الهاتف</label><input class="input" id="ph" inputmode="tel" dir="ltr" placeholder="07XXXXXXXXX"></div>
      <div class="field"><label for="pw">كلمة المرور الجديدة</label><div class="pw"><input class="input" id="pw" type="password" dir="ltr" autocomplete="new-password"><button type="button" class="eye" aria-label="إظهار">👁</button></div><small class="muted">${PW_RULE}</small></div>
      <button class="btn cyan block" type="submit">إرسال الرمز وتغيير كلمة المرور</button>
      <p class="other"><button type="button" class="linkbtn" data-login>العودة لتسجيل الدخول</button></p>
      <p class="small muted" style="text-align:center">الحسابات التجريبية (citizen1…) تُدار من المطور ولا تُستعاد من هنا.</p></form>`;
    eye(root);
    const f = root.querySelector('form');
    f.querySelector('[data-login]').onclick = () => { mode = 'login'; draw(); };
    f.onsubmit = async ev => {
      ev.preventDefault();
      const ph = normPhone(f.ph.value);
      if (!validPhone(ph)) return showErr(root, 'رقم الهاتف غير صحيح');
      if (!pwOk(f.pw.value)) return showErr(root, PW_RULE);
      const pw = f.pw.value;
      const code = await askOtp({ title: 'استعادة كلمة المرور', phone: ph, verify: c => rpc(sb, 'reset_password_otp', { p_phone: ph, p_otp: c, p_new_password: pw }) });
      if (!code) return;
      try { await signIn(ph, pw); toast('تم تغيير كلمة المرور', 'ok'); onDone(); }
      catch (e) { showErr(root, cleanErr(e)); }
    };
  }

  function eye(root) {
    root.querySelectorAll('.eye').forEach(b => b.onclick = () => { const i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; });
  }
}
