// لوحة البنك المركزي — الحصص، التعاميم، السيولة، خريطة المنظومات
import { esc, iqd, mln, pct, num, kpi, appsTable, openApp, dt, tabs, badge, BATCH_STATUS, rpc, toast, cleanErr, modal } from '../core.js';
import { perfView } from '../perf.js';

let leafletReady;
function loadLeaflet() {
  if (leafletReady) return leafletReady;
  leafletReady = new Promise((res, rej) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css);
    const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = rej; document.head.appendChild(s);
  });
  return leafletReady;
}

export async function render(ctx) {
  const { sb, root, orgs } = ctx;
  const [apps, allocs, circ, settings, batches] = await Promise.all([
    sb.from('applications').select('*').order('updated_at', { ascending: false }).then(r => r.data || []),
    sb.from('bank_allocations').select('*').then(r => r.data || []),
    sb.from('circulars').select('*').order('issued_on', { ascending: false }).then(r => r.data || []),
    sb.from('settings').select('*').then(r => r.data || []),
    sb.from('cbi_batches').select('*').order('created_at', { ascending: false }).then(r => r.data || []),
  ]);
  const done = apps.filter(a => a.status === 'completed');
  const live = apps.filter(a => ['active', 'returned'].includes(a.status));
  const pending = batches.filter(b => b.status === 'sent');
  const lateExec = live.filter(a => a.cbi_approved_at && a.stage < 35 && (Date.now() - new Date(a.cbi_approved_at)) / 864e5 > 30);
  const mw = done.reduce((s, a) => s + Number(a.kw), 0) / 1000;
  const byGov = {};
  apps.forEach(a => { const g = byGov[a.governorate] ||= { n: 0, done: 0, kw: 0, amt: 0 }; g.n++; if (a.status === 'completed') { g.done++; g.kw += Number(a.kw); g.amt += a.amount; } });

  root.innerHTML = `
    <div class="page-head"><div><h1>البنك المركزي العراقي</h1><p>مبادرة تمويل منظومات الطاقة الشمسية — قرار السلف التجميعية، وأداء المصارف، والإشراف دون تعديل الطلبات الفردية.</p></div></div>
    <div class="grid g4 mb">
      ${kpi('القدرة المركّبة', mw >= 1 ? `<span class="num">${mw.toLocaleString('en-US', { maximumFractionDigits: 2 })}</span> MW` : `<span class="num">${num(mw * 1000)}</span> kW`, `${done.length} منظومة موثقة ومدققة`, true)}
      ${kpi('إجمالي التمويل المصروف', mln(done.reduce((s, a) => s + a.amount, 0)), 'دينار عراقي')}
      ${kpi('سلف بانتظار قرارك', `<span class="num">${pending.length}</span>`, `بمبلغ ${mln(pending.reduce((s, b) => s + b.total, 0))} · ${lateExec.length} طلب تجاوز مهلة التنفيذ`)}
      ${kpi('المصارف المشاركة', `<span class="num">${allocs.length}</span>`, `مخصصات ${mln(allocs.reduce((s, a) => s + a.allocated, 0))}`)}
    </div>
    <div id="tabs"></div><div id="body"></div>`;

  const body = root.querySelector('#body');
  const defs = [{ key: 'map', label: 'الخريطة والمحافظات' }, { key: 'batch', label: 'السلف التجميعية', count: pending.length }, { key: 'perf', label: 'أداء المصارف' }, { key: 'quota', label: 'حصص المصارف' }, { key: 'circ', label: 'السياسة والإعدادات' }, { key: 'all', label: 'كل الطلبات' }];
  ctx.cbiTab = ctx.cbiTab || 'map';
  tabs(root.querySelector('#tabs'), defs, k => { ctx.cbiTab = k; show(k); });
  root.querySelectorAll('.tab').forEach((b, i) => b.classList.toggle('on', defs[i].key === ctx.cbiTab));
  const open = a => openApp(ctx, a, {});

  async function show(k) {
    if (k === 'map') {
      const rows = Object.entries(byGov).sort((a, b) => b[1].kw - a[1].kw);
      body.innerHTML = `<div class="grid g-side"><div class="card"><h3>خريطة المنظومات <span class="sp"></span><span class="legend" style="margin:0"><span><i style="background:#0E9F6E"></i>مركّبة</span><span><i style="background:#FFB000"></i>قيد التنفيذ</span></span></h3><div id="map"></div></div>
        <div class="card flush"><h3>حسب المحافظة</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>المحافظة</th><th>الطلبات</th><th>مركّبة</th><th>kW</th></tr></thead><tbody>
        ${rows.map(([g, v]) => `<tr><td>${esc(g)}</td><td class="num">${v.n}</td><td class="num">${v.done}</td><td class="num">${num(v.kw)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
      try {
        const L = await loadLeaflet();
        const m = L.map('map', { zoomControl: true }).setView([33.2, 43.7], 6);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 18 }).addTo(m);
        apps.filter(a => a.lat && a.status !== 'rejected').forEach(a => {
          const c = a.status === 'completed' ? '#0E9F6E' : '#FFB000';
          L.circleMarker([a.lat, a.lng], { radius: 5 + Number(a.kw) / 2, color: c, fillColor: c, fillOpacity: .55, weight: 2 })
            .bindPopup(`<div dir="rtl" style="font-family:Cairo"><b>${esc(a.code)}</b><br>${esc(a.governorate)} — ${num(a.kw)} kW<br>${a.status === 'completed' ? 'مركّبة ومدققة' : 'المرحلة ' + a.stage}</div>`).addTo(m);
        });
      } catch { body.querySelector('#map').innerHTML = '<div class="empty">تعذّر تحميل الخريطة</div>'; }
    }
    if (k === 'perf') perfView(ctx, body, { mode: 'oversight' });
    if (k === 'batch') {
      const bank = id => orgs.find(o => o.id === id)?.name || '—';
      body.innerHTML = `<div class="notice">يرفع المصرف طلبات زبائنه مجمّعة في سلفة لا تتجاوز 200 مليون دينار، بكتاب موقّع من إدارته العليا. الموافقة تحجز المبلغ من حصة المصرف وتبدأ مهلة التنفيذ (شهر)، والرفض يعيد الطلبات للمصرف مع الأسباب لإكمال النواقص.</div>
        ${lateExec.length ? `<div class="notice warn"><b>${lateExec.length}</b> طلب تجاوز شهراً من موافقة السلفة دون تنفيذ: ${lateExec.map(a => esc(a.code)).join('، ')}</div>` : ''}
        <div class="card flush"><div class="tbl-wrap"><table class="tbl"><thead><tr><th>السلفة</th><th>المصرف</th><th>الطلبات</th><th>المبلغ</th><th>الكتاب</th><th>الحالة</th><th>التواريخ</th><th></th></tr></thead><tbody>
        ${batches.filter(b => b.status !== 'draft').map(b => `<tr><td><b class="num">${esc(b.code)}</b></td><td>${esc(bank(b.bank_id))}</td><td class="num">${b.apps_count}</td><td>${iqd(b.total)}</td><td class="num small">${esc(b.letter_ref || '—')}<div class="muted">${esc(b.signed_by_name || '')}</div></td>
          <td>${badge(BATCH_STATUS[b.status])}</td><td class="small muted">${b.sent_at ? `أُرسلت ${dt(b.sent_at)}` : ''}${b.decided_at ? `<br>القرار ${dt(b.decided_at)}` : ''}${b.decision_note ? `<br>${esc(b.decision_note)}` : ''}</td>
          <td>${b.status === 'sent' ? `<div class="row" style="gap:6px"><button class="btn sm ok" data-ok="${b.id}">موافقة</button><button class="btn sm bad" data-no="${b.id}">رفض مسبب</button><button class="btn sm ghost" data-apps="${b.id}">الطلبات</button></div>` : `<button class="btn sm ghost" data-apps="${b.id}">الطلبات</button>`}</td></tr>`).join('') || '<tr><td colspan="8" class="empty">لا سلف مرسلة.</td></tr>'}
        </tbody></table></div></div>`;
      body.querySelectorAll('[data-ok]').forEach(x => x.onclick = () => decide(x.dataset.ok, 'approve'));
      body.querySelectorAll('[data-no]').forEach(x => x.onclick = () => decide(x.dataset.no, 'reject'));
      body.querySelectorAll('[data-apps]').forEach(x => x.onclick = () => {
        const rows = apps.filter(a => a.batch_id === x.dataset.apps);
        const m = modal(`<h3>طلبات السلفة</h3>${appsTable(rows, ctx, { onOpen: a => { m.close(); open(a); }, cols: ['code', 'name', 'gov', 'amount', 'stage', 'status'] })}`, { wide: true });
      });
    }
    if (k === 'quota') body.innerHTML = `<div class="grid g3">${allocs.map(a => {
      const b = orgs.find(o => o.id === a.bank_id); const u = (a.reserved + a.disbursed) / a.allocated * 100;
      const w = v => (v / a.allocated * 100).toFixed(2) + '%';
      return `<div class="card"><h3>${esc(b?.name)} <span class="sp"></span>${u >= 90 ? '<span class="badge bad">أحمر</span>' : u >= 80 ? '<span class="badge warn">تنبيه</span>' : '<span class="badge ok">سليم</span>'}</h3>
        <div class="bar"><i style="width:${w(a.disbursed)};background:var(--indigo)"></i><i style="width:${w(a.reserved)};background:var(--sun)"></i></div>
        <dl class="kv mt"><dt>المخصص</dt><dd>${iqd(a.allocated)}</dd><dt>المحجوز</dt><dd>${iqd(a.reserved)}</dd><dt>المصروف</dt><dd>${iqd(a.disbursed)}</dd><dt>الاستخدام</dt><dd>${pct(u)}</dd></dl></div>`;
    }).join('')}</div>`;
    if (k === 'circ') body.innerHTML = `<div class="grid g2"><div class="card"><h3>سجل التعاميم</h3>${circ.map(c => `<div class="alert low"><div class="ic">ت</div><div><h4>${esc(c.title)}</h4><p>رقم <b class="num">${esc(c.number)}</b> · صدر ${dt(c.issued_on).split('،')[0]} · يسري من ${dt(c.effective_on).split('،')[0]}</p><p>${esc(c.summary)}</p></div></div>`).join('')}</div>
      <div class="card flush"><h3>القواعد المالية حسب سياسة التمويل</h3><div class="tbl-wrap"><table class="tbl"><thead><tr><th>القاعدة</th><th>القيمة</th><th>المرجع</th></tr></thead><tbody>
      ${settings.map(s => `<tr><td>${esc(s.label)}</td><td><b class="num">${num(s.value)}</b></td><td class="num muted">${esc(s.circular_no)}</td></tr>`).join('')}</tbody></table></div></div></div>`;
    if (k === 'all') body.innerHTML = `<div class="card flush">${appsTable(apps, ctx, { onOpen: open, cols: ['code', 'name', 'gov', 'kw', 'amount', 'bank', 'stage', 'status'] })}</div>`;
  }
  async function decide(id, action) {
    const m = modal(`<h3>${action === 'approve' ? 'الموافقة على السلفة' : 'رفض السلفة'}</h3>
      <div class="field"><textarea class="input" rows="3" placeholder="${action === 'approve' ? 'ملاحظة (اختيارية)' : 'أسباب الرفض — تُبلَّغ للمصرف والفرع لإكمال النواقص'}"></textarea></div>
      <div class="row mt"><span class="sp"></span><button class="btn ${action === 'approve' ? 'ok' : 'bad'}" data-go>${action === 'approve' ? 'تأكيد الموافقة وحجز المبلغ' : 'تأكيد الرفض'}</button></div>`);
    const go = m.el.querySelector('[data-go]');
    go.onclick = async () => {
      go.disabled = true;
      try { await rpc(sb, 'batch_action', { p_batch: id, p_action: action, p_note: m.el.querySelector('textarea').value.trim() || null }); m.close(); toast(action === 'approve' ? 'تمت الموافقة وأُبلغ المصرف' : 'رُفضت السلفة وأُبلغ المصرف', 'ok'); ctx.refresh(); }
      catch (e) { toast(cleanErr(e), 'bad'); go.disabled = false; }
    };
  }
  show(ctx.cbiTab);
}

export const shouldRefresh = ctx => ctx.cbiTab !== 'perf';
